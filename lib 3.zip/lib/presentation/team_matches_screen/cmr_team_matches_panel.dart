// lib/presentation/team_matches_screen/cmr_team_matches_panel.dart
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/team_matches_screen/team_match_detail_screen.dart';

enum CmrMatchesFilter { all, upcoming, past }

class CmrTeamMatchesPanel extends StatefulWidget {
  final int teamId;
  final String teamName;
  final int clubId;
  final String clubName;

  const CmrTeamMatchesPanel({
    super.key,
    required this.teamId,
    required this.teamName,
    required this.clubId,
    required this.clubName,
  });

  @override
  State<CmrTeamMatchesPanel> createState() => _CmrTeamMatchesPanelState();
}

class _CmrTeamMatchesPanelState extends State<CmrTeamMatchesPanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';
  static const String getUrl = '$apiBase/get_team_matches.php';
  static const String addUrl = '$apiBase/add_team_match.php';
  static const String deleteUrl = '$apiBase/delete_team_match.php';
  static const String getUserUrl = '$apiBase/get_user.php';

  final TextEditingController _searchCtrl = TextEditingController();
  Timer? _searchDebounce;

  bool loading = true;
  bool refreshing = false;
  String? error;

  int userId = 0;
  String role = '';
  CmrMatchesFilter filter = CmrMatchesFilter.all;
  DateTime selectedMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
  DateTime? selectedDay;
  int openingMatchId = 0;
  int calendarRevision = 0;

  List<Map<String, dynamic>> matches = [];

  bool get canEdit => role.toLowerCase().trim() != 'player';

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearchChanged);
    _init();
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearchChanged);
    _searchDebounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    userId = await PrefUtils.getUserId() ?? 0;
    role = userId > 0 ? await _fetchRoleByUser(userId) : '';
    await _fetch(initial: true);
  }

  Future<String> _fetchRoleByUser(int uid) async {
    try {
      final res = await http.get(Uri.parse('$getUserUrl?user_id=$uid')).timeout(const Duration(seconds: 15));
      final data = _decodeJsonMap(res.body);
      final ok = data['success'] == true || data['status'] == 'success';
      if (!ok) return '';
      final user = data['user'];
      if (user is Map) return (user['role'] ?? '').toString().trim().toLowerCase();
    } catch (_) {}
    return '';
  }

  Future<void> _fetch({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      if (initial) {
        loading = true;
      } else {
        refreshing = true;
      }
      error = null;
    });

    try {
      final res = await http.post(
        Uri.parse(getUrl),
        headers: const {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({'team_id': widget.teamId}),
      ).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final ok = data['status'] == 'success' || data['success'] == true;
      if (!ok) throw Exception(data['message']?.toString() ?? 'Не удалось загрузить матчи');

      final list = (data['matches'] as List?) ?? [];
      final parsed = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      parsed.sort((a, b) => _parseDate(_s(a['match_date'])).compareTo(_parseDate(_s(b['match_date']))));

      if (!mounted) return;
      setState(() {
        matches = parsed;

        // На телефоне матчей часто "не видно", если остался фильтр "Впереди"
        // или открыт пустой месяц. После загрузки показываем ближайший месяц,
        // где есть матчи, и оставляем полный список за месяц.
        if (initial || !_hasMatchesInMonth(parsed, selectedMonth)) {
          selectedMonth = _bestMonthForMatches(parsed);
          selectedDay = null;
          filter = CmrMatchesFilter.all;
          calendarRevision++;
        }

        loading = false;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        refreshing = false;
        error = e.toString();
      });
    }
  }

  Map<String, dynamic> _decodeJsonMap(String body) {
    final raw = body.trim();
    final start = raw.indexOf('{');
    if (start < 0) throw Exception('Сервер вернул некорректный ответ');
    final decoded = jsonDecode(raw.substring(start));
    if (decoded is! Map) throw Exception('Некорректный формат ответа API');
    return Map<String, dynamic>.from(decoded);
  }

  Future<void> _openCreate() async {
    if (!canEdit) return;
    if (widget.teamId <= 0) {
      Get.snackbar('Ошибка', 'Не удалось определить team_id');
      return;
    }

    final created = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CmrAddMatchSheet(
        onSubmit: _addMatch,
      ),
    );

    if (created == true) {
      await _fetch();
      Get.snackbar('Готово', 'Матч добавлен');
    }
  }

  Future<bool> _addMatch({
    required String eventType,
    required String opponent,
    required String ourScore,
    required String opponentScore,
    required String matchDate,
    required String competitionName,
    required String tourLabel,
    required String stadium,
    required String referees,
    required String notes,
  }) async {
    if (!canEdit) return false;
    if (opponent.trim().isEmpty || matchDate.trim().isEmpty) {
      Get.snackbar('Ошибка', 'Укажите соперника и дату матча');
      return false;
    }

    try {
      final res = await http.post(
        Uri.parse(addUrl),
        headers: const {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'team_id': widget.teamId,
          'team_name': widget.teamName.trim().isEmpty ? 'Команда #${widget.teamId}' : widget.teamName,
          'event_type': eventType,
          'opponent': opponent.trim(),
          'our_score': int.tryParse(ourScore.trim()) ?? 0,
          'opponent_score': int.tryParse(opponentScore.trim()) ?? 0,
          'match_date': matchDate,
          'competition_name': competitionName.trim(),
          'tour_label': tourLabel.trim(),
          'stadium': stadium.trim(),
          'referees': referees.trim(),
          'notes': notes.trim(),
        }),
      ).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final ok = data['status'] == 'success' || data['success'] == true;
      if (!ok) {
        Get.snackbar('Ошибка', data['message']?.toString() ?? 'Не удалось добавить матч');
        return false;
      }
      return true;
    } catch (e) {
      Get.snackbar('Ошибка', 'Проверь API add_team_match.php');
      return false;
    }
  }

  Future<void> _deleteMatch(Map<String, dynamic> match) async {
    if (!canEdit) return;
    final id = _i(match['id']);
    if (id <= 0) return;

    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Удалить матч?'),
        content: Text('Матч с ${_s(match['opponent']).isEmpty ? 'соперником' : _s(match['opponent'])} будет удалён.'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('Отмена')),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(foregroundColor: _C.red),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      final res = await http.post(Uri.parse(deleteUrl), body: {
        'id': id.toString(),
        'team_id': widget.teamId.toString(),
      }).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final success = data['status'] == 'success' || data['success'] == true;
      if (!success) throw Exception(data['message']?.toString() ?? 'Не удалось удалить матч');
      await _fetch();
      Get.snackbar('Готово', 'Матч удалён');
    } catch (e) {
      Get.snackbar('Ошибка', e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _openDetails(Map<String, dynamic> match) async {
    final id = _i(match['id'] ?? match['match_id']);
    if (id <= 0 || openingMatchId != 0) return;

    if (mounted) setState(() => openingMatchId = id);

    try {
      final changed = await Get.to<bool>(
        () => const TeamMatchDetailScreen(),
        arguments: {
          'match': Map<String, dynamic>.from(match),
          'match_id': id,
          'team_id': widget.teamId,
          'team_name': widget.teamName,
          'club_id': widget.clubId,
          'club_name': widget.clubName,
        },
      );

      if (!mounted) return;
      setState(() => openingMatchId = 0);

      if (changed == true || changed == null) {
        await _fetch();
      }
    } catch (_) {
      if (!mounted) return;
      setState(() => openingMatchId = 0);
    }
  }

  Future<void> _handleMatchTap(Map<String, dynamic> match) async {
    final width = MediaQuery.maybeOf(context)?.size.width ?? 1000;
    if (width < 600) {
      await _showMatchPreviewSheet(match);
      return;
    }
    await _openDetails(match);
  }

  void _onSearchChanged() {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 220), () {
      if (mounted) setState(() {});
    });
  }

  String _s(dynamic v) => (v ?? '').toString().trim();
  int _i(dynamic v) => int.tryParse((v ?? '').toString()) ?? 0;

  DateTime _parseDate(String s) {
    try {
      final t = s.trim();
      if (t.contains('.')) {
        final p = t.split('.');
        if (p.length == 3) return DateTime(int.tryParse(p[2]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[0]) ?? 1);
      }
      final d = DateTime.tryParse(t);
      if (d != null) return DateTime(d.year, d.month, d.day);
    } catch (_) {}
    return DateTime(2000, 1, 1);
  }

  String _dateRu(DateTime d) => '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  bool _isUpcoming(DateTime d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return !d.isBefore(today);
  }

  String _eventTypeLabel(String raw) {
    switch (raw.toLowerCase()) {
      case 'championship':
        return 'Чемпионат';
      case 'friendly':
        return 'Товарищеский';
      case 'tournament':
        return 'Турнир';
      default:
        return raw.isEmpty ? 'Матч' : raw;
    }
  }

  List<Map<String, dynamic>> _visibleMatches() {
    final q = _searchCtrl.text.trim().toLowerCase();
    final first = DateTime(selectedMonth.year, selectedMonth.month, 1);
    final next = DateTime(selectedMonth.year, selectedMonth.month + 1, 1);
    Iterable<Map<String, dynamic>> list = matches.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(first) && d.isBefore(next);
    });

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    if (filter == CmrMatchesFilter.upcoming) {
      list = list.where((m) => !_parseDate(_s(m['match_date'])).isBefore(today));
    } else if (filter == CmrMatchesFilter.past) {
      list = list.where((m) => _parseDate(_s(m['match_date'])).isBefore(today));
    }

    if (q.isNotEmpty) {
      list = list.where((m) {
        final text = '${_s(m['opponent'])} ${_s(m['match_date'])} ${_s(m['event_type'])} ${_s(m['competition_name'])} ${_s(m['stadium'])}'.toLowerCase();
        return text.contains(q);
      });
    }

    final out = list.toList();
    out.sort((a, b) => _parseDate(_s(a['match_date'])).compareTo(_parseDate(_s(b['match_date']))));
    return out;
  }

  List<Map<String, dynamic>> _monthMatches() {
    final first = DateTime(selectedMonth.year, selectedMonth.month, 1);
    final next = DateTime(selectedMonth.year, selectedMonth.month + 1, 1);
    return matches.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(first) && d.isBefore(next);
    }).toList();
  }

  Map<DateTime, List<Map<String, dynamic>>> _monthMap() {
    final map = <DateTime, List<Map<String, dynamic>>>{};
    for (final m in _monthMatches()) {
      final d = _parseDate(_s(m['match_date']));
      final key = DateTime(d.year, d.month, d.day);
      (map[key] ??= []).add(m);
    }
    return map;
  }

  int _wins(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) > _i(m['opponent_score'])).length;
  int _draws(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) == _i(m['opponent_score'])).length;
  int _losses(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) < _i(m['opponent_score'])).length;

  void _prevMonth() {
    setState(() {
      selectedMonth = DateTime(selectedMonth.year, selectedMonth.month - 1, 1);
      selectedDay = null;
      filter = CmrMatchesFilter.all;
      calendarRevision++;
    });
  }

  void _nextMonth() {
    setState(() {
      selectedMonth = DateTime(selectedMonth.year, selectedMonth.month + 1, 1);
      selectedDay = null;
      filter = CmrMatchesFilter.all;
      calendarRevision++;
    });
  }

  void _thisMonth() {
    final now = DateTime.now();
    setState(() {
      selectedMonth = DateTime(now.year, now.month, 1);
      selectedDay = null;
      filter = CmrMatchesFilter.all;
      calendarRevision++;
    });
  }

  bool _hasMatchesInMonth(
    List<Map<String, dynamic>> source,
    DateTime month,
  ) {
    final first = DateTime(month.year, month.month, 1);
    final next = DateTime(month.year, month.month + 1, 1);

    return source.any((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(first) && d.isBefore(next);
    });
  }

  DateTime _bestMonthForMatches(List<Map<String, dynamic>> source) {
    final now = DateTime.now();
    final currentMonth = DateTime(now.year, now.month, 1);

    if (source.isEmpty) return currentMonth;
    if (_hasMatchesInMonth(source, selectedMonth)) {
      return DateTime(selectedMonth.year, selectedMonth.month, 1);
    }
    if (_hasMatchesInMonth(source, currentMonth)) return currentMonth;

    final today = DateTime(now.year, now.month, now.day);
    final upcoming = source.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(today);
    }).toList();

    upcoming.sort((a, b) => _parseDate(_s(a['match_date'])).compareTo(_parseDate(_s(b['match_date']))));
    if (upcoming.isNotEmpty) {
      final d = _parseDate(_s(upcoming.first['match_date']));
      return DateTime(d.year, d.month, 1);
    }

    final archive = [...source];
    archive.sort((a, b) => _parseDate(_s(b['match_date'])).compareTo(_parseDate(_s(a['match_date']))));
    final d = _parseDate(_s(archive.first['match_date']));
    return DateTime(d.year, d.month, 1);
  }


  List<Map<String, dynamic>> _pastMatchesAll() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    final list = matches.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return d.isBefore(today);
    }).toList();

    list.sort((a, b) => _parseDate(_s(b['match_date'])).compareTo(_parseDate(_s(a['match_date']))));
    return list;
  }

  List<DateTime> _archiveMonths(List<Map<String, dynamic>> archive) {
    final seen = <String>{};
    final out = <DateTime>[];

    for (final m in archive) {
      final d = _parseDate(_s(m['match_date']));
      final key = '${d.year}-${d.month.toString().padLeft(2, '0')}';
      if (seen.add(key)) {
        out.add(DateTime(d.year, d.month, 1));
      }
    }

    out.sort((a, b) => b.compareTo(a));
    return out;
  }

  void _openArchiveSheet() {
    final archive = _pastMatchesAll();

    setState(() {
      filter = CmrMatchesFilter.past;
    });

    if (archive.isEmpty) {
      Get.snackbar('Архив матчей', 'Прошедших матчей пока нет');
      return;
    }

    final months = _archiveMonths(archive);
    DateTime activeMonth = months.firstWhere(
      (m) => m.year == selectedMonth.year && m.month == selectedMonth.month,
      orElse: () => months.first,
    );

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            final activeList = archive.where((m) {
              final d = _parseDate(_s(m['match_date']));
              return d.year == activeMonth.year && d.month == activeMonth.month;
            }).toList();

            return DraggableScrollableSheet(
              initialChildSize: 0.88,
              minChildSize: 0.55,
              maxChildSize: 0.96,
              expand: false,
              builder: (context, scrollController) {
                return Container(
                  margin: const EdgeInsets.fromLTRB(10, 10, 10, 0),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x22000000),
                        blurRadius: 28,
                        offset: Offset(0, -8),
                      ),
                    ],
                  ),
                  child: SafeArea(
                    top: false,
                    child: Column(
                      children: [
                        const SizedBox(height: 10),
                        Container(
                          width: 44,
                          height: 5,
                          decoration: BoxDecoration(
                            color: const Color(0xFFE2E8F0),
                            borderRadius: BorderRadius.circular(99),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 14, 10, 10),
                          child: Row(
                            children: [
                              Container(
                                width: 42,
                                height: 42,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF8FAFC),
                                  borderRadius: BorderRadius.circular(15),
                                  border: Border.all(color: _C.border),
                                ),
                                child: const Icon(Icons.history_rounded, color: _C.text, size: 22),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Архив матчей',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: _C.title.copyWith(fontSize: 20),
                                    ),
                                    const SizedBox(height: 3),
                                    Text(
                                      '${archive.length} прошедших • ${_monthTitle(activeMonth)}',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: _C.muted,
                                        fontWeight: FontWeight.w700,
                                        fontSize: 12,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              IconButton(
                                onPressed: () => Navigator.pop(context),
                                icon: const Icon(Icons.close_rounded),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 46,
                          child: ListView.separated(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            scrollDirection: Axis.horizontal,
                            itemCount: months.length,
                            separatorBuilder: (_, __) => const SizedBox(width: 8),
                            itemBuilder: (_, index) {
                              final m = months[index];
                              final active = m.year == activeMonth.year && m.month == activeMonth.month;
                              final count = archive.where((x) {
                                final d = _parseDate(_s(x['match_date']));
                                return d.year == m.year && d.month == m.month;
                              }).length;

                              return _ArchiveMonthChip(
                                title: _monthTitle(m),
                                count: count,
                                active: active,
                                onTap: () {
                                  setSheetState(() => activeMonth = m);
                                  setState(() => selectedMonth = m);
                                },
                              );
                            },
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.fromLTRB(16, 12, 16, 10),
                          child: Row(
                            children: [
                              Expanded(
                                child: _ArchiveMiniStat(
                                  title: 'Матчи',
                                  value: '${activeList.length}',
                                  icon: Icons.sports_soccer_rounded,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _ArchiveMiniStat(
                                  title: 'Победы',
                                  value: '${_wins(activeList)}',
                                  icon: Icons.emoji_events_outlined,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: _ArchiveMiniStat(
                                  title: 'Баланс',
                                  value: '${_wins(activeList)}-${_draws(activeList)}-${_losses(activeList)}',
                                  icon: Icons.timeline_rounded,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Expanded(
                          child: activeList.isEmpty
                              ? const _MiniEmpty(text: 'В этом месяце архивных матчей нет')
                              : ListView.separated(
                                  controller: scrollController,
                                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
                                  itemCount: activeList.length,
                                  separatorBuilder: (_, __) => const SizedBox(height: 9),
                                  itemBuilder: (_, index) {
                                    final m = activeList[index];
                                    return _CmrMatchTile(
                                      eventType: _eventTypeLabel(_s(m['event_type'])),
                                      opponent: _s(m['opponent']),
                                      date: _dateRu(_parseDate(_s(m['match_date']))),
                                      competition: _s(m['competition_name']),
                                      stadium: _s(m['stadium']),
                                      score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                                      upcoming: false,
                                      canEdit: canEdit,
                                      compact: true,
                                      onTap: () {
                                        Navigator.pop(context);
                                        setState(() {
                                          selectedMonth = activeMonth;
                                          filter = CmrMatchesFilter.past;
                                        });
                                        _openDetails(m);
                                      },
                                      onDelete: () => _deleteMatch(m),
                                    );
                                  },
                                ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }

  String _monthTitle(DateTime d) {
    const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    return '${months[d.month - 1]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator(color: _C.green));
    if (error != null) {
      return _CmrEmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить матчи',
        text: error!,
        actionText: 'Повторить',
        onAction: () => _fetch(initial: true),
      );
    }

    final visible = _visibleMatches();
    final monthList = _monthMatches();
    final map = _monthMap();

    return LayoutBuilder(
      builder: (context, c) {
        final isPhone = c.maxWidth < 600;
        final compact = c.maxWidth < 860;
        final left = _buildLeftColumn(visible, monthList, isPhone: isPhone);
        final right = _buildCalendarArea(map, monthList, isPhone: isPhone);

        if (isPhone) {
          return _buildPhoneLayout(
            visible: visible,
            monthList: monthList,
            monthMap: map,
          );
        }

        if (compact) {
          final rowsForHeight = visible.isEmpty ? 1 : (visible.length > 4 ? 4 : visible.length);
          final leftHeight = visible.isEmpty ? 390.0 : 276.0 + rowsForHeight * 116.0;

          return RefreshIndicator(
            color: _C.green,
            onRefresh: () => _fetch(),
            child: ListView(
              padding: EdgeInsets.zero,
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                SizedBox(height: leftHeight, child: left),
                const SizedBox(height: 14),
                SizedBox(height: 660, child: right),
                const SizedBox(height: 16),
              ],
            ),
          );
        }

        return Row(
          children: [
            SizedBox(width: 390, child: left),
            const SizedBox(width: 12),
            Expanded(child: right),
          ],
        );
      },
    );
  }


  Widget _buildPhoneLayout({
    required List<Map<String, dynamic>> visible,
    required List<Map<String, dynamic>> monthList,
    required Map<DateTime, List<Map<String, dynamic>>> monthMap,
  }) {
    final upcomingCount = matches.where((m) => _isUpcoming(_parseDate(_s(m['match_date'])))).length;
    final listTitle = filter == CmrMatchesFilter.upcoming
        ? 'Будущие матчи за ${_monthTitle(selectedMonth)}'
        : filter == CmrMatchesFilter.past
            ? 'Архив за ${_monthTitle(selectedMonth)}'
            : 'Матчи за ${_monthTitle(selectedMonth)}';

    return RefreshIndicator(
      color: _C.green,
      onRefresh: () => _fetch(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(0, 0, 0, 18),
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          Container(
            decoration: _C.cardDecoration,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
                    border: Border(bottom: BorderSide(color: _C.border)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const _CmrIconBox(icon: Icons.sports_soccer_rounded, size: 40),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  widget.teamName.trim().isEmpty ? 'Команда' : widget.teamName,
                                  maxLines: 2,
                                  overflow: TextOverflow.ellipsis,
                                  style: _C.title.copyWith(fontSize: 16.5, height: 1.12),
                                ),
                                const SizedBox(height: 4),
                                const Text(
                                  'Матчи и календарь команды',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 11.5),
                                ),
                              ],
                            ),
                          ),
                          _HeaderIconButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: _HeroStat(value: '${matches.length}', title: 'всего', compact: true)),
                          const SizedBox(width: 8),
                          Expanded(child: _HeroStat(value: '$upcomingCount', title: 'впереди', compact: true)),
                          const SizedBox(width: 8),
                          Expanded(child: _HeroStat(value: canEdit ? 'Да' : 'Нет', title: 'редакт.', compact: true)),
                        ],
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
                  child: _CmrSearch(
                    controller: _searchCtrl,
                    hint: 'Поиск матча',
                    compact: true,
                    onClear: () {
                      _searchCtrl.clear();
                      setState(() {});
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                  child: Row(
                    children: [
                      Expanded(child: _FilterButton(text: 'Все', active: filter == CmrMatchesFilter.all, compact: true, onTap: () => setState(() => filter = CmrMatchesFilter.all))),
                      const SizedBox(width: 8),
                      Expanded(child: _FilterButton(text: 'Впереди', active: filter == CmrMatchesFilter.upcoming, compact: true, onTap: () => setState(() => filter = CmrMatchesFilter.upcoming))),
                      const SizedBox(width: 8),
                      Expanded(child: _FilterButton(text: 'Архив', active: filter == CmrMatchesFilter.past, compact: true, onTap: () => setState(() => filter = CmrMatchesFilter.past))),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: _C.cardDecoration,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const _CmrIconBox(icon: Icons.event_available_rounded, size: 40),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(_monthTitle(selectedMonth), maxLines: 2, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 18, height: 1.12)),
                                const SizedBox(height: 4),
                                Text('П ${_wins(monthList)} • Н ${_draws(monthList)} • Пор ${_losses(monthList)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 11.5)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: _TopActionButton(icon: Icons.today_rounded, text: 'Текущий месяц', compact: true, onTap: _thisMonth)),
                          const SizedBox(width: 8),
                          _SquareButton(icon: Icons.chevron_left_rounded, compact: true, onTap: _prevMonth),
                          const SizedBox(width: 8),
                          _SquareButton(icon: Icons.chevron_right_rounded, compact: true, onTap: _nextMonth),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(height: 1, color: _C.border),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: _buildStatsRow(monthList, isPhone: true),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(10, 0, 10, 12),
                  child: SizedBox(
                    height: 330,
                    child: _MonthMatchesGrid(
                      key: ValueKey('phone-matches-calendar-${selectedMonth.year}-${selectedMonth.month}-$calendarRevision'),
                      month: selectedMonth,
                      selectedDay: selectedDay,
                      matchesByDay: monthMap,
                      dateText: _dateRu,
                      compact: true,
                      onDayTap: (day, list) {
                        setState(() {
                          selectedDay = day;
                          calendarRevision++;
                        });

                        if (list.isEmpty) return;
                        if (list.length == 1) {
                          _showMatchPreviewSheet(list.first);
                          return;
                        }
                        _showDayMatches(day, list);
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            decoration: _C.cardDecoration,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 14, 12, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SelectedMatchesHeader(
                    title: listTitle,
                    canEdit: canEdit,
                    compact: true,
                    onAdd: _openCreate,
                  ),
                  const SizedBox(height: 10),
                  if (visible.isEmpty)
                    _MiniEmpty(text: monthList.isEmpty ? 'В этом месяце матчей нет' : 'Матчи есть в календаре, но скрыты фильтром или поиском')
                  else
                    ...List.generate(visible.length, (i) {
                      final m = visible[i];
                      return Padding(
                        padding: EdgeInsets.only(bottom: i == visible.length - 1 ? 0 : 8),
                        child: _CmrMatchTile(
                          eventType: _eventTypeLabel(_s(m['event_type'])),
                          opponent: _s(m['opponent']),
                          date: _dateRu(_parseDate(_s(m['match_date']))),
                          competition: _s(m['competition_name']),
                          stadium: _s(m['stadium']),
                          score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                          upcoming: _isUpcoming(_parseDate(_s(m['match_date']))),
                          canEdit: canEdit,
                          compact: true,
                          onTap: () => _handleMatchTap(m),
                          onDelete: () => _deleteMatch(m),
                        ),
                      );
                    }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftColumn(
    List<Map<String, dynamic>> visible,
    List<Map<String, dynamic>> monthList, {
    bool isPhone = false,
  }) {
    final upcomingCount = matches.where((m) => _isUpcoming(_parseDate(_s(m['match_date'])))).length;

    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.fromLTRB(isPhone ? 14 : 18, isPhone ? 14 : 18, isPhone ? 14 : 18, isPhone ? 12 : 18),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: const BorderRadius.vertical(top: Radius.circular(28)),
              border: Border(bottom: BorderSide(color: _C.border)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _CmrIconBox(icon: Icons.sports_soccer_rounded, size: isPhone ? 40 : 46),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.teamName.trim().isEmpty ? 'Команда' : widget.teamName,
                            maxLines: isPhone ? 2 : 1,
                            overflow: TextOverflow.ellipsis,
                            style: _C.title.copyWith(fontSize: isPhone ? 16.5 : 19, height: 1.12),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Матчи и календарь команды',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: isPhone ? 11.5 : 12),
                          ),
                        ],
                      ),
                    ),
                    if (!isPhone) _HeaderIconButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
                  ],
                ),
                SizedBox(height: isPhone ? 12 : 16),
                Row(
                  children: [
                    Expanded(child: _HeroStat(value: '${matches.length}', title: 'всего', compact: isPhone)),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: '$upcomingCount', title: 'впереди', compact: isPhone)),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: canEdit ? 'Да' : 'Нет', title: 'редакт.', compact: isPhone)),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(isPhone ? 12 : 14, isPhone ? 12 : 14, isPhone ? 12 : 14, 10),
            child: _CmrSearch(
              controller: _searchCtrl,
              hint: isPhone ? 'Поиск матча' : 'Поиск по сопернику, турниру, стадиону',
              compact: isPhone,
              onClear: () {
                _searchCtrl.clear();
                setState(() {});
              },
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(isPhone ? 12 : 14, 0, isPhone ? 12 : 14, 10),
            child: Row(
              children: [
                Expanded(child: _FilterButton(text: 'Все', active: filter == CmrMatchesFilter.all, compact: isPhone, onTap: () => setState(() => filter = CmrMatchesFilter.all))),
                const SizedBox(width: 8),
                Expanded(child: _FilterButton(text: 'Впереди', active: filter == CmrMatchesFilter.upcoming, compact: isPhone, onTap: () => setState(() => filter = CmrMatchesFilter.upcoming))),
                const SizedBox(width: 8),
                Expanded(child: _FilterButton(text: 'Архив', active: filter == CmrMatchesFilter.past, compact: isPhone, onTap: _openArchiveSheet)),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(isPhone ? 12 : 14, 0, isPhone ? 12 : 14, 10),
            child: _SelectedMatchesHeader(
              title: _monthTitle(selectedMonth),
              canEdit: canEdit,
              compact: isPhone,
              onAdd: _openCreate,
            ),
          ),
          Expanded(
            child: visible.isEmpty
                ? _MiniEmpty(text: monthList.isEmpty ? 'В этом месяце матчей нет' : 'Матчи есть в календаре, но скрыты фильтром или поиском')
                : ListView.separated(
                    padding: EdgeInsets.fromLTRB(isPhone ? 12 : 14, 0, isPhone ? 12 : 14, 14),
                    itemCount: visible.length,
                    separatorBuilder: (_, __) => SizedBox(height: isPhone ? 8 : 10),
                    itemBuilder: (_, i) {
                      final m = visible[i];
                      return _CmrMatchTile(
                        eventType: _eventTypeLabel(_s(m['event_type'])),
                        opponent: _s(m['opponent']),
                        date: _dateRu(_parseDate(_s(m['match_date']))),
                        competition: _s(m['competition_name']),
                        stadium: _s(m['stadium']),
                        score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                        upcoming: _isUpcoming(_parseDate(_s(m['match_date']))),
                        canEdit: canEdit,
                        compact: isPhone,
                        onTap: () => _handleMatchTap(m),
                        onDelete: () => _deleteMatch(m),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendarArea(
    Map<DateTime, List<Map<String, dynamic>>> monthMap,
    List<Map<String, dynamic>> monthList, {
    bool isPhone = false,
  }) {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(isPhone ? 14 : 18),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: isPhone
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const _CmrIconBox(icon: Icons.event_available_rounded, size: 40),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(_monthTitle(selectedMonth), maxLines: 2, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 18, height: 1.12)),
                                const SizedBox(height: 4),
                                Text('П ${_wins(monthList)} • Н ${_draws(monthList)} • Пор ${_losses(monthList)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 11.5)),
                              ],
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Expanded(child: _TopActionButton(icon: Icons.today_rounded, text: 'Текущий месяц', compact: true, onTap: _thisMonth)),
                          const SizedBox(width: 8),
                          _SquareButton(icon: Icons.chevron_left_rounded, compact: true, onTap: _prevMonth),
                          const SizedBox(width: 8),
                          _SquareButton(icon: Icons.chevron_right_rounded, compact: true, onTap: _nextMonth),
                        ],
                      ),
                    ],
                  )
                : Row(
                    children: [
                      const _CmrIconBox(icon: Icons.event_available_rounded),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_monthTitle(selectedMonth), maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 22)),
                            const SizedBox(height: 4),
                            Text('Победы ${_wins(monthList)} • Ничьи ${_draws(monthList)} • Поражения ${_losses(monthList)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 12.5)),
                          ],
                        ),
                      ),
                      _TopActionButton(icon: Icons.today_rounded, text: 'Этот месяц', onTap: _thisMonth),
                      const SizedBox(width: 8),
                      _SquareButton(icon: Icons.chevron_left_rounded, onTap: _prevMonth),
                      const SizedBox(width: 8),
                      _SquareButton(icon: Icons.chevron_right_rounded, onTap: _nextMonth),
                    ],
                  ),
          ),
          const Divider(height: 1, color: _C.border),
          Padding(
            padding: EdgeInsets.all(isPhone ? 12 : 14),
            child: _buildStatsRow(monthList, isPhone: isPhone),
          ),
          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(isPhone ? 10 : 14, 0, isPhone ? 10 : 14, isPhone ? 10 : 14),
              child: _MonthMatchesGrid(
                key: ValueKey('matches-calendar-${selectedMonth.year}-${selectedMonth.month}-$calendarRevision'),
                month: selectedMonth,
                selectedDay: selectedDay,
                matchesByDay: monthMap,
                dateText: _dateRu,
                compact: isPhone,
                onDayTap: (day, list) {
                  setState(() {
                    selectedDay = day;
                    calendarRevision++;
                  });

                  if (list.isEmpty) return;

                  if (isPhone && list.length == 1) {
                    _showMatchPreviewSheet(list.first);
                    return;
                  }

                  _showDayMatches(day, list);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(List<Map<String, dynamic>> monthList, {bool isPhone = false}) {
    final goalsFor = monthList.fold<int>(0, (v, m) => v + _i(m['our_score']));
    final goalsAgainst = monthList.fold<int>(0, (v, m) => v + _i(m['opponent_score']));
    final cards = [
      _MetricCard(icon: Icons.sports_soccer_rounded, title: 'Матчи', value: '${monthList.length}', compact: isPhone),
      _MetricCard(icon: Icons.trending_up_rounded, title: 'Голы', value: '$goalsFor:$goalsAgainst', compact: isPhone),
      _MetricCard(icon: Icons.emoji_events_outlined, title: 'Победы', value: '${_wins(monthList)}', compact: isPhone),
      _MetricCard(icon: Icons.timeline_rounded, title: 'Баланс', value: '${_wins(monthList)}-${_draws(monthList)}-${_losses(monthList)}', compact: isPhone),
    ];

    if (isPhone) {
      return GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        childAspectRatio: 2.65,
        children: cards,
      );
    }

    return Row(
      children: [
        Expanded(child: cards[0]),
        const SizedBox(width: 10),
        Expanded(child: cards[1]),
        const SizedBox(width: 10),
        Expanded(child: cards[2]),
        const SizedBox(width: 10),
        Expanded(child: cards[3]),
      ],
    );
  }

  Future<void> _showDayMatches(DateTime day, List<Map<String, dynamic>> list) async {
    if (!mounted) return;

    final isPhone = (MediaQuery.maybeOf(context)?.size.width ?? 1000) < 600;

    await showModalBottomSheet(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) => DraggableScrollableSheet(
        initialChildSize: isPhone ? .62 : .46,
        minChildSize: isPhone ? .42 : .28,
        maxChildSize: .90,
        expand: false,
        builder: (_, scrollController) => Container(
          margin: EdgeInsets.fromLTRB(isPhone ? 8 : 12, 0, isPhone ? 8 : 12, isPhone ? 8 : 12),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(isPhone ? 24 : 28),
            boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 30, offset: Offset(0, 12))],
          ),
          child: SafeArea(
            top: false,
            child: ListView(
              controller: scrollController,
              padding: EdgeInsets.all(isPhone ? 12 : 14),
              children: [
                Center(
                  child: Container(
                    width: 44,
                    height: 5,
                    margin: const EdgeInsets.only(bottom: 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFE2E8F0),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                Row(
                  children: [
                    _CmrIconBox(icon: Icons.sports_soccer_rounded, size: isPhone ? 40 : 46),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Text(
                        'Матчи • ${_dateRu(day)}',
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: _C.title.copyWith(fontSize: isPhone ? 17 : 18, height: 1.12),
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.pop(sheetContext),
                      icon: const Icon(Icons.close_rounded),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                ...list.map(
                  (m) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _CmrMatchTile(
                      eventType: _eventTypeLabel(_s(m['event_type'])),
                      opponent: _s(m['opponent']),
                      date: _dateRu(_parseDate(_s(m['match_date']))),
                      competition: _s(m['competition_name']),
                      stadium: _s(m['stadium']),
                      score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                      upcoming: _isUpcoming(_parseDate(_s(m['match_date']))),
                      canEdit: canEdit,
                      compact: isPhone,
                      onTap: () async {
                        Navigator.pop(sheetContext);
                        await Future.delayed(const Duration(milliseconds: 80));
                        await _handleMatchTap(m);
                      },
                      onDelete: () => _deleteMatch(m),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _showMatchPreviewSheet(Map<String, dynamic> match) async {
    if (!mounted) return;

    final opponent = _s(match['opponent']).isEmpty ? 'Соперник' : _s(match['opponent']);
    final eventType = _eventTypeLabel(_s(match['event_type']));
    final date = _dateRu(_parseDate(_s(match['match_date'])));
    final score = '${_i(match['our_score'])}:${_i(match['opponent_score'])}';
    final competition = _s(match['competition_name']);
    final tour = _s(match['tour_label']);
    final stadium = _s(match['stadium']);
    final referees = _s(match['referees']);
    final notes = _s(match['notes']);
    final upcoming = _isUpcoming(_parseDate(_s(match['match_date'])));

    await showModalBottomSheet(
      context: context,
      useRootNavigator: true,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (sheetContext) {
        return DraggableScrollableSheet(
          initialChildSize: .68,
          minChildSize: .42,
          maxChildSize: .92,
          expand: false,
          builder: (_, scrollController) {
            return Container(
              margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(26),
                boxShadow: const [BoxShadow(color: Color(0x26000000), blurRadius: 34, offset: Offset(0, 14))],
              ),
              child: SafeArea(
                top: false,
                child: ListView(
                  controller: scrollController,
                  padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
                  children: [
                    Center(
                      child: Container(
                        width: 44,
                        height: 5,
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: const Color(0xFFE2E8F0),
                          borderRadius: BorderRadius.circular(99),
                        ),
                      ),
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const _CmrIconBox(icon: Icons.sports_soccer_rounded, size: 42),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                opponent,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: _C.title.copyWith(fontSize: 20, height: 1.08),
                              ),
                              const SizedBox(height: 5),
                              Text(
                                '$eventType • $date',
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                  color: _C.muted,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 12.5,
                                  height: 1.2,
                                ),
                              ),
                            ],
                          ),
                        ),
                        IconButton(
                          onPressed: () => Navigator.pop(sheetContext),
                          icon: const Icon(Icons.close_rounded),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        color: upcoming ? _C.accentSoft : const Color(0xFFF8FAFC),
                        borderRadius: BorderRadius.circular(22),
                        border: Border.all(color: upcoming ? _C.accentBorder : _C.border),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: _MatchPreviewStat(
                              title: 'Счёт',
                              value: score,
                              icon: Icons.scoreboard_rounded,
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: _MatchPreviewStat(
                              title: upcoming ? 'Статус' : 'Итог',
                              value: upcoming ? 'Скоро' : 'Архив',
                              icon: upcoming ? Icons.event_available_rounded : Icons.history_rounded,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    _MatchInfoRow(icon: Icons.emoji_events_outlined, title: 'Турнир', value: competition.isEmpty ? 'Не указан' : competition),
                    _MatchInfoRow(icon: Icons.flag_rounded, title: 'Тур', value: tour.isEmpty ? 'Не указан' : tour),
                    _MatchInfoRow(icon: Icons.stadium_rounded, title: 'Стадион', value: stadium.isEmpty ? 'Не указан' : stadium),
                    _MatchInfoRow(icon: Icons.sports_rounded, title: 'Судьи', value: referees.isEmpty ? 'Не указаны' : referees),
                    if (notes.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(13),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF8FAFC),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _C.border),
                        ),
                        child: Text(
                          notes,
                          style: const TextStyle(
                            color: _C.text,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.5,
                            height: 1.35,
                          ),
                        ),
                      ),
                    ],
                    const SizedBox(height: 14),
                    Row(
                      children: [
                        Expanded(
                          child: _SheetPrimaryButton(
                            icon: Icons.open_in_new_rounded,
                            text: 'Открыть матч',
                            onTap: () async {
                              Navigator.pop(sheetContext);
                              await Future.delayed(const Duration(milliseconds: 80));
                              await _openDetails(match);
                            },
                          ),
                        ),
                        if (canEdit) ...[
                          const SizedBox(width: 10),
                          _SheetIconButton(
                            icon: Icons.delete_outline_rounded,
                            onTap: () async {
                              Navigator.pop(sheetContext);
                              await Future.delayed(const Duration(milliseconds: 80));
                              await _deleteMatch(match);
                            },
                          ),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

}

class _MonthMatchesGrid extends StatelessWidget {
  final DateTime month;
  final DateTime? selectedDay;
  final Map<DateTime, List<Map<String, dynamic>>> matchesByDay;
  final String Function(DateTime) dateText;
  final void Function(DateTime day, List<Map<String, dynamic>> matches) onDayTap;
  final bool compact;

  const _MonthMatchesGrid({
    super.key,
    required this.month,
    required this.selectedDay,
    required this.matchesByDay,
    required this.dateText,
    required this.onDayTap,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    final first = DateTime(month.year, month.month, 1);
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final offset = first.weekday - 1;
    final total = offset + daysInMonth;
    final cells = ((total / 7).ceil()) * 7;

    return Column(
      children: [
        Row(
          children: weekdays
              .map(
                (d) => Expanded(
                  child: Center(
                    child: Text(
                      d,
                      style: TextStyle(
                        color: _C.muted,
                        fontWeight: FontWeight.w900,
                        fontSize: compact ? 10.5 : 12,
                      ),
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        SizedBox(height: compact ? 6 : 8),
        Expanded(
          child: GridView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: compact ? 5 : 8,
              crossAxisSpacing: compact ? 5 : 8,
              childAspectRatio: compact ? 1.0 : 1.05,
            ),
            itemCount: cells,
            itemBuilder: (_, index) {
              final dayNumber = index - offset + 1;
              final inMonth = dayNumber >= 1 && dayNumber <= daysInMonth;
              if (!inMonth) return const SizedBox.shrink();

              final day = DateTime(month.year, month.month, dayNumber);
              final list = matchesByDay[day] ?? const <Map<String, dynamic>>[];
              final today = DateTime.now();
              final isToday = day.year == today.year && day.month == today.month && day.day == today.day;
              final isSelected = selectedDay != null &&
                  selectedDay!.year == day.year &&
                  selectedDay!.month == day.month &&
                  selectedDay!.day == day.day;
              final hasMatches = list.isNotEmpty;

              return InkWell(
                borderRadius: BorderRadius.circular(compact ? 13 : 18),
                onTap: () => onDayTap(day, list),
                child: Container(
                  padding: EdgeInsets.all(compact ? 6 : 9),
                  decoration: BoxDecoration(
                    color: isSelected ? _C.green.withOpacity(.13) : (hasMatches ? _C.accentSoft : Colors.white),
                    borderRadius: BorderRadius.circular(compact ? 13 : 18),
                    border: Border.all(
                      color: isSelected ? _C.green : (isToday ? _C.green : (hasMatches ? _C.accentBorder : _C.border)),
                      width: isSelected ? 1.8 : (isToday ? 1.4 : 1),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            '$dayNumber',
                            style: TextStyle(
                              fontWeight: FontWeight.w900,
                              color: isToday ? _C.green : _C.text,
                              fontSize: compact ? 11.5 : 13,
                            ),
                          ),
                          const Spacer(),
                          if (hasMatches)
                            Container(
                              width: compact ? 18 : null,
                              height: compact ? 18 : null,
                              alignment: Alignment.center,
                              padding: compact ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(
                                color: _C.green,
                                borderRadius: BorderRadius.circular(99),
                              ),
                              child: Text(
                                '${list.length}',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: compact ? 9 : 10,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const Spacer(),
                      if (hasMatches && compact)
                        Wrap(
                          spacing: 3,
                          runSpacing: 3,
                          children: List.generate(
                            list.length.clamp(1, 3).toInt(),
                            (_) => Container(
                              width: 5,
                              height: 5,
                              decoration: const BoxDecoration(
                                color: _C.green,
                                shape: BoxShape.circle,
                              ),
                            ),
                          ),
                        )
                      else if (hasMatches)
                        ...list.take(2).map(
                              (m) => Padding(
                                padding: const EdgeInsets.only(top: 3),
                                child: Row(
                                  children: [
                                    const Icon(Icons.sports_soccer_rounded, size: 11, color: _C.green),
                                    const SizedBox(width: 3),
                                    Expanded(
                                      child: Text(
                                        (m['opponent'] ?? 'Соперник').toString(),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 10.5,
                                          color: _C.text,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}


class _MatchPreviewStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _MatchPreviewStat({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 34,
          height: 34,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: _C.accentBorder),
          ),
          child: Icon(icon, color: _C.green, size: 18),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 16),
              ),
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w700, color: _C.muted, fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _MatchInfoRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;

  const _MatchInfoRow({
    required this.icon,
    required this.title,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 9),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: _C.green, size: 18),
            const SizedBox(width: 10),
            SizedBox(
              width: 76,
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w800, color: _C.muted, fontSize: 11.5),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                value,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 13, height: 1.2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SheetPrimaryButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _SheetPrimaryButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _C.green,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          height: 52,
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: Colors.white, size: 20),
              const SizedBox(width: 8),
              Text(
                text,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SheetIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _SheetIconButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xFFF8FAFC),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          width: 52,
          height: 52,
          alignment: Alignment.center,
          child: Icon(icon, color: _C.muted),
        ),
      ),
    );
  }
}

class _CmrAddMatchSheet extends StatefulWidget {
  final Future<bool> Function({
    required String eventType,
    required String opponent,
    required String ourScore,
    required String opponentScore,
    required String matchDate,
    required String competitionName,
    required String tourLabel,
    required String stadium,
    required String referees,
    required String notes,
  }) onSubmit;

  const _CmrAddMatchSheet({required this.onSubmit});

  @override
  State<_CmrAddMatchSheet> createState() => _CmrAddMatchSheetState();
}

class _CmrAddMatchSheetState extends State<_CmrAddMatchSheet> {
  final opponent = TextEditingController();
  final ourScore = TextEditingController(text: '0');
  final opponentScore = TextEditingController(text: '0');
  final competition = TextEditingController();
  final tour = TextEditingController();
  final stadium = TextEditingController();
  final referees = TextEditingController();
  final notes = TextEditingController();

  DateTime? picked;
  bool saving = false;
  String eventType = 'championship';

  @override
  void dispose() {
    opponent.dispose();
    ourScore.dispose();
    opponentScore.dispose();
    competition.dispose();
    tour.dispose();
    stadium.dispose();
    referees.dispose();
    notes.dispose();
    super.dispose();
  }

  String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  String _ru(DateTime d) => '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final res = await showDatePicker(context: context, initialDate: picked ?? now, firstDate: DateTime(now.year - 2), lastDate: DateTime(now.year + 3, 12, 31), helpText: 'Выберите дату матча');
    if (res != null) setState(() => picked = DateTime(res.year, res.month, res.day));
  }

  Future<void> _submit() async {
    if (opponent.text.trim().isEmpty || picked == null) {
      Get.snackbar('Ошибка', 'Заполните соперника и дату матча');
      return;
    }
    setState(() => saving = true);
    try {
      final ok = await widget.onSubmit(
        eventType: eventType,
        opponent: opponent.text,
        ourScore: ourScore.text,
        opponentScore: opponentScore.text,
        matchDate: _iso(picked!),
        competitionName: competition.text,
        tourLabel: tour.text,
        stadium: stadium.text,
        referees: referees.text,
        notes: notes.text,
      );
      if (ok && mounted) Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: bottom),
        child: Container(
          margin: const EdgeInsets.all(12),
          constraints: const BoxConstraints(maxWidth: 720),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 30, offset: Offset(0, 12))]),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const _CmrIconBox(icon: Icons.add_rounded),
                    const SizedBox(width: 12),
                    Expanded(child: Text('Добавить матч', style: _C.title.copyWith(fontSize: 19))),
                    IconButton(onPressed: saving ? null : () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  ],
                ),
                const SizedBox(height: 12),
                _CmrFieldShell(
                  child: DropdownButtonFormField<String>(
                    value: eventType,
                    decoration: const InputDecoration(border: InputBorder.none, labelText: 'Тип матча'),
                    items: const [
                      DropdownMenuItem(value: 'championship', child: Text('Чемпионат')),
                      DropdownMenuItem(value: 'friendly', child: Text('Товарищеский')),
                      DropdownMenuItem(value: 'tournament', child: Text('Турнир')),
                    ],
                    onChanged: saving ? null : (v) => setState(() => eventType = v ?? 'championship'),
                  ),
                ),
                const SizedBox(height: 10),
                _CmrTextField(controller: opponent, icon: Icons.shield_outlined, hint: 'Соперник', onChanged: (_) => setState(() {})),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _CmrTextField(controller: ourScore, icon: Icons.looks_one_rounded, hint: 'Наш счёт', keyboardType: TextInputType.number)),
                  const SizedBox(width: 10),
                  Expanded(child: _CmrTextField(controller: opponentScore, icon: Icons.looks_two_rounded, hint: 'Счёт соперника', keyboardType: TextInputType.number)),
                ]),
                const SizedBox(height: 10),
                _CmrFieldShell(onTap: saving ? null : _pickDate, child: Row(children: [
                  const Icon(Icons.calendar_month_rounded, size: 20, color: _C.muted),
                  const SizedBox(width: 8),
                  Expanded(child: Text(picked == null ? 'Выбрать дату матча' : _ru(picked!), style: TextStyle(fontWeight: FontWeight.w900, color: picked == null ? _C.muted : _C.text))),
                  const Icon(Icons.chevron_right_rounded, color: _C.muted),
                ])),
                const SizedBox(height: 10),
                _CmrTextField(controller: competition, icon: Icons.emoji_events_outlined, hint: 'Турнир / соревнование'),
                const SizedBox(height: 10),
                _CmrTextField(controller: tour, icon: Icons.format_list_numbered_rounded, hint: 'Тур / этап'),
                const SizedBox(height: 10),
                _CmrTextField(controller: stadium, icon: Icons.location_on_outlined, hint: 'Стадион'),
                const SizedBox(height: 10),
                _CmrTextField(controller: referees, icon: Icons.gavel_rounded, hint: 'Судьи'),
                const SizedBox(height: 10),
                _CmrTextField(controller: notes, icon: Icons.notes_rounded, hint: 'Примечания', maxLines: 3),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: !saving && opponent.text.trim().isNotEmpty && picked != null ? _submit : null,
                    icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.check_rounded),
                    label: Text(saving ? 'Сохранение...' : 'Сохранить матч'),
                    style: ElevatedButton.styleFrom(backgroundColor: _C.green, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CmrMatchTile extends StatelessWidget {
  final String eventType;
  final String opponent;
  final String date;
  final String competition;
  final String stadium;
  final String score;
  final bool upcoming;
  final bool canEdit;
  final bool compact;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _CmrMatchTile({
    required this.eventType,
    required this.opponent,
    required this.date,
    required this.competition,
    required this.stadium,
    required this.score,
    required this.upcoming,
    required this.canEdit,
    required this.onTap,
    required this.onDelete,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    final meta = [competition, stadium].where((e) => e.trim().isNotEmpty).join(' • ');
    final radius = BorderRadius.circular(compact ? 18 : 22);

    if (compact) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: radius,
          onTap: onTap,
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: upcoming ? _C.accentSoft : Colors.white,
              borderRadius: radius,
              border: Border.all(color: upcoming ? _C.green.withOpacity(.30) : _C.border, width: upcoming ? 1.2 : 1),
              boxShadow: upcoming
                  ? const [BoxShadow(color: Color(0x1200A750), blurRadius: 16, offset: Offset(0, 8))]
                  : const [BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 6))],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 38,
                      height: 38,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: upcoming ? _C.accentBorder : _C.border),
                      ),
                      child: Icon(
                        upcoming ? Icons.sports_soccer_rounded : Icons.history_rounded,
                        color: upcoming ? _C.green : _C.muted,
                        size: 19,
                      ),
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        opponent.isEmpty ? 'Соперник' : opponent,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 13.5, height: 1.1),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: upcoming ? _C.accentBorder : _C.border),
                      ),
                      child: Text(score, style: const TextStyle(fontWeight: FontWeight.w900, color: _C.green, fontSize: 13)),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _MiniBadge(text: eventType, icon: Icons.flag_rounded, active: upcoming, compact: true),
                    _MiniBadge(text: date, icon: Icons.calendar_month_rounded, active: upcoming, compact: true),
                  ],
                ),
                if (meta.isNotEmpty) ...[
                  const SizedBox(height: 7),
                  Text(
                    meta,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 11.2, height: 1.15),
                  ),
                ],
                if (canEdit) ...[
                  const SizedBox(height: 8),
                  Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      borderRadius: BorderRadius.circular(999),
                      onTap: onDelete,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(color: _C.border),
                        ),
                        child: const Text(
                          'Удалить',
                          style: TextStyle(color: _C.muted, fontWeight: FontWeight.w800, fontSize: 11),
                        ),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      );
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: radius,
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: upcoming ? _C.accentSoft : Colors.white,
            borderRadius: radius,
            border: Border.all(color: upcoming ? _C.green.withOpacity(.30) : _C.border, width: upcoming ? 1.2 : 1),
            boxShadow: upcoming
                ? const [BoxShadow(color: Color(0x1200A750), blurRadius: 16, offset: Offset(0, 8))]
                : const [BoxShadow(color: Color(0x08000000), blurRadius: 12, offset: Offset(0, 6))],
          ),
          child: Row(
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(17),
                  border: Border.all(color: upcoming ? _C.accentBorder : _C.border),
                ),
                child: Icon(
                  upcoming ? Icons.sports_soccer_rounded : Icons.history_rounded,
                  color: upcoming ? _C.green : _C.muted,
                  size: 23,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            opponent.isEmpty ? 'Соперник' : opponent,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 15, height: 1.12),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: upcoming ? _C.accentBorder : _C.border),
                          ),
                          child: Text(score, style: const TextStyle(fontWeight: FontWeight.w900, color: _C.green, fontSize: 14.5)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 7),
                    Wrap(
                      spacing: 6,
                      runSpacing: 5,
                      children: [
                        _MiniBadge(text: eventType, icon: Icons.flag_rounded, active: upcoming),
                        _MiniBadge(text: date, icon: Icons.calendar_month_rounded, active: upcoming),
                      ],
                    ),
                    if (meta.isNotEmpty) ...[
                      const SizedBox(height: 6),
                      Text(
                        meta,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 12, height: 1.15),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 8),
              if (canEdit)
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_horiz_rounded, color: _C.muted),
                  onSelected: (v) {
                    if (v == 'delete') onDelete();
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Удалить'))],
                )
              else
                const Icon(Icons.chevron_right_rounded, color: _C.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _MiniBadge extends StatelessWidget {
  final String text;
  final IconData icon;
  final bool active;
  final bool compact;

  const _MiniBadge({required this.text, required this.icon, required this.active, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 8, vertical: compact ? 4 : 5),
      decoration: BoxDecoration(
        color: active ? Colors.white : const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: active ? _C.accentBorder : _C.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: compact ? 12 : 13, color: active ? _C.green : _C.muted),
          const SizedBox(width: 4),
          Text(
            text,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(color: active ? _C.green : _C.muted, fontWeight: FontWeight.w900, fontSize: compact ? 10.2 : 10.8),
          ),
        ],
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final bool compact;

  const _MetricCard({required this.icon, required this.title, required this.value, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: compact ? 9 : 12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(compact ? 16 : 20),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.green, size: compact ? 17 : 20),
          SizedBox(width: compact ? 7 : 9),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: compact ? 14 : 16)),
                const SizedBox(height: 1),
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w700, color: _C.muted, fontSize: compact ? 10.5 : 11)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SelectedMatchesHeader extends StatelessWidget {
  final String title;
  final bool canEdit;
  final bool compact;
  final VoidCallback onAdd;

  const _SelectedMatchesHeader({required this.title, required this.canEdit, required this.onAdd, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: compact ? 14 : 15))),
        if (canEdit) _TopActionButton(icon: Icons.add_rounded, text: compact ? 'Добавить' : 'Матч', compact: compact, onTap: onAdd),
      ],
    );
  }
}

class _CmrSearch extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final VoidCallback onClear;
  final bool compact;

  const _CmrSearch({required this.controller, required this.hint, required this.onClear, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return _CmrFieldShell(
      compact: compact,
      child: Row(
        children: [
          Icon(Icons.search_rounded, size: compact ? 19 : 22, color: _C.muted),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: controller,
              style: TextStyle(fontSize: compact ? 13 : 14),
              decoration: InputDecoration(
                hintText: hint,
                border: InputBorder.none,
                isDense: true,
                hintStyle: TextStyle(color: _C.muted, fontSize: compact ? 12.5 : 14),
              ),
              textInputAction: TextInputAction.search,
            ),
          ),
          if (controller.text.isNotEmpty) IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(), icon: const Icon(Icons.close_rounded, size: 20), onPressed: onClear),
        ],
      ),
    );
  }
}

class _CmrTextField extends StatelessWidget {
  final TextEditingController controller;
  final IconData icon;
  final String hint;
  final TextInputType? keyboardType;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  const _CmrTextField({required this.controller, required this.icon, required this.hint, this.keyboardType, this.maxLines = 1, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return _CmrFieldShell(child: Row(crossAxisAlignment: maxLines > 1 ? CrossAxisAlignment.start : CrossAxisAlignment.center, children: [
      Padding(padding: EdgeInsets.only(top: maxLines > 1 ? 10 : 0), child: Icon(icon, size: 20, color: _C.muted)),
      const SizedBox(width: 8),
      Expanded(child: TextField(controller: controller, keyboardType: keyboardType, maxLines: maxLines, onChanged: onChanged, decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true, hintStyle: const TextStyle(color: _C.muted)))),
    ]));
  }
}

class _CmrFieldShell extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  final bool compact;

  const _CmrFieldShell({required this.child, this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final box = Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: compact ? 6 : 7),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(compact ? 14 : 16),
        border: Border.all(color: _C.border),
      ),
      child: child,
    );
    if (onTap == null) return box;
    return Material(
      color: Colors.transparent,
      child: InkWell(borderRadius: BorderRadius.circular(compact ? 14 : 16), onTap: onTap, child: box),
    );
  }
}


class _ArchiveMonthChip extends StatelessWidget {
  final String title;
  final int count;
  final bool active;
  final VoidCallback onTap;

  const _ArchiveMonthChip({
    required this.title,
    required this.count,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 42,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: active ? _C.accentSoft : const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: active ? _C.green : _C.border, width: active ? 1.2 : 1),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: TextStyle(
                color: active ? _C.green : _C.text,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
            const SizedBox(width: 7),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(99),
                border: Border.all(color: active ? Colors.white.withOpacity(.12) : _C.border),
              ),
              child: Text(
                '$count',
                style: TextStyle(
                  color: active ? _C.green : _C.muted,
                  fontSize: 10,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ArchiveMiniStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _ArchiveMiniStat({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.text, size: 17),
          const SizedBox(width: 7),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.muted,
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 13,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterButton extends StatelessWidget {
  final String text;
  final bool active;
  final VoidCallback onTap;
  final bool compact;

  const _FilterButton({required this.text, required this.active, required this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(compact ? 14 : 16),
      onTap: onTap,
      child: Container(
        height: compact ? 36 : 42,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? _C.accentSoft : const Color(0xFFF8FAFC),
          borderRadius: BorderRadius.circular(compact ? 14 : 16),
          border: Border.all(color: active ? _C.green : _C.border, width: active ? 1.2 : 1),
        ),
        child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? _C.green : _C.text, fontWeight: FontWeight.w900, fontSize: compact ? 11.2 : 12)),
      ),
    );
  }
}

class _TopActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool compact;

  const _TopActionButton({required this.icon, required this.text, required this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(compact ? 14 : 16),
      onTap: onTap,
      child: Container(
        height: compact ? 38 : 42,
        padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12),
        decoration: BoxDecoration(
          color: _C.accentSoft,
          borderRadius: BorderRadius.circular(compact ? 14 : 16),
          border: Border.all(color: _C.accentBorder),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: compact ? 16 : 18, color: _C.green),
            const SizedBox(width: 6),
            Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _C.green, fontWeight: FontWeight.w900, fontSize: compact ? 11.2 : 12))),
          ],
        ),
      ),
    );
  }
}

class _SquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool compact;

  const _SquareButton({required this.icon, required this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final size = compact ? 38.0 : 42.0;
    return InkWell(
      borderRadius: BorderRadius.circular(compact ? 14 : 15),
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(compact ? 14 : 15), border: Border.all(color: _C.border)),
        child: Icon(icon, color: _C.text, size: compact ? 20 : 24),
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _HeaderIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: 42,
        height: 42,
        decoration: BoxDecoration(
          color: _C.accentSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.accentBorder),
        ),
        child: Icon(icon, color: _C.green, size: 21),
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;
  final bool compact;

  const _HeroStat({required this.value, required this.title, this.compact = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 9 : 10, vertical: compact ? 8 : 10),
      decoration: BoxDecoration(
        color: _C.accentSoft,
        borderRadius: BorderRadius.circular(compact ? 15 : 18),
        border: Border.all(color: _C.accentBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _C.green, fontWeight: FontWeight.w900, fontSize: compact ? 14.5 : 17)),
          const SizedBox(height: 1),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: compact ? 10 : 11)),
        ],
      ),
    );
  }
}

class _CmrIconBox extends StatelessWidget {
  final IconData icon;
  final bool dark;
  final double size;

  const _CmrIconBox({required this.icon, this.dark = false, this.size = 46});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: dark ? Colors.white.withOpacity(.12) : _C.accentSoft,
        borderRadius: BorderRadius.circular(size * .35),
        border: Border.all(color: dark ? Colors.white.withOpacity(.12) : _C.accentBorder),
      ),
      child: Icon(icon, color: dark ? Colors.white : _C.green, size: size * .48),
    );
  }
}

class _MiniEmpty extends StatelessWidget {
  final String text;
  const _MiniEmpty({required this.text});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700))));
}

class _CmrEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String actionText;
  final VoidCallback onAction;
  const _CmrEmptyState({required this.icon, required this.title, required this.text, required this.actionText, required this.onAction});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(22),
        decoration: _C.cardDecoration,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: _C.green, size: 42),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: _C.title.copyWith(fontSize: 18)),
          const SizedBox(height: 8),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          _TopActionButton(icon: Icons.refresh_rounded, text: actionText, onTap: onAction),
        ]),
      ),
    );
  }
}

class _C {
  static const Color bg = Color(0xFFF3F5F8);
  static const Color text = Color(0xFF0F172A);
  static const Color muted = Color(0xFF64748B);
  static const Color border = Color(0xFFE5E7EB);

  // Спокойнее, чем яркий салатовый: зелёный остаётся акцентом, но не перегружает мобильный экран.
  static const Color green = Color(0xFF1F7A4D);
  static const Color darkGreen = Color(0xFF10251C);
  static const Color accentSoft = Color(0xFFF2F7F4);
  static const Color accentBorder = Color(0xFFD7E8DE);
  static const Color red = Color(0xFFEF4444);

  static const TextStyle title = TextStyle(color: text, fontWeight: FontWeight.w900, letterSpacing: -.2);
  static const TextStyle darkTitle = TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: -.2);

  static BoxDecoration get cardDecoration => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 22, offset: Offset(0, 10))],
      );
}
