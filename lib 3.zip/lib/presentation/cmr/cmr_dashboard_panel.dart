import 'dart:convert';

import 'package:dio/dio.dart' as dio;
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sportoteka/core/app_export.dart';

class CmrDashboardPanel extends StatefulWidget {
  final String apiBaseUrl;
  final int userId;
  final String role;
  final int coachId;
  final int clubId;
  final int teamId;
  final int playerId;
  final VoidCallback? onOpenWorkspace;
  final void Function(int chatId, String chatName)? onOpenChat;
  final void Function(String moduleId)? onOpenModule;

  const CmrDashboardPanel({
    super.key,
    required this.apiBaseUrl,
    required this.userId,
    required this.role,
    this.coachId = 0,
    this.clubId = 0,
    this.teamId = 0,
    this.playerId = 0,
    this.onOpenWorkspace,
    this.onOpenChat,
    this.onOpenModule,
  });

  @override
  State<CmrDashboardPanel> createState() => _CmrDashboardPanelState();
}

class _CmrDashboardPanelState extends State<CmrDashboardPanel> {
  late final dio.Dio _dio;
  bool _loading = true;
  String _error = '';
  Map<String, dynamic> _data = {};

  bool get _isPlayer => widget.role == 'player' || widget.role == 'parent';

  bool get _isClub {
    final r = widget.role.trim().toLowerCase();
    return r == 'club' || r == 'clubs' || r == 'клуб';
  }

  bool get _isCoach {
    final r = widget.role.trim().toLowerCase();
    return r == 'coach' || r == 'trainer' || r == 'тренер' || r == 'coaches';
  }

  void _openWorkspaceFromPanel() {
    final effectiveClubId = widget.clubId > 0 ? widget.clubId : widget.userId;
    final effectiveTrainerId = widget.coachId > 0 ? widget.coachId : widget.userId;

    if (_isClub) {
      Get.toNamed(
        AppRoutes.clubDashboardScreen,
        arguments: {
          'mode': 'club_profile',
          'club_id': effectiveClubId,
        },
      );
      return;
    }

    if (_isCoach) {
      Get.toNamed(
        AppRoutes.clubDashboardScreen,
        arguments: {
          'mode': 'trainer_assigned',
          'trainer_id': effectiveTrainerId,
          'coach_id': effectiveTrainerId,
          if (widget.clubId > 0) 'club_id': widget.clubId,
          if (widget.teamId > 0) 'team_id': widget.teamId,
        },
      );
      return;
    }

    if (widget.teamId > 0) {
      Get.toNamed(
        '/myTeamScreen',
        arguments: {
          'team_id': widget.teamId,
          'mode': _isPlayer ? 'player_team' : 'dashboard_team',
        },
      );
    }
  }

  @override
  void initState() {
    super.initState();
    _dio = dio.Dio(dio.BaseOptions(
      baseUrl: widget.apiBaseUrl.endsWith('/') ? widget.apiBaseUrl : '${widget.apiBaseUrl}/',
      connectTimeout: const Duration(seconds: 12),
      receiveTimeout: const Duration(seconds: 20),
      responseType: dio.ResponseType.plain,
    ));
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = '';
    });

    try {
      final res = await _dio.get('get_cmr_dashboard.php', queryParameters: {
        'user_id': widget.userId,
        'role': widget.role,
        'coach_id': widget.coachId > 0 ? widget.coachId : widget.userId,
        'club_id': widget.clubId,
        'team_id': widget.teamId,
        'player_id': widget.playerId,
        'period_days': 120,
        'limit': 6,
      });

      final body = _decodeServerMap(res.data);
      final success = body['success'] == true || body['status'] == 'success';
      if (!success) {
        throw Exception((body['message'] ?? 'Не удалось загрузить приборную панель').toString());
      }

      if (!mounted) return;
      setState(() {
        _data = body;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return _loadingView();
    if (_error.isNotEmpty) return _errorView();

    final sections = _asMap(_data['sections']);
    final summary = _asMap(_data['summary']);
    final teams = _asList(_data['teams']);
    final title = _isPlayer ? 'Моя приборная панель' : 'Приборная панель тренера';
    final subtitle = _isPlayer
        ? _playerSubtitle()
        : teams.isEmpty
            ? 'Команды не найдены'
            : 'Последние события по ${teams.length} командам';

    return LayoutBuilder(
      builder: (context, constraints) {
        final isMobile = constraints.maxWidth < 600;
        
        return SingleChildScrollView(
          padding: EdgeInsets.all(isMobile ? 12 : 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _Header(
                title: title,
                subtitle: subtitle,
                isMobile: isMobile,
              ),
              SizedBox(height: isMobile ? 16 : 20),
              _SummaryStrip(
                summary: summary,
                isPlayer: _isPlayer,
                isMobile: isMobile,
              ),
              SizedBox(height: isMobile ? 16 : 20),
              _buildSectionsVertical(sections, isMobile),
            ],
          ),
        );
      },
    );
  }

  /// Вертикальные секции - каждая идёт последовательно сверху вниз
  Widget _buildSectionsVertical(Map<String, dynamic> sections, bool isMobile) {
    final sectionList = _getSectionList(sections);
    
    return Column(
      children: sectionList.asMap().entries.map((entry) {
        final section = entry.value;
        return Padding(
          padding: EdgeInsets.only(bottom: entry.key == sectionList.length - 1 ? 0 : (isMobile ? 16 : 20)),
          child: _SectionWithRows(
            title: section.title,
            icon: section.icon,
            color: section.color,
            rows: section.rows,
            emptyTitle: section.emptyTitle,
            emptySubtitle: section.emptySubtitle,
            actionText: section.actionText,
            onTapAll: section.onTapAll,
            builder: section.builder,
            isMobile: isMobile,
          ),
        );
      }).toList(),
    );
  }

  List<_SectionData> _getSectionList(Map<String, dynamic> sections) {
    if (_isPlayer) {
      return [
        _SectionData(
          title: 'СОБЫТИЯ',
          icon: Icons.event_available_rounded,
          color: const Color(0xFF2563EB),
          rows: _asList(sections['events']),
          emptyTitle: 'Событий пока нет',
          emptySubtitle: 'Тренировки и игры появятся здесь.',
          builder: (row) => _eventRow(row),
        ),
        _SectionData(
          title: 'МАТЧИ',
          icon: Icons.sports_soccer_rounded,
          color: const Color(0xFF16A34A),
          rows: _asList(sections['matches']),
          emptyTitle: 'Матчей пока нет',
          emptySubtitle: 'Здесь будут ближайшие и прошедшие игры.',
          builder: (row) => _matchRow(row),
        ),
        _SectionData(
          title: 'ПОСЕЩЕНИЯ',
          icon: Icons.check_circle_rounded,
          color: const Color(0xFF0891B2),
          rows: _asList(sections['attendance']),
          emptyTitle: 'Отметок пока нет',
          emptySubtitle: 'Последние отметки посещаемости появятся здесь.',
          builder: (row) => _attendanceRow(row),
        ),
        _SectionData(
          title: 'ОЦЕНКИ И ТЕСТЫ',
          actionText: 'контроль',
          icon: Icons.fact_check_rounded,
          color: const Color(0xFFEA580C),
          rows: [..._asList(sections['ratings']), ..._asList(sections['testing'])].take(5).toList(),
          emptyTitle: 'Оценок пока нет',
          emptySubtitle: 'Оценки тренера и тестирования будут здесь.',
          onTapAll: () => widget.onOpenModule?.call('testing'),
          builder: (row) => row.containsKey('rating') ? _ratingRow(row) : _testingRow(row),
        ),
        _SectionData(
          title: 'ЧАТЫ',
          actionText: 'чат',
          icon: Icons.forum_rounded,
          color: const Color(0xFF7C3AED),
          rows: _asList(sections['chats']),
          emptyTitle: 'Нет сообщений',
          emptySubtitle: 'Последние сообщения появятся здесь.',
          onTapAll: () => widget.onOpenModule?.call('chats'),
          builder: (row) => _chatRow(row),
        ),
      ];
    }
    
    return [
      _SectionData(
        title: 'БЛИЖАЙШИЕ СОБЫТИЯ',
        icon: Icons.event_available_rounded,
        color: const Color(0xFF2563EB),
        rows: _asList(sections['events']),
        emptyTitle: 'Событий пока нет',
        emptySubtitle: 'Тренировки, игры и встречи появятся здесь.',
        builder: (row) => _eventRow(row),
      ),
      _SectionData(
        title: 'МАТЧИ',
        icon: Icons.sports_soccer_rounded,
        color: const Color(0xFF16A34A),
        rows: _asList(sections['matches']),
        emptyTitle: 'Матчей пока нет',
        emptySubtitle: 'Ближайшие и последние матчи будут здесь.',
        builder: (row) => _matchRow(row),
      ),
      _SectionData(
        title: 'ПОСЕЩЕНИЯ',
        icon: Icons.how_to_reg_rounded,
        color: const Color(0xFF0891B2),
        rows: _asList(sections['attendance']),
        emptyTitle: 'Отметок пока нет',
        emptySubtitle: 'Последние отметки игроков появятся здесь.',
        builder: (row) => _attendanceRow(row),
      ),
      _SectionData(
        title: 'ОЦЕНКИ',
        actionText: 'оценки',
        icon: Icons.star_rounded,
        color: const Color(0xFFF59E0B),
        rows: _asList(sections['ratings']),
        emptyTitle: 'Оценок пока нет',
        emptySubtitle: 'Последние оценки игроков будут здесь.',
        builder: (row) => _ratingRow(row),
      ),
      _SectionData(
        title: 'ТЕСТИРОВАНИЕ',
        actionText: 'контроль',
        icon: Icons.fact_check_rounded,
        color: const Color(0xFFEA580C),
        rows: _asList(sections['testing']),
        emptyTitle: 'Тестов пока нет',
        emptySubtitle: 'Последние тестирования появятся здесь.',
        onTapAll: () => widget.onOpenModule?.call('testing'),
        builder: (row) => _testingRow(row),
      ),
      _SectionData(
        title: 'ЧАТЫ',
        actionText: 'чат',
        icon: Icons.forum_rounded,
        color: const Color(0xFF7C3AED),
        rows: _asList(sections['chats']),
        emptyTitle: 'Нет сообщений',
        emptySubtitle: 'Последние командные и личные сообщения будут здесь.',
        onTapAll: () => widget.onOpenModule?.call('chats'),
        builder: (row) => _chatRow(row),
      ),
    ];
  }

  // ==================== СТРОКИ ДЛЯ РАЗНЫХ ТИПОВ ДАННЫХ ====================
  
  Widget _eventRow(Map<String, dynamic> row) {
    return _DashboardRow(
      icon: Icons.event_available_rounded,
      color: const Color(0xFF2563EB),
      title: _s(row['title'], fallback: 'Событие'),
      subtitle: _firstNotEmpty([row['location'], row['subtitle'], row['notes'], _eventType(row['type'])]),
      trailing: _shortDate(_s(row['date'])),
      teamName: _teamName(row),
      onTap: null,
    );
  }

  Widget _matchRow(Map<String, dynamic> row) {
    final team = _firstNotEmpty([row['team_name'], row['stored_team_name']], fallback: 'Команда');
    final opponent = _s(row['opponent'], fallback: 'Соперник');
    final score = '${_s(row['our_score'], fallback: '0')}:${_s(row['opponent_score'], fallback: '0')}';
    return _DashboardRow(
      icon: Icons.sports_soccer_rounded,
      color: const Color(0xFF16A34A),
      title: '$team — $opponent',
      subtitle: _firstNotEmpty([row['competition_name'], row['stadium'], row['event_type']], fallback: 'Матч'),
      trailing: score == '0:0' ? _shortDate(_s(row['date'])) : score,
      teamName: team,
      onTap: null,
    );
  }

  Widget _attendanceRow(Map<String, dynamic> row) {
    return _DashboardRow(
      icon: Icons.how_to_reg_rounded,
      color: const Color(0xFF0891B2),
      title: _firstNotEmpty([row['player_name'], row['event_title']], fallback: 'Посещаемость'),
      subtitle: _firstNotEmpty([row['event_title'], row['note']], fallback: _attendanceStatus(row['status'])),
      trailing: _attendanceStatus(row['status']),
      teamName: _teamName(row),
      onTap: null,
    );
  }

  Widget _ratingRow(Map<String, dynamic> row) {
    return _DashboardRow(
      icon: Icons.star_rounded,
      color: const Color(0xFFF59E0B),
      title: _firstNotEmpty([row['player_name'], row['event_title']], fallback: 'Оценка'),
      subtitle: _firstNotEmpty([row['event_title']], fallback: 'Оценка тренера'),
      trailing: '${_s(row['rating'], fallback: '0')}/5',
      teamName: _teamName(row),
      onTap: null,
    );
  }

  Widget _testingRow(Map<String, dynamic> row) {
    final count = int.tryParse('${row['results_count'] ?? 0}') ?? 0;
    return _DashboardRow(
      icon: Icons.fact_check_rounded,
      color: const Color(0xFFEA580C),
      title: _s(row['title'], fallback: 'Тестирование'),
      subtitle: '${_s(row['category_code'], fallback: 'контроль')} • ${_s(row['stage_code'], fallback: 'этап')}',
      trailing: count > 0 ? '$count рез.' : _shortDate(_s(row['date'])),
      teamName: _teamName(row),
      onTap: () => widget.onOpenModule?.call('testing'),
    );
  }

  Widget _chatRow(Map<String, dynamic> row) {
    final chatId = int.tryParse('${row['id'] ?? 0}') ?? 0;
    final title = _s(row['title'], fallback: 'Чат');
    return _DashboardRow(
      icon: Icons.forum_rounded,
      color: const Color(0xFF7C3AED),
      title: title,
      subtitle: _firstNotEmpty([row['last_message'], row['sender_name']], fallback: 'Нет сообщений'),
      trailing: _shortDate(_s(row['date'])),
      teamName: '',
      onTap: chatId > 0 ? () => widget.onOpenChat?.call(chatId, title) : () => widget.onOpenModule?.call('chats'),
    );
  }

  // ==================== ВСПОМОГАТЕЛЬНЫЕ ВИДЖЕТЫ ====================

  Widget _loadingView() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5EAF1)),
      ),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2.5)),
          SizedBox(width: 12),
          Text('Загрузка панели...', style: TextStyle(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _errorView() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5EAF1)),
      ),
      child: Column(
        children: [
          const Icon(Icons.error_outline, color: Color(0xFFEF4444), size: 48),
          const SizedBox(height: 12),
          const Text(
            'Не удалось загрузить панель',
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: Color(0xFF0F172A)),
          ),
          const SizedBox(height: 8),
          Text(
            _error,
            style: const TextStyle(fontSize: 12, color: Color(0xFF64748B)),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: _load,
            icon: const Icon(Icons.refresh_rounded, size: 18),
            label: const Text('Повторить'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF2563EB),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }

  String _playerSubtitle() {
    final player = _asMap(_data['player']);
    final name = _s(player['player_name']).trim();
    final team = _s(player['team_name']).trim();
    if (name.isNotEmpty && team.isNotEmpty) return '$name • $team';
    if (team.isNotEmpty) return team;
    return 'Последние события игрока';
  }
}

// ==================== ДАННЫЕ СЕКЦИИ ====================

class _SectionData {
  final String title;
  final IconData icon;
  final Color color;
  final List<Map<String, dynamic>> rows;
  final String emptyTitle;
  final String emptySubtitle;
  final String? actionText;
  final VoidCallback? onTapAll;
  final Widget Function(Map<String, dynamic>) builder;

  _SectionData({
    required this.title,
    required this.icon,
    required this.color,
    required this.rows,
    required this.emptyTitle,
    required this.emptySubtitle,
    this.actionText,
    this.onTapAll,
    required this.builder,
  });
}

// ==================== ВИДЖЕТ СЕКЦИИ СО СТРОКАМИ ====================

class _SectionWithRows extends StatelessWidget {
  final String title;
  final IconData icon;
  final Color color;
  final List<Map<String, dynamic>> rows;
  final String emptyTitle;
  final String emptySubtitle;
  final String? actionText;
  final VoidCallback? onTapAll;
  final Widget Function(Map<String, dynamic>) builder;
  final bool isMobile;

  const _SectionWithRows({
    required this.title,
    required this.icon,
    required this.color,
    required this.rows,
    required this.emptyTitle,
    required this.emptySubtitle,
    this.actionText,
    this.onTapAll,
    required this.builder,
    this.isMobile = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5EAF1)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.04),
            blurRadius: 12,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Заголовок секции
          Padding(
            padding: EdgeInsets.fromLTRB(16, 14, 16, 10),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: color.withOpacity(.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: color, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    title,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      letterSpacing: 0.5,
                      color: Color(0xFF64748B),
                    ),
                  ),
                ),
                if (actionText != null && actionText!.isNotEmpty)
                  _ActionButton(
                    text: actionText!,
                    color: color,
                    onTap: onTapAll,
                  ),
              ],
            ),
          ),

          const Divider(height: 1, color: Color(0xFFF0F2F5)),

          // Список строк
          if (rows.isEmpty)
            _EmptyState(
              icon: icon,
              title: emptyTitle,
              subtitle: emptySubtitle,
            )
          else
            ...rows.asMap().entries.map((entry) => Column(
                  children: [
                    builder(entry.value),
                    if (entry.key != rows.length - 1)
                      const Divider(height: 1, color: Color(0xFFF0F2F5)),
                  ],
                )),
        ],
      ),
    );
  }
}

class _ActionButton extends StatelessWidget {
  final String text;
  final Color color;
  final VoidCallback? onTap;

  const _ActionButton({
    required this.text,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        child: Text(
          text,
          style: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
            color: onTap == null ? const Color(0xFF94A3B8) : color,
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          Icon(icon, color: const Color(0xFFCBD5E1), size: 40),
          const SizedBox(height: 10),
          Text(
            title,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w500,
              color: Color(0xFF94A3B8),
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

// ==================== ОСТАЛЬНЫЕ ВИДЖЕТЫ (Header, Summary, DashboardRow) ====================

class _Header extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isMobile;

  const _Header({
    required this.title,
    required this.subtitle,
    this.isMobile = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: isMobile ? 44 : 48,
          height: isMobile ? 44 : 48,
          decoration: BoxDecoration(
            color: const Color(0xFF2563EB).withOpacity(.10),
            borderRadius: BorderRadius.circular(isMobile ? 12 : 14),
          ),
          child: const Icon(Icons.dashboard_customize_rounded, color: Color(0xFF2563EB), size: 22),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: isMobile ? 18 : 20,
                  fontWeight: FontWeight.w800,
                  color: const Color(0xFF0F172A),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: TextStyle(
                  fontSize: isMobile ? 11 : 12,
                  fontWeight: FontWeight.w600,
                  color: const Color(0xFF64748B),
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SummaryStrip extends StatelessWidget {
  final Map<String, dynamic> summary;
  final bool isPlayer;
  final bool isMobile;

  const _SummaryStrip({
    required this.summary,
    required this.isPlayer,
    this.isMobile = false,
  });

  @override
  Widget build(BuildContext context) {
    final items = isPlayer
        ? [
            ['События', summary['events']],
            ['Матчи', summary['matches']],
            ['Отметки', summary['attendance']],
            ['Оценки', summary['ratings']],
            ['Тесты', summary['testing']],
          ]
        : [
            ['Команды', summary['teams']],
            ['События', summary['events']],
            ['Матчи', summary['matches']],
            ['Отметки', summary['attendance']],
            ['Оценки', summary['ratings']],
            ['Тесты', summary['testing']],
          ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: items.map((e) {
          return Container(
            margin: const EdgeInsets.only(right: 8),
            padding: EdgeInsets.symmetric(horizontal: isMobile ? 10 : 12, vertical: isMobile ? 8 : 9),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: const Color(0xFFE5EAF1)),
            ),
            child: Row(
              children: [
                Text(
                  '${e[1] ?? 0}',
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  '${e[0]}',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF64748B),
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _DashboardRow extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final String trailing;
  final String teamName;
  final VoidCallback? onTap;

  const _DashboardRow({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.trailing,
    required this.teamName,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isVerySmall = constraints.maxWidth < 400;

        final content = InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: color.withOpacity(.10),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: color, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF0F172A),
                          height: 1.2,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF64748B),
                          height: 1.15,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (teamName.isNotEmpty && !isVerySmall) ...[
                        const SizedBox(height: 4),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF1F5F9),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            teamName,
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF475569),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
                if (trailing.isNotEmpty && !isVerySmall) ...[
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: color.withOpacity(.08),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: color.withOpacity(.12)),
                    ),
                    child: Text(
                      trailing,
                      style: TextStyle(
                        color: color,
                        fontSize: 10,
                        fontWeight: FontWeight.w800,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              ],
            ),
          ),
        );

        if (onTap == null) return content;
        return content;
      },
    );
  }
}

// ==================== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ====================

Map<String, dynamic> _decodeServerMap(dynamic raw) {
  if (raw is Map) return Map<String, dynamic>.from(raw);
  final text = (raw ?? '').toString().trim();
  if (text.isEmpty) return <String, dynamic>{};

  try {
    final decoded = jsonDecode(text);
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
  } catch (_) {}

  final start = text.indexOf('{');
  final end = text.lastIndexOf('}');
  if (start >= 0 && end > start) {
    try {
      final decoded = jsonDecode(text.substring(start, end + 1));
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {}
  }

  return <String, dynamic>{
    'success': false,
    'status': 'error',
    'message': text.length > 260 ? '${text.substring(0, 260)}...' : text,
  };
}

Map<String, dynamic> _asMap(dynamic v) {
  if (v is Map) return Map<String, dynamic>.from(v);
  return <String, dynamic>{};
}

List<Map<String, dynamic>> _asList(dynamic v) {
  if (v is List) {
    return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }
  return <Map<String, dynamic>>[];
}

String _s(dynamic v, {String fallback = ''}) {
  final text = (v ?? '').toString().trim();
  return text.isEmpty ? fallback : text;
}

String _firstNotEmpty(List<dynamic> values, {String fallback = ''}) {
  for (final v in values) {
    final text = _s(v);
    if (text.isNotEmpty) return text;
  }
  return fallback;
}

String _teamName(Map<String, dynamic> row) => _firstNotEmpty([row['team_name'], row['stored_team_name']], fallback: '');

int _asInt(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('${value ?? ''}'.trim()) ?? 0;
}

String _attendanceStatus(dynamic raw) {
  switch (_s(raw)) {
    case 'present':
      return 'был';
    case 'absent':
      return 'нет';
    case 'late':
      return 'опоздал';
    case 'injured':
      return 'травма';
    case 'individual':
      return 'индив.';
    case 'dayoff':
      return 'отдых';
    default:
      return _s(raw, fallback: 'статус');
  }
}

String _eventType(dynamic raw) {
  switch (_s(raw)) {
    case 'training':
      return 'Тренировка';
    case 'league':
      return 'Официальная игра';
    case 'friendly':
      return 'Товарищеская игра';
    case 'theory':
      return 'Теория';
    case 'gym':
      return 'Зал';
    case 'day_off':
      return 'Восстановление';
    default:
      return _s(raw, fallback: 'Событие');
  }
}

String _shortDate(String raw) {
  if (raw.trim().isEmpty) return '';
  final normalized = raw.trim().replaceFirst(' ', 'T');
  final dt = DateTime.tryParse(normalized);
  if (dt == null) return raw.length > 10 ? raw.substring(0, 10) : raw;

  final now = DateTime.now();
  final today = DateTime(now.year, now.month, now.day);
  final day = DateTime(dt.year, dt.month, dt.day);
  final time = dt.hour == 0 && dt.minute == 0 ? '' : ' ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';

  if (day == today) return 'сегодня$time';
  if (day == today.add(const Duration(days: 1))) return 'завтра$time';
  if (day == today.subtract(const Duration(days: 1))) return 'вчера$time';

  return '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}$time';
}