import 'dart:async';

import '../models/action_tracker_protocol.dart';
import 'action_tracker_ble_service.dart';

class TeamTrackerBleEvent {
  final String deviceUuid;
  final String deviceName;
  final ActionTrackerParseResult data;

  const TeamTrackerBleEvent({
    required this.deviceUuid,
    required this.deviceName,
    required this.data,
  });
}

class TeamTrackerBleLog {
  final String deviceUuid;
  final String deviceName;
  final String line;

  const TeamTrackerBleLog({
    required this.deviceUuid,
    required this.deviceName,
    required this.line,
  });
}

class _TeamTrackerConnection {
  final ActionTrackerDevice info;
  final ActionTrackerBleService service;
  StreamSubscription<ActionTrackerParseResult>? dataSub;
  StreamSubscription<String>? logSub;

  _TeamTrackerConnection({required this.info, required this.service});
}

/// Командный GPS-pool: один экземпляр ActionTrackerBleService на каждый UUID.
/// Это принципиально: одиночный ActionTrackerBleService хранит один BluetoothDevice,
/// поэтому при подключении второго GPS отключал первый.
class TeamActionTrackerBlePool {
  final Map<String, _TeamTrackerConnection> _connections = {};
  final StreamController<TeamTrackerBleEvent> _data = StreamController.broadcast();
  final StreamController<TeamTrackerBleLog> _logs = StreamController.broadcast();

  Stream<TeamTrackerBleEvent> get dataStream => _data.stream;
  Stream<TeamTrackerBleLog> get logStream => _logs.stream;

  List<ActionTrackerDevice> get connectedInfos => _connections.values
      .where((c) => c.service.commandChannelReady)
      .map((c) => c.info)
      .toList(growable: false);

  int get connectedCount => connectedInfos.length;

  bool isConnected(String uuid) => _connections[uuid]?.service.commandChannelReady == true;

  ActionTrackerBleService? serviceFor(String uuid) => _connections[uuid]?.service;

  Future<void> connect(ActionTrackerDevice info) async {
    final existing = _connections[info.id];
    if (existing != null && existing.service.commandChannelReady) return;

    final service = existing?.service ?? ActionTrackerBleService();
    await service.init();
    await service.connect(info);

    final conn = existing ?? _TeamTrackerConnection(info: info, service: service);
    _connections[info.id] = conn;

    await conn.dataSub?.cancel();
    conn.dataSub = service.dataStream.listen((event) {
      _data.add(TeamTrackerBleEvent(
        deviceUuid: info.id,
        deviceName: info.name,
        data: event,
      ));
    });

    await conn.logSub?.cancel();
    conn.logSub = service.logStream.listen((line) {
      _logs.add(TeamTrackerBleLog(
        deviceUuid: info.id,
        deviceName: info.name,
        line: line,
      ));
    });
  }

  Future<void> ensureConnected(Iterable<ActionTrackerDevice> devices) async {
    for (final device in devices) {
      if (!isConnected(device.id)) {
        await connect(device);
      }
    }
  }

  Future<void> disconnect(String uuid) async {
    final conn = _connections.remove(uuid);
    if (conn == null) return;
    await conn.dataSub?.cancel();
    await conn.logSub?.cancel();
    await conn.service.disconnect(clearInfo: true);
    await conn.service.dispose();
  }

  Future<void> disconnectAll() async {
    final ids = _connections.keys.toList(growable: false);
    for (final id in ids) {
      await disconnect(id);
    }
  }

  Future<void> requestCurrentGps(String uuid) async {
    final service = serviceFor(uuid);
    if (service == null) throw StateError('GPS $uuid не подключён');
    final ready = await service.ensureCommandChannel();
    if (!ready) throw StateError('TX/RX GPS $uuid не готов');
    await service.requestCurrentGpsCandidate();
  }

  Future<void> requestBattery(String uuid) async {
    final service = serviceFor(uuid);
    if (service == null) return;
    await service.requestBatteryAndGpsState();
  }

  Future<void> dispose() async {
    await disconnectAll();
    await _data.close();
    await _logs.close();
  }
}
