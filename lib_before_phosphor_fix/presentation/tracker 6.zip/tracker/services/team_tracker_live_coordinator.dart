import 'dart:async';
import 'dart:math' as math;

import '../models/tracker_live_models.dart';
import 'team_action_tracker_ble_pool.dart';
import 'tracker_live_api.dart';

class TeamTrackerBinding {
  final int playerId;
  final String playerName;
  final String deviceUuid;
  final String deviceName;

  const TeamTrackerBinding({
    required this.playerId,
    required this.playerName,
    required this.deviceUuid,
    required this.deviceName,
  });
}

class TeamTrackerChannelDebug {
  final int playerId;
  final String playerName;
  final String deviceUuid;
  final String deviceName;
  final bool bleReady;
  final int? liveSessionId;
  final DateTime? lastRxAt;
  final DateTime? lastGpsAt;
  final DateTime? lastServerSaveAt;
  final String? lastError;
  final int receivedPackets;
  final int savedPoints;

  const TeamTrackerChannelDebug({
    required this.playerId,
    required this.playerName,
    required this.deviceUuid,
    required this.deviceName,
    required this.bleReady,
    required this.liveSessionId,
    required this.lastRxAt,
    required this.lastGpsAt,
    required this.lastServerSaveAt,
    required this.lastError,
    required this.receivedPackets,
    required this.savedPoints,
  });
}

class _Runtime {
  final TeamTrackerBinding binding;
  int? liveSessionId;
  Timer? pollTimer;
  DateTime? lastRxAt;
  DateTime? lastGpsAt;
  DateTime? lastServerSaveAt;
  String? lastError;
  int receivedPackets = 0;
  int savedPoints = 0;
  double totalDistanceM = 0;
  double maxSpeedKmh = 0;
  double speedSum = 0;
  int speedCount = 0;
  double? lastLat;
  double? lastLon;
  int? lastTimeMs;

  _Runtime(this.binding);
}

/// Одна командная тренировка на планшете, но отдельная активная строка сервера
/// и отдельный BLE-канал для каждого игрока/UUID.
class TeamTrackerLiveCoordinator {
  final int clubId;
  final int teamId;
  final int? fieldId;
  final TeamActionTrackerBlePool pool;
  final TrackerLiveApi api;
  final Map<String, _Runtime> _runtime = {};
  StreamSubscription<TeamTrackerBleEvent>? _dataSub;
  Timer? _heartbeat;
  bool _running = false;

  TeamTrackerLiveCoordinator({
    required this.clubId,
    required this.teamId,
    required this.pool,
    TrackerLiveApi? api,
    this.fieldId,
  }) : api = api ?? TrackerLiveApi();

  bool get running => _running;

  List<TeamTrackerChannelDebug> get debugRows => _runtime.values.map((r) {
        return TeamTrackerChannelDebug(
          playerId: r.binding.playerId,
          playerName: r.binding.playerName,
          deviceUuid: r.binding.deviceUuid,
          deviceName: r.binding.deviceName,
          bleReady: pool.isConnected(r.binding.deviceUuid),
          liveSessionId: r.liveSessionId,
          lastRxAt: r.lastRxAt,
          lastGpsAt: r.lastGpsAt,
          lastServerSaveAt: r.lastServerSaveAt,
          lastError: r.lastError,
          receivedPackets: r.receivedPackets,
          savedPoints: r.savedPoints,
        );
      }).toList(growable: false);

  Future<void> start(List<TeamTrackerBinding> bindings) async {
    if (_running) return;
    if (bindings.isEmpty) throw StateError('Нет привязанных GPS-трекеров команды');

    final duplicateDevices = <String>{};
    final seenDevices = <String>{};
    final seenPlayers = <int>{};
    for (final b in bindings) {
      if (!seenDevices.add(b.deviceUuid)) duplicateDevices.add(b.deviceUuid);
      if (!seenPlayers.add(b.playerId)) {
        throw StateError('Игрок ${b.playerName} привязан более чем к одному GPS');
      }
    }
    if (duplicateDevices.isNotEmpty) {
      throw StateError('Один UUID назначен нескольким игрокам: ${duplicateDevices.join(', ')}');
    }

    for (final b in bindings) {
      if (!pool.isConnected(b.deviceUuid)) {
        throw StateError('GPS ${b.deviceName} (${b.deviceUuid}) не подключён');
      }
      _runtime[b.deviceUuid] = _Runtime(b);
    }

    _dataSub = pool.dataStream.listen(_onData);

    for (final r in _runtime.values) {
      r.liveSessionId = await api.startLiveSession(
        clubId: clubId,
        teamId: teamId,
        playerId: r.binding.playerId,
        fieldId: fieldId,
        deviceUuid: r.binding.deviceUuid,
        deviceName: r.binding.deviceName,
        source: 'team_tracker',
        activityType: 'football_field',
        fieldRequired: fieldId != null,
      );

      r.pollTimer = Timer.periodic(const Duration(seconds: 1), (_) async {
        try {
          await pool.requestCurrentGps(r.binding.deviceUuid);
        } catch (e) {
          r.lastError = 'TX: $e';
        }
      });
    }

    _heartbeat = Timer.periodic(const Duration(seconds: 5), (_) async {
      for (final r in _runtime.values) {
        final id = r.liveSessionId;
        if (id == null) continue;
        try {
          await api.heartbeatLiveSession(
            liveSessionId: id,
            statusText: 'team_live:${pool.connectedCount}/${_runtime.length}',
          );
        } catch (e) {
          r.lastError = 'heartbeat: $e';
        }
      }
    });

    _running = true;
  }

  Future<void> _onData(TeamTrackerBleEvent event) async {
    final r = _runtime[event.deviceUuid];
    if (r == null) return;
    r.receivedPackets++;
    r.lastRxAt = DateTime.now();

    final chunk = event.data.gpsChunk;
    if (chunk == null || chunk.points.isEmpty) return;

    for (final p in chunk.points) {
      if (p.latitude.abs() < 0.000001 && p.longitude.abs() < 0.000001) {
        r.lastError = 'GPS 0,0: нет спутниковой фиксации';
        continue;
      }

      final nowMs = p.timeMs > 0 ? p.timeMs : DateTime.now().millisecondsSinceEpoch;
      double deltaM = 0;
      double speedKmh = 0;
      if (r.lastLat != null && r.lastLon != null && r.lastTimeMs != null) {
        deltaM = _distanceM(r.lastLat!, r.lastLon!, p.latitude, p.longitude);
        final dt = (nowMs - r.lastTimeMs!) / 1000.0;
        if (dt > 0 && dt < 30 && deltaM < 300) speedKmh = deltaM / dt * 3.6;
        if (speedKmh <= 45) {
          r.totalDistanceM += deltaM;
          r.maxSpeedKmh = math.max(r.maxSpeedKmh, speedKmh);
          r.speedSum += speedKmh;
          r.speedCount++;
        }
      }
      r.lastLat = p.latitude;
      r.lastLon = p.longitude;
      r.lastTimeMs = nowMs;
      r.lastGpsAt = DateTime.now();

      final id = r.liveSessionId;
      if (id == null) continue;
      try {
        await api.saveLivePoint(TrackerLivePointPayload(
          liveSessionId: id,
          clubId: clubId,
          teamId: teamId,
          playerId: r.binding.playerId,
          deviceUuid: r.binding.deviceUuid,
          latitude: p.latitude,
          longitude: p.longitude,
          timeMs: nowMs,
          speedKmh: speedKmh,
          rawSpeedKmh: speedKmh,
          distanceDeltaM: deltaM,
          totalDistanceM: r.totalDistanceM,
          maxSpeedKmh: r.maxSpeedKmh,
          avgSpeedKmh: r.speedCount == 0 ? 0 : r.speedSum / r.speedCount,
          rawHex: event.data.rawHex,
        ));
        r.savedPoints++;
        r.lastServerSaveAt = DateTime.now();
        r.lastError = null;
      } catch (e) {
        r.lastError = 'save: $e';
      }
    }
  }

  Future<void> stop({bool createFinalSession = true}) async {
    // Идемпотентная остановка: повторный сигнал от UI не должен повторно
    // закрывать первую/отдельную сессию команды.
    if (!_running) return;
    _running = false;
    _heartbeat?.cancel();
    _heartbeat = null;
    await _dataSub?.cancel();
    _dataSub = null;

    for (final r in _runtime.values) {
      r.pollTimer?.cancel();
      final id = r.liveSessionId;
      if (id == null) continue;
      try {
        await api.stopLiveSession(
          liveSessionId: id,
          createFinalSession: createFinalSession,
        );
        r.liveSessionId = null;
      } catch (e) {
        r.lastError = 'stop: $e';
      }
    }
  }

  static double _distanceM(double lat1, double lon1, double lat2, double lon2) {
    const earth = 6371000.0;
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dp = (lat2 - lat1) * math.pi / 180;
    final dl = (lon2 - lon1) * math.pi / 180;
    final a = math.sin(dp / 2) * math.sin(dp / 2) +
        math.cos(p1) * math.cos(p2) * math.sin(dl / 2) * math.sin(dl / 2);
    return earth * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  Future<void> dispose() async {
    if (_running) await stop(createFinalSession: false);
  }
}
