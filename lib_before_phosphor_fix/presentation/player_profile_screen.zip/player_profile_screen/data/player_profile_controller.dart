import 'package:flutter/foundation.dart';
import '../models/player_profile_models.dart';
import 'player_profile_repository.dart';

class PlayerProfileController extends ChangeNotifier {
  final Map<String,dynamic> player;
  final PlayerProfileRepository repository;
  PlayerProfileSection section = PlayerProfileSection.overview;
  PlayerProfileSnapshot? snapshot;
  PlayerProfileSession? selectedSession;
  bool loading = false;
  bool sessionLoading = false;
  String? error;

  PlayerProfileController({required this.player, PlayerProfileRepository? repository}) : repository = repository ?? PlayerProfileRepository();
  int _i(dynamic v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}') ?? 0;
  int get teamId => _i(player['team_id'] ?? player['teamId']);
  int get playerId => _i(player['player_id'] ?? player['id'] ?? player['user_id']);

  Future<void> load() async {
    loading = true; error = null; notifyListeners();
    try {
      snapshot = await repository.loadSnapshot(player);
      if (snapshot!.sessions.isNotEmpty) await selectSession(snapshot!.sessions.first);
    } catch (e) { error = e.toString(); }
    loading = false; notifyListeners();
  }

  void selectSection(PlayerProfileSection value) { section = value; notifyListeners(); }

  Future<void> selectSession(PlayerProfileSession session) async {
    selectedSession = session; sessionLoading = true; notifyListeners();
    try { selectedSession = await repository.loadSessionReport(session, teamId: teamId, playerId: playerId); } catch (_) {}
    sessionLoading = false; notifyListeners();
  }
}
