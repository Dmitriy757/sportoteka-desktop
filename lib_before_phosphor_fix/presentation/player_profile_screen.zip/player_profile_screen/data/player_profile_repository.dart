import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../models/player_profile_models.dart';

class PlayerProfileRepository {
  final String apiBase;
  final http.Client _client;
  PlayerProfileRepository({this.apiBase = 'https://sportotekaapp.ru/api', http.Client? client}) : _client = client ?? http.Client();

  int _i(dynamic v) => v is num ? v.toInt() : int.tryParse('${v ?? ''}') ?? 0;
  double _d(dynamic v) => v is num ? v.toDouble() : double.tryParse('${v ?? ''}'.replaceAll(',', '.')) ?? 0;
  String _s(dynamic v) => '${v ?? ''}'.trim();
  DateTime? _date(dynamic v) => DateTime.tryParse(_s(v).replaceAll(' ', 'T'));

  Future<Map<String, dynamic>> _get(String endpoint, Map<String, String> qp) async {
    final response = await _client.get(Uri.parse('$apiBase/$endpoint').replace(queryParameters: qp)).timeout(const Duration(seconds: 18));
    final body = response.body.trim();
    if (body.isEmpty || body.startsWith('<')) return {};
    final decoded = jsonDecode(body);
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
    return {};
  }

  List<Map<String, dynamic>> _list(Map<String, dynamic> data, List<String> keys) {
    for (final key in keys) {
      final value = data[key];
      if (value is List) return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (value is Map) {
        for (final nested in ['items', 'rows', 'data']) {
          final v = value[nested];
          if (v is List) return v.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
        }
      }
    }
    return [];
  }

  Future<PlayerProfileSnapshot> loadSnapshot(Map<String, dynamic> player) async {
    final teamId = _i(player['team_id'] ?? player['teamId']);
    final clubId = _i(player['club_id'] ?? player['clubId']);
    final playerId = _i(player['player_id'] ?? player['id'] ?? player['user_id']);
    final results = await Future.wait([
      _get('get_team_events.php', {'team_id': '$teamId', 'club_id': '$clubId'}).catchError((_) => <String,dynamic>{}),
      _get('get_player_attendance_log.php', {'team_id': '$teamId', 'player_id': '$playerId'}).catchError((_) => <String,dynamic>{}),
      _get('get_team_matches.php', {'team_id': '$teamId'}).catchError((_) => <String,dynamic>{}),
      _get('get_player_testing.php', {'team_id': '$teamId', 'player_id': '$playerId'}).catchError((_) => <String,dynamic>{}),
      _get('medical/get_medical_records.php', {'user_id': '${_i(player['user_id'] ?? playerId)}'}).catchError((_) => <String,dynamic>{}),
      _get('tracker/get_tracker_sessions.php', {'team_id': '$teamId', 'player_id': '$playerId', 'include_personal': '1', 'limit': '300'}).catchError((_) => <String,dynamic>{}),
    ]);
    final trainings = _list(results[0], ['events','items','rows','data']);
    final attendance = _list(results[1], ['items','attendance','rows','data']);
    final matches = _list(results[2], ['matches','items','rows','data']);
    final tests = _list(results[3], ['sessions','results','items','rows','data']);
    final medical = _list(results[4], ['records','items','rows','data']);
    final sessionsRaw = _list(results[5], ['sessions','items','rows','data']);
    final sessions = sessionsRaw.map((e) => PlayerProfileSession(
      id: _i(e['session_id'] ?? e['id']), date: _date(e['started_at'] ?? e['date'] ?? e['created_at']),
      title: _s(e['title']).isEmpty ? 'Сессия трекера' : _s(e['title']), distanceM: _d(e['total_distance_m'] ?? e['distance_m']),
      maxSpeedKmh: _d(e['max_speed_kmh'] ?? e['max_speed']), avgSpeedKmh: _d(e['avg_speed_kmh'] ?? e['avg_speed']),
      durationSec: _i(e['duration_sec'] ?? e['duration_seconds']), sprintCount: _i(e['sprint_count'] ?? e['sprints']),
      avgHr: _d(e['heart_rate_avg_bpm'] ?? e['avg_hr']), maxHr: _d(e['heart_rate_max_bpm'] ?? e['max_hr']),
    )).where((e) => e.id > 0).toList()..sort((a,b)=>(b.date ?? DateTime(1970)).compareTo(a.date ?? DateTime(1970)));
    final snapshot = PlayerProfileSnapshot(player: player, trainings: trainings, attendance: attendance, matches: matches, tests: tests, medical: medical, sessions: sessions);
    return snapshot.copyWith(timeline: buildTimeline(snapshot));
  }

  Future<PlayerProfileSession> loadSessionReport(PlayerProfileSession session, {required int teamId, required int playerId}) async {
    final data = await _get('tracker/get_training_report.php', {
      'session_id': '${session.id}', 'team_id': '$teamId', 'player_id': '$playerId',
      'include_maps': '1', 'include_heatmap': '1', 'include_charts': '1', 'include_hr': '1', 'include_players': '1', 'hr_fallback': '1',
    });
    final root = data['report'] is Map ? Map<String,dynamic>.from(data['report']) : data;
    List<dynamic> pick(List<String> keys) {
      for (final key in keys) { final v = root[key]; if (v is List) return v; }
      for (final group in ['map','charts','player','summary','data']) { final g=root[group]; if (g is Map) { for (final key in keys) { final v=g[key]; if (v is List) return v; } } }
      return const [];
    }
    List<PlayerProfilePoint> points(List<dynamic> raw) => raw.whereType<Map>().map((m) {
      final x = _d(m['x'] ?? m['field_x'] ?? m['lng'] ?? m['longitude']);
      final y = _d(m['y'] ?? m['field_y'] ?? m['lat'] ?? m['latitude']);
      return PlayerProfilePoint(x, y, value: _d(m['value'] ?? m['weight'] ?? m['intensity']));
    }).toList();
    List<double> nums(List<dynamic> raw, List<String> keys) => raw.map((e) {
      if (e is num) return e.toDouble();
      if (e is Map) { for (final k in keys) { final n=_d(e[k]); if (n>0) return n; } }
      return 0.0;
    }).where((e)=>e>0).toList();
    final hrRaw = pick(['heartRateTimeline','heart_rate_timeline','hr_series','heart_rate']);
    final hrValues = <double>[];
    final hrSeconds = <double>[];
    DateTime? firstHrTime;
    for (var index = 0; index < hrRaw.length; index++) {
      final item = hrRaw[index];
      double bpm = 0;
      double sec = index.toDouble();
      if (item is num) {
        bpm = item.toDouble();
      } else if (item is Map) {
        bpm = _d(item['bpm'] ?? item['heart_rate'] ?? item['value']);
        final directSec = _d(item['elapsed_sec'] ?? item['sec'] ?? item['second'] ?? item['seconds']);
        final minute = _d(item['minute']);
        final timeMs = _d(item['time_ms'] ?? item['timestamp_ms']);
        if (directSec > 0) {
          sec = directSec;
        } else if (minute > 0) {
          sec = minute * 60;
        } else if (timeMs > 0) {
          sec = timeMs / 1000;
        } else {
          final rawTime = item['recorded_at'] ?? item['created_at'] ?? item['timestamp'] ?? item['time'];
          final parsed = _date(rawTime);
          if (parsed != null) {
            firstHrTime ??= parsed;
            sec = parsed.difference(firstHrTime!).inMilliseconds / 1000;
          }
        }
      }
      if (bpm > 0) {
        hrValues.add(bpm);
        hrSeconds.add(sec);
      }
    }
    return session.copyWith(
      route: points(pick(['routePoints','route_points','route','gps_points','track_points'])),
      heatmap: points(pick(['heatmapPoints','heatmap_points','heatmap'])),
      speedTimeline: nums(pick(['speedTimeline','speed_timeline','speed_series']), ['speed','speed_kmh','value']),
      heartRateTimeline: hrValues,
      heartRateTimelineSec: hrSeconds,
      trackerReportJson: root,
    );
  }

  List<PlayerTimelineItem> buildTimeline(PlayerProfileSnapshot s) {
    final out = <PlayerTimelineItem>[];
    for (final e in s.trainings) out.add(PlayerTimelineItem(date: _date(e['start_at'] ?? e['date']), type: 'training', title: _s(e['title']).isEmpty ? 'Тренировка' : _s(e['title']), subtitle: _s(e['location']), icon: const IconData(0xe566, fontFamily: 'MaterialIcons')));
    for (final e in s.matches) out.add(PlayerTimelineItem(date: _date(e['match_date'] ?? e['date']), type: 'match', title: _s(e['opponent']).isEmpty ? 'Матч' : 'Матч · ${_s(e['opponent'])}', subtitle: _s(e['score']), icon: const IconData(0xe4dc, fontFamily: 'MaterialIcons')));
    for (final e in s.tests) out.add(PlayerTimelineItem(date: _date(e['date'] ?? e['created_at']), type: 'test', title: _s(e['test_name']).isEmpty ? 'Тестирование' : _s(e['test_name']), subtitle: _s(e['result'] ?? e['value']), icon: const IconData(0xe6e1, fontFamily: 'MaterialIcons')));
    for (final e in s.sessions) out.add(PlayerTimelineItem(date: e.date, type: 'tracker', title: e.title, subtitle: '${(e.distanceM/1000).toStringAsFixed(1)} км · ${e.maxSpeedKmh.toStringAsFixed(1)} км/ч', icon: const IconData(0xe425, fontFamily: 'MaterialIcons')));
    out.sort((a,b)=>(b.date ?? DateTime(1970)).compareTo(a.date ?? DateTime(1970)));
    return out;
  }
}
