import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:sportoteka/core/app_export.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/chat_screen/chat_room_screen.dart';

import 'data/player_profile_controller.dart';
import 'models/player_profile_models.dart';
import 'sections/player_activity_section.dart';
import 'sections/player_analytics_section.dart';
import 'sections/player_card_section.dart';
import 'sections/player_health_section.dart';
import 'sections/player_matches_section.dart';
import 'sections/player_overview_section.dart';
import 'sections/player_testing_section.dart';
import 'widgets/player_profile_header.dart';
import 'widgets/player_profile_ui.dart';
import 'widgets/player_section_tabs.dart';

class CmrPlayerProfileScreen extends StatefulWidget {
  final Map<String, dynamic> player;
  final bool embeddedInWorkspace;
  final VoidCallback? onClose;
  final VoidCallback? onEdit;
  final VoidCallback? onMessage;

  const CmrPlayerProfileScreen({
    super.key,
    required this.player,
    this.embeddedInWorkspace = false,
    this.onClose,
    this.onEdit,
    this.onMessage,
  });

  @override
  State<CmrPlayerProfileScreen> createState() => _CmrPlayerProfileScreenState();
}

class _CmrPlayerProfileScreenState extends State<CmrPlayerProfileScreen> {
  static const String _apiBase = 'https://sportotekaapp.ru/api';
  late PlayerProfileController controller;

  @override
  void initState() {
    super.initState();
    controller = PlayerProfileController(player: widget.player)..addListener(_refresh);
    controller.load();
  }

  @override
  void didUpdateWidget(covariant CmrPlayerProfileScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    final oldId = oldWidget.player['player_id'] ?? oldWidget.player['id'];
    final newId = widget.player['player_id'] ?? widget.player['id'];
    if (oldId != newId) {
      controller.removeListener(_refresh);
      controller.dispose();
      controller = PlayerProfileController(player: widget.player)..addListener(_refresh);
      controller.load();
    }
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  int _i(dynamic value) => value is num ? value.toInt() : int.tryParse('${value ?? ''}') ?? 0;

  String _name() {
    final full = '${widget.player['full_name'] ?? widget.player['fullName'] ?? widget.player['name'] ?? ''}'.trim();
    if (full.isNotEmpty) return full;
    return '${widget.player['first_name'] ?? ''} ${widget.player['last_name'] ?? ''}'.trim();
  }

  Future<void> _handleEdit() async {
    if (widget.onEdit != null) {
      widget.onEdit!();
      return;
    }

    await Get.toNamed(AppRoutes.editPlayerScreen, arguments: widget.player);
    if (mounted) await controller.load();
  }

  Future<void> _handleMessage() async {
    if (widget.onMessage != null) {
      widget.onMessage!();
      return;
    }

    final myId = await PrefUtils.getUserId() ?? 0;
    final peerId = _i(widget.player['user_id'] ?? widget.player['userId']);
    if (myId <= 0 || peerId <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не удалось определить пользователя для чата')),
      );
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('$_apiBase/get_or_create_private_chat.php'),
        body: {'me': '$myId', 'peer_id': '$peerId'},
      ).timeout(const Duration(seconds: 15));
      final decoded = jsonDecode(response.body);
      final chatId = decoded is Map ? _i(decoded['chat_id'] ?? decoded['id']) : 0;
      if (chatId <= 0) throw Exception('Сервер не вернул chat_id');
      if (!mounted) return;

      await Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) => ChatRoomScreen(
            chatId: chatId,
            userId: myId,
            chatName: _name().isEmpty ? 'Игрок' : _name(),
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Не удалось открыть чат: $e')),
      );
    }
  }

  @override
  void dispose() {
    controller.removeListener(_refresh);
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final body = Container(
      color: Colors.white,
      child: Column(
        children: [
          PlayerProfileHeader(
            player: widget.player,
            embedded: widget.embeddedInWorkspace,
            onClose: widget.onClose,
            onEdit: _handleEdit,
            onMessage: _handleMessage,
          ),
          PlayerSectionTabs(value: controller.section, onChanged: controller.selectSection),
          Expanded(child: _content()),
        ],
      ),
    );

    if (widget.embeddedInWorkspace) return body;
    return Scaffold(
      backgroundColor: PpColors.bg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: ClipRRect(borderRadius: BorderRadius.circular(18), child: body),
        ),
      ),
    );
  }

  Widget _content() {
    if (controller.loading && controller.snapshot == null) {
      return const Center(child: CircularProgressIndicator(color: PpColors.green));
    }
    if (controller.error != null && controller.snapshot == null) {
      return Center(
        child: PpActionRow(
          icon: Icons.refresh_rounded,
          title: 'Не удалось загрузить профиль',
          subtitle: controller.error!,
          onTap: controller.load,
        ),
      );
    }
    final data = controller.snapshot;
    if (data == null) return const SizedBox.shrink();

    switch (controller.section) {
      case PlayerProfileSection.overview:
        return PlayerOverviewSection(data: data, session: controller.selectedSession);
      case PlayerProfileSection.activity:
        return PlayerActivitySection(
          data: data,
          selectedSession: controller.selectedSession,
          sessionLoading: controller.sessionLoading,
          onSelectSession: controller.selectSession,
        );
      case PlayerProfileSection.matches:
        return PlayerMatchesSection(data: data);
      case PlayerProfileSection.analytics:
        return PlayerAnalyticsSection(data: data, session: controller.selectedSession);
      case PlayerProfileSection.testing:
        return PlayerTestingSection(data: data);
      case PlayerProfileSection.health:
        return PlayerHealthSection(data: data);
      case PlayerProfileSection.card:
        return PlayerCardSection(data: data, session: controller.selectedSession);
    }
  }
}
