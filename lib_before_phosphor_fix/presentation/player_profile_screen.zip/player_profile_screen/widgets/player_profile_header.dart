import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'player_profile_ui.dart';

class PlayerProfileHeader extends StatelessWidget {
  final Map<String,dynamic> player;
  final VoidCallback? onClose;
  final VoidCallback? onEdit;
  final VoidCallback? onMessage;
  final bool embedded;
  const PlayerProfileHeader({super.key, required this.player, this.onClose, this.onEdit, this.onMessage, required this.embedded});
  String _s(dynamic v)=>'${v??''}'.trim();
  String get name { final full=_s(player['full_name']??player['name']); if(full.isNotEmpty)return full; return '${_s(player['first_name'])} ${_s(player['last_name'])}'.trim(); }
  String get subtitle => [_s(player['position']??player['role']), _s(player['number']).isEmpty?'':'№${_s(player['number'])}', _s(player['team_name'])].where((e)=>e.isNotEmpty).join(' · ');
  String? get photo { final raw=_s(player['photo']??player['avatar']??player['photo_url']); if(raw.isEmpty)return null; if(raw.startsWith('http'))return raw; return raw.startsWith('/')?'https://sportotekaapp.ru$raw':'https://sportotekaapp.ru/uploads/$raw'; }
  @override Widget build(BuildContext context)=>Container(height:92,padding:EdgeInsets.symmetric(horizontal:embedded?18:20),decoration:const BoxDecoration(color:Colors.white,border:Border(bottom:BorderSide(color:PpColors.line,width:.7))),child:Row(children:[ClipOval(child:Container(width:58,height:58,color:PpColors.soft2,child:photo==null?const Icon(Icons.person_rounded,color:PpColors.muted):CachedNetworkImage(imageUrl:photo!,fit:BoxFit.cover,errorWidget:(_,__,___)=>const Icon(Icons.person_rounded)))),const SizedBox(width:13),Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(name.isEmpty?'Игрок':name,style:PpText.title(18)),const SizedBox(height:4),Text(subtitle,style:PpText.body(11.5))])),_HeaderButton(label:'Сообщение',onTap:onMessage),const SizedBox(width:7),_HeaderButton(label:'Редактировать',onTap:onEdit),if(onClose!=null)...[const SizedBox(width:7),IconButton(onPressed:onClose,icon:const Icon(Icons.close_rounded,size:19),tooltip:'Закрыть')]]));
}
class _HeaderButton extends StatelessWidget { final String label; final VoidCallback? onTap; const _HeaderButton({required this.label,this.onTap}); @override Widget build(BuildContext context)=>TextButton(onPressed:onTap,style:TextButton.styleFrom(foregroundColor:PpColors.text,padding:const EdgeInsets.symmetric(horizontal:12,vertical:10),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(10)),backgroundColor:PpColors.soft),child:Text(label,style:PpText.body(11.5,color:PpColors.text,weight:FontWeight.w600))); }
