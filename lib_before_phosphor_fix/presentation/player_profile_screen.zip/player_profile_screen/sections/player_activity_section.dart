import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import 'package:sportoteka/presentation/tracker/screens/tracker_match_workspace_screen.dart';

import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerActivitySection extends StatefulWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? selectedSession;
  final bool sessionLoading;
  final ValueChanged<PlayerProfileSession> onSelectSession;

  const PlayerActivitySection({
    super.key,
    required this.data,
    required this.selectedSession,
    required this.sessionLoading,
    required this.onSelectSession,
  });

  @override
  State<PlayerActivitySection> createState() => _PlayerActivitySectionState();
}

class _PlayerActivitySectionState extends State<PlayerActivitySection> {
  DateTime? _selectedDay;

  List<DateTime> get _days {
    final keys = <String, DateTime>{};
    for (final session in widget.data.sessions) {
      final d = session.date;
      if (d == null) continue;
      final day = DateTime(d.year, d.month, d.day);
      keys[DateFormat('yyyy-MM-dd').format(day)] = day;
    }
    final result = keys.values.toList()..sort((a, b) => b.compareTo(a));
    return result;
  }

  List<PlayerProfileSession> get _visibleSessions {
    if (_selectedDay == null) return widget.data.sessions;
    return widget.data.sessions.where((session) {
      final d = session.date;
      return d != null &&
          d.year == _selectedDay!.year &&
          d.month == _selectedDay!.month &&
          d.day == _selectedDay!.day;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: PpColors.bg,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 24),
        children: [
          const PpSectionTitle(
            title: 'Активность игрока',
            subtitle: 'Выберите дату и сессию. Поле, скорость и пульс открываются отдельным окном.',
          ),
          const SizedBox(height: 14),
          _dayPicker(),
          const SizedBox(height: 14),
          _summaryStrip(),
          const SizedBox(height: 14),
          _sessionGrid(),
        ],
      ),
    );
  }

  Widget _dayPicker() {
    final days = _days;
    if (days.isEmpty) return const SizedBox.shrink();
    return SizedBox(
      height: 68,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: days.length + 1,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (_, index) {
          if (index == 0) {
            final active = _selectedDay == null;
            return _DayTile(
              top: 'Все',
              bottom: '${widget.data.sessions.length} сессий',
              active: active,
              onTap: () => setState(() => _selectedDay = null),
            );
          }
          final day = days[index - 1];
          final count = widget.data.sessions.where((s) {
            final d = s.date;
            return d != null && d.year == day.year && d.month == day.month && d.day == day.day;
          }).length;
          final active = _selectedDay != null &&
              _selectedDay!.year == day.year &&
              _selectedDay!.month == day.month &&
              _selectedDay!.day == day.day;
          return _DayTile(
            top: DateFormat('dd MMM', 'ru').format(day),
            bottom: '$count ${count == 1 ? 'сессия' : 'сессии'}',
            active: active,
            onTap: () => setState(() => _selectedDay = day),
          );
        },
      ),
    );
  }

  Widget _summaryStrip() {
    final sessions = _visibleSessions;
    final distance = sessions.fold<double>(0, (sum, s) => sum + s.distanceM);
    final duration = sessions.fold<int>(0, (sum, s) => sum + s.durationSec);
    final sprints = sessions.fold<int>(0, (sum, s) => sum + s.sprintCount);
    final maxSpeed = sessions.fold<double>(0, (max, s) => s.maxSpeedKmh > max ? s.maxSpeedKmh : max);

    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 780 ? 4 : 2;
        final width = (constraints.maxWidth - (columns - 1) * 10) / columns;
        final items = [
          ('Сессии', '${sessions.length}'),
          ('Дистанция', distance <= 0 ? '—' : '${(distance / 1000).toStringAsFixed(1)} км'),
          ('Макс. скорость', maxSpeed <= 0 ? '—' : '${maxSpeed.toStringAsFixed(1)} км/ч'),
          ('Время / спринты', '${_duration(duration)} · $sprints'),
        ];
        return Wrap(
          spacing: 10,
          runSpacing: 10,
          children: items
              .map((item) => SizedBox(
                    width: width,
                    child: PpSurface(
                      color: Colors.white,
                      padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(item.$1, style: PpText.body(10.5)),
                          const SizedBox(height: 5),
                          Text(item.$2, style: PpText.title(15)),
                        ],
                      ),
                    ),
                  ))
              .toList(),
        );
      },
    );
  }

  Widget _sessionGrid() {
    final sessions = _visibleSessions;
    if (sessions.isEmpty) {
      return const PpEmpty(
        title: 'Активности нет',
        text: 'За выбранную дату сессии трекера не найдены.',
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final count = constraints.maxWidth >= 1050
            ? 3
            : constraints.maxWidth >= 680
                ? 2
                : 1;
        final ratio = count == 1 ? 2.9 : 1.65;
        return GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: count,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: ratio,
          ),
          itemCount: sessions.length,
          itemBuilder: (_, index) {
            final session = sessions[index];
            final active = widget.selectedSession?.id == session.id;
            return _SessionCard(
              session: session,
              active: active,
              loading: active && widget.sessionLoading,
              onSelect: () => widget.onSelectSession(session),
              onAnalytics: () {
                widget.onSelectSession(session);
                if (!mounted) return;
                _openAnalytics(session);
              },
            );
          },
        );
      },
    );
  }

  void _openAnalytics(PlayerProfileSession session) {

    final player = widget.data.player;
    final teamId = _int(player['team_id'] ?? player['teamId']);
    final clubId = _int(player['club_id'] ?? player['clubId']);
    final userId = _int(player['user_id'] ?? player['userId'] ?? player['id']);
    final playerId = _int(player['id'] ?? player['player_id'] ?? player['playerId']);
    final playerName = _text(player['full_name'] ?? player['fullName'] ?? player['name']);
    final teamName = _text(player['team_name'] ?? player['teamName']);
    final clubName = _text(player['club_name'] ?? player['clubName']);

    if (teamId <= 0 || playerId <= 0 || session.id <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Не хватает team_id, player_id или session_id для открытия трекера.')),
      );
      return;
    }

    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => TrackerMatchWorkspaceScreen(
          clubId: clubId,
          clubName: clubName.isEmpty ? 'Клуб' : clubName,
          teamId: teamId,
          teamName: teamName.isEmpty ? 'Команда' : teamName,
          userId: userId,
          initialPlayers: <Map<String, dynamic>>[
            <String, dynamic>{
              ...player,
              'id': playerId,
              'player_id': playerId,
              'name': playerName,
              'full_name': playerName,
            },
          ],
          analyticsOnly: true,
          initialSection: TrackerWorkspaceSection.analytics,
          initialPlayerId: playerId,
          initialSessionId: session.id,
          initialAnalyticsTab: 1,
        ),
      ),
    );
  }

  int _int(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('${value ?? ''}'.trim()) ?? 0;
  }

  String _text(dynamic value) {
    final text = '${value ?? ''}'.trim();
    return text == 'null' ? '' : text;
  }

  String _duration(int seconds) {
    if (seconds <= 0) return '—';
    final h = seconds ~/ 3600;
    final m = (seconds % 3600) ~/ 60;
    return h > 0 ? '${h}ч ${m}м' : '${m}м';
  }
}

class _DayTile extends StatelessWidget {
  final String top;
  final String bottom;
  final bool active;
  final VoidCallback onTap;

  const _DayTile({
    required this.top,
    required this.bottom,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          width: 104,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: active ? PpColors.greenSoft : Colors.white,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: active ? PpColors.greenBorder : PpColors.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(top, style: PpText.body(11.6, color: PpColors.text, weight: FontWeight.w600)),
              const SizedBox(height: 4),
              Text(bottom, style: PpText.body(9.8)),
            ],
          ),
        ),
      ),
    );
  }
}

class _SessionCard extends StatelessWidget {
  final PlayerProfileSession session;
  final bool active;
  final bool loading;
  final VoidCallback onSelect;
  final VoidCallback onAnalytics;

  const _SessionCard({
    required this.session,
    required this.active,
    required this.loading,
    required this.onSelect,
    required this.onAnalytics,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onSelect,
        borderRadius: BorderRadius.circular(12),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          padding: const EdgeInsets.all(13),
          decoration: BoxDecoration(
            color: active ? PpColors.greenSoft : Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: active ? PpColors.greenBorder : PpColors.line),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      session.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PpText.body(12, color: PpColors.text, weight: FontWeight.w600),
                    ),
                  ),
                  if (loading)
                    const SizedBox(
                      width: 15,
                      height: 15,
                      child: CircularProgressIndicator(strokeWidth: 1.8, color: PpColors.green),
                    ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                session.date == null ? 'Без даты' : DateFormat('dd.MM.yyyy · HH:mm').format(session.date!),
                style: PpText.body(10),
              ),
              const Spacer(),
              Wrap(
                spacing: 12,
                runSpacing: 5,
                children: [
                  _smallMetric('${(session.distanceM / 1000).toStringAsFixed(1)} км', 'дистанция'),
                  _smallMetric('${session.maxSpeedKmh.toStringAsFixed(1)}', 'км/ч'),
                  _smallMetric('${session.sprintCount}', 'спринты'),
                ],
              ),
              const Spacer(),
              Align(
                alignment: Alignment.centerRight,
                child: TextButton(
                  onPressed: onAnalytics,
                  style: TextButton.styleFrom(
                    foregroundColor: PpColors.greenDark,
                    backgroundColor: Colors.white.withOpacity(.72),
                    padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                  ),
                  child: Text('Показать аналитику', style: PpText.body(10.8, color: PpColors.greenDark, weight: FontWeight.w600)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _smallMetric(String value, String label) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(value, style: PpText.body(11.3, color: PpColors.text, weight: FontWeight.w600)),
        Text(label, style: PpText.body(9.2)),
      ],
    );
  }
}

class _AnalyticsHeader extends StatelessWidget {
  final PlayerProfileSession session;
  final VoidCallback onClose;

  const _AnalyticsHeader({required this.session, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: PpColors.line)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(session.title, style: PpText.title(16)),
                const SizedBox(height: 3),
                Text(
                  session.date == null ? 'Аналитика сессии' : DateFormat('dd.MM.yyyy · HH:mm').format(session.date!),
                  style: PpText.body(10.5),
                ),
              ],
            ),
          ),
          IconButton(onPressed: onClose, icon: const Icon(Icons.close_rounded, size: 20)),
        ],
      ),
    );
  }
}
