import 'dart:async';

import '../models/action_tracker_protocol.dart';
import 'action_tracker_ble_service.dart';

class TeamTrackerBleEvent {
  final String deviceUuid;
  final String deviceName;
  final ActionTrackerParseResult data;

  const TeamTrackerBleEvent({
    required this.deviceUuid,
    required this.deviceName,
    required this.data,
  });
}

class TeamTrackerBleLog {
  final String deviceUuid;
  final String deviceName;
  final String line;

  const TeamTrackerBleLog({
    required this.deviceUuid,
    required this.deviceName,
    required this.line,
  });
}

class _TeamTrackerConnection {
  final ActionTrackerDevice info;
  final ActionTrackerBleService service;
  StreamSubscription<ActionTrackerParseResult>? dataSub;
  StreamSubscription<String>? logSub;
  DateTime? lastPoolCommandAt;
  DateTime? lastReconnectAttemptAt;

  _TeamTrackerConnection({required this.info, required this.service});
}

/// Командный GPS-pool: один экземпляр ActionTrackerBleService на каждый UUID.
/// Это принципиально: одиночный ActionTrackerBleService хранит один BluetoothDevice,
/// поэтому при подключении второго GPS отключал первый.
class TeamActionTrackerBlePool {
  final Map<String, _TeamTrackerConnection> _connections = {};
  final StreamController<TeamTrackerBleEvent> _data = StreamController.broadcast();
  final StreamController<TeamTrackerBleLog> _logs = StreamController.broadcast();
  Timer? _idleKeepAliveTimer;
  Future<void> _commandQueue = Future<void>.value();
  bool _connectingAny = false;
  bool _livePolling = false;
  int _keepAliveCursor = 0;

  Stream<TeamTrackerBleEvent> get dataStream => _data.stream;
  Stream<TeamTrackerBleLog> get logStream => _logs.stream;

  List<ActionTrackerDevice> get connectedInfos => _connections.values
      .where((c) => c.service.commandChannelReady)
      .map((c) => c.info)
      .toList(growable: false);

  int get connectedCount => connectedInfos.length;

  bool isConnected(String uuid) => _connections[uuid]?.service.commandChannelReady == true;

  ActionTrackerBleService? serviceFor(String uuid) => _connections[uuid]?.service;

  Future<void> connect(ActionTrackerDevice info) async {
    final existing = _connections[info.id];
    if (existing != null && existing.service.commandChannelReady) return;

    final service = existing?.service ?? ActionTrackerBleService();
    final conn = existing ?? _TeamTrackerConnection(info: info, service: service);
    _connections[info.id] = conn;

    await conn.dataSub?.cancel();
    conn.dataSub = service.dataStream.listen((event) {
      _data.add(TeamTrackerBleEvent(
        deviceUuid: info.id,
        deviceName: info.name,
        data: event,
      ));
    });

    await conn.logSub?.cancel();
    conn.logSub = service.logStream.listen((line) {
      _logs.add(TeamTrackerBleLog(
        deviceUuid: info.id,
        deviceName: info.name,
        line: line,
      ));
    });

    _connectingAny = true;
    try {
      await service.init();
      // В командном режиме не запрашиваем список офлайн-файлов при каждом
      // подключении: эта длинная операция перегружала GATT при наборе команды.
      await service.connect(info, inspectOfflineRecords: false);
      conn.lastPoolCommandAt = DateTime.now();
      _ensureIdleKeepAlive();
    } catch (_) {
      // Не оставляем в пуле полуподключённый канал. Остальные UUID не трогаем.
      if (identical(_connections[info.id], conn)) {
        _connections.remove(info.id);
      }
      await conn.dataSub?.cancel();
      await conn.logSub?.cancel();
      await service.dispose();
      rethrow;
    } finally {
      _connectingAny = false;
    }
  }

  void setLivePolling(bool value) {
    _livePolling = value;
    if (!value) _ensureIdleKeepAlive();
  }

  void _ensureIdleKeepAlive() {
    if (_idleKeepAliveTimer != null || _connections.isEmpty) return;
    _idleKeepAliveTimer = Timer.periodic(
      const Duration(milliseconds: 900),
      (_) => _runIdleKeepAliveTick(),
    );
  }

  void _runIdleKeepAliveTick() {
    if (_livePolling || _connectingAny || _connections.isEmpty) return;
    final connections = _connections.values.toList(growable: false);
    if (_keepAliveCursor >= connections.length) _keepAliveCursor = 0;
    final conn = connections[_keepAliveCursor++];

    final now = DateTime.now();
    if (!conn.service.commandChannelReady) {
      final lastReconnect = conn.lastReconnectAttemptAt;
      if (lastReconnect != null &&
          now.difference(lastReconnect).inSeconds < 12) {
        return;
      }
      conn.lastReconnectAttemptAt = now;
      unawaited(_serializedCommand(() async {
        try {
          final restored = await conn.service.ensureCommandChannel();
          if (restored) {
            conn.lastPoolCommandAt = DateTime.now();
            _logs.add(TeamTrackerBleLog(
              deviceUuid: conn.info.id,
              deviceName: conn.info.name,
              line: 'Предстартовый BLE-канал восстановлен автоматически',
            ));
          }
        } catch (e) {
          _logs.add(TeamTrackerBleLog(
            deviceUuid: conn.info.id,
            deviceName: conn.info.name,
            line: 'Предстартовое восстановление BLE ожидает датчик: $e',
          ));
        }
      }));
      return;
    }

    final last = conn.lastPoolCommandAt;
    if (last != null && now.difference(last).inSeconds < 8) return;
    unawaited(_serializedCommand(() async {
      if (!conn.service.commandChannelReady) return;
      try {
        await conn.service.requestBatteryAndGpsState();
        conn.lastPoolCommandAt = DateTime.now();
      } catch (e) {
        _logs.add(TeamTrackerBleLog(
          deviceUuid: conn.info.id,
          deviceName: conn.info.name,
          line: 'Предстартовый keep-alive не прошёл: $e',
        ));
      }
    }));
  }

  Future<void> _serializedCommand(Future<void> Function() action) {
    final completer = Completer<void>();
    _commandQueue = _commandQueue.then((_) async {
      try {
        await action();
        completer.complete();
      } catch (error, stackTrace) {
        completer.completeError(error, stackTrace);
      }
    });
    return completer.future;
  }

  Future<void> ensureConnected(Iterable<ActionTrackerDevice> devices) async {
    for (final device in devices) {
      if (!isConnected(device.id)) {
        await connect(device);
      }
    }
  }

  Future<void> disconnect(String uuid) async {
    final conn = _connections.remove(uuid);
    if (conn == null) return;
    await conn.dataSub?.cancel();
    await conn.logSub?.cancel();
    await conn.service.disconnect(clearInfo: true);
    await conn.service.dispose();
    if (_connections.isEmpty) {
      _idleKeepAliveTimer?.cancel();
      _idleKeepAliveTimer = null;
      _keepAliveCursor = 0;
    }
  }

  Future<void> disconnectAll() async {
    final ids = _connections.keys.toList(growable: false);
    for (final id in ids) {
      await disconnect(id);
    }
  }

  Future<void> requestCurrentGps(String uuid) async {
    final service = serviceFor(uuid);
    if (service == null) throw StateError('GPS $uuid не подключён');
    await _serializedCommand(() async {
      final ready = await service.ensureCommandChannel();
      if (!ready) throw StateError('TX/RX GPS $uuid не готов');
      await service.requestCurrentGpsCandidate();
      _connections[uuid]?.lastPoolCommandAt = DateTime.now();
    });
  }

  Future<void> requestBattery(String uuid) async {
    final service = serviceFor(uuid);
    if (service == null) return;
    await _serializedCommand(() async {
      await service.requestBatteryAndGpsState();
      _connections[uuid]?.lastPoolCommandAt = DateTime.now();
    });
  }

  Future<void> dispose() async {
    _idleKeepAliveTimer?.cancel();
    _idleKeepAliveTimer = null;
    await disconnectAll();
    await _data.close();
    await _logs.close();
  }
}
