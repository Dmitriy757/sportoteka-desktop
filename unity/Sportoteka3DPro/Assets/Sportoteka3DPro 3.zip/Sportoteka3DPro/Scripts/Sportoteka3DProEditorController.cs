
using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.UI;
#endif

namespace Sportoteka3DPro
{
    public sealed class Sportoteka3DProEditorController : MonoBehaviour
    {
        private const string Green = "#00A750";
        private const string GreenDark = "#007A3D";
        private const string Graphite = "#111827";
        private const string Muted = "#667085";
        private const string Border = "#E5E7EB";
        private const string Red = "#F43F5E";

        private Canvas _canvas;
        private Transform _drawingRoot;
        private Transform _previewRoot;
        private Transform _selectionRoot;
        private Transform _popupRoot;

        private readonly List<Sportoteka3DProPlanItem> _items = new List<Sportoteka3DProPlanItem>();
        private readonly List<Sportoteka3DProPlayerData> _players = new List<Sportoteka3DProPlayerData>();
        private readonly List<Sportoteka3DProFrameSnapshot> _frames = new List<Sportoteka3DProFrameSnapshot>();

        private Sportoteka3DProMode _mode = Sportoteka3DProMode.Tactics;
        private Sportoteka3DProTool _tool = Sportoteka3DProTool.Select;
        private Sportoteka3DProPlayerData _selectedPlayer;

        private string _teamName = "ФК «Гомель» U13";
        private string _selectedItemId = "";
        private int _counter;
        private bool _dragging;
        private Vector3 _dragStart;
        private Color _activeColor = ParseColor(Green);
        private float _activeWidth = 0.07f;
        private float _activeAlpha = 1.0f;

        private Text _statusText;
        private Text _modeText;
        private Text _toolText;
        private Text _selectedText;
        private Slider _widthSlider;
        private Slider _alphaSlider;
        private Transform _modePanelRoot;
        private static Sprite _roundedSprite;

        private void Awake()
        {
            DontDestroyOnLoad(gameObject);
            EnsureRoots();
            LoadFlutterPayloadIfAny();
            SeedPlayers();
            BuildInterface();
            SetMode(Sportoteka3DProMode.Tactics);
            SetTool(Sportoteka3DProTool.Select);
            Debug.Log("[Sportoteka3DPro] V6_FULL_PROFESSIONAL_CMR_EDITOR active");
        }

        private void Update()
        {
            HandleShortcuts();
            HandleCameraInput();
            HandleDrawingInput();
        }

        private void EnsureRoots()
        {
            _drawingRoot = FindOrCreateRoot("Sportoteka3DProProfessionalDrawings");
            _previewRoot = FindOrCreateRoot("Sportoteka3DProProfessionalPreview");
            _selectionRoot = FindOrCreateRoot("Sportoteka3DProProfessionalSelection");
        }

        private Transform FindOrCreateRoot(string name)
        {
            var found = GameObject.Find(name);
            if (found == null) found = new GameObject(name);
            return found.transform;
        }


        private void LoadFlutterPayloadIfAny()
        {
            try
            {
                var args = System.Environment.GetCommandLineArgs();
                string path = "";

                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i] == "--sportoteka-team-json" && i + 1 < args.Length)
                    {
                        path = args[i + 1];
                        break;
                    }

                    if (args[i].StartsWith("--sportoteka-team-json="))
                    {
                        path = args[i].Substring("--sportoteka-team-json=".Length);
                        break;
                    }
                }

                if (string.IsNullOrEmpty(path) || !File.Exists(path))
                {
                    Debug.Log("[Sportoteka3DPro] Flutter payload not found, using fallback players.");
                    return;
                }

                var json = File.ReadAllText(path);
                var payload = JsonUtility.FromJson<Sportoteka3DProFlutterPayload>(json);
                if (payload == null)
                {
                    Debug.LogWarning("[Sportoteka3DPro] Flutter payload is empty.");
                    return;
                }

                if (!string.IsNullOrEmpty(payload.teamName)) _teamName = payload.teamName;

                _players.Clear();
                if (payload.players != null)
                {
                    foreach (var p in payload.players)
                    {
                        if (p == null) continue;
                        var player = new Sportoteka3DProPlayerData
                        {
                            id = p.id,
                            number = p.number,
                            name = string.IsNullOrEmpty(p.name) ? ("Игрок " + p.number) : p.name,
                            position = string.IsNullOrEmpty(p.position) ? "Игрок" : p.position,
                            role = string.IsNullOrEmpty(p.role) ? "Состав" : p.role,
                            avatarUrl = p.avatarUrl ?? "",
                            avatarPath = p.avatarPath ?? "",
                            initials = string.IsNullOrEmpty(p.initials) ? Sportoteka3DProPlayerData.MakeInitials(p.name, p.number) : p.initials,
                            teamColor = string.IsNullOrEmpty(p.teamColor) ? "#00A750" : p.teamColor
                        };
                        _players.Add(player);
                    }
                }

                Debug.Log("[Sportoteka3DPro] Flutter payload loaded: team=" + _teamName + ", players=" + _players.Count);
            }
            catch (System.Exception e)
            {
                Debug.LogWarning("[Sportoteka3DPro] Failed to load Flutter payload: " + e.Message);
            }
        }

        private void SeedPlayers()
        {
            if (_players.Count > 0) return;

            _players.Add(new Sportoteka3DProPlayerData(1, "Вратарь", "ВР"));
            _players.Add(new Sportoteka3DProPlayerData(2, "Правый защитник", "ПЗ"));
            _players.Add(new Sportoteka3DProPlayerData(3, "Левый защитник", "ЛЗ"));
            _players.Add(new Sportoteka3DProPlayerData(4, "Центральный защитник", "ЦЗ"));
            _players.Add(new Sportoteka3DProPlayerData(5, "Центральный защитник", "ЦЗ"));
            _players.Add(new Sportoteka3DProPlayerData(6, "Опорный полузащитник", "ОП"));
            _players.Add(new Sportoteka3DProPlayerData(8, "Центральный полузащитник", "ЦП"));
            _players.Add(new Sportoteka3DProPlayerData(10, "Атакующий полузащитник", "АП"));
            _players.Add(new Sportoteka3DProPlayerData(7, "Правый крайний", "ПК"));
            _players.Add(new Sportoteka3DProPlayerData(11, "Левый крайний", "ЛК"));
            _players.Add(new Sportoteka3DProPlayerData(9, "Нападающий", "НП"));
            _selectedPlayer = _players[0];
        }

        private void BuildInterface()
        {
            EnsureEventSystem();

            var canvasObj = new GameObject("Sportoteka 3D Pro V6 Full CMR Canvas");
            canvasObj.transform.SetParent(transform, false);
            _canvas = canvasObj.AddComponent<Canvas>();
            _canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            _canvas.sortingOrder = 1400;

            var scaler = canvasObj.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1440, 900);
            scaler.matchWidthOrHeight = 0.5f;

            canvasObj.AddComponent<GraphicRaycaster>();

            BuildTopBar(canvasObj.transform);
            BuildModeActionPanel(canvasObj.transform);
            BuildModeRail(canvasObj.transform);
            BuildProfessionalToolbar(canvasObj.transform);
            BuildPlayerBench(canvasObj.transform);
            BuildStylePanel(canvasObj.transform);
            BuildSelectionInspector(canvasObj.transform);
            BuildCameraPad(canvasObj.transform);
            BuildTimeline(canvasObj.transform);
            BuildStatus(canvasObj.transform);
            BuildPopupRoot(canvasObj.transform);
        }

        private void BuildTopBar(Transform parent)
        {
            var bar = Panel(parent, "Top Bar", Color.white, 0);
            Place(bar, Vector2.zero, new Vector2(0, 1), new Vector2(1, 1), new Vector2(0, 54), new Vector2(0.5f, 1));
            var border = Panel(bar.transform, "Border", ParseColor("#EEF1F4"), 0);
            Place(border, Vector2.zero, new Vector2(0, 0), new Vector2(1, 0), new Vector2(0, 1), new Vector2(0.5f, 0));

            var close = TextButton(bar.transform, "Закрыть", RequestClose, ParseColor("#FFF1F2"), ParseColor(Red), 112, 38);
            Place(close.gameObject, new Vector2(64, -8), new Vector2(0, 1), new Vector2(0, 1));

            _modeText = Text(bar.transform, "Спортотека • Редактор тактики • " + _teamName, 15, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(_modeText.gameObject, new Vector2(202, -7), new Vector2(0, 1), new Vector2(0, 1), new Vector2(580, 22));

            var sub = Text(bar.transform, "Футбол • схемы • анализ • тренировки • анимация • разбор эпизодов", 11, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(sub.gameObject, new Vector2(202, -29), new Vector2(0, 1), new Vector2(0, 1), new Vector2(620, 18));

            var save = TextButton(bar.transform, "Сохранить", SavePlan, ParseColor(Graphite), Color.white, 132, 42);
            Place(save.gameObject, new Vector2(-12, -6), new Vector2(1, 1), new Vector2(1, 1));

            var load = TextButton(bar.transform, "Открыть", LoadPlan, ParseColor("#F8FAFC"), ParseColor(Graphite), 92, 38);
            Place(load.gameObject, new Vector2(-154, -8), new Vector2(1, 1), new Vector2(1, 1));

            var top = TextButton(bar.transform, "Сверху", () => SetCameraPreset("top"), ParseColor("#F8FAFC"), ParseColor(Graphite), 92, 38);
            Place(top.gameObject, new Vector2(-254, -8), new Vector2(1, 1), new Vector2(1, 1));

            var tactical = TextButton(bar.transform, "Тактика", () => SetCameraPreset("tactical"), ParseColor("#F8FAFC"), ParseColor(Graphite), 78, 38);
            Place(tactical.gameObject, new Vector2(-354, -8), new Vector2(1, 1), new Vector2(1, 1));
            var roster = TextButton(bar.transform, "Состав", ShowPlayerPicker, ParseColor("#ECFDF5"), ParseColor(GreenDark), 88, 38);
            Place(roster.gameObject, new Vector2(-448, -8), new Vector2(1, 1), new Vector2(1, 1));

        }

        private void BuildModeActionPanel(Transform parent)
        {
            var panel = Panel(parent, "Mode Action Panel", Color.white, 18, ParseColor(Border));
            Place(panel, new Vector2(-120, -66), new Vector2(0.5f, 1), new Vector2(0.5f, 1), new Vector2(760, 88), new Vector2(0.5f, 1));
            _modePanelRoot = panel.transform;
            RefreshModeActionPanel();
        }

        private void RefreshModeActionPanel()
        {
            if (_modePanelRoot == null) return;
            ClearChildren(_modePanelRoot);

            var title = Text(_modePanelRoot, "Режим: " + ModeTitle(_mode), 13, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(title.gameObject, new Vector2(16, -10), new Vector2(0, 1), new Vector2(0, 1), new Vector2(210, 20));

            var hint = Text(_modePanelRoot, ModeHint(_mode), 10, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(hint.gameObject, new Vector2(16, -32), new Vector2(0, 1), new Vector2(0, 1), new Vector2(700, 18));

            if (_mode == Sportoteka3DProMode.Tactics)
            {
                ModeAction("4-3-3", ApplyModePreset, 16, -58);
                ModeAction("Состав", ShowPlayerPicker, 96, -58);
                ModeAction("Игрок", () => SetTool(Sportoteka3DProTool.Player), 176, -58);
                ModeAction("Пас", () => SetTool(Sportoteka3DProTool.PassArrow), 256, -58);
                ModeAction("Рывок", () => SetTool(Sportoteka3DProTool.RunArrow), 336, -58);
                ModeAction("Кривая", () => SetTool(Sportoteka3DProTool.CurveArrow), 416, -58);
                ModeAction("Зона", () => SetTool(Sportoteka3DProTool.HatchedZone), 496, -58);
                ModeAction("Соперник", () => SetTool(Sportoteka3DProTool.Opponent), 576, -58);
            }
            else if (_mode == Sportoteka3DProMode.Analysis)
            {
                ModeAction("Пакет анализа", ApplyModePreset, 16, -58, 108);
                ModeAction("Офсайд", () => SetTool(Sportoteka3DProTool.Offside), 134, -58);
                ModeAction("Связь", () => SetTool(Sportoteka3DProTool.Matchup), 214, -58);
                ModeAction("Подсветка", () => SetTool(Sportoteka3DProTool.Spotlight), 294, -58, 92);
                ModeAction("Дистанция", () => SetTool(Sportoteka3DProTool.Measurement), 396, -58, 92);
                ModeAction("Зона давления", () => SetTool(Sportoteka3DProTool.HatchedZone), 498, -58, 118);
            }
            else if (_mode == Sportoteka3DProMode.Drill)
            {
                ModeAction("Шаблон", ApplyModePreset, 16, -58);
                ModeAction("Конус", () => SetTool(Sportoteka3DProTool.Cone), 96, -58);
                ModeAction("Манекен", () => SetTool(Sportoteka3DProTool.Mannequin), 176, -58);
                ModeAction("Лестница", () => SetTool(Sportoteka3DProTool.Ladder), 266, -58);
                ModeAction("Барьер", () => SetTool(Sportoteka3DProTool.Hurdle), 356, -58);
                ModeAction("Гейт", () => SetTool(Sportoteka3DProTool.Gate), 436, -58);
                ModeAction("Ворота", () => SetTool(Sportoteka3DProTool.MiniGoal), 516, -58);
            }
            else if (_mode == Sportoteka3DProMode.Animation)
            {
                ModeAction("+ Кадр", SaveFrame, 16, -58);
                ModeAction("Пуск", PlayFrames, 96, -58);
                ModeAction("Пример", AddAnimationExample, 176, -58);
                ModeAction("Кадр 1", () => LoadFrame(1), 256, -58);
                ModeAction("Кадр 2", () => LoadFrame(2), 336, -58);
                ModeAction("Кадр 3", () => LoadFrame(3), 416, -58);
                ModeAction("Шаблон", ApplyModePreset, 496, -58);
            }
            else if (_mode == Sportoteka3DProMode.MultiSport)
            {
                ModeAction("Разметка", ApplyModePreset, 16, -58);
                ModeAction("Линия", () => SetTool(Sportoteka3DProTool.Line), 96, -58);
                ModeAction("Круг", () => SetTool(Sportoteka3DProTool.Circle), 176, -58);
                ModeAction("Зона", () => SetTool(Sportoteka3DProTool.Zone), 256, -58);
                ModeAction("Подпись", () => SetTool(Sportoteka3DProTool.Text), 336, -58);
            }
            else if (_mode == Sportoteka3DProMode.Calibration)
            {
                ModeAction("4 точки", ApplyModePreset, 16, -58);
                ModeAction("Точка", () => SetTool(Sportoteka3DProTool.CalibrationMarker), 96, -58);
                ModeAction("Дистанция", () => SetTool(Sportoteka3DProTool.Measurement), 176, -58, 92);
                ModeAction("Сверху", () => SetCameraPreset("top"), 278, -58);
            }
            else if (_mode == Sportoteka3DProMode.Branding)
            {
                ModeAction("Бренд-пак", ApplyModePreset, 16, -58, 96);
                ModeAction("Логотип", () => SetTool(Sportoteka3DProTool.TeamBadge), 122, -58);
                ModeAction("Подпись", () => SetTool(Sportoteka3DProTool.Text), 212, -58);
                ModeAction("Цвет клуба", () => SetActiveColor(Green), 302, -58, 96);
                ModeAction("Цвет сопер.", () => SetActiveColor("#2563EB"), 408, -58, 104);
            }
        }

        private string ModeHint(Sportoteka3DProMode mode)
        {
            switch (mode)
            {
                case Sportoteka3DProMode.Tactics:
                    return "Рабочая тактическая карта: расстановка, пасы, рывки, зоны и соперники.";
                case Sportoteka3DProMode.Analysis:
                    return "Разбор эпизода: офсайд, связи игроков, подсветка, дистанции и зоны давления.";
                case Sportoteka3DProMode.Drill:
                    return "План тренировки: конусы, манекены, лестницы, барьеры, ворота и маршруты.";
                case Sportoteka3DProMode.Animation:
                    return "2D/3D-анимация: сохраняй кадры, двигай игроков и запускай проигрывание.";
                case Sportoteka3DProMode.MultiSport:
                    return "Мультиспорт: универсальная разметка для футзала, баскетбола, гандбола и т.п.";
                case Sportoteka3DProMode.Calibration:
                    return "Калибровка поля: точки, дистанции, вид сверху и привязка к координатам.";
                case Sportoteka3DProMode.Branding:
                    return "Брендинг: логотипы, цвета команд, подписи и broadcast-оформление.";
                default:
                    return "";
            }
        }

        private void ModeAction(string title, UnityEngine.Events.UnityAction action, float x, float y, float width = 72)
        {
            var button = TextButton(_modePanelRoot, title, action, ParseColor("#F8FAFC"), ParseColor(Graphite), width, 24, 9);
            Place(button.gameObject, new Vector2(x, y), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void BuildModeRail(Transform parent)
        {
            var rail = Panel(parent, "Mode Rail", Color.white, 0, ParseColor("#EEF1F4"));
            Place(rail, Vector2.zero, new Vector2(0, 0), new Vector2(0, 1), new Vector2(86, 0), new Vector2(0, 0.5f));

            ModeButton(rail.transform, "Тактика", () => SetMode(Sportoteka3DProMode.Tactics), 14);
            ModeButton(rail.transform, "Анализ", () => SetMode(Sportoteka3DProMode.Analysis), 68);
            ModeButton(rail.transform, "Трен.", () => SetMode(Sportoteka3DProMode.Drill), 122);
            ModeButton(rail.transform, "Аним.", () => SetMode(Sportoteka3DProMode.Animation), 176);
            ModeButton(rail.transform, "Спорт", () => SetMode(Sportoteka3DProMode.MultiSport), 230);
            ModeButton(rail.transform, "Калибр.", () => SetMode(Sportoteka3DProMode.Calibration), 284);
            ModeButton(rail.transform, "Бренд", () => SetMode(Sportoteka3DProMode.Branding), 338);
            ModeButton(rail.transform, "C", ClearPlan, 760);
        }

        private void ModeButton(Transform parent, string title, UnityEngine.Events.UnityAction action, float y)
        {
            var btn = TextButton(parent, title, action, ParseColor("#F8FAFC"), ParseColor(Graphite), 76, 40);
            Place(btn.gameObject, new Vector2(5, -y), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void BuildProfessionalToolbar(Transform parent)
        {
            var bar = Panel(parent, "Professional Toolbar", WithAlpha(ParseColor("#080C13"), 0.92f), 18);
            Place(bar, new Vector2(-120, 70), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(940, 74), new Vector2(0.5f, 0));

            ToolbarButton(bar.transform, "↖", "Выбор", () => SetTool(Sportoteka3DProTool.Select), 14);
            ToolbarButton(bar.transform, "●", "Игрок", () => SetTool(Sportoteka3DProTool.Player), 78);
            ToolbarButton(bar.transform, "○", "Сопер.", () => SetTool(Sportoteka3DProTool.Opponent), 142);
            ToolbarButton(bar.transform, "→", "Пас", () => SetTool(Sportoteka3DProTool.PassArrow), 206);
            ToolbarButton(bar.transform, "≋", "Рывок", () => SetTool(Sportoteka3DProTool.RunArrow), 270);
            ToolbarButton(bar.transform, "⌒", "Кривая", () => SetTool(Sportoteka3DProTool.CurveArrow), 334);
            ToolbarButton(bar.transform, "—", "Линия", () => SetTool(Sportoteka3DProTool.Line), 398);
            ToolbarButton(bar.transform, "▧", "Зона", () => SetTool(Sportoteka3DProTool.HatchedZone), 462);
            ToolbarButton(bar.transform, "◉", "Фокус", () => SetTool(Sportoteka3DProTool.Spotlight), 526);
            ToolbarButton(bar.transform, "↔", "Связь", () => SetTool(Sportoteka3DProTool.Matchup), 590);
            ToolbarButton(bar.transform, "OFF", "Офсайд", () => SetTool(Sportoteka3DProTool.Offside), 654);
            ToolbarButton(bar.transform, "m", "Дистан.", () => SetTool(Sportoteka3DProTool.Measurement), 718);
            ToolbarButton(bar.transform, "▲", "Конус", () => SetTool(Sportoteka3DProTool.Cone), 782);
            ToolbarButton(bar.transform, "▱", "Ворота", () => SetTool(Sportoteka3DProTool.MiniGoal), 846);
            ToolbarButton(bar.transform, "▶", "Анимац.", AddAnimationExample, 910);
        }

        private void ToolbarButton(Transform parent, string icon, string title, UnityEngine.Events.UnityAction action, float x)
        {
            var b = TextButton(parent, icon, action, ParseColor("#111827"), Color.white, 46, 42, 14);
            Place(b.gameObject, new Vector2(x, -8), new Vector2(0, 1), new Vector2(0, 1));
            var t = Text(parent, title, 8, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter);
            Place(t.gameObject, new Vector2(x - 4, -52), new Vector2(0, 1), new Vector2(0, 1), new Vector2(54, 12));
        }

        private void BuildPlayerBench(Transform parent)
        {
            var strip = Panel(parent, "Player Bench", WithAlpha(ParseColor("#080C13"), 0.78f), 18);
            Place(strip, new Vector2(-120, 148), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(780, 56), new Vector2(0.5f, 0));

            int max = Mathf.Min(10, _players.Count);
            for (int i = 0; i < max; i++)
            {
                var player = _players[i];
                var btn = TextButton(strip.transform, player.initials, () => SelectPlayer(player), player == _selectedPlayer ? ParseColor(GreenDark) : ParseColor("#111827"), Color.white, 58, 40);
                Place(btn.gameObject, new Vector2(12 + i * 70, -8), new Vector2(0, 1), new Vector2(0, 1));
            }
        }

        private void BuildStylePanel(Transform parent)
        {
            var panel = Panel(parent, "Style Panel", Color.white, 16, ParseColor(Border));
            Place(panel, new Vector2(-20, -74), new Vector2(1, 1), new Vector2(1, 1), new Vector2(240, 122), new Vector2(1, 1));

            var title = Text(panel.transform, "Цвет / толщина / прозрачность", 12, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(title.gameObject, new Vector2(12, -8), new Vector2(0, 1), new Vector2(0, 1), new Vector2(160, 18));

            string[] colors = { Green, "#FDE047", "#38BDF8", "#F97316", "#F43F5E", "#FFFFFF", "#111827" };
            for (int i = 0; i < colors.Length; i++)
            {
                ColorDot(panel.transform, colors[i], 12 + i * 30, -34);
            }

            _widthSlider = Slider(panel.transform, "Толщина", 0.035f, 0.30f, _activeWidth, SetLineWidth);
            Place(_widthSlider.gameObject, new Vector2(12, -68), new Vector2(0, 1), new Vector2(0, 1), new Vector2(205, 20));

            _alphaSlider = Slider(panel.transform, "Прозрачность", 0.10f, 1.0f, _activeAlpha, SetAlpha);
            Place(_alphaSlider.gameObject, new Vector2(12, -94), new Vector2(0, 1), new Vector2(0, 1), new Vector2(205, 20));
        }

        private void BuildSelectionInspector(Transform parent)
        {
            var panel = Panel(parent, "Object Inspector", Color.white, 16, ParseColor(Border));
            Place(panel, new Vector2(-20, -210), new Vector2(1, 1), new Vector2(1, 1), new Vector2(240, 138), new Vector2(1, 1));

            _selectedText = Text(panel.transform, "Редактирование объекта", 12, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(_selectedText.gameObject, new Vector2(12, -8), new Vector2(0, 1), new Vector2(0, 1), new Vector2(205, 18));

            var del = TextButton(panel.transform, "Удалить", DeleteSelected, ParseColor("#FFF1F2"), ParseColor(Red), 70, 26, 10);
            Place(del.gameObject, new Vector2(12, -38), new Vector2(0, 1), new Vector2(0, 1));
            var copy = TextButton(panel.transform, "Копия", DuplicateSelected, ParseColor("#F8FAFC"), ParseColor(Graphite), 58, 26, 10);
            Place(copy.gameObject, new Vector2(88, -38), new Vector2(0, 1), new Vector2(0, 1));
            var plus = TextButton(panel.transform, "+", () => ScaleSelected(1.12f), ParseColor("#F8FAFC"), ParseColor(Graphite), 32, 26, 12);
            Place(plus.gameObject, new Vector2(152, -38), new Vector2(0, 1), new Vector2(0, 1));
            var minus = TextButton(panel.transform, "−", () => ScaleSelected(0.90f), ParseColor("#F8FAFC"), ParseColor(Graphite), 32, 26, 12);
            Place(minus.gameObject, new Vector2(190, -38), new Vector2(0, 1), new Vector2(0, 1));

            var rl = TextButton(panel.transform, "⟲", () => RotateSelected(-10), ParseColor("#F8FAFC"), ParseColor(Graphite), 44, 26, 12);
            Place(rl.gameObject, new Vector2(12, -72), new Vector2(0, 1), new Vector2(0, 1));
            var rr = TextButton(panel.transform, "⟳", () => RotateSelected(10), ParseColor("#F8FAFC"), ParseColor(Graphite), 44, 26, 12);
            Place(rr.gameObject, new Vector2(62, -72), new Vector2(0, 1), new Vector2(0, 1));
            var front = TextButton(panel.transform, "Поверх", BringSelectedToFront, ParseColor("#F8FAFC"), ParseColor(Graphite), 66, 26, 10);
            Place(front.gameObject, new Vector2(112, -72), new Vector2(0, 1), new Vector2(0, 1));
            var reset = TextButton(panel.transform, "Сброс", ResetSelected, ParseColor("#F8FAFC"), ParseColor(Graphite), 54, 26, 10);
            Place(reset.gameObject, new Vector2(184, -72), new Vector2(0, 1), new Vector2(0, 1));

            var apply = TextButton(panel.transform, "Применить стиль к объекту", ApplyStyleToSelected, ParseColor("#ECFDF5"), ParseColor(GreenDark), 210, 26, 10);
            Place(apply.gameObject, new Vector2(12, -104), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void BuildHelpPanel(Transform parent)
        {
            var panel = Panel(parent, "Help Panel", Color.white, 16, ParseColor(Border));
            Place(panel, new Vector2(-20, -360), new Vector2(1, 1), new Vector2(1, 1), new Vector2(240, 128), new Vector2(1, 1));

            var title = Text(panel.transform, "Как работать", 12, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(title.gameObject, new Vector2(12, -8), new Vector2(0, 1), new Vector2(0, 1), new Vector2(205, 18));

            var t1 = Text(panel.transform, "1. Режим слева: Тактика / Анализ / Тренировка", 9, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(t1.gameObject, new Vector2(12, -34), new Vector2(0, 1), new Vector2(0, 1), new Vector2(214, 16));

            var t2 = Text(panel.transform, "2. Инструмент снизу: Пас, Зона, Игрок...", 9, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(t2.gameObject, new Vector2(12, -54), new Vector2(0, 1), new Vector2(0, 1), new Vector2(214, 16));

            var t3 = Text(panel.transform, "3. ЛКМ по полю — рисовать / поставить", 9, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(t3.gameObject, new Vector2(12, -74), new Vector2(0, 1), new Vector2(0, 1), new Vector2(214, 16));

            var t4 = Text(panel.transform, "4. Выбор → клик по объекту → удалить/изменить", 9, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(t4.gameObject, new Vector2(12, -94), new Vector2(0, 1), new Vector2(0, 1), new Vector2(214, 16));
        }

        private void BuildCameraPad(Transform parent)
        {
            var panel = Panel(parent, "Camera Pad", Color.white, 16, ParseColor(Border));
            Place(panel, new Vector2(-270, 16), new Vector2(1, 0), new Vector2(1, 0), new Vector2(214, 128), new Vector2(1, 0));
            var title = Text(panel.transform, "Камера", 11, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(title.gameObject, new Vector2(12, -8), new Vector2(0, 1), new Vector2(0, 1), new Vector2(90, 16));
            Analog(panel.transform, "↑", () => PanCamera(0, 3), 68, -32);
            Analog(panel.transform, "←", () => RotateCamera(-10), 30, -66);
            Analog(panel.transform, "●", () => SetCameraPreset("tactical"), 68, -66);
            Analog(panel.transform, "→", () => RotateCamera(10), 106, -66);
            Analog(panel.transform, "↓", () => PanCamera(0, -3), 68, -100);
            Analog(panel.transform, "+", () => ZoomCamera(-6), 158, -38);
            Analog(panel.transform, "−", () => ZoomCamera(6), 158, -78);
        }

        private void BuildTimeline(Transform parent)
        {
            var panel = Panel(parent, "Timeline", WithAlpha(ParseColor("#080C13"), 0.76f), 16);
            Place(panel, new Vector2(-120, 218), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(610, 42), new Vector2(0.5f, 0));
            var save = TextButton(panel.transform, "+ Кадр", SaveFrame, ParseColor("#111827"), Color.white, 62, 28, 10);
            Place(save.gameObject, new Vector2(12, -7), new Vector2(0, 1), new Vector2(0, 1));
            var play = TextButton(panel.transform, "Пуск", PlayFrames, ParseColor("#111827"), Color.white, 56, 28, 10);
            Place(play.gameObject, new Vector2(80, -7), new Vector2(0, 1), new Vector2(0, 1));
            for (int i = 1; i <= 5; i++)
            {
                int frame = i;
                var b = TextButton(panel.transform, frame.ToString(), () => LoadFrame(frame), ParseColor("#111827"), Color.white, 32, 28, 10);
                Place(b.gameObject, new Vector2(150 + (i - 1) * 38, -7), new Vector2(0, 1), new Vector2(0, 1));
            }
            var preset = TextButton(panel.transform, "Шаблон режима", ApplyModePreset, ParseColor("#111827"), Color.white, 110, 28, 10);
            Place(preset.gameObject, new Vector2(360, -7), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void BuildStatus(Transform parent)
        {
            var panel = Panel(parent, "Status", WithAlpha(ParseColor("#080C13"), 0.72f), 14);
            Place(panel, new Vector2(-120, 16), new Vector2(0.5f, 0), new Vector2(0.5f, 0), new Vector2(800, 36), new Vector2(0.5f, 0));
            _statusText = Text(panel.transform, "Готово: выбери режим слева, инструмент снизу, затем ЛКМ по полю", 11, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter);
            Place(_statusText.gameObject, Vector2.zero, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(760, 24));
            _toolText = _statusText;
        }


        private void BuildPopupRoot(Transform parent)
        {
            var root = new GameObject("Sportoteka V6 Popup Root");
            root.transform.SetParent(parent, false);
            var rect = root.AddComponent<RectTransform>();
            rect.anchorMin = Vector2.zero;
            rect.anchorMax = Vector2.one;
            rect.offsetMin = Vector2.zero;
            rect.offsetMax = Vector2.zero;
            _popupRoot = root.transform;
        }

        private void ShowPlayerPicker()
        {
            if (_popupRoot == null) return;
            ClearChildren(_popupRoot);

            var shade = Panel(_popupRoot, "Затемнение", new Color(0f, 0f, 0f, 0.22f), 0);
            Place(shade, Vector2.zero, Vector2.zero, Vector2.one, Vector2.zero, new Vector2(0.5f, 0.5f), true);

            var card = Panel(_popupRoot, "Выбор состава", Color.white, 24, ParseColor(Border));
            Place(card, new Vector2(0, 0), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(650, 530), new Vector2(0.5f, 0.5f));

            var title = Text(card.transform, "Выбор игрока", 20, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(title.gameObject, new Vector2(28, -22), new Vector2(0, 1), new Vector2(0, 1), new Vector2(300, 30));

            var subtitle = Text(card.transform, "Выбери игрока — затем кликни по полю, чтобы поставить его на карту.", 11, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(subtitle.gameObject, new Vector2(28, -56), new Vector2(0, 1), new Vector2(0, 1), new Vector2(560, 20));

            var close = TextButton(card.transform, "×", HidePopup, ParseColor("#FFF1F2"), ParseColor(Red), 40, 34, 14);
            Place(close.gameObject, new Vector2(-24, -22), new Vector2(1, 1), new Vector2(1, 1));

            PlayerFilterButton(card.transform, "Все", 28, -92);
            PlayerFilterButton(card.transform, "Защита", 100, -92);
            PlayerFilterButton(card.transform, "Полузащита", 196, -92, 116);
            PlayerFilterButton(card.transform, "Атака", 322, -92);
            PlayerFilterButton(card.transform, "Вратари", 406, -92, 86);

            int max = Mathf.Min(_players.Count, 12);
            for (int i = 0; i < max; i++)
            {
                float x = 28 + (i % 2) * 296;
                float y = -136 - (i / 2) * 62;
                BuildPlayerPopupCard(card.transform, _players[i], x, y);
            }
        }

        private void PlayerFilterButton(Transform parent, string title, float x, float y, float width = 66)
        {
            var button = TextButton(parent, title, () => SetStatus("Фильтр: " + title + ". Сейчас показан общий состав."), ParseColor("#F8FAFC"), ParseColor(Graphite), width, 28, 10);
            Place(button.gameObject, new Vector2(x, y), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void BuildPlayerPopupCard(Transform parent, Sportoteka3DProPlayerData player, float x, float y)
        {
            var bg = player == _selectedPlayer ? ParseColor("#ECFDF5") : Color.white;
            var border = player == _selectedPlayer ? ParseColor(Green) : ParseColor(Border);
            var card = Panel(parent, "Игрок " + player.number, bg, 16, border);
            Place(card, new Vector2(x, y), new Vector2(0, 1), new Vector2(0, 1), new Vector2(278, 52));

            var button = card.AddComponent<Button>();
            button.targetGraphic = card.GetComponent<Image>();
            button.onClick.AddListener(() => { SelectPlayer(player); HidePopup(); });

            var avatar = Panel(card.transform, "Аватар", ParseColor("#F8FAFC"), 14, ParseColor(Border));
            Place(avatar, new Vector2(12, -9), new Vector2(0, 1), new Vector2(0, 1), new Vector2(34, 34));
            var num = Text(avatar.transform, player.number.ToString(), 11, FontStyle.Bold, ParseColor(GreenDark), TextAnchor.MiddleCenter);
            Place(num.gameObject, Vector2.zero, new Vector2(0, 0), new Vector2(1, 1), Vector2.zero, new Vector2(0.5f, 0.5f), true);

            var name = Text(card.transform, player.name, 12, FontStyle.Bold, ParseColor(Graphite), TextAnchor.MiddleLeft);
            Place(name.gameObject, new Vector2(58, -8), new Vector2(0, 1), new Vector2(0, 1), new Vector2(180, 18));

            var role = Text(card.transform, "№" + player.number + " • " + player.position, 9, FontStyle.Bold, ParseColor(Muted), TextAnchor.MiddleLeft);
            Place(role.gameObject, new Vector2(58, -29), new Vector2(0, 1), new Vector2(0, 1), new Vector2(190, 16));

            var mark = Text(card.transform, player == _selectedPlayer ? "✓" : "+", 16, FontStyle.Bold, player == _selectedPlayer ? ParseColor(Green) : ParseColor(Muted), TextAnchor.MiddleCenter);
            Place(mark.gameObject, new Vector2(-24, -15), new Vector2(1, 1), new Vector2(1, 1), new Vector2(24, 24));
        }

        private void HidePopup()
        {
            if (_popupRoot == null) return;
            ClearChildren(_popupRoot);
        }

        private void HandleShortcuts()
        {
            if (KeyDown("escape")) { if (_popupRoot != null && _popupRoot.childCount > 0) HidePopup(); else RequestClose(); }
            if (KeyDown("delete") || KeyDown("backspace")) DeleteSelected();
            if (KeyDown("plus")) ScaleSelected(1.12f);
            if (KeyDown("minus")) ScaleSelected(0.90f);
            if (KeyDown("leftBracket")) RotateSelected(-10);
            if (KeyDown("rightBracket")) RotateSelected(10);
            if (KeyDown("c")) ClearPlan();
            if (KeyDown("s")) SavePlan();
        }

        private void HandleDrawingInput()
        {
            if (IsPointerOverUI()) return;

            if (_tool == Sportoteka3DProTool.Select)
            {
                if (PointerDown()) TrySelect();
                return;
            }

            Vector3 hit;
            if (PointerDown())
            {
                if (!TryFieldPoint(PointerPosition(), out hit)) return;
                _dragStart = Snap(hit);

                if (IsPointTool(_tool))
                {
                    AddPointItem(_dragStart);
                    return;
                }

                _dragging = true;
                DrawPreview(_dragStart, _dragStart);
            }
            else if (_dragging && PointerHeld())
            {
                if (!TryFieldPoint(PointerPosition(), out hit)) return;
                DrawPreview(_dragStart, Snap(hit));
            }
            else if (_dragging && PointerUp())
            {
                if (!TryFieldPoint(PointerPosition(), out hit)) return;
                CommitDrag(_dragStart, Snap(hit));
                ClearChildren(_previewRoot);
                _dragging = false;
            }
        }

        private void HandleCameraInput()
        {
#if ENABLE_INPUT_SYSTEM
            var mouse = Mouse.current;
            if (mouse == null || IsPointerOverUI()) return;
            var delta = mouse.delta.ReadValue();
            if (mouse.rightButton.isPressed && delta.sqrMagnitude > 0.01f) RotateCamera(delta.x * 0.18f);
            if (mouse.middleButton.isPressed && delta.sqrMagnitude > 0.01f) PanCamera(-delta.x * 0.025f, -delta.y * 0.025f);
            float scroll = mouse.scroll.ReadValue().y;
            if (Mathf.Abs(scroll) > 0.01f) ZoomCamera(-scroll * 0.035f);
#else
            if (IsPointerOverUI()) return;
            if (Input.GetMouseButton(1)) RotateCamera(Input.GetAxis("Mouse X") * 2.2f);
            if (Input.GetMouseButton(2)) PanCamera(-Input.GetAxis("Mouse X") * 1.3f, -Input.GetAxis("Mouse Y") * 1.3f);
            float wheel = Input.mouseScrollDelta.y;
            if (Mathf.Abs(wheel) > 0.01f) ZoomCamera(-wheel * 2.5f);
#endif
        }

        private bool IsPointTool(Sportoteka3DProTool tool)
        {
            return tool == Sportoteka3DProTool.Player || tool == Sportoteka3DProTool.Opponent || tool == Sportoteka3DProTool.Text ||
                   tool == Sportoteka3DProTool.Cone || tool == Sportoteka3DProTool.Ball || tool == Sportoteka3DProTool.MiniGoal ||
                   tool == Sportoteka3DProTool.BigGoal || tool == Sportoteka3DProTool.Mannequin || tool == Sportoteka3DProTool.Ladder ||
                   tool == Sportoteka3DProTool.Hurdle || tool == Sportoteka3DProTool.Gate || tool == Sportoteka3DProTool.Pole ||
                   tool == Sportoteka3DProTool.Spotlight || tool == Sportoteka3DProTool.TeamBadge || tool == Sportoteka3DProTool.CalibrationMarker;
        }

        private void AddPointItem(Vector3 p)
        {
            var item = NewItem(ToolToType(_tool));
            item.x = p.x;
            item.z = p.z;

            if (_tool == Sportoteka3DProTool.Player || _tool == Sportoteka3DProTool.Opponent)
            {
                var player = _selectedPlayer ?? _players[0];
                item.number = player.number;
                item.name = player.name;
                item.position = player.position;
                item.initials = player.initials;
                item.avatarUrl = player.avatarUrl;
                item.avatarPath = player.avatarPath;
                item.color = _tool == Sportoteka3DProTool.Opponent ? "#EF4444" : Green;
            }
            else if (_tool == Sportoteka3DProTool.Text)
            {
                item.text = _selectedPlayer != null ? ("№" + _selectedPlayer.number + " " + _selectedPlayer.position) : "TEXT";
                item.color = ColorToHex(_activeColor);
            }
            else
            {
                item.color = DefaultColorForTool(_tool);
            }

            AddItem(item, true);
        }

        private void CommitDrag(Vector3 a, Vector3 b)
        {
            if ((a - b).sqrMagnitude < 0.12f) return;

            var item = NewItem(ToolToType(_tool));
            item.x = a.x;
            item.z = a.z;
            item.toX = b.x;
            item.toZ = b.z;
            item.controlX = (a.x + b.x) * 0.5f;
            item.controlZ = (a.z + b.z) * 0.5f + Mathf.Clamp(Vector3.Distance(a, b) * 0.22f, 2f, 9f);
            item.color = ColorToHex(_activeColor);
            item.width = _activeWidth;
            item.alpha = _activeAlpha;

            AddItem(item, true);
        }

        private Sportoteka3DProPlanItem NewItem(string type)
        {
            return new Sportoteka3DProPlanItem
            {
                id = "item_" + (++_counter),
                type = type,
                width = _activeWidth,
                alpha = _activeAlpha,
                scale = 1.0f,
                rotation = 0.0f,
                color = ColorToHex(_activeColor)
            };
        }

        private void AddItem(Sportoteka3DProPlanItem item, bool select)
        {
            _items.Add(item);
            CreateItem(item, _drawingRoot, false);
            if (select) SelectItem(item.id);
            MarkDirty("Добавлен объект: " + item.type);
        }

        private void DrawPreview(Vector3 a, Vector3 b)
        {
            ClearChildren(_previewRoot);
            var item = NewItem(ToolToType(_tool));
            item.x = a.x;
            item.z = a.z;
            item.toX = b.x;
            item.toZ = b.z;
            item.controlX = (a.x + b.x) * 0.5f;
            item.controlZ = (a.z + b.z) * 0.5f + 5f;
            item.color = ColorToHex(_activeColor);
            item.width = _activeWidth;
            item.alpha = _activeAlpha;
            CreateItem(item, _previewRoot, true);
        }

        private void CreateItem(Sportoteka3DProPlanItem item, Transform parent, bool preview)
        {
            Texture2D avatar = FindAvatar(item.number);
            Sportoteka3DProDrawingFactory.Create(item, parent, avatar, preview);
        }

        private Texture2D FindAvatar(int number)
        {
            foreach (var p in _players)
            {
                if (p.number == number) return p.avatarTexture;
            }
            return null;
        }

        private string ToolToType(Sportoteka3DProTool tool)
        {
            switch (tool)
            {
                case Sportoteka3DProTool.Player: return "player";
                case Sportoteka3DProTool.Opponent: return "opponent";
                case Sportoteka3DProTool.PassArrow: return "pass";
                case Sportoteka3DProTool.RunArrow: return "run";
                case Sportoteka3DProTool.CurveArrow: return "curve";
                case Sportoteka3DProTool.Line: return "line";
                case Sportoteka3DProTool.DashedLine: return "dashed";
                case Sportoteka3DProTool.Zone: return "zone";
                case Sportoteka3DProTool.HatchedZone: return "hatched_zone";
                case Sportoteka3DProTool.Circle: return "circle";
                case Sportoteka3DProTool.Text: return "text";
                case Sportoteka3DProTool.Cone: return "cone";
                case Sportoteka3DProTool.Ball: return "ball";
                case Sportoteka3DProTool.MiniGoal: return "mini_goal";
                case Sportoteka3DProTool.BigGoal: return "big_goal";
                case Sportoteka3DProTool.Mannequin: return "mannequin";
                case Sportoteka3DProTool.Ladder: return "ladder";
                case Sportoteka3DProTool.Hurdle: return "hurdle";
                case Sportoteka3DProTool.Gate: return "gate";
                case Sportoteka3DProTool.Pole: return "pole";
                case Sportoteka3DProTool.Spotlight: return "spotlight";
                case Sportoteka3DProTool.Matchup: return "matchup";
                case Sportoteka3DProTool.Offside: return "offside";
                case Sportoteka3DProTool.Measurement: return "measurement";
                case Sportoteka3DProTool.TeamBadge: return "team_badge";
                case Sportoteka3DProTool.CalibrationMarker: return "calibration";
            }
            return "line";
        }

        private string DefaultColorForTool(Sportoteka3DProTool tool)
        {
            if (tool == Sportoteka3DProTool.Cone || tool == Sportoteka3DProTool.Ladder || tool == Sportoteka3DProTool.Gate) return "#F97316";
            if (tool == Sportoteka3DProTool.Mannequin) return "#F59E0B";
            if (tool == Sportoteka3DProTool.Hurdle || tool == Sportoteka3DProTool.Offside) return "#F43F5E";
            if (tool == Sportoteka3DProTool.Ball || tool == Sportoteka3DProTool.MiniGoal || tool == Sportoteka3DProTool.BigGoal) return "#FFFFFF";
            if (tool == Sportoteka3DProTool.CalibrationMarker || tool == Sportoteka3DProTool.Measurement) return "#38BDF8";
            return ColorToHex(_activeColor);
        }

        private void TrySelect()
        {
            var cam = Camera.main;
            if (cam == null) return;

            Ray ray = cam.ScreenPointToRay(PointerPosition());
            RaycastHit hit;
            if (!Physics.Raycast(ray, out hit, 800f))
            {
                SelectItem("");
                return;
            }

            Transform t = hit.collider.transform;
            while (t != null)
            {
                if (t.name.StartsWith("PLAN_"))
                {
                    string[] parts = t.name.Split('_');
                    if (parts.Length >= 3)
                    {
                        SelectItem(parts[1] + "_" + parts[2]);
                        return;
                    }
                }

                t = t.parent;
            }

            SelectItem("");
        }

        private void SelectItem(string id)
        {
            _selectedItemId = id;
            ClearChildren(_selectionRoot);

            var item = FindItem(id);
            if (item == null)
            {
                if (_selectedText != null) _selectedText.text = "Редактирование объекта";
                return;
            }

            if (_selectedText != null) _selectedText.text = "Выбран: " + item.type;
            Sportoteka3DProDrawingFactory.Create(new Sportoteka3DProPlanItem
            {
                id = "selection",
                type = "circle",
                x = Sportoteka3DProDrawingFactory.Center(item).x,
                z = Sportoteka3DProDrawingFactory.Center(item).z,
                toX = Sportoteka3DProDrawingFactory.Center(item).x + Sportoteka3DProDrawingFactory.Radius(item),
                toZ = Sportoteka3DProDrawingFactory.Center(item).z,
                color = "#FDE047",
                width = 0.055f
            }, _selectionRoot, null, false);
        }

        private Sportoteka3DProPlanItem FindItem(string id)
        {
            if (string.IsNullOrEmpty(id)) return null;
            foreach (var item in _items)
            {
                if (item.id == id) return item;
            }
            return null;
        }

        private void DeleteSelected()
        {
            var item = FindItem(_selectedItemId);
            if (item == null) { SetStatus("Сначала выбери объект."); return; }
            _items.Remove(item);
            _selectedItemId = "";
            Rebuild();
            MarkDirty("Объект удалён");
        }

        private void DuplicateSelected()
        {
            var item = FindItem(_selectedItemId);
            if (item == null) { SetStatus("Сначала выбери объект."); return; }
            var copy = item.Clone();
            copy.id = "item_" + (++_counter);
            copy.x += 2f;
            copy.z += 2f;
            copy.toX += 2f;
            copy.toZ += 2f;
            _items.Add(copy);
            Rebuild();
            SelectItem(copy.id);
            MarkDirty("Копия создана");
        }

        private void ScaleSelected(float factor)
        {
            var item = FindItem(_selectedItemId);
            if (item == null) { SetStatus("Сначала выбери объект."); return; }

            if (Sportoteka3DProDrawingFactory.IsPointType(item.type))
            {
                item.scale = Mathf.Clamp(item.scale * factor, 0.35f, 4f);
            }
            else
            {
                Vector3 c = Sportoteka3DProDrawingFactory.Center(item);
                Vector3 a = new Vector3(item.x, 0, item.z);
                Vector3 b = new Vector3(item.toX, 0, item.toZ);
                a = c + (a - c) * factor;
                b = c + (b - c) * factor;
                item.x = a.x; item.z = a.z; item.toX = b.x; item.toZ = b.z;
                item.width = Mathf.Clamp(item.width * Mathf.Lerp(1f, factor, 0.35f), 0.035f, 0.45f);
            }

            Rebuild();
            SelectItem(item.id);
            MarkDirty("Размер изменён");
        }

        private void RotateSelected(float degrees)
        {
            var item = FindItem(_selectedItemId);
            if (item == null) { SetStatus("Сначала выбери объект."); return; }

            if (Sportoteka3DProDrawingFactory.IsPointType(item.type))
            {
                item.rotation += degrees;
            }
            else
            {
                Vector3 c = Sportoteka3DProDrawingFactory.Center(item);
                Vector3 a = Rotate(new Vector3(item.x, 0, item.z), c, degrees);
                Vector3 b = Rotate(new Vector3(item.toX, 0, item.toZ), c, degrees);
                item.x = a.x; item.z = a.z; item.toX = b.x; item.toZ = b.z;
            }

            Rebuild();
            SelectItem(item.id);
            MarkDirty("Объект повернут");
        }

        private Vector3 Rotate(Vector3 p, Vector3 center, float degrees)
        {
            return center + Quaternion.Euler(0, degrees, 0) * (p - center);
        }

        private void BringSelectedToFront()
        {
            var item = FindItem(_selectedItemId);
            if (item == null) return;
            _items.Remove(item);
            _items.Add(item);
            Rebuild();
            SelectItem(item.id);
            MarkDirty("Объект поднят выше");
        }

        private void ResetSelected()
        {
            var item = FindItem(_selectedItemId);
            if (item == null) return;
            item.scale = 1;
            item.rotation = 0;
            item.width = 0.07f;
            Rebuild();
            SelectItem(item.id);
            MarkDirty("Сброс объекта");
        }

        private void ApplyStyleToSelected()
        {
            var item = FindItem(_selectedItemId);
            if (item == null) return;
            item.color = ColorToHex(_activeColor);
            item.width = _activeWidth;
            item.alpha = _activeAlpha;
            Rebuild();
            SelectItem(item.id);
            MarkDirty("Стиль применён");
        }

        private void Rebuild()
        {
            ClearChildren(_drawingRoot);
            ClearChildren(_selectionRoot);
            foreach (var item in _items) CreateItem(item, _drawingRoot, false);
        }

        private void ClearPlan()
        {
            _items.Clear();
            _selectedItemId = "";
            Rebuild();
            MarkDirty("План очищен");
        }

        private void ApplyModePreset()
        {
            List<Sportoteka3DProPlanItem> preset = null;
            if (_mode == Sportoteka3DProMode.Tactics) preset = Sportoteka3DProPresets.Formation433();
            else if (_mode == Sportoteka3DProMode.Analysis) preset = Sportoteka3DProPresets.AnalysisPack();
            else if (_mode == Sportoteka3DProMode.Drill) preset = Sportoteka3DProPresets.DrillPack();
            else if (_mode == Sportoteka3DProMode.MultiSport) preset = Sportoteka3DProPresets.MultiSportPack();
            else if (_mode == Sportoteka3DProMode.Calibration) preset = Sportoteka3DProPresets.CalibrationPack();
            else if (_mode == Sportoteka3DProMode.Branding) preset = Sportoteka3DProPresets.BrandingPack(_teamName);
            else if (_mode == Sportoteka3DProMode.Animation) { AddAnimationExample(); return; }

            if (preset == null) return;
            foreach (var item in preset)
            {
                item.id = "item_" + (++_counter);
                _items.Add(item);
            }
            Rebuild();
            MarkDirty("Добавлен пресет режима: " + _mode);
        }

        private void AddAnimationExample()
        {
            var list = Sportoteka3DProPresets.Formation433();
            foreach (var item in list)
            {
                item.id = "item_" + (++_counter);
                _items.Add(item);
            }
            Rebuild();
            StartCoroutine(PlayBallAnimation());
            MarkDirty("Анимационный пример запущен");
        }

        private System.Collections.IEnumerator PlayBallAnimation()
        {
            var ball = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            ball.name = "AnimationExampleBall";
            ball.transform.SetParent(_drawingRoot, false);
            ball.transform.localScale = new Vector3(0.52f, 0.52f, 0.52f);
            Vector3 a = new Vector3(0, 0.42f, 4);
            Vector3 b = new Vector3(12, 0.42f, -8);
            Vector3 c = new Vector3(0, 0.42f, -28);
            ball.transform.position = a;
            float d = 1.2f;
            float t = 0;
            while (t < d)
            {
                t += Time.deltaTime;
                ball.transform.position = Vector3.Lerp(a, b, Mathf.Clamp01(t / d));
                yield return null;
            }
            t = 0;
            while (t < d)
            {
                t += Time.deltaTime;
                ball.transform.position = Vector3.Lerp(b, c, Mathf.Clamp01(t / d));
                yield return null;
            }
            Destroy(ball, 1.0f);
        }

        private void SaveFrame()
        {
            var snapshot = new Sportoteka3DProFrameSnapshot
            {
                frameIndex = _frames.Count + 1,
                items = CloneItems().ToArray()
            };
            _frames.Add(snapshot);
            SetStatus("Кадр сохранён: " + snapshot.frameIndex);
        }

        private void LoadFrame(int frame)
        {
            foreach (var f in _frames)
            {
                if (f.frameIndex == frame)
                {
                    _items.Clear();
                    foreach (var item in f.items) _items.Add(item.Clone());
                    Rebuild();
                    SetStatus("Кадр загружен: " + frame);
                    return;
                }
            }
            SetStatus("Кадр " + frame + " ещё не сохранён.");
        }

        private void PlayFrames()
        {
            if (_frames.Count == 0) { SetStatus("Нет кадров для проигрывания."); return; }
            StartCoroutine(PlayFrameRoutine());
        }

        private System.Collections.IEnumerator PlayFrameRoutine()
        {
            foreach (var f in _frames)
            {
                _items.Clear();
                foreach (var item in f.items) _items.Add(item.Clone());
                Rebuild();
                SetStatus("Кадр: " + f.frameIndex);
                yield return new WaitForSeconds(0.7f);
            }
        }

        private List<Sportoteka3DProPlanItem> CloneItems()
        {
            var list = new List<Sportoteka3DProPlanItem>();
            foreach (var item in _items) list.Add(item.Clone());
            return list;
        }

        private void SavePlan()
        {
            Sportoteka3DProPlanStorage.Save(_teamName, _items);
            SetStatus("План сохранён");
        }

        private void LoadPlan()
        {
            var snapshot = Sportoteka3DProPlanStorage.Load();
            if (snapshot == null || snapshot.items == null) { SetStatus("Сохранённый план не найден."); return; }
            _items.Clear();
            foreach (var item in snapshot.items) _items.Add(item.Clone());
            Rebuild();
            SetStatus("План загружен");
        }

        private void RequestClose()
        {
            SavePlan();
#if UNITY_EDITOR
            UnityEditor.EditorApplication.isPlaying = false;
#else
            Application.Quit();
#endif
        }

        private string ModeTitle(Sportoteka3DProMode mode)
        {
            switch (mode)
            {
                case Sportoteka3DProMode.Tactics: return "Тактика";
                case Sportoteka3DProMode.Analysis: return "Анализ";
                case Sportoteka3DProMode.Drill: return "Тренировка";
                case Sportoteka3DProMode.Animation: return "Анимация";
                case Sportoteka3DProMode.MultiSport: return "Мультиспорт";
                case Sportoteka3DProMode.Calibration: return "Калибровка";
                case Sportoteka3DProMode.Branding: return "Брендинг";
                default: return mode.ToString();
            }
        }

        private string ToolTitle(Sportoteka3DProTool tool)
        {
            switch (tool)
            {
                case Sportoteka3DProTool.Select: return "Выбор";
                case Sportoteka3DProTool.Player: return "Игрок";
                case Sportoteka3DProTool.Opponent: return "Соперник";
                case Sportoteka3DProTool.PassArrow: return "Пас";
                case Sportoteka3DProTool.RunArrow: return "Рывок";
                case Sportoteka3DProTool.CurveArrow: return "Кривая стрелка";
                case Sportoteka3DProTool.Line: return "Линия";
                case Sportoteka3DProTool.DashedLine: return "Пунктир";
                case Sportoteka3DProTool.Freehand: return "Свободное рисование";
                case Sportoteka3DProTool.Zone: return "Зона";
                case Sportoteka3DProTool.HatchedZone: return "Штрихованная зона";
                case Sportoteka3DProTool.Circle: return "Круг";
                case Sportoteka3DProTool.Text: return "Подпись";
                case Sportoteka3DProTool.Cone: return "Конус";
                case Sportoteka3DProTool.Ball: return "Мяч";
                case Sportoteka3DProTool.MiniGoal: return "Мини-ворота";
                case Sportoteka3DProTool.BigGoal: return "Большие ворота";
                case Sportoteka3DProTool.Mannequin: return "Манекен";
                case Sportoteka3DProTool.Ladder: return "Лестница";
                case Sportoteka3DProTool.Hurdle: return "Барьер";
                case Sportoteka3DProTool.Gate: return "Гейт";
                case Sportoteka3DProTool.Pole: return "Стойка";
                case Sportoteka3DProTool.Spotlight: return "Подсветка";
                case Sportoteka3DProTool.Matchup: return "Связь игроков";
                case Sportoteka3DProTool.Offside: return "Линия офсайда";
                case Sportoteka3DProTool.Measurement: return "Дистанция";
                case Sportoteka3DProTool.TeamBadge: return "Логотип команды";
                case Sportoteka3DProTool.CalibrationMarker: return "Точка калибровки";
                default: return tool.ToString();
            }
        }

        private void SetMode(Sportoteka3DProMode mode)
        {
            _mode = mode;
            if (_modeText != null) _modeText.text = "Спортотека • Редактор тактики • " + _teamName + " • " + mode;
            SetStatus("Режим: " + mode + ". Нажми «Шаблон режима» или выбери инструмент снизу.");
        }

        private void SetTool(Sportoteka3DProTool tool)
        {
            _tool = tool;
            SetStatus("Инструмент: " + ToolTitle(tool) + ". ЛКМ — поставить/начертить, ПКМ — камера, колесо — приближение.");
        }

        private void SelectPlayer(Sportoteka3DProPlayerData player)
        {
            _selectedPlayer = player;
            SetTool(Sportoteka3DProTool.Player);
            SetStatus("Выбран игрок №" + player.number + " — " + player.name + ". Теперь кликни по полю.");
        }

        private void SetLineWidth(float value)
        {
            _activeWidth = Mathf.Clamp(value, 0.035f, 0.30f);
        }

        private void SetAlpha(float value)
        {
            _activeAlpha = Mathf.Clamp01(value);
        }

        private void SetActiveColor(string hex)
        {
            _activeColor = ParseColor(hex);
            SetStatus("Цвет: " + hex);
        }

        private void ColorDot(Transform parent, string hex, float x, float y)
        {
            var dot = Panel(parent, "Color " + hex, ParseColor(hex), 12, ParseColor(Border));
            Place(dot, new Vector2(x, y), new Vector2(0, 1), new Vector2(0, 1), new Vector2(24, 24));
            var b = dot.AddComponent<Button>();
            b.targetGraphic = dot.GetComponent<Image>();
            b.onClick.AddListener(() => SetActiveColor(hex));
        }

        private void RotateCamera(float yaw)
        {
            var cam = Camera.main;
            if (cam == null) return;
            cam.transform.RotateAround(Vector3.zero, Vector3.up, yaw);
            cam.transform.LookAt(Vector3.zero);
            SetStatus("Камера поворот");
        }

        private void ZoomCamera(float amount)
        {
            var cam = Camera.main;
            if (cam == null) return;
            cam.transform.position += cam.transform.forward * amount;
            cam.transform.LookAt(Vector3.zero);
            SetStatus("Камера zoom");
        }

        private void PanCamera(float right, float forward)
        {
            var cam = Camera.main;
            if (cam == null) return;
            Vector3 r = cam.transform.right; r.y = 0; r.Normalize();
            Vector3 f = Vector3.Cross(r, Vector3.up).normalized;
            cam.transform.position += r * right + f * forward;
            SetStatus("Камера сдвиг");
        }

        private void SetCameraPreset(string preset)
        {
            var cam = Camera.main;
            if (cam == null) return;
            if (preset == "top")
            {
                cam.transform.position = new Vector3(0, 86, 0.01f);
                cam.transform.rotation = Quaternion.Euler(90, 0, 0);
            }
            else
            {
                cam.transform.position = new Vector3(0, 38, -58);
                cam.transform.rotation = Quaternion.Euler(54, 0, 0);
            }
            SetStatus("Камера: " + preset);
        }

        private bool TryFieldPoint(Vector2 screen, out Vector3 hit)
        {
            hit = Vector3.zero;
            var cam = Camera.main;
            if (cam == null) return false;
            Ray ray = cam.ScreenPointToRay(screen);
            Plane plane = new Plane(Vector3.up, Vector3.zero);
            float dist;
            if (!plane.Raycast(ray, out dist)) return false;
            hit = ray.GetPoint(dist);
            return true;
        }

        private Vector3 Snap(Vector3 v)
        {
            return new Vector3(Mathf.Round(v.x * 2f) * 0.5f, 0, Mathf.Round(v.z * 2f) * 0.5f);
        }

        private void MarkDirty(string message)
        {
            SetStatus(message);
        }

        private void SetStatus(string message)
        {
            if (_statusText != null) _statusText.text = message;
            Debug.Log("[Sportoteka3DPro] " + message);
        }

        private void ClearChildren(Transform parent)
        {
            if (parent == null) return;
            for (int i = parent.childCount - 1; i >= 0; i--)
            {
                Destroy(parent.GetChild(i).gameObject);
            }
        }

        private bool IsPointerOverUI()
        {
            return EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();
        }

        private Vector2 PointerPosition()
        {
#if ENABLE_INPUT_SYSTEM
            return Pointer.current != null ? Pointer.current.position.ReadValue() : Vector2.zero;
#else
            return Input.mousePosition;
#endif
        }

        private bool PointerDown()
        {
#if ENABLE_INPUT_SYSTEM
            return Pointer.current != null && Pointer.current.press.wasPressedThisFrame;
#else
            return Input.GetMouseButtonDown(0);
#endif
        }

        private bool PointerHeld()
        {
#if ENABLE_INPUT_SYSTEM
            return Pointer.current != null && Pointer.current.press.isPressed;
#else
            return Input.GetMouseButton(0);
#endif
        }

        private bool PointerUp()
        {
#if ENABLE_INPUT_SYSTEM
            return Pointer.current != null && Pointer.current.press.wasReleasedThisFrame;
#else
            return Input.GetMouseButtonUp(0);
#endif
        }

        private bool KeyDown(string key)
        {
#if ENABLE_INPUT_SYSTEM
            var kb = Keyboard.current;
            if (kb == null) return false;
            if (key == "escape") return kb.escapeKey.wasPressedThisFrame;
            if (key == "delete") return kb.deleteKey.wasPressedThisFrame;
            if (key == "backspace") return kb.backspaceKey.wasPressedThisFrame;
            if (key == "plus") return kb.equalsKey.wasPressedThisFrame || kb.numpadPlusKey.wasPressedThisFrame;
            if (key == "minus") return kb.minusKey.wasPressedThisFrame || kb.numpadMinusKey.wasPressedThisFrame;
            if (key == "leftBracket") return kb.leftBracketKey.wasPressedThisFrame;
            if (key == "rightBracket") return kb.rightBracketKey.wasPressedThisFrame;
            if (key == "c") return kb.cKey.wasPressedThisFrame;
            if (key == "s") return kb.sKey.wasPressedThisFrame;
            return false;
#else
            if (key == "escape") return Input.GetKeyDown(KeyCode.Escape);
            if (key == "delete") return Input.GetKeyDown(KeyCode.Delete);
            if (key == "backspace") return Input.GetKeyDown(KeyCode.Backspace);
            if (key == "plus") return Input.GetKeyDown(KeyCode.Equals) || Input.GetKeyDown(KeyCode.KeypadPlus);
            if (key == "minus") return Input.GetKeyDown(KeyCode.Minus) || Input.GetKeyDown(KeyCode.KeypadMinus);
            if (key == "leftBracket") return Input.GetKeyDown(KeyCode.LeftBracket);
            if (key == "rightBracket") return Input.GetKeyDown(KeyCode.RightBracket);
            if (key == "c") return Input.GetKeyDown(KeyCode.C);
            if (key == "s") return Input.GetKeyDown(KeyCode.S);
            return false;
#endif
        }

        private void EnsureEventSystem()
        {
            if (EventSystem.current != null) return;
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
            es.AddComponent<InputSystemUIInputModule>();
#else
            es.AddComponent<StandaloneInputModule>();
#endif
        }

        private GameObject Panel(Transform parent, string name, Color color, float radius, Color? border = null)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.AddComponent<RectTransform>();
            var img = obj.AddComponent<Image>();
            img.color = color;

            if (radius > 0)
            {
                img.sprite = RoundedSprite();
                img.type = Image.Type.Sliced;
            }

            if (border.HasValue)
            {
                var outline = obj.AddComponent<Outline>();
                outline.effectColor = border.Value;
                outline.effectDistance = new Vector2(1f, -1f);
                outline.useGraphicAlpha = false;
            }

            return obj;
        }

        private static Sprite RoundedSprite()
        {
            if (_roundedSprite != null) return _roundedSprite;

            const int size = 64;
            const int radius = 18;
            var texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
            texture.name = "Sportoteka UI Rounded Sprite";

            var clear = new Color(1f, 1f, 1f, 0f);
            var white = Color.white;

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    bool inside =
                        (x >= radius && x < size - radius) ||
                        (y >= radius && y < size - radius) ||
                        Vector2.Distance(new Vector2(x, y), new Vector2(radius, radius)) <= radius ||
                        Vector2.Distance(new Vector2(x, y), new Vector2(size - radius - 1, radius)) <= radius ||
                        Vector2.Distance(new Vector2(x, y), new Vector2(radius, size - radius - 1)) <= radius ||
                        Vector2.Distance(new Vector2(x, y), new Vector2(size - radius - 1, size - radius - 1)) <= radius;

                    texture.SetPixel(x, y, inside ? white : clear);
                }
            }

            texture.Apply();
            _roundedSprite = Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(radius, radius, radius, radius));
            return _roundedSprite;
        }

        private Text Text(Transform parent, string value, int size, FontStyle style, Color color, TextAnchor anchor)
        {
            var obj = new GameObject("Text");
            obj.transform.SetParent(parent, false);
            obj.AddComponent<RectTransform>();
            var text = obj.AddComponent<Text>();
            text.text = value;
            text.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
            text.fontSize = size;
            text.fontStyle = style;
            text.color = color;
            text.alignment = anchor;
            return text;
        }

        private Button TextButton(Transform parent, string label, UnityEngine.Events.UnityAction action, Color bg, Color fg, float width, float height, int fontSize = 11)
        {
            var obj = Panel(parent, "Button " + label, bg, 12);
            var rt = obj.GetComponent<RectTransform>();
            rt.sizeDelta = new Vector2(width, height);
            var btn = obj.AddComponent<Button>();
            btn.targetGraphic = obj.GetComponent<Image>();
            btn.onClick.AddListener(action);
            var t = Text(obj.transform, label, fontSize, FontStyle.Bold, fg, TextAnchor.MiddleCenter);
            Place(t.gameObject, Vector2.zero, new Vector2(0, 0), new Vector2(1, 1), Vector2.zero, new Vector2(0.5f, 0.5f), true);
            return btn;
        }

        private Slider Slider(Transform parent, string name, float min, float max, float value, UnityEngine.Events.UnityAction<float> onChange)
        {
            var obj = new GameObject(name);
            obj.transform.SetParent(parent, false);
            obj.AddComponent<RectTransform>();
            var slider = obj.AddComponent<Slider>();
            slider.minValue = min;
            slider.maxValue = max;
            slider.value = value;
            slider.onValueChanged.AddListener(onChange);

            var bg = Panel(obj.transform, "Bg", ParseColor("#E5E7EB"), 5);
            Place(bg, Vector2.zero, new Vector2(0, 0.5f), new Vector2(1, 0.5f), new Vector2(0, 6), new Vector2(0.5f, 0.5f));
            var fill = Panel(obj.transform, "Fill", ParseColor(Green), 5);
            Place(fill, Vector2.zero, new Vector2(0, 0.5f), new Vector2(1, 0.5f), new Vector2(0, 6), new Vector2(0.5f, 0.5f));
            slider.fillRect = fill.GetComponent<RectTransform>();
            var handle = Panel(obj.transform, "Handle", Color.white, 9, ParseColor(Green));
            Place(handle, Vector2.zero, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(18, 18), new Vector2(0.5f, 0.5f));
            slider.handleRect = handle.GetComponent<RectTransform>();
            slider.targetGraphic = handle.GetComponent<Image>();
            return slider;
        }

        private void Analog(Transform parent, string label, UnityEngine.Events.UnityAction action, float x, float y)
        {
            var b = TextButton(parent, label, action, ParseColor("#F8FAFC"), ParseColor(Graphite), 34, 30, 12);
            Place(b.gameObject, new Vector2(x, y), new Vector2(0, 1), new Vector2(0, 1));
        }

        private void Place(GameObject obj, Vector2 anchored, Vector2 anchorMin, Vector2 anchorMax, Vector2 size, Vector2 pivot, bool stretchOffsets = false)
        {
            var rt = obj.GetComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.pivot = pivot;
            if (stretchOffsets)
            {
                rt.offsetMin = Vector2.zero;
                rt.offsetMax = Vector2.zero;
            }
            else
            {
                rt.anchoredPosition = anchored;
                rt.sizeDelta = size;
            }
        }

        private void Place(GameObject obj, Vector2 anchored, Vector2 anchorMin, Vector2 anchorMax)
        {
            Place(obj, anchored, anchorMin, anchorMax, obj.GetComponent<RectTransform>().sizeDelta, new Vector2(0, 1));
        }

        private void Place(GameObject obj, Vector2 anchored, Vector2 anchorMin, Vector2 anchorMax, Vector2 size)
        {
            Place(obj, anchored, anchorMin, anchorMax, size, new Vector2(0, 1));
        }

        private static Color ParseColor(string hex)
        {
            Color c;
            return ColorUtility.TryParseHtmlString(hex, out c) ? c : Color.white;
        }

        private static Color WithAlpha(Color c, float alpha)
        {
            c.a = alpha;
            return c;
        }

        private static string ColorToHex(Color c)
        {
            return "#" + ColorUtility.ToHtmlStringRGB(c);
        }
    }
}
