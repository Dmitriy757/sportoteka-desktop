
using System.Collections.Generic;
using UnityEngine;

namespace Sportoteka3DPro
{
    public static class Sportoteka3DProPresets
    {
        public static List<Sportoteka3DProPlanItem> Formation433()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPlayer(items, 1, "ВР", 0, 29);
            AddPlayer(items, 2, "ПЗ", 22, 17);
            AddPlayer(items, 4, "ЦЗ", 8, 18);
            AddPlayer(items, 5, "ЦЗ", -8, 18);
            AddPlayer(items, 3, "ЛЗ", -22, 17);
            AddPlayer(items, 6, "ОП", 0, 4);
            AddPlayer(items, 8, "ЦП", -12, -8);
            AddPlayer(items, 10, "АП", 12, -8);
            AddPlayer(items, 7, "ПК", 24, -22);
            AddPlayer(items, 11, "ЛК", -24, -22);
            AddPlayer(items, 9, "НП", 0, -28);
            AddArrow(items, "pass", 0, 4, 12, -8, "#FDE047");
            AddArrow(items, "curve", 12, -8, 0, -28, "#38BDF8");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> AnalysisPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddDrag(items, "spotlight", 0, 0, 0, 0, "#FDE047", 0.08f, 2.2f);
            AddDrag(items, "matchup", -14, -6, 14, -6, "#FDE047", 0.08f);
            AddDrag(items, "offside", -36, -18, 36, -18, "#F43F5E", 0.055f);
            AddDrag(items, "hatched_zone", -20, -16, 20, 8, "#00A750", 0.06f);
            AddLabel(items, "ТРИГГЕР ПРЕССИНГА", 0, -13, "#111827");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> DrillPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPoint(items, "ladder", -24, -12, "#F97316");
            AddPoint(items, "gate", -8, -14, "#F97316");
            AddPoint(items, "hurdle", 6, -14, "#F43F5E");
            AddPoint(items, "mini_goal", 24, -16, "#FFFFFF");
            AddPoint(items, "mannequin", 0, 10, "#F59E0B");
            AddArrow(items, "run", -28, 16, -8, 0, "#38BDF8");
            AddArrow(items, "pass", -8, 0, 16, -10, "#FDE047");
            AddLabel(items, "ТРЕНИРОВКА: пас → рывок → завершение", 2, -28, "#111827");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> CalibrationPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPoint(items, "calibration", -52.5f, -34f, "#38BDF8");
            AddPoint(items, "calibration", 52.5f, -34f, "#38BDF8");
            AddPoint(items, "calibration", -52.5f, 34f, "#38BDF8");
            AddPoint(items, "calibration", 52.5f, 34f, "#38BDF8");
            AddLabel(items, "КАЛИБРОВКА ПОЛЯ", 0, 0, "#38BDF8");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> BrandingPack(string teamName)
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddBadge(items, teamName, -42, 28, "#00A750");
            AddBadge(items, "СОПЕРНИК", 42, 28, "#2563EB");
            AddLabel(items, teamName, -32, 24, "#00A750");
            AddLabel(items, "СОПЕРНИК", 32, 24, "#2563EB");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> MultiSportPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddDrag(items, "line", -22, 22, 22, 22, "#38BDF8", 0.055f);
            AddDrag(items, "line", -22, -22, 22, -22, "#38BDF8", 0.055f);
            AddDrag(items, "line", -22, -22, -22, 22, "#38BDF8", 0.055f);
            AddDrag(items, "line", 22, -22, 22, 22, "#38BDF8", 0.055f);
            AddDrag(items, "circle", 0, 0, 8, 0, "#38BDF8", 0.055f);
            AddLabel(items, "МУЛЬТИСПОРТ РАЗМЕТКА", 0, 26, "#2563EB");
            return items;
        }

        private static void AddPlayer(List<Sportoteka3DProPlanItem> items, int number, string pos, float x, float z)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(),
                type = "player",
                number = number,
                name = "Игрок №" + number,
                position = pos,
                initials = number.ToString(),
                x = x,
                z = z,
                color = "#00A750",
                scale = 1f
            });
        }

        private static void AddArrow(List<Sportoteka3DProPlanItem> items, string type, float x, float z, float toX, float toZ, string color)
        {
            AddDrag(items, type, x, z, toX, toZ, color, 0.08f);
        }

        private static void AddDrag(List<Sportoteka3DProPlanItem> items, string type, float x, float z, float toX, float toZ, string color, float width, float scale = 1f)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(),
                type = type,
                x = x,
                z = z,
                toX = toX,
                toZ = toZ,
                controlX = (x + toX) * 0.5f,
                controlZ = (z + toZ) * 0.5f + 7f,
                color = color,
                width = width,
                scale = scale
            });
        }

        private static void AddPoint(List<Sportoteka3DProPlanItem> items, string type, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(),
                type = type,
                x = x,
                z = z,
                color = color,
                scale = 1f
            });
        }

        private static void AddLabel(List<Sportoteka3DProPlanItem> items, string text, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(),
                type = "text",
                x = x,
                z = z,
                text = text,
                color = color,
                scale = 0.8f
            });
        }

        private static void AddBadge(List<Sportoteka3DProPlanItem> items, string text, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(),
                type = "team_badge",
                x = x,
                z = z,
                text = text,
                color = color,
                scale = 1f
            });
        }

        private static string NewId()
        {
            return "item_" + Random.Range(100000, 999999).ToString();
        }
    }
}
