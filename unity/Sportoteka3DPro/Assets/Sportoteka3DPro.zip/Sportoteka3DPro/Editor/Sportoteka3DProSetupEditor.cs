#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Sportoteka3DPro.EditorTools
{
    public static class Sportoteka3DProSetupEditor
    {
        private const string ScenePath = "Assets/Sportoteka3DPro/Scenes/Sportoteka3DPro.unity";

        [MenuItem("Sportoteka 3D Pro/Create Built-in Professional Scene")]
        public static void CreateBuiltInProfessionalScene()
        {
            EnsureFolders();

            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            scene.name = "Sportoteka3DPro";

            var bridge = new GameObject("Sportoteka3DProBridge");
            bridge.AddComponent<Sportoteka3DProBridge>();

            var cameraObject = new GameObject("Main Camera");
            cameraObject.tag = "MainCamera";
            var camera = cameraObject.AddComponent<Camera>();
            cameraObject.AddComponent<AudioListener>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.42f, 0.50f, 0.58f);
            camera.fieldOfView = 40f;
            camera.transform.position = new Vector3(-36f, 28f, -44f);
            camera.transform.LookAt(new Vector3(7f, 0f, 0f));

            var lightObject = new GameObject("Sportoteka 3D Pro Sun");
            var light = lightObject.AddComponent<Light>();
            light.type = LightType.Directional;
            light.intensity = 0.55f;
            light.shadows = LightShadows.None;
            lightObject.transform.rotation = Quaternion.Euler(50f, -35f, 0f);

            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.28f, 0.34f, 0.30f);
            RenderSettings.skybox = null;

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorSceneManager.OpenScene(ScenePath);

            Debug.Log("[Sportoteka3DPro] Built-in professional scene created with exposure-safe materials. Scene is first in Build Settings: " + ScenePath);
        }

        [MenuItem("Sportoteka 3D Pro/Open Scene")]
        public static void OpenScene()
        {
            if (File.Exists(ScenePath)) EditorSceneManager.OpenScene(ScenePath);
            else CreateBuiltInProfessionalScene();
        }

        private static void EnsureFolders()
        {
            Directory.CreateDirectory("Assets/Sportoteka3DPro/Scenes");
            Directory.CreateDirectory("Assets/Sportoteka3DPro/Resources");
        }
    }
}
#endif
