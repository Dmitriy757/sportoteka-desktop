using System;
using UnityEngine;

namespace Sportoteka3DPro
{
    [Serializable]
    public class Sportoteka3DProScene
    {
        public string title = "Sportoteka 3D Pro";
        public Sportoteka3DProCamera camera = new Sportoteka3DProCamera();
        public Sportoteka3DProObject[] objects = Array.Empty<Sportoteka3DProObject>();
    }

    [Serializable]
    public class Sportoteka3DProCamera
    {
        public string preset = "fifa";
        public float x = 0f;
        public float y = 42f;
        public float z = -54f;
        public float targetX = 0f;
        public float targetY = 0f;
        public float targetZ = 0f;
        public float fov = 42f;
    }

    [Serializable]
    public class Sportoteka3DProObject
    {
        public string id = "object";
        public string type = "marker";
        public string team = "home";
        public string label = "";
        public string color = "#1B5E20";
        public string secondaryColor = "#FFFFFF";
        public float x = 0f;
        public float y = 0f;
        public float z = 0f;
        public float toX = 0f;
        public float toY = 0f;
        public float toZ = 0f;
        public float width = 4f;
        public float height = 4f;
        public float radius = 2f;
        public int number = 0;
        public bool visible = true;
    }
}
