using UnityEngine;

namespace Sportoteka3DPro
{
    public static class Sportoteka3DProObjectFactory
    {
        public static GameObject Create(Sportoteka3DProObject item, Transform parent)
        {
            if (item == null || !item.visible) return null;
            string type = (item.type ?? "marker").Trim().ToLowerInvariant();

            return type switch
            {
                "player" => CreatePlayer(item, parent),
                "ball" => CreateBall(item, parent),
                "cone" => CreateCone(item, parent),
                "arrow" => CreateArrow(item, parent),
                "zone" => CreateZone(item, parent),
                "label" => CreateLabel(item, parent),
                "goal" => CreateGoalMarker(item, parent),
                _ => CreateMarker(item, parent),
            };
        }

        private static GameObject CreatePlayer(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("Player_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0f, item.z);

            string kit = item.team == "away" ? "#E9EEF4" : item.color;
            if (string.IsNullOrWhiteSpace(kit)) kit = item.team == "away" ? "#E9EEF4" : "#0A8F52";
            var kitMat = Sportoteka3DProMaterialFactory.Solid("Kit " + item.team, kit);
            var darkMat = Sportoteka3DProMaterialFactory.Solid("Sportoteka Dark", "#17221D");
            var skinMat = Sportoteka3DProMaterialFactory.Solid("Skin", "#F0C8A0");
            var whiteMat = Sportoteka3DProMaterialFactory.Solid("Player Label", "#EAF7EF");

            AddCapsule(root.transform, "Body", new Vector3(0f, 1.05f, 0f), new Vector3(0.5f, 0.85f, 0.5f), kitMat);
            AddSphere(root.transform, "Head", new Vector3(0f, 2.1f, 0f), new Vector3(0.36f, 0.36f, 0.36f), skinMat);
            AddCapsule(root.transform, "Left Leg", new Vector3(-0.18f, 0.45f, 0f), new Vector3(0.16f, 0.42f, 0.16f), darkMat);
            AddCapsule(root.transform, "Right Leg", new Vector3(0.18f, 0.45f, 0f), new Vector3(0.16f, 0.42f, 0.16f), darkMat);
            AddCapsule(root.transform, "Left Arm", new Vector3(-0.48f, 1.25f, 0f), new Vector3(0.12f, 0.38f, 0.12f), skinMat);
            AddCapsule(root.transform, "Right Arm", new Vector3(0.48f, 1.25f, 0f), new Vector3(0.12f, 0.38f, 0.12f), skinMat);
            AddSelectionDisc(root.transform, item.team == "away" ? "#C6D3E1" : "#6EE7B7");

            if (item.number > 0)
            {
                AddBillboardText(root.transform, item.number.ToString(), new Vector3(0f, 2.65f, 0f), 0.26f, whiteMat, TextAnchor.MiddleCenter);
            }

            if (!string.IsNullOrWhiteSpace(item.label))
            {
                AddBillboardText(root.transform, item.label, new Vector3(0f, 3.05f, 0f), 0.16f, whiteMat, TextAnchor.MiddleCenter);
            }

            return root;
        }

        private static GameObject CreateBall(Sportoteka3DProObject item, Transform parent)
        {
            var mat = Sportoteka3DProMaterialFactory.Solid("Ball", "#EDEFF2");
            var root = new GameObject("Ball_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0.28f, item.z);
            AddSphere(root.transform, "Ball Mesh", Vector3.zero, new Vector3(0.42f, 0.42f, 0.42f), mat);
            return root;
        }

        private static GameObject CreateCone(Sportoteka3DProObject item, Transform parent)
        {
            var mat = Sportoteka3DProMaterialFactory.Solid("Cone", string.IsNullOrWhiteSpace(item.color) ? "#FF7A00" : item.color);
            var root = new GameObject("Cone_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0f, item.z);
            var cone = new GameObject("Cone Mesh");
            cone.transform.SetParent(root.transform, false);
            cone.transform.localPosition = new Vector3(0f, 0.3f, 0f);
            cone.AddComponent<MeshFilter>().sharedMesh = CreateConeMesh(0.36f, 0.02f, 0.72f, 32);
            cone.AddComponent<MeshRenderer>().sharedMaterial = mat;
            return root;
        }

        private static GameObject CreateArrow(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("Arrow_" + SafeName(item.id));
            root.transform.SetParent(parent, false);

            Vector3 start = new Vector3(item.x, 0.35f, item.z);
            Vector3 end = new Vector3(item.toX, 0.35f, item.toZ);
            Vector3 delta = end - start;
            if (delta.magnitude < 0.1f) delta = Vector3.forward * 5f;
            Vector3 dir = delta.normalized;
            var mat = Sportoteka3DProMaterialFactory.Solid("Arrow", string.IsNullOrWhiteSpace(item.color) ? "#00E676" : item.color);

            var shaft = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            shaft.name = "Arrow Shaft";
            shaft.transform.SetParent(root.transform, false);
            shaft.transform.position = start + delta * 0.45f;
            shaft.transform.rotation = Quaternion.FromToRotation(Vector3.up, dir);
            shaft.transform.localScale = new Vector3(0.18f, delta.magnitude * 0.45f, 0.18f);
            shaft.GetComponent<Renderer>().sharedMaterial = mat;

            var head = new GameObject("Arrow Head");
            head.transform.SetParent(root.transform, false);
            head.transform.position = end - dir * 0.6f;
            head.transform.rotation = Quaternion.FromToRotation(Vector3.up, dir);
            head.AddComponent<MeshFilter>().sharedMesh = CreateConeMesh(0.55f, 0.04f, 1.2f, 32);
            head.AddComponent<MeshRenderer>().sharedMaterial = mat;

            return root;
        }

        private static GameObject CreateZone(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("Zone_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0.16f, item.z);
            var mat = Sportoteka3DProMaterialFactory.Solid("Zone", string.IsNullOrWhiteSpace(item.color) ? "#00A870" : item.color, true, 0.28f);

            var zone = GameObject.CreatePrimitive(PrimitiveType.Cube);
            zone.name = "Zone Mesh";
            zone.transform.SetParent(root.transform, false);
            zone.transform.localPosition = Vector3.zero;
            zone.transform.localScale = new Vector3(Mathf.Max(1f, item.width), 0.08f, Mathf.Max(1f, item.height));
            zone.GetComponent<Renderer>().sharedMaterial = mat;

            return root;
        }

        private static GameObject CreateLabel(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("Label_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0f, item.z);
            var mat = Sportoteka3DProMaterialFactory.Solid("Label", string.IsNullOrWhiteSpace(item.color) ? "#EAF7EF" : item.color);
            AddBillboardText(root.transform, string.IsNullOrWhiteSpace(item.label) ? "Эпизод" : item.label, new Vector3(0f, 1.25f, 0f), 0.08f, mat, TextAnchor.MiddleCenter);
            return root;
        }

        private static GameObject CreateGoalMarker(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("GoalMarker_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0.5f, item.z);
            var mat = Sportoteka3DProMaterialFactory.Solid("Goal Marker", "#FFD54F");
            AddSphere(root.transform, "Goal Star", Vector3.zero, new Vector3(0.7f, 0.7f, 0.7f), mat);
            AddBillboardText(root.transform, string.IsNullOrWhiteSpace(item.label) ? "ГОЛ" : item.label, new Vector3(0f, 1.4f, 0f), 0.24f, mat, TextAnchor.MiddleCenter);
            return root;
        }

        private static GameObject CreateMarker(Sportoteka3DProObject item, Transform parent)
        {
            var root = new GameObject("Marker_" + SafeName(item.id));
            root.transform.SetParent(parent, false);
            root.transform.localPosition = new Vector3(item.x, 0.15f, item.z);
            var mat = Sportoteka3DProMaterialFactory.Solid("Marker", string.IsNullOrWhiteSpace(item.color) ? "#00A870" : item.color);
            AddCylinder(root.transform, "Marker Mesh", Vector3.zero, new Vector3(0.55f, 0.12f, 0.55f), mat);
            return root;
        }

        private static void AddSelectionDisc(Transform parent, string color)
        {
            var mat = Sportoteka3DProMaterialFactory.Solid("Player Disc", color, true, 0.55f);
            AddCylinder(parent, "Selection Disc", new Vector3(0f, 0.04f, 0f), new Vector3(0.75f, 0.025f, 0.75f), mat);
        }

        private static Mesh CreateConeMesh(float bottomRadius, float topRadius, float height, int segments)
        {
            var mesh = new Mesh();
            Vector3[] vertices = new Vector3[(segments + 1) * 2];
            int[] triangles = new int[segments * 6];
            for (int i = 0; i <= segments; i++)
            {
                float a = Mathf.PI * 2f * i / segments;
                float ca = Mathf.Cos(a);
                float sa = Mathf.Sin(a);
                vertices[i] = new Vector3(ca * bottomRadius, -height * 0.5f, sa * bottomRadius);
                vertices[i + segments + 1] = new Vector3(ca * topRadius, height * 0.5f, sa * topRadius);
            }
            int t = 0;
            for (int i = 0; i < segments; i++)
            {
                int b0 = i;
                int b1 = i + 1;
                int t0 = i + segments + 1;
                int t1 = i + segments + 2;
                triangles[t++] = b0;
                triangles[t++] = t0;
                triangles[t++] = b1;
                triangles[t++] = b1;
                triangles[t++] = t0;
                triangles[t++] = t1;
            }
            mesh.vertices = vertices;
            mesh.triangles = triangles;
            mesh.RecalculateNormals();
            mesh.RecalculateBounds();
            return mesh;
        }

        private static GameObject AddCapsule(Transform parent, string name, Vector3 pos, Vector3 scale, Material mat)
        {
            var obj = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = pos;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = mat;
            return obj;
        }

        private static GameObject AddSphere(Transform parent, string name, Vector3 pos, Vector3 scale, Material mat)
        {
            var obj = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = pos;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = mat;
            return obj;
        }

        private static GameObject AddCylinder(Transform parent, string name, Vector3 pos, Vector3 scale, Material mat)
        {
            var obj = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            obj.name = name;
            obj.transform.SetParent(parent, false);
            obj.transform.localPosition = pos;
            obj.transform.localScale = scale;
            obj.GetComponent<Renderer>().sharedMaterial = mat;
            return obj;
        }

        private static void AddBillboardText(Transform parent, string text, Vector3 pos, float size, Material mat, TextAnchor anchor)
        {
            var label = new GameObject("Billboard Text");
            label.transform.SetParent(parent, false);
            label.transform.localPosition = pos;
            var mesh = label.AddComponent<TextMesh>();
            mesh.text = text;
            mesh.anchor = anchor;
            mesh.alignment = TextAlignment.Center;
            mesh.characterSize = size;
            mesh.fontSize = 28;
            mesh.color = mat != null && mat.HasProperty("_Color") ? mat.GetColor("_Color") : Color.white;
            label.AddComponent<Sportoteka3DProBillboard>();
        }

        private static string SafeName(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? "object" : value.Replace(" ", "_").Replace("/", "_");
        }
    }
}
