using UnityEngine;

namespace Sportoteka3DPro
{
    public static class Sportoteka3DProCameraRig
    {
        public static Camera EnsureCamera()
        {
            Camera camera = Camera.main;
            if (camera == null)
            {
                var cameraObject = new GameObject("Main Camera");
                cameraObject.tag = "MainCamera";
                camera = cameraObject.AddComponent<Camera>();
                cameraObject.AddComponent<AudioListener>();
            }
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(0.42f, 0.50f, 0.58f);
            camera.fieldOfView = 42f;
            camera.nearClipPlane = 0.1f;
            camera.farClipPlane = 500f;
            return camera;
        }

        public static void ApplyPreset(Sportoteka3DProCamera sceneCamera)
        {
            Camera camera = EnsureCamera();
            string preset = sceneCamera?.preset?.ToLowerInvariant() ?? "fifa";
            Vector3 position;
            Vector3 target;
            float fov;

            switch (preset)
            {
                case "top":
                case "сверху":
                    position = new Vector3(0f, 82f, 0.1f);
                    target = Vector3.zero;
                    fov = 48f;
                    break;
                case "tactical":
                case "тактика":
                    position = new Vector3(0f, 58f, -34f);
                    target = new Vector3(0f, 0f, 4f);
                    fov = 43f;
                    break;
                case "close":
                    position = new Vector3(-16f, 18f, -22f);
                    target = new Vector3(0f, 0f, -4f);
                    fov = 36f;
                    break;
                case "tv":
                    position = new Vector3(-42f, 32f, -48f);
                    target = new Vector3(8f, 0f, 0f);
                    fov = 38f;
                    break;
                case "diagonal":
                case "диагональ":
                    position = new Vector3(-48f, 36f, -38f);
                    target = new Vector3(7f, 0f, 1f);
                    fov = 41f;
                    break;
                default:
                    position = new Vector3(-36f, 28f, -44f);
                    target = new Vector3(7f, 0f, 0f);
                    fov = 40f;
                    break;
            }

            if (sceneCamera != null && (sceneCamera.y > 0.01f || sceneCamera.x != 0f || sceneCamera.z != 0f))
            {
                position = new Vector3(sceneCamera.x, sceneCamera.y, sceneCamera.z);
                target = new Vector3(sceneCamera.targetX, sceneCamera.targetY, sceneCamera.targetZ);
                if (sceneCamera.fov > 1f) fov = sceneCamera.fov;
            }

            camera.transform.position = position;
            camera.transform.LookAt(target, Vector3.up);
            camera.fieldOfView = fov;
        }
    }
}
