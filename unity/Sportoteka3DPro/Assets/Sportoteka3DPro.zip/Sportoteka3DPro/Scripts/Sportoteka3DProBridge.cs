using System;
using UnityEngine;

namespace Sportoteka3DPro
{
    public sealed class Sportoteka3DProBridge : MonoBehaviour
    {
        private Transform _sceneRoot;
        private bool _isReady;

        private void Awake()
        {
            gameObject.name = "Sportoteka3DProBridge";
            DontDestroyOnLoad(gameObject);
            EnsureLighting();
            EnsureRoot();
        }

        private void Start()
        {
            _isReady = true;
            Debug.Log("[Sportoteka3DPro] Sportoteka3DProReady");
            ApplySceneJson(CreateDemoJson());
        }

        public void ApplySceneJson(string json)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(json)) json = CreateDemoJson();
                var scene = JsonUtility.FromJson<Sportoteka3DProScene>(json);
                if (scene == null) scene = DemoScene();
                BuildScene(scene);
                Debug.Log("[Sportoteka3DPro] Sportoteka3DProSceneApplied objects=" + (scene.objects == null ? 0 : scene.objects.Length));
            }
            catch (Exception ex)
            {
                Debug.LogError("[Sportoteka3DPro] ApplySceneJson failed: " + ex.Message + "\n" + ex.StackTrace);
                BuildScene(DemoScene());
            }
        }

        public void SetCameraPreset(string preset)
        {
            Sportoteka3DProCameraRig.ApplyPreset(new Sportoteka3DProCamera { preset = preset });
        }

        public void ResetScene()
        {
            ApplySceneJson(CreateDemoJson());
        }

        private void BuildScene(Sportoteka3DProScene scene)
        {
            EnsureLighting();
            EnsureRoot();
            ClearRoot();
            Sportoteka3DProFieldBuilder.Build(_sceneRoot);

            if (scene.objects != null)
            {
                foreach (var item in scene.objects)
                {
                    Sportoteka3DProObjectFactory.Create(item, _sceneRoot);
                }
            }

            Sportoteka3DProCameraRig.ApplyPreset(scene.camera ?? new Sportoteka3DProCamera { preset = "fifa" });
        }

        private void EnsureRoot()
        {
            if (_sceneRoot != null) return;
            var existing = GameObject.Find("Sportoteka3DProRuntimeScene");
            if (existing == null) existing = new GameObject("Sportoteka3DProRuntimeScene");
            _sceneRoot = existing.transform;
        }

        private void ClearRoot()
        {
            for (int i = _sceneRoot.childCount - 1; i >= 0; i--)
            {
                var child = _sceneRoot.GetChild(i);
                if (Application.isPlaying) Destroy(child.gameObject);
                else UnityEngine.Object.DestroyImmediate(child.gameObject);
            }
        }

        private static void EnsureLighting()
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.28f, 0.34f, 0.30f);

            if (GameObject.Find("Sportoteka 3D Pro Sun") == null)
            {
                var lightObject = new GameObject("Sportoteka 3D Pro Sun");
                var light = lightObject.AddComponent<Light>();
                light.type = LightType.Directional;
                light.intensity = 0.55f;
                light.shadows = LightShadows.None;
                lightObject.transform.rotation = Quaternion.Euler(50f, -35f, 0f);
            }
        }

        private static Sportoteka3DProScene DemoScene()
        {
            return new Sportoteka3DProScene
            {
                title = "Sportoteka 3D Pro",
                camera = new Sportoteka3DProCamera { preset = "fifa" },
                objects = new[]
                {
                    new Sportoteka3DProObject { id = "p10", type = "player", team = "home", x = -24, z = -12, number = 10, label = "10", color = "#0A8F52" },
                    new Sportoteka3DProObject { id = "p7", type = "player", team = "home", x = -12, z = -4, number = 7, label = "7", color = "#0A8F52" },
                    new Sportoteka3DProObject { id = "p9", type = "player", team = "home", x = 2, z = -12, number = 9, label = "9", color = "#0A8F52" },
                    new Sportoteka3DProObject { id = "a5", type = "player", team = "away", x = 4, z = -2, number = 5, label = "5", color = "#E9EEF4" },
                    new Sportoteka3DProObject { id = "a4", type = "player", team = "away", x = 16, z = -13, number = 4, label = "4", color = "#E9EEF4" },
                    new Sportoteka3DProObject { id = "ball", type = "ball", x = -12, z = -4 },
                    new Sportoteka3DProObject { id = "attack_arrow", type = "arrow", x = -12, z = -4, toX = 15, toZ = -18, color = "#00E676" },
                    new Sportoteka3DProObject { id = "press_zone", type = "zone", x = 12, z = -12, width = 18, height = 14, color = "#00A870" },
                    new Sportoteka3DProObject { id = "label", type = "label", x = 6, z = -24, label = "Атака", color = "#EAF7EF" },
                    new Sportoteka3DProObject { id = "cone1", type = "cone", x = -30, z = 18, color = "#FF7A00" },
                    new Sportoteka3DProObject { id = "cone2", type = "cone", x = -24, z = 18, color = "#FF7A00" },
                }
            };
        }

        private static string CreateDemoJson()
        {
            return JsonUtility.ToJson(DemoScene());
        }
    }
}
