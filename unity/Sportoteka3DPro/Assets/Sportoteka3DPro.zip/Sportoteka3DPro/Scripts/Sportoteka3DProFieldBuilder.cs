using UnityEngine;

namespace Sportoteka3DPro
{
    public static class Sportoteka3DProFieldBuilder
    {
        public const float FieldLength = 105f;
        public const float FieldWidth = 68f;

        public static GameObject Build(Transform parent)
        {
            var fieldRoot = new GameObject("Sportoteka3DProField");
            fieldRoot.transform.SetParent(parent, false);

            var grass = Sportoteka3DProMaterialFactory.Solid("Sportoteka Grass", "#135F32");
            var grassDark = Sportoteka3DProMaterialFactory.Solid("Sportoteka Grass Dark", "#0F4F2A");
            var lineMat = Sportoteka3DProMaterialFactory.Solid("Sportoteka Lines", "#DDEFE5");
            var goalMat = Sportoteka3DProMaterialFactory.Solid("Sportoteka Goal", "#DDEFE5");

            for (int i = 0; i < 10; i++)
            {
                float stripeWidth = FieldLength / 10f;
                var stripe = GameObject.CreatePrimitive(PrimitiveType.Cube);
                stripe.name = "Grass Stripe " + (i + 1);
                stripe.transform.SetParent(fieldRoot.transform, false);
                stripe.transform.localPosition = new Vector3(-FieldLength / 2f + stripeWidth * i + stripeWidth / 2f, 0f, 0f);
                stripe.transform.localScale = new Vector3(stripeWidth, 0.06f, FieldWidth);
                stripe.GetComponent<Renderer>().sharedMaterial = (i % 2 == 0) ? grass : grassDark;
            }

            AddLine(fieldRoot.transform, "Touchline Top", 0, 0.08f, FieldWidth / 2f, FieldLength, 0.18f, lineMat);
            AddLine(fieldRoot.transform, "Touchline Bottom", 0, 0.08f, -FieldWidth / 2f, FieldLength, 0.18f, lineMat);
            AddLine(fieldRoot.transform, "Goal Line Left", -FieldLength / 2f, 0.08f, 0, 0.18f, FieldWidth, lineMat);
            AddLine(fieldRoot.transform, "Goal Line Right", FieldLength / 2f, 0.08f, 0, 0.18f, FieldWidth, lineMat);
            AddLine(fieldRoot.transform, "Middle Line", 0, 0.09f, 0, 0.18f, FieldWidth, lineMat);

            AddCircle(fieldRoot.transform, "Center Circle", Vector3.zero + Vector3.up * 0.12f, 9.15f, lineMat);
            AddDisc(fieldRoot.transform, "Center Spot", new Vector3(0f, 0.13f, 0f), 0.45f, lineMat);

            AddPenaltyArea(fieldRoot.transform, -1, lineMat);
            AddPenaltyArea(fieldRoot.transform, 1, lineMat);
            AddGoal(fieldRoot.transform, -1, goalMat);
            AddGoal(fieldRoot.transform, 1, goalMat);

            return fieldRoot;
        }

        private static void AddPenaltyArea(Transform parent, int side, Material lineMat)
        {
            float x = side * FieldLength / 2f;
            float sign = side;
            float penaltyDepth = 16.5f;
            float penaltyWidth = 40.3f;
            float smallDepth = 5.5f;
            float smallWidth = 18.3f;

            AddLine(parent, side < 0 ? "Penalty Left Back" : "Penalty Right Back", x - sign * penaltyDepth, 0.11f, 0, 0.18f, penaltyWidth, lineMat);
            AddLine(parent, side < 0 ? "Penalty Left Top" : "Penalty Right Top", x - sign * penaltyDepth / 2f, 0.11f, penaltyWidth / 2f, penaltyDepth, 0.18f, lineMat);
            AddLine(parent, side < 0 ? "Penalty Left Bottom" : "Penalty Right Bottom", x - sign * penaltyDepth / 2f, 0.11f, -penaltyWidth / 2f, penaltyDepth, 0.18f, lineMat);

            AddLine(parent, side < 0 ? "Small Left Back" : "Small Right Back", x - sign * smallDepth, 0.11f, 0, 0.18f, smallWidth, lineMat);
            AddLine(parent, side < 0 ? "Small Left Top" : "Small Right Top", x - sign * smallDepth / 2f, 0.11f, smallWidth / 2f, smallDepth, 0.18f, lineMat);
            AddLine(parent, side < 0 ? "Small Left Bottom" : "Small Right Bottom", x - sign * smallDepth / 2f, 0.11f, -smallWidth / 2f, smallDepth, 0.18f, lineMat);

            AddDisc(parent, side < 0 ? "Penalty Spot Left" : "Penalty Spot Right", new Vector3(x - sign * 11f, 0.13f, 0f), 0.35f, lineMat);
        }

        private static void AddLine(Transform parent, string name, float x, float y, float z, float sx, float sz, Material mat)
        {
            var line = GameObject.CreatePrimitive(PrimitiveType.Cube);
            line.name = name;
            line.transform.SetParent(parent, false);
            line.transform.localPosition = new Vector3(x, y, z);
            line.transform.localScale = new Vector3(sx, 0.035f, sz);
            line.GetComponent<Renderer>().sharedMaterial = mat;
        }

        private static void AddCircle(Transform parent, string name, Vector3 center, float radius, Material mat)
        {
            var root = new GameObject(name);
            root.transform.SetParent(parent, false);
            const int segments = 72;
            for (int i = 0; i < segments; i++)
            {
                float a1 = Mathf.PI * 2f * i / segments;
                float a2 = Mathf.PI * 2f * (i + 1) / segments;
                Vector3 p1 = center + new Vector3(Mathf.Cos(a1) * radius, 0f, Mathf.Sin(a1) * radius);
                Vector3 p2 = center + new Vector3(Mathf.Cos(a2) * radius, 0f, Mathf.Sin(a2) * radius);
                AddSegment(root.transform, "Circle Segment", p1, p2, 0.16f, mat);
            }
        }

        private static void AddSegment(Transform parent, string name, Vector3 p1, Vector3 p2, float thickness, Material mat)
        {
            Vector3 mid = (p1 + p2) * 0.5f;
            Vector3 dir = p2 - p1;
            var seg = GameObject.CreatePrimitive(PrimitiveType.Cube);
            seg.name = name;
            seg.transform.SetParent(parent, false);
            seg.transform.position = mid;
            seg.transform.rotation = Quaternion.LookRotation(dir.normalized, Vector3.up);
            seg.transform.localScale = new Vector3(thickness, 0.03f, dir.magnitude);
            seg.GetComponent<Renderer>().sharedMaterial = mat;
        }

        private static void AddDisc(Transform parent, string name, Vector3 position, float radius, Material mat)
        {
            var disc = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            disc.name = name;
            disc.transform.SetParent(parent, false);
            disc.transform.localPosition = position;
            disc.transform.localScale = new Vector3(radius, 0.018f, radius);
            disc.GetComponent<Renderer>().sharedMaterial = mat;
        }

        private static void AddGoal(Transform parent, int side, Material mat)
        {
            float x = side * (FieldLength / 2f + 1.1f);
            var goal = new GameObject(side < 0 ? "Goal Left" : "Goal Right");
            goal.transform.SetParent(parent, false);
            AddGoalPost(goal.transform, new Vector3(x, 1.25f, -3.66f), mat);
            AddGoalPost(goal.transform, new Vector3(x, 1.25f, 3.66f), mat);
            AddCrossbar(goal.transform, new Vector3(x, 2.5f, 0f), mat);
        }

        private static void AddGoalPost(Transform parent, Vector3 pos, Material mat)
        {
            var post = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            post.name = "Goal Post";
            post.transform.SetParent(parent, false);
            post.transform.position = pos;
            post.transform.localScale = new Vector3(0.12f, 1.25f, 0.12f);
            post.GetComponent<Renderer>().sharedMaterial = mat;
        }

        private static void AddCrossbar(Transform parent, Vector3 pos, Material mat)
        {
            var bar = GameObject.CreatePrimitive(PrimitiveType.Cube);
            bar.name = "Goal Crossbar";
            bar.transform.SetParent(parent, false);
            bar.transform.position = pos;
            bar.transform.localScale = new Vector3(0.18f, 0.18f, 7.5f);
            bar.GetComponent<Renderer>().sharedMaterial = mat;
        }
    }
}
