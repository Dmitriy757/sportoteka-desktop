using UnityEngine;

namespace Sportoteka3DPro
{
    /// <summary>
    /// Safe material factory for Sportoteka 3D Pro Built-in renderer.
    /// Supports all current ObjectFactory calls:
    /// Solid(name, hex)
    /// Solid(name, hex, transparent, alpha)
    /// </summary>
    public static class Sportoteka3DProMaterialFactory
    {
        public static Material Solid(string name, string hex)
        {
            return Solid(name, hex, false, 1.0f);
        }

        public static Material Solid(string name, string hex, bool transparent)
        {
            return Solid(name, hex, transparent, 1.0f);
        }

        public static Material Solid(string name, string hex, bool transparent, float alpha)
        {
            var shader = FindSafeShader();
            if (shader == null)
            {
                Debug.LogError("[Sportoteka3DPro] No compatible shader found. Check Unity Player Settings / Graphics and shader stripping.");
                shader = Shader.Find("Standard");
            }

            var material = new Material(shader)
            {
                name = string.IsNullOrWhiteSpace(name) ? "Sportoteka Material" : name
            };

            var color = ParseColor(hex, alpha);
            SetColor(material, color);

            if (transparent || color.a < 0.999f)
            {
                MakeTransparent(material, color.a);
            }

            return material;
        }

        private static Shader FindSafeShader()
        {
            // Built-in first. These are lightweight and stable for simple tactical 3D.
            var names = new[]
            {
                "Unlit/Color",
                "Sprites/Default",
                "Legacy Shaders/Diffuse",
                "Diffuse",
                "Standard"
            };

            foreach (var shaderName in names)
            {
                var shader = Shader.Find(shaderName);
                if (shader != null) return shader;
            }

            return null;
        }

        private static void SetColor(Material material, Color color)
        {
            if (material == null) return;

            if (material.HasProperty("_Color"))
            {
                material.SetColor("_Color", color);
            }

            if (material.HasProperty("_BaseColor"))
            {
                material.SetColor("_BaseColor", color);
            }

            if (material.HasProperty("_Tint"))
            {
                material.SetColor("_Tint", color);
            }
        }

        private static Color ParseColor(string hex, float alpha = 1.0f)
        {
            if (string.IsNullOrWhiteSpace(hex))
            {
                return new Color(0.0f, 0.66f, 0.43f, Mathf.Clamp01(alpha));
            }

            var normalized = hex.Trim();
            if (!normalized.StartsWith("#"))
            {
                normalized = "#" + normalized;
            }

            if (ColorUtility.TryParseHtmlString(normalized, out var parsed))
            {
                parsed.a = Mathf.Clamp01(alpha);
                return parsed;
            }

            return new Color(0.0f, 0.66f, 0.43f, Mathf.Clamp01(alpha));
        }

        private static void MakeTransparent(Material material, float alpha)
        {
            if (material == null) return;

            var color = Color.white;
            if (material.HasProperty("_Color"))
            {
                color = material.GetColor("_Color");
            }
            color.a = Mathf.Clamp01(alpha);
            SetColor(material, color);

            // Standard shader transparent setup. Safe no-op for Unlit/Sprites if properties do not exist.
            if (material.HasProperty("_Mode")) material.SetFloat("_Mode", 3f);
            if (material.HasProperty("_SrcBlend")) material.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
            if (material.HasProperty("_DstBlend")) material.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
            if (material.HasProperty("_ZWrite")) material.SetInt("_ZWrite", 0);

            material.EnableKeyword("_ALPHABLEND_ON");
            material.DisableKeyword("_ALPHATEST_ON");
            material.DisableKeyword("_ALPHAPREMULTIPLY_ON");
            material.renderQueue = (int)UnityEngine.Rendering.RenderQueue.Transparent;
        }
    }
}
