using System.Collections.Generic;
using UnityEngine;

namespace Sportoteka3DPro
{
    public static class Sportoteka3DProPresets
    {
        public static List<Sportoteka3DProPlanItem> Formation433()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPlayer(items, 1, "ВР", 0, 29);
            AddPlayer(items, 2, "ПЗ", 22, 17);
            AddPlayer(items, 4, "ЦЗ", 8, 18);
            AddPlayer(items, 5, "ЦЗ", -8, 18);
            AddPlayer(items, 3, "ЛЗ", -22, 17);
            AddPlayer(items, 6, "ОП", 0, 4);
            AddPlayer(items, 8, "ЦП", -12, -8);
            AddPlayer(items, 10, "АП", 12, -8);
            AddPlayer(items, 7, "ПК", 24, -22);
            AddPlayer(items, 11, "ЛК", -24, -22);
            AddPlayer(items, 9, "НП", 0, -28);

            AddDrag(items, "hatched_zone", -28, -31, 28, -14, "#00A750", 0.055f, 1f, 0.18f);
            AddArrow(items, "pass", 0, 4, 12, -8, "#FDE047");
            AddArrow(items, "curve", 12, -8, 0, -28, "#38BDF8");
            AddLabel(items, "4-3-3 • построение атаки", 0, 32, "#F8FAFC");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> BuildUpPatternPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPlayer(items, 1, "ВР", 0, 28);
            AddPlayer(items, 4, "ЦЗ", -9, 17);
            AddPlayer(items, 5, "ЦЗ", 9, 17);
            AddPlayer(items, 2, "ПЗ", 25, 8);
            AddPlayer(items, 3, "ЛЗ", -25, 8);
            AddPlayer(items, 6, "ОП", 0, 4);
            AddPlayer(items, 8, "ЦП", -12, -8);
            AddPlayer(items, 10, "АП", 12, -11);
            AddPoint(items, "ball", 0, 28, "#FFFFFF");
            AddArrow(items, "pass", 0, 28, -9, 17, "#FDE047");
            AddArrow(items, "pass", -9, 17, 0, 4, "#FDE047");
            AddArrow(items, "pass", 0, 4, 12, -11, "#FDE047");
            AddArrow(items, "run", 25, 8, 29, -14, "#38BDF8");
            AddDrag(items, "hatched_zone", -31, 2, 31, 22, "#22C55E", 0.05f, 1f, 0.12f);
            AddLabel(items, "БИЛДАП: выход через 6-го + подключение фланга", 0, -32, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> SetPieceCornerPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPoint(items, "ball", -52, -34, "#FFFFFF");
            AddPlayer(items, 5, "ЦЗ", -8, -24);
            AddPlayer(items, 4, "ЦЗ", 3, -25);
            AddPlayer(items, 9, "НП", 10, -22);
            AddPlayer(items, 10, "АП", -18, -18);
            AddOpponent(items, 21, "DEF", 0, -27);
            AddOpponent(items, 22, "DEF", 8, -27);
            AddOpponent(items, 23, "DEF", -8, -27);
            AddArrow(items, "curve", -52, -34, 4, -27, "#FDE047");
            AddArrow(items, "run", -18, -18, -6, -27, "#38BDF8");
            AddArrow(items, "run", 10, -22, 17, -29, "#38BDF8");
            AddDrag(items, "hatched_zone", -13, -31, 16, -21, "#F97316", 0.05f, 1f, 0.14f);
            AddLabel(items, "СТАНДАРТ: угловой / блокировка / забегание", 0, -16, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> PressingTriggerPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPlayer(items, 9, "НП", 0, -18);
            AddPlayer(items, 7, "ПК", 20, -12);
            AddPlayer(items, 11, "ЛК", -20, -12);
            AddPlayer(items, 10, "АП", 0, -4);
            AddPlayer(items, 6, "ОП", 0, 9);
            AddOpponent(items, 2, "RB", 25, 12);
            AddOpponent(items, 5, "CB", 7, 18);
            AddOpponent(items, 4, "CB", -7, 18);
            AddPoint(items, "ball", 7, 18, "#FFFFFF");
            AddDrag(items, "spotlight", 7, 18, 7, 18, "#FDE047", 0.08f, 2.4f, 0.24f);
            AddArrow(items, "run", 9, -18, 7, 18, "#38BDF8");
            AddArrow(items, "run", 20, -12, 25, 12, "#38BDF8");
            AddArrow(items, "run", 0, -4, -7, 18, "#38BDF8");
            AddDrag(items, "matchup", -23, -8, 23, -8, "#FDE047", 0.06f);
            AddDrag(items, "offside", -36, 9, 36, 9, "#F43F5E", 0.055f);
            AddDrag(items, "hatched_zone", -28, 4, 28, 23, "#F97316", 0.055f, 1f, 0.14f);
            AddLabel(items, "ТРИГГЕР ПРЕССИНГА: пас на ЦЗ / закрыть фланг", 0, 28, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> FieldRadarPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddDrag(items, "hatched_zone", -26, -6, 26, 16, "#38BDF8", 0.05f, 1f, 0.13f);
            AddDrag(items, "hatched_zone", -18, -25, 18, -7, "#22C55E", 0.05f, 1f, 0.12f);
            AddDrag(items, "measurement", -22, 16, 22, 16, "#FDE047", 0.055f);
            AddDrag(items, "measurement", 0, -24, 0, 16, "#FDE047", 0.055f);
            AddLabel(items, "FIELD RADAR: компактность / глубина / ширина блока", 0, 24, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> DrillPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPoint(items, "cone", -28, 16, "#F97316");
            AddPoint(items, "cone", -8, 0, "#F97316");
            AddPoint(items, "cone", 16, -10, "#F97316");
            AddPoint(items, "ladder", -24, -14, "#F97316");
            AddPoint(items, "gate", -8, -14, "#F97316");
            AddPoint(items, "hurdle", 6, -14, "#F43F5E");
            AddPoint(items, "mini_goal", 28, -16, "#FFFFFF");
            AddPoint(items, "mannequin", 0, 10, "#F59E0B");
            AddPoint(items, "ball", -28, 16, "#FFFFFF");
            AddArrow(items, "run", -28, 16, -8, 0, "#38BDF8");
            AddArrow(items, "pass", -8, 0, 16, -10, "#FDE047");
            AddArrow(items, "run", 16, -10, 28, -16, "#38BDF8");
            AddLabel(items, "УПРАЖНЕНИЕ: пас → открывание → завершение", 2, -28, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> CalibrationPack()
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddPoint(items, "calibration", -52.5f, -34f, "#38BDF8");
            AddPoint(items, "calibration", 52.5f, -34f, "#38BDF8");
            AddPoint(items, "calibration", -52.5f, 34f, "#38BDF8");
            AddPoint(items, "calibration", 52.5f, 34f, "#38BDF8");
            AddDrag(items, "measurement", -52.5f, -34f, 52.5f, -34f, "#FDE047", 0.055f);
            AddDrag(items, "measurement", -52.5f, -34f, -52.5f, 34f, "#FDE047", 0.055f);
            AddLabel(items, "КАЛИБРОВКА ФУТБОЛЬНОГО ПОЛЯ 105 × 68 м", 0, 0, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> BrandingPack(string teamName)
        {
            var items = new List<Sportoteka3DProPlanItem>();
            AddBadge(items, string.IsNullOrEmpty(teamName) ? "SPORTOTEKA" : teamName, -42, 28, "#00A750");
            AddBadge(items, "СОПЕРНИК", 42, 28, "#2563EB");
            AddLabel(items, string.IsNullOrEmpty(teamName) ? "SPORTOTEKA" : teamName, -28, 24, "#FFFFFF");
            AddLabel(items, "СОПЕРНИК", 28, 24, "#FFFFFF");
            return items;
        }

        public static List<Sportoteka3DProPlanItem> ShowcasePack(string teamName)
        {
            var items = BrandingPack(teamName);
            AddDrag(items, "hatched_zone", -34, -29, 34, -18, "#111827", 0.045f, 1f, 0.20f);
            AddLabel(items, "SHOWCASE / БРИФИНГ ДЛЯ КОМАНДЫ", 0, -24, "#FFFFFF");
            AddLabel(items, "Тактическая доска • анализ • упражнение • экспорт PNG/JSON", 0, -29, "#FDE047");
            return items;
        }

        private static void AddPlayer(List<Sportoteka3DProPlanItem> items, int number, string pos, float x, float z)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(), type = "player", number = number, name = "Игрок №" + number, position = pos,
                initials = number.ToString(), x = x, z = z, color = "#00A750", scale = 1f
            });
        }

        private static void AddOpponent(List<Sportoteka3DProPlanItem> items, int number, string pos, float x, float z)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(), type = "opponent", number = number, name = "Соперник №" + number, position = pos,
                initials = number.ToString(), x = x, z = z, color = "#EF4444", scale = 1f
            });
        }

        private static void AddArrow(List<Sportoteka3DProPlanItem> items, string type, float x, float z, float toX, float toZ, string color)
        {
            AddDrag(items, type, x, z, toX, toZ, color, 0.08f);
        }

        private static void AddDrag(List<Sportoteka3DProPlanItem> items, string type, float x, float z, float toX, float toZ, string color, float width, float scale = 1f, float alpha = 1f)
        {
            items.Add(new Sportoteka3DProPlanItem
            {
                id = NewId(), type = type, x = x, z = z, toX = toX, toZ = toZ,
                controlX = (x + toX) * 0.5f,
                controlZ = (z + toZ) * 0.5f + Mathf.Clamp(Mathf.Abs(toX - x) * 0.12f + 4f, 4f, 12f),
                color = color, width = width, scale = scale, alpha = alpha
            });
        }

        private static void AddPoint(List<Sportoteka3DProPlanItem> items, string type, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem { id = NewId(), type = type, x = x, z = z, color = color, scale = 1f });
        }

        private static void AddLabel(List<Sportoteka3DProPlanItem> items, string text, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem { id = NewId(), type = "text", x = x, z = z, text = text, color = color, scale = 0.9f });
        }

        private static void AddBadge(List<Sportoteka3DProPlanItem> items, string text, float x, float z, string color)
        {
            items.Add(new Sportoteka3DProPlanItem { id = NewId(), type = "team_badge", x = x, z = z, text = text, color = color, scale = 1f });
        }

        private static string NewId()
        {
            return "item_" + Random.Range(100000, 999999).ToString();
        }
    }
}
