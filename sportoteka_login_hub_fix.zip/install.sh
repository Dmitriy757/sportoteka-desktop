#!/bin/bash
set -e

PROJECT_DIR="$(pwd)"

if [ ! -f "$PROJECT_DIR/pubspec.yaml" ]; then
  echo "Ошибка: запустите install.sh из корня Flutter-проекта sportoteka2.0"
  exit 1
fi

mkdir -p "$PROJECT_DIR/.backup_login_hub"

cp "$PROJECT_DIR/lib/presentation/workspace_hub/workspace_hub_screen.dart" \
   "$PROJECT_DIR/.backup_login_hub/workspace_hub_screen.dart.bak" 2>/dev/null || true

cp "$PROJECT_DIR/lib/presentation/login_screen/login_screen.dart" \
   "$PROJECT_DIR/.backup_login_hub/login_screen.dart.bak" 2>/dev/null || true

cp "$(dirname "$0")/lib/presentation/workspace_hub/workspace_hub_screen.dart" \
   "$PROJECT_DIR/lib/presentation/workspace_hub/workspace_hub_screen.dart"

cp "$(dirname "$0")/lib/presentation/login_screen/login_screen.dart" \
   "$PROJECT_DIR/lib/presentation/login_screen/login_screen.dart"

echo
echo "=== Проверка Hub ==="
if grep -nE 'LayoutBuilder\(|MouseRegion\(|Spacer\(' \
  "$PROJECT_DIR/lib/presentation/workspace_hub/workspace_hub_screen.dart"; then
  echo "ВНИМАНИЕ: найдены старые конструкции"
  exit 2
else
  echo "OK: LayoutBuilder / MouseRegion / Spacer отсутствуют"
fi

echo
echo "=== Проверка Login ==="
grep -n 'Transition.noTransition' \
  "$PROJECT_DIR/lib/presentation/login_screen/login_screen.dart"

echo
echo "Файлы успешно заменены."
echo "Теперь выполните:"
echo "flutter clean"
echo "flutter pub get"
echo "flutter run"
