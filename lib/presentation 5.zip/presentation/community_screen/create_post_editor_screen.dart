import 'dart:convert';
import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:url_launcher/url_launcher.dart';

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'post_blocks.dart';

class PostComposerController extends ChangeNotifier {
  Future<void> Function()? _submitHandler;
  bool _saving = false;
  bool _disposed = false;

  bool get saving => _saving;
  bool get attached => _submitHandler != null;

  Future<void> submit() async {
    final handler = _submitHandler;
    if (handler != null && !_saving) {
      await handler();
    }
  }

  void _attach(Future<void> Function() handler) {
    if (_disposed) return;
    _submitHandler = handler;
  }

  void _detach() {
    if (_disposed) return;
    _submitHandler = null;
    _saving = false;
  }

  void _setSaving(bool value) {
    if (_disposed || _saving == value) return;
    _saving = value;
    notifyListeners();
  }

  @override
  void dispose() {
    _disposed = true;
    _submitHandler = null;
    super.dispose();
  }
}

class CreatePostEditorScreen extends StatefulWidget {
  final String sportName;
  final bool isEdit;
  final int? postId;
  final String initialTitle;
  final String initialCoverUrl;
  final List<PostBlock> initialBlocks;
  final bool embedded;
  final VoidCallback? onClose;
  final VoidCallback? onSaved;
  final int teamId;
  final int clubId;
  final String teamName;
  final String authorLabel;
  final bool pressMode;
  final String visibility;

  /// For visibility=club_internal. Empty list means whole club.
  final List<int> targetTeamIds;
  final List<Map<String, dynamic>> availableTargetTeams;
  final bool allowWholeClubTarget;

  final PostComposerController? composerController;
  final bool hideChrome;
  final bool forceSimpleComposer;

  const CreatePostEditorScreen({
    super.key,
    required this.sportName,
    this.isEdit = false,
    this.postId,
    this.initialTitle = "",
    this.initialCoverUrl = "",
    this.initialBlocks = const [],
    this.embedded = false,
    this.onClose,
    this.onSaved,
    this.teamId = 0,
    this.clubId = 0,
    this.teamName = '',
    this.authorLabel = '',
    this.pressMode = false,
    this.visibility = 'feed',
    this.targetTeamIds = const <int>[],
    this.availableTargetTeams = const <Map<String, dynamic>>[],
    this.allowWholeClubTarget = false,
    this.composerController,
    this.hideChrome = false,
    this.forceSimpleComposer = false,
  });

  @override
  State<CreatePostEditorScreen> createState() => _CreatePostEditorScreenState();
}

class _CreatePostEditorScreenState extends State<CreatePostEditorScreen> {
  static const _apiBase = "https://sportotekaapp.ru/api";

  final _title = TextEditingController();
  final _caption = TextEditingController();
  bool _saving = false;
  bool _showBlockLibrary = false;
  bool _showAdvancedMobileEditor = false;

  late List<PostBlock> _blocks;

  final Map<int, TextEditingController> _pressTextControllers =
      <int, TextEditingController>{};

  String _coverUrl = "";
  File? _newCoverFile;

  int _userId = 0;

  bool _targetWholeClub = false;
  final Set<int> _selectedTargetTeamIds = <int>{};

  bool get _internalNewsMode =>
      widget.visibility.trim().toLowerCase() == 'club_internal';

  final RegExp _urlRegExp = RegExp(
    r'((https?:\/\/)|(www\.))([^\s]+)',
    caseSensitive: false,
  );

  @override
  void initState() {
    super.initState();
    _title.text = widget.initialTitle;
    _blocks = List<PostBlock>.from(widget.initialBlocks);
    _caption.text = _plainCaptionFromBlocks(_blocks);
    _coverUrl = widget.initialCoverUrl;
    _selectedTargetTeamIds.addAll(
      widget.targetTeamIds.where((id) => id > 0),
    );
    _targetWholeClub = _internalNewsMode && _selectedTargetTeamIds.isEmpty;
    if (_internalNewsMode &&
        !_targetWholeClub &&
        _selectedTargetTeamIds.isEmpty &&
        widget.availableTargetTeams.isNotEmpty) {
      final firstId = _targetTeamId(widget.availableTargetTeams.first);
      if (firstId > 0) _selectedTargetTeamIds.add(firstId);
    }
    if (_internalNewsMode &&
        _targetWholeClub &&
        !widget.allowWholeClubTarget &&
        widget.availableTargetTeams.isNotEmpty) {
      _targetWholeClub = false;
      final firstId = _targetTeamId(widget.availableTargetTeams.first);
      if (firstId > 0) _selectedTargetTeamIds.add(firstId);
    }
    widget.composerController?._attach(_save);
    _initUser();
  }

  @override
  void didUpdateWidget(covariant CreatePostEditorScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.composerController != widget.composerController) {
      oldWidget.composerController?._detach();
      widget.composerController?._attach(_save);
    }
  }

  Future<void> _initUser() async {
    final uid = await PrefUtils.getUserId() ?? 0;
    if (!mounted) return;
    setState(() => _userId = uid);
  }

  @override
  void dispose() {
    widget.composerController?._detach();
    for (final controller in _pressTextControllers.values) {
      controller.dispose();
    }
    _pressTextControllers.clear();
    _title.dispose();
    _caption.dispose();
    super.dispose();
  }

  String _plainCaptionFromBlocks(List<PostBlock> blocks) {
    return blocks
        .whereType<TextBlock>()
        .map((b) => b.text.trim())
        .where((text) => text.isNotEmpty)
        .join('\n\n');
  }

  void _syncCaptionToBlocks() {
    final caption = _caption.text.trim();
    final mediaBlocks = _blocks.where((b) => b is! TextBlock).toList();
    _blocks = <PostBlock>[
      if (caption.isNotEmpty) TextBlock(caption),
      ...mediaBlocks,
    ];
  }

  void _syncCaptionFromBlocks() {
    final text = _plainCaptionFromBlocks(_blocks);
    _caption.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
  }

  void _insertHashtag(String hashtag) {
    final current = _caption.text;
    final needsSpace = current.isNotEmpty && !current.endsWith(' ');
    final updated = '$current${needsSpace ? ' ' : ''}$hashtag ';
    _caption.value = TextEditingValue(
      text: updated,
      selection: TextSelection.collapsed(offset: updated.length),
    );
    setState(() {});
  }

  TextEditingController _pressTextController(int index, String initialText) {
    final existing = _pressTextControllers[index];
    if (existing != null) return existing;

    final controller = TextEditingController(text: initialText);
    controller.selection =
        TextSelection.collapsed(offset: controller.text.length);
    _pressTextControllers[index] = controller;
    return controller;
  }

  void _resetPressTextControllers() {
    for (final controller in _pressTextControllers.values) {
      controller.dispose();
    }
    _pressTextControllers.clear();
  }

  void _insertEmojiIntoPressText(int index, String emoji) {
    if (index < 0 || index >= _blocks.length) return;
    final block = _blocks[index];
    if (block is! TextBlock) return;

    final controller = _pressTextController(index, block.text);
    final selection = controller.selection;
    final start = selection.isValid
        ? selection.start.clamp(0, controller.text.length).toInt()
        : controller.text.length;
    final end = selection.isValid
        ? selection.end.clamp(0, controller.text.length).toInt()
        : controller.text.length;

    final updated = controller.text.replaceRange(start, end, emoji);
    controller.value = TextEditingValue(
      text: updated,
      selection: TextSelection.collapsed(offset: start + emoji.length),
    );
    _blocks[index] = block.copyWith(text: updated);
    if (mounted) setState(() {});
  }

  Future<void> _showPressEmojiPicker(int index) async {
    const emojis = <String>[
      '⚽',
      '🔥',
      '💚',
      '👏',
      '💪',
      '🏆',
      '🥇',
      '🎯',
      '⭐',
      '🚀',
      '✅',
      '📣',
      '📸',
      '🎥',
      '🙌',
      '😊',
      '😎',
      '🤝',
      '❤️',
      '🟢',
      '⚡',
      '🎉',
      '💥',
      '👊',
    ];

    final selected = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: false,
      builder: (sheetContext) {
        final width = MediaQuery.sizeOf(sheetContext).width;
        final horizontal = width < 600 ? 12.0 : 18.0;

        return SafeArea(
          child: Container(
            margin: EdgeInsets.fromLTRB(horizontal, 0, horizontal, 10),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 16),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.08),
                  blurRadius: 24,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _brandDots(),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'Добавить смайлик',
                        style: _editorText(
                          12.4,
                          weight: FontWeight.w600,
                          color: const Color(0xFF0B0F14),
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Закрыть',
                      onPressed: () => Navigator.pop(sheetContext),
                      icon: const Icon(Icons.close_rounded, size: 18),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 7,
                  runSpacing: 7,
                  children: [
                    for (final emoji in emojis)
                      Material(
                        color: const Color(0xFFF7F9F8),
                        borderRadius: BorderRadius.circular(10),
                        child: InkWell(
                          onTap: () => Navigator.pop(sheetContext, emoji),
                          borderRadius: BorderRadius.circular(10),
                          child: SizedBox(
                            width: 44,
                            height: 42,
                            child: Center(
                              child: Text(
                                emoji,
                                style: const TextStyle(fontSize: 22),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 9),
                Text(
                  'Можно также использовать системную клавиатуру emoji — символы сохраняются вместе с текстом.',
                  style: _editorText(
                    9.5,
                    color: const Color(0xFF8A9099),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );

    if (selected != null && selected.isNotEmpty) {
      _insertEmojiIntoPressText(index, selected);
    }
  }

  void _snack(String t) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(t)),
    );
  }

  bool _isValidUrl(String input) {
    final uri = Uri.tryParse(input.trim());
    return uri != null &&
        (uri.scheme.toLowerCase() == 'http' ||
            uri.scheme.toLowerCase() == 'https');
  }

  String _normalizeUrl(String url) {
    final trimmed = url.trim();
    if (trimmed.isEmpty) return trimmed;
    if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) {
      return trimmed;
    }
    return "https://$trimmed";
  }

  bool _looksLikeDirectVideoUrl(String url) {
    final clean = url.toLowerCase().split('?').first.split('#').first;
    return clean.endsWith(".mp4") ||
        clean.endsWith(".mov") ||
        clean.endsWith(".m4v") ||
        clean.endsWith(".webm") ||
        clean.endsWith(".m3u8");
  }

  bool _looksLikeExternalVideoPage(String url) {
    final u = url.toLowerCase();
    return u.contains("youtube.com/") ||
        u.contains("youtu.be/") ||
        u.contains("vimeo.com/") ||
        u.contains("rutube.ru/") ||
        u.contains("vkvideo.ru/") ||
        u.contains("vk.com/video") ||
        u.contains("dailymotion.com/") ||
        u.contains("tiktok.com/") ||
        u.contains("drive.google.com/") ||
        u.contains("dropbox.com/");
  }

  String? _tryBuildAutoThumbnail(String url) {
    try {
      final uri = Uri.parse(url);

      if (uri.host.contains("youtu.be")) {
        if (uri.pathSegments.isNotEmpty) {
          final id = uri.pathSegments.first.trim();
          if (id.isNotEmpty) {
            return "https://img.youtube.com/vi/$id/hqdefault.jpg";
          }
        }
      }

      if (uri.host.contains("youtube.com")) {
        final v = uri.queryParameters["v"];
        if (v != null && v.trim().isNotEmpty) {
          return "https://img.youtube.com/vi/${v.trim()}/hqdefault.jpg";
        }

        final segments = uri.pathSegments;
        final shortsIndex = segments.indexOf("shorts");
        if (shortsIndex != -1 && shortsIndex + 1 < segments.length) {
          final id = segments[shortsIndex + 1].trim();
          if (id.isNotEmpty) {
            return "https://img.youtube.com/vi/$id/hqdefault.jpg";
          }
        }

        final embedIndex = segments.indexOf("embed");
        if (embedIndex != -1 && embedIndex + 1 < segments.length) {
          final id = segments[embedIndex + 1].trim();
          if (id.isNotEmpty) {
            return "https://img.youtube.com/vi/$id/hqdefault.jpg";
          }
        }
      }
    } catch (_) {}

    return null;
  }

  Future<void> _openUrl(String url) async {
    final normalized = _normalizeUrl(url);
    final uri = Uri.tryParse(normalized);
    if (uri == null) {
      _snack("Некорректная ссылка");
      return;
    }

    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      _snack("Не удалось открыть ссылку");
    }
  }

  InputDecoration _fieldDecoration(String hint) {
    return InputDecoration(
      hintText: hint,
      hintStyle: _editorText(
        10.6,
        color: const Color(0xFF98A2B3),
      ),
      filled: true,
      fillColor: const Color(0xFFF7F9F8),
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 11,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(9),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(9),
        borderSide: BorderSide.none,
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(9),
        borderSide: BorderSide.none,
      ),
    );
  }

  Future<bool?> _showEditorSheet({
    required String title,
    required Widget content,
    required String buttonText,
  }) {
    return showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) {
        return SafeArea(
          child: Container(
            margin: const EdgeInsets.fromLTRB(8, 0, 8, 8),
            padding: EdgeInsets.fromLTRB(
              14,
              12,
              14,
              14 + MediaQuery.of(context).viewInsets.bottom,
            ),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(14),
                bottom: Radius.circular(14),
              ),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    _brandDots(),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        title,
                        style: _editorText(
                          13.2,
                          weight: FontWeight.w600,
                          color: const Color(0xFF0B0F14),
                        ),
                      ),
                    ),
                    IconButton(
                      tooltip: 'Закрыть',
                      onPressed: () => Navigator.pop(context, false),
                      icon: const Icon(Icons.close_rounded, size: 18),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                content,
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: FilledButton(
                    onPressed: () => Navigator.pop(context, true),
                    style: FilledButton.styleFrom(
                      elevation: 0,
                      backgroundColor: const Color(0xFF00A750),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 14,
                        vertical: 11,
                      ),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(9),
                      ),
                    ),
                    child: Text(
                      buttonText,
                      style: _editorText(
                        10.8,
                        weight: FontWeight.w600,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _addTextBlock() async {
    // В пресс-службе текст редактируется прямо в карточке публикации:
    // без отдельного bottom sheet / modal editor.
    if (widget.pressMode) {
      setState(() {
        _showBlockLibrary = false;
        _blocks.add(const TextBlock(''));
      });
      return;
    }

    final ctrl = TextEditingController();

    final ok = await _showEditorSheet(
      title: "Текст",
      buttonText: "Добавить",
      content: TextField(
        controller: ctrl,
        maxLines: 8,
        minLines: 4,
        decoration: _fieldDecoration("Напишите текст…"),
      ),
    );

    if (ok == true) {
      final text = ctrl.text.trim();
      if (text.isNotEmpty) {
        setState(() => _blocks.add(TextBlock(text)));
      }
    }
  }

  Future<void> _addImageBlock() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
    );
    if (x == null) return;

    final file = File(x.path);
    final url = await _uploadPostImage(file);
    if (url == null) return;

    setState(() => _blocks.add(ImageBlock(url)));
  }

  Future<void> _addLinkBlock() async {
    final titleCtrl = TextEditingController();
    final urlCtrl = TextEditingController();

    final ok = await _showEditorSheet(
      title: "Добавить ссылку",
      buttonText: "Добавить",
      content: Column(
        children: [
          TextField(
            controller: titleCtrl,
            decoration: _fieldDecoration("Название ссылки (по желанию)"),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: urlCtrl,
            keyboardType: TextInputType.url,
            decoration: _fieldDecoration("https://example.com"),
          ),
        ],
      ),
    );

    if (ok == true) {
      final url = _normalizeUrl(urlCtrl.text);
      final title = titleCtrl.text.trim();

      if (!_isValidUrl(url)) {
        _snack("Введите корректную ссылку");
        return;
      }

      setState(() {
        _blocks.add(LinkBlock(url: url, title: title));
      });
    }
  }

  Future<Map<String, String>?> _uploadPostVideo(File file) async {
    try {
      final req = http.MultipartRequest(
        "POST",
        Uri.parse("$_apiBase/upload_post_video.php"),
      );

      req.fields["user_id"] = _userId.toString();
      req.files.add(await http.MultipartFile.fromPath("video", file.path));

      final res = await req.send();
      final body = await res.stream.bytesToString();

      if (res.statusCode != 200) {
        _snack("Ошибка загрузки видео: HTTP ${res.statusCode}");
        return null;
      }

      final j = json.decode(body);
      if (j is! Map || j["success"] != true) {
        _snack("Ошибка загрузки видео: $body");
        return null;
      }

      final url = (j["url"] ?? "").toString();
      final thumbnail = (j["thumbnail"] ?? "").toString();

      if (url.isEmpty) {
        _snack("Сервер не вернул ссылку на видео");
        return null;
      }

      return {
        "url": url,
        "thumbnail": thumbnail,
      };
    } catch (e) {
      _snack("Ошибка загрузки видео: $e");
      return null;
    }
  }

  Future<void> _pickAndUploadVideo() async {
    if (_userId <= 0) {
      _snack("Не найден user_id");
      return;
    }

    final picker = ImagePicker();
    final x = await picker.pickVideo(source: ImageSource.gallery);
    if (x == null) return;

    final file = File(x.path);

    setState(() => _saving = true);
    widget.composerController?._setSaving(true);

    try {
      final uploaded = await _uploadPostVideo(file);
      if (uploaded == null) return;

      final title = p.basenameWithoutExtension(file.path);

      setState(() {
        _blocks.add(
          VideoBlock(
            url: uploaded["url"] ?? "",
            title: title,
            thumbnail: uploaded["thumbnail"] ?? "",
          ),
        );
      });
    } finally {
      widget.composerController?._setSaving(false);
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _addVideoBlock() async {
    await showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (_) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 46,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFE5E7EB),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    "Добавить видео",
                    style: AppTypography.screenTitle(),
                  ),
                ),
                const SizedBox(height: 12),
                _addMenuTile(
                  icon: Icons.link,
                  title: "Видео по ссылке",
                  subtitle: "Ссылка на видео или страницу с видео",
                  onTap: () async {
                    Navigator.pop(context);

                    final titleCtrl = TextEditingController();
                    final urlCtrl = TextEditingController();
                    final thumbCtrl = TextEditingController();

                    final ok = await _showEditorSheet(
                      title: "Добавить видео по ссылке",
                      buttonText: "Добавить",
                      content: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          TextField(
                            controller: titleCtrl,
                            decoration: _fieldDecoration(
                              "Название видео (по желанию)",
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: urlCtrl,
                            keyboardType: TextInputType.url,
                            decoration: _fieldDecoration(
                              "https://site.com/video или https://site.com/video.mp4",
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: thumbCtrl,
                            keyboardType: TextInputType.url,
                            decoration: _fieldDecoration(
                              "Ссылка на превью (по желанию)",
                            ),
                          ),
                          const SizedBox(height: 10),
                          Text(
                            "Можно добавить ссылку с любого источника. Если это прямая ссылка на видеофайл, такое видео можно использовать внутри поста. Если это страница с видео, она будет открываться отдельно.",
                            style: AppTypography.secondaryMedium(
                              color: Colors.grey.shade700,
                            ),
                          ),
                        ],
                      ),
                    );

                    if (ok == true) {
                      final url = _normalizeUrl(urlCtrl.text);
                      final title = titleCtrl.text.trim();
                      String thumb = _normalizeUrl(thumbCtrl.text);

                      if (!_isValidUrl(url)) {
                        _snack("Введите корректную ссылку");
                        return;
                      }

                      if (thumbCtrl.text.trim().isEmpty) {
                        thumb = _tryBuildAutoThumbnail(url) ?? "";
                      } else if (!_isValidUrl(thumb)) {
                        _snack("Некорректная ссылка на превью");
                        return;
                      }

                      setState(() {
                        _blocks.add(
                          VideoBlock(
                            url: url,
                            title: title,
                            thumbnail: thumb,
                          ),
                        );
                      });
                    }
                  },
                ),
                _addMenuTile(
                  icon: Icons.video_library_outlined,
                  title: "Загрузить видео",
                  subtitle: "Выбрать видео из галереи телефона",
                  onTap: () {
                    Navigator.pop(context);
                    _pickAndUploadVideo();
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _editTextBlock(int i, TextBlock b) async {
    // В pressMode TextBlock уже является inline-редактором.
    if (widget.pressMode) return;

    final ctrl = TextEditingController(text: b.text);

    final ok = await _showEditorSheet(
      title: "Редактировать текст",
      buttonText: "Сохранить",
      content: TextField(
        controller: ctrl,
        maxLines: 10,
        minLines: 5,
        decoration: _fieldDecoration("Введите текст"),
      ),
    );

    if (ok == true) {
      final t = ctrl.text.trim();
      setState(() => _blocks[i] = b.copyWith(text: t));
    }
  }

  Future<void> _editLinkBlock(int i, LinkBlock b) async {
    final titleCtrl = TextEditingController(text: b.title);
    final urlCtrl = TextEditingController(text: b.url);

    final ok = await _showEditorSheet(
      title: "Редактировать ссылку",
      buttonText: "Сохранить",
      content: Column(
        children: [
          TextField(
            controller: titleCtrl,
            decoration: _fieldDecoration("Название ссылки"),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: urlCtrl,
            keyboardType: TextInputType.url,
            decoration: _fieldDecoration("https://example.com"),
          ),
        ],
      ),
    );

    if (ok == true) {
      final url = _normalizeUrl(urlCtrl.text);
      final title = titleCtrl.text.trim();

      if (!_isValidUrl(url)) {
        _snack("Введите корректную ссылку");
        return;
      }

      setState(() {
        _blocks[i] = LinkBlock(url: url, title: title);
      });
    }
  }

  Future<void> _editVideoBlock(int i, VideoBlock b) async {
    final titleCtrl = TextEditingController(text: b.title);
    final urlCtrl = TextEditingController(text: b.url);
    final thumbCtrl = TextEditingController(text: b.thumbnail);

    final ok = await _showEditorSheet(
      title: "Редактировать видео",
      buttonText: "Сохранить",
      content: Column(
        children: [
          TextField(
            controller: titleCtrl,
            decoration: _fieldDecoration("Название видео"),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: urlCtrl,
            keyboardType: TextInputType.url,
            decoration: _fieldDecoration(
              "https://site.com/video или https://site.com/video.mp4",
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: thumbCtrl,
            keyboardType: TextInputType.url,
            decoration: _fieldDecoration("Ссылка на превью"),
          ),
        ],
      ),
    );

    if (ok == true) {
      final url = _normalizeUrl(urlCtrl.text);
      final title = titleCtrl.text.trim();
      String thumb = _normalizeUrl(thumbCtrl.text);

      if (!_isValidUrl(url)) {
        _snack("Введите корректную ссылку");
        return;
      }

      if (thumbCtrl.text.trim().isEmpty) {
        thumb = _tryBuildAutoThumbnail(url) ?? "";
      } else if (!_isValidUrl(thumb)) {
        _snack("Некорректная ссылка на превью");
        return;
      }

      setState(() {
        _blocks[i] = VideoBlock(
          url: url,
          title: title,
          thumbnail: thumb,
        );
      });
    }
  }

  void _moveUp(int i) {
    if (i <= 0) return;
    _resetPressTextControllers();
    setState(() {
      final tmp = _blocks[i - 1];
      _blocks[i - 1] = _blocks[i];
      _blocks[i] = tmp;
    });
  }

  void _moveDown(int i) {
    if (i >= _blocks.length - 1) return;
    _resetPressTextControllers();
    setState(() {
      final tmp = _blocks[i + 1];
      _blocks[i + 1] = _blocks[i];
      _blocks[i] = tmp;
    });
  }

  void _deleteBlock(int i) {
    _resetPressTextControllers();
    setState(() => _blocks.removeAt(i));
  }

  Future<void> _showAddBlockMenu() async {
    if (!mounted) return;
    setState(() => _showBlockLibrary = !_showBlockLibrary);
  }

  Widget _blockLibrary() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF3FAF6),
        borderRadius: BorderRadius.circular(9),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final twoColumns = constraints.maxWidth >= 390;
          final width = twoColumns
              ? (constraints.maxWidth - 6) / 2
              : constraints.maxWidth;

          final items = <Widget>[
            _blockTool(
              width: width,
              icon: Icons.text_fields_rounded,
              title: widget.pressMode ? 'Редактор текста' : 'Текст',
              subtitle: widget.pressMode
                  ? 'Редактировать прямо в публикации'
                  : 'Текстовый блок',
              accent: const Color(0xFF00A750),
              onTap: () {
                setState(() => _showBlockLibrary = false);
                _addTextBlock();
              },
            ),
            _blockTool(
              width: width,
              icon: Icons.photo_outlined,
              title: 'Фото',
              subtitle: 'Изображение',
              accent: const Color(0xFFF59E0B),
              onTap: () {
                setState(() => _showBlockLibrary = false);
                _addImageBlock();
              },
            ),
            _blockTool(
              width: width,
              icon: Icons.link_rounded,
              title: 'Ссылка',
              subtitle: 'Сайт или страница',
              accent: const Color(0xFF067A46),
              onTap: () {
                setState(() => _showBlockLibrary = false);
                _addLinkBlock();
              },
            ),
            _blockTool(
              width: width,
              icon: Icons.play_circle_outline_rounded,
              title: 'Видео',
              subtitle: 'Ссылка или файл',
              accent: const Color(0xFFF59E0B),
              onTap: () {
                setState(() => _showBlockLibrary = false);
                _addVideoBlock();
              },
            ),
          ];

          return Wrap(
            spacing: 6,
            runSpacing: 6,
            children: items,
          );
        },
      ),
    );
  }

  Widget _blockTool({
    required double width,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color accent,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: width,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 9,
              vertical: 9,
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _softForAccent(accent),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    icon,
                    size: 16,
                    color: accent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          _statusDot(
                            color: accent,
                            size: 4.5,
                            glow: false,
                          ),
                          const SizedBox(width: 6),
                          Expanded(
                            child: Text(
                              title,
                              style: _editorText(
                                10.4,
                                weight: FontWeight.w600,
                                color: const Color(0xFF0B0F14),
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _editorText(9.2),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _addMenuTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(9),
      child: Container(
        margin: const EdgeInsets.only(bottom: 6),
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: const Color(0xFFF7F9F8),
          borderRadius: BorderRadius.circular(9),
        ),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: const Color(0x1400A750),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: const Color(0xFF00A750)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: _editorText(
                      10.8,
                      weight: FontWeight.w600,
                      color: const Color(0xFF0B0F14),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: _editorText(9.6),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickCover() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 90,
    );
    if (x == null) return;
    setState(() => _newCoverFile = File(x.path));
  }

  Future<String?> _uploadPostImage(File file) async {
    try {
      final req = http.MultipartRequest(
        "POST",
        Uri.parse("$_apiBase/upload_post_image.php"),
      );
      req.fields["user_id"] = _userId.toString();
      req.files.add(await http.MultipartFile.fromPath("image", file.path));

      final res = await req.send();
      final body = await res.stream.bytesToString();

      if (res.statusCode != 200) {
        _snack("Ошибка загрузки фото: HTTP ${res.statusCode}");
        return null;
      }

      final j = json.decode(body);
      if (j is! Map || j["success"] != true) {
        _snack("Ошибка загрузки фото: $body");
        return null;
      }

      final url = (j["url"] ?? "").toString();
      if (url.isEmpty) {
        _snack("Не пришёл url картинки");
        return null;
      }
      return url;
    } catch (e) {
      _snack("Ошибка загрузки фото: $e");
      return null;
    }
  }

  int _targetTeamId(Map<String, dynamic> team) {
    final raw = team['id'] ?? team['team_id'] ?? team['teamId'];
    if (raw is int) return raw;
    if (raw is num) return raw.toInt();
    return int.tryParse('${raw ?? ''}'.trim()) ?? 0;
  }

  String _targetTeamName(Map<String, dynamic> team) {
    final value = '${team['name'] ?? team['team_name'] ?? team['teamName'] ?? ''}'.trim();
    return value.isEmpty || value == 'null' ? 'Команда' : value;
  }

  String _targetTeamNameById(int id) {
    for (final team in widget.availableTargetTeams) {
      if (_targetTeamId(team) == id) return _targetTeamName(team);
    }
    return '';
  }

  List<int> get _effectiveTargetTeamIds {
    if (!_internalNewsMode || _targetWholeClub) return const <int>[];
    final ids = _selectedTargetTeamIds.where((id) => id > 0).toList()..sort();
    return ids;
  }

  void _applyPublicationContext(http.MultipartRequest req) {
    if (widget.pressMode) {
      req.fields['press_mode'] = '1';
      req.fields['workspace'] = 'press';
    }

    if (widget.clubId > 0) req.fields['club_id'] = widget.clubId.toString();
    if (widget.authorLabel.trim().isNotEmpty) {
      req.fields['author'] = widget.authorLabel.trim();
    }

    final visibility = widget.visibility.trim().isEmpty
        ? 'feed'
        : widget.visibility.trim();
    req.fields['visibility'] = visibility;

    if (_internalNewsMode) {
      final ids = _effectiveTargetTeamIds;
      req.fields['target_team_ids'] = jsonEncode(ids);
      if (ids.length == 1) {
        final id = ids.first;
        req.fields['team_id'] = id.toString();
        final name = _targetTeamNameById(id);
        req.fields['team'] = name;
      } else {
        req.fields['team_id'] = '0';
        req.fields['team'] = '';
      }
      return;
    }

    req.fields['team_id'] = widget.teamId.toString();
    req.fields['team'] = widget.teamName;
  }

  Widget _buildInternalAudienceSelector() {
    final ids = _effectiveTargetTeamIds;
    final status = _targetWholeClub
        ? 'Весь клуб'
        : ids.isEmpty
            ? 'Не выбрано'
            : ids.length == 1
                ? (_targetTeamNameById(ids.first).isEmpty
                    ? '1 команда'
                    : _targetTeamNameById(ids.first))
                : '${ids.length} команды';

    Widget audiencePill({
      required String label,
      required bool selected,
      required VoidCallback? onTap,
      IconData? icon,
    }) {
      return Material(
        color: selected
            ? const Color(0xFFF3FAF6)
            : const Color(0xFFF7F9F8),
        borderRadius: BorderRadius.circular(999),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(999),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOutCubic,
            constraints: const BoxConstraints(minHeight: 36),
            padding: const EdgeInsets.symmetric(
              horizontal: 11,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              border: Border.all(
                color: selected
                    ? const Color(0xFFD7F0E2)
                    : const Color(0xFFE9ECEA),
                width: .7,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                if (icon != null) ...[
                  Icon(
                    icon,
                    size: 15,
                    color: selected
                        ? const Color(0xFF067A46)
                        : const Color(0xFF667085),
                  ),
                  const SizedBox(width: 6),
                ],
                if (selected) ...[
                  const Icon(
                    Icons.check_rounded,
                    size: 14,
                    color: Color(0xFF067A46),
                  ),
                  const SizedBox(width: 5),
                ],
                Text(
                  label,
                  style: _editorText(
                    10.2,
                    weight: selected ? FontWeight.w600 : FontWeight.w500,
                    color: selected
                        ? const Color(0xFF067A46)
                        : const Color(0xFF374151),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return _editorSection(
      title: 'Получатели',
      subtitle: 'Эта новость не попадёт в общую Community-ленту',
      dotColor: (_targetWholeClub || ids.isNotEmpty)
          ? const Color(0xFF00A750)
          : const Color(0xFFD92D20),
      statusText: status,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: [
              if (widget.allowWholeClubTarget)
                audiencePill(
                  label: 'Весь клуб',
                  icon: Icons.apartment_rounded,
                  selected: _targetWholeClub,
                  onTap: _saving
                      ? null
                      : () {
                          setState(() {
                            _targetWholeClub = true;
                            _selectedTargetTeamIds.clear();
                          });
                        },
                ),
              for (final team in widget.availableTargetTeams)
                Builder(
                  builder: (_) {
                    final id = _targetTeamId(team);
                    final selected = _selectedTargetTeamIds.contains(id);
                    return audiencePill(
                      label: _targetTeamName(team),
                      icon: Icons.groups_2_outlined,
                      selected: selected,
                      onTap: _saving || id <= 0
                          ? null
                          : () {
                              setState(() {
                                _targetWholeClub = false;
                                if (selected) {
                                  _selectedTargetTeamIds.remove(id);
                                } else {
                                  _selectedTargetTeamIds.add(id);
                                }
                              });
                            },
                    );
                  },
                ),
            ],
          ),
          if (!widget.allowWholeClubTarget &&
              widget.availableTargetTeams.isEmpty) ...[
            const SizedBox(height: 8),
            Text(
              'Нет доступных команд для публикации.',
              style: _editorText(10.2, color: const Color(0xFFD92D20)),
            ),
          ],
        ],
      ),
    );
  }

  Future<void> _save() async {
    if (_saving) return;
    final isSimpleMobile = (widget.forceSimpleComposer ||
            MediaQuery.sizeOf(context).width < 600) &&
        !_showAdvancedMobileEditor &&
        !widget.pressMode;
    if (isSimpleMobile) {
      _syncCaptionToBlocks();
    }
    if (_userId <= 0) {
      _snack("Не найден user_id");
      return;
    }
    if (_internalNewsMode &&
        !_targetWholeClub &&
        _effectiveTargetTeamIds.isEmpty) {
      _snack("Выберите хотя бы одну команду");
      return;
    }
    if (_internalNewsMode &&
        _targetWholeClub &&
        !widget.allowWholeClubTarget) {
      _snack("Нет права публикации для всего клуба");
      return;
    }

    final title = _title.text.trim();
    final htmlBody = PostHtmlParser.blocksToHtml(_blocks);

    if (title.isEmpty &&
        htmlBody.isEmpty &&
        _newCoverFile == null &&
        _coverUrl.trim().isEmpty) {
      _snack("Пустой пост");
      return;
    }

    setState(() => _saving = true);
    widget.composerController?._setSaving(true);

    try {
      if (widget.isEdit) {
        if ((widget.postId ?? 0) <= 0) {
          _snack("postId не передан");
          return;
        }

        final req = http.MultipartRequest(
          "POST",
          Uri.parse("$_apiBase/update_post.php"),
        );
        req.fields["post_id"] = widget.postId.toString();
        req.fields["user_id"] = _userId.toString();
        req.fields["title"] = title;
        req.fields["body"] = htmlBody;
        _applyPublicationContext(req);

        if (_newCoverFile != null) {
          req.files.add(
            await http.MultipartFile.fromPath("image", _newCoverFile!.path),
          );
        }

        final res = await req.send();
        final body = await res.stream.bytesToString();

        if (res.statusCode != 200) {
          _snack("Ошибка сохранения: HTTP ${res.statusCode}");
          return;
        }

        final j = json.decode(body);
        final ok = (j is Map) && (j["success"] == true || j["status"] == "ok");
        if (!ok) {
          _snack("Ошибка: $body");
          return;
        }

        if (!mounted) return;
        _finishEditor(saved: true);
        return;
      }

      final req = http.MultipartRequest(
        "POST",
        Uri.parse("$_apiBase/insert_post.php"),
      );
      req.fields["title"] = title;
      req.fields["body"] = htmlBody;
      req.fields["category"] = widget.sportName;
      req.fields["team"] = widget.teamName.trim();
      req.fields["author"] = widget.authorLabel.trim();
      req.fields["user_id"] = _userId.toString();
      _applyPublicationContext(req);
      req.fields["post_type"] = "post";

      if (_newCoverFile != null) {
        req.files.add(
          await http.MultipartFile.fromPath("image", _newCoverFile!.path),
        );
      }

      final res = await req.send();
      final body = await res.stream.bytesToString();

      if (res.statusCode != 200) {
        _snack("Ошибка публикации: HTTP ${res.statusCode}");
        return;
      }

      final j = json.decode(body);
      final ok = (j is Map) &&
          (j["success"] == true || j["status"] == "ok" || j["created"] == true);
      if (!ok) {
        _snack("Ошибка: $body");
        return;
      }

      if (!mounted) return;
      _finishEditor(saved: true);
    } catch (e) {
      _snack("Ошибка: $e");
    } finally {
      widget.composerController?._setSaving(false);
      if (mounted) setState(() => _saving = false);
    }
  }

  List<InlineSpan> _buildTextSpans(String text) {
    final spans = <InlineSpan>[];
    final matches = _urlRegExp.allMatches(text);

    int current = 0;

    for (final match in matches) {
      if (match.start > current) {
        spans.add(
          TextSpan(
            text: text.substring(current, match.start),
            style: AppTypography.body(
              color: const Color(0xFF1A1A1A),
            ).copyWith(
              height: 1.45,
              fontWeight: FontWeight.w500,
            ),
          ),
        );
      }

      final rawUrl = text.substring(match.start, match.end);
      final normalized = _normalizeUrl(rawUrl);

      spans.add(
        TextSpan(
          text: rawUrl,
          style: AppTypography.bodyMedium(
            color: Colors.blue,
          ).copyWith(
            decoration: TextDecoration.underline,
            height: 1.45,
          ),
          recognizer: TapGestureRecognizer()
            ..onTap = () {
              _openUrl(normalized);
            },
        ),
      );

      current = match.end;
    }

    if (current < text.length) {
      spans.add(
        TextSpan(
          text: text.substring(current),
          style: AppTypography.body(
            color: const Color(0xFF1A1A1A),
          ).copyWith(
            height: 1.45,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
    }

    if (spans.isEmpty) {
      spans.add(
        TextSpan(
          text: text,
          style: AppTypography.body(
            color: const Color(0xFF1A1A1A),
          ).copyWith(
            height: 1.45,
            fontWeight: FontWeight.w500,
          ),
        ),
      );
    }

    return spans;
  }


  TextAlign _pressTextAlign(String value) {
    switch (value) {
      case 'center':
        return TextAlign.center;
      case 'right':
        return TextAlign.right;
      case 'justify':
        return TextAlign.justify;
      default:
        return TextAlign.left;
    }
  }

  TextStyle _pressTextBlockStyle(TextBlock block) {
    final decorations = <TextDecoration>[];
    if (block.underline) decorations.add(TextDecoration.underline);
    if (block.strike) decorations.add(TextDecoration.lineThrough);

    return AppTypography.body(
      color: Color(block.colorValue),
    ).copyWith(
      fontSize: block.fontSize,
      height: 1.42,
      fontWeight: block.bold ? FontWeight.w700 : FontWeight.w500,
      fontStyle: block.italic ? FontStyle.italic : FontStyle.normal,
      decoration: decorations.isEmpty
          ? TextDecoration.none
          : TextDecoration.combine(decorations),
      decorationColor: Color(block.colorValue),
    );
  }

  void _updatePressTextBlock(
    int index,
    TextBlock block, {
    double? fontSize,
    bool? bold,
    bool? italic,
    bool? underline,
    bool? strike,
    String? align,
    int? colorValue,
    bool reset = false,
  }) {
    if (index < 0 || index >= _blocks.length) return;
    final current = _blocks[index] is TextBlock
        ? _blocks[index] as TextBlock
        : block;

    setState(() {
      _blocks[index] = reset
          ? TextBlock(current.text)
          : current.copyWith(
              fontSize: fontSize,
              bold: bold,
              italic: italic,
              underline: underline,
              strike: strike,
              align: align,
              colorValue: colorValue,
            );
    });
  }

  Widget _pressFormatButton({
    required IconData icon,
    required String tooltip,
    required VoidCallback onTap,
    bool active = false,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: active ? const Color(0xFFEAF7F0) : Colors.transparent,
        borderRadius: BorderRadius.circular(7),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(7),
          child: SizedBox(
            width: 34,
            height: 34,
            child: Icon(
              icon,
              size: 17,
              color: active
                  ? const Color(0xFF067A46)
                  : const Color(0xFF4B5563),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPressTextToolbar(TextBlock block, int index) {
    const sizes = <double>[12, 14, 16, 18, 22, 26, 30];
    const colors = <int>[
      0xFF111827,
      0xFF4B5563,
      0xFF067A46,
      0xFF00A750,
      0xFF2563EB,
      0xFFD92D20,
    ];

    return Container(
      height: 42,
      decoration: const BoxDecoration(
        color: Color(0xFFFAFBFA),
        border: Border(
          bottom: BorderSide(color: Color(0xFFE9ECEA), width: .7),
        ),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Row(
          children: [
            PopupMenuButton<double>(
              tooltip: 'Размер шрифта',
              padding: EdgeInsets.zero,
              onSelected: (value) => _updatePressTextBlock(
                index,
                block,
                fontSize: value,
              ),
              itemBuilder: (_) => sizes
                  .map(
                    (size) => PopupMenuItem<double>(
                      value: size,
                      child: Text('${size.toInt()} px'),
                    ),
                  )
                  .toList(),
              child: Container(
                height: 34,
                padding: const EdgeInsets.symmetric(horizontal: 9),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(7),
                  border: Border.all(
                    color: const Color(0xFFE1E5E2),
                    width: .7,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(
                      Icons.format_size_rounded,
                      size: 16,
                      color: Color(0xFF4B5563),
                    ),
                    const SizedBox(width: 5),
                    Text(
                      '${block.fontSize.toInt()}',
                      style: _editorText(
                        9.6,
                        weight: FontWeight.w600,
                        color: const Color(0xFF374151),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 4),
            _pressFormatButton(
              icon: Icons.format_bold_rounded,
              tooltip: 'Жирный',
              active: block.bold,
              onTap: () => _updatePressTextBlock(
                index,
                block,
                bold: !block.bold,
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_italic_rounded,
              tooltip: 'Курсив',
              active: block.italic,
              onTap: () => _updatePressTextBlock(
                index,
                block,
                italic: !block.italic,
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_underlined_rounded,
              tooltip: 'Подчёркивание',
              active: block.underline,
              onTap: () => _updatePressTextBlock(
                index,
                block,
                underline: !block.underline,
              ),
            ),
            _pressFormatButton(
              icon: Icons.strikethrough_s_rounded,
              tooltip: 'Зачёркивание',
              active: block.strike,
              onTap: () => _updatePressTextBlock(
                index,
                block,
                strike: !block.strike,
              ),
            ),
            Container(
              width: 1,
              height: 22,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              color: const Color(0xFFE1E5E2),
            ),
            _pressFormatButton(
              icon: Icons.format_align_left_rounded,
              tooltip: 'По левому краю',
              active: block.align == 'left',
              onTap: () => _updatePressTextBlock(
                index,
                block,
                align: 'left',
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_align_center_rounded,
              tooltip: 'По центру',
              active: block.align == 'center',
              onTap: () => _updatePressTextBlock(
                index,
                block,
                align: 'center',
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_align_right_rounded,
              tooltip: 'По правому краю',
              active: block.align == 'right',
              onTap: () => _updatePressTextBlock(
                index,
                block,
                align: 'right',
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_align_justify_rounded,
              tooltip: 'По ширине',
              active: block.align == 'justify',
              onTap: () => _updatePressTextBlock(
                index,
                block,
                align: 'justify',
              ),
            ),
            Container(
              width: 1,
              height: 22,
              margin: const EdgeInsets.symmetric(horizontal: 4),
              color: const Color(0xFFE1E5E2),
            ),
            PopupMenuButton<int>(
              tooltip: 'Цвет текста',
              padding: EdgeInsets.zero,
              onSelected: (value) => _updatePressTextBlock(
                index,
                block,
                colorValue: value,
              ),
              itemBuilder: (_) => colors
                  .map(
                    (value) => PopupMenuItem<int>(
                      value: value,
                      child: Row(
                        children: [
                          Container(
                            width: 18,
                            height: 18,
                            decoration: BoxDecoration(
                              color: Color(value),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: const Color(0xFFD7DBD8),
                                width: .6,
                              ),
                            ),
                          ),
                          const SizedBox(width: 9),
                          Text(
                            value == 0xFF111827
                                ? 'Основной'
                                : value == 0xFF4B5563
                                    ? 'Графит'
                                    : value == 0xFF067A46
                                        ? 'Зелёный тёмный'
                                        : value == 0xFF00A750
                                            ? 'Зелёный'
                                            : value == 0xFF2563EB
                                                ? 'Синий'
                                                : 'Красный',
                          ),
                        ],
                      ),
                    ),
                  )
                  .toList(),
              child: Container(
                width: 34,
                height: 34,
                alignment: Alignment.center,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    const Icon(
                      Icons.format_color_text_rounded,
                      size: 17,
                      color: Color(0xFF4B5563),
                    ),
                    Positioned(
                      bottom: 5,
                      child: Container(
                        width: 15,
                        height: 3,
                        decoration: BoxDecoration(
                          color: Color(block.colorValue),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            _pressFormatButton(
              icon: Icons.format_clear_rounded,
              tooltip: 'Сбросить форматирование',
              onTap: () => _updatePressTextBlock(
                index,
                block,
                reset: true,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextBlockPreview(TextBlock b, int index) {
    if (widget.pressMode) {
      final controller = _pressTextController(index, b.text);

      return Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: const Color(0xFFE9ECEA),
            width: .7,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildPressTextToolbar(b, index),
            TextField(
              controller: controller,
              autofocus: b.text.trim().isEmpty && index == _blocks.length - 1,
              minLines: 5,
              maxLines: 18,
              keyboardType: TextInputType.multiline,
              textInputAction: TextInputAction.newline,
              textCapitalization: TextCapitalization.sentences,
              enableSuggestions: true,
              autocorrect: true,
              textAlign: _pressTextAlign(b.align),
              style: _pressTextBlockStyle(b),
              onChanged: (value) {
                final current = _blocks[index] is TextBlock
                    ? _blocks[index] as TextBlock
                    : b;
                _blocks[index] = current.copyWith(text: value);
              },
              decoration: InputDecoration(
                hintText: 'Введите текст публикации…',
                hintStyle: _editorText(
                  10.6,
                  color: const Color(0xFF98A2B3),
                ),
                filled: true,
                fillColor: Colors.transparent,
                contentPadding: const EdgeInsets.fromLTRB(12, 12, 4, 12),
                suffixIconConstraints: const BoxConstraints(
                  minWidth: 44,
                  minHeight: 44,
                ),
                suffixIcon: IconButton(
                  tooltip: 'Добавить смайлик',
                  onPressed: _saving ? null : () => _showPressEmojiPicker(index),
                  icon: const Icon(
                    Icons.emoji_emotions_outlined,
                    size: 20,
                    color: Color(0xFF067A46),
                  ),
                ),
                border: InputBorder.none,
                enabledBorder: InputBorder.none,
                focusedBorder: InputBorder.none,
              ),
            ),
          ],
        ),
      );
    }

    return GestureDetector(
      onTap: () => _editTextBlock(index, b),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(2),
        child: RichText(
          text: TextSpan(children: _buildTextSpans(b.text)),
        ),
      ),
    );
  }

  Widget _buildVideoPreview(VideoBlock b, int index) {
    final title = b.title.trim().isEmpty ? "Видео" : b.title;
    final direct = _looksLikeDirectVideoUrl(b.url);
    final externalPage = _looksLikeExternalVideoPage(b.url);

    return InkWell(
      onTap: () => _editVideoBlock(index, b),
      borderRadius: BorderRadius.circular(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (b.thumbnail.trim().isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      b.thumbnail,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey.shade200,
                        child: const Center(child: Icon(Icons.broken_image)),
                      ),
                    ),
                    Container(color: Colors.black.withOpacity(0.20)),
                    const Center(
                      child: CircleAvatar(
                        radius: 26,
                        backgroundColor: Colors.white,
                        child: Icon(
                          Icons.play_arrow,
                          color: Color(0xFF00A750),
                          size: 30,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Container(
              height: 170,
              decoration: BoxDecoration(
                color: const Color(0xFF111827),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Center(
                child: CircleAvatar(
                  radius: 26,
                  backgroundColor: Colors.white,
                  child: Icon(
                    direct ? Icons.play_arrow : Icons.open_in_new,
                    color: const Color(0xFF00A750),
                    size: 30,
                  ),
                ),
              ),
            ),
          const SizedBox(height: 10),
          Text(
            title,
            style: AppTypography.itemTitle(),
          ),
          const SizedBox(height: 8),
          TextButton.icon(
            onPressed: () => _openUrl(b.url),
            icon: const Icon(Icons.open_in_new, size: 18),
            label: Text(
              direct ? "Открыть видео" : "Открыть источник",
              style: AppTypography.action(),
            ),
            style: TextButton.styleFrom(
              padding: EdgeInsets.zero,
              foregroundColor: const Color(0xFF00A750),
              tapTargetSize: MaterialTapTargetSize.shrinkWrap,
              minimumSize: const Size(0, 0),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            direct
                ? "Эта ссылка выглядит как прямой видеофайл."
                : externalPage
                    ? "Видео доступно по внешней ссылке."
                    : "Ссылка добавлена как внешний источник. При необходимости можно указать отдельное превью.",
            style: AppTypography.secondaryMedium(
              color: direct || externalPage
                  ? Colors.green.shade700
                  : Colors.orange.shade800,
            ),
          ),
        ],
      ),
    );
  }

  void _finishEditor({required bool saved}) {
    if (widget.embedded) {
      if (saved) {
        widget.onSaved?.call();
      } else {
        widget.onClose?.call();
      }
      return;
    }
    Navigator.of(context).pop(saved);
  }

  Widget _brandDots({Color color = const Color(0xFF00A750)}) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (final item in const <(double, double)>[
          (3.5, .34),
          (4.5, .48),
          (5.5, .68),
          (6.5, 1.0),
        ]) ...[
          Container(
            width: item.$1,
            height: item.$1,
            decoration: BoxDecoration(
              color: color.withOpacity(item.$2),
              shape: BoxShape.circle,
              boxShadow: item.$2 >= .9
                  ? [
                      BoxShadow(
                        color: color.withOpacity(.16),
                        blurRadius: 8,
                        spreadRadius: 1,
                      ),
                    ]
                  : null,
            ),
          ),
          const SizedBox(width: 3),
        ],
      ],
    );
  }

  Widget _statusDot({
    required Color color,
    double size = 5.5,
    bool glow = true,
  }) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        boxShadow: glow
            ? [
                BoxShadow(
                  color: color.withOpacity(.18),
                  blurRadius: size * 1.9,
                  spreadRadius: .25,
                ),
                BoxShadow(
                  color: color.withOpacity(.08),
                  blurRadius: size * 3.0,
                  spreadRadius: .5,
                ),
              ]
            : null,
      ),
    );
  }

  Color _blockAccent(PostBlock block) {
    if (block is ImageBlock) return const Color(0xFFF59E0B);
    if (block is VideoBlock) return const Color(0xFFF59E0B);
    if (block is LinkBlock) return const Color(0xFF067A46);
    if (block is TextBlock) return const Color(0xFF00A750);
    return const Color(0xFF8A9099);
  }

  String _blockKind(PostBlock block) {
    if (block is ImageBlock) return 'Фото';
    if (block is VideoBlock) return 'Видео';
    if (block is LinkBlock) return 'Ссылка';
    if (block is TextBlock) {
      return widget.pressMode ? 'Редактор текста' : 'Текст';
    }
    return 'Блок';
  }

  Color _softForAccent(Color color) {
    if (color == const Color(0xFFF59E0B)) {
      return const Color(0xFFFFF7E8);
    }
    if (color == const Color(0xFFD92D20)) {
      return const Color(0xFFFFF1F1);
    }
    if (color == const Color(0xFF067A46) || color == const Color(0xFF00A750)) {
      return const Color(0xFFF3FAF6);
    }
    return const Color(0xFFF7F9F8);
  }

  TextStyle _editorText(
    double size, {
    FontWeight weight = FontWeight.w400,
    Color color = const Color(0xFF5F6670),
  }) {
    final TextStyle base;
    if (size >= 14) {
      base = AppTypography.sectionTitle(color: color);
    } else if (size >= 13) {
      base = AppTypography.subsectionTitle(color: color);
    } else if (size >= 11.2) {
      base = AppTypography.formText(color: color);
    } else if (size >= 10) {
      base = AppTypography.formHint(color: color);
    } else {
      base = AppTypography.commentMeta(color: color);
    }
    return base.copyWith(fontWeight: weight);
  }

  Widget _buildInstagramMobileEditor() {
    final hasLocalCover = _newCoverFile != null;
    final hasRemoteCover = _coverUrl.trim().isNotEmpty;
    final hasCover = hasLocalCover || hasRemoteCover;

    final composerWidth = MediaQuery.sizeOf(context).width;
    final wideComposer = widget.hideChrome && composerWidth >= 680;

    Widget mediaPreview() {
      Widget emptyContent() {
        return Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: wideComposer ? 54 : 58,
              height: wideComposer ? 54 : 58,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.045),
                    blurRadius: 18,
                    offset: const Offset(0, 7),
                  ),
                ],
              ),
              child: const Icon(
                Icons.add_photo_alternate_outlined,
                color: Color(0xFF00A750),
                size: 27,
              ),
            ),
            const SizedBox(height: 12),
            Text(
              'Выбрать фото',
              style: _editorText(
                12.4,
                weight: FontWeight.w600,
                color: const Color(0xFF0B0F14),
              ),
            ),
            const SizedBox(height: 4),
            Text(
              wideComposer
                  ? 'Фото аккуратно впишется в публикацию'
                  : 'Фото будет показано в ленте квадратом',
              textAlign: TextAlign.center,
              style: _editorText(
                10.2,
                color: const Color(0xFF8A9099),
              ),
            ),
          ],
        );
      }

      if (!hasCover) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(wideComposer ? 16 : 0),
          child: Material(
            color: const Color(0xFFF4F6F5),
            child: InkWell(
              onTap: _saving ? null : _pickCover,
              child: wideComposer
                  ? SizedBox(
                      height: 410,
                      child: emptyContent(),
                    )
                  : AspectRatio(
                      aspectRatio: 1,
                      child: emptyContent(),
                    ),
            ),
          ),
        );
      }

      Widget image() {
        if (hasLocalCover) {
          return Image.file(
            _newCoverFile!,
            width: double.infinity,
            height: double.infinity,
            fit: wideComposer ? BoxFit.contain : BoxFit.cover,
          );
        }

        return Image.network(
          _coverUrl,
          width: double.infinity,
          height: double.infinity,
          fit: wideComposer ? BoxFit.contain : BoxFit.cover,
          errorBuilder: (_, __, ___) => Container(
            color: const Color(0xFFF4F6F5),
            alignment: Alignment.center,
            child: const Icon(
              Icons.broken_image_outlined,
              color: Color(0xFF98A2B3),
              size: 34,
            ),
          ),
        );
      }

      return ClipRRect(
        borderRadius: BorderRadius.circular(wideComposer ? 16 : 0),
        child: Stack(
          children: [
            if (wideComposer)
              Container(
                height: 410,
                width: double.infinity,
                color: const Color(0xFFF4F6F5),
                alignment: Alignment.center,
                padding: const EdgeInsets.all(10),
                child: image(),
              )
            else
              AspectRatio(
                aspectRatio: 1,
                child: image(),
              ),
            Positioned(
              top: 10,
              right: 10,
              child: Row(
                children: [
                  Material(
                    color: Colors.black.withOpacity(.58),
                    shape: const CircleBorder(),
                    child: InkWell(
                      onTap: _saving ? null : _pickCover,
                      customBorder: const CircleBorder(),
                      child: const SizedBox(
                        width: 38,
                        height: 38,
                        child: Icon(
                          Icons.edit_outlined,
                          color: Colors.white,
                          size: 18,
                        ),
                      ),
                    ),
                  ),
                  if (hasLocalCover) ...[
                    const SizedBox(width: 7),
                    Material(
                      color: Colors.black.withOpacity(.58),
                      shape: const CircleBorder(),
                      child: InkWell(
                        onTap: _saving
                            ? null
                            : () => setState(() => _newCoverFile = null),
                        customBorder: const CircleBorder(),
                        child: const SizedBox(
                          width: 38,
                          height: 38,
                          child: Icon(
                            Icons.close_rounded,
                            color: Colors.white,
                            size: 18,
                          ),
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      );
    }

    final suggestions = <String>[
      '#футбол',
      '#матч',
      '#тренировка',
      '#команда',
      '#гол',
      '#спорт',
    ];

    Widget captionAndSettings() {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            color: Colors.white,
            padding: EdgeInsets.fromLTRB(
              wideComposer ? 4 : 14,
              wideComposer ? 2 : 14,
              wideComposer ? 4 : 14,
              8,
            ),
            child: TextField(
              controller: _caption,
              minLines: wideComposer ? 7 : 4,
              maxLines: wideComposer ? 14 : 10,
              maxLength: 2200,
              textCapitalization: TextCapitalization.sentences,
              style: _editorText(
                wideComposer ? 12.4 : 13.2,
                weight: FontWeight.w400,
                color: const Color(0xFF0B0F14),
              ).copyWith(height: 1.42),
              decoration: InputDecoration(
                hintText: 'Напишите подпись… Добавьте #хэштеги',
                hintStyle: _editorText(
                  12.0,
                  color: const Color(0xFF98A2B3),
                ),
                filled: wideComposer,
                fillColor:
                    wideComposer ? const Color(0xFFF8FAF9) : Colors.transparent,
                border: wideComposer
                    ? OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      )
                    : InputBorder.none,
                enabledBorder: wideComposer
                    ? OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      )
                    : InputBorder.none,
                focusedBorder: wideComposer
                    ? OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(
                          color: Color(0x3300A750),
                        ),
                      )
                    : InputBorder.none,
                counterStyle:
                    _editorText(9.2, color: const Color(0xFF98A2B3)),
                contentPadding: wideComposer
                    ? const EdgeInsets.all(12)
                    : EdgeInsets.zero,
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(
              wideComposer ? 4 : 14,
              4,
              wideComposer ? 4 : 14,
              12,
            ),
            child: TextField(
              controller: _title,
              style: _editorText(
                11.2,
                weight: FontWeight.w500,
                color: const Color(0xFF0B0F14),
              ),
              decoration: InputDecoration(
                labelText: 'Заголовок (необязательно)',
                hintText: 'Например: Победа в важном матче',
                labelStyle:
                    _editorText(10.2, color: const Color(0xFF667085)),
                hintStyle:
                    _editorText(10.2, color: const Color(0xFF98A2B3)),
                filled: true,
                fillColor: const Color(0xFFF7F9F8),
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 12,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(
              wideComposer ? 4 : 14,
              2,
              wideComposer ? 4 : 14,
              12,
            ),
            child: Wrap(
              spacing: 7,
              runSpacing: 7,
              children: [
                for (final hashtag in suggestions)
                  Material(
                    color: const Color(0xFFF3FAF6),
                    borderRadius: BorderRadius.circular(999),
                    child: InkWell(
                      onTap: () => _insertHashtag(hashtag),
                      borderRadius: BorderRadius.circular(999),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 7,
                        ),
                        child: Text(
                          hashtag,
                          style: _editorText(
                            10.1,
                            weight: FontWeight.w600,
                            color: const Color(0xFF067A46),
                          ),
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const Divider(height: 1, color: Color(0xFFF0F2F1)),
          ListTile(
            dense: wideComposer,
            contentPadding: EdgeInsets.symmetric(
              horizontal: wideComposer ? 4 : 14,
            ),
            onTap: _saving
                ? null
                : () {
                    _syncCaptionToBlocks();
                    setState(() => _showAdvancedMobileEditor = true);
                  },
            leading: const Icon(
              Icons.tune_rounded,
              color: Color(0xFF111827),
            ),
            title: Text(
              'Расширенный редактор',
              style: _editorText(
                11.5,
                weight: FontWeight.w600,
                color: const Color(0xFF0B0F14),
              ),
            ),
            subtitle: Text(
              'Текстовые блоки, дополнительные фото, ссылки и видео',
              style: _editorText(9.8, color: const Color(0xFF8A9099)),
            ),
            trailing: const Icon(
              Icons.chevron_right_rounded,
              color: Color(0xFF98A2B3),
            ),
          ),
          const Divider(height: 1, color: Color(0xFFF0F2F1)),
        ],
      );
    }

    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: EdgeInsets.fromLTRB(
        wideComposer ? 14 : 0,
        wideComposer ? 12 : 0,
        wideComposer ? 14 : 0,
        widget.hideChrome ? MediaQuery.paddingOf(context).bottom + 96 : 40,
      ),
      children: [
        if (wideComposer)
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 11,
                child: mediaPreview(),
              ),
              const SizedBox(width: 14),
              Expanded(
                flex: 9,
                child: captionAndSettings(),
              ),
            ],
          )
        else ...[
          mediaPreview(),
          captionAndSettings(),
        ],
      ],
    );
  }

  Widget _buildAdvancedMobileEditor() {
    return ListView(
      keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
      padding: EdgeInsets.fromLTRB(
        12,
        10,
        12,
        widget.hideChrome ? MediaQuery.paddingOf(context).bottom + 96 : 40,
      ),
      children: [
        Material(
          color: const Color(0xFFF3FAF6),
          borderRadius: BorderRadius.circular(10),
          child: InkWell(
            onTap: _saving
                ? null
                : () {
                    _syncCaptionFromBlocks();
                    setState(() => _showAdvancedMobileEditor = false);
                  },
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
              child: Row(
                children: [
                  const Icon(
                    Icons.arrow_back_rounded,
                    size: 18,
                    color: Color(0xFF067A46),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Вернуться к простому редактору',
                      style: _editorText(
                        10.6,
                        weight: FontWeight.w600,
                        color: const Color(0xFF067A46),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        const SizedBox(height: 10),
        ..._buildEditorChildren(),
      ],
    );
  }

  Widget _buildResponsiveAdvancedEditor() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final phone = width < 600;
        final tablet = width >= 600 && width < 1050;

        final maxContentWidth = widget.pressMode
            ? (phone
                ? width
                : tablet
                    ? 820.0
                    : 1040.0)
            : (phone
                ? width
                : tablet
                    ? 860.0
                    : 1080.0);

        final horizontal = phone
            ? (widget.embedded ? 10.0 : 12.0)
            : tablet
                ? 16.0
                : 22.0;

        return ListView(
          keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
          padding: EdgeInsets.fromLTRB(
            horizontal,
            phone ? 8 : 12,
            horizontal,
            widget.hideChrome
                ? MediaQuery.paddingOf(context).bottom + 28
                : 28,
          ),
          children: [
            Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: maxContentWidth),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: _buildEditorChildren(),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final isPhone = width < 600;

    final useSimpleComposer =
        (widget.forceSimpleComposer || isPhone) && !widget.pressMode;

    final Widget editorBody = useSimpleComposer
        ? (_showAdvancedMobileEditor
            ? _buildAdvancedMobileEditor()
            : _buildInstagramMobileEditor())
        : _buildResponsiveAdvancedEditor();

    final baseTheme = Theme.of(context);
    final themed = Theme(
      data: baseTheme.copyWith(
        textTheme: baseTheme.textTheme.apply(
          fontFamily: AppTypography.fontFamily,
          bodyColor: const Color(0xFF0B0F14),
          displayColor: const Color(0xFF0B0F14),
        ),
      ),
      child: editorBody,
    );

    if (widget.hideChrome) {
      return SafeArea(
        top: false,
        bottom: false,
        child: Container(
          color: Colors.white,
          child: themed,
        ),
      );
    }

    if (widget.embedded) {
      return SafeArea(
        top: isPhone,
        bottom: false,
        child: Container(
          color: Colors.white,
          child: Column(
            children: [
              Container(
                constraints: BoxConstraints(minHeight: isPhone ? 50 : 56),
                padding: EdgeInsets.fromLTRB(
                  isPhone ? 4 : 12,
                  isPhone ? 4 : 8,
                  isPhone ? 8 : 10,
                  isPhone ? 4 : 8,
                ),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(color: Color(0xFFF0F2F1), width: .7),
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      tooltip: 'Закрыть',
                      onPressed:
                          _saving ? null : () => _finishEditor(saved: false),
                      icon: Icon(
                        isPhone
                            ? Icons.arrow_back_ios_new_rounded
                            : Icons.close_rounded,
                        size: isPhone ? 19 : 17,
                        color: const Color(0xFF0B0F14),
                      ),
                    ),
                    if (!isPhone) ...[
                      _brandDots(),
                      const SizedBox(width: 9),
                    ],
                    Expanded(
                      child: Text(
                        widget.isEdit ? 'Редактирование' : (widget.pressMode ? (_internalNewsMode ? 'Новость в клуб' : 'Новость в общую ленту') : (_internalNewsMode ? 'Новая новость клуба' : 'Новая публикация')),
                        textAlign: isPhone ? TextAlign.center : TextAlign.start,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _editorText(
                          isPhone ? 13.2 : 13.6,
                          weight: FontWeight.w600,
                          color: const Color(0xFF0B0F14),
                        ),
                      ),
                    ),
                    if (isPhone)
                      TextButton(
                        onPressed: _saving ? null : _save,
                        style: TextButton.styleFrom(
                          foregroundColor: const Color(0xFF00A750),
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                        ),
                        child: _saving
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Color(0xFF00A750),
                                ),
                              )
                            : Text(
                                widget.isEdit ? 'Готово' : 'Поделиться',
                                style: _editorText(
                                  10.8,
                                  weight: FontWeight.w700,
                                  color: const Color(0xFF00A750),
                                ),
                              ),
                      )
                    else
                      FilledButton.icon(
                        onPressed: _saving ? null : _save,
                        style: FilledButton.styleFrom(
                          elevation: 0,
                          backgroundColor: const Color(0xFF00A750),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                            horizontal: 11,
                            vertical: 10,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(9),
                          ),
                        ),
                        icon: _saving
                            ? const SizedBox(
                                width: 14,
                                height: 14,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.check_rounded, size: 16),
                        label: Text(
                          widget.isEdit ? 'Сохранить' : 'Опубликовать',
                          style: _editorText(
                            10.3,
                            weight: FontWeight.w600,
                            color: Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
              Expanded(child: themed),
            ],
          ),
        ),
      );
    }

    return Theme(
      data: baseTheme.copyWith(
        textTheme: baseTheme.textTheme.apply(
          fontFamily: AppTypography.fontFamily,
        ),
      ),
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          centerTitle: isPhone,
          titleSpacing: isPhone ? 0 : 14,
          title: isPhone
              ? Text(
                  widget.isEdit ? 'Редактирование' : (widget.pressMode ? (_internalNewsMode ? 'Новость в клуб' : 'Новость в общую ленту') : (_internalNewsMode ? 'Новая новость клуба' : 'Новая публикация')),
                  style: _editorText(
                    13.2,
                    weight: FontWeight.w600,
                    color: const Color(0xFF0B0F14),
                  ),
                )
              : Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    _brandDots(),
                    const SizedBox(width: 8),
                    Text(
                      widget.isEdit ? 'Редактирование поста' : (widget.pressMode ? (_internalNewsMode ? 'Новость в клуб' : 'Новость в общую ленту') : (_internalNewsMode ? 'Новая новость клуба' : 'Новый пост')),
                      style: _editorText(
                        14,
                        weight: FontWeight.w600,
                        color: const Color(0xFF0B0F14),
                      ),
                    ),
                  ],
                ),
          actions: [
            if (isPhone)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: TextButton(
                  onPressed: _saving ? null : _save,
                  style: TextButton.styleFrom(
                    foregroundColor: const Color(0xFF00A750),
                  ),
                  child: _saving
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Color(0xFF00A750),
                          ),
                        )
                      : Text(
                          widget.isEdit ? 'Готово' : 'Поделиться',
                          style: _editorText(
                            10.8,
                            weight: FontWeight.w700,
                            color: const Color(0xFF00A750),
                          ),
                        ),
                ),
              )
            else
              Padding(
                padding: const EdgeInsets.only(right: 10),
                child: FilledButton.icon(
                  onPressed: _saving ? null : _save,
                  style: FilledButton.styleFrom(
                    elevation: 0,
                    backgroundColor: const Color(0xFF00A750),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(9),
                    ),
                  ),
                  icon: _saving
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(Icons.check_rounded, size: 16),
                  label: Text(
                    widget.isEdit ? 'Сохранить' : 'Опубликовать',
                    style: _editorText(
                      10.4,
                      weight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
          ],
        ),
        body: themed,
      ),
    );
  }

  Widget _buildPublicationDestinationBanner() {
    final internal = _internalNewsMode;
    final title = internal
        ? 'Новость в клуб · внутренняя'
        : 'Новость в общую ленту · публичная';
    final subtitle = internal
        ? 'Эту новость увидят только участники клуба и выбранных команд.'
        : 'Эта новость попадёт в общую ленту СПОРТОТЕКИ и будет видна всем пользователям.';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: internal
            ? const Color(0xFFF3FAF6)
            : const Color(0xFFF7F9F8),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: internal
              ? const Color(0xFFD7F0E2)
              : const Color(0xFFE1E5E2),
          width: .7,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(
              internal ? Icons.lock_outline_rounded : Icons.public_rounded,
              size: 17,
              color: internal
                  ? const Color(0xFF067A46)
                  : const Color(0xFF374151),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: _editorText(
                    10.8,
                    weight: FontWeight.w700,
                    color: internal
                        ? const Color(0xFF067A46)
                        : const Color(0xFF111827),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  subtitle,
                  style: _editorText(
                    9.8,
                    color: const Color(0xFF5F6670),
                  ).copyWith(height: 1.35),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  List<Widget> _buildEditorChildren() {
    return <Widget>[
      if (widget.pressMode) ...[
        _buildPublicationDestinationBanner(),
        const SizedBox(height: 8),
      ],
      if (_internalNewsMode) ...[
        _buildInternalAudienceSelector(),
        const SizedBox(height: 8),
      ],
      _editorSection(
        title: 'Заголовок',
        subtitle: 'Коротко сформулируйте тему публикации',
        dotColor: _title.text.trim().isNotEmpty
            ? const Color(0xFF00A750)
            : const Color(0xFF8A9099),
        statusText: _title.text.trim().isNotEmpty ? 'Готово' : 'Не заполнено',
        child: TextField(
          controller: _title,
          onChanged: (_) => setState(() {}),
          style: _editorText(
            11.2,
            weight: FontWeight.w500,
            color: const Color(0xFF0B0F14),
          ),
          decoration: _fieldDecoration('Введите заголовок…'),
        ),
      ),
      const SizedBox(height: 8),
      _editorSection(
        title: 'Обложка',
        subtitle: 'Необязательно · фото для превью публикации',
        dotColor: _newCoverFile != null || _coverUrl.trim().isNotEmpty
            ? const Color(0xFFF59E0B)
            : const Color(0xFF8A9099),
        statusText: _newCoverFile != null || _coverUrl.trim().isNotEmpty
            ? 'Добавлена'
            : 'Не выбрана',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Material(
              color: const Color(0xFFF7F9F8),
              borderRadius: BorderRadius.circular(9),
              child: InkWell(
                onTap: _saving ? null : _pickCover,
                borderRadius: BorderRadius.circular(9),
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 11,
                    vertical: 10,
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 32,
                        height: 32,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF3FAF6),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(
                          Icons.photo_outlined,
                          size: 17,
                          color: Color(0xFF067A46),
                        ),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Text(
                          _newCoverFile != null || _coverUrl.trim().isNotEmpty
                              ? 'Заменить обложку'
                              : 'Выбрать обложку',
                          style: _editorText(
                            10.5,
                            weight: FontWeight.w600,
                            color: const Color(0xFF0B0F14),
                          ),
                        ),
                      ),
                      if (_newCoverFile != null)
                        IconButton(
                          tooltip: 'Убрать',
                          onPressed: () => setState(() => _newCoverFile = null),
                          icon: const Icon(
                            Icons.close_rounded,
                            size: 16,
                          ),
                        )
                      else
                        const Icon(
                          Icons.chevron_right_rounded,
                          size: 17,
                          color: Color(0xFF98A2B3),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            if (_newCoverFile != null) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: Image.file(
                  _newCoverFile!,
                  height: 190,
                  width: double.infinity,
                  fit: BoxFit.contain,
                ),
              ),
            ] else if (_coverUrl.trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(9),
                child: Image.network(
                  _coverUrl,
                  height: 190,
                  width: double.infinity,
                  fit: BoxFit.contain,
                ),
              ),
            ],
          ],
        ),
      ),
      const SizedBox(height: 8),
      _editorSection(
        title: 'Содержание',
        subtitle: 'Текст, фото, ссылки и видео в нужном порядке',
        dotColor: _blocks.isNotEmpty
            ? const Color(0xFF00A750)
            : const Color(0xFF8A9099),
        statusText: _blocks.isEmpty
            ? 'Пусто'
            : '${_blocks.length} ${_blocks.length == 1 ? 'блок' : 'блока'}',
        trailing: Material(
          color: _showBlockLibrary
              ? const Color(0xFFF3FAF6)
              : const Color(0xFFF7F9F8),
          borderRadius: BorderRadius.circular(8),
          child: InkWell(
            onTap: _saving ? null : _showAddBlockMenu,
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 9,
                vertical: 7,
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _showBlockLibrary ? Icons.close_rounded : Icons.add_rounded,
                    size: 15,
                    color: const Color(0xFF067A46),
                  ),
                  const SizedBox(width: 5),
                  Text(
                    _showBlockLibrary ? 'Закрыть' : 'Добавить блок',
                    style: _editorText(
                      9.8,
                      weight: FontWeight.w600,
                      color: const Color(0xFF067A46),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_showBlockLibrary) ...[
              _blockLibrary(),
              const SizedBox(height: 8),
            ],
            if (_blocks.isEmpty)
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 18,
                ),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F9F8),
                  borderRadius: BorderRadius.circular(9),
                ),
                child: Row(
                  children: [
                    _statusDot(
                      color: const Color(0xFF8A9099),
                      size: 5,
                      glow: false,
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'Добавьте первый блок публикации',
                        style: _editorText(10.4),
                      ),
                    ),
                  ],
                ),
              )
            else
              Column(
                children: List.generate(_blocks.length, (i) {
                  final b = _blocks[i];

                  return Container(
                    margin: const EdgeInsets.only(bottom: 7),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7F9F8),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            _statusDot(
                              color: _blockAccent(b),
                              size: 5.5,
                            ),
                            const SizedBox(width: 7),
                            Expanded(
                              child: Row(
                                children: [
                                  Text(
                                    _blockKind(b),
                                    style: _editorText(
                                      9.8,
                                      weight: FontWeight.w600,
                                      color: _blockAccent(b),
                                    ),
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    'Блок ${i + 1}',
                                    style: _editorText(
                                      9.4,
                                      weight: FontWeight.w500,
                                      color: const Color(0xFF8A9099),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            _blockAction(
                              Icons.arrow_upward_rounded,
                              i == 0 ? null : () => _moveUp(i),
                              'Выше',
                            ),
                            _blockAction(
                              Icons.arrow_downward_rounded,
                              i == _blocks.length - 1
                                  ? null
                                  : () => _moveDown(i),
                              'Ниже',
                            ),
                            _blockAction(
                              Icons.delete_outline_rounded,
                              () => _deleteBlock(i),
                              'Удалить',
                              danger: true,
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        if (b is TextBlock) _buildTextBlockPreview(b, i),
                        if (b is ImageBlock)
                          ClipRRect(
                            borderRadius: BorderRadius.circular(9),
                            child: AspectRatio(
                              aspectRatio: 16 / 10,
                              child: Image.network(
                                b.url,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => Container(
                                  color: const Color(0xFFEFF2F0),
                                  child: const Center(
                                    child: Icon(
                                      Icons.broken_image_outlined,
                                      color: Color(0xFF98A2B3),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        if (b is LinkBlock)
                          InkWell(
                            onTap: () => _editLinkBlock(i, b),
                            borderRadius: BorderRadius.circular(9),
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(9),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.link_rounded,
                                        color: Color(0xFF067A46),
                                        size: 16,
                                      ),
                                      const SizedBox(width: 7),
                                      Text(
                                        'Ссылка',
                                        style: _editorText(
                                          10.2,
                                          weight: FontWeight.w600,
                                          color: const Color(0xFF0B0F14),
                                        ),
                                      ),
                                    ],
                                  ),
                                  if (b.title.trim().isNotEmpty) ...[
                                    const SizedBox(height: 7),
                                    Text(
                                      b.title,
                                      style: _editorText(
                                        10.8,
                                        weight: FontWeight.w600,
                                        color: const Color(0xFF0B0F14),
                                      ),
                                    ),
                                  ],
                                  const SizedBox(height: 5),
                                  GestureDetector(
                                    onTap: () => _openUrl(b.url),
                                    child: Text(
                                      b.url,
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: _editorText(
                                        9.6,
                                        weight: FontWeight.w500,
                                        color: const Color(0xFF067A46),
                                      ).copyWith(
                                        decoration: TextDecoration.underline,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        if (b is VideoBlock) _buildVideoPreview(b, i),
                      ],
                    ),
                  );
                }),
              ),
          ],
        ),
      ),
    ];
  }

  Widget _editorSection({
    required String title,
    required String subtitle,
    required Widget child,
    required Color dotColor,
    String? statusText,
    Widget? trailing,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 5),
                child: _statusDot(
                  color: dotColor,
                  size: 6,
                  glow: dotColor != const Color(0xFF8A9099),
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            title,
                            style: _editorText(
                              11.5,
                              weight: FontWeight.w600,
                              color: const Color(0xFF0B0F14),
                            ),
                          ),
                        ),
                        if (statusText != null && statusText!.isNotEmpty) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 7,
                              vertical: 4,
                            ),
                            decoration: BoxDecoration(
                              color: _softForAccent(dotColor),
                              borderRadius: BorderRadius.circular(7),
                            ),
                            child: Text(
                              statusText!,
                              style: _editorText(
                                8.9,
                                weight: FontWeight.w600,
                                color: dotColor,
                              ),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: _editorText(9.6),
                    ),
                  ],
                ),
              ),
              if (trailing != null) ...[
                const SizedBox(width: 8),
                trailing,
              ],
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  Widget _blockAction(
    IconData icon,
    VoidCallback? onTap,
    String tooltip, {
    bool danger = false,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(7),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(7),
          child: SizedBox(
            width: 29,
            height: 29,
            child: Icon(
              icon,
              size: 15,
              color: onTap == null
                  ? const Color(0xFFD0D5DD)
                  : danger
                      ? const Color(0xFFD92D20)
                      : const Color(0xFF667085),
            ),
          ),
        ),
      ),
    );
  }

  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F9F8),
        borderRadius: BorderRadius.circular(10),
      ),
      child: child,
    );
  }
}
