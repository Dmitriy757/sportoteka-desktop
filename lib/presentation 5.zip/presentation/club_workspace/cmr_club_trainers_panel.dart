// lib/presentation/club_workspace/cmr_club_trainers_panel.dart
// Inter typography aligned with CmrClubTeamsPanel and CmrClubRosterPanel.
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:sportoteka/core/theme/app_typography.dart';

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_staff_access_panel.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_staff_access_admin_panel.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_staff_invite_dialog.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_staff_add_right_panel.dart';
import 'package:sportoteka/presentation/chat_screen/chat_room_screen.dart';
import 'package:sportoteka/presentation/trainer_profile_screen/cmr_trainer_profile_screen.dart';

// ==================== Глобальные вспомогательные функции ====================

String _s(dynamic value) {
  final text = '${value ?? ''}'.trim();
  return text == 'null' ? '' : text;
}

int _i(dynamic value) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('${value ?? ''}'.trim()) ?? 0;
}

bool _b(dynamic value) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  final s = _s(value).toLowerCase();
  return s == '1' || s == 'true' || s == 'yes';
}

String _normalizeImage(String raw) {
  final url = raw.trim();
  if (url.isEmpty || url == 'null') return '';
  if (url.startsWith('http://') || url.startsWith('https://')) return url;
  if (url.startsWith('//')) return 'https:$url';
  if (url.startsWith('sportotekaapp.ru/')) return 'https://$url';
  if (url.startsWith('www.sportotekaapp.ru/')) return 'https://$url';
  if (url.startsWith('/')) return 'https://sportotekaapp.ru$url';
  if (url.startsWith('uploads/')) return 'https://sportotekaapp.ru/$url';
  return 'https://sportotekaapp.ru/uploads/$url';
}

String _trainerName(Map<String, dynamic> t) {
  final full = _s(t['full_name'] ?? t['fullName'] ?? t['name']);
  if (full.isNotEmpty) return full;
  final name = '${_s(t['first_name'])} ${_s(t['last_name'])}'.trim();
  return name.isEmpty ? 'Тренер' : name;
}

String _roleTitleFromCode(String raw) {
  final v = raw.trim().toLowerCase();
  if (v.isEmpty || v == 'extra' || v == 'coach' || v == 'trainer') {
    return 'Тренер';
  }
  if (v == 'main' || v == 'head' || v.contains('глав')) {
    return 'Главный тренер';
  }
  if (v == 'goalkeeper' ||
      v == 'goalkeeper_coach' ||
      v == 'gk' ||
      v.contains('вратар')) {
    return 'Тренер по вратарям';
  }
  if (v == 'doctor' ||
      v == 'medic' ||
      v.contains('sports_medicine') ||
      v.contains('врач') ||
      v.contains('мед')) {
    return 'Врач спортивной медицины';
  }
  if (v == 'assistant' || v.contains('ассист') || v.contains('помощ')) {
    return 'Ассистент';
  }
  if (v == 'press_assistant' ||
      v == 'press' ||
      v == 'press_service' ||
      v.contains('пресс')) {
    return 'Пресс-служба';
  }
  if (v == 'manager' || v == 'admin' || v.contains('админист')) {
    return 'Администратор';
  }
  return raw.trim();
}

String _trainerRole(Map<String, dynamic> t) {
  final currentClubRole = _s(t['_current_club_role']);
  if (currentClubRole.isNotEmpty) {
    return _roleTitleFromCode(currentClubRole);
  }

  // Если список teams уже нормализован под текущий клуб, роль берём именно
  // из текущего назначения, а не из исторических данных общего профиля.
  final teams = _trainerTeams(t);
  if (teams.isNotEmpty) {
    final profiles = teams
        .map((team) => _s(team['profile'] ?? team['link_profile'] ?? team['role_code']))
        .where((value) => value.isNotEmpty)
        .toList();
    if (profiles.any((value) => value.toLowerCase() == 'main')) {
      return 'Главный тренер';
    }
    if (profiles.isNotEmpty) return _roleTitleFromCode(profiles.first);
  }

  final assignmentRole =
      _s(t['profile'] ?? t['link_profile'] ?? t['staff_role']);
  if (assignmentRole.isNotEmpty) {
    // Эти поля описывают именно назначение, поэтому не смешиваем их с
    // произвольной карьерной должностью из общего профиля.
    return _roleTitleFromCode(assignmentRole);
  }

  final raw = _s(t['position'] ??
      t['role_title'] ??
      t['specialization'] ??
      t['staff_role'] ??
      t['role'] ??
      t['profile']);
  return raw.isEmpty ? 'Тренер' : _roleTitleFromCode(raw);
}

String _trainerPhoto(Map<String, dynamic> t) => _normalizeImage(_s(t['photo'] ??
    t['avatar'] ??
    t['image'] ??
    t['photo_url'] ??
    t['avatar_url']));

bool _isMain(Map<String, dynamic> trainer) {
  final currentClubRole = _s(trainer['_current_club_role']).toLowerCase();
  if (currentClubRole.isNotEmpty) {
    return currentClubRole == 'main' ||
        currentClubRole == 'head' ||
        currentClubRole.contains('глав');
  }

  // Когда teams присутствует, он считается источником текущих назначений.
  // Это не даёт роли главного тренера из другого клуба "протечь" в текущий.
  if (trainer['teams'] is List) {
    for (final team in _trainerTeams(trainer)) {
      final raw = _s(team['profile'] ?? team['link_profile'] ?? team['role_code'])
          .toLowerCase();
      if (raw == 'main' || raw == 'head' || raw.contains('глав')) return true;
    }
    return false;
  }

  if (_b(trainer['is_main_any']) || _b(trainer['is_main'])) return true;
  final raw =
      '${_s(trainer['profile'])} ${_s(trainer['link_profile'])} ${_s(trainer['role'])}'
          .toLowerCase();
  return raw.contains('main') || raw.contains('head') || raw.contains('глав');
}

String _trainerEmail(Map<String, dynamic> t) => _s(t['email']);
String _trainerPhone(Map<String, dynamic> t) =>
    _s(t['phone'] ?? t['telephone'] ?? t['phone_number'] ?? t['mobile']);
String _trainerBirthday(Map<String, dynamic> t) =>
    _s(t['birthday'] ?? t['birth_date'] ?? t['date_birth'] ?? t['dob']);
String _trainerExperience(Map<String, dynamic> t) =>
    _s(t['experience'] ?? t['experience_text'] ?? t['work_experience']);
String _trainerBio(Map<String, dynamic> t) =>
    _s(t['bio'] ?? t['description'] ?? t['about'] ?? t['about_me']);
String _trainerCity(Map<String, dynamic> t) => _s(t['city'] ?? t['town']);
String _trainerSpecialization(Map<String, dynamic> t) =>
    _s(t['specialization'] ?? t['speciality'] ?? t['category']);

String _locationKeyValue(String raw) => raw
    .trim()
    .toLowerCase()
    .replaceAll('ё', 'е')
    .replaceAll(RegExp(r'[«»„“”]'), '')
    .replaceAll('"', '')
    .replaceAll("'", '')
    .replaceAll(RegExp(r'\s*[–—-]\s*'), '-')
    .replaceAll(RegExp(r'\s+'), ' ')
    .replaceAll(RegExp(r'[.,;:]+$'), '')
    .trim();

String _firstLocationValue(Map<String, dynamic> source) {
  for (final key in const <String>[
    'location',
    'venue',
    'address',
    'place',
    'stadium',
    'base',
    'training_base',
    'training_location',
  ]) {
    final value = _s(source[key]);
    if (value.isNotEmpty) return value;
  }
  return '';
}

int _teamIdValue(Map<String, dynamic> team) =>
    _i(team['id'] ?? team['team_id'] ?? team['teamId']);

List<String> _manualTrainerLocationsForClub(
  Map<String, dynamic> trainer,
  int clubId,
) {
  if (clubId <= 0) return const <String>[];
  final stored = _s(trainer['work_locations'] ?? trainer['locations']);
  if (stored.isEmpty) return const <String>[];

  final marker = '#club:$clubId|';
  final seen = <String>{};
  final out = <String>[];
  for (final raw in stored.split(RegExp(r'[\r\n]+'))) {
    final line = raw.trim();
    if (!line.startsWith(marker)) continue;
    final value = line.substring(marker.length).trim();
    final key = _locationKeyValue(value);
    if (value.isEmpty || key.isEmpty || !seen.add(key)) continue;
    out.add(value);
  }
  return out;
}

List<String> _automaticTrainerLocationsForClub(
  Map<String, dynamic> trainer,
  int clubId,
  List<Map<String, dynamic>> allTeams,
) {
  final assignments = _trainerTeams(trainer);
  final schedule = _trainerSchedule(trainer);
  final out = <String>[];
  final seen = <String>{};

  Map<String, dynamic>? canonicalTeam(int id) {
    if (id <= 0) return null;
    for (final team in allTeams) {
      if (_teamIdValue(team) == id) return team;
    }
    return null;
  }

  void add(String teamName, String location) {
    if (location.trim().isEmpty) return;
    final label = teamName.trim().isEmpty
        ? location.trim()
        : '${teamName.trim()} — ${location.trim()}';
    final key = _locationKeyValue(label);
    if (key.isEmpty || !seen.add(key)) return;
    out.add(label);
  }

  for (final assignment in assignments) {
    final teamId = _teamIdValue(assignment);
    final teamName = _teamName(assignment);
    final canonical = canonicalTeam(teamId) ?? assignment;

    // Сначала паспорт/карточка команды.
    add(teamName, _firstLocationValue(canonical));

    // Затем календарь только этой команды.
    for (final event in schedule) {
      final eventTeamId = _i(event['team_id'] ?? event['teamId']);
      final eventTeamName = _s(event['team_name']);
      final sameTeam = teamId > 0
          ? eventTeamId == teamId
          : _locationKeyValue(eventTeamName) == _locationKeyValue(teamName);
      if (!sameTeam) continue;
      add(teamName, _firstLocationValue(event));
    }
  }

  // Старые события без team_id связываем только по точному имени команды.
  for (final event in schedule) {
    final eventTeamName = _s(event['team_name']);
    if (eventTeamName.isEmpty) continue;

    final assignment = assignments.cast<Map<String, dynamic>?>().firstWhere(
          (team) =>
              team != null &&
              _locationKeyValue(_teamName(team)) ==
                  _locationKeyValue(eventTeamName),
          orElse: () => null,
        );

    if (assignment == null) continue;
    add(_teamName(assignment), _firstLocationValue(event));
  }

  return out;
}

List<String> _resolvedTrainerLocationsForClub(
  Map<String, dynamic> trainer,
  int clubId,
  List<Map<String, dynamic>> allTeams,
) {
  final manual = _manualTrainerLocationsForClub(trainer, clubId);
  if (manual.isNotEmpty) return manual;

  return _automaticTrainerLocationsForClub(
    trainer,
    clubId,
    allTeams,
  );
}

// Staff Access на сервере привязан именно к users.id.
// В ответах API поле `id` может быть id записи тренера/назначения,
// поэтому user_id должен иметь приоритет.
int _staffAccessUserId(Map<String, dynamic> t) => _i(
      t['user_id'] ??
          t['userId'] ??
          t['trainer_id'] ??
          t['trainerId'] ??
          t['coach_id'] ??
          t['id'],
    );

List<Map<String, dynamic>> _trainerTeams(Map<String, dynamic> t) {
  final rawTeams = t['teams'];
  if (rawTeams is List)
    return rawTeams
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  final teamId = _i(t['team_id'] ?? t['teamId']);
  final teamName = _s(t['team_name'] ?? t['teamName']);
  if (teamId > 0 || teamName.isNotEmpty) {
    return [
      {
        'team_id': teamId,
        'team_name': teamName.isEmpty ? 'Команда #$teamId' : teamName,
        'team_logo': t['team_logo'] ?? t['teamLogo'],
        'link_profile': t['link_profile'] ?? t['profile'],
        'main_coach_id': t['main_coach_id'],
      }
    ];
  }
  return [];
}

bool _isPressProfileValue(dynamic value) {
  final raw = _s(value).trim().toLowerCase();
  return raw == 'press_assistant' ||
      raw == 'press' ||
      raw == 'press_service' ||
      raw.contains('пресс');
}

List<Map<String, dynamic>> _trainerPressTeams(Map<String, dynamic> trainer) {
  for (final key in const <String>['press_teams', 'press_assignments']) {
    final raw = trainer[key];
    if (raw is List) {
      final rows = raw
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
      if (rows.isNotEmpty) return rows;
    }
  }

  // Совместимость со старыми назначениями, где press_assistant
  // временно хранился прямо в team_trainers.profile.
  return _trainerTeams(trainer)
      .where(
        (team) =>
            _isPressProfileValue(team['profile']) ||
            _isPressProfileValue(team['link_profile']) ||
            _isPressProfileValue(team['staff_role']) ||
            _isPressProfileValue(team['role_code']),
      )
      .toList();
}

List<Map<String, dynamic>> _trainerSchedule(Map<String, dynamic> t) {
  final raw = t['_schedule'];
  if (raw is List) {
    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }
  return const <Map<String, dynamic>>[];
}

String _teamName(Map<String, dynamic> team) =>
    _s(team['name'] ?? team['team_name'] ?? team['title']).isEmpty
        ? 'Команда'
        : _s(team['name'] ?? team['team_name'] ?? team['title']);
String _teamLogo(Map<String, dynamic> team) => _normalizeImage(
    _s(team['logo_url'] ?? team['logo'] ?? team['team_logo'] ?? team['photo']));

String _profileTitle(String raw) => _roleTitleFromCode(raw);

String _teamsText(Map<String, dynamic> trainer) {
  final teams = _trainerTeams(trainer);
  if (teams.isEmpty) return 'Команда не назначена';
  if (teams.length <= 2) return teams.map(_teamName).join(', ');
  return '${_teamName(teams[0])}, ${_teamName(teams[1])} +${teams.length - 2}';
}

String _trainerRoleDescriptor(Map<String, dynamic> trainer) {
  final role = _trainerRole(trainer);
  if (role != 'Главный тренер') return role;

  final teams = _trainerTeams(trainer);
  if (teams.length != 1) return role;

  final name = _teamName(teams.first);
  final match = RegExp(r'\b(20\d{2})\b').firstMatch(name);
  if (match == null) return role;

  return 'Главный тренер юношеской команды ${match.group(1)} года рождения';
}

// ==================== Цветовая схема ====================

class _CmrColors {
  static const Color bg = Colors.white;
  static const Color panel = Colors.white;
  static const Color glass = Colors.white;
  static const Color soft = Color(0xFFFAFBFA);
  static const Color soft2 = Color(0xFFF4F6F4);
  static const Color active = Colors.white;

  static const Color text = Color(0xFF0B0F14);
  static const Color muted = Color(0xFF374151);
  static const Color muted2 = Color(0xFF6B7280);
  static const Color subtle = Color(0xFF6B7280);
  static const Color line = Color(0xFFE9ECEA);
  static const Color graphite = Color(0xFF111827);
  static const Color graphite2 = Color(0xFF1F2937);
  static const Color graphiteButton = Color(0xFF111827);
  static const Color graphiteButtonHover = Color(0xFF1F2937);

  static const Color green = Color(0xFF00A750);
  static const Color greenDark = Color(0xFF067A46);
  static const Color greenSoft = Color(0xFFF3FAF6);
  static const Color greenSoft2 = Color(0xFFF8FEFA);
  static const Color greenBorder = Color(0xFFD7F0E2);

  static const Color red = Color(0xFFD92D20);
  static const Color redSoft = Color(0xFFFFF1F1);
  static const Color redBorder = Color(0xFFFEE4E2);
  static const Color amber = Color(0xFFF59E0B);
  static const Color amberSoft = Color(0xFFFFFBEB);
  static const Color blue = Color(0xFF2563EB);
  static const Color blueSoft = Color(0xFFF4F7FF);
  static const Color cyan = Color(0xFF06B6D4);
  static const Color cyanSoft = Color(0xFFEFFBFF);
  static const Color violet = Color(0xFF7C3AED);
  static const Color violetSoft = Color(0xFFF5F0FF);
  static const Color pink = Color(0xFFEC4899);
  static const Color pinkSoft = Color(0xFFFFF1F8);
}

Color _cmrAccent(int index) => _CmrColors.green;

Color _cmrAccentSoft(int index) => _CmrColors.greenSoft;

// ==================== Текстовые стили ====================

class _CmrText {
  static TextStyle title(double size) => AppTypography.custom(
        size: size,
        weight: FontWeight.w600,
        color: _CmrColors.text,
        height: 1.18,
        letterSpacing: 0,
        features: const <FontFeature>[
          FontFeature.tabularFigures(),
        ],
      );

  static TextStyle section() =>
      AppTypography.subsectionTitle(color: _CmrColors.text);

  static TextStyle value(double size) => AppTypography.custom(
        size: size,
        weight: FontWeight.w600,
        color: _CmrColors.text,
        height: 1.16,
        letterSpacing: 0,
        features: const <FontFeature>[
          FontFeature.tabularFigures(),
        ],
      );

  static TextStyle muted(double size) => AppTypography.custom(
        size: size,
        weight: FontWeight.w400,
        color: _CmrColors.muted2,
        height: 1.32,
        letterSpacing: 0,
      );

  static TextStyle caption() =>
      AppTypography.captionMedium(color: _CmrColors.muted2);

  static TextStyle pill() => AppTypography.chip(color: _CmrColors.text);

  static TextStyle tab() => AppTypography.tab(color: _CmrColors.text);

  static TextStyle tabSelected() =>
      AppTypography.tab(color: _CmrColors.text, active: true);

  static TextStyle action() => AppTypography.action(color: _CmrColors.text);

  static TextStyle danger() => AppTypography.custom(
        size: 11.8,
        weight: FontWeight.w600,
        color: _CmrColors.red,
        height: 1.16,
        letterSpacing: 0,
      );

  static TextStyle navLabel({required bool active}) => AppTypography.menuTitle(
        color: active ? _CmrColors.greenDark : _CmrColors.text,
        weight: active ? FontWeight.w600 : FontWeight.w500,
      );

  static TextStyle navSubtitle({required bool active}) =>
      AppTypography.menuSubtitle(
        color:
            active ? _CmrColors.greenDark.withOpacity(.68) : _CmrColors.muted2,
      );
}

class _CmrDecor {
  // Общая геометрия приведена к мобильному/планшетному стилю Tracker Workspace.
  static const double mobilePagePadding = 2.0;
  static const double mobileWindowRadius = 18.0;
  static const double tabletWindowRadius = 16.0;
  static const double mobileCardRadius = 18.0;
  static const double tabletCardRadius = 16.0;
  static const double mobileInnerRadius = 12.0;
  static const double tabletInnerRadius = 12.0;
  static const double sheetRadius = 18.0;
  static const double mobileDockScrollInset = 132.0;

  static List<BoxShadow> get windowShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(.035),
          blurRadius: 28,
          spreadRadius: -18,
          offset: const Offset(0, 16),
        ),
      ];

  static List<BoxShadow> get cardShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(.015),
          blurRadius: 16,
          spreadRadius: -11,
          offset: const Offset(0, 9),
        ),
      ];

  static BoxDecoration workspaceBg() => const BoxDecoration(
        color: _CmrColors.bg,
      );

  static BoxDecoration panel(
          {double radius = tabletCardRadius, bool elevated = true}) =>
      BoxDecoration(
        color: _CmrColors.panel,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: _CmrColors.line.withOpacity(.55), width: .7),
        boxShadow: elevated ? cardShadow : null,
      );

  static BoxDecoration unifiedWindow({double radius = tabletWindowRadius}) =>
      BoxDecoration(
        color: _CmrColors.glass,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Colors.transparent, width: 0),
        boxShadow: windowShadow,
      );

  static BoxDecoration seamlessPane({double radius = 0}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
      );

  static BoxDecoration softCard(
          {double radius = mobileInnerRadius, bool active = false}) =>
      BoxDecoration(
        color: active
            ? Color.alphaBlend(
                _CmrColors.green.withOpacity(.055),
                Colors.white,
              )
            : Color.alphaBlend(
                _CmrColors.green.withOpacity(.010),
                Colors.white,
              ),
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
          color: active
              ? _CmrColors.green.withOpacity(.16)
              : _CmrColors.line.withOpacity(.46),
          width: .65,
        ),
        boxShadow: active ? cardShadow : null,
      );

  static BoxDecoration fluentSurface({
    double radius = mobileInnerRadius,
    Color accent = _CmrColors.green,
    bool active = false,
    bool compact = false,
  }) =>
      BoxDecoration(
        color: active ? _CmrColors.greenSoft : _CmrColors.panel,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(
            color: active
                ? accent.withOpacity(.22)
                : _CmrColors.line.withOpacity(.78),
            width: .85),
      );

  static BoxDecoration greenCard({double radius = mobileInnerRadius}) =>
      fluentSurface(
        radius: radius,
        accent: _CmrColors.green,
        active: true,
      ).copyWith(boxShadow: cardShadow);
}

class _CmrGlowDot extends StatelessWidget {
  final Color color;
  final double size;
  final double opacity;
  final bool halo;

  const _CmrGlowDot({
    super.key,
    required this.color,
    this.size = 6,
    this.opacity = 1,
    this.halo = true,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          boxShadow: halo
              ? <BoxShadow>[
                  BoxShadow(
                    color: color.withOpacity(.16),
                    blurRadius: size * 1.7,
                    spreadRadius: .15,
                  ),
                  BoxShadow(
                    color: color.withOpacity(.055),
                    blurRadius: size * 2.8,
                    spreadRadius: .35,
                  ),
                ]
              : null,
        ),
      ),
    );
  }
}

class _CmrDotCluster extends StatelessWidget {
  final Color color;

  const _CmrDotCluster({
    super.key,
    this.color = _CmrColors.green,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _CmrGlowDot(
          color: color,
          size: 3.5,
          opacity: .28,
          halo: false,
        ),
        const SizedBox(width: 3),
        _CmrGlowDot(
          color: color,
          size: 4.5,
          opacity: .58,
          halo: false,
        ),
        const SizedBox(width: 3),
        _CmrGlowDot(
          color: color,
          size: 6,
        ),
      ],
    );
  }
}

class _FullscreenPhotoDialog extends StatelessWidget {
  final String photoUrl;
  final String name;

  const _FullscreenPhotoDialog({
    required this.photoUrl,
    required this.name,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: const Color(0xFF3A3F47),
      insetPadding: EdgeInsets.zero,
      child: Stack(
        children: [
          Center(
            child: InteractiveViewer(
              minScale: 0.5,
              maxScale: 4.0,
              child: Image.network(
                photoUrl,
                errorBuilder: (_, __, ___) => Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.broken_image, size: 72, color: Colors.grey[600]),
                    const SizedBox(height: 16),
                    Text(
                      'Не удалось загрузить фото',
                      style: TextStyle(color: Colors.grey[400]),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Positioned(
            top: 40,
            right: 20,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white, size: 28),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Text(
              name,
              textAlign: TextAlign.center,
              style: AppTypography.custom(
                size: 16.75,
                weight: FontWeight.w600,
                color: Colors.white,
                height: 1.18,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==================== Основной виджет ====================

class CmrClubTrainersPanel extends StatefulWidget {
  final int clubId;
  final String clubName;
  final List<Map<String, dynamic>> teams;
  final int? selectedTeamId;
  final String selectedTeamName;
  final VoidCallback? onChanged;
  final VoidCallback? onOpenRoster;
  final VoidCallback? onOpenTeams;

  const CmrClubTrainersPanel({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teams,
    required this.selectedTeamId,
    required this.selectedTeamName,
    this.onChanged,
    this.onOpenRoster,
    this.onOpenTeams,
  });

  @override
  State<CmrClubTrainersPanel> createState() => _CmrClubTrainersPanelState();
}

enum _CmrStaffFilter { all, main, coaches, assistants, doctors, press, noTeam }

class _CmrClubTrainersPanelState extends State<CmrClubTrainersPanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';
  static const String getClubTrainersUrl = '$apiBase/get_club_trainers.php';
  static const String getTeamTrainersUrl = '$apiBase/get_team_trainers.php';
  static const String getTeamEventsUrl = '$apiBase/get_team_events.php';
  static const String searchTrainerByEmailUrl =
      '$apiBase/search_trainer_by_email.php';
  static const String searchUsersUrl = '$apiBase/search_users.php';
  static const String linkTrainerToClubUrl =
      '$apiBase/link_trainer_to_club.php';
  static const String unlinkTrainerFromClubUrl =
      '$apiBase/unlink_trainer_from_club.php';
  static const String linkTrainerToTeamUrl =
      '$apiBase/link_trainer_to_team.php';
  static const String setPressStaffScopeUrl =
      '$apiBase/set_press_staff_scope.php';
  static const String removePressStaffUrl = '$apiBase/remove_press_staff.php';
  static const String unlinkTrainerFromTeamUrl =
      '$apiBase/unlink_trainer_from_team.php';
  static const String getTrainerProfileUrl = '$apiBase/get_trainer_profile.php';
  static const String updateTrainerProfileUrl =
      '$apiBase/update_trainer_profile.php';
  static const String updateClubStaffAccountUrl =
      '$apiBase/update_club_staff_account.php';
  static const String resetClubStaffPasswordUrl =
      '$apiBase/reset_club_staff_password.php';
  static const String createChatUrl = '$apiBase/create_chat.php';

  final TextEditingController _searchC = TextEditingController();
  final ScrollController _listScroll = ScrollController();

  bool _loading = true;
  bool _saving = false;
  String? _error;
  _CmrStaffFilter _filter = _CmrStaffFilter.all;
  String _selectedTrainerKey = '';
  List<Map<String, dynamic>> _trainers = [];
  final Map<int, Future<Map<String, dynamic>>> _trainerProfileFutures = {};
  Map<String, dynamic>? _editingTrainer;

  Map<String, dynamic>? _openedTrainerProfile;
  TrainerProfileSection _openedTrainerInitialSection =
      TrainerProfileSection.card;
  bool _addTrainerOpen = false;
  bool _staffAdminOpen = false;
  Map<String, dynamic>? _assigningTrainer;
  String _assigningInitialProfile = 'extra';

  int _sideChatId = 0;
  int _sideChatUserId = 0;
  String _sideChatName = '';
  bool _sideChatOpening = false;

  int _currentUserId = 0;
  String _currentUserRole = '';

  @override
  void initState() {
    super.initState();
    _searchC.addListener(() => setState(() {}));
    _loadViewerContext();
    _load();
  }

  Future<void> _loadViewerContext() async {
    try {
      final userId = await PrefUtils.getUserId() ?? 0;
      final role = (await PrefUtils.getRole()).trim().toLowerCase();

      if (!mounted) return;
      setState(() {
        _currentUserId = userId;
        _currentUserRole = role;
      });
    } catch (_) {}
  }

  bool _canManageAllTrainers() {
    final role = _currentUserRole.trim().toLowerCase();

    // Кадровые операции — только клубный аккаунт.
    // Тренер может изменять только собственный профиль.
    return role == 'club' ||
        role == 'клуб' ||
        role == 'club_admin' ||
        role.contains('club');
  }

  bool _canEditTrainerProfile(Map<String, dynamic> trainer) {
    if (_canManageAllTrainers()) return true;

    final trainerId = _trainerId(trainer);
    return trainerId > 0 && _currentUserId > 0 && trainerId == _currentUserId;
  }

  @override
  void didUpdateWidget(covariant CmrClubTrainersPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.clubId != widget.clubId ||
        oldWidget.teams.length != widget.teams.length) {
      _load();
    }
  }

  @override
  void dispose() {
    _searchC.dispose();
    _listScroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;

    final previouslySelectedKey = _selectedTrainerKey;

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final clubList = await _loadClubTrainers();
      final teamList = await _loadTeamTrainers();
      final merged = _mergeTrainers([...clubList, ...teamList])
          .map(_sanitizeTrainerForCurrentClub)
          .toList();

      if (!mounted) return;

      Map<String, dynamic>? selectedForHydration;
      if (merged.isNotEmpty) {
        if (previouslySelectedKey.isNotEmpty) {
          for (final trainer in merged) {
            if (_trainerIdentity(trainer) == previouslySelectedKey) {
              selectedForHydration = trainer;
              break;
            }
          }
        }
        selectedForHydration ??= merged.first;
      }

      final hydrationTarget = selectedForHydration;

      setState(() {
        _trainerProfileFutures.clear();
        _trainers = merged;
        _loading = false;

        if (hydrationTarget != null) {
          _selectedTrainerKey = _trainerIdentity(hydrationTarget);
        } else {
          _selectedTrainerKey = '';
        }
      });

      // Правый инспектор может быть виден сразу, ещё до первого клика по
      // тренеру. Поэтому сразу догружаем профиль + расписание выбранного
      // сотрудника, иначе блок «Рабочие локации» ошибочно показывал 0.
      if (hydrationTarget != null) {
        await _hydrateTrainerForInspector(hydrationTarget);
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = 'Не удалось загрузить тренеров: $e';
      });
    }
  }

  Future<void> _hydrateTrainerForInspector(
    Map<String, dynamic> trainer,
  ) async {
    final key = _trainerIdentity(trainer);
    if (key.isEmpty) return;

    final profileData = await _loadTrainerProfileForCard(trainer);
    if (!mounted) return;

    // Пока шёл запрос пользователь мог выбрать другого тренера.
    if (_selectedTrainerKey.isNotEmpty && _selectedTrainerKey != key) {
      return;
    }

    final profileKey = _trainerIdentity(profileData);

    setState(() {
      final idx = _trainers.indexWhere(
        (item) =>
            _trainerIdentity(item) == key ||
            (profileKey.isNotEmpty &&
                _trainerIdentity(item) == profileKey),
      );

      if (idx >= 0) {
        _trainers[idx] = <String, dynamic>{
          ..._trainers[idx],
          ...profileData,
        };
      }

      _selectedTrainerKey =
          profileKey.isEmpty ? key : profileKey;
    });
  }

  Future<List<Map<String, dynamic>>> _loadClubTrainers() async {
    if (widget.clubId <= 0) return [];
    try {
      final resp = await http.post(Uri.parse(getClubTrainersUrl), body: {
        'club_id': '${widget.clubId}'
      }).timeout(const Duration(seconds: 12));
      final data = _tryDecode(resp.body);
      return _extractList(
          data, const ['trainers', 'coaches', 'users', 'items', 'data']);
    } catch (_) {
      return [];
    }
  }

  Future<List<Map<String, dynamic>>> _loadTeamTrainers() async {
    final result = <Map<String, dynamic>>[];
    for (final team in widget.teams) {
      final teamId = _teamId(team);
      if (teamId <= 0) continue;
      try {
        dynamic data = await _postJson(getTeamTrainersUrl, {'team_id': teamId});
        var list = _extractList(
            data, const ['trainers', 'coaches', 'users', 'items', 'data']);
        if (list.isEmpty) {
          data = await _postForm(getTeamTrainersUrl, {'team_id': '$teamId'});
          list = _extractList(
              data, const ['trainers', 'coaches', 'users', 'items', 'data']);
        }
        for (final raw in list) {
          final item = Map<String, dynamic>.from(raw);
          item['team_id'] ??= teamId;
          item['team_name'] ??= _teamName(team);
          item['team_logo'] ??= _teamLogo(team);
          result.add(item);
        }
      } catch (_) {}
    }
    return result;
  }

  List<Map<String, dynamic>> _mergeTrainers(List<Map<String, dynamic>> list) {
    final map = <String, Map<String, dynamic>>{};
    for (final raw in list) {
      final item = Map<String, dynamic>.from(raw);
      final id = _trainerId(item);
      final email = _s(item['email']).toLowerCase();
      final key = id > 0
          ? 'id:$id'
          : email.isNotEmpty
              ? 'email:$email'
              : 'name:${_trainerName(item).toLowerCase()}';
      final existing = map[key];
      if (existing == null) {
        item['id'] = id > 0 ? id : item['id'];
        item['teams'] = _trainerTeams(item);
        map[key] = item;
      } else {
        final mergedTeams = _trainerTeams(existing);
        for (final team in _trainerTeams(item)) {
          final tid = _teamId(team);
          if (!mergedTeams.any((t) => _teamId(t) == tid && tid > 0))
            mergedTeams.add(team);
        }
        existing['teams'] = mergedTeams;
        for (final e in item.entries) {
          if (_s(existing[e.key]).isEmpty && _s(e.value).isNotEmpty)
            existing[e.key] = e.value;
        }
      }
    }

    final out = map.values.toList();
    out.sort((a, b) {
      final mainA = _isMain(a) ? 0 : 1;
      final mainB = _isMain(b) ? 0 : 1;
      if (mainA != mainB) return mainA.compareTo(mainB);
      return _trainerName(a)
          .toLowerCase()
          .compareTo(_trainerName(b).toLowerCase());
    });
    return out;
  }

  List<Map<String, dynamic>> get _visibleTrainers {
    final q = _searchC.text.trim().toLowerCase();
    return _trainers.where((trainer) {
      final haystack = [
        _trainerName(trainer),
        _trainerRole(trainer),
        _trainerEmail(trainer),
        _trainerPhone(trainer),
        _trainerTeams(trainer).map(_teamName).join(' '),
      ].join(' ').toLowerCase();
      final matchesSearch = q.isEmpty || haystack.contains(q);
      if (!matchesSearch) return false;
      switch (_filter) {
        case _CmrStaffFilter.all:
          return true;
        case _CmrStaffFilter.main:
          return _isMain(trainer);
        case _CmrStaffFilter.coaches:
          return _detectGroup(trainer) == _CmrStaffFilter.coaches;
        case _CmrStaffFilter.assistants:
          return _detectGroup(trainer) == _CmrStaffFilter.assistants;
        case _CmrStaffFilter.doctors:
          return _detectGroup(trainer) == _CmrStaffFilter.doctors;
        case _CmrStaffFilter.press:
          // Во вкладке «Пресс-служба» показываем только уже назначенных.
          // Выдача новой роли выполняется из раздела «Все» через правый инспектор.
          return _trainerPressTeams(trainer).isNotEmpty ||
              _b(trainer['is_press_assistant']);
        case _CmrStaffFilter.noTeam:
          return _trainerTeams(trainer).isEmpty;
      }
    }).toList();
  }

  _CmrStaffFilter _detectGroup(Map<String, dynamic> trainer) {
    if (_isMain(trainer)) return _CmrStaffFilter.main;
    final raw =
        '${_trainerRole(trainer)} ${_s(trainer['profile'])} ${_s(trainer['link_profile'])} ${_s(trainer['staff_role'])} ${_s(trainer['role_code'])} ${_s(trainer['position_code'])}'
            .toLowerCase();
    if (raw.contains('press') || raw.contains('пресс'))
      return _CmrStaffFilter.press;
    if (raw.contains('мед') ||
        raw.contains('врач') ||
        raw.contains('doctor') ||
        raw.contains('med')) return _CmrStaffFilter.doctors;
    if (raw.contains('ассист') ||
        raw.contains('помощ') ||
        raw.contains('assistant')) return _CmrStaffFilter.assistants;
    return _CmrStaffFilter.coaches;
  }

  String _trainerIdentity(Map<String, dynamic>? trainer) {
    if (trainer == null) return '';
    final id = _trainerId(trainer);
    if (id > 0) return 'id:$id';

    final email = _trainerEmail(trainer).toLowerCase();
    if (email.isNotEmpty) return 'email:$email';

    final fallback = [
      _trainerName(trainer),
      _trainerBirthday(trainer),
      _trainerPhone(trainer),
    ].where((value) => value.trim().isNotEmpty).join('|').toLowerCase();

    return fallback.isEmpty ? '' : 'fallback:$fallback';
  }

  Map<String, dynamic>? _selectedTrainerFrom(
      List<Map<String, dynamic>> visible) {
    if (visible.isEmpty) return null;
    if (_selectedTrainerKey.isNotEmpty) {
      for (final trainer in visible) {
        if (_trainerIdentity(trainer) == _selectedTrainerKey) return trainer;
      }
    }
    return visible.first;
  }

  Future<void> _selectTrainerForInspector(
    Map<String, dynamic> trainer,
  ) async {
    final key = _trainerIdentity(trainer);

    // Обычный клик по сотруднику НЕ открывает полный CMR-профиль.
    // Он только выбирает сотрудника и показывает его в правом инспекторе.
    if (mounted) {
      setState(() {
        _selectedTrainerKey = key;
        _addTrainerOpen = false;
        _staffAdminOpen = false;
        _assigningTrainer = null;
        _editingTrainer = null;
        _openedTrainerProfile = null;
        _sideChatId = 0;
        _sideChatUserId = 0;
        _sideChatName = '';
      });
    }

    // Детальные данные догружаем фоном и обновляем правую панель,
    // не переводя пользователя на отдельный экран.
    final profileData = await _loadTrainerProfileForCard(trainer);
    if (!mounted) return;

    // Не подменяем инспектор, если пользователь уже выбрал другого сотрудника.
    if (_selectedTrainerKey.isNotEmpty &&
        key.isNotEmpty &&
        _selectedTrainerKey != key) {
      return;
    }

    final profileKey = _trainerIdentity(profileData);

    setState(() {
      _selectedTrainerKey = profileKey.isEmpty ? key : profileKey;

      final idx = _trainers.indexWhere(
        (item) =>
            _trainerIdentity(item) == key ||
            _trainerIdentity(item) == profileKey,
      );

      if (idx >= 0) {
        _trainers[idx] = <String, dynamic>{
          ..._trainers[idx],
          ...profileData,
        };
      }
    });
  }

  Future<void> _handleOpenTrainer(
    Map<String, dynamic> trainer,
    bool mobile, {
    TrainerProfileSection initialSection = TrainerProfileSection.card,
  }) async {
    final key = _trainerIdentity(trainer);

    // ВАЖНО: открываем подробный профиль СРАЗУ.
    // Раньше здесь сначала ожидались get_trainer_profile.php +
    // расписание всех команд, поэтому экран визуально не менялся
    // несколько секунд и казалось, что подробный профиль не работает.
    if (mounted) {
      setState(() {
        _selectedTrainerKey = key;
        _addTrainerOpen = false;
        _staffAdminOpen = false;
        _openedTrainerInitialSection = initialSection;
        _openedTrainerProfile = Map<String, dynamic>.from(trainer);
      });
    }

    // Данные профиля и расписание догружаем уже после перехода.
    final profileData = await _loadTrainerProfileForCard(trainer);

    if (!mounted || _openedTrainerProfile == null) return;

    // Если пользователь успел открыть другого тренера,
    // результат предыдущего запроса не должен заменить новый профиль.
    final openedKey = _trainerIdentity(_openedTrainerProfile);
    if (openedKey.isNotEmpty && key.isNotEmpty && openedKey != key) {
      return;
    }

    final profileKey = _trainerIdentity(profileData);

    setState(() {
      _selectedTrainerKey = profileKey.isEmpty ? key : profileKey;

      _openedTrainerProfile = <String, dynamic>{
        ...?_openedTrainerProfile,
        ...profileData,
      };

      final idx = _trainers.indexWhere(
        (item) =>
            _trainerIdentity(item) == key ||
            _trainerIdentity(item) == profileKey,
      );

      if (idx >= 0) {
        _trainers[idx] = <String, dynamic>{
          ..._trainers[idx],
          ...profileData,
        };
      }
    });
  }

  void _closeSideChat() {
    if (!mounted) return;
    setState(() {
      _sideChatId = 0;
      _sideChatUserId = 0;
      _sideChatName = '';
      _sideChatOpening = false;
    });
  }

  void _closeTrainerProfile() {
    if (!mounted) return;
    setState(() {
      _openedTrainerProfile = null;
      _openedTrainerInitialSection = TrainerProfileSection.card;
      _editingTrainer = null;
      _addTrainerOpen = false;
      _staffAdminOpen = false;
      _sideChatId = 0;
      _sideChatUserId = 0;
      _sideChatName = '';
      _sideChatOpening = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final opened = _openedTrainerProfile;

    if (opened != null) {
      Widget profileCore() {
        return CmrTrainerProfileScreen(
          trainer: opened,
          clubId: widget.clubId,
          clubName: widget.clubName,
          embeddedInWorkspace: true,
          allowEdit: _canEditTrainerProfile(opened),
          initialSection: _openedTrainerInitialSection,
          onClose: _closeTrainerProfile,
          onMessage: () => _messageTrainer(opened),
          onAssign: null,
          availableTeams: widget.teams,
          onAssignTeam: _canManageAllTrainers()
              ? (teamId, profile) async {
                  final trainerId = _trainerId(opened);

                  if (trainerId <= 0 || teamId <= 0) {
                    return false;
                  }

                  final ok = await _linkTrainerToTeam(
                    trainerId,
                    teamId,
                    profile,
                  );

                  if (!ok) return false;

                  _trainerProfileFutures.clear();
                  await _load();

                  if (!mounted) return true;

                  Map<String, dynamic> base = opened;

                  final identity = _trainerIdentity(opened);

                  for (final item in _trainers) {
                    if (_trainerIdentity(
                          item,
                        ) ==
                        identity) {
                      base = item;
                      break;
                    }
                  }

                  final refreshed = await _loadTrainerProfileForCard(
                    base,
                  );

                  if (mounted) {
                    setState(() {
                      _openedTrainerProfile = refreshed;
                    });
                  }

                  widget.onChanged?.call();
                  return true;
                }
              : null,
          onChanged: () async {
            _trainerProfileFutures.clear();
            await _load();
            widget.onChanged?.call();

            final active = _openedTrainerProfile;
            if (!mounted || active == null) {
              return;
            }

            final refreshed = await _loadTrainerProfileForCard(
              active,
            );

            if (mounted) {
              setState(() {
                _openedTrainerProfile = refreshed;
              });
            }
          },
        );
      }

      return LayoutBuilder(
        builder: (context, constraints) {
          final chatOpen = _sideChatId > 0 && _sideChatUserId > 0;

          final desktop = constraints.maxWidth >= 920;

          if (!chatOpen) {
            return profileCore();
          }

          final chat = _TrainerChatSidePanel(
            chatId: _sideChatId,
            userId: _sideChatUserId,
            chatName: _sideChatName,
            onClose: _closeSideChat,
          );

          if (!desktop) {
            return chat;
          }

          return Row(
            children: <Widget>[
              Expanded(child: profileCore()),
              Container(
                width: 1,
                color: _CmrColors.line,
              ),
              SizedBox(
                width: math.min(
                  460.0,
                  constraints.maxWidth * .42,
                ),
                child: chat,
              ),
            ],
          );
        },
      );
    }

    final visible = _visibleTrainers;
    final assigned = _trainers.where((t) => _trainerTeams(t).isNotEmpty).length;
    final mainCount = _trainers.where(_isMain).length;
    final doctorsCount = _trainers
        .where((t) => _detectGroup(t) == _CmrStaffFilter.doctors)
        .length;

    if (_loading) {
      return const Center(
        child: CircularProgressIndicator(),
      );
    }

    if (_error != null) {
      return _CmrErrorState(
        text: _error!,
        onRetry: _load,
      );
    }

    return _buildMainLayout(
      visible,
      assigned,
      mainCount,
      doctorsCount,
    );
  }

  String _addInitialProfileForFilter(_CmrStaffFilter filter) {
    switch (filter) {
      case _CmrStaffFilter.main:
        return 'main';
      case _CmrStaffFilter.coaches:
        return 'extra';
      case _CmrStaffFilter.assistants:
        return 'assistant';
      case _CmrStaffFilter.doctors:
        return 'doctor';
      case _CmrStaffFilter.press:
        return 'press_assistant';
      case _CmrStaffFilter.all:
      case _CmrStaffFilter.noTeam:
        return 'extra';
    }
  }

  bool _lockAddProfileForFilter(_CmrStaffFilter filter) {
    return filter == _CmrStaffFilter.main ||
        filter == _CmrStaffFilter.coaches ||
        filter == _CmrStaffFilter.assistants ||
        filter == _CmrStaffFilter.doctors ||
        filter == _CmrStaffFilter.press;
  }

  Widget _buildMainLayout(
    List<Map<String, dynamic>> visible,
    int assigned,
    int mainCount,
    int doctorsCount,
  ) {
    final selected = _selectedTrainerFrom(visible);
    final selectedKey = _trainerIdentity(selected);

    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 640;
        final compact = constraints.maxWidth < 980;
        final pressMode = _filter == _CmrStaffFilter.press;
        final addInitialProfile = _addInitialProfileForFilter(_filter);
        final lockAddProfile = _lockAddProfileForFilter(_filter);
        final listWidth = math.min(compact ? 430.0 : 480.0,
            constraints.maxWidth * (compact ? .43 : .45));

        final list = _TrainerListPanel(
          clubName: widget.clubName,
          sectionTitle: pressMode ? 'Пресс-служба' : 'Тренеры',
          sectionSubtitle: pressMode
              ? 'Сотрудники пресс-службы и ожидающие активации'
              : widget.clubName,
          searchHint: pressMode ? 'Поиск в пресс-службе' : 'Поиск тренера',
          pressMode: pressMode,
          trainersCount: _trainers.length,
          visibleCount: visible.length,
          assignedCount: assigned,
          mainCount: mainCount,
          doctorsCount: doctorsCount,
          searchController: _searchC,
          scrollController: _listScroll,
          filter: _filter,
          onFilterChanged: (value) => setState(() => _filter = value),
          trainers: visible,
          selectedKey: selectedKey,
          trainerIdentity: _trainerIdentity,
          onOpenTrainer: (trainer) {
            if (pressMode) {
              final key = _trainerIdentity(trainer);
              if (mounted) {
                setState(() {
                  _selectedTrainerKey = key;
                  _addTrainerOpen = false;
                  _staffAdminOpen = false;
                  _editingTrainer = null;
                });
              }
              if (mobile) {
                _assignTrainer(
                  trainer,
                  initialProfile: 'press_assistant',
                );
              }
              return;
            }
            if (mobile) {
              // На телефоне правой колонки нет, поэтому открываем подробный экран.
              _handleOpenTrainer(trainer, true);
            } else {
              // Desktop/tablet: обычный клик только открывает инспектор справа.
              _selectTrainerForInspector(trainer);
            }
          },
          onAddTrainer: !_canManageAllTrainers() || _saving
              ? null
              : _openAddTrainerRightPanel,
          onAssignTrainer:
              !_canManageAllTrainers() || _saving || _trainers.isEmpty
                  ? null
                  : () => _assignTrainer(
                        selected ??
                            (_visibleTrainers.isEmpty
                                ? _trainers.first
                                : _visibleTrainers.first),
                      ),
          onRefresh: _load,
          onManageAccess:
              _canManageAllTrainers() ? _openStaffAdminPanel : null,
          mobile: mobile,
          compact: compact,
        );

        final content = mobile
            ? Container(
                width: double.infinity,
                color: const Color(0xFFF6F7F6),
                padding: const EdgeInsets.all(6),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: Container(
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.all(Radius.circular(18)),
                    ),
                    child: _assigningTrainer != null
                        ? _TrainerAssignRightPanel(
                            trainer: _assigningTrainer!,
                            clubName: widget.clubName,
                            teams: widget.teams,
                            saving: _saving,
                            initialProfile: _assigningInitialProfile,
                            onClose: _closeTrainerAssignmentPanel,
                            onSaveProfile: ({
                              required String firstName,
                              required String lastName,
                            }) =>
                                _updateClubStaffAccountFromRightPanel(
                              trainer: _assigningTrainer!,
                              firstName: firstName,
                              lastName: lastName,
                            ),
                            onResetPassword: ({
                              required String newPassword,
                            }) =>
                                _resetClubStaffPasswordFromRightPanel(
                              trainer: _assigningTrainer!,
                              newPassword: newPassword,
                            ),
                            onAssign: ({
                              required List<int> teamIds,
                              required bool allTeams,
                              required String profile,
                            }) =>
                                _assignTrainerFromRightPanel(
                              trainer: _assigningTrainer!,
                              teamIds: teamIds,
                              allTeams: allTeams,
                              profile: profile,
                            ),
                          )
                        : _addTrainerOpen
                            ? CmrStaffAddRightPanel(
                                clubId: widget.clubId,
                                clubName: widget.clubName,
                                teams: widget.teams,
                                pressMode: pressMode,
                                initialProfile: addInitialProfile,
                                lockProfile: lockAddProfile,
                                onAssignExistingPress: pressMode
                                    ? ({
                                        required int userId,
                                        required List<int> teamIds,
                                        required bool allTeams,
                                      }) =>
                                        _saveExistingStaffPressAccess(
                                          userId: userId,
                                          teamIds: teamIds,
                                          allTeams: allTeams,
                                        )
                                    : null,
                                onClose: _closeAddTrainerRightPanel,
                                onSaved: () async {
                                  _trainerProfileFutures.clear();
                                  await _load();
                                  widget.onChanged?.call();
                                },
                              )
                            : _staffAdminOpen
                                ? CmrStaffAccessAdminPanel(
                                    clubId: widget.clubId,
                                    clubName: widget.clubName,
                                    staff: _trainers,
                                    allTeams: widget.teams,
                                    onClose: _closeStaffAdminPanel,
                                    onChanged: () async {
                                      _trainerProfileFutures.clear();
                                      await _load();
                                      widget.onChanged?.call();
                                    },
                                  )
                                : list,
                  ),
                ),
              )
            : Container(
                width: double.infinity,
                color: const Color(0xFFF6F7F6),
                padding: EdgeInsets.all(compact ? 8 : 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(compact ? 18 : 20),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(compact ? 18 : 20),
                      boxShadow: _CmrDecor.windowShadow,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        SizedBox(width: listWidth, child: list),
                        Container(width: 1, color: _CmrColors.line),
                        Expanded(
                          child: _editingTrainer != null
                              ? _TrainerEditSidePanel(
                                  trainer: _editingTrainer!,
                                  clubId: widget.clubId,
                                  compact: compact,
                                  fillAvailableWidth: true,
                                  automaticLocations:
                                      _automaticTrainerLocationsForClub(
                                    _editingTrainer!,
                                    widget.clubId,
                                    widget.teams,
                                  ),
                                  onClose: () {
                                    if (mounted) {
                                      setState(() => _editingTrainer = null);
                                    }
                                  },
                                  onLoadProfile: _loadTrainerEditProfile,
                                  onSaveProfile: _saveTrainerEditProfile,
                                  onSaveAccount: ({
                                    required String firstName,
                                    required String lastName,
                                  }) =>
                                      _updateClubStaffAccountFromRightPanel(
                                    trainer: _editingTrainer!,
                                    firstName: firstName,
                                    lastName: lastName,
                                  ),
                                  onResetPassword: ({
                                    required String newPassword,
                                  }) =>
                                      _resetClubStaffPasswordFromRightPanel(
                                    trainer: _editingTrainer!,
                                    newPassword: newPassword,
                                  ),
                                  onSaved: () async {
                                    if (mounted) {
                                      setState(() => _editingTrainer = null);
                                    }
                                    await _afterMutation(
                                      'Профиль тренера обновлён',
                                    );
                                  },
                                )
                              : _sideChatId > 0 && _sideChatUserId > 0
                                  ? _TrainerChatSidePanel(
                                  chatId: _sideChatId,
                                  userId: _sideChatUserId,
                                  chatName: _sideChatName,
                                  onClose: _closeSideChat,
                                )
                              : _assigningTrainer != null
                                  ? _TrainerAssignRightPanel(
                                      trainer: _assigningTrainer!,
                                      clubName: widget.clubName,
                                      teams: widget.teams,
                                      saving: _saving,
                                      initialProfile: _assigningInitialProfile,
                                      onClose: _closeTrainerAssignmentPanel,
                                      onSaveProfile: ({
                                        required String firstName,
                                        required String lastName,
                                      }) =>
                                          _updateClubStaffAccountFromRightPanel(
                                        trainer: _assigningTrainer!,
                                        firstName: firstName,
                                        lastName: lastName,
                                      ),
                                      onResetPassword: ({
                                        required String newPassword,
                                      }) =>
                                          _resetClubStaffPasswordFromRightPanel(
                                        trainer: _assigningTrainer!,
                                        newPassword: newPassword,
                                      ),
                                      onAssign: ({
                                        required List<int> teamIds,
                                        required bool allTeams,
                                        required String profile,
                                      }) =>
                                          _assignTrainerFromRightPanel(
                                        trainer: _assigningTrainer!,
                                        teamIds: teamIds,
                                        allTeams: allTeams,
                                        profile: profile,
                                      ),
                                    )
                                  : _addTrainerOpen
                                      ? CmrStaffAddRightPanel(
                                          clubId: widget.clubId,
                                          clubName: widget.clubName,
                                          teams: widget.teams,
                                          pressMode: pressMode,
                                          initialProfile: addInitialProfile,
                                          lockProfile: lockAddProfile,
                                          onAssignExistingPress: pressMode
                                              ? ({
                                                  required int userId,
                                                  required List<int> teamIds,
                                                  required bool allTeams,
                                                }) =>
                                                  _saveExistingStaffPressAccess(
                                                    userId: userId,
                                                    teamIds: teamIds,
                                                    allTeams: allTeams,
                                                  )
                                              : null,
                                          onClose: _closeAddTrainerRightPanel,
                                          onSaved: () async {
                                            _trainerProfileFutures.clear();
                                            await _load();
                                            widget.onChanged?.call();
                                          },
                                        )
                                      : _staffAdminOpen
                                          ? CmrStaffAccessAdminPanel(
                                              clubId: widget.clubId,
                                              clubName: widget.clubName,
                                              staff: _trainers,
                                              allTeams: widget.teams,
                                              onClose: _closeStaffAdminPanel,
                                              onChanged: () async {
                                                _trainerProfileFutures.clear();
                                                await _load();
                                                widget.onChanged?.call();
                                              },
                                            )
                                          : pressMode
                                          ? _PressServiceDetailPanel(
                                              trainer: selected,
                                              clubId: widget.clubId,
                                              allTeams: widget.teams,
                                              onAccessChanged: _load,
                                              clubName: widget.clubName,
                                              allTeamsCount:
                                                  widget.teams.length,
                                              canManageAccess:
                                                  _canManageAllTrainers(),
                                              onManageTeams: selected == null ||
                                                      !_canManageAllTrainers()
                                                  ? null
                                                  : () => _assignTrainer(
                                                        selected,
                                                        initialProfile:
                                                            'press_assistant',
                                                      ),
                                              onRemovePress: selected == null ||
                                                      !_canManageAllTrainers() ||
                                                      _trainerPressTeams(
                                                              selected)
                                                          .isEmpty
                                                  ? null
                                                  : () => _removePressScope(
                                                      selected),
                                              onOpenProfile: selected == null
                                                  ? null
                                                  : () => _handleOpenTrainer(
                                                        selected,
                                                        false,
                                                      ),
                                            )
                                          : _TrainerDetailPanel(
                                              trainer: selected,
                                              clubId: widget.clubId,
                                              allTeams: widget.teams,
                                              onAccessChanged: _load,
                                              clubName: widget.clubName,
                                              canManageAccess:
                                                  _canManageAllTrainers(),
                                              onMessage: selected == null
                                                  ? null
                                                  : () => _messageTrainer(
                                                        selected,
                                                      ),
                                              onEdit: selected == null ||
                                                      !_canEditTrainerProfile(
                                                        selected,
                                                      )
                                                  ? null
                                                  : () => _editTrainer(
                                                        selected,
                                                      ),
                                              onAssign: selected == null ||
                                                      !_canManageAllTrainers()
                                                  ? null
                                                  : () => _assignTrainer(
                                                        selected,
                                                      ),
                                              onUnlinkTeam: selected == null ||
                                                      !_canManageAllTrainers()
                                                  ? null
                                                  : () =>
                                                      _unlinkTrainerFromTeam(
                                                        selected,
                                                      ),
                                              onRemoveClub: selected == null ||
                                                      !_canManageAllTrainers()
                                                  ? null
                                                  : () => _removeFromClub(
                                                        selected,
                                                      ),
                                              onAddTrainer:
                                                  !_canManageAllTrainers() ||
                                                          _saving
                                                      ? null
                                                      : _openAddTrainerRightPanel,
                                              onOpenDetailedProfile: selected ==
                                                      null
                                                  ? null
                                                  : () => _handleOpenTrainer(
                                                        selected,
                                                        false,
                                                      ),
                                              onOpenDocuments: selected == null
                                                  ? null
                                                  : () => _handleOpenTrainer(
                                                        selected,
                                                        false,
                                                        initialSection:
                                                            TrainerProfileSection.documents,
                                                      ),
                                            ),
                        ),
                      ],
                    ),
                  ),
                ),
              );

        return Stack(
          children: [
            content,
            if (mobile && _editingTrainer != null)
              Positioned.fill(
                child: _TrainerEditSidePanel(
                  trainer: _editingTrainer!,
                  clubId: widget.clubId,
                  compact: true,
                  automaticLocations: _automaticTrainerLocationsForClub(
                    _editingTrainer!,
                    widget.clubId,
                    widget.teams,
                  ),
                  onClose: () {
                    if (mounted) setState(() => _editingTrainer = null);
                  },
                  onLoadProfile: _loadTrainerEditProfile,
                  onSaveProfile: _saveTrainerEditProfile,
                  onSaveAccount: ({
                    required String firstName,
                    required String lastName,
                  }) =>
                      _updateClubStaffAccountFromRightPanel(
                    trainer: _editingTrainer!,
                    firstName: firstName,
                    lastName: lastName,
                  ),
                  onResetPassword: ({
                    required String newPassword,
                  }) =>
                      _resetClubStaffPasswordFromRightPanel(
                    trainer: _editingTrainer!,
                    newPassword: newPassword,
                  ),
                  onSaved: () async {
                    if (mounted) setState(() => _editingTrainer = null);
                    await _afterMutation('Профиль тренера обновлён');
                  },
                ),
              ),
          ],
        );
      },
    );
  }

  Future<void> _openTrainerModal(Map<String, dynamic> trainer,
      {bool loadProfile = true}) async {
    if (!mounted) return;

    final profileData =
        loadProfile ? await _loadTrainerProfileForCard(trainer) : trainer;
    if (!mounted) return;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(.18),
      builder: (_) => _TrainerModalSheet(
        trainer: profileData,
        onMessage: () => _messageTrainer(profileData, closeCurrentSheet: true),
        onEdit: () => _editTrainer(
          profileData,
          closeCurrentSheet: true,
        ),
        onAssign: () => _assignTrainer(
          profileData,
          closeCurrentSheet: true,
        ),
        onUnlinkTeam: () => _unlinkTrainerFromTeam(
          profileData,
          closeCurrentSheet: true,
        ),
        onRemoveClub: () => _removeFromClub(
          profileData,
          closeCurrentSheet: true,
        ),
      ),
    );
  }

  Future<void> _openTrainerDetails(Map<String, dynamic> trainer) async {
    Navigator.pop(context);
    await Future<void>.delayed(const Duration(milliseconds: 220));
    if (!mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrainerProfileScreen(
          trainer: trainer,
          onMessage: () => _messageTrainer(trainer),
          onEdit: () => _editTrainer(trainer),
          onAssign: () => _assignTrainer(trainer),
          onUnlinkTeam: () => _unlinkTrainerFromTeam(trainer),
          onRemoveClub: () => _removeFromClub(trainer),
        ),
      ),
    );
  }

  // ==================== Вспомогательные методы ====================

  int _trainerId(Map<String, dynamic> t) => _i(t['user_id'] ??
      t['userId'] ??
      t['trainer_id'] ??
      t['trainerId'] ??
      t['coach_id'] ??
      t['id']);
  int _teamId(Map<String, dynamic> team) =>
      _i(team['id'] ?? team['team_id'] ?? team['teamId']);

  int _teamClubId(Map<String, dynamic> team) =>
      _i(team['club_id'] ?? team['clubId']);

  String _normalizedTeamName(Map<String, dynamic> team) =>
      _teamName(team).trim().toLowerCase().replaceAll(RegExp(r'\s+'), ' ');

  Set<int> get _currentClubTeamIds => widget.teams
      .map(_teamId)
      .where((id) => id > 0)
      .toSet();

  Set<String> get _currentClubTeamNames => widget.teams
      .map(_normalizedTeamName)
      .where((name) => name.isNotEmpty && name != 'команда')
      .toSet();

  bool _teamBelongsToCurrentClub(Map<String, dynamic> team) {
    final explicitClubId = _teamClubId(team);
    if (explicitClubId > 0) return explicitClubId == widget.clubId;

    final teamId = _teamId(team);
    final clubIds = _currentClubTeamIds;
    if (teamId > 0 && clubIds.isNotEmpty) return clubIds.contains(teamId);

    // Старые ответы API иногда не содержат club_id/team_id. В таком случае
    // допускаем только точное совпадение с командой из текущего workspace.
    final name = _normalizedTeamName(team);
    return name.isNotEmpty && _currentClubTeamNames.contains(name);
  }

  List<Map<String, dynamic>> _currentClubTeamsForTrainer(
    Map<String, dynamic> trainer,
  ) {
    final out = <Map<String, dynamic>>[];
    final seen = <String>{};

    for (final raw in _trainerTeams(trainer)) {
      final team = Map<String, dynamic>.from(raw);
      if (!_teamBelongsToCurrentClub(team)) continue;

      final teamId = _teamId(team);
      final key = teamId > 0 ? 'id:$teamId' : 'name:${_normalizedTeamName(team)}';
      if (!seen.add(key)) continue;

      // Подмешиваем каноническое имя/логотип из текущего клуба, чтобы в UI
      // не оставались старые подписи из общего профиля тренера.
      Map<String, dynamic>? canonical;
      if (teamId > 0) {
        for (final clubTeam in widget.teams) {
          if (_teamId(clubTeam) == teamId) {
            canonical = clubTeam;
            break;
          }
        }
      }

      if (canonical != null) {
        team['team_id'] = teamId;
        team['id'] = teamId;
        team['team_name'] = _teamName(canonical);
        team['name'] = _teamName(canonical);
        team['team_logo'] = _teamLogo(canonical);
        team['club_id'] = widget.clubId;
      }

      out.add(team);
    }

    return out;
  }

  List<Map<String, dynamic>> _currentClubPressTeamsForTrainer(
    Map<String, dynamic> trainer,
  ) {
    final out = <Map<String, dynamic>>[];
    final seen = <String>{};
    for (final raw in _trainerPressTeams(trainer)) {
      final team = Map<String, dynamic>.from(raw);
      if (!_teamBelongsToCurrentClub(team)) continue;
      final teamId = _teamId(team);
      final key = teamId > 0 ? 'id:$teamId' : 'name:${_normalizedTeamName(team)}';
      if (!seen.add(key)) continue;
      out.add(team);
    }
    return out;
  }

  String _currentClubRoleCode(List<Map<String, dynamic>> teams) {
    final profiles = teams
        .map((team) => _s(team['profile'] ?? team['link_profile'] ?? team['role_code']))
        .where((value) => value.isNotEmpty)
        .toList();
    if (profiles.any((value) => value.toLowerCase() == 'main')) return 'main';

    // При нескольких назначениях берём наиболее специализированную роль
    // для краткой подписи, а сами команды всё равно отображаются отдельно.
    const priority = <String>[
      'goalkeeper',
      'doctor',
      'assistant',
      'manager',
      'admin',
      'extra',
    ];
    for (final code in priority) {
      if (profiles.any((value) => value.toLowerCase() == code)) return code;
    }
    return profiles.isEmpty ? '' : profiles.first;
  }

  Map<String, dynamic> _sanitizeTrainerForCurrentClub(
    Map<String, dynamic> trainer,
  ) {
    final copy = Map<String, dynamic>.from(trainer);
    final currentTeams = _currentClubTeamsForTrainer(copy);

    copy['teams'] = currentTeams;
    copy['assignments'] = currentTeams;

    // В CMR клуба показываем только назначения внутри текущего клуба.
    // История работы в других клубах при необходимости хранится в описании тренера,
    // поэтому карьерные назначения не передаём дальше в интерфейс.
    copy.remove('career_assignments');
    copy.remove('all_assignments');
    copy.remove('_career_assignments');

    final currentPress = _currentClubPressTeamsForTrainer(copy);
    copy['press_teams'] = currentPress;
    copy['press_assignments'] = currentPress;
    copy['is_press_assistant'] = currentPress.isNotEmpty;

    final roleCode = _currentClubRoleCode(currentTeams);
    copy['_current_club_role'] = roleCode;
    copy['is_main'] = roleCode == 'main';
    copy['is_main_any'] = roleCode == 'main';

    // Эти legacy-поля часто приходили от другой команды/другого клуба.
    // Наличие teams=[] не позволит _trainerTeams() снова использовать их,
    // но обнуляем их и для дочерних экранов, читающих поля напрямую.
    if (currentTeams.isEmpty) {
      copy['team_id'] = 0;
      copy['team_name'] = '';
      copy['team_logo'] = '';
    } else {
      final first = currentTeams.first;
      copy['team_id'] = _teamId(first);
      copy['team_name'] = _teamName(first);
      copy['team_logo'] = _teamLogo(first);
    }

    return copy;
  }

  Future<Map<String, dynamic>> _postForm(
      String url, Map<String, String> body) async {
    final resp = await http
        .post(Uri.parse(url), body: body)
        .timeout(const Duration(seconds: 16));
    final data = _tryDecode(resp.body);
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return {'success': false, 'message': 'Некорректный ответ сервера'};
  }

  Future<Map<String, dynamic>> _postJson(
      String url, Map<String, dynamic> body) async {
    final resp = await http
        .post(Uri.parse(url),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode(body))
        .timeout(const Duration(seconds: 16));
    final data = _tryDecode(resp.body);
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return {'success': false, 'message': 'Некорректный ответ сервера'};
  }

  dynamic _tryDecode(String body) {
    try {
      final start = body.indexOf('{');
      final arrayStart = body.indexOf('[');
      final cut = start >= 0 && (arrayStart < 0 || start < arrayStart)
          ? body.substring(start)
          : arrayStart >= 0
              ? body.substring(arrayStart)
              : body;
      return jsonDecode(cut);
    } catch (_) {
      return null;
    }
  }

  List<Map<String, dynamic>> _extractList(dynamic data, List<String> keys) {
    if (data is List)
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    if (data is Map) {
      for (final key in keys) {
        final value = data[key];
        if (value is List)
          return value
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        if (value is Map && (key == 'trainer' || key == 'user'))
          return [Map<String, dynamic>.from(value)];
      }
      for (final key in keys) {
        final nested = data[key];
        if (nested is Map) {
          final list = _extractList(nested, keys);
          if (list.isNotEmpty) return list;
        }
      }
    }
    return [];
  }

  Map<String, dynamic>? _pickMap(Map<String, dynamic> data, List<String> keys) {
    for (final key in keys) {
      final value = data[key];
      if (value is Map) return Map<String, dynamic>.from(value);
    }
    return null;
  }

  Future<List<Map<String, dynamic>>> _loadTrainerSchedule(
      Map<String, dynamic> trainer) async {
    final rows = <Map<String, dynamic>>[];
    for (final team in _trainerTeams(trainer)) {
      final teamId = _teamId(team);
      if (teamId <= 0) continue;
      try {
        final uri = Uri.parse(getTeamEventsUrl)
            .replace(queryParameters: {'team_id': '$teamId'});
        final response =
            await http.get(uri).timeout(const Duration(seconds: 12));
        final data = _tryDecode(response.body);
        final events =
            _extractList(data, const ['events', 'items', 'rows', 'data']);
        for (final event in events) {
          rows.add(<String, dynamic>{
            ...event,
            'team_id': teamId,
            'team_name': _teamName(team),
          });
        }
      } catch (_) {}
    }

    // ВАЖНО: здесь сохраняем ПОЛНЫЙ календарь назначенных команд,
    // как это делает CmrTrainerProfileScreen. Рабочие локации могут быть
    // указаны в уже прошедших событиях, поэтому фильтрация до «ближайших»
    // событий на этом уровне приводила к расхождению: в рабочем профиле
    // локации были, а в правом CMR-инспекторе показывался 0.
    DateTime? parseDate(dynamic value) =>
        DateTime.tryParse(_s(value).replaceAll(' ', 'T'));

    rows.sort((a, b) {
      final da = parseDate(
            a['start_at'] ?? a['date'] ?? a['event_date'],
          ) ??
          DateTime(2100);
      final db = parseDate(
            b['start_at'] ?? b['date'] ?? b['event_date'],
          ) ??
          DateTime(2100);
      return da.compareTo(db);
    });

    return rows;
  }

  Future<Map<String, dynamic>> _loadTrainerProfileForCard(
      Map<String, dynamic> trainer) async {
    final trainerId = _trainerId(trainer);
    if (trainerId <= 0) return trainer;

    try {
      final data = await _postJson(
        getTrainerProfileUrl,
        <String, dynamic>{
          'trainer_id': trainerId,
          // Новый backend может фильтровать назначения сразу на сервере.
          // Старый endpoint просто проигнорирует дополнительное поле.
          'club_id': widget.clubId,
        },
      );
      final raw =
          _pickMap(data, const ['profile', 'trainer', 'user', 'data']) ?? data;
      final merged = <String, dynamic>{...trainer};

      if (raw is Map) {
        raw.forEach((key, value) {
          if (value != null && value.toString().trim().isNotEmpty) {
            merged[key.toString()] = value;
          }
        });
      }

      final sanitized = _sanitizeTrainerForCurrentClub(merged);
      sanitized['_schedule'] = await _loadTrainerSchedule(sanitized);
      return sanitized;
    } catch (_) {
      final fallback = _sanitizeTrainerForCurrentClub(
        Map<String, dynamic>.from(trainer),
      );
      fallback['_schedule'] = await _loadTrainerSchedule(fallback);
      return fallback;
    }
  }

  Future<void> _messageTrainer(
    Map<String, dynamic> trainer, {
    bool closeCurrentSheet = false,
  }) async {
    final peerId = _trainerId(trainer);

    if (peerId <= 0) {
      Get.snackbar(
        'Чат',
        'Не найден ID тренера',
      );
      return;
    }

    final currentUserId = await PrefUtils.getUserId() ?? 0;

    if (currentUserId <= 0) {
      Get.snackbar(
        'Чат',
        'Не найден текущий пользователь',
      );
      return;
    }

    if (currentUserId == peerId) {
      Get.snackbar(
        'Чат',
        'Это ваш профиль тренера',
      );
      return;
    }

    if (mounted) {
      setState(() {
        _sideChatOpening = true;
        _addTrainerOpen = false;
        _editingTrainer = null;
      });
    }

    try {
      final response = await http.post(
        Uri.parse(createChatUrl),
        body: <String, String>{
          'type': 'private',
          'user_id': '$currentUserId',
          'peer_id': '$peerId',
        },
      );

      final data = _tryDecode(response.body);

      final ok =
          response.statusCode == 200 && data is Map && data['success'] == true;

      if (!ok) {
        final msg = data is Map
            ? _s(
                data['error'] ?? data['message'],
              )
            : '';

        if (mounted) {
          setState(
            () => _sideChatOpening = false,
          );
        }

        Get.snackbar(
          'Чат',
          msg.isEmpty ? 'Не удалось открыть чат' : msg,
        );
        return;
      }

      final chatId = _i(
        data['chat_id'] ?? data['id'],
      );

      if (chatId <= 0) {
        if (mounted) {
          setState(
            () => _sideChatOpening = false,
          );
        }

        Get.snackbar(
          'Чат',
          'Сервер не вернул ID чата',
        );
        return;
      }

      if (!mounted) return;

      if (closeCurrentSheet && Navigator.of(context).canPop()) {
        Navigator.of(context).pop();
      }

      setState(() {
        _sideChatId = chatId;
        _sideChatUserId = currentUserId;
        _sideChatName = _trainerName(trainer);
        _sideChatOpening = false;
      });
    } catch (_) {
      if (mounted) {
        setState(
          () => _sideChatOpening = false,
        );
      }

      Get.snackbar(
        'Чат',
        'Ошибка открытия чата',
      );
    }
  }

  void _openAddTrainerRightPanel() {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Добавлять тренеров может только клубный аккаунт.',
      );
      return;
    }

    if (!mounted || _saving) return;
    setState(() {
      _editingTrainer = null;
      _assigningTrainer = null;
      _staffAdminOpen = false;

      // Панель добавления должна иметь приоритет над ранее открытым чатом.
      // Иначе _addTrainerOpen становится true, но справа продолжает
      // отображаться _TrainerChatSidePanel и кажется, что кнопка не работает.
      _sideChatId = 0;
      _sideChatUserId = 0;
      _sideChatName = '';
      _sideChatOpening = false;

      _addTrainerOpen = true;
    });
  }

  void _closeAddTrainerRightPanel() {
    if (!mounted) return;
    setState(() => _addTrainerOpen = false);
  }

  void _openStaffAdminPanel() {
    if (!_canManageAllTrainers() || !mounted) return;
    setState(() {
      _staffAdminOpen = true;
      _addTrainerOpen = false;
      _assigningTrainer = null;
      _editingTrainer = null;
      _sideChatId = 0;
      _sideChatUserId = 0;
      _sideChatName = '';
      _sideChatOpening = false;
    });
  }

  void _closeStaffAdminPanel() {
    if (!mounted) return;
    setState(() => _staffAdminOpen = false);
  }

  Future<List<Map<String, dynamic>>> _searchTrainerByEmailRight(
    String email,
  ) async {
    final value = email.trim();

    if (value.isEmpty) {
      return const <Map<String, dynamic>>[];
    }

    final data = await _postForm(
      searchTrainerByEmailUrl,
      <String, String>{
        'email': value,
      },
    );

    var rows = _extractList(
      data,
      const <String>[
        'trainers',
        'trainer',
        'users',
        'items',
        'data',
      ],
    );

    // Пресс-ассистент может быть обычным пользователем SPORTOTEKA, а не
    // заранее созданным тренером. Поэтому при пустом trainer-поиске делаем
    // fallback в общий поиск пользователей по точному email.
    if (rows.isEmpty) {
      try {
        final uri = Uri.parse(searchUsersUrl).replace(
          queryParameters: <String, String>{'q': value},
        );
        var response = await http.get(uri).timeout(const Duration(seconds: 12));
        if (response.statusCode == 405) {
          response = await http.post(
            Uri.parse(searchUsersUrl),
            body: <String, String>{'q': value},
          ).timeout(const Duration(seconds: 12));
        }
        final decoded = _tryDecode(response.body);
        rows = _extractList(
          decoded,
          const <String>['users', 'items', 'data', 'results'],
        ).where((user) {
          final email = _s(user['email']).toLowerCase();
          return email == value.toLowerCase();
        }).toList();
      } catch (_) {}
    }

    return rows;
  }

  Future<bool> _addTrainerToClubRight(
    Map<String, dynamic> trainer,
  ) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Добавлять тренеров может только клубный аккаунт.',
      );
      return false;
    }

    final trainerId = _trainerId(trainer);

    if (trainerId <= 0) {
      Get.snackbar(
        'Тренеры',
        'Не найден ID тренера',
      );
      return false;
    }

    final ok = await _saveAction(
      () => _postForm(
        linkTrainerToClubUrl,
        <String, String>{
          'club_id': '${widget.clubId}',
          'trainer_id': '$trainerId',
        },
      ),
    );

    if (!ok) return false;

    if (mounted) {
      setState(
        () => _addTrainerOpen = false,
      );
    }

    await _afterMutation(
      'Тренер добавлен в клуб',
    );

    return true;
  }

  Future<bool> _assignTrainerRight(
    Map<String, dynamic> trainer,
    int teamId,
    String profile,
  ) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать тренеров может только клубный аккаунт.',
      );
      return false;
    }

    final trainerId = _trainerId(trainer);

    if (trainerId <= 0 || teamId == 0) {
      return false;
    }

    try {
      await _postForm(
        linkTrainerToClubUrl,
        <String, String>{
          'club_id': '${widget.clubId}',
          'trainer_id': '$trainerId',
        },
      );
    } catch (_) {}

    if (profile == 'press_assistant') {
      final scopeTeamId = teamId == -1 ? 0 : teamId;
      final ok = await _setPressScope(
        trainerId: trainerId,
        teamId: scopeTeamId,
      );
      if (!ok) return false;

      if (mounted) {
        setState(() => _addTrainerOpen = false);
      }

      await _afterMutation(
        scopeTeamId == 0
            ? 'Сотрудник назначен в пресс-службу всех команд'
            : 'Сотрудник назначен в пресс-службу команды',
      );
      return true;
    }

    final ok = await _linkTrainerToTeam(
      trainerId,
      teamId,
      profile,
    );

    if (!ok) return false;

    if (mounted) {
      setState(() => _addTrainerOpen = false);
    }

    await _afterMutation('Сотрудник назначен в команду');
    return true;
  }

  Future<void> _openStaffInviteDialog() async {
    if (!mounted || _saving) return;

    final changed = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => CmrStaffInviteDialog(
        clubId: widget.clubId,
        clubName: widget.clubName,
        teams: widget.teams,
      ),
    );

    if (changed == true) {
      await _afterMutation(
        'Сотрудник добавлен. Staff Key отправлен на почту',
      );
    }
  }

  Future<void> _searchAndAddTrainer() async {
    if (!mounted) return;

    final emailC = TextEditingController();
    final found = <Map<String, dynamic>>[];
    bool searching = false;

    try {
      final action = await showModalBottomSheet<Map<String, dynamic>>(
        context: context,
        isScrollControlled: true,
        useSafeArea: true,
        backgroundColor: Colors.transparent,
        builder: (sheetContext) {
          return StatefulBuilder(
            builder: (sheetContext, setSheet) {
              Future<void> search() async {
                final email = emailC.text.trim();
                if (email.isEmpty) {
                  if (!sheetContext.mounted) return;
                  setSheet(() {
                    searching = false;
                    found.clear();
                  });
                  return;
                }

                if (!sheetContext.mounted) return;
                setSheet(() => searching = true);

                try {
                  final data = await _postForm(
                      searchTrainerByEmailUrl, {'email': email});
                  final list = _extractList(data,
                      const ['trainers', 'trainer', 'users', 'data', 'items']);
                  if (!sheetContext.mounted) return;
                  setSheet(() {
                    found
                      ..clear()
                      ..addAll(list);
                    searching = false;
                  });
                } catch (_) {
                  if (!sheetContext.mounted) return;
                  setSheet(() {
                    found.clear();
                    searching = false;
                  });
                }
              }

              void closeWithAction(String type, Map<String, dynamic> trainer) {
                Navigator.of(sheetContext).pop(<String, dynamic>{
                  'type': type,
                  'trainer': Map<String, dynamic>.from(trainer),
                });
              }

              return _CmrBottomPanel(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _CmrSheetHandle(),
                    _CmrSheetTitle(
                      icon: Icons.person_add_alt_1_rounded,
                      title: 'Добавить сотрудника',
                      subtitle:
                          'Найдите пользователя по email, добавьте в клуб или сразу назначьте в команду.',
                    ),
                    const SizedBox(height: 16),
                    _CmrInput(
                      controller: emailC,
                      hint: 'Email сотрудника',
                      icon: Icons.alternate_email_rounded,
                      keyboardType: TextInputType.emailAddress,
                      onSubmitted: (_) => search(),
                      suffix: IconButton(
                          onPressed: search,
                          icon: const Icon(Icons.search_rounded)),
                    ),
                    const SizedBox(height: 14),
                    if (searching)
                      const Padding(
                        padding: EdgeInsets.all(22),
                        child: Center(child: CircularProgressIndicator()),
                      )
                    else if (found.isEmpty)
                      const _CmrNotice(
                        icon: Icons.search_rounded,
                        title: 'Введите email',
                        text:
                            'После поиска здесь появятся найденные пользователи с ролью тренера.',
                      )
                    else
                      ConstrainedBox(
                        constraints: BoxConstraints(
                          maxHeight:
                              MediaQuery.sizeOf(sheetContext).height * .42,
                        ),
                        child: ListView.builder(
                          shrinkWrap: true,
                          itemCount: found.length,
                          itemBuilder: (_, index) {
                            final trainer = found[index];
                            final name = _trainerName(trainer);
                            final email = _trainerEmail(trainer);
                            final photo = _trainerPhoto(trainer);
                            return _CmrSearchTrainerTile(
                              name: name,
                              email: email,
                              photo: photo,
                              onAddClub: () => closeWithAction('club', trainer),
                              onAssignTeam: () =>
                                  closeWithAction('team', trainer),
                            );
                          },
                        ),
                      ),
                  ],
                ),
              );
            },
          );
        },
      );

      if (!mounted || action == null) return;

      await Future<void>.delayed(const Duration(milliseconds: 120));
      if (!mounted) return;

      final trainerRaw = action['trainer'];
      if (trainerRaw is! Map) return;
      final trainer = Map<String, dynamic>.from(trainerRaw);
      final trainerId = _trainerId(trainer);
      if (trainerId <= 0) return;

      final type = _s(action['type']);

      if (type == 'club') {
        final ok = await _saveAction(() => _postForm(linkTrainerToClubUrl, {
              'club_id': '${widget.clubId}',
              'trainer_id': '$trainerId',
            }));
        if (ok) await _afterMutation('Тренер добавлен в клуб');
        return;
      }

      if (type == 'team') {
        final team = await _pickTeam();
        if (!mounted || team == null) return;

        await Future<void>.delayed(const Duration(milliseconds: 80));
        if (!mounted) return;

        final profile = await _pickProfileType();
        if (!mounted || profile == null) return;

        final ok = await _linkTrainerToTeam(trainerId, _teamId(team), profile);
        if (ok) await _afterMutation('Сотрудник назначен в команду');
      }
    } finally {
      emailC.dispose();
    }
  }

  Future<void> _editTrainer(
    Map<String, dynamic> trainer, {
    bool closeCurrentSheet = false,
  }) async {
    if (!_canEditTrainerProfile(trainer)) {
      Get.snackbar(
        'Доступ',
        'Тренер может редактировать только собственный профиль.',
      );
      return;
    }

    if (closeCurrentSheet) {
      Navigator.of(context).pop();
      await Future<void>.delayed(const Duration(milliseconds: 220));
    }

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0) {
      Get.snackbar('Тренер', 'Не найден ID тренера');
      return;
    }

    // Перед открытием правого редактора догружаем профиль и расписание.
    // Благодаря этому список рабочих локаций в редакторе и в инспекторе
    // совпадает с подробным рабочим профилем тренера.
    Map<String, dynamic> editData = Map<String, dynamic>.from(trainer);
    try {
      editData = await _loadTrainerProfileForCard(editData);
    } catch (_) {}

    if (!mounted) return;

    final key = _trainerIdentity(editData);
    setState(() {
      _editingTrainer = Map<String, dynamic>.from(editData);
      if (key.isNotEmpty) {
        _selectedTrainerKey = key;
      }

      final idx = _trainers.indexWhere(
        (item) => _trainerIdentity(item) == key,
      );
      if (idx >= 0) {
        _trainers[idx] = <String, dynamic>{
          ..._trainers[idx],
          ...editData,
        };
      }
    });
  }

  Future<Map<String, dynamic>> _loadTrainerEditProfile(int trainerId) async {
    final data =
        await _postJson(
          getTrainerProfileUrl,
          <String, dynamic>{
            'trainer_id': trainerId,
            'club_id': widget.clubId,
          },
        );
    return _pickMap(data, const ['profile', 'trainer', 'user', 'data']) ?? data;
  }

  Future<bool> _saveTrainerEditProfile({
    required int trainerId,
    required String firstName,
    required String lastName,
    required String position,
    required String birthday,
    required String experience,
    required String bio,
    required String workLocations,
    XFile? pickedPhoto,
  }) async {
    final canEdit = _canManageAllTrainers() ||
        (_currentUserId > 0 && _currentUserId == trainerId);

    if (!canEdit) {
      Get.snackbar(
        'Доступ',
        'Нельзя редактировать профиль другого тренера.',
      );
      return false;
    }

    try {
      // Всегда отправляем multipart. Так один и тот же серверный путь
      // используется и для обычного сохранения, и для сохранения с фото.
      // На macOS это также надёжнее, чем читать XFile через dart:io File.
      final req =
          http.MultipartRequest('POST', Uri.parse(updateTrainerProfileUrl));

      req.fields.addAll(<String, String>{
        'trainer_id': '$trainerId',
        'user_id': '$trainerId',
        'actor_user_id': '$_currentUserId',
        'actor_role': _currentUserRole,
        'first_name': firstName.trim(),
        'last_name': lastName.trim(),
        'position': position.trim(),
        'birthday': birthday.trim(),
        'experience': experience.trim(),
        'bio': bio.trim(),
        'work_locations': workLocations.trim(),
      });

      if (pickedPhoto != null) {
        final bytes = await pickedPhoto.readAsBytes();
        if (bytes.isEmpty) {
          Get.snackbar('Ошибка', 'Выбранное фото пустое');
          return false;
        }

        final fileName = pickedPhoto.name.trim().isEmpty
            ? 'trainer_$trainerId.jpg'
            : pickedPhoto.name.trim();

        req.files.add(
          http.MultipartFile.fromBytes(
            'photo',
            bytes,
            filename: fileName,
          ),
        );
      }

      final streamed =
          await req.send().timeout(const Duration(seconds: 35));
      final body = await streamed.stream.bytesToString();
      final data = _tryDecode(body);

      final ok = streamed.statusCode >= 200 &&
          streamed.statusCode < 300 &&
          _isSuccessfulResponse(data);

      if (!ok) {
        final serverMessage = data is Map
            ? _s(data['message'] ?? data['error'] ?? data['detail'])
            : '';
        final fallback = body.trim().isEmpty
            ? 'HTTP ${streamed.statusCode}'
            : 'HTTP ${streamed.statusCode}: ${body.trim().length > 220 ? '${body.trim().substring(0, 220)}…' : body.trim()}';

        Get.snackbar(
          'Ошибка',
          serverMessage.isEmpty ? fallback : serverMessage,
        );
        return false;
      }

      return true;
    } catch (e) {
      Get.snackbar('Ошибка', 'Не удалось сохранить профиль: $e');
      return false;
    }
  }

  Future<void> _assignTrainer(
    Map<String, dynamic> trainer, {
    bool closeCurrentSheet = false,
    String initialProfile = 'extra',
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать сотрудников может только клубный аккаунт.',
      );
      return;
    }

    if (closeCurrentSheet) {
      Navigator.of(context).pop();
      await Future<void>.delayed(const Duration(milliseconds: 220));
    }

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0 || !mounted) return;

    setState(() {
      _selectedTrainerKey = _trainerIdentity(trainer);
      _assigningTrainer = Map<String, dynamic>.from(trainer);
      _assigningInitialProfile = initialProfile;
      _addTrainerOpen = false;
      _staffAdminOpen = false;
      _editingTrainer = null;
      _sideChatId = 0;
      _sideChatUserId = 0;
      _sideChatName = '';
    });
  }

  void _closeTrainerAssignmentPanel() {
    if (!mounted) return;
    setState(() => _assigningTrainer = null);
  }

  Future<bool> _assignTrainerFromRightPanel({
    required Map<String, dynamic> trainer,
    required List<int> teamIds,
    required bool allTeams,
    required String profile,
  }) async {
    final trainerId = _trainerId(trainer);
    final normalizedProfile = profile.trim().toLowerCase();

    if (trainerId <= 0 || normalizedProfile.isEmpty) {
      return false;
    }

    final validTeamIds = teamIds.where((id) => id > 0).toSet().toList();
    final allClubTeamIds =
        widget.teams.map(_teamId).where((id) => id > 0).toSet().toList();

    if (!allTeams && validTeamIds.isEmpty) {
      Get.snackbar('Назначение', 'Выберите хотя бы одну команду');
      return false;
    }

    if (normalizedProfile == 'press_assistant') {
      final ok = await _saveAction(
        () => _postJson(
          setPressStaffScopeUrl,
          <String, dynamic>{
            'club_id': widget.clubId,
            'user_id': trainerId,
            'all_teams': allTeams,
            'team_ids': allTeams ? <int>[] : validTeamIds,
          },
        ),
      );

      if (!ok) return false;

      if (mounted) {
        setState(() => _assigningTrainer = null);
      }

      await _afterMutation(
        allTeams
            ? 'Пресс-служба назначена на все команды клуба'
            : 'Пресс-служба назначена на ${validTeamIds.length} команд(ы)',
      );
      return true;
    }

    final targets = allTeams ? allClubTeamIds : validTeamIds;
    if (targets.isEmpty) {
      Get.snackbar('Назначение', 'В клубе нет команд');
      return false;
    }

    var successCount = 0;
    for (final teamId in targets) {
      final ok = await _linkTrainerToTeam(
        trainerId,
        teamId,
        normalizedProfile,
      );
      if (ok) successCount++;
    }

    if (successCount == 0) return false;

    if (mounted) {
      setState(() => _assigningTrainer = null);
    }

    await _afterMutation(
      successCount == targets.length
          ? 'Сотрудник назначен: $successCount команд(ы)'
          : 'Назначено $successCount из ${targets.length} команд',
    );
    return true;
  }

  Future<bool> _updateClubStaffAccountFromRightPanel({
    required Map<String, dynamic> trainer,
    required String firstName,
    required String lastName,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Изменять данные сотрудников может только администратор клуба.',
      );
      return false;
    }

    final targetUserId = _trainerId(trainer);
    if (targetUserId <= 0 || _currentUserId <= 0) return false;

    final ok = await _saveAction(
      () => _postJson(
        updateClubStaffAccountUrl,
        <String, dynamic>{
          'club_id': widget.clubId,
          'actor_user_id': _currentUserId,
          'user_id': targetUserId,
          'first_name': firstName.trim(),
          'last_name': lastName.trim(),
        },
      ),
    );

    if (!ok) return false;

    if (mounted) {
      setState(() {
        _assigningTrainer = <String, dynamic>{
          ...?_assigningTrainer,
          'first_name': firstName.trim(),
          'last_name': lastName.trim(),
        };
      });
    }

    await _load();

    final updated = _trainers.cast<Map<String, dynamic>?>().firstWhere(
          (item) => item != null && _trainerId(item) == targetUserId,
          orElse: () => null,
        );

    if (mounted && updated != null) {
      setState(() {
        _assigningTrainer = Map<String, dynamic>.from(updated);
        _selectedTrainerKey = _trainerIdentity(updated);
      });
    }

    Get.snackbar('Готово', 'Имя и фамилия сотрудника сохранены');
    widget.onChanged?.call();
    return true;
  }

  Future<bool> _resetClubStaffPasswordFromRightPanel({
    required Map<String, dynamic> trainer,
    required String newPassword,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Изменять пароль сотрудника может только администратор клуба.',
      );
      return false;
    }

    final targetUserId = _trainerId(trainer);
    if (targetUserId <= 0 || _currentUserId <= 0) return false;

    final ok = await _saveAction(
      () => _postJson(
        resetClubStaffPasswordUrl,
        <String, dynamic>{
          'club_id': widget.clubId,
          'actor_user_id': _currentUserId,
          'user_id': targetUserId,
          'new_password': newPassword,
        },
      ),
    );

    if (!ok) return false;

    Get.snackbar('Готово', 'Пароль сотрудника изменён');
    return true;
  }

  Future<void> _assignPressAssistant(
    Map<String, dynamic> trainer,
  ) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать пресс-службу может только клубный аккаунт.',
      );
      return;
    }

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0) {
      Get.snackbar('Пресс-служба', 'Не найден ID сотрудника');
      return;
    }

    final team = await _pickTeam(
      title: 'Команда для пресс-службы',
    );
    if (!mounted || team == null) return;

    final teamId = _teamId(team);
    if (teamId <= 0) return;

    final ok = await _setPressScope(
      trainerId: trainerId,
      teamId: teamId,
    );

    if (ok) {
      await _afterMutation(
        'Сотрудник назначен в пресс-службу команды «${_teamName(team)}»',
      );
    }
  }

  Future<void> _assignPressAssistantAll(
    Map<String, dynamic> trainer,
  ) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать пресс-службу может только клубный аккаунт.',
      );
      return;
    }

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0) {
      Get.snackbar('Пресс-служба', 'Не найден ID сотрудника');
      return;
    }

    final teams = widget.teams.where((team) => _teamId(team) > 0).toList();
    if (teams.isEmpty) {
      Get.snackbar('Пресс-служба', 'В клубе нет команд для назначения');
      return;
    }

    final confirmed = await _confirm(
      title: 'Назначить на все команды?',
      text:
          '${_trainerName(trainer)} получит доступ пресс-службы ко всем ${teams.length} командам клуба.',
      confirmText: 'Назначить',
    );
    if (confirmed != true) return;

    final ok = await _setPressScope(
      trainerId: trainerId,
      teamId: 0,
    );

    if (ok) {
      await _afterMutation(
        'Сотрудник назначен в пресс-службу всех команд',
      );
    }
  }

  Future<void> _openPressAssignmentSheet(
    Map<String, dynamic> trainer,
  ) async {
    if (!_canManageAllTrainers()) return;

    final action = await showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _CmrBottomPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _CmrSheetHandle(),
            _CmrSheetTitle(
              icon: Icons.campaign_outlined,
              title: 'Пресс-служба',
              subtitle:
                  '${_trainerName(trainer)} · выберите область назначения',
            ),
            const SizedBox(height: 12),
            _CmrRolePickTile(
              icon: Icons.groups_2_rounded,
              title: 'Одна команда',
              color: _CmrColors.green,
              onTap: () => Navigator.pop(context, 'one'),
            ),
            const SizedBox(height: 8),
            _CmrRolePickTile(
              icon: Icons.apartment_rounded,
              title: 'Все команды клуба',
              color: _CmrColors.violet,
              onTap: () => Navigator.pop(context, 'all'),
            ),
          ],
        ),
      ),
    );

    if (!mounted || action == null) return;
    if (action == 'all') {
      await _assignPressAssistantAll(trainer);
    } else {
      await _assignPressAssistant(trainer);
    }
  }

  Future<bool> _saveExistingStaffPressAccess({
    required int userId,
    required List<int> teamIds,
    required bool allTeams,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать пресс-службу может только клубный аккаунт.',
      );
      return false;
    }

    if (userId <= 0 || widget.clubId <= 0) return false;

    final validTeamIds = teamIds.where((id) => id > 0).toSet().toList();

    if (!allTeams && widget.teams.isNotEmpty && validTeamIds.isEmpty) {
      Get.snackbar(
        'Пресс-служба',
        'Выберите хотя бы одну команду.',
      );
      return false;
    }

    // ВАЖНО: для уже существующего сотрудника клуба используем
    // отдельный press scope. Не вызываем StaffAccessService.invite:
    // иначе press_assistant стал бы его основной staff-ролью и мог бы
    // перезаписать текущие staff scopes.
    return _saveAction(
      () => _postJson(
        setPressStaffScopeUrl,
        <String, dynamic>{
          'club_id': widget.clubId,
          'user_id': userId,
          'all_teams': allTeams,
          'team_ids': allTeams ? <int>[] : validTeamIds,
        },
      ),
    );
  }

  Future<bool> _setPressScope({
    required int trainerId,
    required int teamId,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать пресс-службу может только клубный аккаунт.',
      );
      return false;
    }

    if (trainerId <= 0 || widget.clubId <= 0 || teamId < 0) {
      return false;
    }

    return _saveAction(
      () => _postJson(
        setPressStaffScopeUrl,
        <String, dynamic>{
          'club_id': widget.clubId,
          'user_id': trainerId,
          'team_id': teamId,
        },
      ),
    );
  }

  Future<void> _removePressScope(
    Map<String, dynamic> trainer,
  ) async {
    if (!_canManageAllTrainers()) return;

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0 || widget.clubId <= 0) return;

    final ok = await _confirm(
      title: 'Убрать из пресс-службы?',
      text:
          '${_trainerName(trainer)} потеряет доступ к добавлению и редактированию новостей клуба. Основная должность сотрудника не изменится.',
      confirmText: 'Убрать',
      danger: true,
    );
    if (ok != true) return;

    final success = await _saveAction(
      () => _postJson(
        removePressStaffUrl,
        <String, dynamic>{
          'club_id': widget.clubId,
          'user_id': trainerId,
        },
      ),
    );

    if (success) {
      await _afterMutation('Доступ пресс-службы удалён');
    }
  }

  Future<bool> _linkTrainerToTeam(
      int trainerId, int teamId, String profile) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Назначать тренеров может только клубный аккаунт.',
      );
      return false;
    }

    if (trainerId <= 0 || teamId <= 0) return false;
    if (!_currentClubTeamIds.contains(teamId)) {
      Get.snackbar('Команды', 'Нельзя назначить тренера в команду другого клуба');
      return false;
    }
    return _saveAction(() => _postJson(linkTrainerToTeamUrl, {
          'club_id': widget.clubId,
          'team_id': teamId,
          'trainer_id': trainerId,
          'profile': profile,
        }));
  }

  Future<void> _unlinkTrainerFromTeam(
    Map<String, dynamic> trainer, {
    bool closeCurrentSheet = false,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Изменять назначения может только клубный аккаунт.',
      );
      return;
    }
    if (closeCurrentSheet) {
      Navigator.of(context).pop();
      await Future<void>.delayed(const Duration(milliseconds: 220));
    }

    final trainerId = _trainerId(trainer);
    final teams = _currentClubTeamsForTrainer(trainer);

    if (trainerId <= 0) {
      Get.snackbar('Команды', 'Не найден ID тренера');
      return;
    }

    if (teams.isEmpty) {
      Get.snackbar('Команды', 'У тренера нет назначений в текущем клубе');
      return;
    }

    final team = await _pickTeam(
      from: teams,
      title: 'Отвязать от команды',
    );
    if (team == null) return;

    final teamId = _teamId(team);
    if (teamId <= 0) {
      Get.snackbar('Команды', 'Не найден ID выбранной команды');
      return;
    }

    final ok = await _confirm(
      title: 'Отвязать тренера?',
      text: 'Назначение в команду «${_teamName(team)}» будет удалено.',
      danger: true,
      confirmText: 'Отвязать',
    );
    if (ok != true) return;

    final success = await _saveAction(
      () => _unlinkTrainerTeamRequest(
        trainerId: trainerId,
        teamId: teamId,
      ),
    );

    if (success) {
      await _afterMutation('Тренер отвязан от команды «${_teamName(team)}»');
    }
  }

  Future<Map<String, dynamic>> _unlinkTrainerTeamRequest({
    required int trainerId,
    required int teamId,
  }) async {
    if (!_currentClubTeamIds.contains(teamId)) {
      return <String, dynamic>{
        'success': false,
        'message': 'Команда не относится к текущему клубу',
      };
    }

    // unlink_trainer_from_team.php принимает JSON.
    // Не повторяем запрос как form POST: это маскировало реальную
    // серверную ошибку сообщением "team_id required".
    return _postJson(
      unlinkTrainerFromTeamUrl,
      {
        'club_id': widget.clubId,
        'team_id': teamId,
        'trainer_id': trainerId,
      },
    );
  }

  Future<void> _removeFromClub(
    Map<String, dynamic> trainer, {
    bool closeCurrentSheet = false,
  }) async {
    if (!_canManageAllTrainers()) {
      Get.snackbar(
        'Доступ',
        'Удалять тренеров может только клубный аккаунт.',
      );
      return;
    }
    if (closeCurrentSheet) {
      Navigator.of(context).pop();
      await Future.delayed(const Duration(milliseconds: 220));
    }

    final trainerId = _trainerId(trainer);
    if (trainerId <= 0) return;
    final ok = await _confirm(
      title: 'Удалить из клуба?',
      text: 'Тренер будет удалён из списка специалистов клуба.',
      confirmText: 'Удалить',
      danger: true,
    );
    if (ok != true) return;
    final success =
        await _saveAction(() => _postForm(unlinkTrainerFromClubUrl, {
              'club_id': '${widget.clubId}',
              'trainer_id': '$trainerId',
            }));
    if (success) await _afterMutation('Тренер удалён из клуба');
  }

  bool _isSuccessfulResponse(dynamic data) {
    if (data is! Map) return false;

    final success = data['success'];
    final successText = _s(success).toLowerCase();

    if (success == true ||
        success == 1 ||
        successText == 'true' ||
        successText == '1' ||
        successText == 'success' ||
        successText == 'ok') {
      return true;
    }

    final status = _s(data['status']).toLowerCase();
    return status == 'success' || status == 'ok';
  }

  Future<bool> _saveAction(Future<dynamic> Function() request) async {
    if (!mounted) return false;
    setState(() => _saving = true);

    try {
      final data = await request();
      final ok = _isSuccessfulResponse(data);

      if (!ok) {
        final msg = data is Map
            ? _s(data['message'] ?? data['error'] ?? data['detail'])
            : '';

        Get.snackbar(
          'Ошибка',
          msg.isEmpty ? 'Операция не выполнена' : msg,
        );
      }

      return ok;
    } catch (e) {
      Get.snackbar('Ошибка', 'Не удалось выполнить действие: $e');
      return false;
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _afterMutation(String message) async {
    _trainerProfileFutures.clear();
    Get.snackbar('Готово', message);
    await _load();
    widget.onChanged?.call();
  }

  Future<Map<String, dynamic>?> _pickTeam(
      {List<Map<String, dynamic>>? from,
      String title = 'Выберите команду'}) async {
    final source = from ?? widget.teams;
    if (source.isEmpty) {
      Get.snackbar('Команды', 'Сначала добавьте команду клуба');
      return null;
    }
    return showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _CmrBottomPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _CmrSheetHandle(),
            _CmrSheetTitle(
                icon: Icons.groups_2_rounded,
                title: title,
                subtitle:
                    'Назначение тренера будет привязано к выбранной команде.'),
            const SizedBox(height: 12),
            ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 420),
              child: ListView.separated(
                shrinkWrap: true,
                itemCount: source.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (context, index) {
                  final team = source[index];
                  return _CmrTeamPickTile(
                    name: _teamName(team),
                    logo: _teamLogo(team),
                    onTap: () => Navigator.pop(context, team),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Future<String?> _pickProfileType() {
    const variants = [
      (
        'main',
        'Главный тренер',
        Icons.workspace_premium_rounded,
        _CmrColors.green
      ),
      ('extra', 'Тренер / специалист', Icons.sports_rounded, _CmrColors.blue),
      (
        'goalkeeper',
        'Тренер по вратарям',
        Icons.sports_soccer_rounded,
        _CmrColors.cyan,
      ),
      ('assistant', 'Ассистент', Icons.support_agent_rounded, _CmrColors.amber),
      ('doctor', 'Врач спортивной медицины', Icons.health_and_safety_rounded, _CmrColors.red),
      (
        'manager',
        'Администратор',
        Icons.admin_panel_settings_rounded,
        _CmrColors.muted
      ),
      (
        'press_assistant',
        'Пресс-служба',
        Icons.campaign_outlined,
        _CmrColors.green
      ),
    ];
    return showModalBottomSheet<String>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _CmrBottomPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const _CmrSheetHandle(),
            _CmrSheetTitle(
                icon: Icons.badge_rounded,
                title: 'Роль в команде',
                subtitle: 'Выберите роль сотрудника в штабе команды.'),
            const SizedBox(height: 12),
            for (final item in variants)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: _CmrRolePickTile(
                  icon: item.$3,
                  title: item.$2,
                  color: item.$4,
                  onTap: () => Navigator.pop(context, item.$1),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<bool?> _confirm(
      {required String title,
      required String text,
      required String confirmText,
      bool danger = false}) {
    return showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _CmrBottomPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const _CmrSheetHandle(),
            _CmrRoundIcon(
                icon: danger
                    ? Icons.warning_amber_rounded
                    : Icons.verified_rounded,
                color: danger ? _CmrColors.red : _CmrColors.green,
                size: 52),
            const SizedBox(height: 14),
            Text(title, textAlign: TextAlign.center, style: _CmrText.title(20)),
            const SizedBox(height: 8),
            Text(text, textAlign: TextAlign.center, style: _CmrText.muted(14)),
            const SizedBox(height: 18),
            Row(
              children: [
                Expanded(
                    child: _CmrSecondaryButton(
                        title: 'Отмена',
                        onTap: () => Navigator.pop(context, false))),
                const SizedBox(width: 10),
                Expanded(
                    child: _CmrPrimaryButton(
                        icon: Icons.check_rounded,
                        title: confirmText,
                        color: danger ? _CmrColors.red : _CmrColors.green,
                        onTap: () => Navigator.pop(context, true))),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

// ==================== Панель тренеров в стиле раздела «Состав» ====================

class _TrainerListPanel extends StatelessWidget {
  final String clubName;
  final String sectionTitle;
  final String sectionSubtitle;
  final String searchHint;
  final bool pressMode;
  final int trainersCount;
  final int visibleCount;
  final int assignedCount;
  final int mainCount;
  final int doctorsCount;
  final TextEditingController searchController;
  final ScrollController? scrollController;
  final _CmrStaffFilter filter;
  final ValueChanged<_CmrStaffFilter> onFilterChanged;
  final List<Map<String, dynamic>> trainers;
  final String selectedKey;
  final String Function(Map<String, dynamic>?) trainerIdentity;
  final ValueChanged<Map<String, dynamic>> onOpenTrainer;
  final VoidCallback? onAddTrainer;
  final VoidCallback? onAssignTrainer;
  final Future<void> Function()? onRefresh;
  final VoidCallback? onManageAccess;
  final bool mobile;
  final bool compact;

  const _TrainerListPanel({
    required this.clubName,
    required this.sectionTitle,
    required this.sectionSubtitle,
    required this.searchHint,
    required this.pressMode,
    required this.trainersCount,
    required this.visibleCount,
    required this.assignedCount,
    required this.mainCount,
    required this.doctorsCount,
    required this.searchController,
    required this.scrollController,
    required this.filter,
    required this.onFilterChanged,
    required this.trainers,
    required this.selectedKey,
    required this.trainerIdentity,
    required this.onOpenTrainer,
    required this.onAddTrainer,
    required this.onAssignTrainer,
    required this.onRefresh,
    required this.onManageAccess,
    required this.mobile,
    required this.compact,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: const BoxDecoration(
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: EdgeInsets.symmetric(
                horizontal: mobile ? 10 : 12, vertical: 10),
            decoration: const BoxDecoration(
              color: Colors.transparent,
              border: Border(
                  bottom: BorderSide(color: _CmrColors.line, width: .55)),
            ),
            child: _TrainerHeader(
              clubName: clubName,
              title: sectionTitle,
              subtitle: sectionSubtitle,
              trainersCount: trainersCount,
              visibleCount: visibleCount,
              assignedCount: assignedCount,
              mainCount: mainCount,
              doctorsCount: doctorsCount,
              onAddTrainer: onAddTrainer,
              onAssignTrainer: onAssignTrainer,
              onRefresh: onRefresh,
              onManageAccess: onManageAccess,
              mobile: mobile,
            ),
          ),
          Container(
            padding:
                EdgeInsets.symmetric(horizontal: mobile ? 10 : 12, vertical: 8),
            color: Colors.transparent,
            child: _TrainerSearch(
              controller: searchController,
              mobile: mobile,
              hint: searchHint,
            ),
          ),
          Container(
            height: 46,
            padding:
                EdgeInsets.symmetric(horizontal: mobile ? 10 : 12, vertical: 6),
            color: Colors.transparent,
            child: _TrainerFilterBar(
                value: filter, onChanged: onFilterChanged, mobile: mobile),
          ),
          Expanded(
            child: trainers.isEmpty
                ? _TrainerEmptyState(
                    title: trainersCount == 0
                        ? 'Тренеры пока не добавлены'
                        : 'Ничего не найдено',
                    text: trainersCount == 0
                        ? 'Добавьте тренера по email или назначьте специалиста в команду.'
                        : 'Измените поиск или фильтр.',
                    onTap: onAddTrainer,
                  )
                : RefreshIndicator(
                    color: _CmrColors.green,
                    onRefresh: onRefresh ?? () async {},
                    child: ListView.separated(
                      controller: scrollController,
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.fromLTRB(
                        10,
                        6,
                        10,
                        mobile ? _CmrDecor.mobileDockScrollInset : 12,
                      ),
                      itemCount: trainers.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 4),
                      itemBuilder: (_, index) {
                        final trainer = trainers[index];
                        final active = selectedKey.isNotEmpty &&
                            selectedKey == trainerIdentity(trainer);
                        return _TrainerTile(
                          trainer: trainer,
                          active: active,
                          onTap: () => onOpenTrainer(trainer),
                          mobile: mobile,
                          pressMode: pressMode,
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _TrainerHeader extends StatelessWidget {
  final String clubName;
  final String title;
  final String subtitle;
  final int trainersCount;
  final int visibleCount;
  final int assignedCount;
  final int mainCount;
  final int doctorsCount;
  final VoidCallback? onAddTrainer;
  final VoidCallback? onAssignTrainer;
  final Future<void> Function()? onRefresh;
  final VoidCallback? onManageAccess;
  final bool mobile;

  const _TrainerHeader({
    required this.clubName,
    required this.title,
    required this.subtitle,
    required this.trainersCount,
    required this.visibleCount,
    required this.assignedCount,
    required this.mainCount,
    required this.doctorsCount,
    required this.onAddTrainer,
    required this.onAssignTrainer,
    required this.onRefresh,
    required this.onManageAccess,
    required this.mobile,
  });

  @override
  Widget build(BuildContext context) {
    final resolvedSubtitle = subtitle.trim().isEmpty
        ? (clubName.trim().isEmpty ? 'Специалисты клуба' : clubName)
        : subtitle;

    return Row(
      children: [
        const _CmrDotCluster(),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: mobile
                    ? AppTypography.screenTitle(color: _CmrColors.text)
                    : _CmrText.title(16.5),
              ),
              const SizedBox(height: 3),
              Text(
                resolvedSubtitle,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: _CmrText.muted(mobile ? 12 : 11.5),
              ),
            ],
          ),
        ),
        if (onRefresh != null && !mobile) ...[
          _TrainerIconButton(
              icon: Icons.refresh_rounded,
              tooltip: 'Обновить',
              onTap: onRefresh!,
              compact: true),
          const SizedBox(width: 6),
        ],
        if (onManageAccess != null) ...[
          _TrainerIconButton(
            icon: Icons.admin_panel_settings_outlined,
            tooltip: 'Доступы сотрудников',
            onTap: onManageAccess,
            compact: true,
          ),
          const SizedBox(width: 6),
        ],
        _TrainerIconButton(
          icon: Icons.person_add_alt_1_rounded,
          tooltip: title == 'Пресс-служба'
              ? 'Добавить в пресс-службу'
              : 'Добавить сотрудника',
          onTap: onAddTrainer,
          emphasized: true,
          compact: true,
        ),
      ],
    );
  }
}

class _TinyCounter extends StatelessWidget {
  final String text;
  const _TinyCounter({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 30),
      height: 28,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: _CmrDecor.fluentSurface(
          radius: 8, accent: _CmrColors.green, active: true, compact: true),
      child: Text(
        text,
        style: const TextStyle(
          color: _CmrColors.green,
          fontSize: 11.55,
          fontWeight: FontWeight.w500,
          height: 1,
        ),
      ),
    );
  }
}

class _TrainerStatChip extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _TrainerStatChip(
      {required this.value, required this.label, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 70,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _CmrColors.panel,
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        border: Border.all(color: _CmrColors.line),
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 38,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            ),
            child: Icon(icon, size: 15, color: _CmrColors.green),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _CmrText.title(18)),
                const SizedBox(height: 3),
                Text(label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _CmrText.muted(10.5)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerIconButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final bool emphasized;
  final bool compact;

  const _TrainerIconButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.emphasized = false,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        child: Ink(
          decoration: _CmrDecor.fluentSurface(
              radius: 10,
              accent: _CmrColors.green,
              active: emphasized,
              compact: true),
          child: InkWell(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            onTap: onTap,
            child: Opacity(
              opacity: onTap == null ? .45 : 1,
              child: SizedBox(
                width: compact ? 34 : 38,
                height: compact ? 34 : 38,
                child: Icon(icon,
                    color: emphasized ? _CmrColors.green : _CmrColors.text,
                    size: compact ? 15 : 16),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerSearch extends StatelessWidget {
  final TextEditingController controller;
  final bool mobile;
  final String hint;

  const _TrainerSearch({
    required this.controller,
    required this.mobile,
    required this.hint,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _CmrColors.line.withOpacity(.70), width: .7),
      ),
      padding: EdgeInsets.symmetric(horizontal: mobile ? 10 : 12),
      child: Row(
        children: [
          const Icon(
            Icons.search_rounded,
            color: _CmrColors.muted2,
            size: 16,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: controller,
              decoration: InputDecoration(
                hintText: hint,
                border: InputBorder.none,
                isDense: true,
              ),
              style: mobile
                  ? AppTypography.formText(color: _CmrColors.text)
                  : _CmrText.value(12.9),
            ),
          ),
          if (controller.text.trim().isNotEmpty)
            InkWell(
              onTap: controller.clear,
              borderRadius: BorderRadius.circular(99),
              child: const Padding(
                padding: EdgeInsets.all(5),
                child: Text(
                  '×',
                  style: TextStyle(
                    color: _CmrColors.muted2,
                    fontSize: 19,
                    height: 1,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _TrainerFilterBar extends StatelessWidget {
  final _CmrStaffFilter value;
  final ValueChanged<_CmrStaffFilter> onChanged;
  final bool mobile;

  const _TrainerFilterBar(
      {required this.value, required this.onChanged, required this.mobile});

  @override
  Widget build(BuildContext context) {
    final items = <_CmrStaffFilter, _StaffFilterData>{
      _CmrStaffFilter.all:
          const _StaffFilterData('Все', Icons.groups_2_rounded),
      _CmrStaffFilter.main:
          const _StaffFilterData('Главные', Icons.workspace_premium_rounded),
      _CmrStaffFilter.coaches:
          const _StaffFilterData('Тренеры', Icons.sports_rounded),
      _CmrStaffFilter.assistants:
          const _StaffFilterData('Ассистенты', Icons.support_agent_rounded),
      _CmrStaffFilter.doctors:
          const _StaffFilterData('Врачи', Icons.health_and_safety_rounded),
      _CmrStaffFilter.press:
          const _StaffFilterData('Пресс-служба', Icons.campaign_outlined),
      _CmrStaffFilter.noTeam:
          const _StaffFilterData('Без команды', Icons.link_off_rounded),
    };

    return SizedBox(
      height: mobile ? 33 : 35,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => SizedBox(width: mobile ? 6 : 8),
        itemBuilder: (_, index) {
          final filter = items.keys.elementAt(index);
          final data = items[filter]!;
          final active = filter == value;
          return _StaffFilterPill(
            label: data.label,
            icon: data.icon,
            active: active,
            onTap: () => onChanged(filter),
            dense: mobile,
          );
        },
      ),
    );
  }
}

class _StaffFilterData {
  final String label;
  final IconData icon;
  const _StaffFilterData(this.label, this.icon);
}

class _StaffFilterPill extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;
  final bool dense;

  const _StaffFilterPill({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
    required this.dense,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          curve: Curves.easeOutCubic,
          constraints: BoxConstraints(
            minHeight: dense ? 34 : 36,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: dense ? 10 : 12,
            vertical: dense ? 7 : 8,
          ),
          decoration: BoxDecoration(
            color: active ? _CmrColors.greenSoft : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            border: Border.all(
              color: active ? _CmrColors.greenBorder : Colors.transparent,
              width: .8,
            ),
          ),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _CmrText.action().copyWith(
              color: active ? _CmrColors.greenDark : _CmrColors.muted2,
              fontSize: dense ? 12.0 : 11.4,
              fontWeight: active ? FontWeight.w600 : FontWeight.w500,
              height: 1,
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerTile extends StatelessWidget {
  final Map<String, dynamic> trainer;
  final bool active;
  final VoidCallback onTap;
  final bool mobile;
  final bool pressMode;

  const _TrainerTile({
    required this.trainer,
    required this.active,
    required this.onTap,
    required this.mobile,
    required this.pressMode,
  });

  @override
  Widget build(BuildContext context) {
    final name = _trainerName(trainer);
    final role = _trainerRole(trainer);
    final team = _teamsText(trainer);
    final photo = _trainerPhoto(trainer);
    final main = _isMain(trainer);
    final pressTeams = _trainerPressTeams(trainer);
    final pressText = pressTeams.isEmpty
        ? 'Не назначен в пресс-службу'
        : 'Пресс: ${pressTeams.map(_teamName).join(', ')}';

    final subtitleParts = pressMode
        ? <String>[
            main ? 'Главный тренер' : role,
            pressText,
          ]
        : <String>[
            main ? 'Главный тренер' : role,
            team,
          ];
    final cleanSubtitleParts =
        subtitleParts.where((e) => e.trim().isNotEmpty).toList();

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 160),
          curve: Curves.easeOutCubic,
          constraints: const BoxConstraints(minHeight: 58),
          padding: const EdgeInsets.fromLTRB(10, 6, 8, 6),
          decoration: BoxDecoration(
            color: active ? _CmrColors.greenSoft : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _CmrGlowDot(
                color: active ? _CmrColors.green : _CmrColors.muted2,
                size: active ? 6.4 : 4.8,
                opacity: active ? 1 : .48,
                halo: active,
              ),
              const SizedBox(width: 9),
              _CmrAvatar(
                photo: photo,
                name: name,
                size: mobile ? 40 : 38,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.navLabel(active: active).copyWith(
                        fontSize: mobile ? 12.0 : 11.0,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      cleanSubtitleParts.join(' · '),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.navSubtitle(active: active).copyWith(
                        fontSize: mobile ? 11.2 : 10.2,
                      ),
                    ),
                  ],
                ),
              ),
              if (main) ...[
                const SizedBox(width: 6),
                _CmrGlowDot(
                  color: _CmrColors.green,
                  size: 5,
                  opacity: active ? .9 : .65,
                  halo: false,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _TrainerListBadge extends StatelessWidget {
  final String text;
  final IconData icon;
  final bool active;

  const _TrainerListBadge({
    required this.text,
    required this.icon,
    this.active = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 180),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: active
            ? Color.alphaBlend(
                _CmrColors.green.withOpacity(.05),
                Colors.white,
              )
            : _CmrColors.soft,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _CmrGlowDot(
            color: active ? _CmrColors.green : _CmrColors.muted2,
            size: active ? 5.5 : 4.5,
            opacity: active ? 1 : .62,
            halo: active,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: active ? _CmrColors.greenDark : _CmrColors.muted,
                fontSize: 10.3,
                fontWeight: FontWeight.w600,
                height: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerStatusBadge extends StatelessWidget {
  final bool main;
  final bool active;

  const _TrainerStatusBadge({
    required this.main,
    required this.active,
  });

  @override
  Widget build(BuildContext context) {
    final enabled = main || active;
    return Container(
      width: 18,
      height: 18,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: enabled
            ? Color.alphaBlend(
                _CmrColors.green.withOpacity(.06),
                Colors.white,
              )
            : _CmrColors.soft,
        borderRadius: BorderRadius.circular(9),
      ),
      child: _CmrGlowDot(
        color: enabled ? _CmrColors.green : _CmrColors.muted2,
        size: 5.5,
        opacity: enabled ? 1 : .62,
        halo: enabled,
      ),
    );
  }
}

class _ChevronBadge extends StatelessWidget {
  final bool active;

  const _ChevronBadge({required this.active});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 26,
      height: 26,
      decoration: BoxDecoration(
        color: active ? _CmrColors.green.withOpacity(.10) : _CmrColors.soft,
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        border: Border.all(
            color:
                active ? _CmrColors.green.withOpacity(.18) : _CmrColors.line),
      ),
      child: Icon(Icons.chevron_right_rounded,
          size: 16, color: active ? _CmrColors.green : _CmrColors.muted2),
    );
  }
}

class _TrainerChatSidePanel extends StatelessWidget {
  final int chatId;
  final int userId;
  final String chatName;
  final VoidCallback onClose;

  const _TrainerChatSidePanel({
    required this.chatId,
    required this.userId,
    required this.chatName,
    required this.onClose,
  });

  @override
  Widget build(BuildContext context) {
    return ColoredBox(
      color: Colors.white,
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 54,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 11,
              ),
              child: Row(
                children: <Widget>[
                  const _CmrDotCluster(
                    color: _CmrColors.green,
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          chatName.isEmpty ? 'Чат' : chatName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: _CmrText.title(11.7),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Личная переписка',
                          style: _CmrText.muted(8.6),
                        ),
                      ],
                    ),
                  ),
                  Material(
                    color: _CmrColors.soft2,
                    borderRadius: BorderRadius.circular(8),
                    child: InkWell(
                      onTap: onClose,
                      borderRadius: BorderRadius.circular(8),
                      child: const SizedBox(
                        width: 30,
                        height: 30,
                        child: Icon(
                          Icons.close_rounded,
                          size: 15,
                          color: _CmrColors.muted2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            height: 1,
            color: _CmrColors.line,
          ),
          Expanded(
            child: ChatRoomScreen(
              key: ValueKey<String>(
                'trainer-side-chat-$chatId-$userId',
              ),
              chatId: chatId,
              userId: userId,
              chatName: chatName,
              embedded: true,
            ),
          ),
        ],
      ),
    );
  }
}

class _CmrTextActionButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback? onTap;

  const _CmrTextActionButton({
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: color.withOpacity(.065),
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Opacity(
          opacity: onTap == null ? .46 : 1,
          child: Container(
            height: 34,
            padding: const EdgeInsets.symmetric(
              horizontal: 10,
            ),
            alignment: Alignment.center,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                _CmrGlowDot(
                  color: color,
                  size: 4.2,
                  opacity: .9,
                  halo: false,
                ),
                const SizedBox(width: 6),
                Flexible(
                  child: Text(
                    label,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.custom(
                      size: 9.1,
                      weight: FontWeight.w600,
                      color: color,
                      height: 1.1,
                      letterSpacing: 0,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerAssignRightPanel extends StatefulWidget {
  final Map<String, dynamic> trainer;
  final String clubName;
  final List<Map<String, dynamic>> teams;
  final bool saving;
  final String initialProfile;
  final VoidCallback onClose;
  final Future<bool> Function({
    required String firstName,
    required String lastName,
  }) onSaveProfile;
  final Future<bool> Function({
    required String newPassword,
  }) onResetPassword;
  final Future<bool> Function({
    required List<int> teamIds,
    required bool allTeams,
    required String profile,
  }) onAssign;

  const _TrainerAssignRightPanel({
    required this.trainer,
    required this.clubName,
    required this.teams,
    required this.saving,
    required this.initialProfile,
    required this.onClose,
    required this.onSaveProfile,
    required this.onResetPassword,
    required this.onAssign,
  });

  @override
  State<_TrainerAssignRightPanel> createState() =>
      _TrainerAssignRightPanelState();
}

class _TrainerAssignRightPanelState extends State<_TrainerAssignRightPanel> {
  final Set<int> _teamIds = <int>{};
  bool _allTeams = false;
  late String _profile;
  bool _working = false;
  bool _savingProfile = false;
  bool _savingPassword = false;
  bool _hideNewPassword = true;
  bool _hideRepeatPassword = true;

  late final TextEditingController _firstNameC;
  late final TextEditingController _lastNameC;
  late final TextEditingController _newPasswordC;
  late final TextEditingController _repeatPasswordC;

  static const roles = <(String, String, IconData, Color)>[
    (
      'main',
      'Главный тренер',
      Icons.workspace_premium_rounded,
      _CmrColors.green,
    ),
    (
      'extra',
      'Тренер / специалист',
      Icons.sports_rounded,
      _CmrColors.blue,
    ),
    (
      'goalkeeper',
      'Тренер по вратарям',
      Icons.sports_soccer_rounded,
      _CmrColors.cyan,
    ),
    (
      'assistant',
      'Ассистент',
      Icons.support_agent_rounded,
      _CmrColors.amber,
    ),
    (
      'doctor',
      'Врач спортивной медицины',
      Icons.health_and_safety_rounded,
      _CmrColors.red,
    ),
    (
      'manager',
      'Администратор',
      Icons.admin_panel_settings_rounded,
      _CmrColors.muted,
    ),
    (
      'press_assistant',
      'Пресс-служба',
      Icons.campaign_outlined,
      _CmrColors.violet,
    ),
  ];

  @override
  void initState() {
    super.initState();
    _firstNameC = TextEditingController(
      text: _s(widget.trainer['first_name'] ?? widget.trainer['firstName']),
    );
    _lastNameC = TextEditingController(
      text: _s(widget.trainer['last_name'] ?? widget.trainer['lastName']),
    );
    _newPasswordC = TextEditingController();
    _repeatPasswordC = TextEditingController();

    final requested = widget.initialProfile.trim().toLowerCase();
    _profile = roles.any((role) => role.$1 == requested) ? requested : 'extra';
    _syncScopeFromExisting();
  }

  @override
  void didUpdateWidget(covariant _TrainerAssignRightPanel oldWidget) {
    super.didUpdateWidget(oldWidget);

    final oldId = _id(oldWidget.trainer);
    final newId = _id(widget.trainer);

    if (oldId != newId) {
      _firstNameC.text =
          _s(widget.trainer['first_name'] ?? widget.trainer['firstName']);
      _lastNameC.text =
          _s(widget.trainer['last_name'] ?? widget.trainer['lastName']);
      _newPasswordC.clear();
      _repeatPasswordC.clear();
    }
  }

  @override
  void dispose() {
    _firstNameC.dispose();
    _lastNameC.dispose();
    _newPasswordC.dispose();
    _repeatPasswordC.dispose();
    super.dispose();
  }

  Future<void> _saveProfile() async {
    if (_savingProfile || _working || widget.saving) return;

    final firstName = _firstNameC.text.trim();
    final lastName = _lastNameC.text.trim();

    if (firstName.isEmpty) {
      Get.snackbar('Профиль', 'Укажите имя');
      return;
    }
    if (lastName.isEmpty) {
      Get.snackbar('Профиль', 'Укажите фамилию');
      return;
    }

    setState(() => _savingProfile = true);
    try {
      await widget.onSaveProfile(
        firstName: firstName,
        lastName: lastName,
      );
    } finally {
      if (mounted) setState(() => _savingProfile = false);
    }
  }

  Future<void> _resetPassword() async {
    if (_savingPassword || _working || widget.saving) return;

    final newPassword = _newPasswordC.text;
    final repeatPassword = _repeatPasswordC.text;

    if (newPassword.length < 8) {
      Get.snackbar(
        'Пароль',
        'Новый пароль должен содержать минимум 8 символов',
      );
      return;
    }
    if (newPassword != repeatPassword) {
      Get.snackbar('Пароль', 'Пароли не совпадают');
      return;
    }

    setState(() => _savingPassword = true);
    try {
      final ok = await widget.onResetPassword(
        newPassword: newPassword,
      );

      if (ok) {
        _newPasswordC.clear();
        _repeatPasswordC.clear();
      }
    } finally {
      if (mounted) setState(() => _savingPassword = false);
    }
  }

  InputDecoration _accountInput({
    required String label,
    required IconData icon,
    Widget? suffixIcon,
  }) {
    return InputDecoration(
      labelText: label,
      prefixIcon: Icon(icon, size: 17),
      suffixIcon: suffixIcon,
      filled: true,
      fillColor: Colors.white,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 11,
      ),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: _CmrColors.line),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: _CmrColors.line),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(
          color: _CmrColors.green,
          width: 1.2,
        ),
      ),
    );
  }

  int _id(Map<String, dynamic> value) =>
      _i(value['id'] ?? value['team_id'] ?? value['teamId']);

  String _name(Map<String, dynamic> value) {
    final result = _s(
      value['name'] ?? value['team_name'] ?? value['teamName'],
    ).trim();
    return result.isEmpty ? 'Команда' : result;
  }

  String _roleTitle(String value) {
    switch (value.trim().toLowerCase()) {
      case 'main':
        return 'Главный тренер';
      case 'goalkeeper':
        return 'Тренер по вратарям';
      case 'assistant':
        return 'Ассистент';
      case 'doctor':
        return 'Врач спортивной медицины';
      case 'manager':
      case 'admin':
        return 'Администратор';
      case 'press_assistant':
        return 'Пресс-служба';
      default:
        return 'Тренер / специалист';
    }
  }

  void _syncScopeFromExisting() {
    _teamIds.clear();
    _allTeams = false;

    if (_profile == 'press_assistant') {
      final press = _trainerPressTeams(widget.trainer);
      if (press.any(
        (item) => _s(item['scope']).trim().toLowerCase() == 'all',
      )) {
        _allTeams = true;
        return;
      }

      for (final item in press) {
        final id = _id(item);
        if (id > 0) _teamIds.add(id);
      }
    } else {
      for (final item in _trainerTeams(widget.trainer)) {
        final currentProfile = _s(
          item['profile'] ?? item['link_profile'] ?? item['role_code'],
        ).trim().toLowerCase();

        if (currentProfile == _profile) {
          final id = _id(item);
          if (id > 0) _teamIds.add(id);
        }
      }
    }

    if (_teamIds.isEmpty && widget.teams.isNotEmpty) {
      final firstId = _id(widget.teams.first);
      if (firstId > 0) _teamIds.add(firstId);
    }
  }

  Future<void> _submit() async {
    if (_working || widget.saving) return;
    if (!_allTeams && _teamIds.isEmpty) return;

    setState(() => _working = true);
    try {
      await widget.onAssign(
        teamIds: _teamIds.toList(),
        allTeams: _allTeams,
        profile: _profile,
      );
    } finally {
      if (mounted) setState(() => _working = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final current = _trainerTeams(widget.trainer);
    final pressCurrent = _trainerPressTeams(widget.trainer);
    final trainerName = _trainerName(widget.trainer);
    final totalTeams = widget.teams.where((team) => _id(team) > 0).length;

    return Container(
      decoration: _CmrDecor.seamlessPane(),
      child: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Роль и команды', style: _CmrText.title(20)),
                    const SizedBox(height: 4),
                    Text(
                      'Выберите роль, затем одну, несколько или все команды.',
                      style: _CmrText.muted(10.4),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Закрыть',
                onPressed: _working ? null : widget.onClose,
                icon: const Icon(Icons.close_rounded),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(11),
            decoration: _CmrDecor.softCard(radius: 12),
            child: Row(
              children: [
                _CmrAvatar(
                  photo: _trainerPhoto(widget.trainer),
                  name: trainerName,
                  size: 50,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        trainerName,
                        style: _CmrText.value(12),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 3),
                      Text(
                        widget.clubName,
                        style: _CmrText.muted(9.4),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Text(
            'Профиль пользователя',
            style: _CmrText.value(11.2),
          ),
          const SizedBox(height: 4),
          Text(
            'Администратор клуба может изменить имя, фамилию и пароль сотрудника.',
            style: _CmrText.muted(9.3),
          ),
          const SizedBox(height: 9),
          Container(
            padding: const EdgeInsets.all(11),
            decoration: _CmrDecor.softCard(radius: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: _firstNameC,
                  textInputAction: TextInputAction.next,
                  decoration: _accountInput(
                    label: 'Имя',
                    icon: Icons.person_outline_rounded,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _lastNameC,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) {
                    if (!_savingProfile) _saveProfile();
                  },
                  decoration: _accountInput(
                    label: 'Фамилия',
                    icon: Icons.badge_outlined,
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  initialValue: _trainerEmail(widget.trainer),
                  readOnly: true,
                  enabled: false,
                  decoration: _accountInput(
                    label: 'Email',
                    icon: Icons.alternate_email_rounded,
                  ),
                ),
                const SizedBox(height: 9),
                SizedBox(
                  width: double.infinity,
                  child: _CmrTextActionButton(
                    label: _savingProfile
                        ? 'Сохранение...'
                        : 'Сохранить имя и фамилию',
                    color: _CmrColors.greenDark,
                    onTap: _savingProfile || _working || widget.saving
                        ? null
                        : _saveProfile,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(11),
            decoration: _CmrDecor.softCard(radius: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(
                      Icons.password_rounded,
                      size: 18,
                      color: _CmrColors.greenDark,
                    ),
                    const SizedBox(width: 7),
                    Text(
                      'Изменить пароль',
                      style: _CmrText.value(10.8),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  'Администратор устанавливает новый пароль без текущего пароля сотрудника.',
                  style: _CmrText.muted(9.1),
                ),
                const SizedBox(height: 9),
                TextField(
                  controller: _newPasswordC,
                  obscureText: _hideNewPassword,
                  autofillHints: const <String>[AutofillHints.newPassword],
                  decoration: _accountInput(
                    label: 'Новый пароль',
                    icon: Icons.lock_reset_rounded,
                    suffixIcon: IconButton(
                      tooltip: _hideNewPassword
                          ? 'Показать пароль'
                          : 'Скрыть пароль',
                      onPressed: () => setState(
                        () => _hideNewPassword = !_hideNewPassword,
                      ),
                      icon: Icon(
                        _hideNewPassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        size: 17,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _repeatPasswordC,
                  obscureText: _hideRepeatPassword,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) {
                    if (!_savingPassword) _resetPassword();
                  },
                  decoration: _accountInput(
                    label: 'Повторите пароль',
                    icon: Icons.verified_user_outlined,
                    suffixIcon: IconButton(
                      tooltip: _hideRepeatPassword
                          ? 'Показать пароль'
                          : 'Скрыть пароль',
                      onPressed: () => setState(
                        () => _hideRepeatPassword = !_hideRepeatPassword,
                      ),
                      icon: Icon(
                        _hideRepeatPassword
                            ? Icons.visibility_outlined
                            : Icons.visibility_off_outlined,
                        size: 17,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 9),
                SizedBox(
                  width: double.infinity,
                  child: _CmrTextActionButton(
                    label: _savingPassword ? 'Изменение...' : 'Изменить пароль',
                    color: _CmrColors.greenDark,
                    onTap: _savingPassword || _working || widget.saving
                        ? null
                        : _resetPassword,
                  ),
                ),
              ],
            ),
          ),
          if (current.isNotEmpty || pressCurrent.isNotEmpty) ...[
            const SizedBox(height: 14),
            Text('Текущие назначения', style: _CmrText.value(11.2)),
            const SizedBox(height: 6),
            for (final item in current)
              Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                decoration: _CmrDecor.softCard(radius: 10),
                child: Row(
                  children: [
                    const _CmrGlowDot(color: _CmrColors.green, size: 5),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        _name(item),
                        style: _CmrText.value(10),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      _roleTitle(
                        _s(
                          item['profile'] ??
                              item['link_profile'] ??
                              item['role_code'],
                        ),
                      ),
                      style: _CmrText.muted(9).copyWith(
                        color: _CmrColors.greenDark,
                      ),
                    ),
                  ],
                ),
              ),
            if (pressCurrent.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(bottom: 6),
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 8,
                ),
                decoration: _CmrDecor.softCard(radius: 10),
                child: Row(
                  children: [
                    const Icon(
                      Icons.campaign_outlined,
                      size: 15,
                      color: _CmrColors.violet,
                    ),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        pressCurrent.any(
                          (item) =>
                              _s(item['scope']).trim().toLowerCase() == 'all',
                        )
                            ? 'Все команды клуба'
                            : pressCurrent.map(_name).join(', '),
                        style: _CmrText.value(10),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      'Пресс-служба',
                      style: _CmrText.muted(9).copyWith(
                        color: _CmrColors.violet,
                      ),
                    ),
                  ],
                ),
              ),
          ],
          const SizedBox(height: 14),
          Text('Роль', style: _CmrText.value(11.2)),
          const SizedBox(height: 5),
          Text(
            _profile == 'press_assistant'
                ? 'Пресс-доступ является дополнительным и не заменяет основную должность.'
                : 'Обычная роль сохраняется в назначении сотрудника на команду.',
            style: _CmrText.muted(9.3),
          ),
          const SizedBox(height: 8),
          for (final role in roles)
            Padding(
              padding: const EdgeInsets.only(bottom: 7),
              child: Material(
                color:
                    _profile == role.$1 ? _CmrColors.greenSoft : Colors.white,
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: _working
                      ? null
                      : () {
                          setState(() {
                            _profile = role.$1;
                            _syncScopeFromExisting();
                          });
                        },
                  borderRadius: BorderRadius.circular(10),
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 48),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 11,
                      vertical: 8,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: _profile == role.$1
                            ? _CmrColors.green.withOpacity(.35)
                            : _CmrColors.line,
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          role.$3,
                          size: 18,
                          color:
                              _profile == role.$1 ? role.$4 : _CmrColors.muted2,
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Text(
                            role.$2,
                            style: _CmrText.value(10.5),
                          ),
                        ),
                        if (_profile == role.$1)
                          const Icon(
                            Icons.check_circle_rounded,
                            size: 18,
                            color: _CmrColors.green,
                          ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: Text('Команды', style: _CmrText.value(11.2)),
              ),
              Text(
                _allTeams ? 'Все $totalTeams' : 'Выбрано ${_teamIds.length}',
                style: _CmrText.muted(9.2),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Material(
            color: _allTeams ? _CmrColors.greenSoft : Colors.white,
            borderRadius: BorderRadius.circular(10),
            child: InkWell(
              onTap: _working || totalTeams == 0
                  ? null
                  : () {
                      setState(() {
                        _allTeams = !_allTeams;
                        if (_allTeams) _teamIds.clear();
                      });
                    },
              borderRadius: BorderRadius.circular(10),
              child: Container(
                constraints: const BoxConstraints(minHeight: 46),
                padding: const EdgeInsets.symmetric(
                  horizontal: 11,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _allTeams
                        ? _CmrColors.green.withOpacity(.35)
                        : _CmrColors.line,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      _allTeams
                          ? Icons.check_circle_rounded
                          : Icons.circle_outlined,
                      size: 18,
                      color: _allTeams ? _CmrColors.green : _CmrColors.muted2,
                    ),
                    const SizedBox(width: 9),
                    Expanded(
                      child: Text(
                        'Все команды клуба',
                        style: _CmrText.value(10.5),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 7),
          if (!_allTeams)
            for (final team in widget.teams)
              if (_id(team) > 0)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Material(
                    color: _teamIds.contains(_id(team))
                        ? _CmrColors.greenSoft
                        : Colors.white,
                    borderRadius: BorderRadius.circular(10),
                    child: InkWell(
                      onTap: _working
                          ? null
                          : () {
                              final id = _id(team);
                              setState(() {
                                if (_teamIds.contains(id)) {
                                  _teamIds.remove(id);
                                } else {
                                  _teamIds.add(id);
                                }
                              });
                            },
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        constraints: const BoxConstraints(minHeight: 44),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 11,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                            color: _teamIds.contains(_id(team))
                                ? _CmrColors.green.withOpacity(.35)
                                : _CmrColors.line,
                          ),
                        ),
                        child: Row(
                          children: [
                            Icon(
                              _teamIds.contains(_id(team))
                                  ? Icons.check_box_rounded
                                  : Icons.check_box_outline_blank_rounded,
                              size: 18,
                              color: _teamIds.contains(_id(team))
                                  ? _CmrColors.green
                                  : _CmrColors.muted2,
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Text(
                                _name(team),
                                style: _CmrText.value(10.3),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
          const SizedBox(height: 10),
          _CmrTextActionButton(
            label: _working || widget.saving
                ? 'Сохранение...'
                : _profile == 'press_assistant'
                    ? 'Сохранить пресс-доступ'
                    : 'Назначить · ${_roleTitle(_profile)}',
            color: _profile == 'press_assistant'
                ? _CmrColors.violet
                : _CmrColors.green,
            onTap: _working || widget.saving || (!_allTeams && _teamIds.isEmpty)
                ? null
                : _submit,
          ),
        ],
      ),
    );
  }
}

class _TrainerAddRightPanel extends StatefulWidget {
  final String clubName;
  final List<Map<String, dynamic>> teams;
  final bool pressMode;
  final bool saving;

  final int Function(Map<String, dynamic>) trainerIdOf;
  final String Function(Map<String, dynamic>) trainerNameOf;
  final String Function(Map<String, dynamic>) trainerEmailOf;
  final String Function(Map<String, dynamic>) trainerPhotoOf;
  final int Function(Map<String, dynamic>) teamIdOf;
  final String Function(Map<String, dynamic>) teamNameOf;

  final VoidCallback onClose;

  final Future<List<Map<String, dynamic>>> Function(
    String email,
  ) onSearch;

  final Future<bool> Function(
    Map<String, dynamic> trainer,
  ) onAddClub;

  final Future<bool> Function(
    Map<String, dynamic> trainer,
    int teamId,
    String profile,
  ) onAssignTeam;

  const _TrainerAddRightPanel({
    required this.clubName,
    required this.teams,
    required this.pressMode,
    required this.saving,
    required this.trainerIdOf,
    required this.trainerNameOf,
    required this.trainerEmailOf,
    required this.trainerPhotoOf,
    required this.teamIdOf,
    required this.teamNameOf,
    required this.onClose,
    required this.onSearch,
    required this.onAddClub,
    required this.onAssignTeam,
  });

  @override
  State<_TrainerAddRightPanel> createState() => _TrainerAddRightPanelState();
}

class _TrainerAddRightPanelState extends State<_TrainerAddRightPanel> {
  final TextEditingController _emailC = TextEditingController();

  bool _searching = false;
  bool _working = false;
  String _message = '';

  List<Map<String, dynamic>> _found = <Map<String, dynamic>>[];

  Map<String, dynamic>? _selected;
  int _teamId = 0;
  String _profile = 'extra';

  @override
  void initState() {
    super.initState();

    if (widget.pressMode) {
      _profile = 'press_assistant';
    }

    if (widget.teams.isNotEmpty) {
      _teamId = widget.teamIdOf(
        widget.teams.first,
      );
    }
  }

  @override
  void dispose() {
    _emailC.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final email = _emailC.text.trim();

    if (email.isEmpty || _searching || _working) {
      return;
    }

    setState(() {
      _searching = true;
      _message = '';
      _found = <Map<String, dynamic>>[];
      _selected = null;
    });

    try {
      final rows = await widget.onSearch(
        email,
      );

      if (!mounted) return;

      setState(() {
        _searching = false;
        _found = rows;

        if (rows.isEmpty) {
          _message = 'Пользователь с таким email не найден.';
        }
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _searching = false;
        _message = 'Ошибка поиска: $e';
      });
    }
  }

  Future<void> _addClub(
    Map<String, dynamic> trainer,
  ) async {
    if (_working || widget.saving) {
      return;
    }

    setState(() => _working = true);

    try {
      await widget.onAddClub(
        trainer,
      );
    } finally {
      if (mounted) {
        setState(
          () => _working = false,
        );
      }
    }
  }

  Future<void> _assign() async {
    final trainer = _selected;

    if (trainer == null || _teamId == 0 || _working || widget.saving) {
      return;
    }

    setState(() => _working = true);

    try {
      await widget.onAssignTeam(
        trainer,
        _teamId,
        _profile,
      );
    } finally {
      if (mounted) {
        setState(
          () => _working = false,
        );
      }
    }
  }

  String _roleTitle(String value) {
    switch (value) {
      case 'main':
        return 'Главный тренер';
      case 'goalkeeper':
        return 'Тренер по вратарям';
      case 'assistant':
        return 'Ассистент';
      case 'doctor':
        return 'Врач спортивной медицины';
      case 'press_assistant':
        return 'Пресс-служба';
      case 'manager':
        return 'Администратор';
      default:
        return 'Тренер / специалист';
    }
  }

  @override
  Widget build(BuildContext context) {
    const roles = <String>[
      'main',
      'extra',
      'goalkeeper',
      'assistant',
      'doctor',
      'manager',
    ];

    return ColoredBox(
      color: Colors.white,
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 58,
            child: Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
              ),
              child: Row(
                children: <Widget>[
                  const _CmrDotCluster(
                    color: _CmrColors.green,
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          widget.pressMode
                              ? 'Добавить в пресс-службу'
                              : 'Добавить сотрудника',
                          style: _CmrText.title(13),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          widget.clubName,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: _CmrText.muted(9),
                        ),
                      ],
                    ),
                  ),
                  Material(
                    color: _CmrColors.soft2,
                    borderRadius: BorderRadius.circular(8),
                    child: InkWell(
                      onTap: _working ? null : widget.onClose,
                      borderRadius: BorderRadius.circular(8),
                      child: const SizedBox(
                        width: 30,
                        height: 30,
                        child: Icon(
                          Icons.close_rounded,
                          size: 15,
                          color: _CmrColors.muted2,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            height: 1,
            color: _CmrColors.line,
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(
              12,
              10,
              12,
              8,
            ),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _emailC,
                    onSubmitted: (_) => _search(),
                    style: AppTypography.formText(color: _CmrColors.text),
                    decoration: InputDecoration(
                      hintText: 'Email сотрудника',
                      hintStyle:
                          AppTypography.formHint(color: _CmrColors.muted2),
                      filled: true,
                      fillColor: _CmrColors.soft,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(
                          8,
                        ),
                        borderSide: BorderSide.none,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(
                          8,
                        ),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(
                          8,
                        ),
                        borderSide: BorderSide.none,
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 9,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                _CmrTextActionButton(
                  label: _searching ? 'Поиск...' : 'Найти',
                  color: _CmrColors.green,
                  onTap: _searching || _working ? null : _search,
                ),
              ],
            ),
          ),
          Expanded(
            child: _found.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Text(
                        _message.isEmpty
                            ? (widget.pressMode
                                ? 'Введите email нового сотрудника. После выбора назначьте его на одну или все команды.'
                                : 'Введите email пользователя SPORTOTEKA.')
                            : _message,
                        textAlign: TextAlign.center,
                        style: _CmrText.muted(
                          9.5,
                        ),
                      ),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(
                      12,
                      5,
                      12,
                      16,
                    ),
                    itemCount: _found.length,
                    separatorBuilder: (_, __) => const SizedBox(
                      height: 6,
                    ),
                    itemBuilder: (context, index) {
                      final trainer = _found[index];

                      final selected = identical(
                            _selected,
                            trainer,
                          ) ||
                          (_selected != null &&
                              widget.trainerIdOf(
                                    _selected!,
                                  ) ==
                                  widget.trainerIdOf(
                                    trainer,
                                  ));

                      return Material(
                        color:
                            selected ? _CmrColors.greenSoft : _CmrColors.soft,
                        borderRadius: BorderRadius.circular(9),
                        child: InkWell(
                          onTap: () => setState(
                            () => _selected = trainer,
                          ),
                          borderRadius: BorderRadius.circular(9),
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Column(
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    _CmrAvatar(
                                      photo: widget.trainerPhotoOf(
                                        trainer,
                                      ),
                                      name: widget.trainerNameOf(
                                        trainer,
                                      ),
                                      size: 36,
                                    ),
                                    const SizedBox(
                                      width: 8,
                                    ),
                                    Expanded(
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: <Widget>[
                                          Text(
                                            widget.trainerNameOf(
                                              trainer,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: _CmrText.value(
                                              10.5,
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 2,
                                          ),
                                          Text(
                                            widget.trainerEmailOf(
                                              trainer,
                                            ),
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: _CmrText.muted(
                                              8.8,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    if (!widget.pressMode)
                                      _CmrTextActionButton(
                                        label: 'В клуб',
                                        color: _CmrColors.greenDark,
                                        onTap: _working
                                            ? null
                                            : () => _addClub(trainer),
                                      ),
                                  ],
                                ),
                                if (selected) ...<Widget>[
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  if (widget.teams.isNotEmpty)
                                    DropdownButtonFormField<int>(
                                      value: _teamId > 0 ? _teamId : null,
                                      decoration: InputDecoration(
                                        filled: true,
                                        fillColor: Colors.white,
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(
                                            8,
                                          ),
                                          borderSide: BorderSide.none,
                                        ),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                          horizontal: 9,
                                          vertical: 8,
                                        ),
                                      ),
                                      items: <DropdownMenuItem<int>>[
                                        if (widget.pressMode)
                                          DropdownMenuItem<int>(
                                            value: -1,
                                            child: Text(
                                              'Все команды клуба',
                                              style: _CmrText.value(9.3),
                                            ),
                                          ),
                                        ...widget.teams.map(
                                          (team) => DropdownMenuItem<int>(
                                            value: widget.teamIdOf(team),
                                            child: Text(
                                              widget.teamNameOf(team),
                                              style: _CmrText.value(9.3),
                                            ),
                                          ),
                                        ),
                                      ],
                                      onChanged: _working
                                          ? null
                                          : (value) {
                                              if (value == null) {
                                                return;
                                              }
                                              setState(
                                                () => _teamId = value,
                                              );
                                            },
                                    ),
                                  const SizedBox(height: 7),
                                  if (!widget.pressMode)
                                    Wrap(
                                      spacing: 5,
                                      runSpacing: 5,
                                      children: roles
                                          .map(
                                            (role) => _CmrRoleChoice(
                                              label: _roleTitle(role),
                                              active: _profile == role,
                                              onTap: _working
                                                  ? null
                                                  : () => setState(
                                                        () => _profile = role,
                                                      ),
                                            ),
                                          )
                                          .toList(),
                                    ),
                                  const SizedBox(height: 8),
                                  Align(
                                    alignment: Alignment.centerRight,
                                    child: _CmrTextActionButton(
                                      label: _working
                                          ? 'Назначение...'
                                          : widget.pressMode
                                              ? (_teamId == -1
                                                  ? 'Назначить на все команды'
                                                  : 'Назначить в пресс-службу')
                                              : 'Назначить в команду',
                                      color: _CmrColors.green,
                                      onTap: _working || _teamId == 0
                                          ? null
                                          : _assign,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _CmrRoleChoice extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback? onTap;

  const _CmrRoleChoice({
    required this.label,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? _CmrColors.greenSoft : Colors.white,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 8,
            vertical: 7,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              _CmrGlowDot(
                color: active ? _CmrColors.green : _CmrColors.muted2,
                size: active ? 5 : 4,
              ),
              const SizedBox(width: 5),
              Text(
                label,
                style: _CmrText.muted(
                  8.5,
                ).copyWith(
                  color: active ? _CmrColors.greenDark : _CmrColors.muted,
                  fontWeight: active ? FontWeight.w600 : FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


class _StaffAccessSummaryCard extends StatelessWidget {
  final String role;
  final List<Map<String, dynamic>> teams;

  const _StaffAccessSummaryCard({
    required this.role,
    required this.teams,
  });

  String _name(Map<String, dynamic> team) {
    final value =
        '${team['team_name'] ?? team['name'] ?? team['teamName'] ?? ''}'.trim();
    if (value.isNotEmpty && value != 'null') return value;
    final id = _i(team['team_id'] ?? team['teamId'] ?? team['id']);
    return id > 0 ? 'Команда #$id' : 'Команда';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(11),
        border: Border.all(
          color: _CmrColors.line.withOpacity(.65),
          width: .7,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: _CmrColors.greenSoft,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.work_outline_rounded,
                  color: _CmrColors.greenDark,
                  size: 17,
                ),
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Рабочая информация',
                      style: _CmrText.value(11.6),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '$role · ${teams.isEmpty ? 'без команды' : '${teams.length} команд(ы)'}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.muted(9.6),
                    ),
                  ],
                ),
              ),
            ],
          ),
          if (teams.isNotEmpty) ...[
            const SizedBox(height: 9),
            Wrap(
              spacing: 5,
              runSpacing: 5,
              children: teams
                  .map(
                    (team) => Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(
                          color: _CmrColors.line.withOpacity(.65),
                          width: .6,
                        ),
                      ),
                      child: Text(
                        _name(team),
                        style: _CmrText.muted(9.1).copyWith(
                          color: _CmrColors.text,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          ],
          const SizedBox(height: 7),
          Text(
            'Staff Key, пароль и действия управления доступны только клубному аккаунту.',
            style: _CmrText.muted(8.9),
          ),
        ],
      ),
    );
  }
}

class _PressServiceDetailPanel extends StatelessWidget {
  final Map<String, dynamic>? trainer;
  final int clubId;
  final List<Map<String, dynamic>> allTeams;
  final Future<void> Function()? onAccessChanged;
  final String clubName;
  final int allTeamsCount;
  final bool canManageAccess;
  final VoidCallback? onManageTeams;
  final VoidCallback? onRemovePress;
  final VoidCallback? onOpenProfile;

  const _PressServiceDetailPanel({
    required this.trainer,
    required this.clubId,
    required this.allTeams,
    required this.onAccessChanged,
    required this.clubName,
    required this.allTeamsCount,
    required this.canManageAccess,
    required this.onManageTeams,
    required this.onRemovePress,
    required this.onOpenProfile,
  });

  @override
  Widget build(BuildContext context) {
    final t = trainer;

    if (t == null) {
      return Container(
        decoration: _CmrDecor.seamlessPane(),
        padding: const EdgeInsets.all(18),
        child: const _TrainerEmptyState(
          title: 'Пресс-служба пока пуста',
          text:
              'Новых сотрудников назначайте во вкладке «Все»: выберите человека, роль «Пресс-служба» и нужные команды.',
          onTap: null,
        ),
      );
    }

    final name = _trainerName(t);
    final primaryRole = _trainerRole(t);
    final photo = _trainerPhoto(t);
    final email = _trainerEmail(t);
    final phone = _trainerPhone(t);
    final city = _trainerCity(t);
    final specialization = _trainerSpecialization(t);
    final bio = _trainerBio(t);
    final pressTeams = _trainerPressTeams(t);

    final hasAllTeams = allTeamsCount > 0 && pressTeams.length >= allTeamsCount;

    final pressScopeText = pressTeams.isEmpty
        ? 'Не назначен'
        : hasAllTeams
            ? 'Все команды клуба'
            : pressTeams.map(_teamName).join(', ');

    final headerRole = primaryRole.trim().isEmpty ||
            primaryRole.toLowerCase().contains('пресс')
        ? 'Пресс-служба'
        : 'Пресс-служба · $primaryRole';

    return Container(
      decoration: _CmrDecor.seamlessPane(),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(0),
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _TrainerDetailHeader(
              name: name,
              role: headerRole,
              photo: photo,
              clubName: clubName,
              main: false,
            ),
            const SizedBox(height: 12),
            if (_staffAccessUserId(t) > 0)
              canManageAccess
                  ? CmrStaffAccessPanel(
                      key: ValueKey(
                        'staff-access-$clubId-${_staffAccessUserId(t)}',
                      ),
                      clubId: clubId,
                      staffUserId: _staffAccessUserId(t),
                      allTeams: allTeams,
                      onChanged: onAccessChanged,
                    )
                  : _StaffAccessSummaryCard(
                      role: 'Пресс-служба',
                      teams: pressTeams,
                    ),
            const SizedBox(height: 12),
            if (onOpenProfile != null)
              _PressOpenWorkProfileButton(
                email: email,
                onTap: onOpenProfile!,
              ),
            const SizedBox(height: 14),
            _PressServiceActionsGroup(
              onManageTeams: onManageTeams,
              onRemovePress: pressTeams.isEmpty ? null : onRemovePress,
            ),
            const SizedBox(height: 18),
            _PressMetricsStrip(
              teams: pressTeams.length,
              allTeams: hasAllTeams,
              hasEmail: email.trim().isNotEmpty,
              hasPhone: phone.trim().isNotEmpty,
            ),
            const SizedBox(height: 18),
            _TrainerDetailSection(
              title: 'Данные сотрудника',
              children: [
                _TrainerDetailRow(
                  icon: Icons.campaign_outlined,
                  label: 'Роль',
                  value: 'Пресс-служба',
                ),
                if (primaryRole.trim().isNotEmpty &&
                    !primaryRole.toLowerCase().contains('пресс'))
                  _TrainerDetailRow(
                    icon: Icons.badge_rounded,
                    label: 'Основная должность',
                    value: primaryRole,
                  ),
                _TrainerDetailRow(
                  icon: Icons.apartment_rounded,
                  label: 'Клуб',
                  value: clubName,
                ),
                _TrainerDetailRow(
                  icon: Icons.groups_2_rounded,
                  label: 'Пресс-доступ',
                  value: pressScopeText,
                ),
                _TrainerDetailRow(
                  icon: Icons.location_city_rounded,
                  label: 'Город',
                  value: city.isEmpty ? 'Не указан' : city,
                ),
                _TrainerDetailRow(
                  icon: Icons.auto_awesome_rounded,
                  label: 'Специализация',
                  value: specialization.isEmpty ? 'Не указана' : specialization,
                ),
              ],
            ),
            const SizedBox(height: 14),
            _TrainerDetailSection(
              title: 'Контакты',
              children: [
                _TrainerDetailRow(
                  icon: Icons.mail_outline_rounded,
                  label: 'Email',
                  value: email.isEmpty ? 'Не указан' : email,
                ),
                _TrainerDetailRow(
                  icon: Icons.phone_rounded,
                  label: 'Телефон',
                  value: phone.isEmpty ? 'Не указан' : phone,
                ),
              ],
            ),
            if (bio.trim().isNotEmpty) ...[
              const SizedBox(height: 14),
              _TrainerCommentBox(
                title: 'О сотруднике',
                text: bio,
              ),
            ],
            if (onRemovePress != null) ...[
              const SizedBox(height: 18),
              _TrainerQuietDangerAction(
                icon: Icons.link_off_rounded,
                text: 'Убрать доступ пресс-службы',
                color: _CmrColors.red,
                onTap: pressTeams.isEmpty ? null : onRemovePress,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _PressOpenWorkProfileButton extends StatelessWidget {
  final String email;
  final VoidCallback onTap;

  const _PressOpenWorkProfileButton({
    required this.email,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.greenSoft,
      borderRadius: BorderRadius.circular(9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          height: 42,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              const _CmrDotCluster(
                color: _CmrColors.green,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Открыть профиль сотрудника',
                      style: _CmrText.value(11.8).copyWith(
                        color: _CmrColors.greenDark,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      email.trim().isEmpty ? 'Имя · фамилия · профиль' : email,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.muted(9.3),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                size: 17,
                color: _CmrColors.greenDark,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PressServiceActionsGroup extends StatelessWidget {
  final VoidCallback? onManageTeams;
  final VoidCallback? onRemovePress;

  const _PressServiceActionsGroup({
    required this.onManageTeams,
    required this.onRemovePress,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        children: [
          _TrainerInspectorAction(
            icon: Icons.tune_rounded,
            title: 'Роль и команды',
            subtitle: 'Изменить пресс-доступ к командам',
            onTap: onManageTeams,
            accent: true,
          ),
          _TrainerInspectorAction(
            icon: Icons.campaign_outlined,
            title: 'Пресс-служба',
            subtitle: 'Дополнительная роль, основная должность сохраняется',
            onTap: null,
          ),
        ],
      ),
    );
  }
}

class _PressMetricsStrip extends StatelessWidget {
  final int teams;
  final bool allTeams;
  final bool hasEmail;
  final bool hasPhone;

  const _PressMetricsStrip({
    required this.teams,
    required this.allTeams,
    required this.hasEmail,
    required this.hasPhone,
  });

  @override
  Widget build(BuildContext context) {
    final contacts = (hasEmail ? 1 : 0) + (hasPhone ? 1 : 0);
    final items = <({String value, String label})>[
      (
        value: allTeams ? 'Все' : '$teams',
        label: 'Команды',
      ),
      (
        value: 'Пресс',
        label: 'Доступ',
      ),
      (
        value: hasEmail ? 'Да' : 'Нет',
        label: 'Email',
      ),
      (
        value: '$contacts/2',
        label: 'Контакты',
      ),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 14,
      ),
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          for (var i = 0; i < items.length; i++) ...[
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    items[i].value,
                    style: _CmrText.title(15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    items[i].label,
                    style: _CmrText.caption(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (i != items.length - 1)
              Container(
                width: 1,
                height: 28,
                color: _CmrColors.line,
              ),
          ],
        ],
      ),
    );
  }
}

class _TrainerDetailPanel extends StatelessWidget {
  final Map<String, dynamic>? trainer;
  final int clubId;
  final List<Map<String, dynamic>> allTeams;
  final String clubName;
  final bool canManageAccess;
  final Future<void> Function()? onAccessChanged;
  final VoidCallback? onMessage;
  final VoidCallback? onEdit;
  final VoidCallback? onAssign;
  final VoidCallback? onUnlinkTeam;
  final VoidCallback? onRemoveClub;
  final VoidCallback? onAddTrainer;
  final VoidCallback? onOpenDetailedProfile;
  final VoidCallback? onOpenDocuments;

  const _TrainerDetailPanel({
    required this.trainer,
    required this.clubId,
    required this.allTeams,
    required this.clubName,
    required this.canManageAccess,
    required this.onAccessChanged,
    required this.onMessage,
    required this.onEdit,
    required this.onAssign,
    required this.onUnlinkTeam,
    required this.onRemoveClub,
    required this.onAddTrainer,
    required this.onOpenDetailedProfile,
    required this.onOpenDocuments,
  });

  @override
  Widget build(BuildContext context) {
    final t = trainer;
    if (t == null) {
      return Container(
        decoration: _CmrDecor.seamlessPane(),
        padding: const EdgeInsets.all(18),
        child: _TrainerEmptyDetail(onAddTrainer: onAddTrainer),
      );
    }

    final name = _trainerName(t);
    final role = _trainerRole(t);
    final roleDescriptor = _trainerRoleDescriptor(t);
    final photo = _trainerPhoto(t);
    final teams = _trainerTeams(t);
    final phone = _trainerPhone(t);
    final email = _trainerEmail(t);
    final birthday = _trainerBirthday(t);
    final city = _trainerCity(t);
    final specialization = _trainerSpecialization(t);
    final bio = _trainerBio(t);
    final main = _isMain(t);
    final schedule = _trainerSchedule(t);
    final locations = _resolvedTrainerLocationsForClub(
      t,
      clubId,
      allTeams,
    );

    return Container(
      decoration: _CmrDecor.seamlessPane(),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(0),
        child: ListView(
          padding: const EdgeInsets.all(14),
          children: [
            _TrainerDetailHeader(
              name: name,
              role: roleDescriptor,
              photo: photo,
              clubName: clubName,
              main: main,
            ),
            const SizedBox(height: 12),
            if (_staffAccessUserId(t) > 0)
              canManageAccess
                  ? CmrStaffAccessPanel(
                      key: ValueKey(
                        'staff-access-$clubId-${_staffAccessUserId(t)}',
                      ),
                      clubId: clubId,
                      staffUserId: _staffAccessUserId(t),
                      allTeams: allTeams,
                      onChanged: onAccessChanged,
                    )
                  : _StaffAccessSummaryCard(
                      role: role,
                      teams: teams,
                    ),
            const SizedBox(height: 12),
            if (onOpenDetailedProfile != null)
              _TrainerOpenWorkProfileButton(
                onTap: onOpenDetailedProfile!,
              ),
            const SizedBox(height: 14),
            _TrainerActionsGroup(
              onEdit: onEdit,
              onMessage: onMessage,
              onAssign: onAssign,
              onDocuments: onOpenDocuments,
            ),
            const SizedBox(height: 18),
            _TrainerMetricsStrip(
              teams: teams.length,
              role: role,
              main: main,
              contacts: [email, phone].where((e) => e.trim().isNotEmpty).length,
            ),
            const SizedBox(height: 18),
            _TrainerScheduleSection(
              schedule: schedule,
              locations: locations,
              onEditLocations: onEdit,
            ),
            const SizedBox(height: 18),
            _TrainerDetailSection(
              title: 'Данные тренера',
              children: [
                _TrainerDetailRow(
                    icon: Icons.badge_rounded,
                    label: 'Роль',
                    value: roleDescriptor),
                _TrainerDetailRow(
                    icon: Icons.apartment_rounded,
                    label: 'Клуб',
                    value: clubName),
                _TrainerDetailRow(
                    icon: Icons.groups_2_rounded,
                    label: 'Текущие команды',
                    value: teams.isEmpty
                        ? 'Команда не назначена'
                        : teams.map(_teamName).join(', ')),
                _TrainerDetailRow(
                    icon: Icons.location_city_rounded,
                    label: 'Город',
                    value: city.isEmpty ? 'Не указан' : city),
                _TrainerDetailRow(
                    icon: Icons.auto_awesome_rounded,
                    label: 'Специализация',
                    value:
                        specialization.isEmpty ? 'Не указана' : specialization),
              ],
            ),
            const SizedBox(height: 14),
            _TrainerDetailSection(
              title: 'Контакты',
              children: [
                _TrainerDetailRow(
                    icon: Icons.mail_outline_rounded,
                    label: 'Email',
                    value: email.isEmpty ? 'Не указан' : email),
                _TrainerDetailRow(
                    icon: Icons.phone_rounded,
                    label: 'Телефон',
                    value: phone.isEmpty ? 'Не указан' : phone),
              ],
            ),
            const SizedBox(height: 14),
            _TrainerCommentBox(
              title: 'О тренере',
              text: bio.isEmpty ? 'Описание пока не заполнено.' : bio,
            ),
            const SizedBox(height: 18),
            _TrainerDangerActionsGroup(
              onUnlinkTeam: onUnlinkTeam,
              onRemoveClub: onRemoveClub,
            ),
          ],
        ),
      ),
    );
  }
}

class _TrainerDetailHeader extends StatelessWidget {
  final String name;
  final String role;
  final String photo;
  final String clubName;
  final bool main;

  const _TrainerDetailHeader({
    required this.name,
    required this.role,
    required this.photo,
    required this.clubName,
    required this.main,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () {
            if (photo.isNotEmpty) {
              showDialog(
                context: context,
                builder: (_) => _FullscreenPhotoDialog(
                  photoUrl: photo,
                  name: name,
                ),
              );
            }
          },
          child: _CmrAvatar(
            photo: photo,
            name: name,
            size: 96,
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (main)
                Padding(
                  padding: const EdgeInsets.only(bottom: 7),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _CmrGlowDot(
                        color: _CmrColors.green,
                        size: 6,
                      ),
                      const SizedBox(width: 7),
                      Text(
                        'Главный тренер',
                        style: _CmrText.muted(11).copyWith(
                          color: _CmrColors.greenDark,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              Text(
                name,
                style: _CmrText.title(24),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 7),
              Text(
                '$role  ·  $clubName',
                style: _CmrText.muted(11.8),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 9),
              const _CmrDotCluster(
                color: _CmrColors.greenDark,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _TrainerSummaryCard extends StatelessWidget {
  final String role;
  final String clubName;
  final int teamsCount;
  final bool main;

  const _TrainerSummaryCard(
      {required this.role,
      required this.clubName,
      required this.teamsCount,
      required this.main});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _CmrDecor.greenCard(radius: 26),
      child: Row(
        children: [
          _CmrRoundIcon(
              icon:
                  main ? Icons.workspace_premium_rounded : Icons.sports_rounded,
              color: _CmrColors.green,
              size: 48),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(role,
                    style: _CmrText.title(17),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 5),
                Text(clubName,
                    style: _CmrText.muted(12.5),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            ),
            child: Text(teamsCount == 0 ? 'Без команды' : '$teamsCount ком.',
                style: _CmrText.title(15)),
          ),
        ],
      ),
    );
  }
}

class _TrainerMiniMetric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _TrainerMiniMetric(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: _CmrDecor.softCard(radius: 20),
      child: Row(
        children: [
          _CmrRoundIcon(icon: icon, color: _CmrColors.green, size: 34),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label,
                    style: _CmrText.caption(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
                const SizedBox(height: 4),
                Text(value,
                    style: _CmrText.title(15.5),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerOpenWorkProfileButton extends StatelessWidget {
  final VoidCallback onTap;

  const _TrainerOpenWorkProfileButton({
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.greenSoft,
      borderRadius: BorderRadius.circular(9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(9),
        child: Container(
          height: 42,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            children: [
              const _CmrDotCluster(
                color: _CmrColors.green,
              ),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Открыть рабочий профиль',
                      style: _CmrText.value(11.8).copyWith(
                        color: _CmrColors.greenDark,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Карточка · Локации · Расписание · Планы · Тестирование',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.muted(9.3),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                size: 17,
                color: _CmrColors.greenDark,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrainerActionsGroup extends StatelessWidget {
  final VoidCallback? onEdit;
  final VoidCallback? onMessage;
  final VoidCallback? onAssign;
  final VoidCallback? onDocuments;

  const _TrainerActionsGroup({
    required this.onEdit,
    required this.onMessage,
    required this.onAssign,
    required this.onDocuments,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: const BoxDecoration(
        color: Colors.transparent,
      ),
      child: Column(
        children: [
          _TrainerInspectorAction(
            icon: Icons.edit_outlined,
            title: 'Редактировать профиль',
            subtitle: 'Фото, роль, опыт и описание',
            onTap: onEdit,
            accent: true,
          ),
          _TrainerInspectorAction(
            icon: Icons.folder_copy_outlined,
            title: 'Документы тренера',
            subtitle: 'Добавить файл или документ в Workspace',
            onTap: onDocuments,
          ),
          _TrainerInspectorAction(
            icon: Icons.chat_bubble_outline_rounded,
            title: 'Написать сообщение',
            subtitle: 'Открыть личный чат с тренером',
            onTap: onMessage,
          ),
          _TrainerInspectorAction(
            icon: Icons.add_link_rounded,
            title: 'Назначить в команду',
            subtitle: 'Команда и роль откроются справа',
            onTap: onAssign,
          ),
        ],
      ),
    );
  }
}

class _TrainerInspectorAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final bool accent;

  const _TrainerInspectorAction({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.accent = false,
  });

  @override
  Widget build(BuildContext context) {
    final accentColor = accent ? _CmrColors.green : _CmrColors.muted2;

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .45 : 1,
          child: Container(
            constraints: const BoxConstraints(minHeight: 58),
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 9,
            ),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(
                  color: _CmrColors.line,
                  width: .55,
                ),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 3,
                  height: 28,
                  decoration: BoxDecoration(
                    color: accentColor.withOpacity(
                      accent ? .92 : .48,
                    ),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: _CmrText.value(12.4),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.muted(10.6),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                const Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: _CmrColors.subtle,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerDangerActionsGroup extends StatelessWidget {
  final VoidCallback? onUnlinkTeam;
  final VoidCallback? onRemoveClub;

  const _TrainerDangerActionsGroup({
    required this.onUnlinkTeam,
    required this.onRemoveClub,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _TrainerQuietDangerAction(
          icon: Icons.link_off_rounded,
          text: 'Отвязать от команды',
          color: _CmrColors.amber,
          onTap: onUnlinkTeam,
        ),
        _TrainerQuietDangerAction(
          icon: Icons.delete_outline_rounded,
          text: 'Удалить из клуба',
          color: _CmrColors.red,
          onTap: onRemoveClub,
        ),
      ],
    );
  }
}

class _TrainerQuietDangerAction extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  final VoidCallback? onTap;

  const _TrainerQuietDangerAction({
    required this.icon,
    required this.text,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Opacity(
          opacity: onTap == null ? .45 : 1,
          child: Padding(
            padding: const EdgeInsets.symmetric(
              horizontal: 4,
              vertical: 10,
            ),
            child: Row(
              children: [
                _CmrGlowDot(
                  color: color,
                  size: 6,
                  halo: false,
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    text,
                    style: _CmrText.action().copyWith(
                      color: color,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Icon(
                  Icons.chevron_right_rounded,
                  size: 17,
                  color: color.withOpacity(.55),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerMetricsStrip extends StatelessWidget {
  final int teams;
  final String role;
  final bool main;
  final int contacts;

  const _TrainerMetricsStrip({
    required this.teams,
    required this.role,
    required this.main,
    required this.contacts,
  });

  @override
  Widget build(BuildContext context) {
    final shortRole = role == 'Врач спортивной медицины'
        ? 'Врач'
        : role == 'Тренер по вратарям'
            ? 'Вратари'
            : role == 'Главный тренер'
                ? 'Главный'
                : role == 'Тренер / специалист'
                    ? 'Тренер'
                    : role;
    final items = <({String value, String label})>[
      (value: '$teams', label: 'Команды'),
      (value: shortRole, label: 'Роль'),
      (value: main ? 'Да' : 'Нет', label: 'Главный'),
      (value: '$contacts/2', label: 'Контакты'),
    ];

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 14),
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          for (var i = 0; i < items.length; i++) ...[
            Expanded(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    items[i].value.trim().isEmpty ? '—' : items[i].value,
                    style: _CmrText.title(15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    items[i].label,
                    style: _CmrText.caption(),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (i != items.length - 1)
              Container(
                width: 1,
                height: 28,
                color: _CmrColors.line,
              ),
          ],
        ],
      ),
    );
  }
}

class _TrainerScheduleSection extends StatelessWidget {
  final List<Map<String, dynamic>> schedule;
  final List<String>? locations;
  final VoidCallback? onEditLocations;
  final bool compact;

  const _TrainerScheduleSection({
    required this.schedule,
    this.locations,
    this.onEditLocations,
    this.compact = false,
  });

  String _s(dynamic value) => '${value ?? ''}'.trim();

  DateTime? _date(dynamic value) =>
      DateTime.tryParse(_s(value).replaceAll(' ', 'T'));

  String _two(int value) => value.toString().padLeft(2, '0');

  String _dateLabel(DateTime date) => '${_two(date.day)}.${_two(date.month)}';

  String _timeLabel(DateTime date) => '${_two(date.hour)}:${_two(date.minute)}';

  String _eventLocation(Map<String, dynamic> event) =>
      _firstLocationValue(event);

  List<String> _scheduleLocations() {
    final map = <String, String>{};
    for (final event in schedule) {
      final location = _eventLocation(event);
      if (location.isEmpty) continue;
      final team = _s(event['team_name']);
      final label = team.isEmpty ? location : '$team — $location';
      map.putIfAbsent(_locationKeyValue(label), () => label);
    }
    return map.values.toList();
  }

  @override
  Widget build(BuildContext context) {
    // Для локаций нужен полный календарь, а в блоке расписания показываем
    // только будущие/актуальные события. Это синхронизирует CMR-инспектор
    // с подробным рабочим профилем тренера.
    final resolvedLocations = locations ?? _scheduleLocations();

    final now = DateTime.now();
    final floor = DateTime(now.year, now.month, now.day)
        .subtract(const Duration(days: 1));
    final upcoming = schedule.where((event) {
      final date = _date(
        event['start_at'] ?? event['date'] ?? event['event_date'],
      );
      return date != null && !date.isBefore(floor);
    }).toList()
      ..sort((a, b) {
        final da = _date(
              a['start_at'] ?? a['date'] ?? a['event_date'],
            ) ??
            DateTime(2100);
        final db = _date(
              b['start_at'] ?? b['date'] ?? b['event_date'],
            ) ??
            DateTime(2100);
        return da.compareTo(db);
      });

    final shown = upcoming.take(compact ? 3 : 5).toList();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(2, 2, 2, 4),
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const _CmrGlowDot(
                color: _CmrColors.greenDark,
                size: 6,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Рабочие локации',
                  style: _CmrText.section(),
                ),
              ),
              Text(
                '${resolvedLocations.length}',
                style: _CmrText.caption(),
              ),
              if (onEditLocations != null) ...[
                const SizedBox(width: 7),
                Material(
                  color: _CmrColors.greenSoft,
                  borderRadius: BorderRadius.circular(8),
                  child: InkWell(
                    onTap: onEditLocations,
                    borderRadius: BorderRadius.circular(8),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 6,
                      ),
                      child: Text(
                        'Изменить',
                        style: _CmrText.action().copyWith(
                          color: _CmrColors.greenDark,
                          fontSize: 10.2,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 7),
          if (resolvedLocations.isEmpty)
            Text(
              'Локации пока не указаны. Можно задать их вручную или использовать места из команд и календаря.',
              style: _CmrText.muted(10.8),
            )
          else
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: resolvedLocations
                  .take(compact ? 3 : 6)
                  .map(
                    (location) => Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 9,
                        vertical: 6,
                      ),
                      decoration: BoxDecoration(
                        color: _CmrColors.soft,
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: Text(
                        location,
                        style: _CmrText.muted(10.2).copyWith(
                          color: _CmrColors.text,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ),
                  )
                  .toList(),
            ),
          const SizedBox(height: 12),
          const Divider(
            height: 1,
            thickness: .55,
            color: _CmrColors.line,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              const _CmrGlowDot(
                color: _CmrColors.green,
                size: 5.5,
                halo: false,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Ближайшее расписание',
                  style: _CmrText.value(11.2),
                ),
              ),
              Text(
                '${upcoming.length}',
                style: _CmrText.caption(),
              ),
            ],
          ),
          if (shown.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Text(
                'Ближайших занятий пока нет.',
                style: _CmrText.muted(11.2),
              ),
            )
          else
            for (var i = 0; i < shown.length; i++) ...[
              Builder(
                builder: (context) {
                  final event = shown[i];
                  final start = _date(
                    event['start_at'] ?? event['date'],
                  );
                  final title = _s(event['title']).isEmpty
                      ? 'Занятие'
                      : _s(event['title']);
                  final team = _s(event['team_name']);
                  final location = _eventLocation(event);

                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 7),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          width: 54,
                          child: Text(
                            start == null
                                ? '—'
                                : '${_dateLabel(start)}\n${_timeLabel(start)}',
                            style: _CmrText.value(10.8),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                title,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: _CmrText.value(11.5),
                              ),
                              const SizedBox(height: 2),
                              Text(
                                [
                                  if (team.isNotEmpty) team,
                                  if (location.isNotEmpty) location,
                                ].join(' · '),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: _CmrText.muted(10.3),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
              if (i != shown.length - 1)
                const Divider(
                  height: 1,
                  thickness: .55,
                  color: _CmrColors.line,
                ),
            ],
        ],
      ),
    );
  }
}

class _TrainerDetailSection extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _TrainerDetailSection({
    required this.title,
    required this.children,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(2, 0, 2, 8),
          child: Row(
            children: [
              const _CmrGlowDot(
                color: _CmrColors.greenDark,
                size: 5.5,
                halo: false,
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: _CmrText.section(),
              ),
            ],
          ),
        ),
        Column(
          children: children,
        ),
      ],
    );
  }
}

class _TrainerDetailRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _TrainerDetailRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 44),
      padding: const EdgeInsets.symmetric(
        horizontal: 2,
        vertical: 7,
      ),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: _CmrColors.line,
            width: .55,
          ),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 110,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _CmrText.caption(),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: _CmrText.value(11.8),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerCommentBox extends StatelessWidget {
  final String title;
  final String text;

  const _TrainerCommentBox({
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const _CmrGlowDot(
              color: _CmrColors.green,
              size: 5.5,
              halo: false,
            ),
            const SizedBox(width: 8),
            Text(
              title,
              style: _CmrText.section(),
            ),
          ],
        ),
        const SizedBox(height: 8),
        const Divider(
          height: 1,
          thickness: .55,
          color: _CmrColors.line,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 11),
          child: Text(
            text,
            style: _CmrText.muted(11.4),
          ),
        ),
      ],
    );
  }
}

class _TrainerPrimaryActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;

  const _TrainerPrimaryActionButton(
      {required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.green,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            height: 38,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              border: Border.all(color: _CmrColors.green, width: .7),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(
                  child: Text(text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 10.8,
                          fontWeight: FontWeight.w600))),
            ]),
          ),
        ),
      ),
    );
  }
}

class _TrainerSecondaryActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;

  const _TrainerSecondaryActionButton(
      {required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            height: 38,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              border: Border.all(color: _CmrColors.line, width: .7),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(
                  child: Text(text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.action())),
            ]),
          ),
        ),
      ),
    );
  }
}

class _TrainerDangerActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;
  final Color color;

  const _TrainerDangerActionButton(
      {required this.icon,
      required this.text,
      required this.onTap,
      required this.color});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            height: 34,
            alignment: Alignment.center,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              border: Border.all(color: color.withOpacity(.35), width: .7),
            ),
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Flexible(
                  child: Text(text,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          color: color,
                          fontSize: 10.8,
                          fontWeight: FontWeight.w600))),
            ]),
          ),
        ),
      ),
    );
  }
}

class _TrainerEmptyState extends StatelessWidget {
  final String title;
  final String text;
  final VoidCallback? onTap;

  const _TrainerEmptyState(
      {required this.title, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
        decoration: const BoxDecoration(
          color: _CmrColors.panel,
          border: Border(bottom: BorderSide(color: _CmrColors.line, width: .7)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _CmrRoundIcon(
                icon: Icons.badge_rounded, color: _CmrColors.muted, size: 42),
            const SizedBox(height: 10),
            Text(title,
                textAlign: TextAlign.center, style: _CmrText.title(14.2)),
            const SizedBox(height: 5),
            Text(text,
                textAlign: TextAlign.center, style: _CmrText.muted(11.2)),
            const SizedBox(height: 12),
            SizedBox(
                width: 190,
                child: _CmrPrimaryButton(
                    icon: Icons.person_add_alt_1_rounded,
                    title: 'Добавить тренера',
                    onTap: onTap)),
          ],
        ),
      ),
    );
  }
}

class _TrainerEditSidePanel extends StatefulWidget {
  final Map<String, dynamic> trainer;
  final int clubId;
  final bool compact;
  final bool fillAvailableWidth;
  final List<String> automaticLocations;
  final VoidCallback onClose;
  final Future<Map<String, dynamic>> Function(int trainerId) onLoadProfile;
  final Future<bool> Function({
    required int trainerId,
    required String firstName,
    required String lastName,
    required String position,
    required String birthday,
    required String experience,
    required String bio,
    required String workLocations,
    XFile? pickedPhoto,
  }) onSaveProfile;
  final Future<bool> Function({
    required String firstName,
    required String lastName,
  }) onSaveAccount;
  final Future<bool> Function({
    required String newPassword,
  }) onResetPassword;
  final Future<void> Function() onSaved;

  const _TrainerEditSidePanel({
    required this.trainer,
    required this.clubId,
    required this.compact,
    this.fillAvailableWidth = false,
    this.automaticLocations = const <String>[],
    required this.onClose,
    required this.onLoadProfile,
    required this.onSaveProfile,
    required this.onSaveAccount,
    required this.onResetPassword,
    required this.onSaved,
  });

  @override
  State<_TrainerEditSidePanel> createState() => _TrainerEditSidePanelState();
}

class _TrainerEditSidePanelState extends State<_TrainerEditSidePanel> {
  late final TextEditingController _firstNameC;
  late final TextEditingController _lastNameC;
  late final TextEditingController _positionC;
  late final TextEditingController _birthdayC;
  late final TextEditingController _experienceC;
  late final TextEditingController _bioC;
  late final TextEditingController _addLocationC;
  final List<TextEditingController> _manualLocationControllers =
      <TextEditingController>[];
  final Set<String> _selectedAutomaticLocationKeys = <String>{};
  late final TextEditingController _newPasswordC;
  late final TextEditingController _repeatPasswordC;
  final ImagePicker _picker = ImagePicker();

  XFile? _pickedPhoto;
  String _currentPhoto = '';
  bool _loading = true;
  bool _saving = false;
  bool _savingPassword = false;
  bool _hideNewPassword = true;
  bool _hideRepeatPassword = true;
  String _savedFirstName = '';
  String _savedLastName = '';
  String _storedWorkLocations = '';

  @override
  void initState() {
    super.initState();
    _firstNameC = TextEditingController(
        text: _s(widget.trainer['first_name'] ?? widget.trainer['firstName']));
    _lastNameC = TextEditingController(
        text: _s(widget.trainer['last_name'] ?? widget.trainer['lastName']));
    _positionC = TextEditingController(text: _trainerRole(widget.trainer));
    _birthdayC = TextEditingController(text: _trainerBirthday(widget.trainer));
    _experienceC =
        TextEditingController(text: _trainerExperience(widget.trainer));
    _bioC = TextEditingController(text: _trainerBio(widget.trainer));
    _storedWorkLocations =
        _s(widget.trainer['work_locations'] ?? widget.trainer['locations']);
    _addLocationC = TextEditingController();
    _resetLocationEditorState();
    _newPasswordC = TextEditingController();
    _repeatPasswordC = TextEditingController();
    _savedFirstName = _firstNameC.text.trim();
    _savedLastName = _lastNameC.text.trim();
    _currentPhoto = _trainerPhoto(widget.trainer);
    _load();
  }

  @override
  void didUpdateWidget(covariant _TrainerEditSidePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_trainerIdentityLocal(oldWidget.trainer) !=
        _trainerIdentityLocal(widget.trainer)) {
      _firstNameC.text =
          _s(widget.trainer['first_name'] ?? widget.trainer['firstName']);
      _lastNameC.text =
          _s(widget.trainer['last_name'] ?? widget.trainer['lastName']);
      _positionC.text = _trainerRole(widget.trainer);
      _birthdayC.text = _trainerBirthday(widget.trainer);
      _experienceC.text = _trainerExperience(widget.trainer);
      _bioC.text = _trainerBio(widget.trainer);
      _storedWorkLocations =
          _s(widget.trainer['work_locations'] ?? widget.trainer['locations']);
      _resetLocationEditorState();
      _newPasswordC.clear();
      _repeatPasswordC.clear();
      _savedFirstName = _firstNameC.text.trim();
      _savedLastName = _lastNameC.text.trim();
      _currentPhoto = _trainerPhoto(widget.trainer);
      _pickedPhoto = null;
      _loading = true;
      _load();
    }
  }

  @override
  void dispose() {
    _firstNameC.dispose();
    _lastNameC.dispose();
    _positionC.dispose();
    _birthdayC.dispose();
    _experienceC.dispose();
    _bioC.dispose();
    _addLocationC.dispose();
    for (final controller in _manualLocationControllers) {
      controller.dispose();
    }
    _newPasswordC.dispose();
    _repeatPasswordC.dispose();
    super.dispose();
  }

  int _trainerIdLocal(Map<String, dynamic> trainer) => _i(trainer['user_id'] ??
      trainer['userId'] ??
      trainer['trainer_id'] ??
      trainer['trainerId'] ??
      trainer['coach_id'] ??
      trainer['id']);

  String _trainerIdentityLocal(Map<String, dynamic> trainer) {
    final id = _trainerIdLocal(trainer);
    if (id > 0) return 'id:$id';
    final email = _trainerEmail(trainer).toLowerCase();
    return email.isEmpty ? _trainerName(trainer).toLowerCase() : 'email:$email';
  }

  String get _locationMarker => '#club:${widget.clubId}|';

  List<String> _manualLocationsFromStored(String stored) {
    final out = <String>[];
    final seen = <String>{};
    for (final raw in stored.split(RegExp(r'[\r\n]+'))) {
      final line = raw.trim();
      if (!line.startsWith(_locationMarker)) continue;
      final value = line.substring(_locationMarker.length).trim();
      final key = _locationKeyValue(value);
      if (value.isEmpty || key.isEmpty || !seen.add(key)) continue;
      out.add(value);
    }
    return out;
  }

  List<String> get _automaticLocationValues {
    final out = <String>[];
    final seen = <String>{};

    for (final raw in widget.automaticLocations) {
      final value = raw.trim();
      final key = _locationKeyValue(value);
      if (value.isEmpty || key.isEmpty || !seen.add(key)) continue;
      out.add(value);
    }

    return out;
  }

  void _resetLocationEditorState() {
    for (final controller in _manualLocationControllers) {
      controller.dispose();
    }
    _manualLocationControllers.clear();
    _selectedAutomaticLocationKeys.clear();
    _addLocationC.clear();

    final automatic = _automaticLocationValues;
    final automaticKeys = automatic
        .map(_locationKeyValue)
        .where((key) => key.isNotEmpty)
        .toSet();

    final manual = _manualLocationsFromStored(_storedWorkLocations);

    if (manual.isEmpty) {
      _selectedAutomaticLocationKeys.addAll(automaticKeys);
      return;
    }

    for (final value in manual) {
      final key = _locationKeyValue(value);
      if (key.isEmpty) continue;

      if (automaticKeys.contains(key)) {
        _selectedAutomaticLocationKeys.add(key);
      } else {
        _manualLocationControllers.add(
          TextEditingController(text: value),
        );
      }
    }
  }

  void _addLocationRow() {
    final value = _addLocationC.text.trim();
    final key = _locationKeyValue(value);

    if (value.isEmpty || key.isEmpty) return;

    final duplicateAutomatic =
        _selectedAutomaticLocationKeys.contains(key);
    final duplicateManual = _manualLocationControllers.any(
      (controller) =>
          _locationKeyValue(controller.text.trim()) == key,
    );

    if (duplicateAutomatic || duplicateManual) {
      _addLocationC.clear();
      return;
    }

    setState(() {
      _manualLocationControllers.add(
        TextEditingController(text: value),
      );
      _addLocationC.clear();
    });
  }

  String _workLocationsForSave() {
    final keep = _storedWorkLocations
        .split(RegExp(r'[\r\n]+'))
        .map((value) => value.trim())
        .where(
          (value) =>
              value.isNotEmpty &&
              !value.startsWith(_locationMarker),
        )
        .toList();

    final automatic = _automaticLocationValues;
    final automaticKeys = automatic
        .map(_locationKeyValue)
        .where((key) => key.isNotEmpty)
        .toSet();

    final customValues = <String>[];
    final customSeen = <String>{};

    for (final controller in _manualLocationControllers) {
      final value = controller.text.trim();
      final key = _locationKeyValue(value);
      if (value.isEmpty || key.isEmpty || !customSeen.add(key)) continue;
      customValues.add(value);
    }

    final allAutomaticSelected =
        _selectedAutomaticLocationKeys.length == automaticKeys.length &&
            automaticKeys.every(
              _selectedAutomaticLocationKeys.contains,
            );

    // Полный автоматический набор без пользовательских строк означает,
    // что ручной override не нужен: CMR продолжит обновляться от календаря.
    if (allAutomaticSelected && customValues.isEmpty) {
      return keep.join('\n');
    }

    final seen = <String>{};

    for (final location in automatic) {
      final key = _locationKeyValue(location);
      if (key.isEmpty ||
          !_selectedAutomaticLocationKeys.contains(key) ||
          !seen.add(key)) {
        continue;
      }
      keep.add('$_locationMarker${location.trim()}');
    }

    for (final value in customValues) {
      final key = _locationKeyValue(value);
      if (key.isEmpty || !seen.add(key)) continue;
      keep.add('$_locationMarker$value');
    }

    return keep.join('\n');
  }

  Future<void> _load() async {
    final trainerId = _trainerIdLocal(widget.trainer);
    if (trainerId <= 0) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    try {
      final p = await widget.onLoadProfile(trainerId);
      if (!mounted) return;
      final firstName = _s(p['first_name'] ?? p['firstName']);
      final lastName = _s(p['last_name'] ?? p['lastName']);
      final position =
          _s(p['position'] ?? p['role_title'] ?? p['specialization']);
      final birthday =
          _s(p['birthday'] ?? p['birth_date'] ?? p['date_birth'] ?? p['dob']);
      final experience =
          _s(p['experience'] ?? p['experience_text'] ?? p['work_experience']);
      final bio =
          _s(p['bio'] ?? p['description'] ?? p['about'] ?? p['about_me']);
      final workLocations = _s(p['work_locations'] ?? p['locations']);
      final photo = _normalizeImage(
          _s(p['photo'] ?? p['photo_url'] ?? p['avatar'] ?? p['avatar_url']));

      setState(() {
        if (firstName.isNotEmpty) _firstNameC.text = firstName;
        if (lastName.isNotEmpty) _lastNameC.text = lastName;
        _savedFirstName = _firstNameC.text.trim();
        _savedLastName = _lastNameC.text.trim();
        if (position.isNotEmpty) _positionC.text = position;
        if (birthday.isNotEmpty) _birthdayC.text = birthday;
        if (experience.isNotEmpty) _experienceC.text = experience;
        if (bio.isNotEmpty) _bioC.text = bio;
        _storedWorkLocations = workLocations;
        _resetLocationEditorState();
        if (photo.isNotEmpty) _currentPhoto = photo;
        _loading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _pickPhoto() async {
    final x =
        await _picker.pickImage(source: ImageSource.gallery, imageQuality: 85);
    if (x != null && mounted) setState(() => _pickedPhoto = x);
  }

  Future<void> _save() async {
    if (_saving) return;
    final trainerId = _trainerIdLocal(widget.trainer);
    if (trainerId <= 0) {
      Get.snackbar('Тренер', 'Не найден ID тренера');
      return;
    }

    final firstName = _firstNameC.text.trim();
    final lastName = _lastNameC.text.trim();

    if (firstName.isEmpty) {
      Get.snackbar('Профиль', 'Укажите имя');
      return;
    }
    if (lastName.isEmpty) {
      Get.snackbar('Профиль', 'Укажите фамилию');
      return;
    }

    setState(() => _saving = true);

    // ВАЖНО: профиль/фото сохраняем независимо от account endpoint.
    // Раньше любое отклонение update_club_staff_account.php полностью
    // блокировало сохранение фотографии, опыта, должности и описания.
    final profileOk = await widget.onSaveProfile(
      trainerId: trainerId,
      firstName: firstName,
      lastName: lastName,
      position: _positionC.text,
      birthday: _birthdayC.text,
      experience: _experienceC.text,
      bio: _bioC.text,
      workLocations: _workLocationsForSave(),
      pickedPhoto: _pickedPhoto,
    );

    if (!profileOk) {
      if (mounted) setState(() => _saving = false);
      return;
    }

    _storedWorkLocations = _workLocationsForSave();

    final namesChanged =
        firstName != _savedFirstName || lastName != _savedLastName;

    if (namesChanged) {
      final accountOk = await widget.onSaveAccount(
        firstName: firstName,
        lastName: lastName,
      );

      if (!accountOk) {
        // Остальные данные и фото уже сохранены. Оставляем редактор открытым,
        // чтобы пользователь мог повторить только сохранение имени/фамилии.
        if (mounted) setState(() => _saving = false);
        return;
      }

      _savedFirstName = firstName;
      _savedLastName = lastName;
    }

    await widget.onSaved();
  }

  Future<void> _resetPassword() async {
    if (_savingPassword) return;

    final newPassword = _newPasswordC.text;
    final repeatPassword = _repeatPasswordC.text;

    if (newPassword.length < 8) {
      Get.snackbar(
        'Пароль',
        'Новый пароль должен содержать минимум 8 символов',
      );
      return;
    }

    if (newPassword != repeatPassword) {
      Get.snackbar('Пароль', 'Пароли не совпадают');
      return;
    }

    setState(() => _savingPassword = true);
    try {
      final ok = await widget.onResetPassword(
        newPassword: newPassword,
      );

      if (ok) {
        _newPasswordC.clear();
        _repeatPasswordC.clear();
      }
    } finally {
      if (mounted) setState(() => _savingPassword = false);
    }
  }

  Widget _editLabel(String text) {
    return Padding(
      padding: const EdgeInsets.only(left: 1, bottom: 6),
      child: Text(
        text,
        style: _CmrText.muted(10.5),
      ),
    );
  }

  Widget _labeledInput({
    required String label,
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    int maxLines = 1,
    Widget? suffix,
    bool obscureText = false,
    TextInputAction? textInputAction,
    ValueChanged<String>? onSubmitted,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _editLabel(label),
        TextField(
          controller: controller,
          maxLines: maxLines,
          obscureText: obscureText,
          textInputAction: textInputAction,
          onSubmitted: onSubmitted,
          style: AppTypography.formText(color: _CmrColors.text),
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: AppTypography.formHint(color: _CmrColors.muted2),
            prefixIcon: Icon(icon, color: _CmrColors.muted, size: 18),
            suffixIcon: suffix,
            filled: true,
            fillColor: _CmrColors.soft,
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 14,
              vertical: 14,
            ),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              borderSide: BorderSide.none,
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              borderSide: const BorderSide(
                color: _CmrColors.green,
                width: 1,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _locationEditorBlock() {
    final automatic = _automaticLocationValues;

    Widget selector({
      required bool selected,
      required VoidCallback onTap,
    }) {
      return Material(
        color: Colors.transparent,
        shape: const CircleBorder(),
        child: InkWell(
          onTap: onTap,
          customBorder: const CircleBorder(),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            width: 23,
            height: 23,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: selected ? _CmrColors.green : Colors.white,
              border: Border.all(
                color: selected
                    ? _CmrColors.green
                    : _CmrColors.line,
                width: selected ? 1 : .8,
              ),
            ),
            child: selected
                ? const Icon(
                    Icons.check_rounded,
                    color: Colors.white,
                    size: 14,
                  )
                : null,
          ),
        ),
      );
    }

    Widget removeButton(VoidCallback onTap) {
      return IconButton(
        tooltip: 'Удалить',
        onPressed: onTap,
        visualDensity: VisualDensity.compact,
        icon: const Icon(
          Icons.delete_outline_rounded,
          color: _CmrColors.muted2,
          size: 18,
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: _CmrDecor.softCard(radius: 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Row(
            children: <Widget>[
              const _CmrGlowDot(
                color: _CmrColors.greenDark,
                size: 6,
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Рабочие локации',
                  style: _CmrText.value(11.4),
                ),
              ),
            ],
          ),
          const SizedBox(height: 5),
          Text(
            'Зелёный круг — оставить. Корзина исключает локацию из карточки тренера.',
            style: _CmrText.muted(9.2),
          ),
          const SizedBox(height: 10),
          if (automatic.isNotEmpty) ...<Widget>[
            Text(
              'Автоматически из команд и календаря',
              style: _CmrText.muted(9.6).copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 7),
            for (final location in automatic) ...<Widget>[
              Builder(
                builder: (_) {
                  final key = _locationKeyValue(location);
                  final selected =
                      _selectedAutomaticLocationKeys.contains(key);

                  return AnimatedOpacity(
                    duration: const Duration(milliseconds: 140),
                    opacity: selected ? 1 : .48,
                    child: Container(
                      margin: const EdgeInsets.only(bottom: 7),
                      padding: const EdgeInsets.fromLTRB(9, 6, 4, 6),
                      decoration: BoxDecoration(
                        color: selected
                            ? _CmrColors.greenSoft
                            : Colors.white,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(
                          color: selected
                              ? _CmrColors.green.withOpacity(.18)
                              : _CmrColors.line,
                          width: .7,
                        ),
                      ),
                      child: Row(
                        children: <Widget>[
                          selector(
                            selected: selected,
                            onTap: () {
                              setState(() {
                                if (selected) {
                                  _selectedAutomaticLocationKeys.remove(key);
                                } else {
                                  _selectedAutomaticLocationKeys.add(key);
                                }
                              });
                            },
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              location,
                              style: _CmrText.value(10.2),
                            ),
                          ),
                          removeButton(
                            () => setState(
                              () => _selectedAutomaticLocationKeys.remove(key),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ],
            const SizedBox(height: 4),
          ] else ...<Widget>[
            Text(
              'Автоматические локации пока не найдены.',
              style: _CmrText.muted(9.6),
            ),
            const SizedBox(height: 8),
          ],
          Text(
            'Добавить вручную',
            style: _CmrText.muted(9.6).copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 7),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Expanded(
                child: TextField(
                  controller: _addLocationC,
                  textInputAction: TextInputAction.done,
                  onSubmitted: (_) => _addLocationRow(),
                  style: AppTypography.formText(
                    color: _CmrColors.text,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Название или адрес локации',
                    hintStyle: AppTypography.formHint(
                      color: _CmrColors.muted2,
                    ),
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 11,
                      vertical: 11,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(
                        color: _CmrColors.line,
                      ),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(
                        color: _CmrColors.line,
                      ),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(
                        color: _CmrColors.green,
                        width: 1,
                      ),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 7),
              SizedBox(
                height: 44,
                child: _CmrTextActionButton(
                  label: 'Добавить',
                  color: _CmrColors.greenDark,
                  onTap: _addLocationRow,
                ),
              ),
            ],
          ),
          if (_manualLocationControllers.isNotEmpty) ...<Widget>[
            const SizedBox(height: 9),
            for (var i = 0;
                i < _manualLocationControllers.length;
                i++) ...<Widget>[
              Container(
                margin: const EdgeInsets.only(bottom: 7),
                padding: const EdgeInsets.fromLTRB(9, 5, 4, 5),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: _CmrColors.line,
                    width: .7,
                  ),
                ),
                child: Row(
                  children: <Widget>[
                    selector(
                      selected: true,
                      onTap: () {},
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: _manualLocationControllers[i],
                        maxLines: 2,
                        minLines: 1,
                        style: AppTypography.formText(
                          color: _CmrColors.text,
                        ),
                        decoration: InputDecoration(
                          hintText: 'Локация',
                          hintStyle: AppTypography.formHint(
                            color: _CmrColors.muted2,
                          ),
                          isDense: true,
                          filled: true,
                          fillColor: _CmrColors.soft,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 9,
                            vertical: 8,
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8),
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    removeButton(
                      () {
                        final controller =
                            _manualLocationControllers.removeAt(i);
                        controller.dispose();
                        setState(() {});
                      },
                    ),
                  ],
                ),
              ),
            ],
          ],
          const SizedBox(height: 4),
          Text(
            'Если оставить весь автоматический набор и не добавлять свои строки, локации продолжат обновляться автоматически.',
            style: _CmrText.muted(8.9),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final name = _trainerName(widget.trainer);
    final role = _trainerRole(widget.trainer);

    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 640;
        final width = widget.fillAvailableWidth
            ? constraints.maxWidth
            : mobile
                ? math.max(0.0, constraints.maxWidth - 16)
                : math.min(
                    620.0,
                    math.max(440.0, constraints.maxWidth * .56),
                  );
        final radius = mobile ? 18.0 : 20.0;

        return Align(
          alignment: Alignment.centerRight,
          child: SafeArea(
            left: false,
            child: Container(
              width: width,
              height: double.infinity,
              margin: EdgeInsets.fromLTRB(mobile ? 8 : 0, mobile ? 8 : 0,
                  mobile ? 8 : 0, mobile ? 8 : 0),
              decoration: BoxDecoration(
                  color: _CmrColors.glass,
                  borderRadius: BorderRadius.horizontal(
                      left: Radius.circular(4),
                      right: Radius.circular(mobile ? 4 : 0)),
                  border: Border.all(color: Colors.white.withOpacity(.86))),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  _TrainerEditSideHeader(
                    title: 'Редактирование',
                    subtitle: name,
                    onClose: widget.onClose,
                  ),
                  Expanded(
                    child: _loading
                        ? const Center(child: CircularProgressIndicator())
                        : ListView(
                            padding: const EdgeInsets.fromLTRB(18, 4, 18, 18),
                            children: [
                              Center(
                                child: InkWell(
                                  onTap: _pickPhoto,
                                  borderRadius: BorderRadius.circular(
                                      _CmrDecor.mobileInnerRadius),
                                  child: Stack(
                                    clipBehavior: Clip.none,
                                    children: [
                                      _pickedPhoto != null
                                          ? ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(
                                                      _CmrDecor
                                                          .mobileInnerRadius),
                                              child: Image.file(
                                                  File(_pickedPhoto!.path),
                                                  width: 106,
                                                  height: 106,
                                                  fit: BoxFit.cover),
                                            )
                                          : _CmrAvatar(
                                              photo: _currentPhoto,
                                              name: name,
                                              size: 106),
                                      Positioned(
                                        right: -3,
                                        bottom: -3,
                                        child: Container(
                                          width: 30,
                                          height: 30,
                                          decoration: BoxDecoration(
                                            color: _CmrColors.green,
                                            borderRadius: BorderRadius.circular(
                                                _CmrDecor.mobileInnerRadius),
                                            border: Border.all(
                                                color: Colors.white, width: 2),
                                          ),
                                          child: const Icon(
                                              Icons.photo_camera_rounded,
                                              color: Colors.white,
                                              size: 14),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(name,
                                  textAlign: TextAlign.center,
                                  style: _CmrText.title(18)),
                              const SizedBox(height: 4),
                              Text(role,
                                  textAlign: TextAlign.center,
                                  style: _CmrText.muted(12.5)),
                              const SizedBox(height: 18),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _labeledInput(
                                      label: 'Имя',
                                      controller: _firstNameC,
                                      hint: 'Имя',
                                      icon: Icons.person_outline_rounded,
                                      textInputAction: TextInputAction.next,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _labeledInput(
                                      label: 'Фамилия',
                                      controller: _lastNameC,
                                      hint: 'Фамилия',
                                      icon: Icons.badge_outlined,
                                      textInputAction: TextInputAction.next,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              _editLabel('Email'),
                              Container(
                                width: double.infinity,
                                padding: const EdgeInsets.symmetric(
                                  horizontal: 14,
                                  vertical: 14,
                                ),
                                decoration: BoxDecoration(
                                  color: _CmrColors.soft,
                                  borderRadius: BorderRadius.circular(
                                    _CmrDecor.mobileInnerRadius,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    const Icon(
                                      Icons.alternate_email_rounded,
                                      size: 18,
                                      color: _CmrColors.muted,
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Text(
                                        _trainerEmail(widget.trainer).isEmpty
                                            ? 'Email не указан'
                                            : _trainerEmail(widget.trainer),
                                        style: _CmrText.value(10.8),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              _labeledInput(
                                label: 'Должность / роль',
                                controller: _positionC,
                                hint: 'Должность / роль',
                                icon: Icons.badge_rounded,
                              ),
                              const SizedBox(height: 10),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: _labeledInput(
                                      label: 'Дата рождения',
                                      controller: _birthdayC,
                                      hint: 'ГГГГ-ММ-ДД',
                                      icon: Icons.cake_rounded,
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: _labeledInput(
                                      label: 'Опыт',
                                      controller: _experienceC,
                                      hint: 'Опыт',
                                      icon: Icons.workspace_premium_rounded,
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: 10),
                              _labeledInput(
                                label: 'Описание / биография',
                                controller: _bioC,
                                hint: 'Описание / биография',
                                icon: Icons.notes_rounded,
                                maxLines: 5,
                              ),
                              const SizedBox(height: 10),
                              _locationEditorBlock(),
                              const SizedBox(height: 18),
                              Container(
                                padding: const EdgeInsets.all(12),
                                decoration: _CmrDecor.softCard(radius: 12),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        const Icon(
                                          Icons.password_rounded,
                                          size: 18,
                                          color: _CmrColors.greenDark,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          'Изменить пароль',
                                          style: _CmrText.value(11.2),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      'Администратор клуба устанавливает новый пароль сотруднику.',
                                      style: _CmrText.muted(9.3),
                                    ),
                                    const SizedBox(height: 10),
                                    _labeledInput(
                                      label: 'Новый пароль',
                                      controller: _newPasswordC,
                                      hint: 'Минимум 8 символов',
                                      icon: Icons.lock_reset_rounded,
                                      obscureText: _hideNewPassword,
                                      suffix: IconButton(
                                        tooltip: _hideNewPassword
                                            ? 'Показать пароль'
                                            : 'Скрыть пароль',
                                        onPressed: () => setState(
                                          () => _hideNewPassword =
                                              !_hideNewPassword,
                                        ),
                                        icon: Icon(
                                          _hideNewPassword
                                              ? Icons.visibility_outlined
                                              : Icons.visibility_off_outlined,
                                          size: 17,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    _labeledInput(
                                      label: 'Повторите пароль',
                                      controller: _repeatPasswordC,
                                      hint: 'Повторите новый пароль',
                                      icon: Icons.verified_user_outlined,
                                      obscureText: _hideRepeatPassword,
                                      suffix: IconButton(
                                        tooltip: _hideRepeatPassword
                                            ? 'Показать пароль'
                                            : 'Скрыть пароль',
                                        onPressed: () => setState(
                                          () => _hideRepeatPassword =
                                              !_hideRepeatPassword,
                                        ),
                                        icon: Icon(
                                          _hideRepeatPassword
                                              ? Icons.visibility_outlined
                                              : Icons.visibility_off_outlined,
                                          size: 17,
                                        ),
                                      ),
                                      textInputAction: TextInputAction.done,
                                      onSubmitted: (_) {
                                        if (!_savingPassword) {
                                          _resetPassword();
                                        }
                                      },
                                    ),
                                    const SizedBox(height: 10),
                                    SizedBox(
                                      width: double.infinity,
                                      child: _CmrTextActionButton(
                                        label: _savingPassword
                                            ? 'Изменение...'
                                            : 'Изменить пароль',
                                        color: _CmrColors.greenDark,
                                        onTap: _savingPassword
                                            ? null
                                            : _resetPassword,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 14),
                              _CmrNotice(
                                icon: Icons.info_outline_rounded,
                                title: 'Редактирование сотрудника',
                                text:
                                    'Имя, фамилия, карточка тренера и пароль управляются в этом правом окне.',
                              ),
                            ],
                          ),
                  ),
                  _TrainerEditSideFooter(
                    saving: _saving,
                    onClose: widget.onClose,
                    onSave: _save,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _TrainerEditSideHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final VoidCallback onClose;

  const _TrainerEditSideHeader(
      {required this.title, required this.subtitle, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 12, 12),
      decoration: const BoxDecoration(
          color: _CmrColors.panel,
          border: Border(bottom: BorderSide(color: _CmrColors.line))),
      child: Row(
        children: [
          _CmrRoundIcon(
              icon: Icons.tune_rounded, color: _CmrColors.green, size: 34),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _CmrText.title(15.5)),
                const SizedBox(height: 2),
                Text(subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _CmrText.muted(12)),
              ],
            ),
          ),
          Material(
            color: _CmrColors.soft,
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            child: InkWell(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              onTap: onClose,
              child: const SizedBox(
                width: 34,
                height: 34,
                child: Icon(Icons.close_rounded,
                    size: 15, color: _CmrColors.muted),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerEditSideFooter extends StatelessWidget {
  final bool saving;
  final VoidCallback onClose;
  final VoidCallback onSave;

  const _TrainerEditSideFooter(
      {required this.saving, required this.onClose, required this.onSave});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
        decoration: const BoxDecoration(
            color: _CmrColors.panel,
            border: Border(top: BorderSide(color: _CmrColors.line))),
        child: Row(
          children: [
            Expanded(
              child: _TrainerPanelSoftButton(
                title: 'Закрыть',
                icon: Icons.close_rounded,
                onTap: saving ? null : onClose,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: _TrainerPanelGraphiteButton(
                title: saving ? 'Сохранение...' : 'Сохранить',
                icon: Icons.check_rounded,
                onTap: saving ? null : onSave,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TrainerPanelSoftButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback? onTap;

  const _TrainerPanelSoftButton(
      {required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.soft,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            height: 38,
            alignment: Alignment.center,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 15, color: _CmrColors.muted),
                const SizedBox(width: 6),
                Text(title, style: _CmrText.action()),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerPanelGraphiteButton extends StatelessWidget {
  final String title;
  final IconData icon;
  final VoidCallback? onTap;

  const _TrainerPanelGraphiteButton(
      {required this.title, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            height: 38,
            alignment: Alignment.center,
            decoration: _CmrDecor.fluentSurface(
                radius: 10,
                accent: _CmrColors.green,
                active: true,
                compact: true),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 15, color: _CmrColors.green),
                const SizedBox(width: 6),
                Text(title,
                    style: const TextStyle(
                        color: _CmrColors.green,
                        fontSize: 11.55,
                        fontWeight: FontWeight.w600)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _TrainerEmptyDetail extends StatelessWidget {
  final VoidCallback? onAddTrainer;

  const _TrainerEmptyDetail({required this.onAddTrainer});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: _CmrDecor.softCard(radius: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _CmrRoundIcon(
                icon: Icons.badge_rounded, color: _CmrColors.green, size: 56),
            const SizedBox(height: 14),
            Text('Выберите тренера',
                textAlign: TextAlign.center, style: _CmrText.title(18)),
            const SizedBox(height: 7),
            Text(
              'Слева откройте карточку тренера — здесь появятся профиль, команды, контакты и действия.',
              textAlign: TextAlign.center,
              style: _CmrText.muted(13),
            ),
            const SizedBox(height: 16),
            SizedBox(
                width: 210,
                child: _CmrPrimaryButton(
                    icon: Icons.person_add_alt_1_rounded,
                    title: 'Добавить тренера',
                    onTap: onAddTrainer)),
          ],
        ),
      ),
    );
  }
}

// ==================== Модальное окно тренера ====================

class _TrainerModalSheet extends StatefulWidget {
  final Map<String, dynamic> trainer;
  final VoidCallback onMessage;
  final VoidCallback onEdit;
  final VoidCallback onAssign;
  final VoidCallback onUnlinkTeam;
  final VoidCallback onRemoveClub;

  const _TrainerModalSheet({
    required this.trainer,
    required this.onMessage,
    required this.onEdit,
    required this.onAssign,
    required this.onUnlinkTeam,
    required this.onRemoveClub,
  });

  @override
  State<_TrainerModalSheet> createState() => _TrainerModalSheetState();
}

class _TrainerModalSheetState extends State<_TrainerModalSheet>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (!mounted || _selectedTab == _tabController.index) return;
      setState(() => _selectedTab = _tabController.index);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = _trainerName(widget.trainer);
    final role = _trainerRole(widget.trainer);
    final photo = _trainerPhoto(widget.trainer);
    final isMain = _isMain(widget.trainer);
    final teams = _trainerTeams(widget.trainer);
    final phone = _trainerPhone(widget.trainer);
    final email = _trainerEmail(widget.trainer);
    final birthday = _trainerBirthday(widget.trainer);
    final experience = _trainerExperience(widget.trainer);
    final city = _trainerCity(widget.trainer);
    final specialization = _trainerSpecialization(widget.trainer);
    final bio = _trainerBio(widget.trainer);
    final schedule = _trainerSchedule(widget.trainer);

    final screen = MediaQuery.sizeOf(context);
    final bottomInset = MediaQuery.viewInsetsOf(context).bottom;
    final sheetHeight = math.min(screen.height * .92, 760.0);

    return Padding(
      padding:
          EdgeInsets.fromLTRB(10, 0, 10, bottomInset > 0 ? bottomInset : 10),
      child: Align(
        alignment: Alignment.bottomCenter,
        child: Container(
          height: sheetHeight,
          constraints: const BoxConstraints(maxWidth: 720),
          decoration: BoxDecoration(
            color: _CmrColors.panel,
            borderRadius: BorderRadius.circular(_CmrDecor.sheetRadius),
            border:
                Border.all(color: _CmrColors.line.withOpacity(.55), width: .7),
            boxShadow: _CmrDecor.windowShadow,
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            children: [
              _ModalTopBar(name: name),
              _ModalHeaderCard(
                name: name,
                role: role,
                photo: photo,
                isMain: isMain,
                teamsCount: teams.length,
              ),
              _ModalQuickActions(
                onMessage: widget.onMessage,
                onEdit: widget.onEdit,
                onAssign: widget.onAssign,
              ),
              _ModalTabBar(
                controller: _tabController,
                selectedTab: _selectedTab,
              ),
              Expanded(
                child: TabBarView(
                  controller: _tabController,
                  children: [
                    _ModalOverviewTab(
                      role: role,
                      experience: experience,
                      birthday: birthday,
                      city: city,
                      specialization: specialization,
                      bio: bio,
                      schedule: schedule,
                    ),
                    _ModalAssignmentsTab(teams: teams),
                    _ModalContactsTab(phone: phone, email: email),
                  ],
                ),
              ),
              _ModalBottomDangerActions(
                onUnlinkTeam: widget.onUnlinkTeam,
                onRemoveClub: widget.onRemoveClub,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModalTopBar extends StatelessWidget {
  final String name;

  const _ModalTopBar({required this.name});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 12, 8),
      child: Column(
        children: [
          const _CmrSheetHandle(),
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Профиль тренера', style: _CmrText.title(16)),
                    const SizedBox(height: 2),
                    Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.muted(12)),
                  ],
                ),
              ),
              Material(
                color: _CmrColors.soft,
                borderRadius:
                    BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                child: InkWell(
                  borderRadius:
                      BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                  onTap: () => Navigator.of(context).pop(),
                  child: const SizedBox(
                    width: 38,
                    height: 38,
                    child: Icon(Icons.close_rounded,
                        color: _CmrColors.text, size: 18),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ModalHeaderCard extends StatelessWidget {
  final String name;
  final String role;
  final String photo;
  final bool isMain;
  final int teamsCount;

  const _ModalHeaderCard({
    required this.name,
    required this.role,
    required this.photo,
    required this.isMain,
    required this.teamsCount,
  });

  @override
  Widget build(BuildContext context) {
    final teamsText = teamsCount == 0
        ? 'Без команды'
        : '$teamsCount ${_modalTeamWord(teamsCount)}';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 2, 16, 16),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              if (photo.isNotEmpty) {
                showDialog(
                  context: context,
                  builder: (_) => _FullscreenPhotoDialog(
                    photoUrl: photo,
                    name: name,
                  ),
                );
              }
            },
            child: _CmrAvatar(
              photo: photo,
              name: name,
              size: 94,
            ),
          ),
          const SizedBox(height: 14),
          Text(
            name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: _CmrText.title(21),
          ),
          const SizedBox(height: 7),
          Text(
            '$role  ·  $teamsText',
            textAlign: TextAlign.center,
            style: _CmrText.muted(11.8),
          ),
          if (isMain) ...[
            const SizedBox(height: 7),
            Text(
              'ГЛАВНЫЙ ТРЕНЕР',
              style: TextStyle(
                color: _CmrColors.greenDark,
                fontSize: 8.7,
                fontWeight: FontWeight.w700,
                letterSpacing: .35,
              ),
            ),
          ],
        ],
      ),
    );
  }

  String _modalTeamWord(int count) {
    if (count % 10 == 1 && count % 100 != 11) return 'команда';
    if (count % 10 >= 2 &&
        count % 10 <= 4 &&
        (count % 100 < 10 || count % 100 >= 20)) {
      return 'команды';
    }
    return 'команд';
  }
}

class _ModalQuickActions extends StatelessWidget {
  final VoidCallback onMessage;
  final VoidCallback onEdit;
  final VoidCallback onAssign;

  const _ModalQuickActions({
    required this.onMessage,
    required this.onEdit,
    required this.onAssign,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Expanded(
            child: _ModalTextAction(
              label: 'Сообщение',
              onTap: onMessage,
              primary: true,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _ModalTextAction(
              label: 'Редактировать',
              onTap: onEdit,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: _ModalTextAction(
              label: 'Назначить',
              onTap: onAssign,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModalTextAction extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool primary;

  const _ModalTextAction({
    required this.label,
    required this.onTap,
    this.primary = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: primary ? _CmrColors.green : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          height: 38,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: primary ? _CmrColors.green : _CmrColors.line,
              width: .7,
            ),
          ),
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _CmrText.action().copyWith(
              color: primary ? Colors.white : _CmrColors.text,
              fontSize: 10.6,
            ),
          ),
        ),
      ),
    );
  }
}

class _ModalTabBar extends StatelessWidget {
  final TabController controller;
  final int selectedTab;

  const _ModalTabBar({
    required this.controller,
    required this.selectedTab,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _CmrColors.line, width: .7),
        ),
      ),
      child: TabBar(
        controller: controller,
        indicatorColor: _CmrColors.green,
        indicatorWeight: 2.2,
        indicatorSize: TabBarIndicatorSize.label,
        dividerColor: Colors.transparent,
        labelColor: _CmrColors.text,
        unselectedLabelColor: _CmrColors.muted2,
        labelStyle: const TextStyle(
          fontSize: 11.8,
          fontWeight: FontWeight.w700,
        ),
        unselectedLabelStyle: const TextStyle(
          fontSize: 11.8,
          fontWeight: FontWeight.w500,
        ),
        tabs: const [
          Tab(text: 'Обзор'),
          Tab(text: 'Команды'),
          Tab(text: 'Связь'),
        ],
      ),
    );
  }
}

class _ModalPill extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color? color;

  const _ModalPill({
    required this.text,
    required this.icon,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final accent = color ?? _CmrColors.muted2;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          accent.withOpacity(.025),
          Colors.white,
        ),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _CmrGlowDot(
            color: accent,
            size: 4.5,
            opacity: .75,
            halo: false,
          ),
          const SizedBox(width: 6),
          Text(
            text,
            style: _CmrText.muted(12),
          ),
        ],
      ),
    );
  }
}

class _ModalActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ModalActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Material(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        child: InkWell(
          borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 15, color: color),
                const SizedBox(height: 4),
                Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: color,
                      fontSize: 10.35,
                      fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ModalBottomDangerActions extends StatelessWidget {
  final VoidCallback onUnlinkTeam;
  final VoidCallback onRemoveClub;

  const _ModalBottomDangerActions({
    required this.onUnlinkTeam,
    required this.onRemoveClub,
  });

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
        decoration: const BoxDecoration(
          border: Border(
            top: BorderSide(color: _CmrColors.line, width: .7),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: _ModalDangerTextButton(
                label: 'Отвязать',
                color: _CmrColors.amber,
                onTap: onUnlinkTeam,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _ModalDangerTextButton(
                label: 'Удалить из клуба',
                color: _CmrColors.red,
                onTap: onRemoveClub,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModalDangerTextButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ModalDangerTextButton({
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          height: 36,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: color.withOpacity(.45),
                width: .8,
              ),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 10.6,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}

class _ModalDangerButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final bool isRed;

  const _ModalDangerButton({
    required this.icon,
    required this.label,
    required this.onTap,
    this.isRed = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = isRed ? _CmrColors.red : _CmrColors.amber;
    return Material(
      color: color.withOpacity(.09),
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      color: color,
                      fontSize: 11.85,
                      fontWeight: FontWeight.w500),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ModalOverviewTab extends StatelessWidget {
  final String role;
  final String experience;
  final String birthday;
  final String city;
  final String specialization;
  final String bio;
  final List<Map<String, dynamic>> schedule;

  const _ModalOverviewTab({
    required this.role,
    required this.experience,
    required this.birthday,
    required this.city,
    required this.specialization,
    required this.bio,
    required this.schedule,
  });

  @override
  Widget build(BuildContext context) {
    final info = <_ModalInfoData>[
      _ModalInfoData(Icons.badge_rounded, 'Должность', role),
      _ModalInfoData(Icons.workspace_premium_rounded, 'Опыт',
          experience.isEmpty ? 'Не указан' : experience),
      _ModalInfoData(Icons.cake_rounded, 'Дата рождения',
          birthday.isEmpty ? 'Не указана' : birthday),
      _ModalInfoData(Icons.location_city_rounded, 'Город',
          city.isEmpty ? 'Не указан' : city),
      if (specialization.isNotEmpty)
        _ModalInfoData(
            Icons.sports_soccer_rounded, 'Специализация', specialization),
    ];

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          LayoutBuilder(
            builder: (context, constraints) {
              final twoColumns = constraints.maxWidth >= 520;
              return Wrap(
                spacing: 10,
                runSpacing: 10,
                children: info
                    .map(
                      (item) => SizedBox(
                        width: twoColumns
                            ? (constraints.maxWidth - 10) / 2
                            : constraints.maxWidth,
                        child: _ModalInfoRow(
                            icon: item.icon,
                            label: item.label,
                            value: item.value),
                      ),
                    )
                    .toList(),
              );
            },
          ),
          const SizedBox(height: 12),
          _TrainerScheduleSection(schedule: schedule, compact: true),
          const SizedBox(height: 12),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: _CmrDecor.softCard(radius: 22),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('О тренере', style: _CmrText.title(15)),
                const SizedBox(height: 10),
                Text(
                  bio.isEmpty
                      ? 'Описание пока не заполнено. Можно добавить опыт, задачи тренера и направление работы с командой.'
                      : bio,
                  style: _CmrText.muted(13.2),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ModalInfoData {
  final IconData icon;
  final String label;
  final String value;

  const _ModalInfoData(this.icon, this.label, this.value);
}

class _ModalAssignmentsTab extends StatelessWidget {
  final List<Map<String, dynamic>> teams;

  const _ModalAssignmentsTab({required this.teams});

  @override
  Widget build(BuildContext context) {
    if (teams.isEmpty) {
      return _ModalEmptyBlock(
        icon: Icons.groups_2_rounded,
        title: 'Нет назначений',
        text:
            'Назначьте тренера в команду, чтобы он появился в тренерском штабе.',
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
      itemCount: teams.length,
      separatorBuilder: (_, __) => const SizedBox(height: 10),
      itemBuilder: (context, index) {
        final team = teams[index];
        final profile =
            _profileTitle(_s(team['link_profile'] ?? team['profile']));
        final isHead = profile == 'Главный тренер';
        return Container(
          padding: const EdgeInsets.all(14),
          decoration: _CmrDecor.softCard(radius: 22),
          child: Row(
            children: [
              _CmrAvatar(
                  photo: _teamLogo(team), name: _teamName(team), size: 50),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_teamName(team),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.title(15)),
                    const SizedBox(height: 4),
                    Text(profile,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.muted(12.5)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ModalContactsTab extends StatelessWidget {
  final String phone;
  final String email;

  const _ModalContactsTab({
    required this.phone,
    required this.email,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
      child: Column(
        children: [
          _ModalContactCard(
            icon: Icons.phone_rounded,
            label: 'Телефон',
            value: phone.isEmpty ? 'Не указан' : phone,
            color: _CmrColors.green,
          ),
          const SizedBox(height: 10),
          _ModalContactCard(
            icon: Icons.mail_rounded,
            label: 'Email',
            value: email.isEmpty ? 'Не указан' : email,
            color: _CmrColors.blue,
          ),
          const SizedBox(height: 12),
          _CmrNotice(
            icon: Icons.info_outline_rounded,
            title: 'Быстрая связь',
            text: 'Кнопка «Сообщение» сверху откроет личный чат с тренером.',
          ),
        ],
      ),
    );
  }
}

class _ModalInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _ModalInfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 44),
      padding: const EdgeInsets.symmetric(vertical: 8),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _CmrColors.line, width: .55),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 116,
            child: Text(
              label,
              style: _CmrText.caption(),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: _CmrText.value(12.2),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

class _ModalContactCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _ModalContactCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 52),
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _CmrColors.line, width: .55),
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 92,
            child: Text(
              label,
              style: _CmrText.caption(),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: _CmrText.value(12.6),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModalEmptyBlock extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _ModalEmptyBlock(
      {required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: _CmrDecor.softCard(radius: 26),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _CmrRoundIcon(icon: icon, color: _CmrColors.green, size: 52),
              const SizedBox(height: 12),
              Text(title,
                  textAlign: TextAlign.center, style: _CmrText.title(18)),
              const SizedBox(height: 7),
              Text(text,
                  textAlign: TextAlign.center, style: _CmrText.muted(13)),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== Компактные компоненты ====================

class _CompactTrainersHeader extends StatelessWidget {
  final String clubName;
  final int trainersCount;
  final int assigned;
  final int mainCount;
  final int doctorsCount;
  final VoidCallback? onAddTrainer;
  final VoidCallback? onAssignTrainer;

  const _CompactTrainersHeader({
    required this.clubName,
    required this.trainersCount,
    required this.assigned,
    required this.mainCount,
    required this.doctorsCount,
    this.onAddTrainer,
    this.onAssignTrainer,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 8),
      decoration: BoxDecoration(
        color: _CmrColors.panel,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              _CmrRoundIcon(
                  icon: Icons.badge_rounded, color: _CmrColors.green, size: 32),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Тренеры', style: _CmrText.title(16)),
                    Text(clubName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.muted(11)),
                  ],
                ),
              ),
              _CompactActionButton(
                  icon: Icons.person_add_alt_1_rounded, onTap: onAddTrainer),
              const SizedBox(width: 8),
              _CompactActionButton(
                  icon: Icons.add_link_rounded, onTap: onAssignTrainer),
            ],
          ),
          const SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _CompactStatChip(
                    value: '$trainersCount',
                    label: 'в клубе',
                    icon: Icons.groups_2_rounded),
                const SizedBox(width: 6),
                _CompactStatChip(
                    value: '$assigned',
                    label: 'назначены',
                    icon: Icons.link_rounded),
                const SizedBox(width: 6),
                _CompactStatChip(
                    value: '$mainCount',
                    label: 'главные',
                    icon: Icons.workspace_premium_rounded),
                const SizedBox(width: 6),
                _CompactStatChip(
                    value: '$doctorsCount',
                    label: 'медики',
                    icon: Icons.health_and_safety_rounded),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CompactActionButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;

  const _CompactActionButton({required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.soft,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Container(
            padding: const EdgeInsets.all(10),
            child: Icon(icon, size: 18, color: _CmrColors.green)),
      ),
    );
  }
}

class _CompactStatChip extends StatelessWidget {
  final String value;
  final String label;
  final IconData icon;

  const _CompactStatChip({
    required this.value,
    required this.label,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const _CmrGlowDot(
            color: _CmrColors.green,
            size: 4.5,
            opacity: .72,
            halo: false,
          ),
          const SizedBox(width: 6),
          Text(
            value,
            style: _CmrText.title(12),
          ),
          const SizedBox(width: 3),
          Text(
            label,
            style: _CmrText.muted(10),
          ),
        ],
      ),
    );
  }
}

class _CompactSearchBar extends StatelessWidget {
  final TextEditingController controller;

  const _CompactSearchBar({required this.controller});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      style: AppTypography.formText(color: _CmrColors.text),
      decoration: InputDecoration(
        hintText: 'Поиск тренера...',
        hintStyle: AppTypography.formHint(color: _CmrColors.muted2),
        prefixIcon:
            Icon(Icons.search_rounded, color: _CmrColors.muted, size: 16),
        filled: true,
        fillColor: _CmrColors.soft,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
      ),
    );
  }
}

class _CompactFilters extends StatelessWidget {
  final _CmrStaffFilter currentFilter;
  final ValueChanged<_CmrStaffFilter> onFilterChanged;

  const _CompactFilters(
      {required this.currentFilter, required this.onFilterChanged});

  @override
  Widget build(BuildContext context) {
    final items = [
      (_CmrStaffFilter.all, 'Все'),
      (_CmrStaffFilter.main, 'Главные'),
      (_CmrStaffFilter.coaches, 'Тренеры'),
      (_CmrStaffFilter.assistants, 'Ассистенты'),
      (_CmrStaffFilter.doctors, 'Врачи'),
      (_CmrStaffFilter.press, 'Пресс-служба'),
      (_CmrStaffFilter.noTeam, 'Без команды'),
    ];

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: items.map((item) {
          final active = currentFilter == item.$1;
          return Padding(
            padding: const EdgeInsets.only(right: 6),
            child: Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              child: InkWell(
                borderRadius:
                    BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                onTap: () => onFilterChanged(item.$1),
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: active ? _CmrColors.panel : _CmrColors.soft,
                    borderRadius:
                        BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                    border: Border.all(
                        color: active
                            ? _CmrColors.green.withOpacity(.16)
                            : _CmrColors.line),
                  ),
                  child: Text(
                    item.$2,
                    style: active
                        ? _CmrText.tabSelected().copyWith(fontSize: 11.55)
                        : _CmrText.tab().copyWith(fontSize: 11.55),
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _CmrTrainerTile extends StatelessWidget {
  final String name;
  final String role;
  final String team;
  final String photo;
  final bool main;
  final VoidCallback onTap;

  const _CmrTrainerTile({
    required this.name,
    required this.role,
    required this.team,
    required this.photo,
    required this.main,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: _CmrColors.soft,
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
          ),
          child: Row(
            children: [
              _CmrAvatar(photo: photo, name: name, size: 50),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: _CmrText.title(14.5)),
                        ),
                        if (main)
                          Icon(Icons.workspace_premium_rounded,
                              color: _CmrColors.green, size: 15),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      children: [
                        _CmrPill(text: role, icon: Icons.badge_rounded),
                        _CmrPill(text: team, icon: Icons.groups_2_rounded),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chevron_right_rounded,
                  color: _CmrColors.muted, size: 18),
            ],
          ),
        ),
      ),
    );
  }
}

class _CmrPill extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color? color;

  const _CmrPill({
    required this.text,
    required this.icon,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final accent = color ?? _CmrColors.muted2;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 8,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          accent.withOpacity(.025),
          Colors.white,
        ),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _CmrGlowDot(
            color: accent,
            size: 4.5,
            opacity: .72,
            halo: false,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _CmrText.muted(11),
            ),
          ),
        ],
      ),
    );
  }
}

class _CmrAvatar extends StatefulWidget {
  final String photo;
  final String name;
  final double size;

  const _CmrAvatar(
      {required this.photo, required this.name, required this.size});

  @override
  State<_CmrAvatar> createState() => _CmrAvatarState();
}

class _CmrAvatarState extends State<_CmrAvatar> {
  bool _hasError = false;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _resetLoadingState();
  }

  @override
  void didUpdateWidget(_CmrAvatar oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.photo != widget.photo) _resetLoadingState();
  }

  void _resetLoadingState() {
    _hasError = false;
    _isLoading = widget.photo.isNotEmpty;
  }

  void _onImageLoaded() {
    if (mounted) setState(() => _isLoading = false);
  }

  void _onImageError() {
    if (mounted)
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
  }

  @override
  Widget build(BuildContext context) {
    final initials = widget.name.trim().isEmpty
        ? 'Т'
        : widget.name
            .trim()
            .split(RegExp(r'\s+'))
            .take(2)
            .map((e) => e.isEmpty ? '' : e[0].toUpperCase())
            .join();

    return Container(
      width: widget.size,
      height: widget.size,
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(math.min(widget.size * .22, 14)),
      ),
      clipBehavior: Clip.antiAlias,
      child: _hasError || widget.photo.isEmpty
          ? Center(
              child: Text(initials, style: _CmrText.title(widget.size * .32)))
          : Stack(
              fit: StackFit.expand,
              children: [
                Image.network(
                  widget.photo,
                  fit: BoxFit.cover,
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) {
                      WidgetsBinding.instance
                          .addPostFrameCallback((_) => _onImageLoaded());
                      return child;
                    }
                    return Center(
                      child: SizedBox(
                        width: widget.size * 0.3,
                        height: widget.size * 0.3,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: _CmrColors.green,
                          value: loadingProgress.expectedTotalBytes != null
                              ? loadingProgress.cumulativeBytesLoaded /
                                  loadingProgress.expectedTotalBytes!
                              : null,
                        ),
                      ),
                    );
                  },
                  errorBuilder: (_, __, ___) {
                    _onImageError();
                    return Center(
                        child: Text(initials,
                            style: _CmrText.title(widget.size * .32)));
                  },
                ),
                if (_isLoading) Container(color: Colors.white.withOpacity(0.5)),
              ],
            ),
    );
  }
}

class _CmrRoundIcon extends StatelessWidget {
  final IconData icon;
  final Color color;
  final double size;

  const _CmrRoundIcon({
    required this.icon,
    required this.color,
    this.size = 36,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          color.withOpacity(.055),
          Colors.white,
        ),
        borderRadius: BorderRadius.circular(
          math.min(size * .22, 10),
        ),
      ),
      child: _CmrGlowDot(
        color: color,
        size: math.max(5.0, math.min(7.0, size * .16)),
        halo: color == _CmrColors.green,
      ),
    );
  }
}

class _CmrPrimaryButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback? onTap;
  final Color color;

  const _CmrPrimaryButton(
      {required this.icon,
      required this.title,
      required this.onTap,
      this.color = _CmrColors.green});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            decoration: color == _CmrColors.green
                ? _CmrDecor.fluentSurface(
                    radius: 10,
                    accent: _CmrColors.green,
                    active: true,
                    compact: true)
                : BoxDecoration(
                    color: color,
                    borderRadius:
                        BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                    border: Border.all(color: color.withOpacity(.25)),
                  ),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon,
                    size: 15,
                    color: color == _CmrColors.green
                        ? _CmrColors.green
                        : Colors.white),
                const SizedBox(width: 8),
                Flexible(
                    child: Text(title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                            color: color == _CmrColors.green
                                ? _CmrColors.green
                                : Colors.white,
                            fontSize: 11.85,
                            fontWeight: FontWeight.w600))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CmrSecondaryButton extends StatelessWidget {
  final String title;
  final VoidCallback? onTap;

  const _CmrSecondaryButton({required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Opacity(
          opacity: onTap == null ? .55 : 1,
          child: Container(
            decoration: BoxDecoration(
                color: _CmrColors.soft,
                borderRadius:
                    BorderRadius.circular(_CmrDecor.mobileInnerRadius)),
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            child: Center(child: Text(title, style: _CmrText.tab())),
          ),
        ),
      ),
    );
  }
}

class _CmrInput extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final int maxLines;
  final Widget? suffix;
  final TextInputType? keyboardType;
  final ValueChanged<String>? onSubmitted;

  const _CmrInput({
    required this.controller,
    required this.hint,
    required this.icon,
    this.maxLines = 1,
    this.suffix,
    this.keyboardType,
    this.onSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      keyboardType: keyboardType,
      onSubmitted: onSubmitted,
      style: AppTypography.formText(color: _CmrColors.text),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: AppTypography.formHint(color: _CmrColors.muted2),
        prefixIcon: Icon(icon, color: _CmrColors.muted, size: 18),
        suffixIcon: suffix,
        filled: true,
        fillColor: _CmrColors.soft,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            borderSide: BorderSide.none),
      ),
    );
  }
}

class _CmrEmptyState extends StatelessWidget {
  final String title;
  final String text;
  final String buttonText;
  final VoidCallback onTap;

  const _CmrEmptyState(
      {required this.title,
      required this.text,
      required this.buttonText,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: _CmrDecor.softCard(radius: 28),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _CmrRoundIcon(
                icon: Icons.badge_rounded, color: _CmrColors.muted, size: 52),
            const SizedBox(height: 12),
            Text(title, textAlign: TextAlign.center, style: _CmrText.title(16)),
            const SizedBox(height: 6),
            Text(text,
                textAlign: TextAlign.center, style: _CmrText.muted(12.5)),
            const SizedBox(height: 14),
            SizedBox(
                width: 190,
                child: _CmrPrimaryButton(
                    icon: Icons.person_add_alt_1_rounded,
                    title: buttonText,
                    onTap: onTap)),
          ],
        ),
      ),
    );
  }
}

class _CmrErrorState extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;

  const _CmrErrorState({required this.text, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: _CmrDecor.panel(),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded,
                color: _CmrColors.red, size: 38),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center, style: _CmrText.muted(13)),
            const SizedBox(height: 14),
            SizedBox(
                width: 160,
                child: _CmrPrimaryButton(
                    icon: Icons.refresh_rounded,
                    title: 'Повторить',
                    onTap: onRetry)),
          ],
        ),
      ),
    );
  }
}

class _CmrNotice extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _CmrNotice(
      {required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _CmrDecor.softCard(radius: 24),
      child: Row(
        children: [
          _CmrRoundIcon(icon: icon, color: _CmrColors.green, size: 36),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: _CmrText.title(14)),
                const SizedBox(height: 4),
                Text(text, style: _CmrText.muted(13)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CmrBottomPanel extends StatelessWidget {
  final Widget child;
  final double maxHeightFactor;

  const _CmrBottomPanel({required this.child, this.maxHeightFactor = .86});

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.viewInsetsOf(context).bottom;
    final h = MediaQuery.sizeOf(context).height;
    return Padding(
      padding: EdgeInsets.only(bottom: bottom),
      child: Container(
        constraints: BoxConstraints(maxHeight: h * maxHeightFactor),
        margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
        decoration: _CmrDecor.panel(radius: _CmrDecor.sheetRadius),
        child: SingleChildScrollView(child: child),
      ),
    );
  }
}

class _CmrSheetHandle extends StatelessWidget {
  const _CmrSheetHandle();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 42,
        height: 5,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
            color: const Color(0xFFD0D5DD),
            borderRadius: BorderRadius.circular(99)),
      ),
    );
  }
}

class _CmrSheetTitle extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _CmrSheetTitle(
      {required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        _CmrRoundIcon(icon: icon, color: _CmrColors.green, size: 44),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: _CmrText.title(20)),
              const SizedBox(height: 4),
              Text(subtitle, style: _CmrText.muted(12.5)),
            ],
          ),
        ),
      ],
    );
  }
}

class _CmrSearchTrainerTile extends StatelessWidget {
  final String name;
  final String email;
  final String photo;
  final VoidCallback onAddClub;
  final VoidCallback onAssignTeam;

  const _CmrSearchTrainerTile({
    required this.name,
    required this.email,
    required this.photo,
    required this.onAddClub,
    required this.onAssignTeam,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: _CmrDecor.softCard(radius: 22),
      child: Column(
        children: [
          Row(
            children: [
              _CmrAvatar(photo: photo, name: name, size: 48),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.title(14)),
                    Text(email.isEmpty ? 'Email не указан' : email,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _CmrText.muted(11.5)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                  child:
                      _CmrSecondaryButton(title: 'В клуб', onTap: onAddClub)),
              const SizedBox(width: 8),
              Expanded(
                  child: _CmrPrimaryButton(
                      icon: Icons.add_link_rounded,
                      title: 'В команду',
                      onTap: onAssignTeam)),
            ],
          ),
        ],
      ),
    );
  }
}

class _CmrTeamPickTile extends StatelessWidget {
  final String name;
  final String logo;
  final VoidCallback onTap;

  const _CmrTeamPickTile(
      {required this.name, required this.logo, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: _CmrDecor.softCard(radius: 20),
          child: Row(
            children: [
              _CmrAvatar(photo: logo, name: name, size: 42),
              const SizedBox(width: 10),
              Expanded(
                  child: Text(name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _CmrText.title(14))),
              const Icon(Icons.chevron_right_rounded, color: _CmrColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _CmrRolePickTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final Color color;
  final VoidCallback onTap;

  const _CmrRolePickTile({
    required this.icon,
    required this.title,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(13),
          decoration: _CmrDecor.softCard(radius: 20),
          child: Row(
            children: [
              Icon(icon, color: color),
              const SizedBox(width: 10),
              Expanded(child: Text(title, style: _CmrText.title(14))),
              const Icon(Icons.chevron_right_rounded, color: _CmrColors.muted),
            ],
          ),
        ),
      ),
    );
  }
}

// ==================== ПОЛНОЭКРАННЫЙ ПРОФИЛЬ ТРЕНЕРА ====================

class TrainerProfileScreen extends StatefulWidget {
  final Map<String, dynamic> trainer;
  final VoidCallback onMessage;
  final VoidCallback onEdit;
  final VoidCallback onAssign;
  final VoidCallback onUnlinkTeam;
  final VoidCallback onRemoveClub;

  const TrainerProfileScreen({
    super.key,
    required this.trainer,
    required this.onMessage,
    required this.onEdit,
    required this.onAssign,
    required this.onUnlinkTeam,
    required this.onRemoveClub,
  });

  @override
  State<TrainerProfileScreen> createState() => _TrainerProfileScreenState();
}

class _TrainerProfileScreenState extends State<TrainerProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _tabController.addListener(() {
      if (mounted) {
        setState(() {
          _selectedTab = _tabController.index;
        });
      }
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final name = _trainerName(widget.trainer);
    final role = _trainerRole(widget.trainer);
    final photo = _trainerPhoto(widget.trainer);
    final isMain = _isMain(widget.trainer);
    final teams = _trainerTeams(widget.trainer);
    final phone = _trainerPhone(widget.trainer);
    final email = _trainerEmail(widget.trainer);
    final birthday = _trainerBirthday(widget.trainer);
    final experience = _trainerExperience(widget.trainer);
    final city = _trainerCity(widget.trainer);
    final specialization = _trainerSpecialization(widget.trainer);
    final bio = _trainerBio(widget.trainer);

    return Scaffold(
      backgroundColor: _CmrColors.bg,
      body: Column(
        children: [
          // Кастомный AppBar
          _ProfileAppBar(
            name: name,
            onBack: () => Navigator.pop(context),
          ),
          // Основной контент
          Expanded(
            child: CustomScrollView(
              slivers: [
                // Header с фото
                SliverToBoxAdapter(
                  child: _ProfileHeader(
                    name: name,
                    role: role,
                    photo: photo,
                    isMain: isMain,
                    teamsCount: teams.length,
                  ),
                ),
                // Кнопки действий
                SliverToBoxAdapter(
                  child: _ProfileActions(
                    onMessage: widget.onMessage,
                    onEdit: widget.onEdit,
                    onAssign: widget.onAssign,
                  ),
                ),
                // TabBar
                SliverToBoxAdapter(
                  child: _ProfileTabBar(
                    tabController: _tabController,
                    selectedTab: _selectedTab,
                  ),
                ),
                // TabBarView content
                SliverFillRemaining(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _ProfileOverviewTab(
                        role: role,
                        experience: experience,
                        birthday: birthday,
                        city: city,
                        specialization: specialization,
                        bio: bio,
                      ),
                      _ProfileAssignmentsTab(teams: teams),
                      _ProfileContactsTab(phone: phone, email: email),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Нижние кнопки
          _ProfileBottomButtons(
            onUnlinkTeam: widget.onUnlinkTeam,
            onRemoveClub: widget.onRemoveClub,
          ),
        ],
      ),
    );
  }
}

// ==================== КОМПОНЕНТЫ ПРОФИЛЯ ====================

class _ProfileAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String name;
  final VoidCallback onBack;

  const _ProfileAppBar({
    required this.name,
    required this.onBack,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(top: 48, left: 16, right: 16, bottom: 12),
      decoration: BoxDecoration(
        color: _CmrColors.panel,
      ),
      child: Row(
        children: [
          Material(
            color: _CmrColors.soft,
            borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
            child: InkWell(
              borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
              onTap: onBack,
              child: const Padding(
                padding: EdgeInsets.all(10),
                child: Icon(Icons.arrow_back_rounded,
                    size: 19, color: _CmrColors.text),
              ),
            ),
          ),
          const SizedBox(width: 12),
          _CmrRoundIcon(
              icon: Icons.badge_rounded, color: _CmrColors.green, size: 32),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('Профиль тренера', style: _CmrText.title(16)),
                const SizedBox(height: 2),
                Text(
                  name,
                  style: _CmrText.muted(12),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          const SizedBox(width: 48),
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(88);
}

class _ProfileHeader extends StatelessWidget {
  final String name;
  final String role;
  final String photo;
  final bool isMain;
  final int teamsCount;

  const _ProfileHeader({
    required this.name,
    required this.role,
    required this.photo,
    required this.isMain,
    required this.teamsCount,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        children: [
          GestureDetector(
            onTap: () {
              if (photo.isNotEmpty) {
                showDialog(
                  context: context,
                  builder: (_) =>
                      _FullscreenPhotoDialog(photoUrl: photo, name: name),
                );
              }
            },
            child: _CmrAvatar(photo: photo, name: name, size: 120),
          ),
          const SizedBox(height: 20),
          Text(
            name,
            style: _CmrText.title(26),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.center,
            children: [
              _ProfilePill(text: role, icon: Icons.badge_rounded),
              if (isMain)
                _ProfilePill(
                  text: 'Главный тренер',
                  icon: Icons.verified_rounded,
                  color: _CmrColors.green,
                ),
              _ProfilePill(
                text: teamsCount == 0
                    ? 'Без команды'
                    : '$teamsCount ${_teamWord(teamsCount)}',
                icon: Icons.groups_2_rounded,
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _teamWord(int count) {
    if (count % 10 == 1 && count % 100 != 11) return 'команда';
    if (count % 10 >= 2 &&
        count % 10 <= 4 &&
        (count % 100 < 10 || count % 100 >= 20)) return 'команды';
    return 'команд';
  }
}

class _ProfilePill extends StatelessWidget {
  final String text;
  final IconData icon;
  final Color? color;

  const _ProfilePill({
    required this.text,
    required this.icon,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final accent = color ?? _CmrColors.greenDark;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Color.alphaBlend(
          accent.withOpacity(.03),
          Colors.white,
        ),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _CmrGlowDot(
            color: accent,
            size: 5,
            opacity: .78,
            halo: color == _CmrColors.green,
          ),
          const SizedBox(width: 7),
          Text(
            text,
            style: _CmrText.muted(13),
          ),
        ],
      ),
    );
  }
}

class _ProfileActions extends StatelessWidget {
  final VoidCallback onMessage;
  final VoidCallback onEdit;
  final VoidCallback onAssign;

  const _ProfileActions({
    required this.onMessage,
    required this.onEdit,
    required this.onAssign,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Expanded(
            child: _ProfileActionButton(
              icon: Icons.chat_bubble_rounded,
              label: 'Сообщение',
              color: _CmrColors.green,
              onTap: onMessage,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _ProfileActionButton(
              icon: Icons.edit_rounded,
              label: 'Редактировать',
              color: _CmrColors.green,
              onTap: onEdit,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _ProfileActionButton(
              icon: Icons.add_link_rounded,
              label: 'Назначить',
              color: _CmrColors.amber,
              onTap: onAssign,
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileActionButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _ProfileActionButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Color.alphaBlend(
        color.withOpacity(.025),
        _CmrColors.soft,
      ),
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: SizedBox(
          height: 40,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 3,
                height: 16,
                decoration: BoxDecoration(
                  color: color.withOpacity(.75),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(width: 7),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: color,
                    fontSize: 10.55,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileTabBar extends StatelessWidget {
  final TabController tabController;
  final int selectedTab;

  const _ProfileTabBar({
    required this.tabController,
    required this.selectedTab,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 20, 20, 0),
      decoration: BoxDecoration(
        color: _CmrColors.soft,
        borderRadius: BorderRadius.circular(40),
      ),
      child: TabBar(
        controller: tabController,
        indicator: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(40),
          border: Border.all(color: _CmrColors.green.withOpacity(.18)),
        ),
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: _CmrColors.green,
        unselectedLabelColor: _CmrColors.muted,
        labelStyle:
            const TextStyle(fontSize: 13.05, fontWeight: FontWeight.w500),
        unselectedLabelStyle:
            const TextStyle(fontSize: 13.05, fontWeight: FontWeight.w500),
        tabs: const [
          Tab(text: 'Обзор'),
          Tab(text: 'Назначения'),
          Tab(text: 'Контакты'),
        ],
      ),
    );
  }
}

class _ProfileOverviewTab extends StatelessWidget {
  final String role;
  final String experience;
  final String birthday;
  final String city;
  final String specialization;
  final String bio;

  const _ProfileOverviewTab({
    required this.role,
    required this.experience,
    required this.birthday,
    required this.city,
    required this.specialization,
    required this.bio,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _ProfileInfoCard(
            icon: Icons.badge_rounded,
            label: 'Должность',
            value: role,
          ),
          const SizedBox(height: 12),
          _ProfileInfoCard(
            icon: Icons.workspace_premium_rounded,
            label: 'Опыт работы',
            value: experience.isEmpty ? 'Не указан' : experience,
          ),
          const SizedBox(height: 12),
          _ProfileInfoCard(
            icon: Icons.cake_rounded,
            label: 'Дата рождения',
            value: birthday.isEmpty ? 'Не указана' : birthday,
          ),
          const SizedBox(height: 12),
          _ProfileInfoCard(
            icon: Icons.location_city_rounded,
            label: 'Город',
            value: city.isEmpty ? 'Не указан' : city,
          ),
          if (specialization.isNotEmpty) ...[
            const SizedBox(height: 12),
            _ProfileInfoCard(
              icon: Icons.sports_soccer_rounded,
              label: 'Специализация',
              value: specialization,
            ),
          ],
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(20),
            decoration: _CmrDecor.softCard(radius: 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const _CmrGlowDot(
                      color: _CmrColors.green,
                      size: 6,
                    ),
                    const SizedBox(width: 10),
                    Text('О тренере', style: _CmrText.title(16)),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  bio.isEmpty ? 'Описание пока не заполнено.' : bio,
                  style: _CmrText.muted(14),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _ProfileInfoCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _ProfileInfoCard({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 56),
      padding: const EdgeInsets.symmetric(vertical: 10),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: _CmrColors.line,
            width: .55,
          ),
        ),
      ),
      child: Row(
        children: [
          const _CmrGlowDot(
            color: _CmrColors.greenDark,
            size: 5.5,
            halo: false,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: _CmrText.caption(),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: _CmrText.value(15),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileAssignmentsTab extends StatelessWidget {
  final List<Map<String, dynamic>> teams;

  const _ProfileAssignmentsTab({required this.teams});

  @override
  Widget build(BuildContext context) {
    if (teams.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.groups_2_rounded,
                size: 64, color: _CmrColors.muted.withOpacity(0.4)),
            const SizedBox(height: 20),
            Text('Нет назначений', style: _CmrText.title(20)),
            const SizedBox(height: 8),
            Text(
              'Тренер пока не назначен ни в одну команду',
              style: _CmrText.muted(14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(20),
      itemCount: teams.length,
      separatorBuilder: (_, __) => const SizedBox(height: 12),
      itemBuilder: (context, index) {
        final team = teams[index];
        final profile =
            _profileTitle(_s(team['link_profile'] ?? team['profile']));
        final isMainCoach = _i(team['main_coach_id']) > 0;

        return Container(
          padding: const EdgeInsets.all(16),
          decoration: _CmrDecor.softCard(radius: 20),
          child: Row(
            children: [
              _CmrAvatar(
                  photo: _teamLogo(team), name: _teamName(team), size: 56),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _teamName(team),
                      style: _CmrText.title(16),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.badge_rounded,
                            size: 12, color: _CmrColors.muted),
                        const SizedBox(width: 4),
                        Text(profile, style: _CmrText.muted(12)),
                      ],
                    ),
                  ],
                ),
              ),
              if (isMainCoach || profile == 'Главный тренер')
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: _CmrColors.panel,
                    borderRadius:
                        BorderRadius.circular(_CmrDecor.mobileInnerRadius),
                    border:
                        Border.all(color: _CmrColors.green.withOpacity(.14)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.workspace_premium_rounded,
                          size: 12, color: _CmrColors.green),
                      const SizedBox(width: 4),
                      Text(
                        'Главный',
                        style: TextStyle(
                            color: _CmrColors.green,
                            fontSize: 10.55,
                            fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _ProfileContactsTab extends StatelessWidget {
  final String phone;
  final String email;

  const _ProfileContactsTab({
    required this.phone,
    required this.email,
  });

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          _ProfileContactCard(
            icon: Icons.phone_rounded,
            label: 'Телефон',
            value: phone.isEmpty ? 'Не указан' : phone,
            color: _CmrColors.green,
            onTap: phone.isNotEmpty
                ? () {
                    // Можно добавить вызов телефонного звонка
                  }
                : null,
          ),
          const SizedBox(height: 16),
          _ProfileContactCard(
            icon: Icons.mail_rounded,
            label: 'Email',
            value: email.isEmpty ? 'Не указан' : email,
            color: _CmrColors.blue,
            onTap: email.isNotEmpty
                ? () {
                    // Можно добавить отправку email
                  }
                : null,
          ),
        ],
      ),
    );
  }
}

class _ProfileContactCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final VoidCallback? onTap;

  const _ProfileContactCard({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 58),
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: const BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: _CmrColors.line,
                width: .55,
              ),
            ),
          ),
          child: Row(
            children: [
              _CmrGlowDot(
                color: color,
                size: 6,
                halo: false,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: _CmrText.caption(),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      value,
                      style: _CmrText.value(13.2),
                    ),
                  ],
                ),
              ),
              if (onTap != null)
                const Icon(
                  Icons.chevron_right_rounded,
                  color: _CmrColors.muted2,
                  size: 18,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileBottomButtons extends StatelessWidget {
  final VoidCallback onUnlinkTeam;
  final VoidCallback onRemoveClub;

  const _ProfileBottomButtons({
    required this.onUnlinkTeam,
    required this.onRemoveClub,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _CmrColors.panel,
      ),
      child: SafeArea(
        child: Row(
          children: [
            Expanded(
              child: _ProfileDangerButton(
                icon: Icons.link_off_rounded,
                label: 'Отвязать от команды',
                onTap: onUnlinkTeam,
                color: _CmrColors.amber,
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _ProfileDangerButton(
                icon: Icons.delete_outline_rounded,
                label: 'Удалить из клуба',
                onTap: onRemoveClub,
                color: _CmrColors.red,
                isRed: true,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileDangerButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  final bool isRed;

  const _ProfileDangerButton({
    required this.icon,
    required this.label,
    required this.onTap,
    required this.color,
    this.isRed = false,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _CmrColors.soft,
      borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
      child: InkWell(
        borderRadius: BorderRadius.circular(_CmrDecor.mobileInnerRadius),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: color),
              const SizedBox(width: 8),
              Text(
                label,
                style: TextStyle(
                    color: color, fontSize: 12.35, fontWeight: FontWeight.w500),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
