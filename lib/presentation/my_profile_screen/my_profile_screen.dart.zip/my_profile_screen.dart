// lib/presentation/my_profile_screen/my_profile_screen.dart

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'dart:math' as math;

import 'package:flutter/foundation.dart'
    show TargetPlatform, defaultTargetPlatform;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/core/auth/club_access_guard.dart';
import 'package:sportoteka/presentation/auth/club_access_screen.dart';
import 'package:sportoteka/presentation/community_screen/news_detail_screen.dart';
import 'package:sportoteka/presentation/community_screen/create_content_screen.dart';
import 'package:sportoteka/presentation/community_screen/sport_community_screen.dart';
import 'package:sportoteka/widgets/player_skills_fifa_stub.dart';
import 'package:sportoteka/presentation/reels_screen/user_reels_screen.dart';
import 'package:sportoteka/presentation/reels_screen/reels_screen.dart';
import 'package:sportoteka/presentation/chat_screen/chat_room_screen.dart';
import 'package:sportoteka/presentation/chat_screen/chat_screen.dart';
import 'package:sportoteka/presentation/chat_screen/cmr_notifications_panel.dart';
import 'package:sportoteka/presentation/club_workspace/club_workspace_screen.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_press_assistant_screen.dart';
import 'package:sportoteka/presentation/booking_screen/booking_screen.dart';
import 'package:sportoteka/presentation/catalog/events_list_screen.dart';
import 'package:sportoteka/presentation/catalog/team_list_screen.dart';
import 'package:sportoteka/presentation/service_screens/generic_service_screen.dart';
import 'package:sportoteka/presentation/subscription/subscription_screen.dart';
import 'package:sportoteka/presentation/tracking/tracking_mode_screen.dart';
import 'package:sportoteka/presentation/tracker/player/player_my_trainings_screen.dart';
import 'package:sportoteka/presentation/video_lessons/video_lessons_hub_screen.dart';
import 'package:sportoteka/presentation/player_screen/player_dashboard_screen.dart';
import 'package:sportoteka/presentation/parent_access/parent_family_screen.dart';
import 'package:sportoteka/presentation/my_profile_screen/profile_reel_widget.dart';
import 'package:sportoteka/routes/app_routes.dart';

// =============================
// ЦВЕТОВАЯ ПАЛИТРА (ОСТАВЛЯЕМ)
// =============================
class ProfilePalette {
  static const primaryGreen = Color(0xFF00A750);
  static const primaryGreenDark = Color(0xFF008C40);
  static const primaryGreenLight = Color(0xFF00C060);
  static const accentGreen = Color(0xFF7ED321);
  static const lightGreen = Color(0xFFE8F5E9);
  static const white = Color(0xFFFFFFFF);
  static const text = Color(0xFF1A1A1A);
  static const textMuted = Color(0xFF666666);
  static const textLight = Color(0xFF999999);
  static const background = Color(0xFFFFFFFF);
  static const card = Color(0xFFFFFFFF);
  static const softBackground = Color(0xFFF8F9F8);
  static const softGreen = Color(0xFFF1FBF6);
  static const border = Color(0xFFE9EEF3);
}

// =============================
// МОДЕЛЬ ДИЗАЙНА ПРОФИЛЯ (НОВЫЙ КОД)
// =============================
class ProfileDesign {
  // === Основные цвета ===
  int primaryColorValue;
  int secondaryColorValue;
  int accentColorValue;
  int backgroundColorValue;
  int surfaceColorValue;
  int cardColorValue;
  int textPrimaryColorValue;
  int textSecondaryColorValue;
  int textTertiaryColorValue;

  // === Текст ===
  String fontFamily;
  double titleFontSize;
  double headingFontSize;
  double bodyFontSize;
  double smallFontSize;
  FontWeight titleWeight;
  FontWeight headingWeight;
  FontWeight bodyWeight;

  // === Размеры и скругления ===
  double avatarSize;
  double avatarBorderWidth;
  double cardRadius;
  double buttonRadius;
  double spacing;
  double contentPadding;

  // === Аватар ===
  int avatarBorderColorValue;
  bool avatarGlowEnabled;
  double avatarGlowRadius;
  double avatarGlowOpacity;

  // === Градиенты ===
  bool headerGradientEnabled;
  List<int> headerGradientColors;
  double headerGradientBeginX;
  double headerGradientBeginY;
  double headerGradientEndX;
  double headerGradientEndY;

  // === Тени ===
  bool cardShadowEnabled;
  double cardShadowBlurRadius;
  double cardShadowSpreadRadius;
  double cardShadowOffsetX;
  double cardShadowOffsetY;
  int cardShadowColorValue;
  double cardShadowOpacity;

  bool avatarShadowEnabled;
  double avatarShadowBlurRadius;
  double avatarShadowSpreadRadius;
  double avatarShadowOffsetX;
  double avatarShadowOffsetY;
  int avatarShadowColorValue;
  double avatarShadowOpacity;

  // === Блоки и видимость ===
  List<ProfileBlock> blocks;
  Map<String, bool> sectionVisibility;
  Map<String, int> sectionOrder;

  // === Статистика ===
  bool statsCompactMode;
  bool statsShowLabels;
  bool statsShowIcons;

  // === Анимации ===
  bool enableHoverEffects;
  bool enablePulseEffects;

  ProfileDesign({
    required this.primaryColorValue,
    required this.secondaryColorValue,
    required this.accentColorValue,
    required this.backgroundColorValue,
    required this.surfaceColorValue,
    required this.cardColorValue,
    required this.textPrimaryColorValue,
    required this.textSecondaryColorValue,
    required this.textTertiaryColorValue,
    required this.fontFamily,
    required this.titleFontSize,
    required this.headingFontSize,
    required this.bodyFontSize,
    required this.smallFontSize,
    required this.titleWeight,
    required this.headingWeight,
    required this.bodyWeight,
    required this.avatarSize,
    required this.avatarBorderWidth,
    required this.cardRadius,
    required this.buttonRadius,
    required this.spacing,
    required this.contentPadding,
    required this.avatarBorderColorValue,
    required this.avatarGlowEnabled,
    required this.avatarGlowRadius,
    required this.avatarGlowOpacity,
    required this.headerGradientEnabled,
    required this.headerGradientColors,
    required this.headerGradientBeginX,
    required this.headerGradientBeginY,
    required this.headerGradientEndX,
    required this.headerGradientEndY,
    required this.cardShadowEnabled,
    required this.cardShadowBlurRadius,
    required this.cardShadowSpreadRadius,
    required this.cardShadowOffsetX,
    required this.cardShadowOffsetY,
    required this.cardShadowColorValue,
    required this.cardShadowOpacity,
    required this.avatarShadowEnabled,
    required this.avatarShadowBlurRadius,
    required this.avatarShadowSpreadRadius,
    required this.avatarShadowOffsetX,
    required this.avatarShadowOffsetY,
    required this.avatarShadowColorValue,
    required this.avatarShadowOpacity,
    required this.blocks,
    required this.sectionVisibility,
    required this.sectionOrder,
    required this.statsCompactMode,
    required this.statsShowLabels,
    required this.statsShowIcons,
    required this.enableHoverEffects,
    required this.enablePulseEffects,
  });

  // ========== ВАЖНО: МЕТОД COPYWITH ==========
  ProfileDesign copyWith({
    int? primaryColorValue,
    int? secondaryColorValue,
    int? accentColorValue,
    int? backgroundColorValue,
    int? surfaceColorValue,
    int? cardColorValue,
    int? textPrimaryColorValue,
    int? textSecondaryColorValue,
    int? textTertiaryColorValue,
    String? fontFamily,
    double? titleFontSize,
    double? headingFontSize,
    double? bodyFontSize,
    double? smallFontSize,
    FontWeight? titleWeight,
    FontWeight? headingWeight,
    FontWeight? bodyWeight,
    double? avatarSize,
    double? avatarBorderWidth,
    double? cardRadius,
    double? buttonRadius,
    double? spacing,
    double? contentPadding,
    int? avatarBorderColorValue,
    bool? avatarGlowEnabled,
    double? avatarGlowRadius,
    double? avatarGlowOpacity,
    bool? headerGradientEnabled,
    List<int>? headerGradientColors,
    double? headerGradientBeginX,
    double? headerGradientBeginY,
    double? headerGradientEndX,
    double? headerGradientEndY,
    bool? cardShadowEnabled,
    double? cardShadowBlurRadius,
    double? cardShadowSpreadRadius,
    double? cardShadowOffsetX,
    double? cardShadowOffsetY,
    int? cardShadowColorValue,
    double? cardShadowOpacity,
    bool? avatarShadowEnabled,
    double? avatarShadowBlurRadius,
    double? avatarShadowSpreadRadius,
    double? avatarShadowOffsetX,
    double? avatarShadowOffsetY,
    int? avatarShadowColorValue,
    double? avatarShadowOpacity,
    List<ProfileBlock>? blocks,
    Map<String, bool>? sectionVisibility,
    Map<String, int>? sectionOrder,
    bool? statsCompactMode,
    bool? statsShowLabels,
    bool? statsShowIcons,
    bool? enableHoverEffects,
    bool? enablePulseEffects,
  }) {
    return ProfileDesign(
      primaryColorValue: primaryColorValue ?? this.primaryColorValue,
      secondaryColorValue: secondaryColorValue ?? this.secondaryColorValue,
      accentColorValue: accentColorValue ?? this.accentColorValue,
      backgroundColorValue: backgroundColorValue ?? this.backgroundColorValue,
      surfaceColorValue: surfaceColorValue ?? this.surfaceColorValue,
      cardColorValue: cardColorValue ?? this.cardColorValue,
      textPrimaryColorValue:
          textPrimaryColorValue ?? this.textPrimaryColorValue,
      textSecondaryColorValue:
          textSecondaryColorValue ?? this.textSecondaryColorValue,
      textTertiaryColorValue:
          textTertiaryColorValue ?? this.textTertiaryColorValue,
      fontFamily: fontFamily ?? this.fontFamily,
      titleFontSize: titleFontSize ?? this.titleFontSize,
      headingFontSize: headingFontSize ?? this.headingFontSize,
      bodyFontSize: bodyFontSize ?? this.bodyFontSize,
      smallFontSize: smallFontSize ?? this.smallFontSize,
      titleWeight: titleWeight ?? this.titleWeight,
      headingWeight: headingWeight ?? this.headingWeight,
      bodyWeight: bodyWeight ?? this.bodyWeight,
      avatarSize: avatarSize ?? this.avatarSize,
      avatarBorderWidth: avatarBorderWidth ?? this.avatarBorderWidth,
      cardRadius: cardRadius ?? this.cardRadius,
      buttonRadius: buttonRadius ?? this.buttonRadius,
      spacing: spacing ?? this.spacing,
      contentPadding: contentPadding ?? this.contentPadding,
      avatarBorderColorValue:
          avatarBorderColorValue ?? this.avatarBorderColorValue,
      avatarGlowEnabled: avatarGlowEnabled ?? this.avatarGlowEnabled,
      avatarGlowRadius: avatarGlowRadius ?? this.avatarGlowRadius,
      avatarGlowOpacity: avatarGlowOpacity ?? this.avatarGlowOpacity,
      headerGradientEnabled:
          headerGradientEnabled ?? this.headerGradientEnabled,
      headerGradientColors: headerGradientColors ?? this.headerGradientColors,
      headerGradientBeginX: headerGradientBeginX ?? this.headerGradientBeginX,
      headerGradientBeginY: headerGradientBeginY ?? this.headerGradientBeginY,
      headerGradientEndX: headerGradientEndX ?? this.headerGradientEndX,
      headerGradientEndY: headerGradientEndY ?? this.headerGradientEndY,
      cardShadowEnabled: cardShadowEnabled ?? this.cardShadowEnabled,
      cardShadowBlurRadius: cardShadowBlurRadius ?? this.cardShadowBlurRadius,
      cardShadowSpreadRadius:
          cardShadowSpreadRadius ?? this.cardShadowSpreadRadius,
      cardShadowOffsetX: cardShadowOffsetX ?? this.cardShadowOffsetX,
      cardShadowOffsetY: cardShadowOffsetY ?? this.cardShadowOffsetY,
      cardShadowColorValue: cardShadowColorValue ?? this.cardShadowColorValue,
      cardShadowOpacity: cardShadowOpacity ?? this.cardShadowOpacity,
      avatarShadowEnabled: avatarShadowEnabled ?? this.avatarShadowEnabled,
      avatarShadowBlurRadius:
          avatarShadowBlurRadius ?? this.avatarShadowBlurRadius,
      avatarShadowSpreadRadius:
          avatarShadowSpreadRadius ?? this.avatarShadowSpreadRadius,
      avatarShadowOffsetX: avatarShadowOffsetX ?? this.avatarShadowOffsetX,
      avatarShadowOffsetY: avatarShadowOffsetY ?? this.avatarShadowOffsetY,
      avatarShadowColorValue:
          avatarShadowColorValue ?? this.avatarShadowColorValue,
      avatarShadowOpacity: avatarShadowOpacity ?? this.avatarShadowOpacity,
      blocks: blocks ?? this.blocks,
      sectionVisibility: sectionVisibility ?? this.sectionVisibility,
      sectionOrder: sectionOrder ?? this.sectionOrder,
      statsCompactMode: statsCompactMode ?? this.statsCompactMode,
      statsShowLabels: statsShowLabels ?? this.statsShowLabels,
      statsShowIcons: statsShowIcons ?? this.statsShowIcons,
      enableHoverEffects: enableHoverEffects ?? this.enableHoverEffects,
      enablePulseEffects: enablePulseEffects ?? this.enablePulseEffects,
    );
  }

  Color get primaryColor => Color(primaryColorValue);
  Color get secondaryColor => Color(secondaryColorValue);
  Color get accentColor => Color(accentColorValue);
  Color get backgroundColor => Color(backgroundColorValue);
  Color get surfaceColor => Color(surfaceColorValue);
  Color get cardColor => Color(cardColorValue);
  Color get textPrimaryColor => Color(textPrimaryColorValue);
  Color get textSecondaryColor => Color(textSecondaryColorValue);
  Color get textTertiaryColor => Color(textTertiaryColorValue);
  Color get avatarBorderColor => Color(avatarBorderColorValue);

  factory ProfileDesign.fromJson(Map<String, dynamic> json) {
    final rawBlocks = json['blocks'];
    final rawSectionVisibility = json['sectionVisibility'];
    final rawSectionOrder = json['sectionOrder'];

    return ProfileDesign(
      primaryColorValue: json['primaryColorValue'] ?? 0xFF00A750,
      secondaryColorValue: json['secondaryColorValue'] ?? 0xFF008C40,
      accentColorValue: json['accentColorValue'] ?? 0xFF7ED321,
      backgroundColorValue: json['backgroundColorValue'] ?? 0xFFF3F5F7,
      surfaceColorValue: json['surfaceColorValue'] ?? 0xFFE8F5E9,
      cardColorValue: json['cardColorValue'] ?? 0xFFFFFFFF,
      textPrimaryColorValue: json['textPrimaryColorValue'] ?? 0xFF1A1A1A,
      textSecondaryColorValue: json['textSecondaryColorValue'] ?? 0xFF666666,
      textTertiaryColorValue: json['textTertiaryColorValue'] ?? 0xFF999999,
      fontFamily: (json['fontFamily'] ?? 'default').toString(),
      titleFontSize: (json['titleFontSize'] as num?)?.toDouble() ?? 22,
      headingFontSize: (json['headingFontSize'] as num?)?.toDouble() ?? 18,
      bodyFontSize: (json['bodyFontSize'] as num?)?.toDouble() ?? 14,
      smallFontSize: (json['smallFontSize'] as num?)?.toDouble() ?? 12,
      titleWeight: _parseFontWeight((json['titleWeight'] ?? 'w900').toString()),
      headingWeight:
          _parseFontWeight((json['headingWeight'] ?? 'w700').toString()),
      bodyWeight: _parseFontWeight((json['bodyWeight'] ?? 'w500').toString()),
      avatarSize: (json['avatarSize'] as num?)?.toDouble() ?? 96,
      avatarBorderWidth: (json['avatarBorderWidth'] as num?)?.toDouble() ?? 2,
      cardRadius: (json['cardRadius'] as num?)?.toDouble() ?? 16,
      buttonRadius: (json['buttonRadius'] as num?)?.toDouble() ?? 14,
      spacing: (json['spacing'] as num?)?.toDouble() ?? 12,
      contentPadding: (json['contentPadding'] as num?)?.toDouble() ?? 16,
      avatarBorderColorValue: json['avatarBorderColorValue'] ?? 0xFF00A750,
      avatarGlowEnabled: json['avatarGlowEnabled'] == true,
      avatarGlowRadius: (json['avatarGlowRadius'] as num?)?.toDouble() ?? 20,
      avatarGlowOpacity: (json['avatarGlowOpacity'] as num?)?.toDouble() ?? 0.3,
      headerGradientEnabled: json['headerGradientEnabled'] == true,
      headerGradientColors: (json['headerGradientColors'] is List)
          ? List<int>.from((json['headerGradientColors'] as List).map((e) {
              if (e is int) return e;
              return int.tryParse('$e') ?? 0xFF00A750;
            }))
          : <int>[0xFF00A750, 0xFF008C40],
      headerGradientBeginX:
          (json['headerGradientBeginX'] as num?)?.toDouble() ?? 0,
      headerGradientBeginY:
          (json['headerGradientBeginY'] as num?)?.toDouble() ?? 0,
      headerGradientEndX: (json['headerGradientEndX'] as num?)?.toDouble() ?? 1,
      headerGradientEndY: (json['headerGradientEndY'] as num?)?.toDouble() ?? 1,
      cardShadowEnabled: json['cardShadowEnabled'] != false,
      cardShadowBlurRadius:
          (json['cardShadowBlurRadius'] as num?)?.toDouble() ?? 8,
      cardShadowSpreadRadius:
          (json['cardShadowSpreadRadius'] as num?)?.toDouble() ?? 0,
      cardShadowOffsetX: (json['cardShadowOffsetX'] as num?)?.toDouble() ?? 0,
      cardShadowOffsetY: (json['cardShadowOffsetY'] as num?)?.toDouble() ?? 4,
      cardShadowColorValue: json['cardShadowColorValue'] ?? 0xFF000000,
      cardShadowOpacity:
          (json['cardShadowOpacity'] as num?)?.toDouble() ?? 0.05,
      avatarShadowEnabled: json['avatarShadowEnabled'] != false,
      avatarShadowBlurRadius:
          (json['avatarShadowBlurRadius'] as num?)?.toDouble() ?? 8,
      avatarShadowSpreadRadius:
          (json['avatarShadowSpreadRadius'] as num?)?.toDouble() ?? 0,
      avatarShadowOffsetX:
          (json['avatarShadowOffsetX'] as num?)?.toDouble() ?? 0,
      avatarShadowOffsetY:
          (json['avatarShadowOffsetY'] as num?)?.toDouble() ?? 4,
      avatarShadowColorValue: json['avatarShadowColorValue'] ?? 0xFF000000,
      avatarShadowOpacity:
          (json['avatarShadowOpacity'] as num?)?.toDouble() ?? 0.1,
      blocks: rawBlocks is List
          ? rawBlocks
              .whereType<Map>()
              .map((e) => ProfileBlock.fromJson(Map<String, dynamic>.from(e)))
              .toList()
          : ProfileBlock.defaultBlocks(),
      sectionVisibility: rawSectionVisibility is Map
          ? Map<String, bool>.from(
              rawSectionVisibility.map(
                (key, value) => MapEntry(key.toString(), value == true),
              ),
            )
          : <String, bool>{
              'posts': true,
              'reels': true,
              'feed': true,
              'skills': true,
              'team': true,
              'bio': true,
              'location': true,
              'ai': true,
              'header': true,
              'stats': true,
              'actions': true,
              'switcher': true,
              'content': true,
            },
      sectionOrder: rawSectionOrder is Map
          ? Map<String, int>.from(
              rawSectionOrder.map(
                (key, value) => MapEntry(
                  key.toString(),
                  value is num ? value.toInt() : int.tryParse('$value') ?? 0,
                ),
              ),
            )
          : <String, int>{
              'header': 0,
              'stats': 1,
              'actions': 2,
              'team': 3,
              'ai': 4,
              'skills': 5,
              'bio': 6,
              'location': 7,
              'switcher': 8,
              'content': 9,
            },
      statsCompactMode: json['statsCompactMode'] == true,
      statsShowLabels: json['statsShowLabels'] != false,
      statsShowIcons: json['statsShowIcons'] != false,
      enableHoverEffects: json['enableHoverEffects'] == true,
      enablePulseEffects: json['enablePulseEffects'] == true,
    );
  }
  static FontWeight _parseFontWeight(String value) {
    switch (value) {
      case 'w100':
        return FontWeight.w100;
      case 'w200':
        return FontWeight.w200;
      case 'w300':
        return FontWeight.w300;
      case 'w400':
        return FontWeight.w400;
      case 'w500':
        return FontWeight.w500;
      case 'w600':
        return FontWeight.w600;
      case 'w700':
        return FontWeight.w700;
      case 'w800':
        return FontWeight.w800;
      case 'w900':
        return FontWeight.w900;
      default:
        return FontWeight.w500;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'primaryColorValue': primaryColorValue,
      'secondaryColorValue': secondaryColorValue,
      'accentColorValue': accentColorValue,
      'backgroundColorValue': backgroundColorValue,
      'surfaceColorValue': surfaceColorValue,
      'cardColorValue': cardColorValue,
      'textPrimaryColorValue': textPrimaryColorValue,
      'textSecondaryColorValue': textSecondaryColorValue,
      'textTertiaryColorValue': textTertiaryColorValue,
      'fontFamily': fontFamily,
      'titleFontSize': titleFontSize,
      'headingFontSize': headingFontSize,
      'bodyFontSize': bodyFontSize,
      'smallFontSize': smallFontSize,
      'titleWeight': _fontWeightToString(titleWeight),
      'headingWeight': _fontWeightToString(headingWeight),
      'bodyWeight': _fontWeightToString(bodyWeight),
      'avatarSize': avatarSize,
      'avatarBorderWidth': avatarBorderWidth,
      'cardRadius': cardRadius,
      'buttonRadius': buttonRadius,
      'spacing': spacing,
      'contentPadding': contentPadding,
      'avatarBorderColorValue': avatarBorderColorValue,
      'avatarGlowEnabled': avatarGlowEnabled,
      'avatarGlowRadius': avatarGlowRadius,
      'avatarGlowOpacity': avatarGlowOpacity,
      'headerGradientEnabled': headerGradientEnabled,
      'headerGradientColors': headerGradientColors,
      'headerGradientBeginX': headerGradientBeginX,
      'headerGradientBeginY': headerGradientBeginY,
      'headerGradientEndX': headerGradientEndX,
      'headerGradientEndY': headerGradientEndY,
      'cardShadowEnabled': cardShadowEnabled,
      'cardShadowBlurRadius': cardShadowBlurRadius,
      'cardShadowSpreadRadius': cardShadowSpreadRadius,
      'cardShadowOffsetX': cardShadowOffsetX,
      'cardShadowOffsetY': cardShadowOffsetY,
      'cardShadowColorValue': cardShadowColorValue,
      'cardShadowOpacity': cardShadowOpacity,
      'avatarShadowEnabled': avatarShadowEnabled,
      'avatarShadowBlurRadius': avatarShadowBlurRadius,
      'avatarShadowSpreadRadius': avatarShadowSpreadRadius,
      'avatarShadowOffsetX': avatarShadowOffsetX,
      'avatarShadowOffsetY': avatarShadowOffsetY,
      'avatarShadowColorValue': avatarShadowColorValue,
      'avatarShadowOpacity': avatarShadowOpacity,
      'blocks': blocks.map((b) => b.toJson()).toList(),
      'sectionVisibility': sectionVisibility,
      'sectionOrder': sectionOrder,
      'statsCompactMode': statsCompactMode,
      'statsShowLabels': statsShowLabels,
      'statsShowIcons': statsShowIcons,
      'enableHoverEffects': enableHoverEffects,
      'enablePulseEffects': enablePulseEffects,
    };
  }

  static String _fontWeightToString(FontWeight weight) {
    if (weight == FontWeight.w100) return 'w100';
    if (weight == FontWeight.w200) return 'w200';
    if (weight == FontWeight.w300) return 'w300';
    if (weight == FontWeight.w400) return 'w400';
    if (weight == FontWeight.w500) return 'w500';
    if (weight == FontWeight.w600) return 'w600';
    if (weight == FontWeight.w700) return 'w700';
    if (weight == FontWeight.w800) return 'w800';
    if (weight == FontWeight.w900) return 'w900';
    return 'w500';
  }

  factory ProfileDesign.defaults() {
    return ProfileDesign(
      primaryColorValue: 0xFF00A750,
      secondaryColorValue: 0xFF008C40,
      accentColorValue: 0xFF7ED321,
      backgroundColorValue: 0xFFFFFFFF,
      surfaceColorValue: 0xFFF8F9F8,
      cardColorValue: 0xFFFFFFFF,
      textPrimaryColorValue: 0xFF111827,
      textSecondaryColorValue: 0xFF667085,
      textTertiaryColorValue: 0xFF98A2B3,
      fontFamily: 'default',
      titleFontSize: 17,
      headingFontSize: 13.5,
      bodyFontSize: 12,
      smallFontSize: 10.5,
      titleWeight: FontWeight.w800,
      headingWeight: FontWeight.w700,
      bodyWeight: FontWeight.w500,
      avatarSize: 82,
      avatarBorderWidth: 1.5,
      cardRadius: 18,
      buttonRadius: 12,
      spacing: 8,
      contentPadding: 14,
      avatarBorderColorValue: 0xFFE5E7EB,
      avatarGlowEnabled: false,
      avatarGlowRadius: 20,
      avatarGlowOpacity: 0.3,
      headerGradientEnabled: false,
      headerGradientColors: [0xFF00A750, 0xFF008C40],
      headerGradientBeginX: 0,
      headerGradientBeginY: 0,
      headerGradientEndX: 1,
      headerGradientEndY: 1,
      cardShadowEnabled: false,
      cardShadowBlurRadius: 8,
      cardShadowSpreadRadius: 0,
      cardShadowOffsetX: 0,
      cardShadowOffsetY: 4,
      cardShadowColorValue: 0xFF000000,
      cardShadowOpacity: 0.035,
      avatarShadowEnabled: false,
      avatarShadowBlurRadius: 8,
      avatarShadowSpreadRadius: 0,
      avatarShadowOffsetX: 0,
      avatarShadowOffsetY: 4,
      avatarShadowColorValue: 0xFF000000,
      avatarShadowOpacity: 0.08,
      blocks: ProfileBlock.defaultBlocks(),
      sectionVisibility: {
        'posts': true,
        'reels': true,
        'feed': true,
        'skills': true,
        'team': true,
        'bio': true,
        'location': true,
        'ai': true,
        'header': true,
        'stats': true,
        'actions': true,
        'switcher': true,
        'content': true,
      },
      sectionOrder: {
        'header': 0,
        'stats': 1,
        'actions': 2,
        'team': 3,
        'ai': 4,
        'skills': 5,
        'bio': 6,
        'location': 7,
        'switcher': 8,
        'content': 9,
      },
      statsCompactMode: false,
      statsShowLabels: true,
      statsShowIcons: false,
      enableHoverEffects: false,
      enablePulseEffects: false,
    );
  }
}

class ProfileBlock {
  final String id;
  final String title;
  final String type;
  final bool enabled;
  final int order;
  final Map<String, dynamic> settings;

  ProfileBlock({
    required this.id,
    required this.title,
    required this.type,
    required this.enabled,
    required this.order,
    this.settings = const {},
  });

  factory ProfileBlock.fromJson(Map<String, dynamic> json) {
    final rawSettings = json['settings'];

    Map<String, dynamic> parsedSettings;
    if (rawSettings is Map) {
      parsedSettings = Map<String, dynamic>.from(rawSettings);
    } else {
      parsedSettings = <String, dynamic>{};
    }

    return ProfileBlock(
      id: (json['id'] ?? '').toString(),
      title: (json['title'] ?? '').toString(),
      type: (json['type'] ?? 'info').toString(),
      enabled: json['enabled'] == null ? true : json['enabled'] == true,
      order: (json['order'] is num)
          ? (json['order'] as num).toInt()
          : int.tryParse('${json['order']}') ?? 0,
      settings: parsedSettings,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'title': title,
      'type': type,
      'enabled': enabled,
      'order': order,
      'settings': settings,
    };
  }

  static List<ProfileBlock> defaultBlocks() {
    return [
      ProfileBlock(
          id: 'posts',
          title: 'Посты',
          type: 'grid',
          enabled: true,
          order: 0,
          settings: {}),
      ProfileBlock(
          id: 'reels',
          title: 'Reels',
          type: 'grid',
          enabled: true,
          order: 1,
          settings: {}),
      ProfileBlock(
          id: 'feed',
          title: 'Лента',
          type: 'grid',
          enabled: true,
          order: 2,
          settings: {}),
      ProfileBlock(
          id: 'skills',
          title: 'Скиллы',
          type: 'card',
          enabled: true,
          order: 3,
          settings: {}),
      ProfileBlock(
          id: 'team',
          title: 'Команда',
          type: 'card',
          enabled: true,
          order: 4,
          settings: {}),
      ProfileBlock(
          id: 'ai',
          title: 'Спортотека AI',
          type: 'card',
          enabled: true,
          order: 5,
          settings: {}),
      ProfileBlock(
          id: 'bio',
          title: 'О себе',
          type: 'text',
          enabled: true,
          order: 6,
          settings: {}),
      ProfileBlock(
          id: 'location',
          title: 'Локация',
          type: 'text',
          enabled: true,
          order: 7,
          settings: {}),
    ];
  }

  ProfileBlock copyWith({
    String? id,
    String? title,
    String? type,
    bool? enabled,
    int? order,
    Map<String, dynamic>? settings,
  }) {
    return ProfileBlock(
      id: id ?? this.id,
      title: title ?? this.title,
      type: type ?? this.type,
      enabled: enabled ?? this.enabled,
      order: order ?? this.order,
      settings: settings ?? this.settings,
    );
  }
}

enum _ProfileFeedMode { posts, reels, feed }

class MyProfileScreen extends StatefulWidget {
  final int? userId;

  /// true = экран открывается как публичная витрина другого пользователя:
  /// без личного кабинета, рабочих зон, настроек и текста «Вы вошли как ...».
  final bool publicView;

  const MyProfileScreen({Key? key, this.userId, this.publicView = false})
      : super(key: key);

  @override
  State<MyProfileScreen> createState() => _MyProfileScreenState();
}

class _MyProfileScreenState extends State<MyProfileScreen>
    with TickerProviderStateMixin {
  // =============================
  // СТАРЫЕ КОНСТАНТЫ (ОСТАВЛЯЕМ)
  // =============================
  static const String _apiBase = 'https://sportotekaapp.ru/api';
  static const String _uploadsBase = 'https://sportotekaapp.ru/uploads';
  static const String _getOrCreatePrivateChatUrl =
      '$_apiBase/get_or_create_private_chat.php';
  static const String _deletePostUrl = '$_apiBase/delete_post.php';
  static const String _deleteReelUrl = '$_apiBase/delete_reel.php';
  static const String _deleteAccountUrl = '$_apiBase/delete_account.php';
  static const String _saveDesignUrl = '$_apiBase/save_profile_design.php';
  static const String _loadDesignUrl = '$_apiBase/get_profile_design.php';

  // =============================
  // НОВЫЕ ПЕРЕМЕННЫЕ ДИЗАЙНА
  // =============================
  ProfileDesign design = ProfileDesign.defaults();
  bool designLoading = false;
  bool designSaving = false;
  late AnimationController _pulseController;
  final Map<String, AnimationController> _hoverControllers = {};

  // =============================
  // СТАРЫЕ ПЕРЕМЕННЫЕ (ВСЕ ОСТАВЛЯЕМ)
  // =============================
  String firstName = "";
  String lastName = "";
  String email = "";
  String role = "";
  Map<String, dynamic>? _pressAssistantAssignment;
  String? photo;
  String? bio;
  String? location;
  int? age;
  String? birthDateRaw;
  String? playerTeamName;
  String? playerClubName;
  String? playerTeamLogoUrl;
  int? playerTeamId;
  List<dynamic> userPosts = [];
  bool isLoadingPosts = false;
  List<Map<String, dynamic>> userReels = [];
  bool isLoadingReels = false;
  List<Map<String, dynamic>> feedPosts = [];
  bool isLoadingFeed = false;
  bool isLoadingProfile = true;
  _ProfileFeedMode _mode = _ProfileFeedMode.posts;

  // Активный раздел адаптивного Profile Workspace. На планшете и ПК
  // содержимое меняется справа без перехода на новый экран.
  String _profileWorkspaceSection = 'posts';

  // Подключим к API важных уведомлений на следующем этапе.
  // Пока 0 = без badge, но сам фирменный знак уже работает.
  int _importantNotificationCount = 0;
  int _chatUnreadCount = 0;
  Timer? _badgePollingTimer;
  ClubAccessGuard? _clubAccessGuard;

  // Мобильные окна поверх профиля. Так нижний Instagram-dock не исчезает
  // при открытии ленты, Reels, чата, сервисов и рабочей зоны.
  Widget? _mobileWindowChild;
  String _mobileWindowTitle = '';
  IconData _mobileWindowIcon = Icons.apps_rounded;
  String _mobileDockKey = 'profile';

  // Детали публикации профиля: на планшете открываются в правой CMR-панели.
  Map<String, dynamic>? _openedProfilePost;

  // Правая рабочая область главной страницы на ПК.
  Widget? _desktopRightPaneChild;
  String _desktopRightPaneTitle = '';
  IconData _desktopRightPaneIcon = Icons.newspaper_rounded;

  // Геометрия окон ПК — та же модель, что и в Club Workspace.
  Offset? _profileMainWindowPosition;
  Size? _profileMainWindowSize;
  bool _profileMainWindowMaximized = false;
  bool _profileMainWindowMinimized = false;

  Offset? _profileModuleWindowPosition;
  Size? _profileModuleWindowSize;
  bool _profileModuleWindowMaximized = false;
  bool _profileModuleWindowMinimized = false;
  int _profileWindowZCounter = 1;
  int _profileMainWindowZ = 1;
  int _profileModuleWindowZ = 2;

  File? _newPostImage;
  final TextEditingController _newPostText = TextEditingController();
  bool _posting = false;
  bool _uploadingProfilePhoto = false;
  bool isFollowing = false;
  bool isOwnProfile = true;
  int followersCount = 0;
  int followingsCount = 0;
  List<_UserShort> _followers = [];
  List<_UserShort> _followings = [];
  bool _loadingFollowers = false;
  bool _loadingFollowings = false;

  // Социальные списки: состояние подписки текущего пользователя
  // на людей из списков "Подписчики / Подписки".
  final Map<int, bool> _socialFollowingState = <int, bool>{};
  final Set<int> _socialFollowingLoaded = <int>{};
  final Set<int> _socialFollowingBusy = <int>{};
  static const bool _enableSportotekaAi = false;
  final Random _rnd = Random();
  int _aiCardSeed = 1;
  bool _aiExpanded = false;
  bool _skillsExpanded = false;

  // ========== ВАЖНО: ГЕТТЕР ISPLAYER ==========
  bool get isPlayer {
    final r = role.trim().toLowerCase();
    return r == 'player' ||
        r == 'игрок' ||
        r.contains('player') ||
        r.contains('игрок');
  }

  bool get isClubRole {
    final r = role.trim().toLowerCase();
    return r == 'club' || r == 'клуб' || r.contains('club');
  }

  bool get hasPressAssistantAccess {
    final r = role.trim().toLowerCase();
    if (r == 'press_assistant' ||
        r == 'press' ||
        r == 'press_service' ||
        r.contains('press_assistant') ||
        r.contains('пресс')) {
      return true;
    }

    final assignment = _pressAssistantAssignment;
    if (assignment == null) return false;
    final profile =
        '${assignment['profile'] ?? assignment['link_profile'] ?? assignment['staff_role'] ?? ''}'
            .trim()
            .toLowerCase();
    return profile.contains('press') || profile.contains('пресс');
  }

  // Отдельный пресс-доступ не должен отнимать основную должность.
  // Тренер/медик/ассистент сохраняет свой обычный Workspace и получает
  // «Пресс-службу» дополнительным модулем. Только пользователь без другой
  // рабочей роли открывает пресс-кабинет как основной.
  bool get isPressAssistantRole {
    if (!hasPressAssistantAccess) return false;

    final r = role.trim().toLowerCase();
    final hasOtherPrimaryRole =
        r == 'coach' ||
        r == 'trainer' ||
        r == 'тренер' ||
        r.contains('coach') ||
        r.contains('trainer') ||
        r == 'club' ||
        r == 'клуб' ||
        r.contains('club') ||
        r == 'player' ||
        r == 'игрок' ||
        r.contains('player') ||
        r.contains('игрок') ||
        r == 'parent' ||
        r == 'родитель' ||
        r == 'guardian' ||
        r.contains('parent') ||
        r.contains('родител') ||
        r.contains('guardian');

    return !hasOtherPrimaryRole;
  }

  bool get isCoachRole {
    final r = role.trim().toLowerCase();
    return r == 'coach' ||
        r == 'trainer' ||
        r == 'тренер' ||
        r.contains('coach') ||
        r.contains('trainer');
  }

  bool get isParentRole {
    final r = role.trim().toLowerCase();
    return r == 'parent' ||
        r == 'родитель' ||
        r == 'guardian' ||
        r.contains('parent') ||
        r.contains('родител') ||
        r.contains('guardian');
  }

  bool get _isPublicProfileView =>
      !isOwnProfile && (widget.publicView || widget.userId != null);

  String get _publicProfileTitle {
    if (isPlayer) return 'Публичный профиль игрока';
    if (isCoachRole) return 'Публичный профиль тренера';
    if (isClubRole) return 'Публичная страница клуба';
    if (isParentRole) return 'Профиль родителя';
    return 'Публичный профиль';
  }

  String get _publicProfileSubtitle {
    final parts = <String>[];
    final team = (playerTeamName ?? '').trim();
    final club = (playerClubName ?? '').trim();
    if (club.isNotEmpty) parts.add(club);
    if (team.isNotEmpty) parts.add(team);
    parts.add('фото и публикации');
    return parts.join(' • ');
  }

  String get _profileContextLine {
    if (_isPublicProfileView) return _publicProfileSubtitle;
    return '${_enteredAsText} • ${_activeWorkspaceName.isEmpty ? 'Sportoteka' : _activeWorkspaceName}';
  }

  String get _roleLabel {
    if (isPressAssistantRole) return 'пресс-служба';
    if (isClubRole) return 'клуб';
    if (isCoachRole) return 'тренер';
    if (isPlayer) return 'игрок';
    if (isParentRole) return 'родитель';
    final r = role.trim();
    return r.isEmpty ? 'пользователь' : r;
  }

  String get _enteredAsText {
    if (_isPublicProfileView) return _publicProfileTitle;
    final team = (playerTeamName ?? '').trim();
    final club = (playerClubName ?? '').trim();
    if (isPressAssistantRole) return 'Вы вошли как пресс-служба';
    if (isClubRole) return 'Вы вошли как клуб';
    if (isCoachRole)
      return team.isNotEmpty
          ? 'Вы вошли как тренер команды'
          : 'Вы вошли как тренер';
    if (isPlayer)
      return team.isNotEmpty
          ? 'Вы вошли как игрок команды'
          : 'Вы вошли как игрок';
    if (isParentRole) return 'Вы вошли как родитель';
    return 'Вы вошли как $_roleLabel';
  }

  String get _activeWorkspaceName {
    final team = (playerTeamName ?? '').trim();
    final club = (playerClubName ?? '').trim();
    if (isClubRole && fullName.trim().isNotEmpty) return fullName;
    if (club.isNotEmpty && team.isNotEmpty) return '$club • $team';
    if (club.isNotEmpty) return club;
    if (team.isNotEmpty) return team;
    return fullName;
  }

  String get _primaryZoneTitle {
    if (isPressAssistantRole) return 'Пресс-служба';
    if (isPlayer) return 'Мой кабинет';
    if (isCoachRole) return 'Кабинет тренера';
    if (isClubRole) return 'Кабинет клуба';
    if (isParentRole) return 'Мои дети';
    return 'Мой кабинет';
  }

  String get _primaryZoneSubtitle {
    if (isPressAssistantRole) return 'создание и редактирование новостей команды';
    if (isPlayer) return 'личный прогресс, тренировки и матчи';
    if (isCoachRole) return 'команда, состав, календарь и матчи';
    if (isClubRole) return 'команды, тренеры, состав и аналитика';
    if (isParentRole)
      return 'дневник, посещаемость, тестирование и успехи ребёнка';
    return 'профиль, лента, чат и сервисы';
  }

  IconData get _primaryZoneIcon {
    if (isPressAssistantRole) return Icons.campaign_outlined;
    if (isPlayer) return Icons.dashboard_customize_outlined;
    if (isCoachRole) return Icons.sports_soccer_outlined;
    if (isClubRole) return Icons.apartment_outlined;
    if (isParentRole) return Icons.family_restroom_outlined;
    return Icons.person_outline_rounded;
  }

  bool get _isDesktopOperatingSystem {
    return defaultTargetPlatform == TargetPlatform.macOS ||
        defaultTargetPlatform == TargetPlatform.windows ||
        defaultTargetPlatform == TargetPlatform.linux;
  }

  bool get _isDesktopProfileLayout {
    final width = MediaQuery.maybeOf(context)?.size.width ?? 0;
    // Оконный рабочий стол включаем только в приложении для ПК.
    // Большой iPad/Android-планшет может быть шире 1180 логических пикселей,
    // но всё равно должен оставаться в полноэкранной планшетной оболочке.
    return _isDesktopOperatingSystem && width >= 1180;
  }

  String _dockKeyForWindow(String title) {
    final value = title.trim().toLowerCase();

    if (value.contains('лента') ||
        value.contains('feed') ||
        value.contains('новост')) {
      return 'feed';
    }
    if (value.contains('видеоурок') || value.contains('обучен')) {
      return 'lessons';
    }
    if (value.contains('reels') ||
        value.contains('рилс') ||
        value.contains('эфир')) {
      return 'reels';
    }
    if (value.contains('чат') || value.contains('сообщ')) {
      return 'chat';
    }
    if (value.contains('поиск')) {
      return 'search';
    }
    if (value.contains('площад')) {
      return 'venues';
    }
    if (value.contains('трек') ||
        value.contains('трениров') ||
        value.contains('tracking')) {
      return 'tracker';
    }
    if (value.contains('профил') ||
        value.contains('главная') ||
        value.contains('обзор')) {
      return 'profile';
    }

    // Все остальные рабочие разделы открываются из пункта «Ещё».
    return 'more';
  }

  void _openCmrWindow({
    required String title,
    required IconData icon,
    required Widget child,
    double maxWidth = 1180,
    double maxHeight = 780,
  }) {
    if (!mounted) return;

    if (_isDesktopProfileLayout) {
      setState(() {
        // Только ПК: модуль открывается отдельным плавающим окном.
        _desktopRightPaneTitle = title;
        _desktopRightPaneIcon = icon;
        _desktopRightPaneChild = child;
        _profileModuleWindowMinimized = false;
        _profileModuleWindowZ = ++_profileWindowZCounter;
        _mobileWindowChild = null;
        _mobileWindowTitle = '';
        _openedProfilePost = null;
        _mobileDockKey = _dockKeyForWindow(title);
      });
      return;
    }

    final width = MediaQuery.sizeOf(context).width;
    if (width >= 720) {
      setState(() {
        // Любой планшет, в том числе широкий, открывает модуль на всю
        // доступную рабочую область без рамки плавающего окна ПК.
        _profileWorkspaceSection = 'embedded';
        _desktopRightPaneTitle = title;
        _desktopRightPaneIcon = icon;
        _desktopRightPaneChild = child;
        _openedProfilePost = null;
        _mobileWindowChild = null;
        _mobileWindowTitle = '';
        _mobileWindowIcon = Icons.apps_rounded;
        _mobileDockKey = _dockKeyForWindow(title);
      });
      return;
    }

    setState(() {
      _mobileWindowTitle = title;
      _mobileWindowIcon = icon;
      _mobileWindowChild = child;
      _mobileDockKey = _dockKeyForWindow(title);
    });
  }

  void _closeMobileWindow({String dockKey = 'profile'}) {
    if (!mounted) return;
    setState(() {
      _mobileWindowChild = null;
      _mobileWindowTitle = '';
      _mobileWindowIcon = Icons.apps_rounded;
      _mobileDockKey = dockKey;
    });
  }

  Widget _buildCmrWindowTitleBar({
    required String title,
    required IconData icon,
    required VoidCallback onClose,
    VoidCallback? onMinimize,
    VoidCallback? onMaximize,
    String? subtitle,
    bool maximized = false,
  }) {
    return Container(
      height: 54,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0x00FFFFFF), width: 0)),
      ),
      child: Row(
        children: [
          Row(
            children: [
              _buildWorkspaceWindowDot(
                icon: Icons.close_rounded,
                color: const Color(0xFFE9ECEF),
                iconColor: const Color(0xFF6B7280),
                onTap: onClose,
                tooltip: 'Закрыть',
              ),
              const SizedBox(width: 7),
              _buildWorkspaceWindowDot(
                icon: Icons.remove_rounded,
                color: const Color(0xFFF1F3F5),
                iconColor: const Color(0xFF6B7280),
                onTap: onMinimize ?? onClose,
                tooltip: 'Свернуть',
              ),
              const SizedBox(width: 7),
              _buildWorkspaceWindowDot(
                icon: maximized
                    ? Icons.fullscreen_exit_rounded
                    : Icons.open_in_full_rounded,
                color: const Color(0xFFF1F3F5),
                iconColor: const Color(0xFF667085),
                onTap: onMaximize ?? () {},
                tooltip: maximized ? 'Вернуть размер' : 'Развернуть',
              ),
            ],
          ),
          const SizedBox(width: 14),
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: const Color(0xFFF4F6F8),
              borderRadius: BorderRadius.circular(11),
              border: Border.all(color: const Color(0xFFE9EEF3)),
            ),
            child: Icon(icon, color: const Color(0xFF344054), size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF111827),
                    fontSize: 13.5,
                    height: 1,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  (subtitle ?? _activeWorkspaceName).trim().isEmpty
                      ? 'Sportoteka Workspace'
                      : (subtitle ?? _activeWorkspaceName).trim(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Color(0xFF667085),
                    fontSize: 11.5,
                    height: 1,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWorkspaceWindowDot({
    required IconData icon,
    required Color color,
    required Color iconColor,
    required VoidCallback onTap,
    required String tooltip,
  }) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 17,
          height: 17,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: color,
            border: Border.all(color: const Color(0xFFE9EEF3)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.035),
                blurRadius: 6,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Icon(icon, color: iconColor, size: 10),
        ),
      ),
    );
  }

  Widget _buildMacDot(Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(99),
      child: Container(
          width: 11,
          height: 11,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
    );
  }

  Future<void> _openPrimaryArea() async {
    if (_isPublicProfileView) {
      if (mounted) {
        setState(() => _mode = _ProfileFeedMode.posts);
      }
      return;
    }

    if (isPressAssistantRole) {
      await _openPressAssistantArea();
      return;
    }

    if (isParentRole) {
      _openCmrWindow(
        title: 'Мои дети',
        icon: Icons.family_restroom_rounded,
        maxWidth: 1240,
        maxHeight: 840,
        child: const ParentFamilyScreen(),
      );
      return;
    }

    if (isPlayer) {
      final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
      if (!mounted) return;
      _openCmrWindow(
        title: 'Мой Dashboard',
        icon: Icons.space_dashboard_rounded,
        maxWidth: 1220,
        maxHeight: 820,
        child: PlayerDashboardScreen(
          teamId: playerTeamId ?? 0,
          teamName: (playerTeamName ?? '').trim().isNotEmpty
              ? (playerTeamName ?? '').trim()
              : 'Мой Dashboard',
          userId: myId,
          teamLogo: playerTeamLogoUrl,
        ),
      );
      return;
    }

    _openProPanel();
  }

  Future<void> _openPressAssistantArea() async {
    final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (!mounted || myId <= 0) return;

    final assignment = _pressAssistantAssignment ?? const <String, dynamic>{};
    int asInt(dynamic value) =>
        value is num ? value.toInt() : int.tryParse('${value ?? ''}') ?? 0;
    String clean(dynamic value) {
      final text = '${value ?? ''}'.trim();
      return text.toLowerCase() == 'null' ? '' : text;
    }

    _openCmrWindow(
      title: 'Пресс-служба',
      icon: Icons.campaign_outlined,
      maxWidth: 1240,
      maxHeight: 840,
      child: CmrPressAssistantScreen(
        userId: myId,
        clubId: asInt(assignment['club_id'] ?? assignment['clubId']),
        teamId: asInt(assignment['team_id'] ?? assignment['teamId']),
        clubName: clean(assignment['club_name'] ?? assignment['clubName']),
        teamName: clean(assignment['team_name'] ?? assignment['teamName']),
        sportName: clean(assignment['sport']).isEmpty
            ? 'Футбол'
            : clean(assignment['sport']),
        embedded: true,
      ),
    );
  }

  void _goToWorkspaceHub() {
    if (!mounted) return;

    // Возвращаемся именно на экран выбора доступного рабочего пространства,
    // не открывая напрямую кабинет клуба/тренера из личного профиля.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Get.offAllNamed(AppRoutes.workspaceHubScreen);
    });
  }

  Future<void> _openMainChat() async {
    final myId = await PrefUtils.getUserId() ?? 0;
    if (!mounted || myId <= 0) return;

    if (_isDesktopProfileLayout) {
      _openCmrWindow(
        title: 'Чаты',
        icon: Icons.forum_rounded,
        maxWidth: 1180,
        maxHeight: 800,
        child: ChatScreen(
          userId: myId,
          onUnreadChanged: (value) {
            if (!mounted) return;
            setState(() => _chatUnreadCount = value);
          },
        ),
      );
      return;
    }

    _openCmrWindow(
      title: 'Чаты',
      icon: Icons.forum_rounded,
      maxWidth: 1180,
      maxHeight: 800,
      child: ChatScreen(
        userId: myId,
        onUnreadChanged: (value) {
          if (!mounted) return;
          setState(() => _chatUnreadCount = value);
        },
      ),
    );
    if (mounted) setState(() => _mobileDockKey = 'chat');
  }

  Future<void> _openProPanel() async {
    if (isPressAssistantRole) {
      await _openPressAssistantArea();
      return;
    }

    // Панель клуба/тренера — это отдельный рабочий стол Workspace.
    // Важно открывать через Get.to с arguments: ClubWorkspaceScreen читает
    // Get.arguments и так получает режим, club_id/trainer_id и нужную команду.
    final currentUserId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (!mounted) return;

    final args = <String, dynamic>{
      'mode': isCoachRole ? 'trainer_workspace' : 'club_workspace',
      if (isClubRole && currentUserId > 0) 'club_id': currentUserId,
      if (isCoachRole && currentUserId > 0) 'trainer_id': currentUserId,
      if ((playerTeamId ?? 0) > 0) 'initial_team_id': playerTeamId,
    };

    Get.to<void>(
      () => const ClubWorkspaceScreen(),
      arguments: args,
    );
  }

  void _openAllReels() => _openGlobalReels();

  void _openGrounds() {
    _openVenuesWindow();
  }

  void _openHomeMode(int modeIndex) {
    switch (modeIndex.clamp(0, 3).toInt()) {
      case 0:
        _openTeamsWindow();
        break;
      case 1:
        _openCommunityFeedHome();
        break;
      case 2:
        _openServicesWindow();
        break;
      case 3:
        _openTipsWindow();
        break;
    }
  }

  void _openHomeFunctions() => _openTeamsWindow();
  void _openCommunityFeedHome() {
    if (!mounted) return;

    final communityFeed = const SportCommunityScreen(
      sportName: 'Футбол',
      embedded: true,
    );

    // ПК: отдельное плавающее окно.
    if (_isDesktopProfileLayout) {
      setState(() {
        _desktopRightPaneTitle = 'Соцлента и новости';
        _desktopRightPaneIcon = Icons.newspaper_rounded;
        _desktopRightPaneChild = communityFeed;
        _openedProfilePost = null;
        _mobileDockKey = 'feed';
      });
      return;
    }

    // Планшет любой ширины: полноэкранный модуль в рабочей области.
    if (MediaQuery.sizeOf(context).width >= 720) {
      setState(() {
        _profileWorkspaceSection = 'embedded';
        _desktopRightPaneTitle = 'Соцлента и новости';
        _desktopRightPaneIcon = Icons.newspaper_rounded;
        _desktopRightPaneChild = communityFeed;
        _openedProfilePost = null;
        _mobileWindowChild = null;
        _mobileDockKey = 'feed';
      });
      return;
    }

    // Телефон: открываем внутри личной оболочки, чтобы нижнее меню не исчезало.
    _openCmrWindow(
      title: 'Соцлента и новости',
      icon: Icons.dynamic_feed_rounded,
      maxWidth: 720,
      maxHeight: 820,
      child: const SportCommunityScreen(
        sportName: 'Футбол',
        embedded: true,
      ),
    );
    if (mounted) setState(() => _mobileDockKey = 'feed');
  }

  void _openHomeServices() => _openServicesWindow();
  void _openHomeTips() => _openTipsWindow();

  void _openGlobalReels() {
    _openCmrWindow(
      title: 'Reels сообщества',
      icon: Icons.play_circle_fill_rounded,
      maxWidth: 720,
      maxHeight: 820,
      child: const ReelsScreen(),
    );
  }

  Future<void> _openPeopleSearchWindow() async {
    final myUserId = await PrefUtils.getUserId() ?? 0;
    if (!mounted) return;
    _openCmrWindow(
      title: 'Поиск людей',
      icon: Icons.search_rounded,
      maxWidth: 860,
      maxHeight: 800,
      child: _ProfilePeopleSearchPanel(
        apiBase: _apiBase,
        myUserId: myUserId,
        onOpenUser: (userId) {
          if (!mounted || userId <= 0) return;
          Navigator.of(context).push<void>(
            MaterialPageRoute<void>(
              builder: (_) => MyProfileScreen(
                userId: userId,
                publicView: true,
              ),
            ),
          );
        },
      ),
    );
  }

  // Старое имя оставляем как alias, чтобы внешние вызовы/старые участки файла
  // не сломались после перехода на полноценный поиск пользователей.
  void _openMobileSearchWindow() {
    _openPeopleSearchWindow();
  }

  void _openComingSoonSection({
    required String title,
    required String description,
    required IconData icon,
    required List<String> features,
  }) {
    _openCmrWindow(
      title: title,
      icon: icon,
      maxWidth: 760,
      maxHeight: 720,
      child: _ProfileComingSoonPanel(
        title: title,
        description: description,
        icon: icon,
        features: features,
      ),
    );
  }

  void _openNearbyGamesWindow() {
    _openComingSoonSection(
      title: 'Игры рядом',
      description:
          'Раздел дополняется. Здесь появится поиск открытых игр, спаррингов и команд, которым нужны игроки.',
      icon: Icons.sports_soccer_rounded,
      features: const [
        'Открытые игры и спарринги рядом',
        'Поиск игроков на матч или тренировку',
        'Создание своей игры и набор участников',
        'Переход в чат с организатором',
      ],
    );
  }

  void _openNearbyTrainingsWindow() {
    _openComingSoonSection(
      title: 'Тренировки рядом',
      description:
          'Раздел дополняется. В нём тренеры и клубы смогут публиковать открытые индивидуальные и групповые тренировки.',
      icon: Icons.directions_run_rounded,
      features: const [
        'Индивидуальные тренировки',
        'Групповые занятия',
        'Фильтры по тренеру, возрасту и локации',
        'Запись и сообщение тренеру',
      ],
    );
  }

  void _openSavedWindow() {
    _openComingSoonSection(
      title: 'Сохранённое',
      description:
          'Раздел дополняется. Здесь будут собраны материалы, которые пользователь сохранил для быстрого доступа.',
      icon: Icons.bookmark_border_rounded,
      features: const [
        'Видеоуроки',
        'Публикации и Reels',
        'Тренеры и пользователи',
        'Площадки',
      ],
    );
  }

  void _openTeamsWindow() {
    _openCmrWindow(
      title: 'Команды / CMR',
      icon: Icons.groups_rounded,
      maxWidth: 1180,
      maxHeight: 800,
      child: TeamListScreen(
        initialSport: 'Футбол',
        embedded: true,
        onClose: () => Navigator.of(context).maybePop(),
      ),
    );
  }

  void _openScheduleWindow() {
    _openCmrWindow(
      title: 'Расписание',
      icon: Icons.calendar_month_rounded,
      maxWidth: 1120,
      maxHeight: 780,
      child: GenericServiceScreen(title: 'Расписание', sport: 'Футбол'),
    );
  }

  void _openEventsWindow() {
    _openCmrWindow(
      title: 'Мероприятия',
      icon: Icons.event_rounded,
      maxWidth: 1120,
      maxHeight: 800,
      child: EventsListScreen(
        initialSport: 'Футбол',
        embedded: true,
        onClose: () => Navigator.of(context).maybePop(),
      ),
    );
  }

  void _openVideoLessonsWindow() {
    _openCmrWindow(
      title: 'Видеоуроки',
      icon: Icons.school_rounded,
      maxWidth: 1120,
      maxHeight: 800,
      child: const VideoLessonsHubScreen(),
    );
  }

  void _openTipsWindow() {
    _openCmrWindow(
      title: 'Советы',
      icon: Icons.tips_and_updates_rounded,
      maxWidth: 980,
      maxHeight: 760,
      child: GenericServiceScreen(title: 'Советы', sport: 'Футбол'),
    );
  }

  void _openServicesWindow() {
    _openCmrWindow(
      title: 'Сервисы',
      icon: Icons.apps_rounded,
      maxWidth: 980,
      maxHeight: 760,
      child: GenericServiceScreen(title: 'Сервисы', sport: 'Футбол'),
    );
  }

  void _openTrackingWindow() {
    _openCmrWindow(
      title: 'Трекинг',
      icon: Icons.monitor_heart_rounded,
      maxWidth: 1240,
      maxHeight: 820,
      child: const TrackingModeScreen(),
    );
  }

  Future<void> _openPersonalTrainingsQuick() async {
    final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (!mounted || myId <= 0) return;

    _openCmrWindow(
      title: 'Личные тренировки',
      icon: Icons.directions_run_rounded,
      maxWidth: 1240,
      maxHeight: 840,
      child: PlayerMyTrainingsScreen(
        teamId: playerTeamId ?? 0,
        teamName: (playerTeamName ?? '').trim().isNotEmpty
            ? (playerTeamName ?? '').trim()
            : 'Личные тренировки',
        userId: myId,
      ),
    );
  }

  Future<void> _openTrainingQuickMenu() async {
    if (!mounted || _isPublicProfileView) return;

    final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (!mounted || myId <= 0) return;

    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (sheetContext) {
        Widget quickItem({
          required IconData icon,
          required String title,
          required String subtitle,
          required VoidCallback onTap,
          bool primary = false,
        }) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Material(
              color:
                  primary ? const Color(0xFFF1FBF6) : const Color(0xFFF7F8F7),
              borderRadius: BorderRadius.circular(16),
              child: InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: () {
                  Navigator.of(sheetContext).pop();
                  Future<void>.delayed(const Duration(milliseconds: 80), () {
                    if (mounted) onTap();
                  });
                },
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(12, 11, 10, 11),
                  child: Row(
                    children: [
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color:
                              primary ? const Color(0xFF00A750) : Colors.white,
                          borderRadius: BorderRadius.circular(13),
                        ),
                        child: Icon(
                          icon,
                          size: 21,
                          color:
                              primary ? Colors.white : const Color(0xFF344054),
                        ),
                      ),
                      const SizedBox(width: 11),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              title,
                              style: _flagshipText(12.2,
                                  color: const Color(0xFF111827),
                                  weight: FontWeight.w700),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              subtitle,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: _flagshipText(10.2,
                                  color: const Color(0xFF667085),
                                  weight: FontWeight.w500),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      const Icon(Icons.chevron_right_rounded,
                          color: Color(0xFF98A2B3), size: 21),
                    ],
                  ),
                ),
              ),
            ),
          );
        }

        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE5E7EB),
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF1FBF6),
                        borderRadius: BorderRadius.circular(11),
                      ),
                      child: const Icon(Icons.sensors_rounded,
                          color: Color(0xFF00A750), size: 20),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Трекер и тренировки',
                              style: _flagshipTitle(15.2,
                                  weight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          Text('Быстрый переход без входа в кабинет',
                              style: _flagshipText(10.4,
                                  color: const Color(0xFF667085))),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: () => Navigator.of(sheetContext).pop(),
                      icon: const Icon(Icons.close_rounded, size: 20),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                if (isPlayer)
                  quickItem(
                    icon: Icons.directions_run_rounded,
                    title: 'Личные тренировки',
                    subtitle:
                        'тренировка, аналитика, календарь и сравнение с предыдущей',
                    primary: true,
                    onTap: () {
                      _openPersonalTrainingsQuick();
                    },
                  ),
                if (isCoachRole || isClubRole)
                  quickItem(
                    icon: Icons.groups_2_rounded,
                    title: 'Командный трекер',
                    subtitle: 'Live, устройства, сессии и аналитика команды',
                    primary: true,
                    onTap: _openTrackingWindow,
                  ),
                if (!isCoachRole && !isClubRole && !isParentRole)
                  quickItem(
                    icon: Icons.bluetooth_searching_rounded,
                    title: 'Подключение трекера',
                    subtitle: 'GPS / BLE / Polar и режим трекинга',
                    onTap: _openTrackingWindow,
                  ),
                if (isCoachRole || isClubRole)
                  quickItem(
                    icon: _primaryZoneIcon,
                    title: _primaryZoneTitle,
                    subtitle: 'открыть полный рабочий кабинет',
                    onTap: () {
                      _openPrimaryArea();
                    },
                  ),
                if (isParentRole)
                  quickItem(
                    icon: Icons.family_restroom_rounded,
                    title: 'Мои дети',
                    subtitle: 'дневник, посещаемость, тестирование и успехи',
                    primary: true,
                    onTap: () {
                      _openPrimaryArea();
                    },
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _openVenuesWindow() async {
    final userId = await PrefUtils.getUserId();
    if (!mounted || userId == null) return;
    _openCmrWindow(
      title: 'Площадки',
      icon: Icons.stadium_rounded,
      maxWidth: 1120,
      maxHeight: 800,
      child: Column(
        children: [
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(12, 12, 12, 0),
            padding: const EdgeInsets.fromLTRB(13, 11, 13, 11),
            decoration: BoxDecoration(
              color: const Color(0xFFF3FAF6),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: const Icon(
                    Icons.auto_awesome_rounded,
                    size: 18,
                    color: Color(0xFF067A46),
                  ),
                ),
                const SizedBox(width: 10),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Раздел дополняется',
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF111827),
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Каталог площадок уже доступен. Далее добавим свободные слоты, онлайн-бронирование, оплату и открытые тренировки.',
                        style: TextStyle(
                          fontSize: 10.5,
                          height: 1.35,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF667085),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(child: BookingScreen(userId: userId)),
        ],
      ),
    );
  }

  void _openTicketsWindow() {
    _openCmrWindow(
      title: 'Билеты',
      icon: Icons.confirmation_number_rounded,
      maxWidth: 980,
      maxHeight: 760,
      child: GenericServiceScreen(title: 'Билеты', sport: 'Футбол'),
    );
  }

  void _openSubscriptionWindow() {
    _openCmrWindow(
      title: 'PRO подписка',
      icon: Icons.workspace_premium_rounded,
      maxWidth: 980,
      maxHeight: 760,
      child: const SubscriptionScreen(),
    );
  }

  void _openGlobalHomeSection(String title, int modeIndex) {
    _openHomeMode(modeIndex);
  }

  void _switchToFeed() {
    setState(() => _mode = _ProfileFeedMode.feed);
  }

  void _startBadgePolling() {
    _badgePollingTimer?.cancel();
    unawaited(_refreshBadgeCounts());
    _badgePollingTimer = Timer.periodic(
      const Duration(seconds: 6),
      (_) => unawaited(_refreshBadgeCounts()),
    );
  }

  int _sumChatUnreadFromList(dynamic raw) {
    if (raw is! List) return 0;
    var total = 0;
    for (final entry in raw.whereType<Map>()) {
      final count = int.tryParse('${entry['unread_count'] ?? 0}') ?? 0;
      if (count > 0) total += count;
    }
    return total;
  }

  bool _profileChatIsPrivate(Map<dynamic, dynamic> chat) {
    final type =
        '${chat['type'] ?? chat['chat_type'] ?? ''}'.trim().toLowerCase();
    if (type == 'private' || type == 'personal' || type == 'direct') {
      return true;
    }

    final flag = chat['is_private'];
    return flag == 1 || flag == '1' || flag == true;
  }

  bool _profileGroupIsMember(Map<dynamic, dynamic> group) {
    final flag = group['i_am_member'];
    return flag == null || flag == 1 || flag == '1' || flag == true;
  }

  Future<int> _loadRealChatUnread(int userId) async {
    var total = 0;

    try {
      final response = await http
          .get(Uri.parse('$_apiBase/get_user_chats.php?user_id=$userId'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is List) {
          final privateRows =
              decoded.whereType<Map>().where(_profileChatIsPrivate).toList();
          total += _sumChatUnreadFromList(privateRows);
        }
      }
    } catch (_) {}

    try {
      final response = await http
          .get(Uri.parse('$_apiBase/get_groups_feed.php?user_id=$userId'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final decoded = jsonDecode(response.body);
        if (decoded is Map && decoded['success'] == true) {
          final raw = decoded['groups'];
          if (raw is List) {
            final memberRows =
                raw.whereType<Map>().where(_profileGroupIsMember).toList();
            total += _sumChatUnreadFromList(memberRows);
          }
        }
      }
    } catch (_) {}

    return total.clamp(0, 9999);
  }

  Future<void> _refreshBadgeCounts() async {
    final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (myId <= 0) {
      if (mounted &&
          (_chatUnreadCount != 0 || _importantNotificationCount != 0)) {
        setState(() {
          _chatUnreadCount = 0;
          _importantNotificationCount = 0;
        });
      }
      return;
    }

    int chatUnread = 0;
    int importantUnread = 0;

    // Источник истины для badge — unread_count в самих списках чатов.
    // Старый get_unread_total.php мог возвращать устаревшее число.
    chatUnread = await _loadRealChatUnread(myId);

    try {
      final response = await http
          .get(Uri.parse(
              '$_apiBase/notifications/unread_count.php?user_id=$myId'))
          .timeout(const Duration(seconds: 8));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is Map && data['success'] == true) {
          importantUnread = int.tryParse('${data['unread_count'] ?? 0}') ?? 0;
        }
      }
    } catch (_) {
      importantUnread = 0;
    }

    if (!mounted) return;

    chatUnread = chatUnread.clamp(0, 9999);
    importantUnread = importantUnread.clamp(0, 9999);

    if (chatUnread == _chatUnreadCount &&
        importantUnread == _importantNotificationCount) {
      return;
    }

    setState(() {
      _chatUnreadCount = chatUnread;
      _importantNotificationCount = importantUnread;
    });
  }


  // =============================
  // CLUB ACCESS GUARD
  // =============================
  //
  // Для club-аккаунта регулярно проверяем серверный status.php.
  // Если администратор нажал
  // «Сбросить доступ и выдать новый ключ»,
  // сервер вернёт requires_activation=true.
  //
  // Legacy-клубы сервер помечает legacy=true, поэтому они
  // никогда не будут выброшены этим guard.
  Future<void> _startClubAccessGuard() async {
    if (_isPublicProfileView) return;

    final userId = await PrefUtils.getUserId() ?? 0;
    if (userId <= 0) return;

    final savedRole = await PrefUtils.getRole();
    final normalizedRole = savedRole.trim().toLowerCase();

    final bool isClubAccount = normalizedRole == 'club' ||
        normalizedRole == 'клуб' ||
        normalizedRole.contains('club');

    if (!isClubAccount) {
      _clubAccessGuard?.dispose();
      _clubAccessGuard = null;
      return;
    }

    final savedEmail = await PrefUtils.getUserEmail();

    _clubAccessGuard?.dispose();

    _clubAccessGuard = ClubAccessGuard(
      userId: userId,
      email: savedEmail,
      interval: const Duration(seconds: 20),
      onAccessBlocked: () async {
        final guard = _clubAccessGuard;
        _clubAccessGuard = null;
        guard?.dispose();

        final clubNameForAccess = fullName;
        final emailForAccess =
            savedEmail.trim().isNotEmpty ? savedEmail : email;

        await PrefUtils.clearAll();

        if (!mounted) return;

        Get.offAll<void>(
          () => ClubAccessScreen(
            userId: userId,
            clubName: clubNameForAccess,
            email: emailForAccess,
          ),
          transition: Transition.noTransition,
          duration: Duration.zero,
        );
      },
    );

    _clubAccessGuard!.start();
  }

  @override
  void initState() {
    super.initState();
    _startBadgePolling();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _startClubAccessGuard();
    });
    _aiCardSeed = _rnd.nextInt(999999);
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat(reverse: true);

    _loadInitialData().then((_) {
      // После загрузки данных принудительно обновляем
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _clubAccessGuard?.dispose();
    _clubAccessGuard = null;

    _badgePollingTimer?.cancel();
    _newPostText.dispose();

    // ===== НОВЫЙ КОД =====
    _pulseController.dispose();
    for (var c in _hoverControllers.values) {
      c.dispose();
    }

    super.dispose();
  }

  // =============================
  // СТАРЫЕ МЕТОДЫ (ВСЕ ОСТАВЛЯЕМ)
  // =============================
  int _asInt(dynamic v) {
    if (v is int) return v;
    return int.tryParse(v?.toString() ?? '0') ?? 0;
  }

  DateTime? _parseDate(dynamic v) {
    if (v == null) return null;
    final s = v.toString().trim();
    if (s.isEmpty || s.toLowerCase() == 'null') return null;
    try {
      final pure = s.contains(' ') ? s.split(' ').first : s;
      return DateTime.tryParse(pure);
    } catch (_) {
      return null;
    }
  }

  int? _calcAge(DateTime? dob) {
    if (dob == null) return null;
    final now = DateTime.now();
    int a = now.year - dob.year;
    final hadBirthdayThisYear = (now.month > dob.month) ||
        (now.month == dob.month && now.day >= dob.day);
    if (!hadBirthdayThisYear) a -= 1;
    if (a < 0 || a > 120) return null;
    return a;
  }

  String? _normalizePhotoUrl(dynamic raw) {
    if (raw == null) return null;
    final s = raw.toString().trim();
    if (s.isEmpty || s.toLowerCase() == 'null') return null;
    if (s.startsWith('http://') || s.startsWith('https://')) return s;
    return '$_uploadsBase/$s';
  }

  String get fullName {
    final name = '$firstName $lastName'.trim();
    return name.isEmpty ? 'Пользователь' : name;
  }

  int _toInt(dynamic v) {
    if (v == null) return 0;
    if (v is int) return v;
    if (v is double) return v.toInt();
    return int.tryParse(v.toString().replaceAll(RegExp('[^0-9]'), '')) ?? 0;
  }

  String _safeStr(dynamic v) => (v ?? '').toString();
  int _safeInt(dynamic v) => int.tryParse(_safeStr(v)) ?? 0;

  String _fixUrl(String s) {
    final u = s.trim();
    if (u.isEmpty) return "";
    if (u.startsWith("http")) return u;
    return "https://sportotekaapp.ru/$u";
  }

  bool _looksLikeHtml(String s) {
    final t = s.trim().toLowerCase();
    return t.contains('<p') ||
        t.contains('<br') ||
        t.contains('</') ||
        t.contains('<div') ||
        t.contains('<span');
  }

  String _htmlToPlain(String html) {
    var t = html;
    t = t.replaceAll(RegExp(r'<br\s*/?>', caseSensitive: false), '\n');
    t = t.replaceAll(RegExp(r'</p\s*>', caseSensitive: false), '\n\n');
    t = t.replaceAll(RegExp(r'<p[^>]*>', caseSensitive: false), '');
    t = t.replaceAll(RegExp(r'<[^>]+>'), '');
    t = t.replaceAll('&nbsp;', ' ');
    t = t.replaceAll('&amp;', '&');
    t = t.replaceAll('&quot;', '"');
    t = t.replaceAll('&#39;', "'");
    t = t.replaceAll('&lt;', '<');
    t = t.replaceAll('&gt;', '>');
    return t.trim();
  }

  Future<bool> _confirmDeleteDialog({
    required String title,
    required String message,
  }) async {
    final res = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Text(message),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text("Отмена")),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Удалить"),
          ),
        ],
      ),
    );
    return res == true;
  }

  void _openItemActionsSheet({
    required String title,
    required VoidCallback onDelete,
  }) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (_) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(99))),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                        child: Text(title,
                            style: const TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w900))),
                    IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close)),
                  ],
                ),
                const SizedBox(height: 6),
                ListTile(
                  leading: const Icon(Icons.delete_outline, color: Colors.red),
                  title: const Text("Удалить",
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: const Text("Действие нельзя отменить"),
                  onTap: () {
                    Navigator.pop(context);
                    onDelete();
                  },
                ),
                const SizedBox(height: 6),
              ],
            ),
          ),
        );
      },
    );
  }

  Future<void> _deletePostById(int postId) async {
    final myId = await PrefUtils.getUserId() ?? 0;
    if (myId <= 0 || postId <= 0) return;

    final ok = await _confirmDeleteDialog(
        title: "Удалить пост?", message: "Пост будет удалён навсегда.");
    if (!ok) return;

    try {
      final resp = await http.post(
        Uri.parse(_deletePostUrl),
        body: {'user_id': myId.toString(), 'post_id': postId.toString()},
      );

      if (resp.statusCode != 200) {
        Get.snackbar("Ошибка", "Сервер: ${resp.statusCode}",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final data = jsonDecode(resp.body);
      final success = (data is Map) &&
          (data['success'] == true ||
              data['status'] == 'success' ||
              data['status'] == 'deleted');

      if (!success) {
        Get.snackbar(
            "Не удалось удалить",
            (data is Map && data['error'] != null)
                ? data['error'].toString()
                : "Ошибка",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      if (mounted) {
        setState(() {
          userPosts.removeWhere((p) => _toInt((p as Map)['id']) == postId);
          feedPosts.removeWhere((p) => _safeInt(p['id']) == postId);
        });
      }

      await _fetchUserPosts();
      await _fetchAuthorFeedPosts();

      Get.snackbar("Готово", "Пост удалён",
          snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      Get.snackbar("Ошибка сети", e.toString(),
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _deleteReelById(int reelId) async {
    final myId = await PrefUtils.getUserId() ?? 0;
    if (myId <= 0 || reelId <= 0) return;

    final ok = await _confirmDeleteDialog(
        title: "Удалить Reels?", message: "Видео будет удалено навсегда.");
    if (!ok) return;

    try {
      final resp = await http.post(
        Uri.parse(_deleteReelUrl),
        body: {'user_id': myId.toString(), 'reel_id': reelId.toString()},
      );

      if (resp.statusCode != 200) {
        Get.snackbar("Ошибка", "Сервер: ${resp.statusCode}",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final data = jsonDecode(resp.body);
      final success = (data is Map) &&
          (data['success'] == true ||
              data['status'] == 'success' ||
              data['status'] == 'deleted');

      if (!success) {
        Get.snackbar(
            "Не удалось удалить",
            (data is Map && data['error'] != null)
                ? data['error'].toString()
                : "Ошибка",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      if (mounted) {
        setState(() {
          userReels.removeWhere((r) => _toInt(r['id']) == reelId);
        });
      }

      await _fetchUserReels();

      Get.snackbar("Готово", "Reels удалён",
          snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      Get.snackbar("Ошибка сети", e.toString(),
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _loadInitialData() async {
    try {
      await Future.wait([
        loadUserData(),
        _fetchUserPosts(),
        _fetchUserReels(),
        _fetchAuthorFeedPosts(),
        _checkIfFollowing(),
        _loadFollowersData(),
        // Дизайн профиля больше не загружаем с сервера: белый социальный профиль по умолчанию.
      ]);
      await _resolvePressAssistantAssignment();
    } catch (_) {
      // ignore
    } finally {
      if (mounted) setState(() => isLoadingProfile = false);
    }
  }

  Future<void> loadUserData() async {
    final currentUserId = await PrefUtils.getUserId();
    final viewedUserId = widget.userId ?? currentUserId;

    if (viewedUserId == null || viewedUserId <= 0) {
      await _loadLocalData();
      return;
    }

    try {
      final uri = Uri.parse('$_apiBase/get_user.php?user_id=$viewedUserId');
      final response = await http.get(uri);

      if (response.statusCode != 200) {
        if (viewedUserId == currentUserId) {
          await _loadLocalData();
        } else {
          if (mounted) {
            setState(() {
              firstName = 'Пользователь';
              lastName = '';
            });
          }
        }
        return;
      }

      final responseBody = utf8.decode(response.bodyBytes);
      final data = jsonDecode(responseBody);

      Map<String, dynamic> root = {};
      if (data is Map) root = data.cast<String, dynamic>();

      Map<String, dynamic> userData = {};
      if (root['success'] == true && root['user'] is Map) {
        userData = (root['user'] as Map).cast<String, dynamic>();
      } else if (root['user'] is Map) {
        userData = (root['user'] as Map).cast<String, dynamic>();
      } else {
        userData = root;
      }

      final first = (userData['first_name'] ?? userData['firstName'] ?? '')
          .toString()
          .trim();
      final last = (userData['last_name'] ?? userData['lastName'] ?? '')
          .toString()
          .trim();
      final mail = (userData['email'] ?? '').toString().trim();
      final r = (userData['role'] ?? '').toString().trim();

      final photo1 = _normalizePhotoUrl(userData['photo_url']);
      final photo2 = _normalizePhotoUrl(userData['photo_urls']);
      final photo3 = _normalizePhotoUrl(userData['photo']);
      final resolvedPhoto = photo1 ?? photo2 ?? photo3;

      final b =
          (userData['bio'] ?? userData['description'] ?? '').toString().trim();
      final loc =
          (userData['location'] ?? userData['city'] ?? '').toString().trim();

      int? resolvedAge;
      String? resolvedBirthRaw;
      String? resolvedTeamName;
      String? resolvedClubName;
      String? resolvedTeamLogo;
      int? resolvedTeamId;

      final player = (root['player'] is Map)
          ? (root['player'] as Map).cast<String, dynamic>()
          : null;
      final playerTeam = (root['player_team'] is Map)
          ? (root['player_team'] as Map).cast<String, dynamic>()
          : null;

      if (player != null) {
        final apiAge = _asInt(player['age']);
        final birthAny = player['birth_date'] ??
            player['dob'] ??
            player['date_of_birth'] ??
            player['birthday'];
        final dob = _parseDate(birthAny);
        final computedAge = _calcAge(dob);

        resolvedAge = (apiAge > 0) ? apiAge : computedAge;
        resolvedBirthRaw = (birthAny ?? '').toString().trim();
        if ((resolvedBirthRaw ?? '').isEmpty) {
          resolvedBirthRaw = null;
        }
      }

      if (playerTeam != null) {
        resolvedTeamId = _asInt(playerTeam['id'] ?? playerTeam['team_id']);

        resolvedTeamName = (playerTeam['name'] ?? playerTeam['team_name'] ?? '')
            .toString()
            .trim();
        if (resolvedTeamName.isEmpty) resolvedTeamName = null;

        resolvedClubName =
            (playerTeam['club_name'] ?? playerTeam['clubName'] ?? '')
                .toString()
                .trim();
        if (resolvedClubName.isEmpty) resolvedClubName = null;

        resolvedTeamLogo =
            (playerTeam['logo_url'] ?? playerTeam['logoUrl'] ?? '')
                .toString()
                .trim();
        if (resolvedTeamLogo.isEmpty) resolvedTeamLogo = null;
      }

      if (!mounted) return;
      setState(() {
        firstName = first;
        lastName = last;
        email = mail;
        role = r;
        photo = resolvedPhoto;
        bio = b.isEmpty ? null : b;
        location = loc.isEmpty ? null : loc;

        age = resolvedAge;
        birthDateRaw = resolvedBirthRaw;

        playerTeamName = resolvedTeamName;
        playerClubName = resolvedClubName;
        playerTeamLogoUrl = resolvedTeamLogo;
        playerTeamId = (resolvedTeamId ?? 0) > 0 ? resolvedTeamId : null;
      });

      if (viewedUserId == currentUserId) {
        await PrefUtils.setUserFirstName(firstName);
        await PrefUtils.setUserLastName(lastName);
        await PrefUtils.setUserEmail(email);
        await PrefUtils.setRole(role);

        final photoFile = (userData['photo'] ?? '').toString().trim();
        if (photoFile.isNotEmpty) {
          await PrefUtils.setUserPhoto(photoFile);
        }
      }
    } catch (_) {
      final currentUserId2 = await PrefUtils.getUserId();
      final viewedUserId2 = widget.userId ?? currentUserId2;

      if (viewedUserId2 == currentUserId2) {
        await _loadLocalData();
      } else {
        if (mounted) {
          setState(() {
            firstName = 'Пользователь';
            lastName = '';
          });
        }
      }
    }
  }

  Future<void> _resolvePressAssistantAssignment() async {
    final currentUserId = await PrefUtils.getUserId() ?? 0;
    final viewedUserId = widget.userId ?? currentUserId;
    if (currentUserId <= 0 || viewedUserId != currentUserId) return;

    bool isPressValue(dynamic value) {
      final v = '${value ?? ''}'.trim().toLowerCase();
      return v == 'press_assistant' ||
          v == 'press' ||
          v == 'press_service' ||
          v.contains('press_assistant') ||
          v.contains('пресс');
    }

    Map<String, dynamic>? firstPressFrom(dynamic node) {
      if (node is Map) {
        final map = Map<String, dynamic>.from(node);

        // Новый get_trainer_profile.php возвращает отдельный массив
        // press_assignments из club_press_staff. Используем его первым.
        for (final key in const <String>[
          'press_assignments',
          'press_teams',
        ]) {
          final raw = map[key];
          if (raw is List) {
            for (final item in raw.whereType<Map>()) {
              final assignment = Map<String, dynamic>.from(item);
              if (isPressValue(assignment['profile']) ||
                  isPressValue(assignment['link_profile'])) {
                return assignment;
              }
            }
          }
        }

        if (isPressValue(map['profile']) ||
            isPressValue(map['link_profile']) ||
            isPressValue(map['staff_role']) ||
            isPressValue(map['position_code'])) {
          return map;
        }

        for (final value in map.values) {
          final found = firstPressFrom(value);
          if (found != null) return found;
        }
      } else if (node is List) {
        for (final value in node) {
          final found = firstPressFrom(value);
          if (found != null) return found;
        }
      }

      return null;
    }

    try {
      final response = await http
          .post(
            Uri.parse('$_apiBase/get_trainer_profile.php'),
            headers: const <String, String>{
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode(<String, dynamic>{
              'trainer_id': currentUserId,
              'user_id': currentUserId,
            }),
          )
          .timeout(const Duration(seconds: 12));

      dynamic decoded;
      try {
        decoded = jsonDecode(utf8.decode(response.bodyBytes));
      } catch (_) {
        decoded = null;
      }

      final found = firstPressFrom(decoded);

      if (!mounted) return;

      if (found != null) {
        setState(() => _pressAssistantAssignment = found);
        return;
      }

      final r = role.trim().toLowerCase();
      if (r.contains('press') || r.contains('пресс')) {
        setState(() {
          _pressAssistantAssignment = <String, dynamic>{
            'profile': 'press_assistant',
          };
        });
      }
    } catch (_) {
      final r = role.trim().toLowerCase();
      if (mounted && (r.contains('press') || r.contains('пресс'))) {
        setState(() {
          _pressAssistantAssignment = <String, dynamic>{
            'profile': 'press_assistant',
          };
        });
      }
    }
  }

  Future<void> _loadLocalData() async {
    try {
      final savedFirstName = await PrefUtils.getUserFirstName();
      final savedLastName = await PrefUtils.getUserLastName();
      final savedEmail = await PrefUtils.getUserEmail();
      final savedRole = await PrefUtils.getRole();
      final savedPhotoFile = await PrefUtils.getUserPhoto();

      if (!mounted) return;
      setState(() {
        firstName = savedFirstName;
        lastName = savedLastName;
        email = savedEmail;
        role = savedRole;
        photo = _normalizePhotoUrl(savedPhotoFile);
      });
    } catch (_) {}
  }

  Future<void> _checkIfFollowing() async {
    final currentUserId = await PrefUtils.getUserId();
    final viewedUserId = widget.userId ?? currentUserId;

    if (currentUserId == null || currentUserId <= 0) {
      if (widget.userId != null && mounted) {
        setState(() {
          isOwnProfile = false;
          isFollowing = false;
        });
      }
      return;
    }

    if (viewedUserId == currentUserId || viewedUserId == null) {
      if (mounted) {
        setState(() {
          isOwnProfile = true;
          isFollowing = false;
        });
      }
      return;
    }

    if (mounted) setState(() => isOwnProfile = false);

    try {
      final response = await http.post(
        Uri.parse('$_apiBase/check_following.php'),
        body: {
          'follower_id': currentUserId.toString(),
          'following_id': viewedUserId.toString()
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (mounted) {
          setState(
              () => isFollowing = (data is Map && data['following'] == true));
        }
      }
    } catch (_) {}
  }

  Future<void> _toggleFollow() async {
    final currentUserId = await PrefUtils.getUserId();
    final viewedUserId = widget.userId ?? currentUserId;

    if (currentUserId == null || currentUserId <= 0) return;
    if (viewedUserId == null || viewedUserId <= 0) return;

    final url =
        isFollowing ? '$_apiBase/unsubscribe.php' : '$_apiBase/subscribe.php';

    try {
      final response = await http.post(Uri.parse(url), body: {
        'follower_id': currentUserId.toString(),
        'following_id': viewedUserId.toString(),
      });

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final ok = (data is Map) &&
            (data['status'] == 'success' ||
                data['status'] == 'subscribed' ||
                data['status'] == 'unsubscribed' ||
                data['success'] == true);
        if (ok) {
          if (mounted) {
            setState(() {
              isFollowing = !isFollowing;
              final viewedId = widget.userId ?? 0;
              if (viewedId > 0) {
                _socialFollowingState[viewedId] = isFollowing;
                _socialFollowingLoaded.add(viewedId);
              }
            });
          }
          await _loadFollowersData();
          _followers.clear();
          _followings.clear();
        } else {
          Get.snackbar('Ошибка', 'Не удалось изменить подписку',
              backgroundColor: Colors.red,
              colorText: Colors.white,
              snackPosition: SnackPosition.BOTTOM);
        }
      }
    } catch (_) {
      Get.snackbar('Ошибка сети', 'Проверьте соединение',
          backgroundColor: Colors.red,
          colorText: Colors.white,
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _openPrivateChat() async {
    try {
      final myId = await PrefUtils.getUserId() ?? 0;
      final peerId = widget.userId ?? 0;

      if (myId <= 0) {
        Get.snackbar("Чат", "Не найден мой user_id",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }
      if (peerId <= 0) {
        Get.snackbar("Чат", "Не найден user_id профиля",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }
      if (myId == peerId) return;

      final resp = await http.post(
        Uri.parse(_getOrCreatePrivateChatUrl),
        body: {'me': myId.toString(), 'peer_id': peerId.toString()},
      );

      if (resp.statusCode != 200) {
        Get.snackbar("Чат", "Ошибка сервера: ${resp.statusCode}",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final data = jsonDecode(resp.body);
      final ok = (data is Map && data['success'] == true);
      if (!ok) {
        Get.snackbar(
            "Чат",
            (data is Map && data['error'] != null)
                ? data['error'].toString()
                : "Ошибка",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final chatId = int.tryParse('${data['chat_id'] ?? ''}') ?? 0;
      if (chatId <= 0) {
        Get.snackbar("Чат", "Не удалось получить chat_id",
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final chatName = fullName.isNotEmpty ? fullName : "Личный чат";

      if (!mounted) return;
      Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => ChatRoomScreen(
                chatId: chatId, userId: myId, chatName: chatName)),
      );
    } catch (e) {
      Get.snackbar("Чат", "Ошибка: $e", snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _loadFollowersData() async {
    final userId = widget.userId ?? await PrefUtils.getUserId();
    if (userId == null || userId <= 0) return;

    try {
      final response = await http.post(
        Uri.parse('$_apiBase/get_follow_counts.php'),
        body: {'user_id': userId.toString()},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        final ok = (data is Map) &&
            (data['status'] == 'success' || data['success'] == true);

        if (ok && mounted) {
          setState(() {
            followersCount = _asInt(data['followers']);
            followingsCount = _asInt(data['followings']);
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _fetchUserPosts() async {
    if (mounted) setState(() => isLoadingPosts = true);

    try {
      final userId = widget.userId ?? await PrefUtils.getUserId();
      if (userId == null || userId <= 0) return;

      final response = await http.post(
        Uri.parse('$_apiBase/get_posts_by_user.php'),
        body: jsonEncode(
            {'user_id': userId, 'visibility': 'profile', 'post_type': 'post'}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is Map && data['status'] == 'success') {
          if (mounted) {
            setState(
                () => userPosts = (data['posts'] is List) ? data['posts'] : []);
          }
        }
      }
    } catch (_) {
      // ignore
    } finally {
      if (mounted) setState(() => isLoadingPosts = false);
    }
  }

  Future<void> _fetchUserReels() async {
    if (mounted) setState(() => isLoadingReels = true);

    try {
      final userId = widget.userId ?? await PrefUtils.getUserId();
      if (userId == null || userId <= 0) return;

      final url = Uri.parse(
          "$_apiBase/get_reels.php?limit=200&offset=0&user_id=$userId");
      final resp = await http.get(url);
      if (resp.statusCode != 200) return;

      final body = utf8.decode(resp.bodyBytes, allowMalformed: true).trim();
      final jsonAny = jsonDecode(body);

      final parsed = _parseReels(jsonAny);
      final filtered =
          parsed.where((m) => (m['user_id'] ?? 0) == userId).toList();

      if (mounted) setState(() => userReels = filtered);
    } catch (_) {
      // ignore
    } finally {
      if (mounted) setState(() => isLoadingReels = false);
    }
  }

  List<Map<String, dynamic>> _parseReels(dynamic jsonAny) {
    List raw;
    if (jsonAny is Map) {
      raw = (jsonAny['reels'] ??
              jsonAny['data'] ??
              jsonAny['items'] ??
              jsonAny['list'] ??
              []) as List? ??
          [];
    } else if (jsonAny is List) {
      raw = jsonAny;
    } else {
      raw = const [];
    }

    return raw
        .map<Map<String, dynamic>>((e) {
          final m = Map<String, dynamic>.from(e as Map);

          final String video =
              (m['video_url'] ?? m['video'] ?? m['url'] ?? m['src'] ?? '')
                  .toString()
                  .trim();
          String thumb = (m['thumbnail'] ?? m['thumb'] ?? m['poster'] ?? '')
              .toString()
              .trim();
          if (thumb.isEmpty && m['preview'] != null) {
            thumb = m['preview'].toString().trim();
          }

          return {
            'id': _toInt(m['id'] ?? m['reel_id'] ?? 0),
            'user_id': _toInt(m['user_id'] ?? m['author_id'] ?? 0),
            'video_url': video,
            'thumbnail': thumb,
            'description': (m['description'] ?? m['caption'] ?? '').toString(),
            'likes': _toInt(m['likes'] ?? m['like_count'] ?? 0),
            'comments': _toInt(m['comments_count'] ??
                m['comments'] ??
                m['comment_count'] ??
                0),
            'views': _toInt(m['views'] ?? m['view_count'] ?? 0),
            'rotation': m['rotation'],
            'crop_mode': m['crop_mode'],
            'crop_scale': m['crop_scale'],
            'crop_dx': m['crop_dx'],
            'crop_dy': m['crop_dy'],
          };
        })
        .where((e) => (e['video_url'] as String).isNotEmpty)
        .toList();
  }

  Future<void> _fetchAuthorFeedPosts() async {
    if (mounted) setState(() => isLoadingFeed = true);

    try {
      final userId = widget.userId ?? await PrefUtils.getUserId();
      if (userId == null || userId <= 0) return;

      final response = await http.post(
        Uri.parse('$_apiBase/get_posts_by_user.php'),
        body: jsonEncode(
            {'user_id': userId, 'visibility': 'profile', 'post_type': 'post'}),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode != 200) return;
      final decoded = jsonDecode(response.body);
      final List<dynamic> data = decoded is Map
          ? ((decoded['posts'] ?? decoded['data'] ?? decoded['items'] ?? [])
                  as List? ??
              [])
          : (decoded is List ? decoded : const []);

      final authorName = ('$firstName $lastName').trim().isNotEmpty
          ? ('$firstName $lastName').trim()
          : 'Профиль';
      final authorAvatar = _fixUrl(photo ?? '');

      final list = data.map<Map<String, dynamic>>((rawAny) {
        final raw = Map<String, dynamic>.from(rawAny as Map);
        final body = _safeStr(raw['body'] ?? raw['text'] ?? raw['caption']);
        final plainBody = _looksLikeHtml(body) ? _htmlToPlain(body) : body;
        final image =
            _fixUrl(_safeStr(raw['image'] ?? raw['image_url'] ?? raw['photo']));
        final createdAt =
            DateTime.tryParse(_safeStr(raw['created_at'] ?? raw['date'])) ??
                DateTime.now();
        final category = _safeStr(raw['category']).trim();
        final title = _safeStr(raw['title']).trim();

        return <String, dynamic>{
          'id': _safeInt(raw['id']),
          'title': title.isNotEmpty
              ? title
              : (category.isNotEmpty ? category : 'Публикация профиля'),
          'text': plainBody,
          'imageUrl': image,
          'date': createdAt,
          'category': category.isNotEmpty ? category : 'Профиль',
          'authorName': authorName,
          'user_id': userId,
          'authorAvatar': authorAvatar,
          'likes': _safeInt(raw['likes_count'] ?? raw['likes']),
          'comments': _safeInt(raw['comments_count'] ?? raw['comments']),
        };
      }).where((post) {
        final text = _safeStr(post['text']).trim();
        final image = _safeStr(post['imageUrl']).trim();
        return text.isNotEmpty || image.isNotEmpty;
      }).toList();

      list.sort(
          (a, b) => (b['date'] as DateTime).compareTo(a['date'] as DateTime));

      if (!mounted) return;
      setState(() => feedPosts = list);
    } catch (_) {
      // ignore
    } finally {
      if (mounted) setState(() => isLoadingFeed = false);
    }
  }

  void _openFeedPostDetail(Map<String, dynamic> post) {
    final width = MediaQuery.sizeOf(context).width;

    // Социальный профиль на планшете и ПК остаётся на месте:
    // публикация раскрывается в соседней правой области, а сетка остаётся слева.
    if (width >= 720) {
      setState(() {
        // Важно: при нажатии из общего обзора сразу переводим профиль
        // в отдельный экран публикаций с двумя колонками.
        _profileWorkspaceSection = 'posts';
        _mode = _ProfileFeedMode.posts;
        _openedProfilePost = Map<String, dynamic>.from(post);
        _desktopRightPaneChild = null;
        _desktopRightPaneTitle = '';
      });
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => NewsDetailScreen(
          title: _safeStr(post['title']).isNotEmpty
              ? _safeStr(post['title'])
              : 'Публикация',
          body: _safeStr(post['text']),
          newsId: _safeInt(post['id']),
          imageUrl: _safeStr(post['imageUrl']),
        ),
      ),
    ).then((_) => _fetchAuthorFeedPosts());
  }

  void _closeTabletProfilePost() {
    if (!mounted) return;
    setState(() => _openedProfilePost = null);
    _fetchAuthorFeedPosts();
  }

  Future<void> _submitProfilePost() async {
    final userId = await PrefUtils.getUserId();
    if (userId == null || userId <= 0) return;

    final text = _newPostText.text.trim();
    if (text.isEmpty && _newPostImage == null) {
      Get.snackbar("Публикация", "Напишите текст или добавьте фото",
          snackPosition: SnackPosition.BOTTOM);
      return;
    }

    if (mounted) setState(() => _posting = true);

    final uri = Uri.parse('$_apiBase/insert_post.php');
    final req = http.MultipartRequest('POST', uri)
      ..fields['title'] = ''
      ..fields['body'] = text
      ..fields['category'] = ''
      ..fields['team'] = ''
      ..fields['author'] = ''
      ..fields['user_id'] = userId.toString()
      ..fields['visibility'] = 'profile'
      ..fields['post_type'] = 'post';

    if (_newPostImage != null) {
      req.files
          .add(await http.MultipartFile.fromPath('image', _newPostImage!.path));
    }

    try {
      final resp = await req.send();
      final body = await resp.stream.bytesToString();

      if (resp.statusCode == 200) {
        if (mounted) Navigator.pop(context);

        if (mounted) {
          setState(() {
            _newPostText.clear();
            _newPostImage = null;
          });
        }

        await _fetchUserPosts();
        await _fetchAuthorFeedPosts();
      } else {
        Get.snackbar("Ошибка", "Не удалось опубликовать: $body",
            snackPosition: SnackPosition.BOTTOM);
      }
    } catch (e) {
      Get.snackbar("Ошибка сети", e.toString(),
          snackPosition: SnackPosition.BOTTOM);
    } finally {
      if (mounted) setState(() => _posting = false);
    }
  }

  Future<void> _openContextualProfileCreate() async {
    if (!isOwnProfile) return;

    final initialType = _mode == _ProfileFeedMode.reels
        ? CreateContentType.reel
        : CreateContentType.post;

    final createdType = await Navigator.of(context).push<CreateContentType>(
      MaterialPageRoute<CreateContentType>(
        builder: (_) => CreateContentScreen(
          initialType: initialType,
          sportName: 'Футбол',
          postDestination: CreatePostDestination.profile,
          authorLabel: fullName,
        ),
      ),
    );

    if (!mounted || createdType == null) return;

    if (createdType == CreateContentType.reel) {
      await _fetchUserReels();
      if (!mounted) return;
      setState(() {
        _mode = _ProfileFeedMode.reels;
        _profileWorkspaceSection = 'reels';
      });
      return;
    }

    await Future.wait([
      _fetchUserPosts(),
      _fetchAuthorFeedPosts(),
    ]);
    if (!mounted) return;
    setState(() {
      _mode = _ProfileFeedMode.posts;
      _profileWorkspaceSection = 'posts';
    });
  }


  String get _profileMediaEditTitle =>
      isClubRole ? 'Изменить логотип / аватарку' : 'Изменить аватарку';

  String get _profileMediaEditSubtitle =>
      isClubRole ? 'Обновить логотип клуба в профиле' : 'Обновить фото профиля';

  Future<void> _uploadProfilePhoto(File imageFile) async {
    if (_uploadingProfilePhoto) return;

    final userId = await PrefUtils.getUserId();
    if (userId == null || userId <= 0) {
      Get.snackbar('Профиль', 'Не удалось определить пользователя',
          snackPosition: SnackPosition.BOTTOM);
      return;
    }

    if (mounted) setState(() => _uploadingProfilePhoto = true);

    final uri = Uri.parse('$_apiBase/upload_user_photo.php');

    try {
      final request = http.MultipartRequest('POST', uri)
        ..fields['user_id'] = userId.toString()
        ..fields['profile_media_type'] = isClubRole ? 'club_logo' : 'avatar'
        ..files.add(await http.MultipartFile.fromPath('photo', imageFile.path));

      final response = await request.send();
      final body = await response.stream.bytesToString();

      if (response.statusCode != 200) {
        Get.snackbar('Профиль', 'Сервер вернул ошибку ${response.statusCode}',
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      dynamic decoded;
      try {
        decoded = jsonDecode(body);
      } catch (_) {
        Get.snackbar('Профиль', 'Сервер вернул некорректный ответ',
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final data = decoded is Map
          ? decoded.cast<String, dynamic>()
          : <String, dynamic>{};
      final success = data['status'] == 'success' || data['success'] == true;

      if (!success) {
        final message = (data['message'] ??
                data['error'] ??
                'Не удалось обновить изображение')
            .toString();
        Get.snackbar('Профиль', message, snackPosition: SnackPosition.BOTTOM);
        return;
      }

      final serverPhotoUrl =
          (data['photo_url'] ?? data['photoUrl'] ?? data['url'] ?? '')
              .toString()
              .trim();
      final fileName =
          (data['file_name'] ?? data['filename'] ?? data['photo'] ?? '')
              .toString()
              .trim();
      final newUrl =
          _normalizePhotoUrl(serverPhotoUrl) ?? _normalizePhotoUrl(fileName);

      if (newUrl != null && mounted) {
        setState(() => photo = newUrl);
      }

      if (fileName.isNotEmpty) {
        await PrefUtils.setUserPhoto(fileName);
      } else if (serverPhotoUrl.isNotEmpty) {
        await PrefUtils.setUserPhoto(serverPhotoUrl);
      }

      await loadUserData();
      await _fetchAuthorFeedPosts();

      Get.snackbar(
        'Профиль',
        isClubRole ? 'Логотип обновлён' : 'Аватарка обновлена',
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e) {
      Get.snackbar('Профиль', 'Ошибка загрузки изображения',
          snackPosition: SnackPosition.BOTTOM);
    } finally {
      if (mounted) setState(() => _uploadingProfilePhoto = false);
    }
  }

  Future<void> _pickAndUploadPhoto(
      {ImageSource source = ImageSource.gallery}) async {
    if (!isOwnProfile || _uploadingProfilePhoto) return;

    try {
      final picked = await ImagePicker().pickImage(
        source: source,
        imageQuality: 88,
        maxWidth: 1600,
      );
      if (picked != null) {
        await _uploadProfilePhoto(File(picked.path));
      }
    } catch (_) {
      Get.snackbar('Профиль', 'Не удалось выбрать изображение',
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  void _openProfileMediaPickerSheet() {
    if (!isOwnProfile) return;

    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 42,
                    height: 4,
                    decoration: BoxDecoration(
                        color: const Color(0xFFE5E7EB),
                        borderRadius: BorderRadius.circular(999)),
                  ),
                ),
                const SizedBox(height: 14),
                Text(_profileMediaEditTitle,
                    style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF111827))),
                const SizedBox(height: 4),
                Text(_profileMediaEditSubtitle,
                    style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF667085))),
                const SizedBox(height: 14),
                _buildSettingsRow(
                  icon: Icons.photo_library_outlined,
                  title: 'Выбрать из галереи',
                  subtitle: 'Загрузить изображение из файлов или фото',
                  onTap: () {
                    Navigator.pop(context);
                    _pickAndUploadPhoto(source: ImageSource.gallery);
                  },
                ),
                _buildSettingsRow(
                  icon: Icons.photo_camera_outlined,
                  title: 'Сделать фото',
                  subtitle: 'Открыть камеру устройства',
                  onTap: () {
                    Navigator.pop(context);
                    _pickAndUploadPhoto(source: ImageSource.camera);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  String _socialRoleLabel(String? rawRole) {
    final roleValue = (rawRole ?? '').trim().toLowerCase();
    if (roleValue.isEmpty) return '';

    if (roleValue == 'player' || roleValue.contains('игрок')) {
      return 'Игрок';
    }
    if (roleValue == 'coach' ||
        roleValue == 'trainer' ||
        roleValue.contains('тренер')) {
      return 'Тренер';
    }
    if (roleValue == 'club' || roleValue.contains('клуб')) {
      return 'Клуб';
    }
    if (roleValue == 'parent' || roleValue.contains('родител')) {
      return 'Родитель';
    }

    final raw = (rawRole ?? '').trim();
    if (raw.isEmpty) return '';
    return raw[0].toUpperCase() + raw.substring(1);
  }

  Future<void> _ensureSocialFollowingState(int targetUserId) async {
    if (targetUserId <= 0 ||
        _socialFollowingLoaded.contains(targetUserId) ||
        _socialFollowingBusy.contains(targetUserId)) {
      return;
    }

    final myId = await PrefUtils.getUserId() ?? 0;
    if (myId <= 0) return;

    if (myId == targetUserId) {
      if (!mounted) return;
      setState(() {
        _socialFollowingState[targetUserId] = false;
        _socialFollowingLoaded.add(targetUserId);
      });
      return;
    }

    _socialFollowingBusy.add(targetUserId);

    try {
      final response = await http.post(
        Uri.parse('$_apiBase/check_following.php'),
        body: <String, String>{
          'follower_id': myId.toString(),
          'following_id': targetUserId.toString(),
        },
      );

      bool following = false;
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        following = data is Map && data['following'] == true;
      }

      if (!mounted) return;
      setState(() {
        _socialFollowingState[targetUserId] = following;
        _socialFollowingLoaded.add(targetUserId);
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _socialFollowingState[targetUserId] = false;
        _socialFollowingLoaded.add(targetUserId);
      });
    } finally {
      _socialFollowingBusy.remove(targetUserId);
    }
  }

  Future<void> _toggleSocialFollowing(int targetUserId) async {
    if (targetUserId <= 0 || _socialFollowingBusy.contains(targetUserId)) {
      return;
    }

    final myId = await PrefUtils.getUserId() ?? 0;
    if (myId <= 0 || myId == targetUserId) return;

    if (!_socialFollowingLoaded.contains(targetUserId)) {
      await _ensureSocialFollowingState(targetUserId);
    }

    final currentlyFollowing = _socialFollowingState[targetUserId] == true;

    if (mounted) {
      setState(() => _socialFollowingBusy.add(targetUserId));
    } else {
      _socialFollowingBusy.add(targetUserId);
    }

    try {
      final response = await http.post(
        Uri.parse(
          currentlyFollowing
              ? '$_apiBase/unsubscribe.php'
              : '$_apiBase/subscribe.php',
        ),
        body: <String, String>{
          'follower_id': myId.toString(),
          'following_id': targetUserId.toString(),
        },
      );

      if (response.statusCode != 200) return;

      final data = jsonDecode(response.body);
      final ok = data is Map &&
          (data['status'] == 'success' ||
              data['status'] == 'subscribed' ||
              data['status'] == 'unsubscribed' ||
              data['success'] == true);

      if (!ok || !mounted) return;

      setState(() {
        _socialFollowingState[targetUserId] = !currentlyFollowing;
        _socialFollowingLoaded.add(targetUserId);
      });

      await _loadFollowersData();

      if (widget.userId == targetUserId) {
        await _checkIfFollowing();
      }
    } catch (_) {
      // Оставляем текущее состояние — список не должен прыгать при сетевой ошибке.
    } finally {
      if (mounted) {
        setState(() => _socialFollowingBusy.remove(targetUserId));
      } else {
        _socialFollowingBusy.remove(targetUserId);
      }
    }
  }

  void _openSocialUserProfile(
    BuildContext sheetContext,
    _UserShort user,
  ) {
    final userId = user.id ?? 0;
    if (userId <= 0) return;

    Navigator.of(sheetContext).pop();

    Navigator.of(context)
        .push<void>(
      MaterialPageRoute<void>(
        builder: (_) => MyProfileScreen(
          userId: userId,
          publicView: true,
        ),
      ),
    )
        .then((_) async {
      await _loadFollowersData();
      await _checkIfFollowing();
    });
  }

  Future<void> _fetchFollowersList() async {
    if (_loadingFollowers) return;
    if (mounted) setState(() => _loadingFollowers = true);

    try {
      final userId = widget.userId ?? await PrefUtils.getUserId();
      if (userId == null || userId <= 0) {
        _followers = [];
        return;
      }

      final res = await http.post(
        Uri.parse('$_apiBase/get_followers.php'),
        body: {'user_id': userId.toString()},
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map &&
            data['status'] == 'success' &&
            data['users'] is List) {
          _followers = (data['users'] as List)
              .map((e) => _UserShort.fromJson(e))
              .toList();
        } else {
          _followers = [];
        }
      }
    } catch (_) {
      _followers = [];
    } finally {
      if (mounted) setState(() => _loadingFollowers = false);
    }
  }

  Future<void> _fetchFollowingsList() async {
    if (_loadingFollowings) return;
    if (mounted) setState(() => _loadingFollowings = true);

    try {
      final userId = widget.userId ?? await PrefUtils.getUserId();
      if (userId == null || userId <= 0) {
        _followings = [];
        return;
      }

      final res = await http.post(
        Uri.parse('$_apiBase/get_followings.php'),
        body: {'user_id': userId.toString()},
      );

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is Map &&
            data['status'] == 'success' &&
            data['users'] is List) {
          _followings = (data['users'] as List)
              .map((e) => _UserShort.fromJson(e))
              .toList();
        } else {
          _followings = [];
        }
      }
    } catch (_) {
      _followings = [];
    } finally {
      if (mounted) setState(() => _loadingFollowings = false);
    }
  }

  void _openUsersModal({
    required bool showFollowers,
  }) async {
    if (showFollowers) {
      await _fetchFollowersList();
    } else {
      await _fetchFollowingsList();
    }

    if (!mounted) return;

    final searchController = TextEditingController();

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(.24),
      builder: (sheetContext) {
        return StatefulBuilder(
          builder: (sheetContext, setSheetState) {
            final allItems = showFollowers ? _followers : _followings;

            final query = searchController.text.trim().toLowerCase();

            final items = query.isEmpty
                ? allItems
                : allItems.where((user) {
                    final haystack = <String>[
                      user.fullName,
                      user.username ?? '',
                      user.role ?? '',
                      user.teamName ?? '',
                      user.clubName ?? '',
                    ].join(' ').toLowerCase();
                    return haystack.contains(query);
                  }).toList();

            final loading =
                showFollowers ? _loadingFollowers : _loadingFollowings;

            final viewportHeight = MediaQuery.sizeOf(sheetContext).height;
            final viewportWidth = MediaQuery.sizeOf(sheetContext).width;

            final isPhone = viewportWidth < 720;

            Widget dots({
              Color color = const Color(0xFF00A750),
              bool compact = true,
            }) {
              final values = compact
                  ? const <List<double>>[
                      <double>[3.0, .34],
                      <double>[3.8, .48],
                      <double>[4.6, .68],
                      <double>[5.4, 1],
                    ]
                  : const <List<double>>[
                      <double>[3.5, .34],
                      <double>[4.5, .48],
                      <double>[5.5, .68],
                      <double>[6.5, 1],
                    ];

              return Row(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (int i = 0; i < values.length; i++) ...[
                    Container(
                      width: values[i][0],
                      height: values[i][0],
                      decoration: BoxDecoration(
                        color: color.withOpacity(values[i][1]),
                        shape: BoxShape.circle,
                      ),
                    ),
                    if (i != values.length - 1) const SizedBox(width: 3),
                  ],
                ],
              );
            }

            Widget avatar(_UserShort user) {
              final hasPhoto = (user.photoUrl ?? '').trim().isNotEmpty;

              return Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFF1F4F2),
                  border: Border.all(
                    color: const Color(0xFFEEF1EF),
                    width: .8,
                  ),
                ),
                clipBehavior: Clip.antiAlias,
                child: hasPhoto
                    ? Image.network(
                        user.photoUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Center(
                          child: Text(
                            user.initials,
                            style: AppTypography.custom(
                              size: 12,
                              weight: FontWeight.w600,
                              color: const Color(0xFF067A46),
                              height: 1,
                              letterSpacing: 0,
                            ),
                          ),
                        ),
                      )
                    : Center(
                        child: Text(
                          user.initials,
                          style: AppTypography.custom(
                            size: 12,
                            weight: FontWeight.w600,
                            color: const Color(0xFF067A46),
                            height: 1,
                            letterSpacing: 0,
                          ),
                        ),
                      ),
              );
            }

            String secondaryLine(_UserShort user) {
              final parts = <String>[];

              final username = (user.username ?? '').trim();
              if (username.isNotEmpty) {
                parts.add(username.startsWith('@') ? username : '@$username');
              }

              final roleLabel = _socialRoleLabel(user.role);
              if (roleLabel.isNotEmpty) {
                parts.add(roleLabel);
              }

              final team = (user.teamName ?? '').trim();
              final club = (user.clubName ?? '').trim();

              if (team.isNotEmpty) {
                parts.add(team);
              } else if (club.isNotEmpty) {
                parts.add(club);
              }

              return parts.join(' · ');
            }

            Widget followButton(_UserShort user) {
              final targetId = user.id ?? 0;
              if (targetId <= 0) {
                return const SizedBox.shrink();
              }

              final myIdFuture = PrefUtils.getUserId();

              return FutureBuilder<int?>(
                future: myIdFuture,
                builder: (context, snapshot) {
                  final myId = snapshot.data ?? 0;

                  if (myId == targetId) {
                    return Container(
                      height: 32,
                      padding: const EdgeInsets.symmetric(
                        horizontal: 11,
                      ),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F9F8),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        'Вы',
                        style: AppTypography.custom(
                          size: 9.2,
                          weight: FontWeight.w600,
                          color: const Color(0xFF667085),
                          height: 1,
                          letterSpacing: 0,
                        ),
                      ),
                    );
                  }

                  final loaded = _socialFollowingLoaded.contains(targetId);
                  final busy = _socialFollowingBusy.contains(targetId);
                  final following = _socialFollowingState[targetId] == true;

                  if (!loaded && !busy) {
                    WidgetsBinding.instance.addPostFrameCallback((_) async {
                      await _ensureSocialFollowingState(targetId);
                      if (sheetContext.mounted) {
                        setSheetState(() {});
                      }
                    });
                  }

                  if (!loaded || busy) {
                    return Container(
                      width: 86,
                      height: 32,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF7F9F8),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const SizedBox(
                        width: 13,
                        height: 13,
                        child: CircularProgressIndicator(
                          strokeWidth: 1.7,
                          color: Color(0xFF00A750),
                        ),
                      ),
                    );
                  }

                  return Material(
                    color: following
                        ? const Color(0xFFF1F3F2)
                        : const Color(0xFF00A750),
                    borderRadius: BorderRadius.circular(8),
                    child: InkWell(
                      onTap: () async {
                        await _toggleSocialFollowing(targetId);
                        if (sheetContext.mounted) {
                          setSheetState(() {});
                        }
                      },
                      borderRadius: BorderRadius.circular(8),
                      child: Container(
                        height: 32,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 11,
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          following ? 'Вы подписаны' : 'Подписаться',
                          style: AppTypography.custom(
                            size: 9.1,
                            weight: FontWeight.w600,
                            color: following
                                ? const Color(0xFF344054)
                                : Colors.white,
                            height: 1,
                            letterSpacing: 0,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              );
            }

            Widget row(_UserShort user) {
              final secondary = secondaryLine(user);

              return Material(
                color: Colors.white,
                child: InkWell(
                  onTap: () => _openSocialUserProfile(sheetContext, user),
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(
                      14,
                      8,
                      12,
                      8,
                    ),
                    child: Row(
                      children: [
                        avatar(user),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                user.fullName,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: AppTypography.custom(
                                  size: 11.2,
                                  weight: FontWeight.w600,
                                  color: const Color(0xFF0B0F14),
                                  height: 1.15,
                                  letterSpacing: 0,
                                ),
                              ),
                              if (secondary.isNotEmpty) ...[
                                const SizedBox(height: 3),
                                Text(
                                  secondary,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTypography.custom(
                                    size: 9.2,
                                    weight: FontWeight.w400,
                                    color: const Color(0xFF7A828D),
                                    height: 1.15,
                                    letterSpacing: 0,
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        followButton(user),
                      ],
                    ),
                  ),
                ),
              );
            }

            return Align(
              alignment: Alignment.bottomCenter,
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: isPhone ? double.infinity : 560,
                ),
                child: Container(
                  height: viewportHeight * (isPhone ? .88 : .82),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(
                      top: Radius.circular(isPhone ? 18 : 16),
                    ),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Column(
                    children: [
                      if (isPhone)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: Container(
                            width: 38,
                            height: 4,
                            decoration: BoxDecoration(
                              color: const Color(0xFFD8DDDA),
                              borderRadius: BorderRadius.circular(99),
                            ),
                          ),
                        ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(
                          14,
                          9,
                          10,
                          7,
                        ),
                        child: Row(
                          children: [
                            dots(
                              color: showFollowers
                                  ? const Color(0xFF00A750)
                                  : const Color(0xFFF59E0B),
                            ),
                            const SizedBox(width: 9),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    showFollowers ? 'Подписчики' : 'Подписки',
                                    style: AppTypography.custom(
                                      size: 12.4,
                                      weight: FontWeight.w600,
                                      color: const Color(0xFF0B0F14),
                                      height: 1.1,
                                      letterSpacing: 0,
                                    ),
                                  ),
                                  const SizedBox(height: 1),
                                  Text(
                                    '${allItems.length} ${showFollowers ? 'подписчиков' : 'подписок'}',
                                    style: AppTypography.custom(
                                      size: 9.2,
                                      weight: FontWeight.w400,
                                      color: const Color(0xFF7A828D),
                                      height: 1.1,
                                      letterSpacing: 0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            InkWell(
                              onTap: () => Navigator.of(sheetContext).pop(),
                              borderRadius: BorderRadius.circular(8),
                              child: Container(
                                width: 32,
                                height: 32,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: const Color(0xFFF7F9F8),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: const Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                  color: Color(0xFF5F6670),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(
                          14,
                          0,
                          14,
                          7,
                        ),
                        child: TextField(
                          controller: searchController,
                          onChanged: (_) => setSheetState(() {}),
                          style: AppTypography.custom(
                            size: 10.2,
                            weight: FontWeight.w400,
                            color: const Color(0xFF0B0F14),
                            height: 1.15,
                            letterSpacing: 0,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Поиск',
                            hintStyle: AppTypography.custom(
                              size: 10.2,
                              weight: FontWeight.w400,
                              color: const Color(0xFF98A2B3),
                              height: 1.15,
                              letterSpacing: 0,
                            ),
                            prefixIcon: const Icon(
                              Icons.search_rounded,
                              size: 17,
                              color: Color(0xFF7A828D),
                            ),
                            filled: true,
                            fillColor: const Color(0xFFF5F7F6),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 9,
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(9),
                              borderSide: BorderSide.none,
                            ),
                            enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(9),
                              borderSide: BorderSide.none,
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(9),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                      ),
                      const Divider(
                        height: 1,
                        thickness: .6,
                        color: Color(0xFFEEF1EF),
                      ),
                      if (loading)
                        const Expanded(
                          child: Center(
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(0xFF00A750),
                            ),
                          ),
                        )
                      else if (items.isEmpty)
                        Expanded(
                          child: Center(
                            child: Padding(
                              padding: const EdgeInsets.all(24),
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  dots(
                                    color: showFollowers
                                        ? const Color(0xFF00A750)
                                        : const Color(0xFFF59E0B),
                                    compact: false,
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    query.isNotEmpty
                                        ? 'Ничего не найдено'
                                        : showFollowers
                                            ? 'Пока нет подписчиков'
                                            : 'Пока нет подписок',
                                    style: AppTypography.custom(
                                      size: 11.2,
                                      weight: FontWeight.w600,
                                      color: const Color(0xFF344054),
                                      height: 1.2,
                                      letterSpacing: 0,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        )
                      else
                        Expanded(
                          child: ListView.builder(
                            padding: const EdgeInsets.only(bottom: 16),
                            itemCount: items.length,
                            itemBuilder: (_, index) => row(items[index]),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );

    searchController.dispose();
  }

  void _onEditProfile() {
    Get.snackbar("Профиль", "Редактирование профиля подключим следующим шагом.",
        snackPosition: SnackPosition.BOTTOM);
  }

  void _openAiDetailsSheet({
    required String title,
    required String subtitle,
    required List<_AiBullet> bullets,
    String? primaryActionLabel,
  }) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (_) {
        return SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                    width: 44,
                    height: 5,
                    decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(99))),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                        child: Text(title,
                            style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.w900,
                                color: Colors.black))),
                    IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close)),
                  ],
                ),
                const SizedBox(height: 4),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(subtitle,
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black.withOpacity(0.55))),
                ),
                const SizedBox(height: 14),
                ...bullets.map((b) => _AiBulletTile(bullet: b)).toList(),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.black,
                          side:
                              BorderSide(color: Colors.black.withOpacity(0.12)),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14)),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: const Text("Закрыть",
                            style: TextStyle(fontWeight: FontWeight.w800)),
                      ),
                    ),
                    if (primaryActionLabel != null) ...[
                      const SizedBox(width: 10),
                      Expanded(
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pop(context);
                            Get.snackbar(
                              "Спортотека AI",
                              "Подключим этот модуль на сервере следующим шагом 🙂",
                              snackPosition: SnackPosition.BOTTOM,
                              backgroundColor:
                                  ProfilePalette.primaryGreen.withOpacity(0.12),
                              colorText: Colors.black,
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: ProfilePalette.primaryGreen,
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14)),
                            elevation: 0,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          child: Text(primaryActionLabel,
                              style:
                                  const TextStyle(fontWeight: FontWeight.w900)),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // =============================
  // НОВЫЕ МЕТОДЫ ДЛЯ ДИЗАЙНА
  // =============================
  Future<void> _loadProfileDesign() async {
    final userId = widget.userId ?? await PrefUtils.getUserId();
    if (userId == null || userId <= 0) return;

    if (mounted) {
      setState(() => designLoading = true);
    }

    try {
      final uri = Uri.parse('$_loadDesignUrl?user_id=$userId');
      final response = await http.get(uri).timeout(const Duration(seconds: 10));

      debugPrint('GET DESIGN STATUS: ${response.statusCode}');
      debugPrint('GET DESIGN BODY: ${utf8.decode(response.bodyBytes)}');

      if (response.statusCode != 200) return;

      final body = utf8.decode(response.bodyBytes);
      final data = jsonDecode(body);

      if (data is Map && data['success'] == true && data['design'] != null) {
        final loadedDesign = ProfileDesign.fromJson(
          Map<String, dynamic>.from(data['design']),
        );

        if (mounted) {
          setState(() {
            design = loadedDesign;
          });
        }
      }
    } catch (e) {
      debugPrint('Error loading design: $e');
    } finally {
      if (mounted) {
        setState(() => designLoading = false);
      }
    }
  }

  Future<void> _saveProfileDesign() async {
    final userId = await PrefUtils.getUserId();
    if (userId == null || userId <= 0) return;

    if (mounted) {
      setState(() => designSaving = true);
    }

    try {
      final designJson = jsonEncode(design.toJson());

      debugPrint('SAVE DESIGN USER ID: $userId');
      debugPrint('SAVE DESIGN JSON: $designJson');

      final response = await http.post(
        Uri.parse(_saveDesignUrl),
        body: {
          'user_id': userId.toString(),
          'design_json': designJson,
        },
      ).timeout(const Duration(seconds: 15));

      final body = utf8.decode(response.bodyBytes);
      debugPrint('SAVE DESIGN STATUS: ${response.statusCode}');
      debugPrint('SAVE DESIGN BODY: $body');

      if (response.statusCode != 200) {
        Get.snackbar(
          'Ошибка',
          'Сервер вернул ${response.statusCode}',
          snackPosition: SnackPosition.BOTTOM,
        );
        return;
      }

      final data = jsonDecode(body);

      if (data is Map && data['success'] == true) {
        Get.snackbar(
          'Успешно',
          'Дизайн профиля сохранён',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: design.primaryColor,
          colorText: Colors.white,
          duration: const Duration(seconds: 2),
        );
      } else {
        Get.snackbar(
          'Ошибка',
          (data is Map && data['message'] != null)
              ? data['message'].toString()
              : 'Не удалось сохранить дизайн',
          snackPosition: SnackPosition.BOTTOM,
        );
      }
    } catch (e) {
      Get.snackbar(
        'Ошибка',
        'Не удалось сохранить дизайн: $e',
        snackPosition: SnackPosition.BOTTOM,
      );
    } finally {
      if (mounted) {
        setState(() => designSaving = false);
      }
    }
  }

  void _openDesignEditor() {
    if (!isOwnProfile) return;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _DesignEditorModal(
        initialDesign: design,
        onSave: (newDesign) async {
          setState(() => design = newDesign);
          await _saveProfileDesign();
        },
      ),
    );
  }

  // =============================
  // СТИЛИ ТЕКСТА
  // =============================
  TextStyle get _titleStyle => TextStyle(
        fontFamily: design.fontFamily != 'default' ? design.fontFamily : null,
        fontSize: design.titleFontSize,
        fontWeight: design.titleWeight,
        color: design.textPrimaryColor,
        height: 1.2,
      );

  TextStyle get _headingStyle => TextStyle(
        fontFamily: design.fontFamily != 'default' ? design.fontFamily : null,
        fontSize: design.headingFontSize,
        fontWeight: design.headingWeight,
        color: design.textPrimaryColor,
        height: 1.3,
      );

  TextStyle get _bodyStyle => TextStyle(
        fontFamily: design.fontFamily != 'default' ? design.fontFamily : null,
        fontSize: design.bodyFontSize,
        fontWeight: design.bodyWeight,
        color: design.textSecondaryColor,
        height: 1.4,
      );

  TextStyle get _smallStyle => TextStyle(
        fontFamily: design.fontFamily != 'default' ? design.fontFamily : null,
        fontSize: design.smallFontSize,
        fontWeight: design.bodyWeight,
        color: design.textTertiaryColor,
        height: 1.2,
      );

  // =============================
  // BUILD МЕТОД — CMR / CLUB WORKSPACE FLAGSHIP
  // =============================
  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final isDesktopWorkspace = _isDesktopOperatingSystem && width >= 1180;
    final isTabletWorkspace = !isDesktopWorkspace && width >= 720;
    final isVisitor = !isOwnProfile;

    return Scaffold(
      extendBody: true,
      backgroundColor: const Color(0xFFF6F7F6),
      appBar: isTabletWorkspace || _mobileWindowChild != null
          ? null
          : _buildFlagshipMobileAppBar(isVisitor),
      bottomNavigationBar:
          isOwnProfile && width < 720 ? _buildSocialBottomBar() : null,
      body: isLoadingProfile
          ? _buildFlagshipLoading()
          : isDesktopWorkspace
              ? _buildProfileDesktopWorkspace(isVisitor: isVisitor)
              : isTabletWorkspace
                  ? _buildProfileTabletWorkspace(isVisitor: isVisitor)
                  : _buildFlagshipPhoneOrTabletBody(
                      width: width,
                      isVisitor: isVisitor,
                    ),
    );
  }

  Widget _buildProfileTabletWorkspace({required bool isVisitor}) {
    return SafeArea(
      bottom: false,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return Stack(
            children: [
              Positioned.fill(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(8, 8, 8, 88),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      width: double.infinity,
                      color: Colors.white,
                      child: RefreshIndicator(
                        onRefresh: _loadInitialData,
                        color: const Color(0xFF00A750),
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 180),
                          switchInCurve: Curves.easeOutCubic,
                          switchOutCurve: Curves.easeInCubic,
                          child: KeyedSubtree(
                            key: ValueKey('tablet-${_profileWorkspaceSection}'),
                            child: _buildProfileWorkspaceBody(
                              compact: true,
                              isVisitor: isVisitor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              if (_mobileWindowChild != null)
                Positioned.fill(
                  bottom: 78,
                  child: _buildMobilePersistentWindow(),
                ),
              Positioned(
                left: 0,
                right: 0,
                bottom: 10,
                child: _buildProfileTabletTaskbar(),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildProfileTabletTaskbar() {
    final width = MediaQuery.of(context).size.width;
    final compact = width < 920;

    Widget divider() => Container(
          width: 1,
          height: 30,
          margin: const EdgeInsets.symmetric(horizontal: 7),
          color: const Color(0xFFE9ECEA),
        );

    Widget button({
      required IconData icon,
      required String tooltip,
      required VoidCallback onTap,
      bool active = false,
      bool system = false,
    }) {
      return Tooltip(
        message: tooltip,
        child: Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(16),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(16),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: active
                    ? const Color(0xFF344054)
                    : system
                        ? const Color(0xFFF7F9F8)
                        : Colors.transparent,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: system ? const Color(0xFFEFF2F5) : Colors.transparent,
                ),
                boxShadow: active
                    ? [
                        BoxShadow(
                          color: Colors.black.withOpacity(.11),
                          blurRadius: 16,
                          offset: const Offset(0, 7),
                        ),
                      ]
                    : const [],
              ),
              child: Icon(
                icon,
                size: 22,
                color: active ? Colors.white : const Color(0xFF344054),
              ),
            ),
          ),
        ),
      );
    }

    final apps = <Widget>[
      button(
        icon: Icons.home_rounded,
        tooltip: 'Главная',
        active:
            _profileWorkspaceSection == 'posts' && _mobileDockKey == 'profile',
        onTap: () {
          _closeMobileWindow(dockKey: 'profile');
          _selectProfileWorkspaceSection('posts');
        },
      ),
      button(
        icon: Icons.dynamic_feed_rounded,
        tooltip: 'Лента',
        active: _mobileDockKey == 'feed',
        onTap: _openCommunityFeedHome,
      ),
      button(
        icon: Icons.search_rounded,
        tooltip: 'Поиск людей',
        active: _mobileDockKey == 'search',
        onTap: _openPeopleSearchWindow,
      ),
      button(
        icon: Icons.play_circle_outline_rounded,
        tooltip: 'Видеоуроки',
        onTap: _openVideoLessonsWindow,
      ),
      button(
        icon: Icons.stadium_outlined,
        tooltip: 'Площадки',
        onTap: _openVenuesWindow,
      ),
      button(
        icon: Icons.forum_rounded,
        tooltip: 'Чаты',
        active: _mobileDockKey == 'chat',
        onTap: _openMainChat,
      ),
      button(
        icon: Icons.person_outline_rounded,
        tooltip: 'Профиль',
        onTap: () => _selectProfileWorkspaceSection('profile'),
      ),
    ];

    return Center(
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: math.min(width - 28, 1040.0),
        ),
        child: Container(
          height: 62,
          margin: const EdgeInsets.symmetric(horizontal: 8),
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(.97),
            borderRadius: BorderRadius.circular(21),
            border: Border.all(color: Colors.white.withOpacity(.82)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.11),
                blurRadius: 28,
                offset: const Offset(0, 14),
              ),
            ],
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              button(
                icon: Icons.grid_view_rounded,
                tooltip: 'Все разделы',
                onTap: _openProfileHomeMoreSheet,
                system: true,
              ),
              const SizedBox(width: 8),
              Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  onTap: _goToWorkspaceHub,
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    width: compact ? 44 : 118,
                    height: 44,
                    padding: EdgeInsets.symmetric(horizontal: compact ? 0 : 11),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3FAF6),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFD7F0E2)),
                    ),
                    child: Row(
                      mainAxisAlignment: compact
                          ? MainAxisAlignment.center
                          : MainAxisAlignment.start,
                      children: [
                        const Icon(
                          Icons.account_tree_outlined,
                          color: Color(0xFF067A46),
                          size: 20,
                        ),
                        if (!compact) ...[
                          const SizedBox(width: 8),
                          Text(
                            'Workspace',
                            style: AppTypography.custom(
                              size: 10.8,
                              weight: FontWeight.w600,
                              color: const Color(0xFF067A46),
                              height: 1.1,
                              letterSpacing: 0,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Material(
                color: Colors.transparent,
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  onTap: _openPeopleSearchWindow,
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    width: compact ? 44 : 132,
                    height: 44,
                    padding: EdgeInsets.symmetric(horizontal: compact ? 0 : 12),
                    decoration: BoxDecoration(
                      color: const Color(0xFFF7F9F8),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: const Color(0xFFEFF2F5)),
                    ),
                    child: Row(
                      mainAxisAlignment: compact
                          ? MainAxisAlignment.center
                          : MainAxisAlignment.start,
                      children: [
                        const Icon(Icons.search_rounded,
                            color: Color(0xFF344054), size: 21),
                        if (!compact) ...[
                          const SizedBox(width: 9),
                          Text(
                            'Поиск',
                            style: AppTypography.custom(
                              size: 11.8,
                              weight: FontWeight.w500,
                              color: const Color(0xFF667085),
                              height: 1.15,
                              letterSpacing: 0,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
              ),
              divider(),
              Flexible(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      for (final app in apps) ...[
                        app,
                        const SizedBox(width: 4),
                      ],
                    ],
                  ),
                ),
              ),
              divider(),
              button(
                icon: Icons.tune_rounded,
                tooltip: 'Настройки',
                onTap: () => _selectProfileWorkspaceSection('settings'),
                system: true,
              ),
              const SizedBox(width: 6),
              button(
                icon: Icons.refresh_rounded,
                tooltip: 'Обновить',
                onTap: _loadInitialData,
                system: true,
              ),
              const SizedBox(width: 6),
              button(
                icon: Icons.home_rounded,
                tooltip: 'Главная',
                onTap: () => _selectProfileWorkspaceSection('posts'),
                system: true,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileDesktopWorkspace({required bool isVisitor}) {
    return SafeArea(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final desktopSize = Size(constraints.maxWidth, constraints.maxHeight);
          _profileMainWindowPosition ??= const Offset(76, 34);
          _profileMainWindowSize ??= Size(
            max(720.0, desktopSize.width - 152),
            max(520.0, desktopSize.height - 134),
          );
          _profileModuleWindowPosition ??= Offset(
            desktopSize.width > 1380 ? 210 : 130,
            64,
          );
          _profileModuleWindowSize ??= Size(
            min(1120.0,
                desktopSize.width - (desktopSize.width > 1380 ? 330 : 200)),
            min(760.0, desktopSize.height - 182),
          );

          final windows = <({int z, Widget child})>[];
          if (!_profileMainWindowMinimized) {
            windows.add((
              z: _profileMainWindowZ,
              child: _buildPositionedProfileMainWindow(desktopSize, isVisitor),
            ));
          }
          if (_desktopRightPaneChild != null &&
              !_profileModuleWindowMinimized) {
            windows.add((
              z: _profileModuleWindowZ,
              child: _buildPositionedProfileModuleWindow(desktopSize),
            ));
          }
          windows.sort((a, b) => a.z.compareTo(b.z));

          return Stack(
            clipBehavior: Clip.none,
            children: [
              Positioned.fill(child: _buildProfileDesktopWallpaper()),
              Positioned(
                  left: 18, top: 24, child: _buildProfileDesktopShortcuts()),
              for (final window in windows) window.child,
              Positioned(
                left: 0,
                right: 0,
                bottom: 14,
                child: _buildProfileDesktopDock(),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildPositionedProfileMainWindow(Size desktopSize, bool isVisitor) {
    final maximized = _profileMainWindowMaximized;
    final frame = _buildProfileFloatingWindow(
      title: 'Мой профиль',
      subtitle: _activeWorkspaceName,
      icon: Icons.person_rounded,
      active: _profileMainWindowZ >= _profileModuleWindowZ ||
          _desktopRightPaneChild == null,
      maximized: maximized,
      onTap: () =>
          setState(() => _profileMainWindowZ = ++_profileWindowZCounter),
      onClose: () => Navigator.of(context).maybePop(),
      onMinimize: () => setState(() => _profileMainWindowMinimized = true),
      onMaximize: () => setState(() {
        _profileMainWindowMaximized = !_profileMainWindowMaximized;
        _profileMainWindowZ = ++_profileWindowZCounter;
      }),
      onDragUpdate: (delta) => _moveProfileMainWindow(delta, desktopSize),
      onResizeUpdate: (delta) => _resizeProfileMainWindow(delta, desktopSize),
      child: _buildProfileWorkspaceShell(
        compact: false,
        isVisitor: isVisitor,
        desktopWindow: true,
      ),
    );

    if (maximized) {
      return Positioned(left: 12, top: 12, right: 12, bottom: 92, child: frame);
    }

    final size = _safeProfileWindowSize(
      _profileMainWindowSize!,
      desktopSize,
      minWidth: 620,
      minHeight: 480,
    );
    final pos = _safeProfileWindowPosition(
        _profileMainWindowPosition!, size, desktopSize);
    return Positioned(
        left: pos.dx,
        top: pos.dy,
        width: size.width,
        height: size.height,
        child: frame);
  }

  Widget _buildPositionedProfileModuleWindow(Size desktopSize) {
    final maximized = _profileModuleWindowMaximized;
    final frame = _buildProfileFloatingWindow(
      title: _desktopRightPaneTitle.isEmpty
          ? 'Подробный просмотр'
          : _desktopRightPaneTitle,
      subtitle: _activeWorkspaceName,
      icon: _desktopRightPaneIcon,
      active: _profileModuleWindowZ >= _profileMainWindowZ,
      maximized: maximized,
      onTap: () =>
          setState(() => _profileModuleWindowZ = ++_profileWindowZCounter),
      onClose: () => setState(() {
        _desktopRightPaneChild = null;
        _desktopRightPaneTitle = '';
        _profileModuleWindowMinimized = false;
      }),
      onMinimize: () => setState(() => _profileModuleWindowMinimized = true),
      onMaximize: () => setState(() {
        _profileModuleWindowMaximized = !_profileModuleWindowMaximized;
        _profileModuleWindowZ = ++_profileWindowZCounter;
      }),
      onDragUpdate: (delta) => _moveProfileModuleWindow(delta, desktopSize),
      onResizeUpdate: (delta) => _resizeProfileModuleWindow(delta, desktopSize),
      child: _desktopRightPaneChild!,
    );

    if (maximized) {
      return Positioned(left: 12, top: 12, right: 12, bottom: 92, child: frame);
    }

    final size = _safeProfileWindowSize(
      _profileModuleWindowSize!,
      desktopSize,
      minWidth: 560,
      minHeight: 420,
    );
    final pos = _safeProfileWindowPosition(
        _profileModuleWindowPosition!, size, desktopSize);
    return Positioned(
        left: pos.dx,
        top: pos.dy,
        width: size.width,
        height: size.height,
        child: frame);
  }

  Size _safeProfileWindowSize(
    Size requested,
    Size desktopSize, {
    required double minWidth,
    required double minHeight,
  }) {
    final availableWidth = max(360.0, desktopSize.width - 24);
    final availableHeight = max(300.0, desktopSize.height - 106);
    return Size(
      requested.width
          .clamp(min(minWidth, availableWidth), availableWidth)
          .toDouble(),
      requested.height
          .clamp(min(minHeight, availableHeight), availableHeight)
          .toDouble(),
    );
  }

  Offset _safeProfileWindowPosition(
      Offset requested, Size size, Size desktopSize) {
    final maxX = max(8.0, desktopSize.width - size.width - 8);
    final maxY = max(8.0, desktopSize.height - size.height - 96);
    return Offset(
      requested.dx.clamp(8.0, maxX).toDouble(),
      requested.dy.clamp(8.0, maxY).toDouble(),
    );
  }

  void _moveProfileMainWindow(Offset delta, Size desktopSize) {
    setState(() {
      _profileMainWindowMaximized = false;
      _profileMainWindowZ = ++_profileWindowZCounter;
      final size = _profileMainWindowSize ?? const Size(1040, 680);
      _profileMainWindowPosition = _safeProfileWindowPosition(
        (_profileMainWindowPosition ?? const Offset(76, 34)) + delta,
        size,
        desktopSize,
      );
    });
  }

  void _resizeProfileMainWindow(Offset delta, Size desktopSize) {
    setState(() {
      _profileMainWindowMaximized = false;
      _profileMainWindowZ = ++_profileWindowZCounter;
      final position = _profileMainWindowPosition ?? const Offset(76, 34);
      final current = _profileMainWindowSize ?? const Size(1040, 680);
      _profileMainWindowSize = Size(
        (current.width + delta.dx)
            .clamp(620.0, max(620.0, desktopSize.width - position.dx - 12))
            .toDouble(),
        (current.height + delta.dy)
            .clamp(480.0, max(480.0, desktopSize.height - position.dy - 102))
            .toDouble(),
      );
    });
  }

  void _moveProfileModuleWindow(Offset delta, Size desktopSize) {
    setState(() {
      _profileModuleWindowMaximized = false;
      _profileModuleWindowZ = ++_profileWindowZCounter;
      final size = _profileModuleWindowSize ?? const Size(1040, 680);
      _profileModuleWindowPosition = _safeProfileWindowPosition(
        (_profileModuleWindowPosition ?? const Offset(130, 64)) + delta,
        size,
        desktopSize,
      );
    });
  }

  void _resizeProfileModuleWindow(Offset delta, Size desktopSize) {
    setState(() {
      _profileModuleWindowMaximized = false;
      _profileModuleWindowZ = ++_profileWindowZCounter;
      final position = _profileModuleWindowPosition ?? const Offset(130, 64);
      final current = _profileModuleWindowSize ?? const Size(1040, 680);
      _profileModuleWindowSize = Size(
        (current.width + delta.dx)
            .clamp(560.0, max(560.0, desktopSize.width - position.dx - 12))
            .toDouble(),
        (current.height + delta.dy)
            .clamp(420.0, max(420.0, desktopSize.height - position.dy - 102))
            .toDouble(),
      );
    });
  }

  Widget _buildProfileFloatingWindow({
    required String title,
    required String subtitle,
    required IconData icon,
    required bool active,
    required bool maximized,
    required VoidCallback onTap,
    required VoidCallback onClose,
    required VoidCallback onMinimize,
    required VoidCallback onMaximize,
    required ValueChanged<Offset> onDragUpdate,
    required ValueChanged<Offset> onResizeUpdate,
    required Widget child,
  }) {
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        curve: Curves.easeOutCubic,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(maximized ? 22 : 24),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(active ? .14 : .09),
              blurRadius: active ? 42 : 28,
              offset: Offset(0, active ? 22 : 14),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(maximized ? 22 : 24),
          child: Column(
            children: [
              GestureDetector(
                behavior: HitTestBehavior.opaque,
                onPanUpdate:
                    maximized ? null : (details) => onDragUpdate(details.delta),
                onDoubleTap: onMaximize,
                child: _buildCmrWindowTitleBar(
                  title: title,
                  subtitle: subtitle,
                  icon: icon,
                  onClose: onClose,
                  onMinimize: onMinimize,
                  onMaximize: onMaximize,
                  maximized: maximized,
                ),
              ),
              Expanded(
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: ColoredBox(
                        color: const Color(0xFFF7F9F8),
                        child: ClipRect(child: child),
                      ),
                    ),
                    if (!maximized)
                      Positioned(
                        right: 0,
                        bottom: 0,
                        child: GestureDetector(
                          behavior: HitTestBehavior.opaque,
                          onPanUpdate: (details) =>
                              onResizeUpdate(details.delta),
                          child: const SizedBox(
                            width: 28,
                            height: 28,
                            child: Align(
                              alignment: Alignment.bottomRight,
                              child: Padding(
                                padding: EdgeInsets.all(6),
                                child: Icon(Icons.open_in_full_rounded,
                                    size: 13, color: Color(0xFF98A2B3)),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileDesktopWallpaper() {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF4F8F5), Color(0xFFEAF4EE), Color(0xFFF7F8F7)],
        ),
      ),
      child: Align(
        alignment: Alignment.topRight,
        child: Container(
          width: 520,
          height: 520,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
              colors: [Color(0x2200A750), Color(0x0000A750)],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileDesktopMainWindow({required bool isVisitor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(.9)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.13),
              blurRadius: 42,
              spreadRadius: -18,
              offset: const Offset(0, 22),
            ),
          ],
        ),
        child: Column(
          children: [
            _buildCmrWindowTitleBar(
              title: 'Мой профиль',
              icon: Icons.person_rounded,
              onClose: () => Navigator.of(context).maybePop(),
            ),
            Expanded(
              child: _buildProfileWorkspaceShell(
                compact: false,
                isVisitor: isVisitor,
                desktopWindow: true,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileDesktopShortcuts() {
    final items = <({IconData icon, String title, VoidCallback tap})>[
      (
        icon: Icons.dynamic_feed_rounded,
        title: 'Лента',
        tap: _openCommunityFeedHome
      ),
      (
        icon: Icons.search_rounded,
        title: 'Поиск',
        tap: _openPeopleSearchWindow
      ),
      (
        icon: Icons.school_outlined,
        title: 'Уроки',
        tap: _openVideoLessonsWindow
      ),
      (icon: Icons.stadium_outlined, title: 'Площадки', tap: _openVenuesWindow),
      (icon: Icons.forum_outlined, title: 'Чаты', tap: _openMainChat),
      (
        icon: Icons.person_outline_rounded,
        title: 'Профиль',
        tap: () => _selectProfileWorkspaceSection('profile')
      ),
    ];
    return Column(
      children: items
          .map((item) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: InkWell(
                  onTap: item.tap,
                  borderRadius: BorderRadius.circular(16),
                  child: SizedBox(
                    width: 76,
                    child: Column(
                      children: [
                        Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(.86),
                            borderRadius: BorderRadius.circular(15),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.black.withOpacity(.08),
                                  blurRadius: 16,
                                  offset: const Offset(0, 7))
                            ],
                          ),
                          child: Icon(item.icon,
                              color: const Color(0xFF16794B), size: 24),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          item.title,
                          textAlign: TextAlign.center,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.custom(
                            size: 9.2,
                            weight: FontWeight.w600,
                            color: const Color(0xFF344054),
                            height: 1.12,
                            letterSpacing: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ))
          .toList(),
    );
  }

  Widget _buildProfileDesktopDock() {
    // На ПК используем тот же нижний flagship-taskbar, что и на планшете.
    // Так навигация и «Ещё» выглядят одинаково на больших экранах.
    return _buildProfileTabletTaskbar();
  }

  Widget _buildFlagshipPhoneOrTabletBody({
    required double width,
    required bool isVisitor,
  }) {
    Widget profileScroll() {
      return RefreshIndicator(
        onRefresh: _loadInitialData,
        color: const Color(0xFF00A750),
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(child: _buildFlagshipMobileProfile()),
            if (isVisitor)
              const SliverToBoxAdapter(child: SizedBox(height: 20)),
            const SliverToBoxAdapter(child: SizedBox(height: 18)),
          ],
        ),
      );
    }

    return Stack(
      children: [
        Positioned.fill(child: profileScroll()),
        if (_mobileWindowChild != null)
          Positioned.fill(child: _buildMobilePersistentWindow()),
      ],
    );
  }

  void _selectProfileWorkspaceSection(String section) {
    if (!mounted) return;
    setState(() {
      _profileWorkspaceSection = section;
      _profileMainWindowMinimized = false;
      _profileMainWindowZ = ++_profileWindowZCounter;
      _desktopRightPaneChild = null;
      _desktopRightPaneTitle = '';
      _openedProfilePost = null;
      if (section == 'posts') {
        _mode = _ProfileFeedMode.posts;
        _mobileDockKey = 'profile';
      }
      if (section == 'feed') {
        _mode = _ProfileFeedMode.feed;
        _mobileDockKey = 'feed';
      }
      if (section == 'reels') {
        _mode = _ProfileFeedMode.reels;
        _mobileDockKey = 'reels';
      }
      if (section == 'profile') _mobileDockKey = 'account';
    });
  }

  Widget _buildProfileWorkspaceShell({
    required bool compact,
    required bool isVisitor,
    bool desktopWindow = false,
  }) {
    final dockInset =
        isOwnProfile ? MediaQuery.paddingOf(context).bottom + 76.0 : 16.0;

    return SafeArea(
      bottom: false,
      child: Container(
        color: desktopWindow ? Colors.white : const Color(0xFFF6F7F6),
        padding: desktopWindow
            ? EdgeInsets.zero
            : EdgeInsets.fromLTRB(
                compact ? 8 : 10,
                compact ? 8 : 10,
                compact ? 8 : 10,
                dockInset,
              ),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1480),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(compact ? 24 : 28),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(compact ? 24 : 28),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.035),
                      blurRadius: 28,
                      spreadRadius: -18,
                      offset: const Offset(0, 16),
                    ),
                  ],
                ),
                child: Stack(
                  children: [
                    Positioned.fill(
                      child: Column(
                        children: [
                          _buildProfileWorkspaceTopBar(compact: compact),
                          Expanded(
                            child: desktopWindow
                                ? AnimatedSwitcher(
                                    duration: const Duration(milliseconds: 190),
                                    switchInCurve: Curves.easeOutCubic,
                                    switchOutCurve: Curves.easeInCubic,
                                    child: KeyedSubtree(
                                      key: ValueKey(
                                          'desktop-${_profileWorkspaceSection}'),
                                      child: _buildProfileWorkspaceBody(
                                        compact: false,
                                        isVisitor: isVisitor,
                                      ),
                                    ),
                                  )
                                : Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      SizedBox(
                                        width: compact ? 270 : 304,
                                        child: _buildProfileWorkspaceNavigation(
                                          compact: compact,
                                          isVisitor: isVisitor,
                                        ),
                                      ),
                                      Container(
                                        width: .7,
                                        color: const Color(0xFFE9ECEA),
                                      ),
                                      Expanded(
                                        child: AnimatedSwitcher(
                                          duration:
                                              const Duration(milliseconds: 190),
                                          switchInCurve: Curves.easeOutCubic,
                                          switchOutCurve: Curves.easeInCubic,
                                          child: KeyedSubtree(
                                            key: ValueKey(
                                                _profileWorkspaceSection),
                                            child: _buildProfileWorkspaceBody(
                                              compact: compact,
                                              isVisitor: isVisitor,
                                            ),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                          ),
                        ],
                      ),
                    ),
                    if (_mobileWindowChild != null)
                      Positioned.fill(child: _buildMobilePersistentWindow()),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProfileWorkspaceNavigation({
    required bool compact,
    required bool isVisitor,
  }) {
    Widget item({
      required String id,
      required String title,
      required String subtitle,
      required IconData icon,
      VoidCallback? onTap,
      bool danger = false,
    }) {
      final active = _profileWorkspaceSection == id;
      final foreground = danger
          ? const Color(0xFFE11D48)
          : active
              ? const Color(0xFF067A46)
              : const Color(0xFF344054);

      return InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap ?? () => _selectProfileWorkspaceSection(id),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 170),
          margin: const EdgeInsets.only(bottom: 4),
          padding: EdgeInsets.fromLTRB(compact ? 9 : 11, 9, 8, 9),
          decoration: BoxDecoration(
            color: active ? const Color(0xFFF3FAF6) : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              AnimatedContainer(
                duration: const Duration(milliseconds: 170),
                width: 4,
                height: active ? 34 : 0,
                decoration: BoxDecoration(
                  color: const Color(0xFF00A750),
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              SizedBox(width: active ? 8 : 11),
              Icon(icon, size: 18, color: foreground),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _flagshipText(
                        11.3,
                        color: foreground,
                        weight: active ? FontWeight.w800 : FontWeight.w600,
                      ),
                    ),
                    if (!compact) ...[
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _flagshipText(
                          8.9,
                          color: danger
                              ? const Color(0xFFBE123C)
                              : const Color(0xFF98A2B3),
                          weight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Container(
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(compact ? 6 : 8, 8, compact ? 6 : 8, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFlagshipAccountMini(),
          const SizedBox(height: 8),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                item(
                  id: 'posts',
                  title: 'Публикации',
                  subtitle: 'фото и посты профиля',
                  icon: Icons.grid_on_rounded,
                ),
                item(
                  id: 'feed',
                  title: 'Лента',
                  subtitle: 'публикации списком',
                  icon: Icons.article_outlined,
                ),
                item(
                  id: 'reels',
                  title: 'Reels',
                  subtitle: 'короткие спортивные видео',
                  icon: Icons.play_circle_outline_rounded,
                ),
                if (!isVisitor) ...[
                  const Padding(
                    padding: EdgeInsets.fromLTRB(10, 14, 10, 6),
                    child: Text(
                      'ЛИЧНОЕ',
                      style: TextStyle(
                        fontSize: 8.5,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF98A2B3),
                        letterSpacing: .55,
                      ),
                    ),
                  ),
                  item(
                    id: 'community',
                    title: 'Лента',
                    subtitle: 'новости и публикации сообщества',
                    icon: Icons.newspaper_rounded,
                    onTap: _openCommunityFeedHome,
                  ),
                  item(
                    id: 'search',
                    title: 'Поиск людей',
                    subtitle: 'игроки, тренеры и пользователи',
                    icon: Icons.person_search_outlined,
                    onTap: _openPeopleSearchWindow,
                  ),
                  item(
                    id: 'lessons',
                    title: 'Видеоуроки',
                    subtitle: 'обучение и спортивные материалы',
                    icon: Icons.school_outlined,
                    onTap: _openVideoLessonsWindow,
                  ),
                  item(
                    id: 'venues',
                    title: 'Площадки',
                    subtitle: 'каталог и бронирование',
                    icon: Icons.stadium_outlined,
                    onTap: _openVenuesWindow,
                  ),
                  item(
                    id: 'chat',
                    title: 'Чаты',
                    subtitle: 'личные сообщения и группы',
                    icon: Icons.forum_outlined,
                    onTap: _openMainChat,
                  ),
                  const Padding(
                    padding: EdgeInsets.fromLTRB(10, 14, 10, 6),
                    child: Text(
                      'АККАУНТ',
                      style: TextStyle(
                        fontSize: 8.5,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF98A2B3),
                        letterSpacing: .55,
                      ),
                    ),
                  ),
                  item(
                    id: 'settings',
                    title: 'Настройки',
                    subtitle: 'профиль и доступ',
                    icon: Icons.settings_outlined,
                  ),
                  item(
                    id: 'more',
                    title: 'Все разделы',
                    subtitle: 'сервисы, события и медиа',
                    icon: Icons.grid_view_rounded,
                    onTap: _openProfileHomeMoreSheet,
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileWorkspaceTopBar({required bool compact}) {
    String title;
    String subtitle;
    IconData icon;

    switch (_profileWorkspaceSection) {
      case 'embedded':
        title =
            _desktopRightPaneTitle.isEmpty ? 'Раздел' : _desktopRightPaneTitle;
        subtitle = 'Рабочая область SPORTOTEKA';
        icon = _desktopRightPaneIcon;
        break;
      case 'community':
        title = 'Соцлента и новости';
        subtitle = 'Публикации игроков, тренеров и клубов';
        icon = Icons.newspaper_rounded;
        break;
      case 'posts':
        title = 'Публикации профиля';
        subtitle = 'Фото и посты пользователя';
        icon = Icons.grid_on_rounded;
        break;
      case 'feed':
        title = 'Лента профиля';
        subtitle = 'Публикации в подробном виде';
        icon = Icons.article_outlined;
        break;
      case 'reels':
        title = 'Reels профиля';
        subtitle = 'Короткие спортивные видео';
        icon = Icons.play_circle_outline_rounded;
        break;
      case 'profile':
        title = 'Мой профиль';
        subtitle = 'Профиль, публикации и личная информация';
        icon = Icons.person_outline_rounded;
        break;
      case 'settings':
        title = 'Настройки профиля';
        subtitle = 'Данные аккаунта, доступ и управление';
        icon = Icons.settings_outlined;
        break;
      default:
        title = 'Публикации профиля';
        subtitle = 'Фото и посты пользователя';
        icon = Icons.grid_on_rounded;
    }

    return Container(
      height: compact ? 52 : 58,
      padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(color: Color(0xFFE9ECEA), width: .7),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFF1FBF6),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, size: 17, color: const Color(0xFF00A750)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _flagshipTitle(14.2, weight: FontWeight.w700),
                ),
                if (!compact) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _flagshipText(10, color: const Color(0xFF8A9099)),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileWorkspaceBody({
    required bool compact,
    required bool isVisitor,
  }) {
    if (_profileWorkspaceSection == 'embedded' &&
        _desktopRightPaneChild != null) {
      return ColoredBox(
        color: Colors.white,
        child: KeyedSubtree(
          key: ValueKey(_desktopRightPaneTitle),
          child: _desktopRightPaneChild!,
        ),
      );
    }

    if (_profileWorkspaceSection == 'community') {
      return const SportCommunityScreen(
        sportName: 'Футбол',
        embedded: true,
      );
    }

    if (_profileWorkspaceSection == 'profile') {
      return SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.all(compact ? 12 : 16),
        child: Column(
          children: [
            _buildFlagshipProfileCard(),
            SizedBox(height: compact ? 20 : 8),
          ],
        ),
      );
    }

    if (_profileWorkspaceSection == 'settings') {
      return SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: EdgeInsets.all(compact ? 12 : 16),
        child: Column(
          children: [
            _buildFlagshipProfileCard(),
            const SizedBox(height: 10),
            _buildFlagshipSettingsPanel(),
            SizedBox(height: compact ? 20 : 8),
          ],
        ),
      );
    }

    if (_profileWorkspaceSection == 'posts') {
      return _buildTabletPublicationsSplit(compact: compact);
    }

    if (_profileWorkspaceSection == 'feed' ||
        _profileWorkspaceSection == 'reels') {
      return SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.only(bottom: compact ? 20 : 8),
        child: _buildFlagshipContentWindow(),
      );
    }

    // Любое неизвестное состояние возвращаем к публикациям, а не к обзору.
    return _buildTabletPublicationsSplit(compact: compact);
  }

  Map<String, dynamic> _profileGridPostToDetail(Map<String, dynamic> post) {
    final rawBody = _safeStr(post['body'] ?? post['text'] ?? post['caption']);
    final body = _looksLikeHtml(rawBody) ? _htmlToPlain(rawBody) : rawBody;
    final image = _fixUrl(_safeStr(
      post['imageUrl'] ?? post['image_url'] ?? post['image'] ?? post['photo'],
    ));
    final category = _safeStr(post['category']).trim();
    final rawTitle = _safeStr(post['title']).trim();

    return <String, dynamic>{
      'id': _safeInt(post['id']),
      'title': rawTitle.isNotEmpty
          ? rawTitle
          : (category.isNotEmpty ? category : 'Публикация профиля'),
      'text': body,
      'imageUrl': image,
      'category': category.isNotEmpty ? category : 'Профиль',
      'authorName': fullName,
      'authorAvatar': _fixUrl(photo ?? ''),
      'likes': _safeInt(post['likes_count'] ?? post['likes']),
      'comments': _safeInt(post['comments_count'] ?? post['comments']),
    };
  }

  Widget _buildTabletPublicationsSplit({required bool compact}) {
    final selected = _openedProfilePost;
    final leftWidthFactor = compact ? .53 : .57;

    return LayoutBuilder(
      builder: (context, constraints) {
        final leftWidth = constraints.maxWidth * leftWidthFactor;

        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(
              width: leftWidth,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: EdgeInsets.fromLTRB(
                  compact ? 10 : 14,
                  compact ? 10 : 14,
                  compact ? 8 : 12,
                  compact ? 20 : 14,
                ),
                child: _buildFlagshipContentWindow(),
              ),
            ),
            Container(width: 1, color: const Color(0xFFE9ECEA)),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 190),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: selected == null
                    ? _buildPublicationSelectionPlaceholder(compact: compact)
                    : Container(
                        key: ValueKey(
                            'tablet-profile-post-${_safeInt(selected['id'])}'),
                        color: Colors.white,
                        child: NewsDetailScreen(
                          title: _safeStr(selected['title']).trim().isNotEmpty
                              ? _safeStr(selected['title']).trim()
                              : 'Публикация',
                          body: _safeStr(selected['text']),
                          newsId: _safeInt(selected['id']),
                          imageUrl: _safeStr(selected['imageUrl']),
                          embedded: true,
                          onClose: _closeTabletProfilePost,
                        ),
                      ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCmrPublicationDetail(
    Map<String, dynamic> post, {
    required bool compact,
  }) {
    final title = _safeStr(post['title']).trim().isNotEmpty
        ? _safeStr(post['title']).trim()
        : 'Публикация';
    final body = _safeStr(post['text']).trim();
    final imageUrl = _safeStr(post['imageUrl']).trim();
    final likes = _safeInt(post['likes']);
    final comments = _safeInt(post['comments']);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          height: compact ? 54 : 58,
          padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(
              bottom: BorderSide(color: Color(0xFFE9ECEA), width: .7),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3FAF6),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: const Icon(
                  Icons.article_outlined,
                  size: 17,
                  color: Color(0xFF00A750),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Просмотр публикации',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _flagshipTitle(13.6, weight: FontWeight.w700),
                    ),
                    if (!compact) ...[
                      const SizedBox(height: 2),
                      Text(
                        fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style:
                            _flagshipText(9.8, color: const Color(0xFF8A9099)),
                      ),
                    ],
                  ],
                ),
              ),
              InkWell(
                onTap: _closeTabletProfilePost,
                borderRadius: BorderRadius.circular(10),
                child: Container(
                  width: 34,
                  height: 34,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F8F7),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(
                    Icons.close_rounded,
                    size: 17,
                    color: Color(0xFF5F6670),
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.all(compact ? 12 : 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  padding: EdgeInsets.all(compact ? 12 : 14),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F8F7),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Row(
                    children: [
                      _buildFlagshipAvatar(
                          size: compact ? 46 : 52,
                          hasAvatar: photo != null && photo!.trim().isNotEmpty),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              fullName,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style:
                                  _flagshipTitle(12.6, weight: FontWeight.w700),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              _roleLabel,
                              style: _flagshipText(9.8,
                                  color: const Color(0xFF8A9099)),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                if (imageUrl.isNotEmpty)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Container(
                      width: double.infinity,
                      color: const Color(0xFFF4F5F4),
                      child: Image.network(
                        imageUrl,
                        width: double.infinity,
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => Container(
                          constraints: const BoxConstraints(minHeight: 180),
                          color: const Color(0xFFF2F4F2),
                          alignment: Alignment.center,
                          child: const Icon(
                            Icons.broken_image_outlined,
                            color: Color(0xFF8A9099),
                            size: 34,
                          ),
                        ),
                      ),
                    ),
                  ),
                if (imageUrl.isNotEmpty) const SizedBox(height: 14),
                Text(
                  title,
                  style: _flagshipTitle(compact ? 17 : 19,
                      weight: FontWeight.w700),
                ),
                if (body.isNotEmpty) ...[
                  const SizedBox(height: 9),
                  Text(
                    body,
                    style: _flagshipText(
                      compact ? 11.7 : 12.4,
                      color: const Color(0xFF374151),
                      height: 1.48,
                    ),
                  ),
                ],
                const SizedBox(height: 16),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF7F8F7),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.favorite_border_rounded,
                          size: 17, color: Color(0xFF5F6670)),
                      const SizedBox(width: 6),
                      Text('$likes',
                          style: _flagshipText(10.8, weight: FontWeight.w600)),
                      const SizedBox(width: 18),
                      const Icon(Icons.mode_comment_outlined,
                          size: 17, color: Color(0xFF5F6670)),
                      const SizedBox(width: 6),
                      Text('$comments',
                          style: _flagshipText(10.8, weight: FontWeight.w600)),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPublicationSelectionPlaceholder({required bool compact}) {
    return Container(
      key: const ValueKey('publication-placeholder'),
      color: const Color(0xFFFCFDFC),
      padding: EdgeInsets.all(compact ? 22 : 34),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 390),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: compact ? 64 : 72,
                height: compact ? 64 : 72,
                decoration: BoxDecoration(
                  color: const Color(0xFFF1FBF6),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Icon(
                  Icons.touch_app_rounded,
                  size: compact ? 29 : 32,
                  color: const Color(0xFF00A750),
                ),
              ),
              const SizedBox(height: 16),
              Text(
                'Выберите публикацию',
                textAlign: TextAlign.center,
                style:
                    _flagshipTitle(compact ? 17 : 19, weight: FontWeight.w700),
              ),
              const SizedBox(height: 7),
              Text(
                'Нажмите на фото или пост слева — подробная публикация откроется здесь, не закрывая профиль и нижнее меню.',
                textAlign: TextAlign.center,
                style: _flagshipText(
                  compact ? 11.5 : 12.2,
                  color: const Color(0xFF667085),
                  height: 1.42,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDesktopWorkspaceOverlay(Widget overlay) {
    return Container(
      color: const Color(0xFFF4F6F5),
      padding: const EdgeInsets.all(8),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Container(
          color: Colors.white,
          child: Column(
            children: [
              Container(
                height: 54,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  border: Border(
                    bottom: BorderSide(color: Color(0xFFE9ECEA), width: .7),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: const Color(0xFFF3FAF6),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(
                        _desktopRightPaneIcon,
                        size: 17,
                        color: const Color(0xFF00A750),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        _desktopRightPaneTitle.isEmpty
                            ? 'Подробный просмотр'
                            : _desktopRightPaneTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _flagshipTitle(14.2, weight: FontWeight.w700),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        if (!mounted) return;
                        setState(() {
                          _desktopRightPaneChild = null;
                          _desktopRightPaneTitle = '';
                        });
                      },
                      borderRadius: BorderRadius.circular(10),
                      child: Container(
                        width: 36,
                        height: 36,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: const Color(0xFFF7F8F7),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(
                          Icons.close_rounded,
                          size: 18,
                          color: Color(0xFF5F6670),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(child: overlay),
            ],
          ),
        ),
      ),
    );
  }

  // =============================
  // НОВЫЕ МЕТОДЫ ПОСТРОЕНИЯ UI
  // =============================

  PreferredSizeWidget _buildFlagshipMobileAppBar(bool isVisitor) {
    final creatingReel = _mode == _ProfileFeedMode.reels;

    return AppBar(
      toolbarHeight: 44,
      backgroundColor: Colors.white,
      elevation: 0,
      surfaceTintColor: Colors.white,
      automaticallyImplyLeading: false,
      centerTitle: false,
      titleSpacing: 12,
      title: Text(
        fullName,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: _flagshipTitle(
          14.6,
          weight: FontWeight.w600,
        ),
      ),
      actions: [
        if (!isVisitor) ...[
          Tooltip(
            message: 'Поиск',
            child: IconButton(
              onPressed: _openPeopleSearchWindow,
              visualDensity: VisualDensity.compact,
              icon: const Icon(
                Icons.search_rounded,
                size: 21,
                color: Color(0xFF111827),
              ),
            ),
          ),
          Tooltip(
            message: 'Создать',
            child: IconButton(
              onPressed: _openContextualProfileCreate,
              visualDensity: VisualDensity.compact,
              icon: Container(
                width: 25,
                height: 25,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: const Color(0xFF00A750),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Icon(
                  Icons.add_rounded,
                  size: 18,
                  color: Colors.white,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 7),
            child: _buildImportantNotificationButton(),
          ),
        ],
      ],
    );
  }

  Widget _buildFlagshipDotCluster({
    Color color = const Color(0xFF00A750),
    bool compact = false,
  }) {
    final values = compact
        ? const <List<double>>[
            <double>[3.0, .34],
            <double>[3.8, .48],
            <double>[4.6, .68],
            <double>[5.4, 1],
          ]
        : const <List<double>>[
            <double>[3.5, .34],
            <double>[4.5, .48],
            <double>[5.5, .68],
            <double>[6.5, 1],
          ];

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (int i = 0; i < values.length; i++) ...[
          Container(
            width: values[i][0],
            height: values[i][0],
            decoration: BoxDecoration(
              color: color.withOpacity(values[i][1]),
              shape: BoxShape.circle,
            ),
          ),
          if (i != values.length - 1) const SizedBox(width: 3),
        ],
      ],
    );
  }

  Widget _buildImportantNotificationButton() {
    final hasImportant = _importantNotificationCount > 0;

    return Tooltip(
      message: 'Важные уведомления',
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(9),
        child: InkWell(
          onTap: _openImportantNotifications,
          borderRadius: BorderRadius.circular(9),
          child: SizedBox(
            width: 34,
            height: 34,
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                const Center(
                  child: Icon(
                    Icons.notifications_none_rounded,
                    size: 20,
                    color: Color(0xFF111827),
                  ),
                ),
                if (hasImportant)
                  Positioned(
                    top: 0,
                    right: -1,
                    child: Container(
                      constraints: const BoxConstraints(
                        minWidth: 15,
                        minHeight: 15,
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 3),
                      decoration: BoxDecoration(
                        color: const Color(0xFFD92D20),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(color: Colors.white, width: 1.2),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        _importantNotificationCount > 99
                            ? '99+'
                            : '$_importantNotificationCount',
                        style: AppTypography.custom(
                          size: 7.4,
                          weight: FontWeight.w700,
                          color: Colors.white,
                          height: 1,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _openImportantNotifications() async {
    final myId = await PrefUtils.getUserId() ?? widget.userId ?? 0;
    if (!mounted || myId <= 0) return;

    _openCmrWindow(
      title: 'Уведомления',
      icon: Icons.notifications_none_rounded,
      maxWidth: 900,
      maxHeight: 760,
      child: CmrNotificationsPanel(
        userId: myId,
        onUnreadChanged: (value) {
          if (!mounted) return;
          setState(() => _importantNotificationCount = value);
        },
      ),
    );
  }

  Widget _buildFlagshipLoading() {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        decoration: _flagshipPanel(radius: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                  color: Color(0xFF00A750), strokeWidth: 2.4),
            ),
            const SizedBox(width: 12),
            Text('Загружаем профиль',
                style: _flagshipText(12.5, weight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }

  TextStyle _flagshipTitle(
    double size, {
    Color color = const Color(0xFF0B0F14),
    FontWeight weight = FontWeight.w600,
  }) {
    return AppTypography.custom(
      size: size,
      weight: weight,
      color: color,
      height: 1.18,
      letterSpacing: 0,
    );
  }

  TextStyle _flagshipText(
    double size, {
    Color color = const Color(0xFF5F6670),
    FontWeight weight = FontWeight.w400,
    double height = 1.30,
  }) {
    return AppTypography.custom(
      size: size,
      weight: weight,
      color: color,
      height: height,
      letterSpacing: 0,
    );
  }

  BoxDecoration _flagshipPanel({
    double radius = 20,
    bool elevated = true,
    Color color = Colors.white,
  }) {
    return BoxDecoration(
      color: color,
      borderRadius: BorderRadius.circular(radius),
    );
  }

  BoxDecoration _flagshipSoft({
    double radius = 16,
    bool active = false,
  }) {
    return BoxDecoration(
      color: active ? const Color(0xFFF3FAF6) : Colors.transparent,
      borderRadius: BorderRadius.circular(radius),
      border: active
          ? const Border(
              left: BorderSide(color: Color(0xFF00A750), width: 3),
            )
          : null,
    );
  }

  List<_ProfileFlagshipAction> get _flagshipWorkspaceActions {
    if (_isPublicProfileView) {
      return [
        _ProfileFlagshipAction(
            'Публикации',
            'фото и посты профиля',
            Icons.grid_on_rounded,
            () => _selectProfileWorkspaceSection('posts'),
            group: 'Профиль',
            primary: true),
        _ProfileFlagshipAction(
            'Reels профиля',
            'короткие видео игрока',
            Icons.play_circle_fill_rounded,
            () => setState(() => _mode = _ProfileFeedMode.reels),
            group: 'Профиль'),
        _ProfileFlagshipAction(
            'Лента профиля',
            'публикации списком',
            Icons.article_outlined,
            () => setState(() => _mode = _ProfileFeedMode.feed),
            group: 'Профиль'),
        _ProfileFlagshipAction(isFollowing ? 'Вы подписаны' : 'Подписаться',
            'следить за обновлениями', Icons.person_add_alt_1_rounded, () {
          _toggleFollow();
        }, group: 'Действия'),
        _ProfileFlagshipAction(
            'Написать', 'личное сообщение', Icons.chat_bubble_outline_rounded,
            () {
          _openPrivateChat();
        }, group: 'Действия'),
      ];
    }

    return [
      if (isOwnProfile)
        _ProfileFlagshipAction(
            'Выйти в Workspace',
            'закрыть профиль и выбрать рабочий кабинет',
            Icons.account_tree_outlined,
            _goToWorkspaceHub,
            group: 'Навигация',
            primary: true),
      _ProfileFlagshipAction('Лента', 'новости и публикации сообщества',
          Icons.dynamic_feed_rounded, _openCommunityFeedHome,
          group: 'Основное'),
      _ProfileFlagshipAction('Поиск людей', 'игроки, тренеры и пользователи',
          Icons.person_search_outlined, _openPeopleSearchWindow,
          group: 'Основное'),
      _ProfileFlagshipAction('Чаты', 'личные сообщения и группы',
          Icons.forum_rounded, _openMainChat,
          group: 'Основное'),
      _ProfileFlagshipAction('Видеоуроки', 'обучение и спортивные материалы',
          Icons.school_rounded, _openVideoLessonsWindow,
          group: 'Обучение'),
      _ProfileFlagshipAction(
          'Сохранённое · скоро',
          'уроки, публикации, люди и площадки',
          Icons.bookmark_border_rounded,
          _openSavedWindow,
          group: 'Обучение'),
      _ProfileFlagshipAction(
          'Площадки',
          'каталог доступен · раздел дополняется',
          Icons.stadium_rounded,
          _openVenuesWindow,
          group: 'Сервисы'),
      _ProfileFlagshipAction(
          'Игры рядом · скоро',
          'открытые игры, спарринги и поиск игроков',
          Icons.sports_soccer_rounded,
          _openNearbyGamesWindow,
          group: 'Сервисы'),
      _ProfileFlagshipAction(
          'Тренировки рядом · скоро',
          'открытые занятия тренеров и клубов',
          Icons.directions_run_rounded,
          _openNearbyTrainingsWindow,
          group: 'Сервисы'),
      _ProfileFlagshipAction('Публикации профиля', 'фото и посты пользователя',
          Icons.grid_on_rounded, () => _selectProfileWorkspaceSection('posts'),
          group: 'Профиль'),
      _ProfileFlagshipAction(
          'Reels профиля',
          'короткие видео пользователя',
          Icons.play_circle_outline_rounded,
          () => setState(() => _mode = _ProfileFeedMode.reels),
          group: 'Профиль'),
      if (isOwnProfile)
        _ProfileFlagshipAction(
            isClubRole ? 'Логотип / аватар' : 'Аватарка',
            _profileMediaEditSubtitle,
            Icons.add_a_photo_outlined,
            _openProfileMediaPickerSheet,
            group: 'Профиль'),
      _ProfileFlagshipAction('Настройки', 'профиль и доступ',
          Icons.settings_outlined, _openProfileSettingsSheet,
          group: 'Аккаунт'),
      _ProfileFlagshipAction('PRO подписка', 'расширенные возможности',
          Icons.workspace_premium_rounded, _openSubscriptionWindow,
          group: 'Аккаунт', pro: true),
      if (isOwnProfile)
        _ProfileFlagshipAction('Выйти из профиля', 'завершить текущую сессию',
            Icons.logout_rounded, _logoutFromProfile,
            group: 'Аккаунт'),
      if (isOwnProfile)
        _ProfileFlagshipAction(
            'Удалить профиль',
            'безвозвратное удаление аккаунта',
            Icons.delete_forever_rounded,
            _deleteOwnProfileWithConfirmation,
            group: 'Аккаунт',
            danger: true),
    ];
  }

  Widget _buildFlagshipDesktopProfile() {
    if (_isPublicProfileView) {
      return _buildFlagshipDesktopPublicProfile();
    }

    final Widget? overlay = _desktopRightPaneChild;

    Widget mainContent() {
      return CustomScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        slivers: [
          SliverToBoxAdapter(child: _buildFlagshipDesktopHeader()),
          const SliverToBoxAdapter(child: SizedBox(height: 10)),
          SliverToBoxAdapter(child: _buildFlagshipProfileWorkspaceRow()),
          const SliverToBoxAdapter(child: SizedBox(height: 10)),
          SliverToBoxAdapter(child: _buildFlagshipContentWindow()),
          const SliverToBoxAdapter(child: SizedBox(height: 18)),
        ],
      );
    }

    return SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1480),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(width: 228, child: _buildFlagshipDesktopMenu()),
                const SizedBox(width: 14),
                Expanded(
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Stack(
                      children: [
                        Positioned.fill(child: mainContent()),
                        if (overlay != null)
                          Positioned.fill(
                            child: Container(
                              color: const Color(0xFFF4F6F5),
                              padding: const EdgeInsets.all(8),
                              child: ClipRRect(
                                borderRadius: BorderRadius.circular(18),
                                child: Container(
                                  color: Colors.white,
                                  child: Column(
                                    children: [
                                      Container(
                                        height: 54,
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 14),
                                        decoration: const BoxDecoration(
                                          color: Colors.white,
                                          border: Border(
                                            bottom: BorderSide(
                                              color: Color(0xFFE9ECEA),
                                              width: .7,
                                            ),
                                          ),
                                        ),
                                        child: Row(
                                          children: [
                                            Container(
                                              width: 34,
                                              height: 34,
                                              decoration: BoxDecoration(
                                                color: const Color(0xFFF3FAF6),
                                                borderRadius:
                                                    BorderRadius.circular(10),
                                              ),
                                              child: Icon(
                                                _desktopRightPaneIcon,
                                                size: 17,
                                                color: const Color(0xFF00A750),
                                              ),
                                            ),
                                            const SizedBox(width: 10),
                                            Expanded(
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                    _desktopRightPaneTitle
                                                            .isEmpty
                                                        ? 'Публикация'
                                                        : _desktopRightPaneTitle,
                                                    maxLines: 1,
                                                    overflow:
                                                        TextOverflow.ellipsis,
                                                    style: _flagshipTitle(
                                                      14.2,
                                                      weight: FontWeight.w700,
                                                    ),
                                                  ),
                                                  const SizedBox(height: 2),
                                                  Text(
                                                    'Подробный просмотр',
                                                    style: _flagshipText(
                                                      10.2,
                                                      color: const Color(
                                                          0xFF8A9099),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            InkWell(
                                              onTap: () {
                                                if (!mounted) return;
                                                setState(() {
                                                  _desktopRightPaneChild = null;
                                                  _desktopRightPaneTitle = '';
                                                });
                                              },
                                              borderRadius:
                                                  BorderRadius.circular(10),
                                              child: Container(
                                                width: 36,
                                                height: 36,
                                                alignment: Alignment.center,
                                                decoration: BoxDecoration(
                                                  color:
                                                      const Color(0xFFF7F8F7),
                                                  borderRadius:
                                                      BorderRadius.circular(10),
                                                ),
                                                child: const Icon(
                                                  Icons.close_rounded,
                                                  size: 18,
                                                  color: Color(0xFF5F6670),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                      Expanded(child: overlay),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFlagshipDesktopPublicProfile() {
    return SafeArea(
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 980),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 16),
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildFlagshipDesktopHeader()),
                const SliverToBoxAdapter(child: SizedBox(height: 10)),
                SliverToBoxAdapter(child: _buildFlagshipProfileCard()),
                const SliverToBoxAdapter(child: SizedBox(height: 10)),
                SliverToBoxAdapter(child: _buildFlagshipContentWindow()),
                const SliverToBoxAdapter(child: SizedBox(height: 18)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFlagshipDesktopHeader() {
    return Container(
      height: 54,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: _flagshipPanel(radius: 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _isPublicProfileView
                      ? _publicProfileTitle
                      : 'Профиль Sportoteka',
                  style: _flagshipTitle(13.8, weight: FontWeight.w700),
                ),
                const SizedBox(height: 3),
                Text(
                  _profileContextLine,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _flagshipText(
                    10.5,
                    color: const Color(0xFF6B7280),
                    weight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (isOwnProfile)
            _buildTinyAction(
              Icons.add_rounded,
              'Создать',
              _openContextualProfileCreate,
            ),
          if (isOwnProfile) ...[
            const SizedBox(width: 8),
            _buildTinyAction(
              Icons.more_horiz_rounded,
              'Меню',
              _openProfileSettingsSheet,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildWindowDots() {
    Widget dot(Color color) => Container(
        width: 10,
        height: 10,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle));
    return Row(
      children: [
        dot(const Color(0xFFFF5F57)),
        const SizedBox(width: 7),
        dot(const Color(0xFFFFBD2E)),
        const SizedBox(width: 7),
        dot(const Color(0xFF28C840)),
      ],
    );
  }

  Widget _buildTinyAction(IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        child: Text(
          label,
          style: _flagshipText(
            10.5,
            color: const Color(0xFF111827),
            weight: FontWeight.w700,
          ),
        ),
      ),
    );
  }

  Widget _buildFlagshipDesktopMenu() {
    final groups = <String, List<_ProfileFlagshipAction>>{};
    for (final action in _flagshipWorkspaceActions) {
      groups.putIfAbsent(action.group, () => []).add(action);
    }

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(4, 4, 4, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFlagshipAccountMini(),
          if (isOwnProfile) ...[
            const SizedBox(height: 10),
            _buildWorkspaceLaunchButton(dense: true),
            const SizedBox(height: 10),
          ] else
            const SizedBox(height: 10),
          Expanded(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              children: [
                ...groups.entries.expand((entry) {
                  return [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(8, 10, 8, 6),
                      child: Text(entry.key.toUpperCase(),
                          style: _flagshipText(8.2,
                              color: const Color(0xFF98A2B3),
                              weight: FontWeight.w900)),
                    ),
                    ...entry.value.map(_buildDesktopMenuAction),
                  ];
                }),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDesktopMenuAction(_ProfileFlagshipAction action) {
    final active = action.primary;
    final danger = action.danger;
    final titleColor =
        danger ? const Color(0xFFE11D48) : const Color(0xFF111827);

    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: action.onTap,
      child: Container(
        constraints: const BoxConstraints(minHeight: 42),
        margin: const EdgeInsets.only(bottom: 2),
        padding: const EdgeInsets.fromLTRB(10, 7, 8, 7),
        decoration: BoxDecoration(
          color: active ? const Color(0xFFF3FAF6) : Colors.transparent,
          border: active
              ? const Border(
                  left: BorderSide(color: Color(0xFF00A750), width: 3),
                )
              : null,
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          action.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: _flagshipText(
                            11.2,
                            color: titleColor,
                            weight: active ? FontWeight.w700 : FontWeight.w600,
                          ),
                        ),
                      ),
                      if (action.pro) ...[
                        const SizedBox(width: 5),
                        Text(
                          'PRO',
                          style: _flagshipText(
                            7.5,
                            color: const Color(0xFF00A750),
                            weight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    action.subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _flagshipText(
                      9.1,
                      color: const Color(0xFF8A94A6),
                      weight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFlagshipAccountMini() {
    final hasAvatar = photo != null && photo!.trim().isNotEmpty;
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 6, 6, 8),
      child: Row(
        children: [
          _buildFlagshipAvatar(size: 42, hasAvatar: hasAvatar),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fullName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _flagshipTitle(12.4, weight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text(
                  _roleLabel.toUpperCase(),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _flagshipText(
                    9.3,
                    color: const Color(0xFF6B7280),
                    weight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFlagshipProfileWorkspaceRow() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth >= 860;
        if (!wide) {
          return Column(
            children: [
              _buildFlagshipProfileCard(),
              if (isOwnProfile) ...[
                const SizedBox(height: 10),
                _buildFlagshipWorkspaceSummary(),
              ],
            ],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(flex: 12, child: _buildFlagshipProfileCard()),
            if (isOwnProfile) ...[
              const SizedBox(width: 10),
              Expanded(flex: 6, child: _buildFlagshipWorkspaceSummary()),
            ],
          ],
        );
      },
    );
  }

  Widget _buildFlagshipProfileCard() {
    final hasAvatar = photo != null && photo!.trim().isNotEmpty;
    final width = MediaQuery.sizeOf(context).width;
    // На мобильном и свой, и чужой профиль используют
    // одну компактную social-шапку.
    final compactSocial = width < 720;

    final infoLine = [
      if ((playerClubName ?? '').trim().isNotEmpty)
        (playerClubName ?? '').trim(),
      if ((playerTeamName ?? '').trim().isNotEmpty)
        (playerTeamName ?? '').trim(),
      if ((location ?? '').trim().isNotEmpty) (location ?? '').trim(),
    ].join(' · ');

    final avatarSize = compactSocial ? 76.0 : 92.0;

    return Container(
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(
        compactSocial ? 12 : 14,
        compactSocial ? 8 : 12,
        compactSocial ? 12 : 14,
        compactSocial ? 8 : 10,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildFlagshipAvatar(
                size: avatarSize,
                hasAvatar: hasAvatar,
              ),
              SizedBox(width: compactSocial ? 10 : 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (isClubRole || isCoachRole || isPlayer || isParentRole)
                      Padding(
                        padding: EdgeInsets.only(
                          bottom: compactSocial ? 3 : 6,
                        ),
                        child: Text(
                          _roleLabel.toUpperCase(),
                          style: _flagshipText(
                            compactSocial ? 8.0 : 8.8,
                            color: const Color(0xFF067A46),
                            weight: FontWeight.w600,
                          ).copyWith(letterSpacing: .24),
                        ),
                      ),
                    Text(
                      fullName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _flagshipTitle(
                        compactSocial ? 16.6 : 20.5,
                        weight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: compactSocial ? 3 : 7),
                    Text(
                      _activeWorkspaceName.isEmpty
                          ? 'Sportoteka'
                          : _activeWorkspaceName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _flagshipText(
                        compactSocial ? 10.2 : 11.5,
                        color: const Color(0xFF667085),
                        weight: FontWeight.w400,
                      ),
                    ),
                    if (infoLine.isNotEmpty) ...[
                      SizedBox(height: compactSocial ? 3 : 7),
                      Text(
                        infoLine,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _flagshipText(
                          compactSocial ? 9.4 : 10.6,
                          color: const Color(0xFF8A94A6),
                          weight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
          if ((bio ?? '').trim().isNotEmpty) ...[
            SizedBox(height: compactSocial ? 8 : 13),
            Text(
              (bio ?? '').trim(),
              maxLines: compactSocial ? 2 : 4,
              overflow: TextOverflow.ellipsis,
              style: _flagshipText(
                compactSocial ? 10.3 : 11.6,
                color: const Color(0xFF1F2937),
                weight: FontWeight.w400,
                height: compactSocial ? 1.24 : 1.32,
              ),
            ),
          ],
          SizedBox(height: compactSocial ? 8 : 15),
          Padding(
            padding: EdgeInsets.symmetric(
              vertical: compactSocial ? 4 : 11,
            ),
            child: Row(
              children: [
                Expanded(
                  child: _buildFlagshipStat(
                    userPosts.length,
                    'Посты',
                    Icons.grid_on_rounded,
                    compact: compactSocial,
                  ),
                ),
                Expanded(
                  child: _buildFlagshipStat(
                    userReels.length,
                    'Reels',
                    Icons.play_circle_fill_rounded,
                    compact: compactSocial,
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _openUsersModal(showFollowers: true),
                    child: _buildFlagshipStat(
                      followersCount,
                      'Подписчики',
                      Icons.people_rounded,
                      compact: compactSocial,
                    ),
                  ),
                ),
                Expanded(
                  child: GestureDetector(
                    onTap: () => _openUsersModal(showFollowers: false),
                    child: _buildFlagshipStat(
                      followingsCount,
                      'Подписки',
                      Icons.person_add_alt_rounded,
                      compact: compactSocial,
                    ),
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: compactSocial ? 7 : 13),
          Row(
            children: [
              Expanded(
                child: _buildFlagshipSmallButton(
                  label: isOwnProfile
                      ? 'Редактировать'
                      : (isFollowing ? 'Отписаться' : 'Подписаться'),
                  icon: Icons.person_add_alt_1_rounded,
                  onTap:
                      isOwnProfile ? _openProfileSettingsSheet : _toggleFollow,
                  primary: !isOwnProfile && !isFollowing,
                  compact: compactSocial,
                ),
              ),
              SizedBox(width: compactSocial ? 6 : 7),
              Expanded(
                child: _buildFlagshipSmallButton(
                  label: isOwnProfile ? _primaryZoneTitle : 'Написать',
                  icon: Icons.chat_bubble_outline_rounded,
                  onTap: isOwnProfile ? _openPrimaryArea : _openPrivateChat,
                  primary: isOwnProfile,
                  compact: compactSocial,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildFlagshipAvatar({
    required double size,
    required bool hasAvatar,
  }) {
    return GestureDetector(
      onTap: isOwnProfile ? _openProfileMediaPickerSheet : null,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: const Color(0xFFF3F4F6),
              borderRadius: BorderRadius.circular(size * .24),
            ),
            clipBehavior: Clip.antiAlias,
            child: hasAvatar
                ? Image.network(
                    photo!,
                    width: size,
                    height: size,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Center(
                      child: Text(
                        fullName.isEmpty
                            ? 'S'
                            : fullName.characters.first.toUpperCase(),
                        style: _flagshipTitle(size * .28),
                      ),
                    ),
                  )
                : Center(
                    child: Text(
                      fullName.isEmpty
                          ? 'S'
                          : fullName.characters.first.toUpperCase(),
                      style: _flagshipTitle(size * .28),
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCapsule() {
    final icon = isClubRole
        ? Icons.apartment_rounded
        : isCoachRole
            ? Icons.sports_soccer_rounded
            : isParentRole
                ? Icons.family_restroom_rounded
                : Icons.person_rounded;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF3FBF7),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 13, color: const Color(0xFF067A46)),
          const SizedBox(width: 5),
          Text(_roleLabel.toUpperCase(),
              style: _flagshipText(9,
                  color: const Color(0xFF067A46), weight: FontWeight.w900)),
        ],
      ),
    );
  }

  Widget _buildFlagshipStat(
    int value,
    String label,
    IconData icon, {
    bool compact = false,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value.toString(),
          style: _flagshipTitle(
            compact ? 13.2 : 14.6,
            weight: FontWeight.w600,
          ),
        ),
        SizedBox(height: compact ? 2 : 4),
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: _flagshipText(
            compact ? 8.5 : 9.3,
            color: const Color(0xFF8A94A6),
            weight: FontWeight.w400,
          ),
        ),
      ],
    );
  }

  Widget _buildFlagshipSmallButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
    bool primary = false,
    bool compact = false,
  }) {
    final isFollowAction = label == 'Подписаться' || label == 'Отписаться';

    final background = primary
        ? const Color(0xFF00A750)
        : isFollowAction && label == 'Отписаться'
            ? const Color(0xFFF1F3F2)
            : const Color(0xFFF5F6F5);

    final foreground = primary ? Colors.white : const Color(0xFF111827);

    return Material(
      color: background,
      borderRadius: BorderRadius.circular(compact ? 8 : 9),
      child: InkWell(
        borderRadius: BorderRadius.circular(compact ? 8 : 9),
        onTap: onTap,
        child: Container(
          height: compact ? 32 : 36,
          padding: EdgeInsets.symmetric(
            horizontal: compact ? 8 : 10,
          ),
          alignment: Alignment.center,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (!isOwnProfile) ...[
                Container(
                  width: 4.2,
                  height: 4.2,
                  decoration: BoxDecoration(
                    color: primary
                        ? Colors.white
                        : isFollowAction
                            ? const Color(0xFF00A750)
                            : const Color(0xFF667085),
                    shape: BoxShape.circle,
                  ),
                ),
                SizedBox(width: compact ? 5 : 6),
              ],
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _flagshipText(
                    compact ? 9.5 : 10.2,
                    color: foreground,
                    weight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildFlagshipWorkspaceSummary() {
    final name =
        _activeWorkspaceName.isEmpty ? 'Sportoteka' : _activeWorkspaceName;

    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            _primaryZoneTitle,
            style: _flagshipTitle(14.2, weight: FontWeight.w700),
          ),
          const SizedBox(height: 4),
          Text(
            name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _flagshipText(
              10.4,
              color: const Color(0xFF667085),
              weight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 12),
          _buildAccessStripe(
            icon: Icons.verified_user_outlined,
            title: _enteredAsText,
            value: _roleLabel.toUpperCase(),
            onTap: _openProfileSettingsSheet,
          ),
          _buildAccessStripe(
            icon: _primaryZoneIcon,
            title: _primaryZoneSubtitle,
            value: 'Открыть',
            strong: true,
            onTap: _openPrimaryArea,
          ),
          _buildAccessStripe(
            icon: Icons.add_a_photo_outlined,
            title: _profileMediaEditTitle,
            value: 'Изменить',
            onTap: _openProfileMediaPickerSheet,
          ),
        ],
      ),
    );
  }

  Widget _buildAccessStripe({
    required IconData icon,
    required String title,
    required String value,
    required VoidCallback onTap,
    bool strong = false,
  }) {
    return InkWell(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minHeight: 38),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: strong
            ? const BoxDecoration(
                border: Border(
                  left: BorderSide(color: Color(0xFF00A750), width: 3),
                ),
              )
            : null,
        child: Row(
          children: [
            Expanded(
              child: Text(
                title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: _flagshipText(
                  10.6,
                  color: const Color(0xFF344054),
                  weight: strong ? FontWeight.w700 : FontWeight.w500,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _flagshipText(
                9.5,
                color:
                    strong ? const Color(0xFF067A46) : const Color(0xFF98A2B3),
                weight: FontWeight.w700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWorkspaceLaunchButton({bool dense = false}) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: _openPrimaryArea,
      child: Container(
        constraints: BoxConstraints(minHeight: dense ? 40 : 44),
        padding: const EdgeInsets.fromLTRB(10, 8, 8, 8),
        decoration: const BoxDecoration(
          color: Color(0xFFF3FAF6),
          border: Border(
            left: BorderSide(color: Color(0xFF00A750), width: 3),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _primaryZoneTitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _flagshipText(
                10.8,
                color: const Color(0xFF111827),
                weight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              _primaryZoneSubtitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _flagshipText(
                8.8,
                color: const Color(0xFF667085),
                weight: FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFlagshipRightDesk() {
    return CustomScrollView(
      physics: const BouncingScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(child: _buildFlagshipSettingsPanel()),
        const SliverToBoxAdapter(child: SizedBox(height: 20)),
      ],
    );
  }

  Widget _buildFlagshipSettingsPanel() {
    return Container(
      decoration: _flagshipPanel(radius: 20),
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Настройки', style: _flagshipTitle(13.6)),
          const SizedBox(height: 8),
          _buildSettingsLine(Icons.verified_user_outlined, 'Роль аккаунта',
              _roleLabel.toUpperCase(), _openProfileSettingsSheet),
          _buildSettingsLine(Icons.image_outlined, 'Фото и профиль',
              'Редактировать', _pickAndUploadPhoto),
          _buildSettingsLine(Icons.notifications_none_rounded, 'Уведомления',
              'Открыть', _openProfileSettingsSheet),
          _buildSettingsLine(
              Icons.security_rounded,
              isParentRole
                  ? 'Доступ к детям'
                  : (isPlayer ? 'Личный доступ' : 'Права клуба'),
              isParentRole ? 'Мои дети' : (isPlayer ? 'Dashboard' : 'Панель'),
              _openPrimaryArea),
        ],
      ),
    );
  }

  Widget _buildSettingsLine(
      IconData icon, String title, String value, VoidCallback onTap) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 44,
        margin: const EdgeInsets.only(bottom: 7),
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: _flagshipSoft(radius: 16),
        child: Row(
          children: [
            Icon(icon, size: 16, color: const Color(0xFF111827)),
            const SizedBox(width: 9),
            Expanded(
                child: Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _flagshipText(10.8,
                        color: const Color(0xFF111827),
                        weight: FontWeight.w800))),
            const SizedBox(width: 8),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: _flagshipText(9.6,
                    color: const Color(0xFF8A94A6), weight: FontWeight.w800)),
          ],
        ),
      ),
    );
  }

  String get _profileContentTitle {
    switch (_mode) {
      case _ProfileFeedMode.reels:
        return 'Мои Reels';
      case _ProfileFeedMode.feed:
        return 'Лента профиля';
      case _ProfileFeedMode.posts:
        return 'Публикации профиля';
    }
  }

  Widget _buildFlagshipContentWindow() {
    return Container(
      color: Colors.white,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 13, 14, 7),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    _profileContentTitle,
                    style: _flagshipTitle(14.2, weight: FontWeight.w700),
                  ),
                ),
              ],
            ),
          ),
          _buildModeSwitcher(),
          const SizedBox(height: 2),
          _buildContentGrid(),
        ],
      ),
    );
  }

  Widget _buildFlagshipMobileProfile() {
    // Публичный профиль должен начинаться как социальный профиль:
    // avatar / имя / статистика / Подписаться-Отписаться / Написать,
    // а уже потом публикации.
    if (_isPublicProfileView) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFlagshipProfileCard(),
          const SizedBox(height: 4),
          _buildFlagshipContentWindow(),
          SizedBox(
            height: MediaQuery.paddingOf(context).bottom + 28,
          ),
        ],
      );
    }

    if (_profileWorkspaceSection == 'profile') {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFlagshipProfileCard(),
          SizedBox(height: MediaQuery.paddingOf(context).bottom + 116),
        ],
      );
    }

    // Своя мобильная главная тоже остаётся социальной:
    // профиль + подписчики/подписки + публикации.
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildFlagshipProfileCard(),
        const SizedBox(height: 2),
        _buildFlagshipContentWindow(),
        SizedBox(
          height: MediaQuery.paddingOf(context).bottom + 28,
        ),
      ],
    );
  }

  Widget _buildProfileContent() {
    final sortedBlocks = design.blocks
        .where((b) => b.enabled)
        .where((b) => b.id != 'team')
        .toList()
      ..sort((a, b) => a.order.compareTo(b.order));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (isOwnProfile) _buildLoggedInClubStrip(),
        if (design.sectionVisibility['header'] != false) _buildHeaderSection(),
        if (design.sectionVisibility['actions'] != false && !isOwnProfile)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 8, 14, 10),
            child: _buildActionsSection(),
          ),
        ...sortedBlocks.map((block) {
          return Padding(
            padding: EdgeInsets.fromLTRB(14, 0, 14, design.spacing),
            child: _buildBlock(block),
          );
        }).toList(),
        if (design.sectionVisibility['switcher'] != false)
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 2, 0, 0),
            child: _buildModeSwitcher(),
          ),
        if (design.sectionVisibility['content'] != false) _buildContentGrid(),
        SizedBox(height: MediaQuery.paddingOf(context).bottom + 116),
      ],
    );
  }

  Widget _buildLoggedInClubStrip() {
    final isWorkspaceRole = isClubRole || isCoachRole || isParentRole;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 7, 14, 7),
      color: Colors.white,
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${_roleLabel.toUpperCase()}  ·  ${_activeWorkspaceName.isEmpty ? 'Sportoteka' : _activeWorkspaceName}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: _flagshipText(
                10.1,
                color: const Color(0xFF667085),
                weight: FontWeight.w600,
              ),
            ),
          ),
          if (isWorkspaceRole)
            InkWell(
              onTap: _openPrimaryArea,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
                child: Text(
                  'Кабинет',
                  style: _flagshipText(
                    10.1,
                    color: const Color(0xFF067A46),
                    weight: FontWeight.w700,
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildMobilePersistentWindow() {
    // Мобильные разделы открываются на полный экран, но нижнее Instagram/CMR-меню
    // остаётся постоянной навигацией. Верхнюю панель с закрыть/свернуть/развернуть
    // убираем: назад в профиль, Reels, чат и меню доступны через нижний dock.
    return Container(
      color: Colors.white,
      child: Padding(
        padding: EdgeInsets.zero,
        child: Material(
          color: Colors.white,
          child: SafeArea(
            top: false,
            bottom: false,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              color: Colors.white,
              child: _mobileWindowChild ?? const SizedBox.shrink(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildMobileWindowTitleBar(
      {required String title,
      required IconData icon,
      required VoidCallback onClose}) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFEFF2F5), width: 1)),
      ),
      child: Row(
        children: [
          _buildMacDot(const Color(0xFFFF5F57), onClose),
          const SizedBox(width: 6),
          _buildMacDot(const Color(0xFFFFBD2E), onClose),
          const SizedBox(width: 6),
          _buildMacDot(const Color(0xFF28C840), () {}),
          const SizedBox(width: 10),
          Container(
            width: 25,
            height: 25,
            decoration: BoxDecoration(
              color: const Color(0xFFF4F6F8),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, size: 15, color: const Color(0xFF344054)),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              title.isEmpty ? 'Окно' : title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.custom(
                  size: 11.5,
                  weight: FontWeight.w600,
                  color: const Color(0xFF111827),
                  height: 1.2),
            ),
          ),
          InkWell(
            onTap: onClose,
            borderRadius: BorderRadius.circular(999),
            child: Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                  color: const Color(0xFFF3F4F6),
                  borderRadius: BorderRadius.circular(999)),
              child: const Icon(Icons.close_rounded,
                  size: 16, color: Color(0xFF111827)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSocialBottomBar() {
    final media = MediaQuery.of(context);
    final width = media.size.width;
    final horizontal = width < 380 ? 8.0 : 12.0;

    // На Android системная navigation bar может занимать заметную высоту
    // (3 кнопки, gesture area, фирменная панель производителя). Старый код
    // ограничивал отступ 14 px, поэтому dock мог накладываться на неё.
    // viewPadding сохраняет реальный системный inset даже при edge-to-edge.
    final isAndroid = defaultTargetPlatform == TargetPlatform.android;
    final systemBottom = math.max(media.viewPadding.bottom, media.padding.bottom);
    final gestureBottom = media.systemGestureInsets.bottom;
    final protectedBottom =
        isAndroid ? math.max(systemBottom, gestureBottom) : systemBottom;

    // Android: полностью поднимаем dock над системной навигацией.
    // iOS: оставляем более привычный компактный зазор над home indicator.
    final bottomInset = isAndroid
        ? math.max(5.0, protectedBottom + 2.0)
        : protectedBottom > 0
            ? math.min(11.0, protectedBottom * .34)
            : 8.0;

    Widget dockItem({
      required String keyName,
      required IconData icon,
      required VoidCallback onTap,
      int badge = 0,
    }) {
      final active = _mobileDockKey == keyName;

      return Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: onTap,
          child: Center(
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 170),
              curve: Curves.easeOutCubic,
              width: active ? 42 : 37,
              height: 36,
              decoration: BoxDecoration(
                color: active ? const Color(0xFFDDF2E6) : Colors.transparent,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Stack(
                clipBehavior: Clip.none,
                alignment: Alignment.center,
                children: [
                  Icon(
                    icon,
                    size: active ? 21 : 20,
                    color: active
                        ? const Color(0xFF067A46)
                        : const Color(0xFF475467),
                  ),
                  if (badge > 0)
                    Positioned(
                      top: 0,
                      right: active ? 5 : -1,
                      child: Container(
                        constraints: const BoxConstraints(
                          minWidth: 17,
                          minHeight: 17,
                        ),
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF0050),
                          borderRadius: BorderRadius.circular(999),
                          border: Border.all(
                            color: const Color(0xFFF0F4F1),
                            width: 1.7,
                          ),
                        ),
                        alignment: Alignment.center,
                        child: Text(
                          badge > 99 ? '99+' : '$badge',
                          style: AppTypography.custom(
                            size: 8.5,
                            weight: FontWeight.w900,
                            color: Colors.white,
                            height: 1,
                            letterSpacing: 0,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return SafeArea(
      top: false,
      bottom: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          horizontal,
          0,
          horizontal,
          bottomInset,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(21),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
            child: Container(
              height: 54,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                // Чуть серо-зелёный фон: меню отделяется от белого контента,
                // но остаётся лёгким и не превращается в яркую зелёную панель.
                color: const Color(0xFFF0F4F1).withOpacity(.97),
                borderRadius: BorderRadius.circular(21),
                border: Border.all(
                  color: const Color(0xFFDCE6E0),
                  width: 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.12),
                    blurRadius: 26,
                    spreadRadius: -10,
                    offset: const Offset(0, 12),
                  ),
                  BoxShadow(
                    color: const Color(0xFF067A46).withOpacity(.05),
                    blurRadius: 12,
                    spreadRadius: -7,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Row(
                children: [
                  dockItem(
                    keyName: 'profile',
                    icon: Icons.home_outlined,
                    onTap: () {
                      _closeMobileWindow(dockKey: 'profile');
                      if (mounted) {
                        _selectProfileWorkspaceSection('posts');
                      }
                    },
                  ),
                  dockItem(
                    keyName: 'feed',
                    icon: Icons.dynamic_feed_outlined,
                    onTap: _openCommunityFeedHome,
                  ),
                  dockItem(
                    keyName: 'search',
                    icon: Icons.search_rounded,
                    onTap: () {
                      if (mounted) {
                        setState(() => _mobileDockKey = 'search');
                      }
                      _openPeopleSearchWindow();
                    },
                  ),
                  dockItem(
                    keyName: 'chat',
                    icon: Icons.forum_outlined,
                    badge: _chatUnreadCount,
                    onTap: _openMainChat,
                  ),
                  dockItem(
                    keyName: 'more',
                    icon: Icons.grid_view_rounded,
                    onTap: () {
                      if (mounted) {
                        setState(() => _mobileDockKey = 'more');
                      }
                      _openProfileHomeMoreSheet();
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _openProfileHomeMoreSheet() {
    final actions = <_ProfileFlagshipAction>[
      if (isOwnProfile)
        _ProfileFlagshipAction(
            'Выйти в Workspace',
            'закрыть профиль и выбрать рабочий кабинет',
            Icons.account_tree_outlined,
            _goToWorkspaceHub,
            group: 'Навигация',
            primary: true),
      if (isOwnProfile && hasPressAssistantAccess)
        _ProfileFlagshipAction(
            'Пресс-служба',
            'новости назначенных команд',
            Icons.campaign_outlined,
            _openPressAssistantArea,
            group: 'Работа',
            primary: true),
      _ProfileFlagshipAction('Лента', 'новости и публикации сообщества',
          Icons.dynamic_feed_rounded, _openCommunityFeedHome,
          group: 'Основное'),
      _ProfileFlagshipAction('Поиск людей', 'игроки, тренеры и пользователи',
          Icons.person_search_outlined, _openPeopleSearchWindow,
          group: 'Основное'),
      _ProfileFlagshipAction('Чаты', 'личные сообщения и группы',
          Icons.forum_rounded, _openMainChat,
          group: 'Основное'),
      _ProfileFlagshipAction('Reels', 'короткие видео сообщества',
          Icons.play_circle_outline_rounded, _openGlobalReels,
          group: 'Основное'),
      _ProfileFlagshipAction('Видеоуроки', 'обучение и спортивные материалы',
          Icons.school_rounded, _openVideoLessonsWindow,
          group: 'Обучение'),
      _ProfileFlagshipAction(
          'Сохранённое · скоро',
          'ваши сохранённые материалы',
          Icons.bookmark_border_rounded,
          _openSavedWindow,
          group: 'Обучение'),
      _ProfileFlagshipAction(
          'Площадки',
          'каталог доступен · раздел дополняется',
          Icons.stadium_rounded,
          _openVenuesWindow,
          group: 'Сервисы'),
      _ProfileFlagshipAction(
          'Игры рядом · скоро',
          'открытые игры и поиск игроков',
          Icons.sports_soccer_rounded,
          _openNearbyGamesWindow,
          group: 'Сервисы'),
      _ProfileFlagshipAction(
          'Тренировки рядом · скоро',
          'открытые занятия тренеров и клубов',
          Icons.directions_run_rounded,
          _openNearbyTrainingsWindow,
          group: 'Сервисы'),
      if (isOwnProfile)
        _ProfileFlagshipAction(
            isClubRole ? 'Логотип / аватар' : 'Аватарка',
            _profileMediaEditSubtitle,
            Icons.add_a_photo_outlined,
            _openProfileMediaPickerSheet,
            group: 'Аккаунт'),
      _ProfileFlagshipAction('PRO подписка', 'расширенные возможности',
          Icons.workspace_premium_rounded, _openSubscriptionWindow,
          group: 'Аккаунт', pro: true),
      _ProfileFlagshipAction('Настройки', 'профиль и доступ',
          Icons.settings_outlined, _openProfileSettingsSheet,
          group: 'Аккаунт'),
      if (isOwnProfile)
        _ProfileFlagshipAction('Выйти из профиля', 'завершить текущую сессию',
            Icons.logout_rounded, _logoutFromProfile,
            group: 'Аккаунт'),
      if (isOwnProfile)
        _ProfileFlagshipAction(
            'Удалить профиль',
            'подтверждение кодовым словом',
            Icons.delete_forever_rounded,
            _deleteOwnProfileWithConfirmation,
            group: 'Аккаунт',
            danger: true),
    ];

    final width = MediaQuery.sizeOf(context).width;

    // Телефон: меню в той же визуальной модели, что Club Workspace —
    // плавающий белый лист, без карточочных обводок и лишней рамки окна.
    if (width < 720) {
      showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withOpacity(.22),
        builder: (sheetContext) =>
            _buildProfileMobileMoreSheet(sheetContext, actions),
      );
      return;
    }

    // Планшет и ПК: меню полностью повторяет Club Workspace —
    // большая белая панель, сетка модулей, счётчик и крестик в шапке.
    showGeneralDialog<void>(
      context: context,
      barrierDismissible: true,
      barrierLabel: 'Закрыть меню',
      barrierColor: Colors.black.withOpacity(.28),
      transitionDuration: const Duration(milliseconds: 220),
      pageBuilder: (dialogContext, animation, secondaryAnimation) {
        return _ProfileFullModulesMenuOverlay(
          title: fullName,
          subtitle: _activeWorkspaceName,
          photoUrl: photo,
          actions: actions,
          onSelect: (action) {
            Navigator.of(dialogContext).pop();
            Future<void>.delayed(
                const Duration(milliseconds: 80), action.onTap);
          },
        );
      },
      transitionBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return FadeTransition(
          opacity: curved,
          child: Transform.translate(
            offset: Offset(0, 26 * (1 - curved.value)),
            child: Transform.scale(
              alignment: Alignment.bottomCenter,
              scale: .965 + (.035 * curved.value),
              child: child,
            ),
          ),
        );
      },
    );
  }

  Widget _buildProfileMobileMoreSheet(
    BuildContext sheetContext,
    List<_ProfileFlagshipAction> actions,
  ) {
    final grouped = <String, List<_ProfileFlagshipAction>>{};
    for (final action in actions) {
      grouped
          .putIfAbsent(action.group, () => <_ProfileFlagshipAction>[])
          .add(action);
    }

    final height = MediaQuery.of(sheetContext).size.height;
    final bottom = MediaQuery.of(sheetContext).padding.bottom;
    const orderedGroups = <String>[
      'Навигация',
      'Создать',
      'Основное',
      'Обучение',
      'Сервисы',
      'Профиль',
      'Аккаунт',
    ];

    Widget actionTile(_ProfileFlagshipAction action) {
      final danger = action.danger;
      final active = action.primary;
      final accent = danger
          ? const Color(0xFFE11D48)
          : active
              ? const Color(0xFF067A46)
              : const Color(0xFF344054);

      return Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(15),
        child: InkWell(
          borderRadius: BorderRadius.circular(15),
          onTap: () {
            Navigator.of(sheetContext).pop();
            Future<void>.delayed(
              const Duration(milliseconds: 80),
              action.onTap,
            );
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 170),
            width: double.infinity,
            constraints: const BoxConstraints(minHeight: 50),
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
            decoration: BoxDecoration(
              color: active
                  ? const Color(0xFFF3FAF6)
                  : danger
                      ? const Color(0xFFFFF7F8)
                      : Colors.transparent,
              borderRadius: BorderRadius.circular(15),
            ),
            child: Row(
              children: [
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: active
                        ? const Color(0xFFEAF8F0)
                        : danger
                            ? const Color(0xFFFFECEF)
                            : const Color(0xFFF7F9F8),
                    borderRadius: BorderRadius.circular(11),
                  ),
                  child: Icon(action.icon, size: 18, color: accent),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              action.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTypography.custom(
                                size: 11.4,
                                weight: FontWeight.w600,
                                color: danger
                                    ? const Color(0xFFE11D48)
                                    : active
                                        ? const Color(0xFF067A46)
                                        : const Color(0xFF111827),
                                height: 1.15,
                                letterSpacing: 0,
                              ),
                            ),
                          ),
                          if (action.pro) ...[
                            const SizedBox(width: 5),
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 3,
                              ),
                              decoration: BoxDecoration(
                                color: const Color(0xFFFFF7ED),
                                borderRadius: BorderRadius.circular(999),
                              ),
                              child: Text(
                                'PRO',
                                style: AppTypography.custom(
                                  size: 8.2,
                                  weight: FontWeight.w600,
                                  color: const Color(0xFFEA580C),
                                  height: 1,
                                  letterSpacing: 0,
                                ),
                              ),
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        action.subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 9.7,
                          weight: FontWeight.w400,
                          color: danger
                              ? const Color(0xFFBE123C)
                              : const Color(0xFF667085),
                          height: 1.2,
                          letterSpacing: 0,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 6),
                Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: danger
                      ? const Color(0xFFE11D48)
                      : const Color(0xFF98A2B3),
                ),
              ],
            ),
          ),
        ),
      );
    }

    Widget section(String title, List<_ProfileFlagshipAction> items) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(9, 5, 9, 5),
              child: Text(
                title.toUpperCase(),
                style: AppTypography.custom(
                  size: 8.4,
                  weight: FontWeight.w700,
                  color: const Color(0xFF98A2B3),
                  height: 1.1,
                  letterSpacing: .45,
                ),
              ),
            ),
            ...items.map(
              (action) => Padding(
                padding: const EdgeInsets.only(bottom: 3),
                child: actionTile(action),
              ),
            ),
          ],
        ),
      );
    }

    return Container(
      constraints: BoxConstraints(maxHeight: height * .88),
      margin: const EdgeInsets.fromLTRB(10, 0, 10, 10),
      padding: EdgeInsets.fromLTRB(14, 10, 14, 14 + bottom),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.16),
            blurRadius: 28,
            offset: const Offset(0, 14),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 42,
            height: 5,
            decoration: BoxDecoration(
              color: const Color(0xFFD0D5DD),
              borderRadius: BorderRadius.circular(999),
            ),
          ),
          const SizedBox(height: 12),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 2, 4, 10),
            child: Row(
              children: [
                _buildSmallAvatarForSheet(),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 12.6,
                          weight: FontWeight.w600,
                          color: const Color(0xFF111827),
                          height: 1.15,
                          letterSpacing: 0,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _enteredAsText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 9.8,
                          weight: FontWeight.w400,
                          color: const Color(0xFF667085),
                          height: 1.15,
                          letterSpacing: 0,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8,
                    vertical: 5,
                  ),
                  decoration: BoxDecoration(
                    color: const Color(0xFFECFDF3),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    _roleLabel.toUpperCase(),
                    style: AppTypography.custom(
                      size: 8.6,
                      weight: FontWeight.w600,
                      color: const Color(0xFF00A750),
                      height: 1,
                      letterSpacing: .15,
                    ),
                  ),
                ),
              ],
            ),
          ),
          Row(
            children: [
              Expanded(
                child: Text(
                  'Меню',
                  style: AppTypography.custom(
                    size: 13.2,
                    weight: FontWeight.w600,
                    color: const Color(0xFF111827),
                    height: 1.1,
                    letterSpacing: 0,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Flexible(
            child: ListView(
              shrinkWrap: true,
              padding: EdgeInsets.zero,
              physics: const BouncingScrollPhysics(),
              children: [
                for (final group in orderedGroups)
                  if ((grouped[group] ?? const <_ProfileFlagshipAction>[])
                      .isNotEmpty)
                    section(group, grouped[group]!),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileHomeMoreWindowContent(
    List<_ProfileFlagshipAction> actions, {
    void Function(_ProfileFlagshipAction action)? onActionTap,
  }) {
    final grouped = <String, List<_ProfileFlagshipAction>>{};
    for (final action in actions) {
      grouped
          .putIfAbsent(action.group, () => <_ProfileFlagshipAction>[])
          .add(action);
    }

    Widget compactTile(_ProfileFlagshipAction action) {
      final danger = action.danger;
      final tileBg = action.primary
          ? const Color(0xFF111827)
          : (danger ? const Color(0xFFFFF1F2) : const Color(0xFFF8FAFC));
      final tileBorder = action.primary
          ? const Color(0xFF111827)
          : (danger ? const Color(0xFFFFCCD5) : const Color(0xFFE9EEF3));
      final iconColor = action.primary
          ? Colors.white
          : (danger ? const Color(0xFFE11D48) : const Color(0xFF344054));
      final titleColor = action.primary
          ? Colors.white
          : (danger ? const Color(0xFFE11D48) : const Color(0xFF111827));
      return InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: () {
          if (onActionTap != null) {
            onActionTap(action);
          } else {
            action.onTap();
          }
        },
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
          decoration: BoxDecoration(
            color: tileBg,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: tileBorder),
          ),
          child: Row(
            children: [
              Container(
                width: 32,
                height: 32,
                decoration: BoxDecoration(
                  color: action.primary
                      ? Colors.white.withOpacity(.14)
                      : Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: action.primary
                      ? null
                      : Border.all(color: const Color(0xFFE9EEF3)),
                ),
                child: Icon(action.icon, size: 18, color: iconColor),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            action.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.custom(
                              size: 11.4,
                              weight: FontWeight.w600,
                              color: titleColor,
                              height: 1.15,
                              letterSpacing: 0,
                            ),
                          ),
                        ),
                        if (action.pro)
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 6, vertical: 3),
                            decoration: BoxDecoration(
                                color: const Color(0xFFFFF7ED),
                                borderRadius: BorderRadius.circular(999)),
                            child: Text(
                              'PRO',
                              style: AppTypography.custom(
                                size: 8.2,
                                weight: FontWeight.w600,
                                color: const Color(0xFFEA580C),
                                height: 1,
                                letterSpacing: 0,
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 2),
                    Text(
                      action.subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.custom(
                        size: 9.7,
                        weight: FontWeight.w400,
                        color: action.primary
                            ? Colors.white.withOpacity(.72)
                            : const Color(0xFF667085),
                        height: 1.2,
                        letterSpacing: 0,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded,
                  size: 18,
                  color: action.primary
                      ? Colors.white.withOpacity(.72)
                      : const Color(0xFF98A2B3)),
            ],
          ),
        ),
      );
    }

    Widget section(String title, List<_ProfileFlagshipAction> items) {
      return Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 4, bottom: 7),
              child: Text(
                title.toUpperCase(),
                style: AppTypography.custom(
                  size: 8.4,
                  weight: FontWeight.w700,
                  color: const Color(0xFF98A2B3),
                  height: 1.1,
                  letterSpacing: .45,
                ),
              ),
            ),
            ...items.map((a) => Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: compactTile(a))),
          ],
        ),
      );
    }

    final orderedGroups = [
      'Навигация',
      'Создать',
      'Основное',
      'Обучение',
      'Сервисы',
      'Профиль',
      'Аккаунт'
    ];

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: const Color(0xFFE9EEF3)),
            ),
            child: Row(
              children: [
                _buildSmallAvatarForSheet(),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 12.6,
                          weight: FontWeight.w600,
                          color: const Color(0xFF111827),
                          height: 1.15,
                          letterSpacing: 0,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        _enteredAsText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 9.8,
                          weight: FontWeight.w400,
                          color: const Color(0xFF667085),
                          height: 1.15,
                          letterSpacing: 0,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                      color: const Color(0xFFECFDF3),
                      borderRadius: BorderRadius.circular(999)),
                  child: Text(
                    _roleLabel.toUpperCase(),
                    style: AppTypography.custom(
                      size: 8.6,
                      weight: FontWeight.w600,
                      color: const Color(0xFF00A750),
                      height: 1,
                      letterSpacing: .15,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Column(
                children: [
                  for (final group in orderedGroups)
                    if ((grouped[group] ?? const <_ProfileFlagshipAction>[])
                        .isNotEmpty)
                      section(group, grouped[group]!),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _logoutFromProfile() async {
    await _clearLocalProfileSession();
    if (!mounted) return;
    Get.offAllNamed(AppRoutes.loginScreen);
  }

  Future<void> _clearLocalProfileSession() async {
    try {
      await PrefUtils.setIsSignIn(false);
    } catch (_) {}

    try {
      await PrefUtils.setUserId(0);
    } catch (_) {}

    try {
      await PrefUtils.setUserFirstName('');
    } catch (_) {}

    try {
      await PrefUtils.setUserLastName('');
    } catch (_) {}

    try {
      await PrefUtils.setUserEmail('');
    } catch (_) {}

    try {
      await PrefUtils.setRole('');
    } catch (_) {}

    try {
      await PrefUtils.setUserPhoto('');
    } catch (_) {}
  }

  Future<void> _deleteOwnProfileWithConfirmation() async {
    final userId = await PrefUtils.getUserId();
    if (userId == null || userId <= 0) {
      Get.snackbar('Профиль', 'Не найден user_id для удаления профиля',
          snackPosition: SnackPosition.BOTTOM);
      return;
    }

    final confirmed = await _showDeleteProfileCodeBanner();
    if (confirmed != true) return;

    try {
      final resp = await http.post(
        Uri.parse(_deleteAccountUrl),
        body: {
          'user_id': userId.toString(),
        },
      );

      if (resp.statusCode != 200) {
        Get.snackbar(
            'Удаление профиля', 'Сервер вернул ошибку: ${resp.statusCode}',
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      dynamic data;
      try {
        data = jsonDecode(resp.body);
      } catch (_) {
        data = null;
      }

      final success = data is Map &&
          (data['success'] == true ||
              data['status'] == 'success' ||
              data['status'] == 'deleted');

      if (!success) {
        final message = data is Map
            ? (data['error'] ?? data['message'] ?? 'Не удалось удалить профиль')
                .toString()
            : 'Не удалось удалить профиль';
        Get.snackbar('Удаление профиля', message,
            snackPosition: SnackPosition.BOTTOM);
        return;
      }

      await _clearLocalProfileSession();
      if (!mounted) return;
      Get.offAllNamed(AppRoutes.loginScreen);
    } catch (e) {
      Get.snackbar('Ошибка сети', e.toString(),
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<bool?> _showDeleteProfileCodeBanner() async {
    const codeWord = 'УДАЛИТЬ';
    final controller = TextEditingController();
    bool canDelete = false;

    final result = await showModalBottomSheet<bool>(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) {
        final bottom = MediaQuery.of(context).viewInsets.bottom +
            MediaQuery.of(context).padding.bottom;
        return StatefulBuilder(
          builder: (context, setSheetState) {
            void onTextChanged(String value) {
              final next = value.trim().toUpperCase() == codeWord;
              if (next != canDelete) {
                setSheetState(() => canDelete = next);
              }
            }

            return Padding(
              padding: EdgeInsets.fromLTRB(14, 0, 14, 14 + bottom),
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(28),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(.16),
                      blurRadius: 34,
                      spreadRadius: -14,
                      offset: const Offset(0, 18),
                    ),
                  ],
                ),
                clipBehavior: Clip.antiAlias,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.fromLTRB(18, 18, 18, 17),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFFFFE4E6), Color(0xFFFFF7ED)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.9),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: const Icon(Icons.warning_amber_rounded,
                                color: Color(0xFFE11D48), size: 25),
                          ),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'Удалить профиль?',
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                      color: Color(0xFF111827)),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  'Это действие удалит аккаунт и завершит текущую сессию. Отменить удаление после подтверждения нельзя.',
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      height: 1.25,
                                      color: Color(0xFF667085)),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          RichText(
                            text: const TextSpan(
                              style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w700,
                                  color: Color(0xFF667085),
                                  height: 1.25),
                              children: [
                                TextSpan(
                                    text:
                                        'Для подтверждения введите кодовое слово: '),
                                TextSpan(
                                    text: codeWord,
                                    style: TextStyle(
                                        color: Color(0xFFE11D48),
                                        fontWeight: FontWeight.w900)),
                              ],
                            ),
                          ),
                          const SizedBox(height: 10),
                          TextField(
                            controller: controller,
                            onChanged: onTextChanged,
                            textCapitalization: TextCapitalization.characters,
                            decoration: InputDecoration(
                              hintText: codeWord,
                              filled: true,
                              fillColor: const Color(0xFFF8FAFC),
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 13),
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: const BorderSide(
                                      color: Color(0xFFE5E7EB))),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: const BorderSide(
                                      color: Color(0xFFE5E7EB))),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(16),
                                  borderSide: BorderSide(
                                      color: canDelete
                                          ? const Color(0xFFE11D48)
                                          : const Color(0xFF00A750),
                                      width: 1.4)),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Row(
                            children: [
                              Expanded(
                                child: OutlinedButton(
                                  style: OutlinedButton.styleFrom(
                                    foregroundColor: const Color(0xFF111827),
                                    side: const BorderSide(
                                        color: Color(0xFFE5E7EB)),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 13),
                                  ),
                                  onPressed: () =>
                                      Navigator.pop(context, false),
                                  child: const Text('Отмена',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900)),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                    elevation: 0,
                                    backgroundColor: canDelete
                                        ? const Color(0xFFE11D48)
                                        : const Color(0xFFE5E7EB),
                                    foregroundColor: canDelete
                                        ? Colors.white
                                        : const Color(0xFF98A2B3),
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(16)),
                                    padding: const EdgeInsets.symmetric(
                                        vertical: 13),
                                  ),
                                  onPressed: canDelete
                                      ? () => Navigator.pop(context, true)
                                      : null,
                                  child: const Text('Удалить профиль',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900)),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );

    controller.dispose();
    return result;
  }


  void _openProfileSettingsSheet() {
    final width = MediaQuery.sizeOf(context).width;
    if (width >= 720) {
      _selectProfileWorkspaceSection('settings');
      return;
    }

    _openCmrWindow(
      title: 'Настройки',
      icon: Icons.settings_outlined,
      maxWidth: 560,
      maxHeight: 780,
      child: _buildMobileAccountSettingsContent(),
    );
    if (mounted) setState(() => _mobileDockKey = 'more');
  }

  Widget _buildMobileAccountSettingsContent() {
    return Container(
      color: Colors.white,
      child: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(14, 16, 14, 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                _buildSmallAvatarForSheet(),
                const SizedBox(width: 11),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        fullName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 13.2,
                          weight: FontWeight.w600,
                          color: const Color(0xFF111827),
                          height: 1.15,
                          letterSpacing: 0,
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        _enteredAsText,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.custom(
                          size: 9.8,
                          weight: FontWeight.w400,
                          color: const Color(0xFF667085),
                          height: 1.2,
                          letterSpacing: 0,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: BoxDecoration(
                    color: const Color(0xFFF3FAF6),
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(
                    _roleLabel.toUpperCase(),
                    style: AppTypography.custom(
                      size: 8.5,
                      weight: FontWeight.w600,
                      color: const Color(0xFF067A46),
                      height: 1,
                      letterSpacing: .1,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              'АККАУНТ',
              style: AppTypography.custom(
                size: 8.6,
                weight: FontWeight.w600,
                color: const Color(0xFF98A2B3),
                height: 1,
                letterSpacing: .45,
              ),
            ),
            const SizedBox(height: 8),
            _buildSettingsRow(
              icon: Icons.account_tree_outlined,
              title: 'Выйти в Workspace',
              subtitle: 'Закрыть профиль и выбрать рабочий кабинет',
              strong: true,
              onTap: _goToWorkspaceHub,
            ),
            _buildSettingsRow(
              icon: Icons.camera_alt_outlined,
              title: _profileMediaEditTitle,
              subtitle: _profileMediaEditSubtitle,
              onTap: _openProfileMediaPickerSheet,
            ),
            _buildSettingsRow(
              icon: Icons.notifications_none_rounded,
              title: 'Уведомления',
              subtitle: 'Матчи, тренировки, чаты и события',
              onTap: () => Get.snackbar(
                'Уведомления',
                'Раздел подключим отдельным экраном.',
                snackPosition: SnackPosition.BOTTOM,
              ),
            ),
            _buildSettingsRow(
              icon: Icons.privacy_tip_outlined,
              title: 'Приватность и доступ',
              subtitle: 'Видимость профиля и личных данных',
              onTap: () => Get.snackbar(
                'Приватность',
                'Раздел подключим отдельным экраном.',
                snackPosition: SnackPosition.BOTTOM,
              ),
            ),
            _buildSettingsRow(
              icon: Icons.workspace_premium_rounded,
              title: 'PRO подписка',
              subtitle: 'Управление возможностями аккаунта',
              onTap: _openSubscriptionWindow,
            ),
            if (isOwnProfile) ...[
              const SizedBox(height: 10),
              Text(
                'СЕССИЯ',
                style: AppTypography.custom(
                  size: 8.6,
                  weight: FontWeight.w600,
                  color: const Color(0xFF98A2B3),
                  height: 1,
                  letterSpacing: .45,
                ),
              ),
              const SizedBox(height: 8),
              _buildSettingsRow(
                icon: Icons.logout_rounded,
                title: 'Выйти из профиля',
                subtitle: 'Завершить текущую сессию',
                onTap: _logoutFromProfile,
              ),
              _buildSettingsRow(
                icon: Icons.delete_forever_rounded,
                title: 'Удалить профиль',
                subtitle: 'Безвозвратное удаление аккаунта',
                danger: true,
                onTap: _deleteOwnProfileWithConfirmation,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildSmallAvatarForSheet() {
    final hasAvatar = (photo ?? '').trim().isNotEmpty;
    final avatar = Stack(
      clipBehavior: Clip.none,
      children: [
        Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
              color: const Color(0xFFF7F8FA),
              shape: BoxShape.circle,
              border: Border.all(color: const Color(0xFFE5E7EB))),
          child: ClipOval(
            child: hasAvatar
                ? Image.network(photo!,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                        Icons.person_rounded,
                        color: Color(0xFF667085),
                        size: 20))
                : const Icon(Icons.person_rounded,
                    color: Color(0xFF667085), size: 20),
          ),
        ),
        if (isOwnProfile)
          Positioned(
            right: -2,
            bottom: -2,
            child: Container(
              width: 18,
              height: 18,
              decoration: BoxDecoration(
                color: const Color(0xFF00A750),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 2),
              ),
              child: _uploadingProfilePhoto
                  ? const Padding(
                      padding: EdgeInsets.all(3),
                      child: CircularProgressIndicator(
                          strokeWidth: 1.6, color: Colors.white),
                    )
                  : const Icon(Icons.photo_camera_rounded,
                      color: Colors.white, size: 10),
            ),
          ),
      ],
    );

    if (!isOwnProfile) return avatar;

    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: _openProfileMediaPickerSheet,
      child: avatar,
    );
  }

  Widget _buildSettingsRow({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool strong = false,
    bool danger = false,
  }) {
    final titleColor =
        danger ? const Color(0xFFE11D48) : const Color(0xFF111827);
    final subtitleColor =
        danger ? const Color(0xFFBE123C) : const Color(0xFF667085);

    return InkWell(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minHeight: 48),
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: strong
            ? const BoxDecoration(
                color: Color(0xFFF3FAF6),
                border: Border(
                  left: BorderSide(color: Color(0xFF00A750), width: 3),
                ),
              )
            : null,
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.custom(
                      size: 11.8,
                      weight: strong ? FontWeight.w600 : FontWeight.w500,
                      color: titleColor,
                      height: 1.15,
                      letterSpacing: 0,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.custom(
                      size: 9.7,
                      weight: FontWeight.w400,
                      color: subtitleColor,
                      height: 1.2,
                      letterSpacing: 0,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Text(
              strong ? 'Открыть' : '',
              style: AppTypography.custom(
                size: 9.2,
                weight: FontWeight.w600,
                color: const Color(0xFF067A46),
                height: 1,
                letterSpacing: 0,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeaderSection() {
    final hasAvatar = (photo ?? '').trim().isNotEmpty;
    final infoLine = [
      if ((playerClubName ?? '').trim().isNotEmpty)
        (playerClubName ?? '').trim(),
      if ((playerTeamName ?? '').trim().isNotEmpty)
        (playerTeamName ?? '').trim(),
      if ((location ?? '').trim().isNotEmpty) (location ?? '').trim(),
    ].join(' • ');

    return Container(
      width: double.infinity,
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              _buildAvatar(hasAvatar),
              const SizedBox(width: 18),
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _buildInstagramStat(userPosts.length, 'посты'),
                    _buildInstagramStat(userReels.length, 'reels'),
                    GestureDetector(
                      onTap: () => _openUsersModal(showFollowers: true),
                      child: _buildInstagramStat(followersCount, 'подписчики'),
                    ),
                    GestureDetector(
                      onTap: () => _openUsersModal(showFollowers: false),
                      child: _buildInstagramStat(followingsCount, 'подписки'),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 11),
          Text(
            fullName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
                fontSize: 13.2,
                fontWeight: FontWeight.w900,
                color: Color(0xFF111827),
                height: 1.1),
          ),
          const SizedBox(height: 4),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              _buildProfileBadge(
                  _roleLabel,
                  isClubRole || isCoachRole || isParentRole
                      ? const Color(0xFF00A750)
                      : const Color(0xFF111827)),
              if (age != null)
                _buildProfileBadge('$age лет', const Color(0xFF667085)),
              if ((playerTeamName ?? '').trim().isNotEmpty)
                _buildProfileBadge(
                    (playerTeamName ?? '').trim(), const Color(0xFF2563EB)),
            ],
          ),
          if ((bio ?? '').trim().isNotEmpty) ...[
            const SizedBox(height: 7),
            Text(
              (bio ?? '').trim(),
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  fontSize: 11.7,
                  fontWeight: FontWeight.w500,
                  color: Color(0xFF1F2937),
                  height: 1.25),
            ),
          ],
          if (infoLine.isNotEmpty) ...[
            const SizedBox(height: 7),
            Row(
              children: [
                const Icon(Icons.location_on_outlined,
                    size: 14, color: Color(0xFF8A94A6)),
                const SizedBox(width: 4),
                Expanded(
                  child: Text(
                    infoLine,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 11.2,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF667085)),
                  ),
                ),
              ],
            ),
          ],
          const SizedBox(height: 11),
          Row(
            children: [
              Expanded(
                child: _buildSlimProfileButton(
                  label: isOwnProfile
                      ? 'Редактировать профиль'
                      : (isFollowing ? 'Вы подписаны' : 'Подписаться'),
                  icon: isOwnProfile
                      ? Icons.edit_note_rounded
                      : Icons.person_add_alt_1_rounded,
                  onTap:
                      isOwnProfile ? _openProfileSettingsSheet : _toggleFollow,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _buildSlimProfileButton(
                  label: isOwnProfile ? _primaryZoneTitle : 'Написать',
                  icon: isOwnProfile
                      ? _primaryZoneIcon
                      : Icons.chat_bubble_outline_rounded,
                  onTap: isOwnProfile ? _openPrimaryArea : _openPrivateChat,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInstagramStat(int value, String label) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          value.toString(),
          style: const TextStyle(
              fontSize: 14.5,
              fontWeight: FontWeight.w900,
              color: Color(0xFF111827),
              height: 1.05),
        ),
        const SizedBox(height: 3),
        Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
              fontSize: 10.2,
              fontWeight: FontWeight.w600,
              color: Color(0xFF667085),
              height: 1),
        ),
      ],
    );
  }

  Widget _buildProfileBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
            fontSize: 10.2,
            fontWeight: FontWeight.w900,
            color: color,
            height: 1),
      ),
    );
  }

  Widget _buildSlimProfileButton({
    required String label,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: onTap,
      child: Container(
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: const Color(0xFFF5F6F5),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(
            fontSize: 10.8,
            fontWeight: FontWeight.w700,
            color: Color(0xFF111827),
          ),
        ),
      ),
    );
  }

  Widget _buildAvatar(bool hasAvatar) {
    return GestureDetector(
      onTap: isOwnProfile ? _openProfileMediaPickerSheet : null,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Container(
            width: design.avatarSize,
            height: design.avatarSize,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                  color: design.avatarBorderColor,
                  width: design.avatarBorderWidth),
              boxShadow: design.avatarShadowEnabled
                  ? [
                      BoxShadow(
                        color: Color(design.avatarShadowColorValue)
                            .withOpacity(design.avatarShadowOpacity),
                        blurRadius: design.avatarShadowBlurRadius,
                        spreadRadius: design.avatarShadowSpreadRadius,
                        offset: Offset(design.avatarShadowOffsetX,
                            design.avatarShadowOffsetY),
                      )
                    ]
                  : null,
            ),
            child: ClipOval(
              child: hasAvatar
                  ? Image.network(photo!,
                      width: design.avatarSize,
                      height: design.avatarSize,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => _buildDefaultAvatar())
                  : _buildDefaultAvatar(),
            ),
          ),
          if (design.avatarGlowEnabled)
            Positioned.fill(
              child: IgnorePointer(
                child: AnimatedBuilder(
                  animation: _pulseController,
                  builder: (context, child) {
                    return Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: design.primaryColor.withOpacity(
                                design.avatarGlowOpacity *
                                    _pulseController.value),
                            blurRadius: design.avatarGlowRadius,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ),
          if (isOwnProfile)
            Positioned(
              bottom: 0,
              right: 0,
              child: Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: design.primaryColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
                child: _uploadingProfilePhoto
                    ? const Padding(
                        padding: EdgeInsets.all(7),
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.camera_alt_rounded,
                        size: 16, color: Colors.white),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildStatsSection() {
    return Container(
      padding: EdgeInsets.all(design.contentPadding),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                      design.cardShadowOffsetX, design.cardShadowOffsetY),
                )
              ]
            : null,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem(
              count: userPosts.length,
              label: design.statsShowLabels ? 'Посты' : null,
              icon: design.statsShowIcons ? Icons.grid_on_rounded : null),
          _buildStatItem(
              count: userReels.length,
              label: design.statsShowLabels ? 'Reels' : null,
              icon: design.statsShowIcons
                  ? Icons.play_circle_fill_rounded
                  : null),
          GestureDetector(
            onTap: () => _openUsersModal(showFollowers: false),
            child: _buildStatItem(
                count: followingsCount,
                label: design.statsShowLabels ? 'Подписки' : null,
                icon: design.statsShowIcons ? Icons.person_add_rounded : null),
          ),
          GestureDetector(
            onTap: () => _openUsersModal(showFollowers: true),
            child: _buildStatItem(
                count: followersCount,
                label: design.statsShowLabels ? 'Подписчики' : null,
                icon: design.statsShowIcons ? Icons.people_rounded : null),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem({required int count, String? label, IconData? icon}) {
    if (design.statsCompactMode) {
      return Column(
        children: [
          if (icon != null)
            Icon(icon, size: 20, color: design.textSecondaryColor),
          const SizedBox(height: 4),
          Text(count.toString(),
              style: _headingStyle.copyWith(color: design.textPrimaryColor)),
        ],
      );
    }

    return Column(
      children: [
        Text(count.toString(),
            style: _headingStyle.copyWith(
                fontSize: design.headingFontSize * 1.2,
                color: design.primaryColor)),
        const SizedBox(height: 4),
        if (label != null) Text(label, style: _smallStyle),
      ],
    );
  }

  Widget _buildActionsSection() {
    return Row(
      children: [
        Expanded(
            child: _buildActionButton(
          label: isFollowing ? 'Отписаться' : 'Подписаться',
          icon: isFollowing
              ? Icons.person_remove_rounded
              : Icons.person_add_rounded,
          onTap: _toggleFollow,
          primary: !isFollowing,
        )),
        const SizedBox(width: 8),
        Expanded(
            child: _buildActionButton(
          label: 'Написать',
          icon: Icons.chat_rounded,
          onTap: _openPrivateChat,
          primary: false,
        )),
      ],
    );
  }

  Widget _buildActionButton(
      {required String label,
      required IconData icon,
      required VoidCallback onTap,
      bool primary = true}) {
    final button = ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon, size: 18),
      label: Text(label,
          style: TextStyle(
              fontWeight: FontWeight.w700, fontSize: design.bodyFontSize)),
      style: ElevatedButton.styleFrom(
        backgroundColor: primary ? design.primaryColor : design.cardColor,
        foregroundColor: primary ? Colors.white : design.textPrimaryColor,
        elevation: 0,
        padding: EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(design.buttonRadius),
          side: primary
              ? BorderSide.none
              : BorderSide(color: design.textTertiaryColor),
        ),
      ),
    );

    if (design.enableHoverEffects) {
      return _HoverAnimation(child: button);
    }

    return button;
  }

  Widget _buildBlock(ProfileBlock block) {
    switch (block.id) {
      case 'team':
        return _buildTeamCard();
      case 'ai':
        if (!isPlayer || !_enableSportotekaAi) return const SizedBox();
        return _buildAiSection();
      case 'skills':
        if (!isPlayer) return const SizedBox();
        return _buildSkillsSection();
      case 'bio':
        if (bio?.isEmpty != false) return const SizedBox();
        return _buildBioSection();
      case 'location':
        if (location?.isEmpty != false) return const SizedBox();
        return _buildLocationSection();
      default:
        return const SizedBox();
    }
  }

  Widget _buildTeamCard() {
    final logo = (playerTeamLogoUrl ?? '').trim();
    final team = (playerTeamName ?? '').trim();
    final club = (playerClubName ?? '').trim();

    if (team.isEmpty && club.isEmpty) return const SizedBox();

    return Container(
      padding: EdgeInsets.all(design.contentPadding),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                      design.cardShadowOffsetX, design.cardShadowOffsetY),
                )
              ]
            : null,
      ),
      child: Row(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: design.primaryColor.withOpacity(0.08),
              border: Border.all(color: design.primaryColor.withOpacity(0.18)),
            ),
            child: ClipOval(
              child: logo.isNotEmpty
                  ? Image.network(logo, fit: BoxFit.cover)
                  : Icon(Icons.shield_outlined,
                      color: design.primaryColor, size: 26),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(team.isNotEmpty ? team : "Команда", style: _headingStyle),
                const SizedBox(height: 4),
                Text(club.isNotEmpty ? "Клуб: $club" : "Клуб: —",
                    style: _bodyStyle),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
                color: design.primaryColor,
                borderRadius: BorderRadius.circular(12)),
            child: Text("Профи",
                style: _smallStyle.copyWith(
                    color: Colors.white, fontWeight: FontWeight.w800)),
          ),
        ],
      ),
    );
  }

  Widget _buildAiSection() {
    // ===== НОВЫЙ КОД =====
    if (!_enableSportotekaAi) return const SizedBox();

    return _buildExpandableCard(
      title: "Спортотека AI",
      icon: Icons.auto_awesome_rounded,
      expanded: _aiExpanded,
      onToggle: () => setState(() => _aiExpanded = !_aiExpanded),
      badge: const Text("BETA"),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                  child: Text("Персонально для: $fullName",
                      style: _smallStyle.copyWith(
                          color: design.textSecondaryColor,
                          fontWeight: FontWeight.w700))),
              IconButton(
                  onPressed: () =>
                      setState(() => _aiCardSeed = _rnd.nextInt(999999)),
                  icon: Icon(Icons.refresh_rounded,
                      color: design.textSecondaryColor)),
            ],
          ),
          const SizedBox(height: 10),
          _AiMatchIqCard(
              seed: _aiCardSeed,
              playerName: fullName,
              position: "ST",
              design: design),
          const SizedBox(height: 10),
          _AiTrainingScanCard(seed: _aiCardSeed, design: design),
          const SizedBox(height: 10),
          _AiWeeklyChallengeCard(seed: _aiCardSeed, design: design),
        ],
      ),
    );
  }

  Widget _buildSkillsSection() {
    return _buildExpandableCard(
      title: "Скиллы игрока",
      icon: Icons.shield_outlined,
      expanded: _skillsExpanded,
      onToggle: () => setState(() => _skillsExpanded = !_skillsExpanded),
      subtitle: "Автоматически рассчитываются на основе тренировок",
      child: PlayerSkillsFifaStub(
        playerName: fullName,
        position: "ST",
        clubName: (playerClubName ?? "Sportoteka").toString(),
        photoUrl: photo,
      ),
    );
  }

  Widget _buildExpandableCard({
    required String title,
    required IconData icon,
    required bool expanded,
    required VoidCallback onToggle,
    String? subtitle,
    Widget? badge,
    required Widget child,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                      design.cardShadowOffsetX, design.cardShadowOffsetY),
                )
              ]
            : null,
      ),
      child: Column(
        children: [
          InkWell(
            onTap: onToggle,
            borderRadius: BorderRadius.circular(design.cardRadius),
            child: Padding(
              padding: EdgeInsets.all(design.contentPadding),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                        color: design.primaryColor.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(14)),
                    child: Icon(icon, color: design.primaryColor),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Expanded(child: Text(title, style: _headingStyle)),
                            if (badge != null) badge,
                          ],
                        ),
                        if (subtitle != null) ...[
                          const SizedBox(height: 3),
                          Text(subtitle, style: _smallStyle, maxLines: 2),
                        ],
                      ],
                    ),
                  ),
                  AnimatedRotation(
                    turns: expanded ? 0.5 : 0.0,
                    duration: const Duration(milliseconds: 220),
                    child: Icon(Icons.keyboard_arrow_down_rounded,
                        color: design.textSecondaryColor),
                  ),
                ],
              ),
            ),
          ),
          AnimatedCrossFade(
            firstChild: const SizedBox(height: 0),
            secondChild: Padding(
              padding: EdgeInsets.fromLTRB(design.contentPadding, 0,
                  design.contentPadding, design.contentPadding),
              child: child,
            ),
            crossFadeState:
                expanded ? CrossFadeState.showSecond : CrossFadeState.showFirst,
            duration: const Duration(milliseconds: 220),
          ),
        ],
      ),
    );
  }

  Widget _buildBioSection() {
    return Container(
      padding: EdgeInsets.all(design.contentPadding),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                      design.cardShadowOffsetX, design.cardShadowOffsetY),
                )
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.info_outline_rounded,
                  size: 18, color: design.primaryColor),
              const SizedBox(width: 8),
              Text('О себе', style: _headingStyle),
            ],
          ),
          const SizedBox(height: 8),
          Text(bio!, style: _bodyStyle),
        ],
      ),
    );
  }

  Widget _buildLocationSection() {
    return Container(
      padding: EdgeInsets.all(design.contentPadding),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                      design.cardShadowOffsetX, design.cardShadowOffsetY),
                )
              ]
            : null,
      ),
      child: Row(
        children: [
          Icon(Icons.location_on_rounded, size: 18, color: design.primaryColor),
          const SizedBox(width: 8),
          Expanded(child: Text(location!, style: _bodyStyle)),
        ],
      ),
    );
  }

  Widget _buildModeSwitcher() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(color: Color(0xFFE9ECEA), width: .7),
        ),
      ),
      child: Row(
        children: [
          _buildModeButton(
            active: _mode == _ProfileFeedMode.posts,
            icon: Icons.grid_on_rounded,
            label: 'Посты',
            onTap: () => _selectProfileWorkspaceSection('posts'),
          ),
          _buildModeButton(
            active: _mode == _ProfileFeedMode.feed,
            icon: Icons.article_outlined,
            label: 'Лента',
            onTap: () => setState(() => _mode = _ProfileFeedMode.feed),
          ),
          _buildModeButton(
            active: _mode == _ProfileFeedMode.reels,
            icon: Icons.play_circle_outline_rounded,
            label: 'Reels',
            onTap: () => setState(() => _mode = _ProfileFeedMode.reels),
          ),
        ],
      ),
    );
  }

  Widget _buildModeButton({
    required bool active,
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 170),
          height: 42,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            border: Border(
              bottom: BorderSide(
                color: active ? const Color(0xFF00A750) : Colors.transparent,
                width: 2.2,
              ),
            ),
          ),
          child: Text(
            label,
            style: _flagshipText(
              10.9,
              color: active ? const Color(0xFF111827) : const Color(0xFF98A2B3),
              weight: active ? FontWeight.w700 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContentGrid() {
    if (_mode == _ProfileFeedMode.reels) {
      return _buildReelsGrid();
    }
    if (_mode == _ProfileFeedMode.feed) {
      return _buildFeedGrid();
    }

    // Профиль хранит личные публикации пользователя: сетка и лента — это разные виды одного контента.
    return _buildPostsGrid();
  }

  int _profileGridCrossAxisCount() {
    final width = MediaQuery.maybeOf(context)?.size.width ?? 0;
    // На ПК/планшете профильная сетка должна быть плотнее: 4 карточки в ряд.
    // На мобильной версии оставляем классические 3 колонки, ближе к Instagram.
    return width >= 720 ? 4 : 3;
  }

  Widget _buildPostsGrid() {
    if (isLoadingPosts) {
      return Center(
          child: CircularProgressIndicator(color: design.primaryColor));
    }

    if (userPosts.isEmpty) {
      return _buildEmptyState(
          icon: Icons.add_photo_alternate_outlined, message: 'Пока нет постов');
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _profileGridCrossAxisCount(),
        crossAxisSpacing: 4,
        mainAxisSpacing: 4,
        childAspectRatio: 1,
      ),
      itemCount: userPosts.length,
      itemBuilder: (context, index) {
        final post = userPosts[index] as Map<String, dynamic>;
        final imageUrl = (post['image'] ?? '').toString().trim();
        final hasImage = imageUrl.isNotEmpty;

        return GestureDetector(
          onTap: () => _openFeedPostDetail(_profileGridPostToDetail(post)),
          child: Container(
            color: design.surfaceColor,
            child: Stack(
              fit: StackFit.expand,
              children: [
                if (hasImage)
                  Image.network(imageUrl, fit: BoxFit.cover)
                else
                  Container(
                    color: design.surfaceColor,
                    child: Center(
                        child: Icon(Icons.article_outlined,
                            size: 40, color: design.textTertiaryColor)),
                  ),
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.bottomCenter,
                      end: Alignment.topCenter,
                      colors: [
                        Colors.black.withOpacity(0.30),
                        Colors.transparent
                      ],
                    ),
                  ),
                ),
                Positioned(
                  top: 8,
                  right: 8,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.50),
                        borderRadius: BorderRadius.circular(6)),
                    child: Icon(hasImage ? Icons.photo : Icons.article,
                        size: 16, color: Colors.white),
                  ),
                ),
                if (isOwnProfile)
                  Positioned(
                    top: 8,
                    left: 8,
                    child: _buildDeleteMenuButton(onTap: () {
                      final postId = _toInt(post['id']);
                      _openItemActionsSheet(
                          title: "Пост",
                          onDelete: () => _deletePostById(postId));
                    }),
                  ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildReelsGrid() {
    if (isLoadingReels) {
      return Center(
          child: CircularProgressIndicator(color: design.primaryColor));
    }

    if (userReels.isEmpty) {
      return _buildEmptyState(
          icon: Icons.play_circle_outline, message: 'Пока нет Reels');
    }

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: _profileGridCrossAxisCount(),
        crossAxisSpacing: 4,
        mainAxisSpacing: 4,
        childAspectRatio: 9 / 16,
      ),
      itemCount: userReels.length,
      itemBuilder: (context, index) {
        final reel = userReels[index];

        return GestureDetector(
          onTap: () async {
            final viewedUserId =
                widget.userId ?? await PrefUtils.getUserId() ?? 0;
            if (!mounted || viewedUserId <= 0) return;

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => UserReelsScreen(
                  userId: viewedUserId,
                  initialIndex: index,
                  title: "Reels: $fullName",
                ),
              ),
            ).then((_) => _fetchUserReels());
          },
          child: Stack(
            fit: StackFit.expand,
            children: [
              PlayerProfileReelWidget(
                videoUrl: reel['video_url'] ?? '',
                thumbnailUrl: reel['thumbnail'] ?? '',
                autoPlay: false,
                muted: true,
                rotationDeg: reel['rotation'] as int?,
                cropMode: reel['crop_mode'] as String?,
                cropScale: (reel['crop_scale'] as num?)?.toDouble(),
                cropDx: (reel['crop_dx'] as num?)?.toDouble(),
                cropDy: (reel['crop_dy'] as num?)?.toDouble(),
              ),
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter,
                    colors: [
                      Colors.black.withOpacity(0.25),
                      Colors.transparent
                    ],
                  ),
                ),
              ),
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.all(6),
                  decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.55),
                      borderRadius: BorderRadius.circular(10)),
                  child: const Icon(Icons.play_circle_fill_rounded,
                      color: Colors.white, size: 18),
                ),
              ),
              if (isOwnProfile)
                Positioned(
                  left: 8,
                  top: 8,
                  child: _buildDeleteMenuButton(onTap: () {
                    final reelId = _toInt(reel['id']);
                    _openItemActionsSheet(
                        title: "Reels",
                        onDelete: () => _deleteReelById(reelId));
                  }),
                ),
              Positioned(
                left: 8,
                bottom: 8,
                child: Row(
                  children: [
                    _buildMiniBadge("❤ ${reel['likes'] ?? 0}"),
                    const SizedBox(width: 6),
                    _buildMiniBadge("💬 ${reel['comments'] ?? 0}"),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildFeedGrid() {
    if (isLoadingFeed) {
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 28),
        child: Center(
            child: CircularProgressIndicator(color: design.primaryColor)),
      );
    }

    if (feedPosts.isEmpty) {
      return _buildEmptyState(
          icon: Icons.public_rounded,
          message: 'В ленте профиля пока нет публикаций');
    }

    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 680),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 16, 14, 8),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF3F7F5),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.public_rounded,
                        size: 17, color: Color(0xFF667085)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Лента профиля',
                          style: AppTypography.custom(
                            size: 13,
                            weight: FontWeight.w700,
                            color: const Color(0xFF0B0F14),
                            height: 1.18,
                            letterSpacing: 0,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          'Публикации, которые добавил этот пользователь',
                          style: AppTypography.custom(
                            size: 10.5,
                            weight: FontWeight.w500,
                            color: const Color(0xFF98A2B3),
                            height: 1.25,
                            letterSpacing: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                  TextButton(
                    onPressed: () => _selectProfileWorkspaceSection('posts'),
                    style: TextButton.styleFrom(
                      foregroundColor: const Color(0xFF101828),
                      textStyle: AppTypography.custom(
                        size: 10.5,
                        weight: FontWeight.w600,
                        color: const Color(0xFF101828),
                        height: 1.15,
                        letterSpacing: 0,
                      ),
                    ),
                    child: const Text('Сетка'),
                  ),
                ],
              ),
            ),
            ...feedPosts.map((post) => _buildCommunityNewsCard(post)).toList(),
            const SizedBox(height: 18),
          ],
        ),
      ),
    );
  }

  Widget _buildCommunityNewsCard(Map<String, dynamic> post) {
    final img = _safeStr(post['imageUrl']).trim();
    final avatar = _safeStr(post['authorAvatar']).trim();
    final hasImage = img.isNotEmpty;
    final category = _safeStr(post['category']).trim();
    final title = _safeStr(post['title']).trim();
    final text = _safeStr(post['text']).trim();
    final author = _safeStr(post['authorName']).trim().isNotEmpty
        ? _safeStr(post['authorName']).trim()
        : 'Сообщество';
    final date =
        post['date'] is DateTime ? post['date'] as DateTime : DateTime.now();

    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          borderRadius: BorderRadius.circular(18),
          onTap: () => _openFeedPostDetail(post),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(
                  color: const Color(0xFFE9ECEA).withOpacity(.55), width: .7),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
                  child: Row(
                    children: [
                      CircleAvatar(
                        radius: 16,
                        backgroundColor: const Color(0xFFF3F7F5),
                        backgroundImage:
                            avatar.isNotEmpty ? NetworkImage(avatar) : null,
                        child: avatar.isEmpty
                            ? const Icon(Icons.groups_2_outlined,
                                size: 16, color: Color(0xFF667085))
                            : null,
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              author,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTypography.custom(
                                  size: 11.5,
                                  weight: FontWeight.w600,
                                  color: const Color(0xFF0B0F14),
                                  height: 1.18),
                            ),
                            const SizedBox(height: 1),
                            Text(
                              '${category.isNotEmpty ? '$category • ' : ''}${_formatFeedDate(date)}',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: AppTypography.custom(
                                  size: 10,
                                  weight: FontWeight.w400,
                                  color: const Color(0xFF8A9099),
                                  height: 1.30),
                            ),
                          ],
                        ),
                      ),
                      const Icon(Icons.more_horiz_rounded,
                          size: 18, color: Color(0xFF98A2B3)),
                    ],
                  ),
                ),
                if (hasImage)
                  ClipRRect(
                    borderRadius: BorderRadius.circular(0),
                    child: AspectRatio(
                      aspectRatio: 16 / 9,
                      child: Image.network(
                        img,
                        fit: BoxFit.contain,
                        errorBuilder: (_, __, ___) => Container(
                          color: const Color(0xFFF3F7F5),
                          alignment: Alignment.center,
                          child: const Icon(Icons.image_not_supported_outlined,
                              color: Color(0xFF98A2B3)),
                        ),
                      ),
                    ),
                  ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      if (title.isNotEmpty)
                        Text(
                          title,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.custom(
                              size: 12.5,
                              weight: FontWeight.w600,
                              color: const Color(0xFF0B0F14),
                              height: 1.25),
                        ),
                      if (text.isNotEmpty) ...[
                        const SizedBox(height: 5),
                        Text(
                          text,
                          maxLines: 3,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.custom(
                            size: 11,
                            weight: FontWeight.w400,
                            color: const Color(0xFF475467),
                            height: 1.35,
                            letterSpacing: 0,
                          ),
                        ),
                      ],
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          _buildCommunityNewsMeta(Icons.favorite_border_rounded,
                              '${_safeInt(post['likes'])}'),
                          const SizedBox(width: 12),
                          _buildCommunityNewsMeta(
                              Icons.chat_bubble_outline_rounded,
                              '${_safeInt(post['comments'])}'),
                          const Spacer(),
                          Text(
                            'Открыть',
                            style: AppTypography.custom(
                              size: 10.5,
                              weight: FontWeight.w600,
                              color: const Color(0xFF101828),
                              height: 1.15,
                              letterSpacing: 0,
                            ),
                          ),
                          const SizedBox(width: 4),
                          const Icon(Icons.arrow_forward_ios_rounded,
                              size: 10, color: Color(0xFF101828)),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCommunityNewsMeta(IconData icon, String value) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 15, color: const Color(0xFF98A2B3)),
        const SizedBox(width: 4),
        Text(
          value,
          style: AppTypography.custom(
            size: 10.5,
            weight: FontWeight.w500,
            color: const Color(0xFF667085),
            height: 1.15,
            letterSpacing: 0,
          ),
        ),
      ],
    );
  }

  String _formatFeedDate(DateTime date) {
    final now = DateTime.now();
    final diff = now.difference(date);
    if (diff.inMinutes < 1) return 'только что';
    if (diff.inMinutes < 60) return '${diff.inMinutes} мин назад';
    if (diff.inHours < 24) return '${diff.inHours} ч назад';
    if (diff.inDays < 7) return '${diff.inDays} дн назад';
    final d = date.day.toString().padLeft(2, '0');
    final m = date.month.toString().padLeft(2, '0');
    return '$d.$m.${date.year}';
  }

  Widget _buildDeleteMenuButton({required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(6),
        decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.50),
            borderRadius: BorderRadius.circular(10)),
        child: const Icon(Icons.more_horiz, size: 18, color: Colors.white),
      ),
    );
  }

  Widget _buildMiniBadge(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.55),
          borderRadius: BorderRadius.circular(999)),
      child: Text(text,
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w800, fontSize: 11)),
    );
  }

  Widget _buildEmptyState({required IconData icon, required String message}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 48),
      child: Column(
        children: [
          Icon(icon, size: 64, color: design.textTertiaryColor),
          const SizedBox(height: 16),
          Text(message,
              style: _bodyStyle.copyWith(color: design.textSecondaryColor)),
        ],
      ),
    );
  }

  Widget _buildDefaultAvatar() {
    return Container(
      color: design.surfaceColor,
      child: Center(
          child: Icon(Icons.person,
              size: design.avatarSize * 0.5, color: design.primaryColor)),
    );
  }
}

// =============================
// ВСПОМОГАТЕЛЬНЫЕ КЛАССЫ (ОСТАВЛЯЕМ)
// =============================

class _ProfileFullModulesMenuOverlay extends StatelessWidget {
  final String title;
  final String subtitle;
  final String? photoUrl;
  final List<_ProfileFlagshipAction> actions;
  final ValueChanged<_ProfileFlagshipAction> onSelect;

  const _ProfileFullModulesMenuOverlay({
    required this.title,
    required this.subtitle,
    required this.photoUrl,
    required this.actions,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.of(context);
    final width = media.size.width;
    final height = media.size.height;
    final compact = width < 720;
    final columns = compact ? 4 : 6;
    final menuWidth = min(compact ? width - 22 : 760.0, width - 32);
    final maxHeight = max(320.0, min(height - 118, compact ? 560.0 : 600.0));

    return Material(
      color: Colors.transparent,
      child: SafeArea(
        child: Align(
          alignment: Alignment.bottomCenter,
          child: Padding(
            padding: EdgeInsets.fromLTRB(12, 12, 12, compact ? 78 : 88),
            child: Container(
              width: menuWidth,
              constraints: BoxConstraints(maxHeight: maxHeight),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(.985),
                borderRadius: BorderRadius.circular(compact ? 24 : 30),
                border: Border.all(color: Colors.white.withOpacity(.88)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(.18),
                    blurRadius: 46,
                    offset: const Offset(0, 22),
                  ),
                  BoxShadow(
                    color: Colors.white.withOpacity(.72),
                    blurRadius: 10,
                    offset: const Offset(0, -2),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(compact ? 24 : 30),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Padding(
                      padding: EdgeInsets.fromLTRB(compact ? 14 : 18,
                          compact ? 13 : 16, compact ? 10 : 14, 10),
                      child: Row(
                        children: [
                          _ProfileMenuAvatar(
                              photoUrl: photoUrl, size: compact ? 38 : 44),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  title.trim().isEmpty
                                      ? 'Мой профиль'
                                      : title.trim(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTypography.custom(
                                    size: 14.2,
                                    weight: FontWeight.w600,
                                    color: const Color(0xFF111827),
                                    height: 1.1,
                                    letterSpacing: 0,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  subtitle.trim().isEmpty
                                      ? 'Sportoteka Workspace'
                                      : subtitle.trim(),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: AppTypography.custom(
                                    size: 10.4,
                                    weight: FontWeight.w400,
                                    color: const Color(0xFF667085),
                                    height: 1.1,
                                    letterSpacing: 0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 7),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF7F9F8),
                              borderRadius: BorderRadius.circular(999),
                              border:
                                  Border.all(color: const Color(0xFFEFF2F5)),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(Icons.apps_rounded,
                                    color: const Color(0xFF344054),
                                    size: compact ? 16 : 17),
                                const SizedBox(width: 4),
                                Text(
                                  '${actions.length} разделов',
                                  style: AppTypography.custom(
                                    size: 10,
                                    weight: FontWeight.w500,
                                    color: const Color(0xFF667085),
                                    height: 1,
                                    letterSpacing: 0,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(width: 4),
                          IconButton(
                            onPressed: () => Navigator.of(context).pop(),
                            icon: const Icon(Icons.close_rounded,
                                color: Color(0xFF344054)),
                            tooltip: 'Закрыть',
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: compact ? 14 : 18),
                      child:
                          Container(height: 1, color: const Color(0xFFEFF2F5)),
                    ),
                    Flexible(
                      child: Padding(
                        padding: EdgeInsets.fromLTRB(compact ? 12 : 16, 14,
                            compact ? 12 : 16, compact ? 12 : 16),
                        child: GridView.builder(
                          shrinkWrap: true,
                          physics: const BouncingScrollPhysics(),
                          itemCount: actions.length,
                          gridDelegate:
                              SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: columns,
                            mainAxisSpacing: compact ? 8 : 10,
                            crossAxisSpacing: compact ? 6 : 8,
                            childAspectRatio: compact ? .88 : .92,
                          ),
                          itemBuilder: (context, index) {
                            final action = actions[index];
                            return _ProfileModuleMenuTile(
                              action: action,
                              selected: index == 0,
                              onTap: () => onSelect(action),
                            );
                          },
                        ),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.fromLTRB(compact ? 14 : 18, 0,
                          compact ? 14 : 18, compact ? 12 : 14),
                      child: Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 9),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF7F9F8),
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: const Color(0xFFEFF2F5)),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.search_rounded,
                                color: Color(0xFF667085), size: 18),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'Для быстрого поиска используйте кнопку «Поиск» в нижнем меню',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: AppTypography.custom(
                                  size: 10.2,
                                  weight: FontWeight.w400,
                                  color: const Color(0xFF667085),
                                  height: 1.15,
                                  letterSpacing: 0,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _ProfileMenuAvatar extends StatelessWidget {
  final String? photoUrl;
  final double size;
  const _ProfileMenuAvatar({required this.photoUrl, required this.size});

  @override
  Widget build(BuildContext context) {
    final image = (photoUrl ?? '').trim();
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: const Color(0xFFF7F9F8),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFEFF2F5)),
      ),
      clipBehavior: Clip.antiAlias,
      child: image.isEmpty
          ? const Icon(Icons.person_rounded, color: Color(0xFF344054), size: 21)
          : Image.network(
              image,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded,
                  color: Color(0xFF344054), size: 21),
            ),
    );
  }
}

class _ProfileModuleMenuTile extends StatelessWidget {
  final _ProfileFlagshipAction action;
  final bool selected;
  final VoidCallback onTap;

  const _ProfileModuleMenuTile({
    required this.action,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final danger = action.danger;
    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 6),
          decoration: BoxDecoration(
            color: selected ? const Color(0xFFF7F9F8) : Colors.transparent,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(
              color: selected ? const Color(0xFFD8DEE6) : Colors.transparent,
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: selected ? 54 : 50,
                    height: selected ? 54 : 50,
                    decoration: BoxDecoration(
                      color: selected ? const Color(0xFFE2E6EA) : Colors.white,
                      borderRadius: BorderRadius.circular(17),
                      border: Border.all(color: const Color(0xFFE9EEF3)),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(.045),
                          blurRadius: 14,
                          offset: const Offset(0, 7),
                        ),
                      ],
                    ),
                    child: Icon(
                      action.icon,
                      size: selected ? 25 : 23,
                      color: danger
                          ? const Color(0xFFD92D20)
                          : const Color(0xFF344054),
                    ),
                  ),
                  if (action.pro)
                    Positioned(
                      right: -4,
                      top: -4,
                      child: Container(
                        width: 16,
                        height: 16,
                        decoration: BoxDecoration(
                          color: const Color(0xFFFFF1E8),
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 1.5),
                        ),
                        child: const Icon(Icons.lock_rounded,
                            size: 9, color: Color(0xFFF05A18)),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 7),
              Flexible(
                child: Text(
                  action.title,
                  maxLines: 2,
                  textAlign: TextAlign.center,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.custom(
                    size: 10.7,
                    weight: FontWeight.w500,
                    color: danger
                        ? const Color(0xFFD92D20)
                        : const Color(0xFF172033),
                    height: 1.08,
                    letterSpacing: 0,
                  ),
                ),
              ),
              if (selected) ...[
                const SizedBox(height: 5),
                Container(
                  width: 20,
                  height: 3,
                  decoration: BoxDecoration(
                    color: const Color(0xFF344054),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfilePeopleSearchPanel extends StatefulWidget {
  const _ProfilePeopleSearchPanel({
    required this.apiBase,
    required this.myUserId,
    required this.onOpenUser,
  });

  final String apiBase;
  final int myUserId;
  final ValueChanged<int> onOpenUser;

  @override
  State<_ProfilePeopleSearchPanel> createState() =>
      _ProfilePeopleSearchPanelState();
}

class _ProfilePeopleSearchPanelState extends State<_ProfilePeopleSearchPanel> {
  final TextEditingController _controller = TextEditingController();
  Timer? _debounce;
  bool _loading = false;
  String _filter = 'all';
  String? _error;
  List<Map<String, dynamic>> _results = const [];

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  void _onChanged(String value) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 380), _search);
  }

  Future<void> _search() async {
    final query = _controller.text.trim();
    if (query.length < 2) {
      if (!mounted) return;
      setState(() {
        _results = const [];
        _error = null;
        _loading = false;
      });
      return;
    }

    setState(() {
      _loading = true;
      _error = null;
    });

    try {
      final uri = Uri.parse('${widget.apiBase}/search_users.php').replace(
        queryParameters: <String, String>{
          'q': query,
          if (widget.myUserId > 0) 'exclude_id': widget.myUserId.toString(),
          if (widget.myUserId > 0) 'exclude': widget.myUserId.toString(),
        },
      );

      http.Response response =
          await http.get(uri).timeout(const Duration(seconds: 12));
      if (response.statusCode == 405) {
        response = await http.post(
          Uri.parse('${widget.apiBase}/search_users.php'),
          body: <String, String>{
            'q': query,
            if (widget.myUserId > 0) 'exclude_id': widget.myUserId.toString(),
            if (widget.myUserId > 0) 'exclude': widget.myUserId.toString(),
          },
        ).timeout(const Duration(seconds: 12));
      }

      if (response.statusCode != 200) {
        throw Exception('HTTP ${response.statusCode}');
      }

      final decoded = jsonDecode(utf8.decode(response.bodyBytes));
      final raw = _extractUsers(decoded);
      final parsed = raw
          .map(_normalizeUser)
          .where((e) => (e['id'] as int) > 0)
          .where(_matchesFilter)
          .toList();

      if (!mounted) return;
      setState(() => _results = parsed);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _results = const [];
        _error = 'Поиск временно недоступен. Попробуйте ещё раз чуть позже.';
      });
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  List<Map<String, dynamic>> _extractUsers(dynamic data) {
    if (data is List) {
      return data
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .toList();
    }
    if (data is Map) {
      final map = Map<String, dynamic>.from(data);
      for (final key in const ['users', 'data', 'results', 'items', 'list']) {
        final value = map[key];
        if (value is List) {
          return value
              .whereType<Map>()
              .map((e) => Map<String, dynamic>.from(e))
              .toList();
        }
        if (value is Map) {
          final nested = Map<String, dynamic>.from(value);
          for (final nestedKey in const [
            'users',
            'data',
            'results',
            'items',
            'list'
          ]) {
            final nestedValue = nested[nestedKey];
            if (nestedValue is List) {
              return nestedValue
                  .whereType<Map>()
                  .map((e) => Map<String, dynamic>.from(e))
                  .toList();
            }
          }
        }
      }
    }
    return const [];
  }

  Map<String, dynamic> _normalizeUser(Map<String, dynamic> raw) {
    int asInt(dynamic value) =>
        value is num ? value.toInt() : int.tryParse('${value ?? ''}') ?? 0;
    String clean(dynamic value) {
      final v = '${value ?? ''}'.trim();
      return v.toLowerCase() == 'null' ? '' : v;
    }

    final first =
        clean(raw['first_name'] ?? raw['firstname'] ?? raw['firstName']);
    final last = clean(raw['last_name'] ?? raw['lastname'] ?? raw['lastName']);
    final fallbackName =
        clean(raw['full_name'] ?? raw['fullName'] ?? raw['name']);
    final fullName =
        '$first $last'.trim().isNotEmpty ? '$first $last'.trim() : fallbackName;
    var photo = clean(raw['photo_url'] ??
        raw['avatar_url'] ??
        raw['photoUrl'] ??
        raw['photo'] ??
        raw['avatar']);
    if (photo.isNotEmpty &&
        !photo.startsWith('http://') &&
        !photo.startsWith('https://')) {
      photo =
          'https://sportotekaapp.ru/uploads/${photo.replaceFirst(RegExp(r'^/+'), '')}';
    }

    return <String, dynamic>{
      'id': asInt(raw['id'] ?? raw['user_id'] ?? raw['userId']),
      'name': fullName.isEmpty ? 'Пользователь' : fullName,
      'role': clean(raw['role'] ?? raw['user_role'] ?? raw['type']),
      'team': clean(raw['team_name'] ?? raw['teamName']),
      'club': clean(raw['club_name'] ?? raw['clubName']),
      'photo': photo,
    };
  }

  bool _matchesFilter(Map<String, dynamic> user) {
    if (_filter == 'all') return true;
    final role = '${user['role'] ?? ''}'.toLowerCase();
    if (role.trim().isEmpty) return true;
    if (_filter == 'player')
      return role.contains('player') || role.contains('игрок');
    if (_filter == 'coach') {
      return role.contains('coach') ||
          role.contains('trainer') ||
          role.contains('тренер');
    }
    return true;
  }

  String _roleLabel(String role) {
    final value = role.toLowerCase();
    if (value.contains('coach') ||
        value.contains('trainer') ||
        value.contains('тренер')) return 'Тренер';
    if (value.contains('player') || value.contains('игрок')) return 'Игрок';
    if (value.contains('club') || value.contains('клуб')) return 'Клуб';
    if (value.contains('parent') || value.contains('родител'))
      return 'Родитель';
    return role.trim().isEmpty ? 'Пользователь' : role.trim();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 46,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: const Color(0xFFF6F7F9),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Row(
              children: [
                const Icon(Icons.search_rounded,
                    size: 20, color: Color(0xFF667085)),
                const SizedBox(width: 8),
                Expanded(
                  child: TextField(
                    controller: _controller,
                    autofocus: true,
                    onChanged: _onChanged,
                    onSubmitted: (_) => _search(),
                    decoration: const InputDecoration(
                      isDense: true,
                      border: InputBorder.none,
                      hintText: 'Имя игрока, тренера или пользователя',
                      hintStyle: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w500,
                          color: Color(0xFF98A2B3)),
                    ),
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Color(0xFF111827)),
                  ),
                ),
                if (_controller.text.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.close_rounded, size: 18),
                    onPressed: () {
                      _controller.clear();
                      setState(() {
                        _results = const [];
                        _error = null;
                      });
                    },
                  ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _filterChip('all', 'Все'),
              const SizedBox(width: 7),
              _filterChip('player', 'Игроки'),
              const SizedBox(width: 7),
              _filterChip('coach', 'Тренеры'),
            ],
          ),
          const SizedBox(height: 12),
          Expanded(child: _buildBody()),
        ],
      ),
    );
  }

  Widget _filterChip(String value, String label) {
    final active = _filter == value;
    return InkWell(
      borderRadius: BorderRadius.circular(999),
      onTap: () {
        setState(() => _filter = value);
        if (_controller.text.trim().length >= 2) _search();
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: active ? const Color(0xFF111827) : const Color(0xFFF6F7F9),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 10.8,
            fontWeight: FontWeight.w600,
            color: active ? Colors.white : const Color(0xFF667085),
          ),
        ),
      ),
    );
  }

  Widget _buildBody() {
    if (_loading) {
      return const Center(
          child: CircularProgressIndicator(
              color: Color(0xFF00A750), strokeWidth: 2.2));
    }
    if (_error != null) {
      return _emptyState(
          Icons.cloud_off_outlined, 'Поиск временно недоступен', _error!);
    }
    if (_controller.text.trim().length < 2) {
      return _emptyState(
        Icons.person_search_outlined,
        'Найдите людей в Sportoteka',
        'Введите минимум 2 символа. Можно отдельно искать игроков и тренеров.',
      );
    }
    if (_results.isEmpty) {
      return _emptyState(Icons.search_off_rounded, 'Ничего не найдено',
          'Попробуйте другое имя или переключите категорию.');
    }

    return ListView.separated(
      physics: const BouncingScrollPhysics(),
      itemCount: _results.length,
      separatorBuilder: (_, __) => const SizedBox(height: 6),
      itemBuilder: (context, index) {
        final user = _results[index];
        final photo = '${user['photo'] ?? ''}'.trim();
        final team = '${user['team'] ?? ''}'.trim();
        final club = '${user['club'] ?? ''}'.trim();
        final contextLine =
            [if (club.isNotEmpty) club, if (team.isNotEmpty) team].join(' · ');
        return Material(
          color: const Color(0xFFF8F9FA),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: () => widget.onOpenUser(user['id'] as int),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(10, 9, 10, 9),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 22,
                    backgroundColor: const Color(0xFFF1FBF6),
                    backgroundImage:
                        photo.isNotEmpty ? NetworkImage(photo) : null,
                    child: photo.isEmpty
                        ? Text(
                            '${user['name'] ?? 'П'}'
                                .substring(0, 1)
                                .toUpperCase(),
                            style: const TextStyle(
                                fontWeight: FontWeight.w700,
                                color: Color(0xFF067A46)),
                          )
                        : null,
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${user['name']}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 12.5,
                              fontWeight: FontWeight.w700,
                              color: Color(0xFF111827)),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          [
                            _roleLabel('${user['role'] ?? ''}'),
                            if (contextLine.isNotEmpty) contextLine
                          ].join(' · '),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 10.3,
                              fontWeight: FontWeight.w500,
                              color: Color(0xFF667085)),
                        ),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      color: Color(0xFF98A2B3), size: 20),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _emptyState(IconData icon, String title, String subtitle) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 410),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 66,
              height: 66,
              decoration: BoxDecoration(
                color: const Color(0xFFF1FBF6),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Icon(icon, color: const Color(0xFF067A46), size: 29),
            ),
            const SizedBox(height: 14),
            Text(title,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF111827))),
            const SizedBox(height: 6),
            Text(subtitle,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontSize: 11.3,
                    height: 1.4,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF667085))),
          ],
        ),
      ),
    );
  }
}

class _ProfileComingSoonPanel extends StatelessWidget {
  const _ProfileComingSoonPanel({
    required this.title,
    required this.description,
    required this.icon,
    required this.features,
  });

  final String title;
  final String description;
  final IconData icon;
  final List<String> features;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.all(18),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 560),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 58,
                  height: 58,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF1FBF6),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Icon(icon, color: const Color(0xFF067A46), size: 27),
                ),
              ),
              const SizedBox(height: 16),
              const Text(
                'РАЗДЕЛ ДОПОЛНЯЕТСЯ',
                style: TextStyle(
                    fontSize: 9.5,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .65,
                    color: Color(0xFF00A750)),
              ),
              const SizedBox(height: 7),
              Text(title,
                  style: const TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF111827))),
              const SizedBox(height: 8),
              Text(description,
                  style: const TextStyle(
                      fontSize: 12,
                      height: 1.48,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF667085))),
              const SizedBox(height: 18),
              ...features.map(
                (feature) => Padding(
                  padding: const EdgeInsets.only(bottom: 9),
                  child: Row(
                    children: [
                      Container(
                        width: 22,
                        height: 22,
                        decoration: const BoxDecoration(
                            color: Color(0xFFF3FAF6), shape: BoxShape.circle),
                        child: const Icon(Icons.check_rounded,
                            size: 13, color: Color(0xFF067A46)),
                      ),
                      const SizedBox(width: 9),
                      Expanded(
                          child: Text(feature,
                              style: const TextStyle(
                                  fontSize: 11.3,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF344054)))),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProfileFlagshipAction {
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback onTap;
  final String group;
  final bool pro;
  final bool primary;
  final bool danger;

  const _ProfileFlagshipAction(
    this.title,
    this.subtitle,
    this.icon,
    this.onTap, {
    required this.group,
    this.pro = false,
    this.primary = false,
    this.danger = false,
  });
}

class _ProfileShortcut {
  final String title;
  final IconData icon;
  final VoidCallback onTap;

  const _ProfileShortcut(this.title, this.icon, this.onTap);
}

class _FlagshipNotificationPainter extends CustomPainter {
  final Color color;

  const _FlagshipNotificationPainter({
    required this.color,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.7
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    final centerX = size.width / 2;

    final bell = Path()
      ..moveTo(size.width * .24, size.height * .66)
      ..quadraticBezierTo(
        size.width * .31,
        size.height * .57,
        size.width * .31,
        size.height * .42,
      )
      ..quadraticBezierTo(
        size.width * .31,
        size.height * .19,
        centerX,
        size.height * .18,
      )
      ..quadraticBezierTo(
        size.width * .69,
        size.height * .19,
        size.width * .69,
        size.height * .42,
      )
      ..quadraticBezierTo(
        size.width * .69,
        size.height * .57,
        size.width * .76,
        size.height * .66,
      )
      ..lineTo(size.width * .24, size.height * .66);

    canvas.drawPath(bell, stroke);

    canvas.drawLine(
      Offset(size.width * .19, size.height * .73),
      Offset(size.width * .81, size.height * .73),
      stroke,
    );

    canvas.drawArc(
      Rect.fromCenter(
        center: Offset(centerX, size.height * .77),
        width: size.width * .24,
        height: size.height * .20,
      ),
      0,
      3.14159,
      false,
      stroke,
    );

    // Небольшая фирменная нижняя точка вместо стандартного bell-clapper.
    canvas.drawCircle(
      Offset(centerX, size.height * .90),
      size.width * .055,
      Paint()..color = const Color(0xFF00A750),
    );
  }

  @override
  bool shouldRepaint(covariant _FlagshipNotificationPainter oldDelegate) {
    return oldDelegate.color != color;
  }
}

class _UserShort {
  final int? id;
  final String fullName;
  final String? username;
  final String? role;
  final String? photoUrl;
  final String? teamName;
  final String? clubName;

  _UserShort({
    this.id,
    required this.fullName,
    this.username,
    this.role,
    this.photoUrl,
    this.teamName,
    this.clubName,
  });

  String get initials {
    final parts = fullName
        .trim()
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList();

    if (parts.isEmpty) return 'S';
    if (parts.length == 1) {
      return parts.first.characters.first.toUpperCase();
    }

    return '${parts.first.characters.first}${parts.last.characters.first}'
        .toUpperCase();
  }

  factory _UserShort.fromJson(dynamic json) {
    final m = (json as Map).cast<String, dynamic>();

    final first = (m['first_name'] ?? m['firstName'] ?? '').toString().trim();
    final last = (m['last_name'] ?? m['lastName'] ?? '').toString().trim();

    String? normalize(dynamic raw) {
      if (raw == null) return null;
      final s = raw.toString().trim();
      if (s.isEmpty || s.toLowerCase() == 'null') return null;
      if (s.startsWith('http://') || s.startsWith('https://')) {
        return s;
      }
      return 'https://sportotekaapp.ru/uploads/$s';
    }

    String? optional(dynamic raw) {
      final value = (raw ?? '').toString().trim();
      if (value.isEmpty || value.toLowerCase() == 'null') {
        return null;
      }
      return value;
    }

    final photo = normalize(m['photo_url']) ??
        normalize(m['photo_urls']) ??
        normalize(m['photo']);

    final name = '$first $last'.trim();

    return _UserShort(
      id: (m['id'] is int)
          ? m['id'] as int
          : int.tryParse(
              (m['id'] ?? m['user_id'] ?? '').toString(),
            ),
      fullName:
          name.isEmpty ? optional(m['full_name']) ?? 'Пользователь' : name,
      username: optional(
        m['username'] ?? m['user_name'] ?? m['nickname'] ?? m['login'],
      ),
      role: optional(m['role']),
      photoUrl: photo,
      teamName: optional(
        m['team_name'] ?? m['player_team_name'] ?? m['team'],
      ),
      clubName: optional(
        m['club_name'] ?? m['player_club_name'] ?? m['club'],
      ),
    );
  }
}

class _AiBullet {
  final IconData icon;
  final String title;
  final String text;
  const _AiBullet(
      {required this.icon, required this.title, required this.text});
}

class _AiBulletTile extends StatelessWidget {
  final _AiBullet bullet;
  const _AiBulletTile({required this.bullet});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: ProfilePalette.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.black.withOpacity(0.06)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: ProfilePalette.primaryGreen.withOpacity(0.10),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: ProfilePalette.primaryGreen.withOpacity(0.22)),
            ),
            child: Icon(bullet.icon, color: ProfilePalette.primaryGreen),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(bullet.title,
                    style: const TextStyle(
                        fontSize: 14.5,
                        fontWeight: FontWeight.w900,
                        color: Colors.black)),
                const SizedBox(height: 4),
                Text(bullet.text,
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: Colors.black.withOpacity(0.62),
                        height: 1.15)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AiMatchIqCard extends StatelessWidget {
  final int seed;
  final String playerName;
  final String position;
  final ProfileDesign design;

  const _AiMatchIqCard(
      {required this.seed,
      required this.playerName,
      required this.position,
      required this.design});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        border: Border.all(color: design.primaryColor.withOpacity(0.1)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                    color: design.primaryColor.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(12)),
                child: Icon(Icons.psychology_alt_rounded,
                    color: design.primaryColor),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text("Match IQ • Совет на сегодня",
                        style: TextStyle(
                            fontSize: design.bodyFontSize,
                            fontWeight: FontWeight.w900,
                            color: design.textPrimaryColor)),
                    const SizedBox(height: 2),
                    Text("Персонально для позиции: $position",
                        style: TextStyle(
                            fontSize: design.smallFontSize,
                            color: design.textSecondaryColor)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text("Играй в 2 касания и чаще открывайся в полуфланг.",
              style: TextStyle(
                  fontSize: design.bodyFontSize,
                  color: design.textPrimaryColor)),
        ],
      ),
    );
  }
}

class _AiTrainingScanCard extends StatefulWidget {
  final int seed;
  final ProfileDesign design;

  const _AiTrainingScanCard({required this.seed, required this.design});

  @override
  State<_AiTrainingScanCard> createState() => _AiTrainingScanCardState();
}

class _AiTrainingScanCardState extends State<_AiTrainingScanCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _progress;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1900));
    _progress =
        CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic);
    _controller.forward(from: 0);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _progress,
      builder: (context, _) {
        final p = _progress.value;

        return Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: widget.design.cardColor,
            borderRadius: BorderRadius.circular(widget.design.cardRadius),
            border:
                Border.all(color: widget.design.primaryColor.withOpacity(0.1)),
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                        color: widget.design.primaryColor.withOpacity(0.10),
                        borderRadius: BorderRadius.circular(12)),
                    child: Icon(Icons.auto_awesome_rounded,
                        color: widget.design.primaryColor),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("AI-анализ тренировки",
                            style: TextStyle(
                                fontSize: widget.design.bodyFontSize,
                                fontWeight: FontWeight.w900,
                                color: widget.design.textPrimaryColor)),
                        const SizedBox(height: 2),
                        Text(
                          p < 0.999
                              ? "Сканируем упражнения… ${(p * 100).clamp(0, 100).toInt()}%"
                              : "Готово • Отчёт сформирован",
                          style: TextStyle(
                              fontSize: widget.design.smallFontSize,
                              color: widget.design.textSecondaryColor),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: LinearProgressIndicator(
                  value: p.clamp(0, 1),
                  minHeight: 8,
                  backgroundColor: widget.design.surfaceColor,
                  valueColor:
                      AlwaysStoppedAnimation(widget.design.primaryColor),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AiWeeklyChallengeCard extends StatelessWidget {
  final int seed;
  final ProfileDesign design;

  const _AiWeeklyChallengeCard({required this.seed, required this.design});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        border: Border.all(color: design.accentColor.withOpacity(0.1)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
                color: design.accentColor.withOpacity(0.10),
                borderRadius: BorderRadius.circular(12)),
            child: Icon(Icons.emoji_events_rounded, color: design.accentColor),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Челлендж недели",
                    style: TextStyle(
                        fontSize: design.bodyFontSize,
                        fontWeight: FontWeight.w900,
                        color: design.textPrimaryColor)),
                const SizedBox(height: 4),
                Text("20 точных передач",
                    style: TextStyle(
                        fontSize: design.smallFontSize,
                        color: design.accentColor,
                        fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HoverAnimation extends StatefulWidget {
  final Widget child;

  const _HoverAnimation({required this.child});

  @override
  State<_HoverAnimation> createState() => _HoverAnimationState();
}

class _HoverAnimationState extends State<_HoverAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  bool _isHovered = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 200));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MouseRegion(
      onEnter: (_) {
        setState(() => _isHovered = true);
        _controller.forward();
      },
      onExit: (_) {
        setState(() => _isHovered = false);
        _controller.reverse();
      },
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
              scale: 1.0 + (_controller.value * 0.05), child: child);
        },
        child: widget.child,
      ),
    );
  }
}

class _DesignEditorModal extends StatefulWidget {
  final ProfileDesign initialDesign;
  final Function(ProfileDesign) onSave;

  const _DesignEditorModal({required this.initialDesign, required this.onSave});

  @override
  State<_DesignEditorModal> createState() => _DesignEditorModalState();
}

class _DesignEditorModalState extends State<_DesignEditorModal> {
  late ProfileDesign design;
  int _selectedTab = 0;

  final List<Color> colorPresets = [
    // Яркие спортивные
    const Color(0xFF00A750),
    const Color(0xFF008C40),
    const Color(0xFF2563EB),
    const Color(0xFF1D4ED8),
    const Color(0xFF7C3AED),
    const Color(0xFF9333EA),
    const Color(0xFFDC2626),
    const Color(0xFFEF4444),
    const Color(0xFFF59E0B),
    const Color(0xFFEAB308),

    // Мягкие пастельные
    const Color(0xFFB8E1DD),
    const Color(0xFFC7D2FE),
    const Color(0xFFD8B4FE),
    const Color(0xFFFBCFE8),
    const Color(0xFFFDE68A),
    const Color(0xFFBFDBFE),
    const Color(0xFFA7F3D0),
    const Color(0xFFF5D0FE),
    const Color(0xFFFFE4E6),
    const Color(0xFFE2E8F0),

    // Премиум тёмные
    const Color(0xFF0F172A),
    const Color(0xFF1E293B),
    const Color(0xFF334155),
    const Color(0xFF475569),
    const Color(0xFF64748B),
    const Color(0xFF94A3B8),

    // Светлые фоны
    const Color(0xFFF8F9FA),
    const Color(0xFFF1F5F9),
    const Color(0xFFFAFAF9),
    const Color(0xFFFDF2F8),
    const Color(0xFFECFDF5),
    const Color(0xFFEFF6FF),
    const Color(0xFFFFFFFF),
  ];
  final List<String> fontFamilies = [
    'default',
    'inter',
    'montserrat',
    'roboto',
    'poppins'
  ];

  @override
  void initState() {
    super.initState();
    design = widget.initialDesign;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.9,
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                    child: Text('Настройка профиля',
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w900,
                            color: design.textPrimaryColor))),
                IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context)),
              ],
            ),
          ),
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildTab('Цвета', 0),
                _buildTab('Текст', 1),
                _buildTab('Размеры', 2),
                _buildTab('Тени', 3),
                _buildTab('Блоки', 4),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: design.backgroundColor,
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.grey.shade200),
            ),
            child: _buildLivePreview(),
          ),
          const Divider(height: 1),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_selectedTab == 0) _buildColorsTab(),
                if (_selectedTab == 1) _buildTextTab(),
                if (_selectedTab == 2) _buildSizesTab(),
                if (_selectedTab == 3) _buildShadowsTab(),
                if (_selectedTab == 4) _buildBlocksTab(),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                border: Border(top: BorderSide(color: Colors.grey.shade200))),
            child: Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () =>
                        setState(() => design = ProfileDesign.defaults()),
                    style: OutlinedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Сбросить'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      widget.onSave(design);
                      Navigator.pop(context);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: design.primaryColor,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Сохранить',
                        style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLivePreview() {
    return Container(
      padding: EdgeInsets.all(design.contentPadding),
      decoration: BoxDecoration(
        color: design.cardColor,
        borderRadius: BorderRadius.circular(design.cardRadius),
        boxShadow: design.cardShadowEnabled
            ? [
                BoxShadow(
                  color: Color(design.cardShadowColorValue)
                      .withOpacity(design.cardShadowOpacity),
                  blurRadius: design.cardShadowBlurRadius,
                  spreadRadius: design.cardShadowSpreadRadius,
                  offset: Offset(
                    design.cardShadowOffsetX,
                    design.cardShadowOffsetY,
                  ),
                ),
              ]
            : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: design.avatarSize * 0.55,
                height: design.avatarSize * 0.55,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: design.surfaceColor,
                  border: Border.all(
                    color: Color(design.avatarBorderColorValue),
                    width: design.avatarBorderWidth,
                  ),
                  boxShadow: design.avatarShadowEnabled
                      ? [
                          BoxShadow(
                            color: Color(design.avatarShadowColorValue)
                                .withOpacity(design.avatarShadowOpacity),
                            blurRadius: design.avatarShadowBlurRadius,
                            spreadRadius: design.avatarShadowSpreadRadius,
                            offset: Offset(
                              design.avatarShadowOffsetX,
                              design.avatarShadowOffsetY,
                            ),
                          ),
                        ]
                      : null,
                ),
                child: Icon(
                  Icons.person,
                  color: design.primaryColor,
                  size: design.avatarSize * 0.25,
                ),
              ),
              SizedBox(width: design.spacing),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Спортотека',
                      style: TextStyle(
                        fontSize: design.titleFontSize,
                        fontWeight: design.titleWeight,
                        color: design.textPrimaryColor,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Игрок • Центральный полузащитник',
                      style: TextStyle(
                        fontSize: design.smallFontSize,
                        fontWeight: design.bodyWeight,
                        color: design.textSecondaryColor,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: design.spacing),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _previewStat('24', 'Посты'),
              _previewStat('8', 'Reels'),
              _previewStat('153', 'Подписчики'),
            ],
          ),
          SizedBox(height: design.spacing),
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(design.contentPadding),
            decoration: BoxDecoration(
              color: design.surfaceColor,
              borderRadius: BorderRadius.circular(design.cardRadius),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'О себе',
                  style: TextStyle(
                    fontSize: design.headingFontSize,
                    fontWeight: design.headingWeight,
                    color: design.textPrimaryColor,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Футболист, тренируюсь каждый день и развиваю свой профиль в Спортотеке.',
                  style: TextStyle(
                    fontSize: design.bodyFontSize,
                    fontWeight: design.bodyWeight,
                    color: design.textSecondaryColor,
                    height: 1.35,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _previewStat(String value, String label) {
    if (design.statsCompactMode) {
      return Column(
        children: [
          Text(
            value,
            style: TextStyle(
              fontSize: design.headingFontSize,
              fontWeight: design.headingWeight,
              color: design.primaryColor,
            ),
          ),
        ],
      );
    }

    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            fontSize: design.headingFontSize,
            fontWeight: design.headingWeight,
            color: design.primaryColor,
          ),
        ),
        const SizedBox(height: 4),
        if (design.statsShowLabels)
          Text(
            label,
            style: TextStyle(
              fontSize: design.smallFontSize,
              color: design.textSecondaryColor,
            ),
          ),
      ],
    );
  }

  Widget _buildTab(String label, int index) {
    final active = _selectedTab == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedTab = index),
      child: Container(
        margin: const EdgeInsets.only(right: 8),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: active
              ? design.primaryColor.withOpacity(0.1)
              : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
              color: active ? design.primaryColor : Colors.grey.shade300),
        ),
        child: Text(label,
            style: TextStyle(
                color: active ? design.primaryColor : design.textSecondaryColor,
                fontWeight: active ? FontWeight.w700 : FontWeight.normal)),
      ),
    );
  }

  Widget _buildColorsTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildColorSection(
            'Основной цвет',
            design.primaryColorValue,
            (c) => setState(
                () => design = design.copyWith(primaryColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Второй цвет',
            design.secondaryColorValue,
            (c) => setState(
                () => design = design.copyWith(secondaryColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Акцентный цвет',
            design.accentColorValue,
            (c) => setState(
                () => design = design.copyWith(accentColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Фон',
            design.backgroundColorValue,
            (c) => setState(
                () => design = design.copyWith(backgroundColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Карточки',
            design.cardColorValue,
            (c) => setState(
                () => design = design.copyWith(cardColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Текст основной',
            design.textPrimaryColorValue,
            (c) => setState(() =>
                design = design.copyWith(textPrimaryColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Текст второстепенный',
            design.textSecondaryColorValue,
            (c) => setState(() =>
                design = design.copyWith(textSecondaryColorValue: c.value))),
        const SizedBox(height: 16),
        _buildColorSection(
            'Граница аватара',
            design.avatarBorderColorValue,
            (c) => setState(() =>
                design = design.copyWith(avatarBorderColorValue: c.value))),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('Градиент в шапке'),
          value: design.headerGradientEnabled,
          onChanged: (v) => setState(
              () => design = design.copyWith(headerGradientEnabled: v)),
        ),
        if (design.headerGradientEnabled) ...[
          const SizedBox(height: 8),
          const Text('Цвета градиента:'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            children: List.generate(design.headerGradientColors.length, (i) {
              return Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Color(design.headerGradientColors[i]),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey.shade300),
                ),
              );
            }),
          ),
        ],
      ],
    );
  }

  Widget _buildColorSection(
      String label, int value, Function(Color) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: colorPresets.map((preset) {
            final active = preset.value == value;
            return GestureDetector(
              onTap: () => onChanged(preset),
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: preset,
                  shape: BoxShape.circle,
                  border: Border.all(
                      color: active ? Colors.black : Colors.transparent,
                      width: 2),
                ),
                child: active
                    ? const Icon(Icons.check, color: Colors.white, size: 20)
                    : null,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildTextTab() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<String>(
          value: design.fontFamily,
          decoration: const InputDecoration(
            labelText: 'Шрифт',
            border: OutlineInputBorder(),
          ),
          items: fontFamilies
              .map((f) => DropdownMenuItem(value: f, child: Text(f)))
              .toList(),
          onChanged: (v) {
            if (v == null) return;
            setState(() {
              design = design.copyWith(fontFamily: v);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Заголовок',
          value: design.titleFontSize,
          min: 16,
          max: 32,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(titleFontSize: v);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Подзаголовок',
          value: design.headingFontSize,
          min: 14,
          max: 24,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(headingFontSize: v);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Основной текст',
          value: design.bodyFontSize,
          min: 12,
          max: 18,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(bodyFontSize: v);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Мелкий текст',
          value: design.smallFontSize,
          min: 10,
          max: 14,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(smallFontSize: v);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildWeightSelector(
          label: 'Жирность заголовка',
          value: design.titleWeight,
          onChanged: (w) {
            setState(() {
              design = design.copyWith(titleWeight: w);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildWeightSelector(
          label: 'Жирность подзаголовка',
          value: design.headingWeight,
          onChanged: (w) {
            setState(() {
              design = design.copyWith(headingWeight: w);
            });
          },
        ),
        const SizedBox(height: 16),
        _buildWeightSelector(
          label: 'Жирность текста',
          value: design.bodyWeight,
          onChanged: (w) {
            setState(() {
              design = design.copyWith(bodyWeight: w);
            });
          },
        ),
      ],
    );
  }

  Widget _buildSizesTab() {
    return Column(
      children: [
        _buildSliderTile(
          label: 'Размер аватара',
          value: design.avatarSize,
          min: 60,
          max: 120,
          onChanged: (v) => setState(() {
            design = design.copyWith(avatarSize: v);
          }),
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Толщина рамки аватара',
          value: design.avatarBorderWidth,
          min: 1,
          max: 5,
          onChanged: (v) => setState(() {
            design = design.copyWith(avatarBorderWidth: v);
          }),
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Скругление карточек',
          value: design.cardRadius,
          min: 8,
          max: 32,
          onChanged: (v) => setState(() {
            design = design.copyWith(cardRadius: v);
          }),
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Скругление кнопок',
          value: design.buttonRadius,
          min: 4,
          max: 24,
          onChanged: (v) => setState(() {
            design = design.copyWith(buttonRadius: v);
          }),
        ),
        const SizedBox(height: 16),
        _buildSliderTile(
          label: 'Отступы',
          value: design.spacing,
          min: 8,
          max: 24,
          onChanged: (v) => setState(() {
            design = design.copyWith(spacing: v);
          }),
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('Компактная статистика'),
          value: design.statsCompactMode,
          onChanged: (v) => setState(() {
            design = design.copyWith(statsCompactMode: v);
          }),
        ),
        SwitchListTile(
          title: const Text('Показывать подписи в статистике'),
          value: design.statsShowLabels,
          onChanged: (v) => setState(() {
            design = design.copyWith(statsShowLabels: v);
          }),
        ),
        SwitchListTile(
          title: const Text('Показывать иконки в статистике'),
          value: design.statsShowIcons,
          onChanged: (v) => setState(() {
            design = design.copyWith(statsShowIcons: v);
          }),
        ),
      ],
    );
  }

  Widget _buildShadowsTab() {
    return Column(
      children: [
        SwitchListTile(
          title: const Text('Тень карточек'),
          value: design.cardShadowEnabled,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(cardShadowEnabled: v);
            });
          },
        ),
        if (design.cardShadowEnabled) ...[
          const SizedBox(height: 16),
          _buildSliderTile(
            label: 'Размытие',
            value: design.cardShadowBlurRadius,
            min: 0,
            max: 20,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(cardShadowBlurRadius: v);
              });
            },
          ),
          _buildSliderTile(
            label: 'Смещение по X',
            value: design.cardShadowOffsetX,
            min: -10,
            max: 10,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(cardShadowOffsetX: v);
              });
            },
          ),
          _buildSliderTile(
            label: 'Смещение по Y',
            value: design.cardShadowOffsetY,
            min: -10,
            max: 10,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(cardShadowOffsetY: v);
              });
            },
          ),
          _buildSliderTile(
            label: 'Прозрачность',
            value: design.cardShadowOpacity,
            min: 0,
            max: 1,
            divisions: 20,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(cardShadowOpacity: v);
              });
            },
          ),
        ],
        const Divider(height: 32),
        SwitchListTile(
          title: const Text('Тень аватара'),
          value: design.avatarShadowEnabled,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(avatarShadowEnabled: v);
            });
          },
        ),
        if (design.avatarShadowEnabled) ...[
          const SizedBox(height: 16),
          _buildSliderTile(
            label: 'Размытие',
            value: design.avatarShadowBlurRadius,
            min: 0,
            max: 20,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(avatarShadowBlurRadius: v);
              });
            },
          ),
          _buildSliderTile(
            label: 'Прозрачность',
            value: design.avatarShadowOpacity,
            min: 0,
            max: 1,
            divisions: 20,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(avatarShadowOpacity: v);
              });
            },
          ),
        ],
        const Divider(height: 32),
        SwitchListTile(
          title: const Text('Свечение аватара'),
          value: design.avatarGlowEnabled,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(avatarGlowEnabled: v);
            });
          },
        ),
        if (design.avatarGlowEnabled) ...[
          const SizedBox(height: 16),
          _buildSliderTile(
            label: 'Радиус свечения',
            value: design.avatarGlowRadius,
            min: 0,
            max: 40,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(avatarGlowRadius: v);
              });
            },
          ),
          _buildSliderTile(
            label: 'Интенсивность',
            value: design.avatarGlowOpacity,
            min: 0,
            max: 1,
            divisions: 20,
            onChanged: (v) {
              setState(() {
                design = design.copyWith(avatarGlowOpacity: v);
              });
            },
          ),
        ],
      ],
    );
  }

  Widget _buildBlocksTab() {
    return Column(
      children: [
        ...design.blocks.map((block) {
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: design.surfaceColor,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(Icons.drag_handle_rounded,
                    color: design.textTertiaryColor),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    block.title,
                    style: TextStyle(
                      fontWeight:
                          block.enabled ? FontWeight.w700 : FontWeight.normal,
                      color: block.enabled
                          ? design.textPrimaryColor
                          : design.textTertiaryColor,
                    ),
                  ),
                ),
                Switch(
                  value: block.enabled,
                  onChanged: (v) {
                    setState(() {
                      final newBlocks = design.blocks.map((b) {
                        if (b.id == block.id) {
                          return b.copyWith(enabled: v);
                        }
                        return b;
                      }).toList();

                      design = design.copyWith(blocks: newBlocks);
                    });
                  },
                ),
              ],
            ),
          );
        }).toList(),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('Показывать шапку'),
          value: design.sectionVisibility['header'] ?? true,
          onChanged: (v) {
            setState(() {
              final newVisibility =
                  Map<String, bool>.from(design.sectionVisibility);
              newVisibility['header'] = v;
              design = design.copyWith(sectionVisibility: newVisibility);
            });
          },
        ),
        SwitchListTile(
          title: const Text('Показывать статистику'),
          value: design.sectionVisibility['stats'] ?? true,
          onChanged: (v) {
            setState(() {
              final newVisibility =
                  Map<String, bool>.from(design.sectionVisibility);
              newVisibility['stats'] = v;
              design = design.copyWith(sectionVisibility: newVisibility);
            });
          },
        ),
        SwitchListTile(
          title: const Text('Показывать кнопки действий'),
          value: design.sectionVisibility['actions'] ?? true,
          onChanged: (v) {
            setState(() {
              final newVisibility =
                  Map<String, bool>.from(design.sectionVisibility);
              newVisibility['actions'] = v;
              design = design.copyWith(sectionVisibility: newVisibility);
            });
          },
        ),
        SwitchListTile(
          title: const Text('Показывать переключатель'),
          value: design.sectionVisibility['switcher'] ?? true,
          onChanged: (v) {
            setState(() {
              final newVisibility =
                  Map<String, bool>.from(design.sectionVisibility);
              newVisibility['switcher'] = v;
              design = design.copyWith(sectionVisibility: newVisibility);
            });
          },
        ),
        const SizedBox(height: 16),
        SwitchListTile(
          title: const Text('Эффекты при наведении'),
          value: design.enableHoverEffects,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(enableHoverEffects: v);
            });
          },
        ),
        SwitchListTile(
          title: const Text('Пульсирующие эффекты'),
          value: design.enablePulseEffects,
          onChanged: (v) {
            setState(() {
              design = design.copyWith(enablePulseEffects: v);
            });
          },
        ),
      ],
    );
  }

  Widget _buildSliderTile(
      {required String label,
      required double value,
      required double min,
      required double max,
      int? divisions,
      required ValueChanged<double> onChanged}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: ${value.toStringAsFixed(1)}'),
        Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            activeColor: design.primaryColor,
            onChanged: onChanged),
      ],
    );
  }

  Widget _buildWeightSelector(
      {required String label,
      required FontWeight value,
      required ValueChanged<FontWeight> onChanged}) {
    final weights = [
      FontWeight.w400,
      FontWeight.w500,
      FontWeight.w600,
      FontWeight.w700,
      FontWeight.w800,
      FontWeight.w900
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label),
        const SizedBox(height: 8),
        Wrap(
          spacing: 8,
          children: weights.map((w) {
            final active = w == value;
            return FilterChip(
              label: Text(w.value.toString()),
              selected: active,
              onSelected: (_) => onChanged(w),
              selectedColor: design.primaryColor.withOpacity(0.2),
            );
          }).toList(),
        ),
      ],
    );
  }
}
