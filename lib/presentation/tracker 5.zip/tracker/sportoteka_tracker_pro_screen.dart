import 'package:flutter/material.dart';

import 'screens/tracker_match_workspace_screen.dart';

class SportotekaTrackerProScreen extends StatelessWidget {
  const SportotekaTrackerProScreen({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teamId,
    required this.teamName,
    required this.userId,
    this.initialPlayers = const [],
  });

  final int clubId;
  final String clubName;
  final int teamId;
  final String teamName;
  final int userId;
  final List<Map<String, dynamic>> initialPlayers;

  @override
  Widget build(BuildContext context) {
    return TrackerMatchWorkspaceScreen(
      clubId: clubId,
      clubName: clubName,
      teamId: teamId,
      teamName: teamName,
      userId: userId,
      initialPlayers: initialPlayers,
    );
  }
}
