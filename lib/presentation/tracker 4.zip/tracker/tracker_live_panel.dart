
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'models/action_tracker_protocol.dart';
import 'models/tracker_live_models.dart';
import 'models/tracker_pro_models.dart';
import 'services/action_tracker_ble_service.dart';
import 'services/tracker_live_api.dart';

enum TrackerLiveSourceMode {
  trackerExperimental,
  phoneGps,
}

class TrackerLivePanel extends StatefulWidget {
  const TrackerLivePanel({
    super.key,
    required this.clubId,
    required this.teamId,
    required this.teamName,
    required this.players,
    required this.selectedPlayer,
    required this.selectedField,
    required this.ble,
    this.savedDevices = const [],
    this.batteryPercent,
    this.onManageTrackers,
  });

  final int clubId;
  final int teamId;
  final String teamName;
  final List<TrackerPlayerOption> players;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final ActionTrackerBleService ble;
  final List<TrackerDeviceModel> savedDevices;
  final int? batteryPercent;
  final VoidCallback? onManageTrackers;

  @override
  State<TrackerLivePanel> createState() => _TrackerLivePanelState();
}

class _TrackerLivePanelState extends State<TrackerLivePanel>
    with AutomaticKeepAliveClientMixin {
  final TrackerLiveApi _api = TrackerLiveApi();

  final List<String> _logs = <String>[];
  final Map<String, _RuntimeTrack> _tracks = <String, _RuntimeTrack>{};
  List<TrackerLiveSessionModel> _sessions = <TrackerLiveSessionModel>[];

  Timer? _pollTimer;
  Timer? _phoneTimer;
  Timer? _trackerTimer;
  Timer? _heartbeatTimer;
  StreamSubscription<ActionTrackerParseResult>? _bleSub;

  int? _myLiveSessionId;
  TrackerLiveSourceMode _mode = TrackerLiveSourceMode.trackerExperimental;
  int _candidateCommandIndex = 0;

  bool _starting = false;
  bool _savingPoint = false;
  bool _running = false;
  bool _testingCommands = false;
  bool _showDebug = true;

  bool _showVectors = true;
  bool _showHeatmap = true;
  bool _showTrace = true;
  bool _showLabels = true;
  bool _savingAnalysis = false;
  String? _expandedPanel;
  DateTime? _lastAnalysisSavedAt;

  String _lastRx = 'нет пакетов';
  String _lastTx = 'нет команд';
  String _lastGps = 'нет GPS';
  String _lastSave = 'нет сохранения';
  String _lastProblem = 'Ожидание старта Live';
  DateTime? _lastGpsAt;
  DateTime? _lastSaveAt;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _listenBle();
    _startPolling();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _phoneTimer?.cancel();
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();
    _bleSub?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant TrackerLivePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedField?.id != widget.selectedField?.id) {
      _loadLiveState();
      _log('Изменено поле: ${widget.selectedField?.title ?? 'нет поля'}');
    }
  }

  void _listenBle() {
    _bleSub = widget.ble.dataStream.listen((event) async {
      final typeHex = '0x${event.packetType.toRadixString(16).toUpperCase()}';
      _lastRx = '${event.rawHex} · $typeHex';

      if (_mode == TrackerLiveSourceMode.trackerExperimental) {
        _log('RX $_lastRx');
      }

      if (!_running || _mode != TrackerLiveSourceMode.trackerExperimental) {
        if (mounted) setState(() {});
        return;
      }

      if (event.battery != null) {
        _log(
          'Батарея/GPS: ${event.battery!.voltage.toStringAsFixed(2)} В · '
          'GPS ${event.battery!.gpsReady ? 'готов' : 'не готов'} · это не координата',
        );
      }

      final chunk = event.gpsChunk;
      if (chunk == null || chunk.points.isEmpty) {
        final zeroGps = event.rawHex.contains('3B 00 00 00 00 00 00 00 00') ||
            event.rawHex.contains('44 00 00 00 00 00 00 00');
        _lastProblem = zeroGps
            ? 'Трекер отвечает нулевой GPS-точкой 0,0. Это не ошибка UI: нет актуальной координаты. Выйдите на улицу, дождитесь спутников или включите запись на трекере.'
            : 'Пакет $typeHex получен, но координат в нём нет';
        _lastGps = zeroGps ? '0.000000, 0.000000 · $typeHex · нет фиксации' : _lastGps;
        if (mounted) setState(() {});
        return;
      }

      final point = chunk.points.last;
      final nowMs = DateTime.now().millisecondsSinceEpoch;

      _lastGpsAt = DateTime.now();
      _lastGps =
          '${point.latitude.toStringAsFixed(6)}, ${point.longitude.toStringAsFixed(6)} · $typeHex';

      _log('GPS трекера: $_lastGps');

      await _handleGpsPoint(
        latitude: point.latitude,
        longitude: point.longitude,
        timeMs: nowMs,
        packetType: typeHex,
        rawHex: event.rawHex,
      );
    });
  }

  void _startPolling() {
    _log('Live открыт. Команда Live GPS: 3A → ответ 3B/44.');
    _loadLiveState();
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => _loadLiveState(),
    );
  }

  Future<void> _loadLiveState() async {
    try {
      final data = await _api.loadTeamLiveState(
        teamId: widget.teamId,
        fieldId: widget.selectedField?.id,
      );
      if (!mounted) return;
      setState(() => _sessions = data);
    } catch (e) {
      _lastProblem = 'Ошибка загрузки Live: $e';
      _log(_lastProblem);
    }
  }

  Future<void> _startLive() async {
    final field = widget.selectedField;
    if (field == null || !field.hasCalibration) {
      _toast('Сначала выберите и откалибруйте поле');
      _lastProblem = 'Нет калибровки поля';
      setState(() {});
      return;
    }

    final device = widget.ble.connectedInfo;
    if (_mode == TrackerLiveSourceMode.trackerExperimental && device == null) {
      _toast('Сначала подключите BLE-трекер во вкладке «Подключение»');
      _lastProblem = 'Трекер не подключён';
      setState(() {});
      return;
    }

    final deviceUuid = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-GPS-${widget.teamId}-${widget.selectedPlayer?.id ?? 0}'
        : device!.id;

    final deviceName = _mode == TrackerLiveSourceMode.phoneGps
        ? 'Телефон GPS'
        : device!.name;

    setState(() {
      _starting = true;
      _lastProblem = 'Старт Live...';
    });

    try {
      final id = await _api.startLiveSession(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: widget.selectedPlayer?.id,
        fieldId: field.id,
        deviceUuid: deviceUuid,
        deviceName: deviceName,
        source: _mode == TrackerLiveSourceMode.phoneGps ? 'phone' : 'tracker',
        batteryPercent: widget.batteryPercent,
      );

      if (id <= 0) throw Exception('сервер не вернул live_session_id');

      if (_mode == TrackerLiveSourceMode.phoneGps) {
        final serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) throw Exception('геолокация выключена');

        var permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) {
          permission = await Geolocator.requestPermission();
        }
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          throw Exception('нет разрешения на геолокацию');
        }
      }

      _myLiveSessionId = id;
      _running = true;
      _lastProblem = 'Live активен';

      _trackForCurrentDevice();

      if (_mode == TrackerLiveSourceMode.phoneGps) {
        _startPhoneGpsLoop();
      } else {
        _startTrackerLoop();
      }

      _log('Live стартовал: session=$id');
      _serverLog('Live стартовал: session=$id', source: 'live_start');
      await _loadLiveState();
    } catch (e) {
      _lastProblem = 'Ошибка старта Live: $e';
      _log(_lastProblem);
      _toast('Live: $e');
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  void _startPhoneGpsLoop() {
    _phoneTimer?.cancel();

    Future<void> tick() async {
      if (!_running || _savingPoint) return;

      try {
        final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.bestForNavigation,
        );

        await _handleGpsPoint(
          latitude: pos.latitude,
          longitude: pos.longitude,
          timeMs: DateTime.now().millisecondsSinceEpoch,
          packetType: 'PHONE',
          rawHex: null,
        );
      } catch (e) {
        _lastProblem = 'GPS телефона: $e';
        _log(_lastProblem);
      }
    }

    tick();
    _phoneTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void _startTrackerLoop() {
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();

    Future<void> tick() async {
      if (!_running) return;

      final command =
          ActionTrackerBleProfile.commandCurrentGpsCandidates[_candidateCommandIndex];
      final cmd = command
          .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
          .join(' ');

      try {
        _lastTx = cmd;
        _log('TX current GPS кандидат ${_candidateCommandIndex + 1}: $cmd');
        await widget.ble.sendRawCommand(command);
      } catch (e) {
        _lastProblem = 'TX GPS: $e';
        _log(_lastProblem);
      }
    }

    tick();
    _trackerTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());

    _heartbeatTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final id = _myLiveSessionId;
      if (!_running || id == null) return;
      try {
        await _api.heartbeatLiveSession(liveSessionId: id);
        await _loadLiveState();
      } catch (e) {
        _log('Heartbeat: $e');
      }
    });
  }

  Future<void> _handleGpsPoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
    String? rawHex,
  }) async {
    final track = _trackForCurrentDevice();
    final stat = track.addPoint(
      latitude: latitude,
      longitude: longitude,
      timeMs: DateTime.now().millisecondsSinceEpoch,
      packetType: packetType,
    );

    _lastGpsAt = DateTime.now();
    _lastGps =
        '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)} · $packetType';

    if (stat.distanceDeltaM <= 0.25 && track.points.length > 1) {
      _lastProblem =
          'GPS приходит, но смещение меньше 25 см. Скорость будет около 0.';
    } else if (stat.rawSpeedKmh > 55) {
      _lastProblem =
          'GPS-скачок ${stat.rawSpeedKmh.toStringAsFixed(1)} км/ч. На экране скорость ограничена.';
    } else {
      _lastProblem = 'GPS принят, скорость считается локально';
    }

    if (mounted) setState(() {});

    await _savePoint(
      latitude: latitude,
      longitude: longitude,
      timeMs: timeMs,
      packetType: packetType,
      rawHex: rawHex,
    );

    final needAutoSnapshot = _myLiveSessionId != null &&
        track.points.length >= 8 &&
        (_lastAnalysisSavedAt == null ||
            DateTime.now().difference(_lastAnalysisSavedAt!).inSeconds >= 45 ||
            track.points.length % 30 == 0);

    if (needAutoSnapshot) {
      await _saveLiveAnalysisSnapshot(manual: false);
    }
  }

  Future<void> _savePoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
    String? rawHex,
  }) async {
    final id = _myLiveSessionId;
    if (id == null || _savingPoint) return;

    final device = widget.ble.connectedInfo;
    final deviceUuid = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-GPS-${widget.teamId}-${widget.selectedPlayer?.id ?? 0}'
        : (device?.id ?? 'TRACKER');

    setState(() => _savingPoint = true);

    try {
      final result = await _api.saveLivePoint(
        TrackerLivePointPayload(
          liveSessionId: id,
          clubId: widget.clubId,
          teamId: widget.teamId,
          playerId: widget.selectedPlayer?.id,
          deviceUuid: deviceUuid,
          latitude: latitude,
          longitude: longitude,
          timeMs: timeMs,
          batteryPercent: widget.batteryPercent,
        ),
      );

      _lastSaveAt = DateTime.now();
      final speed = result['speed_kmh'] ?? 0;
      final delta = result['distance_delta_m'] ?? 0;
      final field = result['field'];
      final fieldWarning = field is Map ? field['field_warning'] : null;

      if (fieldWarning != null) {
        _lastProblem =
            'Сервер сохранил GPS, но координата поля вне диапазона. Проверьте калибровку.';
      } else {
        _lastProblem = 'Точка сохранена на сервере';
      }

      _lastSave = 'OK · $speed км/ч · +$delta м';
      _log('Точка сохранена: $_lastSave');
      await _serverLog(
        'point saved: $_lastSave · $packetType',
        source: 'save_point',
        rawHex: rawHex,
      );
      await _loadLiveState();
    } catch (e) {
      _lastSave = 'ОШИБКА: $e';
      _lastProblem = 'Сервер не сохранил точку: $e';
      _log('Сохранение точки: $e');
      await _serverLog(
        'save point error: $e',
        level: 'error',
        source: 'save_point',
        rawHex: rawHex,
      );
    } finally {
      if (mounted) setState(() => _savingPoint = false);
    }
  }


  Future<void> _saveLiveAnalysisSnapshot({required bool manual}) async {
    final track = _mainTrack;
    final liveSessionId = _myLiveSessionId;

    if (track == null || track.points.length < 2 || liveSessionId == null || _savingAnalysis) {
      if (manual && mounted) {
        _toast('Недостаточно данных для сохранения анализа');
      }
      return;
    }

    final device = widget.ble.connectedInfo;
    final now = DateTime.now();
    final payload = <String, dynamic>{
      'club_id': widget.clubId,
      'team_id': widget.teamId,
      'player_id': widget.selectedPlayer?.id,
      'live_session_id': liveSessionId,
      'device_uuid': _mode == TrackerLiveSourceMode.phoneGps
          ? 'PHONE-GPS-${widget.teamId}-${widget.selectedPlayer?.id ?? 0}'
          : (device?.id ?? track.key),
      'device_name': _mode == TrackerLiveSourceMode.phoneGps ? 'Телефон GPS' : (device?.name ?? track.deviceName),
      'snapshot_date': now.toIso8601String().substring(0, 10),
      'snapshot_time': now.toIso8601String(),
      'duration_sec': track.durationSec,
      'total_distance_m': _round1(track.totalDistanceM),
      'high_speed_distance_m': _round1(track.highSpeedDistanceM),
      'sprint_distance_m': _round1(track.sprintDistanceM),
      'sprint_count': track.sprintCount,
      'max_speed_kmh': _round1(track.maxSpeedKmh),
      'avg_speed_kmh': _round1(track.avgSpeedKmh),
      'moving_avg_speed_kmh': _round1(track.movingAvgSpeedKmh),
      'speed_drop_percent': _round1(track.speedDropPercent),
      'fatigue_score': _round1(track.fatigueScore),
      'load_score': _round1(track.proLoadScore),
      'accel_count': track.accelerationCount,
      'decel_count': track.decelerationCount,
      'status_level': track.proStatusLevel,
      'recommendation': track.coachRecommendation,
      'analysis_json': track.toAnalysisJson(),
    };

    setState(() => _savingAnalysis = true);

    try {
      await _api.saveLiveAnalysisSnapshot(payload);
      _lastAnalysisSavedAt = now;
      _log('Pro-анализ сохранён: нагрузка ${track.proLoadScore.toStringAsFixed(0)}, усталость ${track.fatigueScore.toStringAsFixed(0)}%');
      if (manual && mounted) {
        _toast('Анализ нагрузки сохранён по дате');
      }
    } catch (e) {
      _log('Ошибка сохранения Pro-анализа: $e');
      if (manual && mounted) {
        _toast('Ошибка сохранения анализа: $e');
      }
    } finally {
      if (mounted) setState(() => _savingAnalysis = false);
    }
  }

  Future<void> _stopLive() async {
    _running = false;
    _phoneTimer?.cancel();
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();

    final id = _myLiveSessionId;
    if (id != null) {
      try {
        await _saveLiveAnalysisSnapshot(manual: true);

        await _api.stopLiveSession(
          liveSessionId: id,
          createFinalSession: true,
        );
        _lastProblem = 'Live остановлен и сохранён как сессия';
        _log('Live остановлен: session=$id');
      } catch (e) {
        _lastProblem = 'Ошибка остановки Live: $e';
        _log(_lastProblem);
      }
    }

    _myLiveSessionId = null;
    await _loadLiveState();
    if (mounted) setState(() {});
  }


  Future<void> _addDebugLocalPoint() async {
    final startLat = 55.973505;
    final startLon = 37.399388;
    final track = _trackForCurrentDevice();

    final index = track.points.length;
    final lat = startLat + index * 0.000006;
    final lon = startLon + index * 0.000010;

    await _handleGpsPoint(
      latitude: lat,
      longitude: lon,
      timeMs: DateTime.now().millisecondsSinceEpoch,
      packetType: 'LOCAL-TEST',
      rawHex: null,
    );

    _lastProblem = 'Добавлена тестовая точка на устройстве. Если она двигается — UI работает, проблема в GPS/сервере.';
    if (mounted) setState(() {});
  }

  Future<void> _testGpsCommands() async {
    if (_testingCommands) return;

    final device = widget.ble.connectedInfo;
    if (device == null) {
      _toast('Сначала подключите BLE-трекер');
      return;
    }

    setState(() => _testingCommands = true);

    try {
      _log('--- Проверка команд GPS ---');
      final commands = ActionTrackerBleProfile.commandCurrentGpsCandidates;

      for (var i = 0; i < commands.length; i++) {
        if (!mounted) break;

        final cmd = commands[i]
            .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
            .join(' ');

        setState(() => _candidateCommandIndex = i);
        _log('TEST TX ${i + 1}/${commands.length}: $cmd');

        try {
          await widget.ble.sendRawCommand(commands[i]);
        } catch (e) {
          _log('TEST ERROR: $e');
        }

        await Future<void>.delayed(const Duration(milliseconds: 700));
      }

      _log('--- Проверка завершена ---');
    } finally {
      if (mounted) setState(() => _testingCommands = false);
    }
  }

  _RuntimeTrack _trackForCurrentDevice() {
    final device = widget.ble.connectedInfo;
    final key = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-${widget.selectedPlayer?.id ?? 0}'
        : (device?.id ?? 'TRACKER');

    final playerName = widget.selectedPlayer?.name ?? 'Игрок';
    final deviceName = _mode == TrackerLiveSourceMode.phoneGps
        ? 'Телефон GPS'
        : (device?.name ?? 'Трекер');

    return _tracks.putIfAbsent(
      key,
      () => _RuntimeTrack(
        key: key,
        playerName: playerName,
        deviceName: deviceName,
      ),
    );
  }

  Future<void> _serverLog(
    String message, {
    String level = 'info',
    String source = 'live',
    String? rawHex,
  }) async {
    await _api.sendDebugLog(
      teamId: widget.teamId,
      playerId: widget.selectedPlayer?.id,
      liveSessionId: _myLiveSessionId,
      level: level,
      source: source,
      message: message,
      rawHex: rawHex,
    );
  }

  void _log(String text) {
    final line = '[${DateTime.now().toIso8601String()}] $text';
    // ignore: avoid_print
    print('[TRACKER_LIVE] $line');

    if (!mounted) return;
    setState(() {
      _logs.insert(0, line);
      if (_logs.length > 220) _logs.removeLast();
    });
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  _RuntimeTrack? get _mainTrack {
    if (_tracks.isEmpty) return null;
    if (widget.ble.connectedInfo != null) {
      final key = widget.ble.connectedInfo!.id;
      if (_tracks.containsKey(key)) return _tracks[key];
    }
    return _tracks.values.first;
  }

  double get _displaySpeedKmh {
    final local = _mainTrack?.speedKmh ?? 0;
    if (local > 0) return local;

    final server = _sessions.isEmpty ? 0.0 : _sessions.first.speedKmh;
    return server;
  }

  double get _displayDistanceM {
    final local = _mainTrack?.totalDistanceM ?? 0;
    if (local > 0) return local;

    final server = _sessions.isEmpty ? 0.0 : _sessions.first.totalDistanceM;
    return server;
  }

  int get _displayPoints => _tracks.values.fold<int>(0, (s, t) => s + t.points.length);

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final active = _sessions.where((s) => s.status == 'active').toList();
    final online = active.where((s) => s.isOnline).length;

    if (_expandedPanel != null) {
      return _expandedPanelView(online, active.length);
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final threeGrid = constraints.maxWidth >= 1180;

        if (!threeGrid) {
          return ListView(
            padding: const EdgeInsets.all(8),
            children: [
              _connectionSummaryCard(),
              const SizedBox(height: 8),
              _statusHeader(online, active.length),
              const SizedBox(height: 8),
              _realisticFieldCard(height: 410),
              const SizedBox(height: 8),
              SizedBox(height: 178, child: _kpiGrid(columns: 2)),
              const SizedBox(height: 8),
              _proAnalyticsCard(height: 470),
              const SizedBox(height: 8),
              _playersCard(height: 300),
              const SizedBox(height: 8),
              _debugCard(height: 420),
            ],
          );
        }

        return Padding(
          padding: const EdgeInsets.all(8),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(width: 330, child: _leftTrackerGrid(online, active.length)),
              const SizedBox(width: 8),
              Expanded(flex: 11, child: _centerTrackerGrid()),
              const SizedBox(width: 8),
              SizedBox(width: 430, child: _rightTrackerGrid()),
            ],
          ),
        );
      },
    );
  }

  Widget _leftTrackerGrid(int online, int active) {
    return ListView(
      padding: EdgeInsets.zero,
      children: [
        _connectionSummaryCard(),
        const SizedBox(height: 8),
        _statusHeader(online, active),
        const SizedBox(height: 8),
        _playersCard(height: 286),
      ],
    );
  }

  Widget _centerTrackerGrid() {
    return Column(
      children: [
        Expanded(child: _realisticFieldCard()),
        const SizedBox(height: 8),
        SizedBox(height: 132, child: _kpiGrid(columns: 6)),
        const SizedBox(height: 8),
        _bottomProblemBar(),
      ],
    );
  }

  Widget _rightTrackerGrid() {
    return Column(
      children: [
        Expanded(flex: 5, child: _proAnalyticsCard()),
        const SizedBox(height: 8),
        Expanded(flex: 4, child: _debugCard()),
      ],
    );
  }


  Widget _connectionSummaryCard() {
    final device = widget.ble.connectedInfo;
    final trackerCount = widget.savedDevices.length;
    final fieldReady = widget.selectedField?.hasCalibration == true;

    return _LiveCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _TitleRow(
            icon: Icons.dashboard_customize_rounded,
            title: 'Функции трекера',
            subtitle: 'подключение, игрок, поле и сохранённые датчики',
          ),
          const SizedBox(height: 10),
          _TrackerSummaryLine(
            icon: Icons.bluetooth_connected_rounded,
            label: 'Подключение',
            value: device == null ? 'не подключён' : device.name,
            ok: device != null,
          ),
          _TrackerSummaryLine(
            icon: Icons.person_rounded,
            label: 'Игрок',
            value: widget.selectedPlayer?.name ?? 'не выбран',
            ok: widget.selectedPlayer != null,
          ),
          _TrackerSummaryLine(
            icon: Icons.map_rounded,
            label: 'Поле',
            value: widget.selectedField?.title ?? 'не выбрано',
            ok: fieldReady,
          ),
          _TrackerSummaryLine(
            icon: Icons.sensors_rounded,
            label: 'Датчики',
            value: '$trackerCount шт.',
            ok: trackerCount > 0,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _running || _testingCommands ? null : _testGpsCommands,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _C.green,
                    side: const BorderSide(color: _C.green),
                    minimumSize: const Size(0, 40),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  icon: _testingCommands
                      ? const SizedBox(
                          width: 14,
                          height: 14,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.bug_report_rounded, size: 18),
                  label: Text(_testingCommands ? 'Проверка...' : 'GPS тест'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _addDebugLocalPoint,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _C.orange,
                    side: const BorderSide(color: _C.orange),
                    minimumSize: const Size(0, 40),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  icon: const Icon(Icons.add_location_alt_rounded, size: 18),
                  label: const Text('Тест точки'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _bottomProblemBar() {
    final isBad = _lastProblem.toLowerCase().contains('ошибка') ||
        _lastProblem.toLowerCase().contains('нет ') ||
        _lastProblem.toLowerCase().contains('нулевой');

    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: isBad ? _C.redSoft : _C.greenSoft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: isBad ? _C.red.withOpacity(.18) : _C.green.withOpacity(.18),
        ),
      ),
      child: Row(
        children: [
          Icon(
            isBad ? Icons.warning_amber_rounded : Icons.check_circle_rounded,
            color: isBad ? _C.red : _C.green,
            size: 19,
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              _lastProblem,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isBad ? _C.red : _C.greenDark,
                fontFamily: 'Roboto',
                fontSize: 11.5,
                fontWeight: FontWeight.w900,
                height: 1.15,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _realisticFieldCard({double? height}) {
    final card = _LiveCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          Container(
            height: 46,
            padding: const EdgeInsets.symmetric(horizontal: 14),
            decoration: const BoxDecoration(
              color: Color(0xFFF8FAFC),
              borderRadius: BorderRadius.vertical(top: Radius.circular(10)),
              border: Border(bottom: BorderSide(color: _C.divider)),
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: _C.greenSoft,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: _C.green.withOpacity(.12)),
                  ),
                  child: const Icon(Icons.map_rounded, color: _C.green, size: 17),
                ),
                const SizedBox(width: 9),
                const Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Реалистичное поле',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: _C.text,
                          fontSize: 14,
                          fontWeight: FontWeight.w900,
                          height: 1.1,
                        ),
                      ),
                      Text(
                        '105×68 м · без растяжения · трек · вектор · heatmap',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontFamily: 'Roboto',
                          color: _C.subtle,
                          fontSize: 10.5,
                          fontWeight: FontWeight.w700,
                          height: 1.1,
                        ),
                      ),
                    ],
                  ),
                ),
                _TinyHud(label: 'GPS', value: _lastGpsAt == null ? 'нет' : '${DateTime.now().difference(_lastGpsAt!).inSeconds}с'),
                const SizedBox(width: 6),
                _TinyHud(label: 'SAVE', value: _lastSaveAt == null ? 'нет' : '${DateTime.now().difference(_lastSaveAt!).inSeconds}с'),
                const SizedBox(width: 6),
                _CmrAnimatedIconButton(
                  tooltip: 'Развернуть поле',
                  icon: Icons.open_in_full_rounded,
                  onTap: () => _openExpandedPanel('field'),
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: const Color(0xFF0B1110),
              child: LayoutBuilder(
                builder: (context, c) {
                  final maxW = c.maxWidth.isFinite ? c.maxWidth : MediaQuery.of(context).size.width;
                  final maxH = c.maxHeight.isFinite ? c.maxHeight : 360.0;
                  const pitchAspect = 105.0 / 68.0;
                  final w = math.min(maxW, maxH * pitchAspect);
                  final h = w / pitchAspect;

                  return Center(
                    child: SizedBox(
                      width: w,
                      height: h,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(6),
                        child: CustomPaint(
                          painter: _RuntimeFieldPainter(
                            field: widget.selectedField,
                            tracks: _tracks.values.toList(),
                            showVectors: true,
                            showHeatmap: true,
                            showTrace: true,
                            showLabels: true,
                          ),
                          child: const SizedBox.expand(),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );

    return height == null ? card : SizedBox(height: height, child: card);
  }



  Widget _expandedPanelView(int online, int active) {
    final panel = _expandedPanel ?? 'field';
    final title = switch (panel) {
      'field' => 'Поле и live-движение',
      'analytics' => 'Расширенный Pro-анализ',
      'players' => 'Игроки онлайн',
      'debug' => 'Debug устройства',
      _ => 'Tracker Workstation',
    };
    final subtitle = switch (panel) {
      'field' => 'реалистичное поле 105×68, трек, векторы и heatmap',
      'analytics' => 'нагрузка, fatigue, HSR, sprint, speed drop, IMA',
      'players' => 'онлайн-статусы, серверные сессии и локальные точки',
      'debug' => 'TX/RX/GPS/SAVE, ошибки устройства и сервера',
      _ => 'детальный экран трекера',
    };

    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _CmrPanelHeader(
            icon: Icons.open_in_full_rounded,
            title: title,
            subtitle: subtitle,
            actions: [
              _CmrAnimatedIconButton(
                tooltip: 'Свернуть',
                icon: Icons.close_fullscreen_rounded,
                onTap: () => setState(() => _expandedPanel = null),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: switch (panel) {
              'field' => _realisticFieldCard(),
              'analytics' => _proAnalyticsCard(),
              'players' => _playersCard(),
              'debug' => _debugCard(),
              _ => _realisticFieldCard(),
            },
          ),
        ],
      ),
    );
  }

  void _openExpandedPanel(String panel) {
    setState(() => _expandedPanel = panel);
  }

  Widget _statusHeader(int online, int active) {
    final device = widget.ble.connectedInfo;
    final fieldReady = widget.selectedField?.hasCalibration == true;

    return _LiveCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _TitleRow(
            icon: Icons.analytics_rounded,
            title: 'Vector Tracking Center',
            subtitle: '${widget.teamName} · скорость, векторы, тепловая карта и нагрузка',
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _StatePill(
                icon: Icons.person_rounded,
                label: widget.selectedPlayer?.name ?? 'Игрок не выбран',
                ok: widget.selectedPlayer != null,
              ),
              _StatePill(
                icon: Icons.bluetooth_connected_rounded,
                label: device == null ? 'Трекер не подключён' : '${device.name}',
                ok: device != null,
              ),
              _StatePill(
                icon: Icons.map_rounded,
                label: fieldReady ? widget.selectedField!.title : 'Поле не готово',
                ok: fieldReady,
              ),
            ],
          ),
          const SizedBox(height: 12),
          SegmentedButton<TrackerLiveSourceMode>(
            segments: const [
              ButtonSegment(
                value: TrackerLiveSourceMode.phoneGps,
                icon: Icon(Icons.phone_iphone_rounded),
                label: Text('Телефон'),
              ),
              ButtonSegment(
                value: TrackerLiveSourceMode.trackerExperimental,
                icon: Icon(Icons.sensors_rounded),
                label: Text('Трекер'),
              ),
            ],
            selected: {_mode},
            onSelectionChanged: _running
                ? null
                : (v) => setState(() => _mode = v.first),
          ),
          if (_mode == TrackerLiveSourceMode.trackerExperimental) ...[
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              value: _candidateCommandIndex,
              decoration: _input('Команда Live GPS'),
              items: List.generate(
                ActionTrackerBleProfile.commandCurrentGpsCandidates.length,
                (i) {
                  final cmd = ActionTrackerBleProfile.commandCurrentGpsCandidates[i]
                      .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
                      .join(' ');
                  return DropdownMenuItem(value: i, child: Text('Кандидат ${i + 1}: $cmd'));
                },
              ),
              onChanged: _running ? null : (v) => setState(() => _candidateCommandIndex = v ?? 0),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _starting || _running ? null : _startLive,
                  style: FilledButton.styleFrom(
                    backgroundColor: _C.green,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(0, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  icon: _starting
                      ? const SizedBox(
                          width: 17,
                          height: 17,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.play_arrow_rounded),
                  label: const Text('Старт Live'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _running ? _stopLive : null,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _C.red,
                    side: const BorderSide(color: _C.green),
                    minimumSize: const Size(0, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  icon: const Icon(Icons.stop_rounded),
                  label: const Text('Стоп'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _running || _testingCommands ? null : _testGpsCommands,
            style: OutlinedButton.styleFrom(
              foregroundColor: _C.green,
              side: const BorderSide(color: _C.green),
              minimumSize: const Size(double.infinity, 42),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            icon: _testingCommands
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bug_report_rounded),
            label: Text(_testingCommands ? 'Проверка команд...' : 'Debug: проверить команды GPS'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _addDebugLocalPoint,
            style: OutlinedButton.styleFrom(
              foregroundColor: _C.orange,
              side: const BorderSide(color: _C.orange),
              minimumSize: const Size(double.infinity, 42),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            icon: const Icon(Icons.playlist_add_rounded),
            label: const Text('Debug: добавить тестовую точку'),
          ),
          const SizedBox(height: 12),
          _ProblemBox(text: _lastProblem),
        ],
      ),
    );
  }

  Widget _fieldCard() {
    final track = _mainTrack;

    return _LiveCard(
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _RuntimeFieldPainter(
                  field: widget.selectedField,
                  tracks: _tracks.values.toList(),
                  showVectors: _showVectors,
                  showHeatmap: _showHeatmap,
                  showTrace: _showTrace,
                  showLabels: _showLabels,
                ),
              ),
            ),
            Positioned(
              left: 14,
              top: 14,
              right: 14,
              child: _FieldHud(
                title: 'Полевой радар',
                subtitle: _running
                    ? 'LIVE · ${track?.speedKmh.toStringAsFixed(1) ?? '0.0'} км/ч · ${track?.points.length ?? 0} точек'
                    : 'готов к старту · ${widget.selectedField?.title ?? 'поле не выбрано'}',
                speed: track?.speedKmh ?? _displaySpeedKmh,
                gpsAge: _lastGpsAt == null ? null : DateTime.now().difference(_lastGpsAt!).inSeconds,
              ),
            ),
            Positioned(
              left: 14,
              right: 14,
              bottom: 14,
              child: _FieldControlStrip(
                showTrace: _showTrace,
                showVectors: _showVectors,
                showHeatmap: _showHeatmap,
                showLabels: _showLabels,
                onTrace: () => setState(() => _showTrace = !_showTrace),
                onVectors: () => setState(() => _showVectors = !_showVectors),
                onHeatmap: () => setState(() => _showHeatmap = !_showHeatmap),
                onLabels: () => setState(() => _showLabels = !_showLabels),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kpiGrid({required int columns}) {
    final track = _mainTrack;
    final lastDelta = track?.lastDeltaM ?? 0;

    final vector = track?.directionLabel ?? '—';
    final items = [
      _KpiData('Скорость', '${_displaySpeedKmh.toStringAsFixed(1)} км/ч', Icons.speed_rounded),
      _KpiData('Дистанция', '${(_displayDistanceM / 1000).toStringAsFixed(2)} км', Icons.route_rounded),
      _KpiData('Нагрузка', '${track?.proLoadScore.toStringAsFixed(0) ?? '0'}', Icons.bolt_rounded),
      _KpiData('Падение', '${track?.speedDropPercent.toStringAsFixed(0) ?? '0'}%', Icons.trending_down_rounded),
      _KpiData('Вектор', vector, Icons.near_me_rounded),
      _KpiData('Смещение', '${lastDelta.toStringAsFixed(1)} м', Icons.open_with_rounded),
    ];

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: columns == 2 ? 2.6 : (columns >= 6 ? 1.55 : 1.95),
      ),
      itemBuilder: (_, i) => _KpiCard(data: items[i]),
    );
  }


  Widget _proAnalyticsCard({double? height}) {
    final track = _mainTrack;

    final content = _LiveCard(
      padding: const EdgeInsets.all(12),
      child: track == null || track.points.length < 2
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: _TitleRow(
                        icon: Icons.analytics_rounded,
                        title: 'Pro-анализ нагрузки',
                        subtitle: 'Catapult-style: fatigue, HSR, sprint, IMA',
                      ),
                    ),
                    _CmrAnimatedIconButton(
                      tooltip: 'Развернуть анализ',
                      icon: Icons.open_in_full_rounded,
                      onTap: () => _openExpandedPanel('analytics'),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: Center(
                    child: Text(
                      'Запустите Live или нажмите «Тест точки», чтобы увидеть анализ нагрузки, падение скорости и рекомендации.',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: _C.subtle,
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        height: 1.35,
                      ),
                    ),
                  ),
                ),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Expanded(
                      child: _TitleRow(
                        icon: Icons.analytics_rounded,
                        title: 'Pro-анализ нагрузки',
                        subtitle: 'скорость, HSR, спринты, усталость, рекомендации',
                      ),
                    ),
                    const SizedBox(width: 8),
                    _CmrAnimatedIconButton(
                      tooltip: 'Развернуть анализ',
                      icon: Icons.open_in_full_rounded,
                      onTap: () => _openExpandedPanel('analytics'),
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      onPressed: _savingAnalysis ? null : () => _saveLiveAnalysisSnapshot(manual: true),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: _C.green,
                        side: const BorderSide(color: _C.green),
                        minimumSize: const Size(0, 36),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                      ),
                      icon: _savingAnalysis
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.save_rounded, size: 16),
                      label: Text(_lastAnalysisSavedAt == null
                          ? 'Сохранить'
                          : 'Сохранено ${_lastAnalysisSavedAt!.hour.toString().padLeft(2, '0')}:${_lastAnalysisSavedAt!.minute.toString().padLeft(2, '0')}'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                _LoadAlert(track: track),
                const SizedBox(height: 10),
                Expanded(
                  child: Row(
                    children: [
                      Expanded(
                        flex: 5,
                        child: Column(
                          children: [
                            Expanded(
                              child: GridView.count(
                                physics: const NeverScrollableScrollPhysics(),
                                crossAxisCount: 3,
                                crossAxisSpacing: 8,
                                mainAxisSpacing: 8,
                                childAspectRatio: 1.9,
                                children: [
                                  _ProMetricTile(title: 'Load', value: track.proLoadScore.toStringAsFixed(0), subtitle: track.proStatusLabel, icon: Icons.bolt_rounded),
                                  _ProMetricTile(title: 'Fatigue', value: '${track.fatigueScore.toStringAsFixed(0)}%', subtitle: track.fatigueLabel, icon: Icons.battery_alert_rounded),
                                  _ProMetricTile(title: 'Drop', value: '${track.speedDropPercent.toStringAsFixed(0)}%', subtitle: 'падение скорости', icon: Icons.trending_down_rounded),
                                  _ProMetricTile(title: 'HSR', value: '${track.highSpeedDistanceM.toStringAsFixed(0)} м', subtitle: '> 19.8 км/ч', icon: Icons.speed_rounded),
                                  _ProMetricTile(title: 'Sprint', value: '${track.sprintDistanceM.toStringAsFixed(0)} м', subtitle: '> 25.2 км/ч', icon: Icons.flash_on_rounded),
                                  _ProMetricTile(title: 'IMA', value: '${track.accelerationCount}/${track.decelerationCount}', subtitle: 'ускор./торм.', icon: Icons.swap_vert_rounded),
                                ],
                              ),
                            ),
                            const SizedBox(height: 8),
                            _SpeedTrendMiniChart(track: track),
                          ],
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        flex: 4,
                        child: Column(
                          children: [
                            Expanded(child: _ZoneBars(track: track)),
                            const SizedBox(height: 8),
                            _CoachHintBox(track: track),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );

    return height == null ? content : SizedBox(height: height, child: content);
  }

  Widget _playersCard({double? height}) {
    final content = _LiveCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _TitleRow(
            icon: Icons.groups_rounded,
            title: 'Игроки онлайн',
            subtitle: 'Локальные данные + серверное состояние',
          ),
          const SizedBox(height: 12),
          Expanded(
            child: _tracks.isEmpty && _sessions.isEmpty
                ? const Center(
                    child: Text(
                      'Запустите Live, чтобы увидеть игрока',
                      style: TextStyle(color: _C.subtle, fontWeight: FontWeight.w700),
                    ),
                  )
                : ListView(
                    children: [
                      ..._tracks.values.map((track) => _RuntimePlayerTile(track: track)),
                      if (_sessions.isNotEmpty && _tracks.isNotEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Divider(height: 1),
                        ),
                      ..._sessions.map((s) => _ServerPlayerTile(session: s)),
                    ],
                  ),
          ),
        ],
      ),
    );

    return height == null ? content : SizedBox(height: height, child: content);
  }

  Widget _debugCard({double? height}) {
    final content = _LiveCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: _TitleRow(
                  icon: Icons.bug_report_rounded,
                  title: 'Debug на устройстве',
                  subtitle: 'Показывает, где именно ломается цепочка',
                ),
              ),
              _CmrAnimatedIconButton(
                tooltip: _showDebug ? 'Свернуть лог' : 'Развернуть лог',
                icon: _showDebug ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                onTap: () => setState(() => _showDebug = !_showDebug),
              ),
              const SizedBox(width: 6),
              _CmrAnimatedIconButton(
                tooltip: 'Открыть Debug',
                icon: Icons.open_in_full_rounded,
                onTap: () => _openExpandedPanel('debug'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _DebugLine(label: 'TX', value: _lastTx),
          _DebugLine(label: 'RX', value: _lastRx),
          _DebugLine(label: 'GPS', value: _lastGps),
          _DebugLine(label: 'SAVE', value: _lastSave),
          _DebugLine(
            label: 'GPS age',
            value: _lastGpsAt == null
                ? 'нет'
                : '${DateTime.now().difference(_lastGpsAt!).inSeconds} сек назад',
          ),
          _DebugLine(
            label: 'Save age',
            value: _lastSaveAt == null
                ? 'нет'
                : '${DateTime.now().difference(_lastSaveAt!).inSeconds} сек назад',
          ),
          const SizedBox(height: 10),
          if (_showDebug)
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF0B0F14),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: const EdgeInsets.all(10),
                child: _logs.isEmpty
                    ? const Center(
                        child: Text(
                          'Логи появятся здесь',
                          style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w700),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _logs.length,
                        itemBuilder: (_, i) => Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            _logs[i],
                            style: const TextStyle(
                              color: Color(0xFFE5E7EB),
                              fontSize: 10.8,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'monospace',
                              height: 1.25,
                            ),
                          ),
                        ),
                      ),
              ),
            ),
        ],
      ),
    );

    return height == null ? content : SizedBox(height: height, child: content);
  }
}

class _FieldHud extends StatelessWidget {
  const _FieldHud({
    required this.title,
    required this.subtitle,
    required this.speed,
    required this.gpsAge,
  });

  final String title;
  final String subtitle;
  final double speed;
  final int? gpsAge;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.34),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(.16)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.16),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.radar_rounded, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withOpacity(.72),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                speed.toStringAsFixed(1),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFeatures: [FontFeature.tabularFigures()],
                ),
              ),
              Text(
                gpsAge == null ? 'GPS —' : 'GPS ${gpsAge}s',
                style: TextStyle(
                  color: Colors.white.withOpacity(.72),
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FieldControlStrip extends StatelessWidget {
  const _FieldControlStrip({
    required this.showTrace,
    required this.showVectors,
    required this.showHeatmap,
    required this.showLabels,
    required this.onTrace,
    required this.onVectors,
    required this.onHeatmap,
    required this.onLabels,
  });

  final bool showTrace;
  final bool showVectors;
  final bool showHeatmap;
  final bool showLabels;
  final VoidCallback onTrace;
  final VoidCallback onVectors;
  final VoidCallback onHeatmap;
  final VoidCallback onLabels;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.34),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.white.withOpacity(.14)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _FieldToggleChip(label: 'Трек', icon: Icons.timeline_rounded, active: showTrace, onTap: onTrace),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Векторы', icon: Icons.near_me_rounded, active: showVectors, onTap: onVectors),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Тепло', icon: Icons.local_fire_department_rounded, active: showHeatmap, onTap: onHeatmap),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Метки', icon: Icons.label_rounded, active: showLabels, onTap: onLabels),
          ],
        ),
      ),
    );
  }
}

class _FieldToggleChip extends StatelessWidget {
  const _FieldToggleChip({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? Colors.white : Colors.white.withOpacity(.12),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: active ? _C.text : Colors.white),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  color: active ? _C.text : Colors.white,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}





class _CmrPanelHeader extends StatelessWidget {
  const _CmrPanelHeader({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.actions = const [],
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final List<Widget> actions;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
        boxShadow: const [
          BoxShadow(
            color: Color(0x050F172A),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _C.greenSoft,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: _C.green.withOpacity(.12)),
            ),
            child: Icon(icon, color: _C.green, size: 18),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto',
                    color: _C.text,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    height: 1.05,
                    letterSpacing: -0.18,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Roboto',
                    color: _C.subtle,
                    fontSize: 10.8,
                    fontWeight: FontWeight.w700,
                    height: 1.05,
                  ),
                ),
              ],
            ),
          ),
          ...actions,
        ],
      ),
    );
  }
}

class _CmrAnimatedIconButton extends StatefulWidget {
  const _CmrAnimatedIconButton({
    required this.icon,
    required this.onTap,
    this.tooltip,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final String? tooltip;

  @override
  State<_CmrAnimatedIconButton> createState() => _CmrAnimatedIconButtonState();
}

class _CmrAnimatedIconButtonState extends State<_CmrAnimatedIconButton> {
  bool _pressed = false;
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    final child = MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: Listener(
        onPointerDown: enabled ? (_) => setState(() => _pressed = true) : null,
        onPointerUp: enabled ? (_) => setState(() => _pressed = false) : null,
        onPointerCancel: enabled ? (_) => setState(() => _pressed = false) : null,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 110),
          curve: Curves.easeOut,
          scale: _pressed ? .92 : 1,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            curve: Curves.easeOut,
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _hovered ? _C.greenSoft : _C.soft,
              borderRadius: BorderRadius.circular(9),
              border: Border.all(color: _hovered ? _C.green.withOpacity(.22) : _C.divider),
            ),
            child: InkWell(
              onTap: widget.onTap,
              borderRadius: BorderRadius.circular(9),
              child: Icon(
                widget.icon,
                size: 18,
                color: enabled ? (_hovered ? _C.green : _C.muted) : _C.subtle,
              ),
            ),
          ),
        ),
      ),
    );

    return widget.tooltip == null
        ? child
        : Tooltip(
            message: widget.tooltip!,
            waitDuration: const Duration(milliseconds: 250),
            child: child,
          );
  }
}


class _TrackerSummaryLine extends StatelessWidget {
  const _TrackerSummaryLine({
    required this.icon,
    required this.label,
    required this.value,
    required this.ok,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    final color = ok ? _C.green : _C.subtle;
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
      decoration: BoxDecoration(
        color: ok ? _C.greenSoft : _C.soft,
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: ok ? _C.green.withOpacity(.16) : _C.divider),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 7),
          SizedBox(
            width: 86,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontFamily: 'Roboto',
                color: _C.subtle,
                fontSize: 10.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontFamily: 'Roboto',
                color: ok ? _C.text : _C.muted,
                fontSize: 11.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class _LoadAlert extends StatelessWidget {
  const _LoadAlert({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    final color = track.proStatusLevel == 'danger'
        ? _C.red
        : track.proStatusLevel == 'warning'
            ? _C.orange
            : _C.green;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(.18)),
      ),
      child: Row(
        children: [
          Icon(track.proStatusLevel == 'danger' ? Icons.warning_amber_rounded : Icons.insights_rounded, color: color, size: 20),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              track.liveInsight,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 12,
                fontWeight: FontWeight.w900,
                height: 1.25,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProMetricTile extends StatelessWidget {
  const _ProMetricTile({
    required this.title,
    required this.value,
    required this.subtitle,
    required this.icon,
  });

  final String title;
  final String value;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
      ),
      child: Row(
        children: [
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: _C.greenSoft,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, color: _C.green, size: 17),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 9.5, fontWeight: FontWeight.w900)),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 15, fontWeight: FontWeight.w900, fontFeatures: [FontFeature.tabularFigures()])),
                Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontSize: 8.5, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SpeedTrendMiniChart extends StatelessWidget {
  const _SpeedTrendMiniChart({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
      ),
      padding: const EdgeInsets.all(8),
      child: Row(
        children: [
          const SizedBox(
            width: 86,
            child: Text(
              'Кривая скорости',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: _C.subtle, fontSize: 10, fontWeight: FontWeight.w900),
            ),
          ),
          Expanded(
            child: CustomPaint(
              painter: _SpeedTrendPainter(points: track.points),
              child: const SizedBox.expand(),
            ),
          ),
        ],
      ),
    );
  }
}

class _ZoneBars extends StatelessWidget {
  const _ZoneBars({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    final zones = track.zoneDistancesM;
    final total = math.max(1.0, zones.values.fold<double>(0, (a, b) => a + b));

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Зоны скорости', style: TextStyle(color: _C.text, fontSize: 12, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          _ZoneRow(label: 'Ходьба', value: zones['walk'] ?? 0, total: total, color: _C.subtle),
          _ZoneRow(label: 'Бег', value: zones['run'] ?? 0, total: total, color: _C.green),
          _ZoneRow(label: 'HSR', value: zones['hsr'] ?? 0, total: total, color: _C.orange),
          _ZoneRow(label: 'Sprint', value: zones['sprint'] ?? 0, total: total, color: _C.red),
        ],
      ),
    );
  }
}

class _ZoneRow extends StatelessWidget {
  const _ZoneRow({
    required this.label,
    required this.value,
    required this.total,
    required this.color,
  });

  final String label;
  final double value;
  final double total;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final percent = (value / total).clamp(0.0, 1.0).toDouble();

    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(
        children: [
          SizedBox(
            width: 54,
            child: Text(label, style: const TextStyle(color: _C.muted, fontSize: 9.5, fontWeight: FontWeight.w800)),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                minHeight: 7,
                value: percent,
                backgroundColor: _C.divider,
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
          ),
          const SizedBox(width: 7),
          SizedBox(
            width: 44,
            child: Text('${value.toStringAsFixed(0)}м', textAlign: TextAlign.right, style: const TextStyle(color: _C.text, fontSize: 9.5, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _CoachHintBox extends StatelessWidget {
  const _CoachHintBox({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 68,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.greenSoft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.green.withOpacity(.16)),
      ),
      child: Row(
        children: [
          const Icon(Icons.psychology_alt_rounded, color: _C.green, size: 21),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              track.coachRecommendation,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _C.greenDark, fontSize: 10.5, fontWeight: FontWeight.w900, height: 1.25),
            ),
          ),
        ],
      ),
    );
  }
}

class _SpeedTrendPainter extends CustomPainter {
  const _SpeedTrendPainter({required this.points});

  final List<_RuntimePoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()
      ..color = _C.divider.withOpacity(.55)
      ..strokeWidth = 1;
    for (var i = 0; i < 3; i++) {
      final y = size.height * (i + 1) / 4;
      canvas.drawLine(Offset(0, y), Offset(size.width, y), bg);
    }

    if (points.length < 2) return;

    final src = points.length > 36 ? points.sublist(points.length - 36) : points;
    final maxSpeed = math.max(8.0, src.map((p) => p.speedKmh).fold<double>(0, math.max));

    final path = Path();
    for (var i = 0; i < src.length; i++) {
      final x = src.length == 1 ? 0.0 : size.width * i / (src.length - 1);
      final y = size.height - (src[i].speedKmh / maxSpeed).clamp(0.0, 1.0) * size.height;
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    canvas.drawPath(
      path,
      Paint()
        ..color = _C.green
        ..strokeWidth = 2.4
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round,
    );
  }

  @override
  bool shouldRepaint(covariant _SpeedTrendPainter oldDelegate) => true;
}


class _SummaryRow extends StatelessWidget {
  const _SummaryRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.ok,
  });

  final IconData icon;
  final String label;
  final String value;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    final color = ok ? _C.green : _C.subtle;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: ok ? _C.greenSoft : _C.soft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: ok ? _C.green.withOpacity(.18) : _C.divider),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          SizedBox(
            width: 96,
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _C.subtle,
                fontSize: 11,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              textAlign: TextAlign.right,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: ok ? _C.text : _C.muted,
                fontSize: 12,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TinyHud extends StatelessWidget {
  const _TinyHud({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 9),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(label, style: const TextStyle(color: _C.subtle, fontSize: 8.5, fontWeight: FontWeight.w900)),
          Text(value, style: const TextStyle(color: _C.text, fontSize: 10, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}


class _RuntimePoint {
  final double lat;
  final double lon;
  final int timeMs;
  final double speedKmh;
  final double rawSpeedKmh;
  final double distanceDeltaM;
  final String packetType;

  const _RuntimePoint({
    required this.lat,
    required this.lon,
    required this.timeMs,
    required this.speedKmh,
    required this.rawSpeedKmh,
    required this.distanceDeltaM,
    required this.packetType,
  });
}

class _RuntimeTrack {
  _RuntimeTrack({
    required this.key,
    required this.playerName,
    required this.deviceName,
  });

  final String key;
  final String playerName;
  final String deviceName;
  final List<_RuntimePoint> points = <_RuntimePoint>[];

  double speedKmh = 0;
  double rawSpeedKmh = 0;
  double totalDistanceM = 0;
  double maxSpeedKmh = 0;
  double lastDeltaM = 0;
  double headingDeg = 0;
  int sprintCount = 0;

  String get directionLabel {
    if (points.length < 2 || lastDeltaM <= 0.25) return 'нет движения';
    return '${headingDeg.round()}°';
  }

  int get durationSec {
    if (points.length < 2) return 0;
    return math.max(1, ((points.last.timeMs - points.first.timeMs) / 1000).round());
  }

  double get avgSpeedKmh {
    if (durationSec <= 0) return 0;
    return (totalDistanceM / durationSec) * 3.6;
  }

  double get movingAvgSpeedKmh {
    final moving = points.where((p) => p.speedKmh >= 4).toList();
    if (moving.isEmpty) return 0;
    return moving.map((p) => p.speedKmh).fold<double>(0, (a, b) => a + b) / moving.length;
  }

  double get highSpeedDistanceM => points
      .where((p) => p.speedKmh >= 19.8 && p.speedKmh < 25.2)
      .map((p) => p.distanceDeltaM)
      .fold<double>(0, (a, b) => a + b);

  double get sprintDistanceM => points
      .where((p) => p.speedKmh >= 25.2)
      .map((p) => p.distanceDeltaM)
      .fold<double>(0, (a, b) => a + b);

  Map<String, double> get zoneDistancesM {
    double walk = 0;
    double run = 0;
    double hsr = 0;
    double sprint = 0;

    for (final p in points) {
      if (p.speedKmh < 7) {
        walk += p.distanceDeltaM;
      } else if (p.speedKmh < 19.8) {
        run += p.distanceDeltaM;
      } else if (p.speedKmh < 25.2) {
        hsr += p.distanceDeltaM;
      } else {
        sprint += p.distanceDeltaM;
      }
    }

    return {
      'walk': walk,
      'run': run,
      'hsr': hsr,
      'sprint': sprint,
    };
  }

  int get accelerationCount {
    var count = 0;
    for (var i = 1; i < points.length; i++) {
      final dt = math.max(0.75, (points[i].timeMs - points[i - 1].timeMs) / 1000.0);
      final acc = ((points[i].speedKmh - points[i - 1].speedKmh) / 3.6) / dt;
      if (acc >= 2.0) count++;
    }
    return count;
  }

  int get decelerationCount {
    var count = 0;
    for (var i = 1; i < points.length; i++) {
      final dt = math.max(0.75, (points[i].timeMs - points[i - 1].timeMs) / 1000.0);
      final acc = ((points[i].speedKmh - points[i - 1].speedKmh) / 3.6) / dt;
      if (acc <= -2.0) count++;
    }
    return count;
  }

  double get recentAvgSpeedKmh {
    if (points.isEmpty) return 0;
    final end = points.last.timeMs;
    final recent = points.where((p) => end - p.timeMs <= 60000 && p.speedKmh >= 2).toList();
    if (recent.isEmpty) return speedKmh;
    return recent.map((p) => p.speedKmh).fold<double>(0, (a, b) => a + b) / recent.length;
  }

  double get firstPhaseAvgSpeedKmh {
    if (points.length < 6) return movingAvgSpeedKmh;
    final split = math.max(3, (points.length * 0.33).floor());
    final list = points.take(split).where((p) => p.speedKmh >= 2).toList();
    if (list.isEmpty) return movingAvgSpeedKmh;
    return list.map((p) => p.speedKmh).fold<double>(0, (a, b) => a + b) / list.length;
  }

  double get speedDropPercent {
    final base = firstPhaseAvgSpeedKmh;
    if (base <= 1) return 0;
    final drop = ((base - recentAvgSpeedKmh) / base) * 100;
    return drop.clamp(0.0, 100.0).toDouble();
  }

  double get highIntensityShare {
    if (totalDistanceM <= 0) return 0;
    return ((highSpeedDistanceM + sprintDistanceM) / totalDistanceM).clamp(0.0, 1.0).toDouble();
  }

  double get proLoadScore {
    final value = (totalDistanceM * 0.018) +
        (highSpeedDistanceM * 0.10) +
        (sprintDistanceM * 0.22) +
        (accelerationCount * 3.0) +
        (decelerationCount * 2.4) +
        (maxSpeedKmh * 0.65);
    return value.clamp(0.0, 999.0).toDouble();
  }

  double get fatigueScore {
    final value = (speedDropPercent * 1.55) +
        (highIntensityShare * 42.0) +
        (decelerationCount * 1.4) +
        (sprintDistanceM / 20.0);
    return value.clamp(0.0, 100.0).toDouble();
  }

  String get proStatusLevel {
    if (fatigueScore >= 72 || speedDropPercent >= 24) return 'danger';
    if (fatigueScore >= 48 || speedDropPercent >= 14 || highIntensityShare >= .22) return 'warning';
    return 'normal';
  }

  String get proStatusLabel {
    if (proStatusLevel == 'danger') return 'высокая';
    if (proStatusLevel == 'warning') return 'контроль';
    return 'норма';
  }

  String get fatigueLabel {
    if (fatigueScore >= 72) return 'риск';
    if (fatigueScore >= 48) return 'следить';
    return 'норма';
  }

  String get liveInsight {
    if (speedDropPercent >= 24) {
      return 'Скорость заметно падает (${speedDropPercent.toStringAsFixed(0)}%). Игрок теряет интенсивность — нужен контроль нагрузки.';
    }
    if (fatigueScore >= 72) {
      return 'Высокая усталость (${fatigueScore.toStringAsFixed(0)}%). Риск падения качества рывков и решений.';
    }
    if (highIntensityShare >= .25) {
      return 'Высокая доля интенсивной работы. Следите за восстановлением между рывками.';
    }
    if (sprintDistanceM > 0) {
      return 'Спринты фиксируются, нагрузка управляемая. Можно сравнивать отрезки по времени.';
    }
    return 'Нагрузка в норме. Для полноценного анализа нужен более длинный live-отрезок.';
  }

  String get coachRecommendation {
    if (speedDropPercent >= 24) {
      return 'Снизить объём рывков, дать восстановление 2–3 минуты или заменить игрока при повторном падении скорости.';
    }
    if (fatigueScore >= 72) {
      return 'Контроль ЧСС/самочувствия, перейти на технико-тактическую работу низкой интенсивности.';
    }
    if (highIntensityShare >= .25) {
      return 'После серии HSR добавить паузу восстановления и оценить качество ускорений.';
    }
    if (accelerationCount + decelerationCount >= 10) {
      return 'Много IMA-событий: следить за мышечной нагрузкой и резкими торможениями.';
    }
    return 'Продолжать наблюдение: темп стабильный, критичного падения скорости нет.';
  }

  Map<String, dynamic> toAnalysisJson() {
    return {
      'duration_sec': durationSec,
      'distance_m': _round1(totalDistanceM),
      'avg_speed_kmh': _round1(avgSpeedKmh),
      'moving_avg_speed_kmh': _round1(movingAvgSpeedKmh),
      'max_speed_kmh': _round1(maxSpeedKmh),
      'high_speed_distance_m': _round1(highSpeedDistanceM),
      'sprint_distance_m': _round1(sprintDistanceM),
      'sprint_count': sprintCount,
      'acceleration_count': accelerationCount,
      'deceleration_count': decelerationCount,
      'speed_drop_percent': _round1(speedDropPercent),
      'fatigue_score': _round1(fatigueScore),
      'load_score': _round1(proLoadScore),
      'high_intensity_share': _round1(highIntensityShare * 100),
      'zones': zoneDistancesM.map((key, value) => MapEntry(key, _round1(value))),
      'status_level': proStatusLevel,
      'insight': liveInsight,
      'recommendation': coachRecommendation,
    };
  }

  _RuntimePoint addPoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
  }) {
    double delta = 0;
    double speed = 0;
    double raw = 0;

    if (points.isNotEmpty) {
      final prev = points.last;
      delta = _haversineM(prev.lat, prev.lon, latitude, longitude);
      final dt = math.max(0.75, (timeMs - prev.timeMs) / 1000.0);
      raw = (delta / dt) * 3.6;
      speed = raw.clamp(0.0, 42.0).toDouble();
      headingDeg = _bearingDeg(prev.lat, prev.lon, latitude, longitude);

      if (raw <= 55.0) {
        totalDistanceM += delta;
      }

      if (speed >= 20.0 && (points.isEmpty || points.last.speedKmh < 20.0)) {
        sprintCount += 1;
      }
    }

    speedKmh = speed;
    rawSpeedKmh = raw;
    maxSpeedKmh = math.max(maxSpeedKmh, speed);
    lastDeltaM = delta;

    final p = _RuntimePoint(
      lat: latitude,
      lon: longitude,
      timeMs: timeMs,
      speedKmh: speed,
      rawSpeedKmh: raw,
      distanceDeltaM: delta,
      packetType: packetType,
    );

    points.add(p);
    if (points.length > 900) {
      points.removeAt(0);
    }

    return p;
  }
}

double _round1(double value) => (value * 10).roundToDouble() / 10;

double _haversineM(double lat1, double lon1, double lat2, double lon2) {
  const r = 6371000.0;
  final dLat = _deg(lat2 - lat1);
  final dLon = _deg(lon2 - lon1);
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_deg(lat1)) *
          math.cos(_deg(lat2)) *
          math.sin(dLon / 2) *
          math.sin(dLon / 2);
  return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

double _deg(double v) => v * math.pi / 180.0;

double _bearingDeg(double lat1, double lon1, double lat2, double lon2) {
  final p1 = _deg(lat1);
  final p2 = _deg(lat2);
  final dLon = _deg(lon2 - lon1);
  final y = math.sin(dLon) * math.cos(p2);
  final x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dLon);
  final bearing = math.atan2(y, x) * 180.0 / math.pi;
  return (bearing + 360.0) % 360.0;
}

class _RuntimeFieldPainter extends CustomPainter {
  _RuntimeFieldPainter({
    required this.field,
    required this.tracks,
    required this.showVectors,
    required this.showHeatmap,
    required this.showTrace,
    required this.showLabels,
  });

  final TrackerFieldModel? field;
  final List<_RuntimeTrack> tracks;
  final bool showVectors;
  final bool showHeatmap;
  final bool showTrace;
  final bool showLabels;

  static const double _pitchMetersX = 105.0;
  static const double _pitchMetersY = 68.0;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = const Color(0xFF0B1110));

    final pitch = _fitPitch(rect.deflate(8));
    final grass = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          Color(0xFF0B8B3A),
          Color(0xFF087A33),
          Color(0xFF0EA34E),
        ],
      ).createShader(pitch);

    canvas.drawRect(pitch, grass);

    _drawGrass(canvas, pitch);
    _drawPitchLines(canvas, pitch);

    final allPoints = tracks.expand((t) => t.points).toList();
    if (allPoints.isEmpty) {
      _drawCenterText(
        canvas,
        size,
        field?.hasCalibration == true
            ? 'Ждём GPS · поле 105×68 без растяжения'
            : 'Сначала откалибруйте поле',
      );
      return;
    }

    double minLat = allPoints.first.lat;
    double maxLat = allPoints.first.lat;
    double minLon = allPoints.first.lon;
    double maxLon = allPoints.first.lon;

    for (final p in allPoints) {
      minLat = math.min(minLat, p.lat);
      maxLat = math.max(maxLat, p.lat);
      minLon = math.min(minLon, p.lon);
      maxLon = math.max(maxLon, p.lon);
    }

    if (showHeatmap) {
      _drawHeatmap(canvas, pitch, allPoints, minLat, maxLat, minLon, maxLon);
    }

    for (final track in tracks) {
      if (track.points.isEmpty) continue;

      if (showTrace && track.points.length >= 2) {
        final path = Path();
        for (var i = 0; i < track.points.length; i++) {
          final pos = _project(track.points[i], pitch, minLat, maxLat, minLon, maxLon);
          if (i == 0) {
            path.moveTo(pos.dx, pos.dy);
          } else {
            path.lineTo(pos.dx, pos.dy);
          }
        }

        canvas.drawPath(
          path,
          Paint()
            ..color = Colors.black.withOpacity(.26)
            ..strokeWidth = 5.5
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeJoin = StrokeJoin.round,
        );

        canvas.drawPath(
          path,
          Paint()
            ..color = Colors.white.withOpacity(.86)
            ..strokeWidth = 2.4
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeJoin = StrokeJoin.round,
        );
      }

      if (showVectors && track.points.length >= 2) {
        final last = track.points.last;
        final prev = track.points[track.points.length - 2];
        final a = _project(prev, pitch, minLat, maxLat, minLon, maxLon);
        final b = _project(last, pitch, minLat, maxLat, minLon, maxLon);
        _drawVector(canvas, a, b, track.speedKmh);
      }

      final last = track.points.last;
      final pos = _project(last, pitch, minLat, maxLat, minLon, maxLon);
      final color = _speedColor(track.speedKmh);

      canvas.drawCircle(
        pos,
        22,
        Paint()
          ..color = color.withOpacity(.24)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 10),
      );
      canvas.drawCircle(
        pos,
        10,
        Paint()..color = color,
      );
      canvas.drawCircle(
        pos,
        13.5,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.2
          ..color = Colors.white.withOpacity(.94),
      );

      if (showLabels) {
        final label =
            '${track.playerName} · ${track.speedKmh.toStringAsFixed(1)} км/ч · ${track.directionLabel}';
        _drawLabel(canvas, pitch, pos, label);
      }
    }

    _drawScale(canvas, pitch);
  }

  Rect _fitPitch(Rect area) {
    const aspect = _pitchMetersX / _pitchMetersY;
    double w = area.width;
    double h = w / aspect;

    if (h > area.height) {
      h = area.height;
      w = h * aspect;
    }

    return Rect.fromCenter(
      center: area.center,
      width: w,
      height: h,
    );
  }

  void _drawGrass(Canvas canvas, Rect pitch) {
    final stripePaint = Paint();
    final stripeW = pitch.width / 14.0;

    for (var i = 0; i < 14; i++) {
      stripePaint.color = i.isEven
          ? Colors.white.withOpacity(.035)
          : Colors.black.withOpacity(.035);

      canvas.drawRect(
        Rect.fromLTWH(pitch.left + i * stripeW, pitch.top, stripeW, pitch.height),
        stripePaint,
      );
    }

    final mower = Paint()
      ..color = Colors.white.withOpacity(.025)
      ..strokeWidth = 1;

    for (var i = 1; i < 7; i++) {
      final y = pitch.top + pitch.height * i / 7;
      canvas.drawLine(Offset(pitch.left, y), Offset(pitch.right, y), mower);
    }
  }

  void _drawPitchLines(Canvas canvas, Rect pitch) {
    final line = Paint()
      ..color = Colors.white.withOpacity(.92)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final thin = Paint()
      ..color = Colors.white.withOpacity(.72)
      ..strokeWidth = 1.35
      ..style = PaintingStyle.stroke;

    double xM(double m) => pitch.left + pitch.width * (m / _pitchMetersX);
    double yM(double m) => pitch.top + pitch.height * (m / _pitchMetersY);

    canvas.drawRect(pitch, line);

    // Halfway line and centre circle.
    canvas.drawLine(Offset(xM(52.5), pitch.top), Offset(xM(52.5), pitch.bottom), thin);
    canvas.drawCircle(pitch.center, pitch.width * (9.15 / _pitchMetersX), thin);
    canvas.drawCircle(pitch.center, 3.2, Paint()..color = Colors.white.withOpacity(.92));

    // Penalty and goal areas in real football proportions.
    final penaltyDepth = pitch.width * (16.5 / _pitchMetersX);
    final penaltyHeight = pitch.height * (40.32 / _pitchMetersY);
    final goalDepth = pitch.width * (5.5 / _pitchMetersX);
    final goalHeight = pitch.height * (18.32 / _pitchMetersY);

    final leftPenalty = Rect.fromLTWH(
      pitch.left,
      pitch.center.dy - penaltyHeight / 2,
      penaltyDepth,
      penaltyHeight,
    );
    final rightPenalty = Rect.fromLTWH(
      pitch.right - penaltyDepth,
      pitch.center.dy - penaltyHeight / 2,
      penaltyDepth,
      penaltyHeight,
    );

    final leftGoal = Rect.fromLTWH(
      pitch.left,
      pitch.center.dy - goalHeight / 2,
      goalDepth,
      goalHeight,
    );
    final rightGoal = Rect.fromLTWH(
      pitch.right - goalDepth,
      pitch.center.dy - goalHeight / 2,
      goalDepth,
      goalHeight,
    );

    canvas.drawRect(leftPenalty, thin);
    canvas.drawRect(rightPenalty, thin);
    canvas.drawRect(leftGoal, thin);
    canvas.drawRect(rightGoal, thin);

    // Penalty spots.
    canvas.drawCircle(Offset(xM(11), pitch.center.dy), 2.2, Paint()..color = Colors.white.withOpacity(.9));
    canvas.drawCircle(Offset(xM(94), pitch.center.dy), 2.2, Paint()..color = Colors.white.withOpacity(.9));

    // Penalty arcs.
    final arcRadius = pitch.width * (9.15 / _pitchMetersX);
    final leftSpot = Offset(xM(11), pitch.center.dy);
    final rightSpot = Offset(xM(94), pitch.center.dy);

    canvas.drawArc(
      Rect.fromCircle(center: leftSpot, radius: arcRadius),
      -math.pi / 3,
      math.pi * 2 / 3,
      false,
      thin,
    );
    canvas.drawArc(
      Rect.fromCircle(center: rightSpot, radius: arcRadius),
      math.pi * 2 / 3,
      math.pi * 2 / 3,
      false,
      thin,
    );

    // Goals outside the pitch.
    final goalPaint = Paint()
      ..color = Colors.white.withOpacity(.85)
      ..strokeWidth = 2.2
      ..style = PaintingStyle.stroke;
    final goalVisualH = pitch.height * (7.32 / _pitchMetersY);
    canvas.drawRect(
      Rect.fromLTWH(pitch.left - 7, pitch.center.dy - goalVisualH / 2, 7, goalVisualH),
      goalPaint,
    );
    canvas.drawRect(
      Rect.fromLTWH(pitch.right, pitch.center.dy - goalVisualH / 2, 7, goalVisualH),
      goalPaint,
    );

    // Corner arcs.
    final cornerR = pitch.width * (1.0 / _pitchMetersX);
    canvas.drawArc(Rect.fromCircle(center: pitch.topLeft, radius: cornerR), 0, math.pi / 2, false, thin);
    canvas.drawArc(Rect.fromCircle(center: pitch.topRight, radius: cornerR), math.pi / 2, math.pi / 2, false, thin);
    canvas.drawArc(Rect.fromCircle(center: pitch.bottomLeft, radius: cornerR), -math.pi / 2, math.pi / 2, false, thin);
    canvas.drawArc(Rect.fromCircle(center: pitch.bottomRight, radius: cornerR), math.pi, math.pi / 2, false, thin);
  }

  void _drawHeatmap(
    Canvas canvas,
    Rect pitch,
    List<_RuntimePoint> points,
    double minLat,
    double maxLat,
    double minLon,
    double maxLon,
  ) {
    final step = points.length > 240
        ? 5
        : points.length > 140
            ? 3
            : points.length > 70
                ? 2
                : 1;

    for (var i = 0; i < points.length; i += step) {
      final p = points[i];
      final pos = _project(p, pitch, minLat, maxLat, minLon, maxLon);
      final double radius = (16 + p.speedKmh * 1.25).clamp(15.0, 48.0).toDouble();
      final color = _speedColor(p.speedKmh);
      final heat = Paint()
        ..shader = RadialGradient(
          colors: [
            color.withOpacity(.30),
            color.withOpacity(.10),
            Colors.transparent,
          ],
          stops: const [.0, .48, 1],
        ).createShader(Rect.fromCircle(center: pos, radius: radius));
      canvas.drawCircle(pos, radius, heat);
    }
  }

  void _drawVector(Canvas canvas, Offset from, Offset to, double speedKmh) {
    final delta = to - from;
    final len = delta.distance;
    if (len < 2) return;

    final dir = delta / len;
    final double vectorLen = (18 + speedKmh * 1.8).clamp(24.0, 74.0).toDouble();
    final end = to + dir * vectorLen;
    final color = _speedColor(speedKmh);

    canvas.drawLine(
      to,
      end,
      Paint()
        ..color = Colors.black.withOpacity(.32)
        ..strokeWidth = 7
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      to,
      end,
      Paint()
        ..color = color
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round,
    );

    final angle = math.atan2(dir.dy, dir.dx);
    final left = end - Offset(math.cos(angle - .62), math.sin(angle - .62)) * 12;
    final right = end - Offset(math.cos(angle + .62), math.sin(angle + .62)) * 12;
    final head = Path()
      ..moveTo(end.dx, end.dy)
      ..lineTo(left.dx, left.dy)
      ..lineTo(right.dx, right.dy)
      ..close();

    canvas.drawPath(head, Paint()..color = color);
    canvas.drawPath(
      head,
      Paint()
        ..color = Colors.white.withOpacity(.86)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );
  }

  Color _speedColor(double speedKmh) {
    if (speedKmh >= 25) return const Color(0xFFE11D48);
    if (speedKmh >= 20) return _C.orange;
    if (speedKmh >= 13) return const Color(0xFFFACC15);
    if (speedKmh >= 6) return const Color(0xFF5EEAD4);
    return _C.greenLight;
  }

  void _drawLabel(Canvas canvas, Rect pitch, Offset pos, String label) {
    final text = label.length > 34 ? '${label.substring(0, 34)}…' : label;
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 240);

    final bgRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        (pos.dx + 14).clamp(pitch.left, pitch.right - tp.width - 18).toDouble(),
        (pos.dy - 32).clamp(pitch.top, pitch.bottom - 24).toDouble(),
        tp.width + 16,
        24,
      ),
      const Radius.circular(8),
    );

    canvas.drawRRect(bgRect, Paint()..color = Colors.black.withOpacity(.40));
    tp.paint(canvas, Offset(bgRect.left + 8, bgRect.top + 5));
  }

  Offset _project(
    _RuntimePoint p,
    Rect pitch,
    double minLat,
    double maxLat,
    double minLon,
    double maxLon,
  ) {
    final lonRange = (maxLon - minLon).abs();
    final latRange = (maxLat - minLat).abs();

    final double nx = lonRange < 0.000001
        ? 0.5
        : ((p.lon - minLon) / lonRange).clamp(0.035, 0.965).toDouble();
    final double ny = latRange < 0.000001
        ? 0.5
        : ((p.lat - minLat) / latRange).clamp(0.035, 0.965).toDouble();

    return Offset(
      pitch.left + nx * pitch.width,
      pitch.bottom - ny * pitch.height,
    );
  }

  void _drawScale(Canvas canvas, Rect pitch) {
    final tp = TextPainter(
      text: TextSpan(
        text: '105 × 68 м',
        style: TextStyle(
          color: Colors.white.withOpacity(.70),
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    tp.paint(canvas, Offset(pitch.right - tp.width - 8, pitch.bottom - tp.height - 6));
  }

  void _drawCenterText(Canvas canvas, Size size, String text) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: Colors.white.withOpacity(.88),
          fontSize: 16,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: size.width - 60);

    tp.paint(canvas, Offset((size.width - tp.width) / 2, (size.height - tp.height) / 2));
  }

  @override
  bool shouldRepaint(covariant _RuntimeFieldPainter oldDelegate) => true;
}


class _RuntimePlayerTile extends StatelessWidget {
  const _RuntimePlayerTile({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    final color = track.speedKmh >= 20 ? _C.orange : _C.green;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _C.greenSoft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.green.withOpacity(.22)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: Colors.white,
            child: Icon(Icons.radio_button_checked_rounded, color: color),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(track.playerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(
                  '${track.speedKmh.toStringAsFixed(1)} км/ч · ${(track.totalDistanceM / 1000).toStringAsFixed(2)} км · точек ${track.points.length}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _C.muted, fontSize: 11.5, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text('LIVE', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
        ],
      ),
    );
  }
}

class _ServerPlayerTile extends StatelessWidget {
  const _ServerPlayerTile({required this.session});

  final TrackerLiveSessionModel session;

  @override
  Widget build(BuildContext context) {
    final color = !session.isOnline ? _C.subtle : session.speedKmh >= 20 ? _C.orange : _C.green;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: session.isOnline ? _C.soft : Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: _C.soft,
            child: Icon(session.isOnline ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, color: color),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(session.playerName ?? session.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text('${session.speedKmh.toStringAsFixed(1)} км/ч · ${(session.totalDistanceM / 1000).toStringAsFixed(2)} км · сервер', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 11.5, fontWeight: FontWeight.w700)),
            ]),
          ),
          Text(session.isOnline ? 'SERVER' : 'OFF', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11)),
        ],
      ),
    );
  }
}

class _KpiData {
  const _KpiData(this.title, this.value, this.icon);
  final String title;
  final String value;
  final IconData icon;
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({required this.data});
  final _KpiData data;

  @override
  Widget build(BuildContext context) {
    return _LiveCard(
      padding: const EdgeInsets.all(13),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: _C.greenSoft, borderRadius: BorderRadius.circular(10)),
            child: Icon(data.icon, color: _C.green),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(data.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 11.5, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(data.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w900, fontFeatures: [FontFeature.tabularFigures()])),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DebugLine extends StatelessWidget {
  const _DebugLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.divider)),
      child: Row(
        children: [
          SizedBox(width: 72, child: Text(label, style: const TextStyle(color: _C.subtle, fontSize: 11, fontWeight: FontWeight.w900))),
          Expanded(
            child: Text(
              value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _C.text, fontSize: 11.2, fontWeight: FontWeight.w800, fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProblemBox extends StatelessWidget {
  const _ProblemBox({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final isBad = text.toLowerCase().contains('ошибка') || text.toLowerCase().contains('нет ');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isBad ? _C.redSoft : _C.greenSoft,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: isBad ? _C.red.withOpacity(.18) : _C.green.withOpacity(.18)),
      ),
      child: Row(
        children: [
          Icon(isBad ? Icons.warning_amber_rounded : Icons.check_circle_rounded, color: isBad ? _C.red : _C.green),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              text,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: isBad ? _C.red : _C.greenDark, fontSize: 12, fontWeight: FontWeight.w900, height: 1.25),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatePill extends StatelessWidget {
  const _StatePill({required this.icon, required this.label, required this.ok});
  final IconData icon;
  final String label;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    final color = ok ? _C.green : _C.orange;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 6),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 220),
            child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}


class _TitleRow extends StatelessWidget {
  const _TitleRow({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(
            color: _C.greenSoft,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: _C.green.withOpacity(.12)),
          ),
          child: Icon(icon, color: _C.green, size: 19),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: 'Roboto',
                  color: _C.text,
                  fontSize: 14.5,
                  fontWeight: FontWeight.w900,
                  height: 1.12,
                  letterSpacing: -0.22,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontFamily: 'Roboto',
                  color: _C.subtle,
                  fontSize: 10.8,
                  fontWeight: FontWeight.w700,
                  height: 1.18,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}


class _LiveCard extends StatelessWidget {
  const _LiveCard({required this.child, this.padding = const EdgeInsets.all(12)});
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: _C.divider),
        boxShadow: const [
          BoxShadow(
            color: Color(0x050F172A),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: child,
    );
  }
}



InputDecoration _input(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: _C.soft,
      isDense: true,
      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: _C.divider),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: _C.divider),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(10),
        borderSide: const BorderSide(color: _C.green),
      ),
    );



class _C {
  static const Color bg = Color(0xFFF4F5F6);
  static const Color panel = Colors.white;
  static const Color soft = Color(0xFFF8F9FA);
  static const Color soft2 = Color(0xFFFAFAFB);
  static const Color text = Color(0xFF111827);
  static const Color muted = Color(0xFF475467);
  static const Color subtle = Color(0xFF6B7280);
  static const Color divider = Color(0xFFE5E7EB);
  static const Color dividerStrong = Color(0xFFD8DEE6);
  static const Color green = Color(0xFF00A750);
  static const Color greenLight = Color(0xFFB9FFDC);
  static const Color greenSoft = Color(0xFFF3FBF6);
  static const Color greenDark = Color(0xFF047A3F);
  static const Color orange = Color(0xFFB7791F);
  static const Color orangeSoft = Color(0xFFFFF7E6);
  static const Color red = Color(0xFFD92D20);
  static const Color redSoft = Color(0xFFFFF1F1);
}

