import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:geolocator/geolocator.dart';

import 'models/action_tracker_protocol.dart';
import 'models/tracker_pro_models.dart';
import 'services/action_tracker_ble_service.dart';
import 'services/tracker_permissions.dart';
import 'services/tracker_pro_api.dart';
import 'widgets/tracker_heatmap_painter.dart';
import 'widgets/tracker_field_painter.dart';
import 'tracker_live_panel.dart';

class SportotekaTrackerProScreen extends StatefulWidget {
  const SportotekaTrackerProScreen({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teamId,
    required this.teamName,
    required this.userId,
    this.initialPlayers = const [],
  });

  final int clubId;
  final String clubName;
  final int teamId;
  final String teamName;
  final int userId;
  final List<Map<String, dynamic>> initialPlayers;

  @override
  State<SportotekaTrackerProScreen> createState() => _SportotekaTrackerProScreenState();
}

class _SportotekaTrackerProScreenState extends State<SportotekaTrackerProScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;
  late final ActionTrackerBleService _ble;
  late final TrackerProApi _api;

  final List<ActionTrackerRecord> _records = [];
  final List<ActionTrackerGpsPoint> _points = [];
  final List<String> _logs = [];

  List<TrackerPlayerOption> _players = [];
  List<TrackerDeviceModel> _savedDevices = [];
  List<TrackerSessionModel> _sessions = [];
  List<TrackerHeatPoint> _heatPoints = [];
  List<TrackerFieldModel> _fields = [];

  TrackerDashboardModel? _dashboard;
  TrackerSpeedSettings _settings = const TrackerSpeedSettings();
  ActionTrackerBatteryState? _battery;
  ActionTrackerRecord? _selectedRecord;
  ActionTrackerDevice? _connected;
  TrackerPlayerOption? _selectedPlayer;
  TrackerSessionModel? _selectedSession;
  TrackerFieldModel? _selectedField;

  bool _busy = false;
  bool _saving = false;
  bool _loadingServer = false;
  bool _transferFinished = false;

  StreamSubscription<ActionTrackerParseResult>? _dataSub;
  StreamSubscription<String>? _logSub;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 8, vsync: this);
    _ble = ActionTrackerBleService();
    _api = TrackerProApi();
    _players = widget.initialPlayers.map(TrackerPlayerOption.fromJson).where((p) => p.id > 0).toList();
    _bindBle();
    _loadServerData();
  }

  Future<void> _bindBle() async {
    _dataSub = _ble.dataStream.listen((event) {
      if (!mounted) return;
      setState(() {
        if (event.battery != null) _battery = event.battery;
        if (event.records.isNotEmpty) {
          _records
            ..clear()
            ..addAll(event.records);
        }
        if (event.gpsChunk != null) _points.addAll(event.gpsChunk!.points);
        if (event.transferFinished) _transferFinished = true;
      });
    });

    _logSub = _ble.logStream.listen((line) {
      if (!mounted) return;
      setState(() {
        _logs.insert(0, line);
        if (_logs.length > 100) _logs.removeLast();
      });
    });

    try {
      await _ble.init();
    } catch (e) {
      _toast('Bluetooth', '$e');
    }
  }

  Future<void> _loadServerData() async {
    setState(() => _loadingServer = true);
    try {
      final results = await Future.wait<dynamic>([
        if (_players.isEmpty) _api.loadPlayers(teamId: widget.teamId) else Future<List<TrackerPlayerOption>>.value(_players),
        _api.loadDevices(teamId: widget.teamId),
        _api.loadDashboard(teamId: widget.teamId),
        _api.loadSessions(teamId: widget.teamId, playerId: _selectedPlayer?.id),
        _api.loadHeatmap(teamId: widget.teamId, playerId: _selectedPlayer?.id, sessionId: _selectedSession?.id, fieldId: _selectedField?.id),
        _api.loadSettings(teamId: widget.teamId),
        _api.loadFields(teamId: widget.teamId),
      ]);

      if (!mounted) return;
      setState(() {
        _players = results[0] as List<TrackerPlayerOption>;
        _savedDevices = results[1] as List<TrackerDeviceModel>;
        _dashboard = results[2] as TrackerDashboardModel;
        _sessions = results[3] as List<TrackerSessionModel>;
        _heatPoints = results[4] as List<TrackerHeatPoint>;
        _settings = results[5] as TrackerSpeedSettings;
        _fields = results[6] as List<TrackerFieldModel>;
        _selectedPlayer ??= _players.isNotEmpty ? _players.first : null;
        _selectedField ??= _fields.isNotEmpty ? _fields.firstWhere((f) => f.isDefault, orElse: () => _fields.first) : null;
      });
    } catch (e) {
      _toast('Трекер', 'Ошибка загрузки данных: $e');
    } finally {
      if (mounted) setState(() => _loadingServer = false);
    }
  }

  @override
  void dispose() {
    _dataSub?.cancel();
    _logSub?.cancel();
    _ble.dispose();
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _scan() async {
    setState(() => _busy = true);
    try {
      await TrackerPermissions.ensureBlePermissions();
      await _ble.scan();
    } catch (e) {
      _toast('Bluetooth', '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _connect(ActionTrackerDevice device) async {
    setState(() => _busy = true);
    try {
      await TrackerPermissions.ensureBlePermissions();
      await _ble.connect(device);
      if (!mounted) return;
      setState(() => _connected = device);
      await _api.registerOrBindDevice(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: _selectedPlayer?.id,
        deviceUuid: device.id,
        deviceName: device.name,
      );
      await _loadServerData();
    } catch (e) {
      _toast('Подключение', '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _loadGps(ActionTrackerRecord record) async {
    setState(() {
      _selectedRecord = record;
      _points.clear();
      _transferFinished = false;
      _busy = true;
    });
    try {
      await _ble.requestGpsRecord(record);
      _tabs.animateTo(2);
    } catch (e) {
      _toast('GPS', '$e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _saveSession() async {
    final connected = _connected;
    final record = _selectedRecord;
    final selectedPlayer = _selectedPlayer;

    if (connected == null) {
      _toast('Трекер', 'Сначала подключите устройство');
      return;
    }
    if (record == null) {
      _toast('Трекер', 'Сначала выберите запись');
      return;
    }
    if (_points.length < 2) {
      _toast('GPS', 'Недостаточно GPS-точек для сохранения');
      return;
    }

    TrackerDeviceModel? boundDevice;
    for (final d in _savedDevices) {
      if (d.deviceUuid == connected.id) {
        boundDevice = d;
        break;
      }
    }

    final effectivePlayerId = selectedPlayer?.id ?? boundDevice?.playerId;
    if (effectivePlayerId == null || effectivePlayerId <= 0) {
      _toast('Игрок', 'Выберите игрока сверху или привяжите трекер к игроку во вкладке «Трекеры»');
      return;
    }

    setState(() => _saving = true);
    try {
      final result = await _api.saveGpsSession(
        clubId: widget.clubId,
        teamId: widget.teamId,
        userId: widget.userId,
        playerId: effectivePlayerId,
        deviceUuid: connected.id,
        deviceName: connected.name,
        record: record,
        points: _points,
        fieldId: _selectedField?.id,
      );

      final sessionId = int.tryParse('${result['session_id'] ?? ''}');
      if (sessionId != null && sessionId > 0) {
        await _api.processSession(sessionId: sessionId);
      }

      _toast('Готово', 'Сессия сохранена и обработана');
      setState(() {
        _selectedSession = null;
      });
      await _loadServerData();
      _tabs.animateTo(2);
    } catch (e) {
      _toast('Сохранение', '$e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _bindSavedDevice(TrackerDeviceModel device, TrackerPlayerOption? player) async {
    try {
      await _api.registerOrBindDevice(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: player?.id,
        deviceUuid: device.deviceUuid,
        deviceName: device.deviceName,
        batteryPercent: device.batteryPercent,
      );
      _toast('Готово', player == null ? 'Привязка снята' : 'Трекер привязан к игроку');
      await _loadServerData();
    } catch (e) {
      _toast('Привязка', '$e');
    }
  }

  Future<void> _saveSettings(TrackerSpeedSettings settings) async {
    setState(() => _settings = settings);
    try {
      await _api.saveSettings(teamId: widget.teamId, settings: settings);
      _toast('Настройки', 'Пороги скорости сохранены');
      await _loadServerData();
    } catch (e) {
      _toast('Настройки', '$e');
    }
  }


  Future<void> _saveField(TrackerFieldModel field) async {
    try {
      await _api.saveField(
        clubId: widget.clubId,
        teamId: widget.teamId,
        field: field,
      );
      _toast('Поле', 'Калибровка поля сохранена');
      await _loadServerData();
    } catch (e) {
      _toast('Поле', '$e');
    }
  }

  void _toast(String title, String message) {
    if (!mounted) return;
    Get.snackbar(title, message, snackPosition: SnackPosition.BOTTOM, duration: const Duration(seconds: 3));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F5F6),
      body: SafeArea(
        child: Column(
          children: [
            _TrackerMatchTopBar(
            teamName: widget.teamName,
            selectedPlayer: _selectedPlayer,
            players: _players,
            loading: _loadingServer,
            onPlayerChanged: (p) async {
              setState(() => _selectedPlayer = p);
              await _loadServerData();
            },
            onRefresh: _loadServerData,
          ),
          Expanded(
            child: Row(
              children: [
                _TrackerMatchRail(
                  selectedIndex: _tabs.index,
                  onSelect: (index) {
                    setState(() => _tabs.index = index);
                  },
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(8, 8, 10, 8),
                    child: _buildTrackerWorkspaceContent(),
                  ),
                ),
              ],
            ),
          ),
          ],
        ),
      ),
    );
  }

  Widget _buildTrackerWorkspaceContent() {
    final index = _tabs.index;

    if (index == 0) {
      return _ConnectionTab(
        busy: _busy,
        battery: _battery,
        connected: _connected,
        records: _records,
        selectedPlayer: _selectedPlayer,
        devicesStream: _ble.devicesStream,
        logs: _logs,
        onScan: _scan,
        onConnect: _connect,
        onLoadGps: _loadGps,
      );
    }

    if (index == 1) {
      return TrackerLivePanel(
        clubId: widget.clubId,
        teamId: widget.teamId,
        teamName: widget.teamName,
        players: _players,
        selectedPlayer: _selectedPlayer,
        selectedField: _selectedField,
        ble: _ble,
        batteryPercent: _battery == null ? null : (_battery!.voltage * 10).round().clamp(0, 100),
      );
    }

    if (index == 2) {
      return _DashboardTab(
        dashboard: _dashboard,
        onSelectPlayer: (id) {
          final match = _players.where((p) => p.id == id).toList();
          if (match.isNotEmpty) setState(() => _selectedPlayer = match.first);
        },
      );
    }

    if (index == 3) {
      return _SessionsTab(
        sessions: _sessions,
        selectedSession: _selectedSession,
        selectedRecord: _selectedRecord,
        points: _points,
        transferFinished: _transferFinished,
        saving: _saving,
        onSave: _saveSession,
        onSelectSession: (s) async {
          setState(() => _selectedSession = s);
          await _loadServerData();
        },
      );
    }

    if (index == 4) {
      return _HeatmapTab(
        points: _heatPoints,
        selectedPlayer: _selectedPlayer,
        selectedSession: _selectedSession,
        selectedField: _selectedField,
      );
    }

    if (index == 5) {
      return _FieldCalibrationTab(
        fields: _fields,
        selectedField: _selectedField,
        onSelectField: (field) async {
          setState(() => _selectedField = field);
          await _loadServerData();
        },
        onSaveField: _saveField,
        clubId: widget.clubId,
        teamId: widget.teamId,
        latestTrackerPoint: _points.isEmpty ? null : _points.last,
        connectedTrackerName: _connected?.name,
      );
    }

    if (index == 6) {
      return _DevicesTab(
        devices: _savedDevices,
        players: _players,
        onBind: _bindSavedDevice,
      );
    }

    return _SettingsTab(settings: _settings, onSave: _saveSettings);
  }

}




class _TrackerMatchTopBar extends StatelessWidget {
  const _TrackerMatchTopBar({
    required this.teamName,
    required this.selectedPlayer,
    required this.players,
    required this.loading,
    required this.onPlayerChanged,
    required this.onRefresh,
  });

  final String teamName;
  final TrackerPlayerOption? selectedPlayer;
  final List<TrackerPlayerOption> players;
  final bool loading;
  final ValueChanged<TrackerPlayerOption?> onPlayerChanged;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      decoration: const BoxDecoration(
        color: Color(0xFF101214),
        border: Border(bottom: BorderSide(color: Color(0xFF22262B))),
      ),
      padding: const EdgeInsets.only(left: 8, right: 10),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Назад',
            onPressed: () => Navigator.of(context).maybePop(),
            icon: const Icon(Icons.arrow_back_rounded),
            color: Colors.white,
            style: IconButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(.04),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          const SizedBox(width: 8),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.sensors_rounded, color: Color(0xFF101214), size: 20),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Tracker Match Center',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    height: 1.05,
                    letterSpacing: -.2,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  '$teamName · GPS · нагрузка · векторы · тепловая карта',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Roboto',
                    color: Colors.white.withOpacity(.58),
                    fontSize: 10.5,
                    fontWeight: FontWeight.w800,
                    height: 1.05,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 278,
            height: 38,
            child: DropdownButtonFormField<int?>(
              value: selectedPlayer?.id,
              isExpanded: true,
              dropdownColor: Colors.white,
              style: const TextStyle(
                fontFamily: 'Roboto',
                color: Color(0xFF111827),
                fontSize: 12,
                fontWeight: FontWeight.w800,
              ),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.white,
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide.none,
                ),
              ),
              items: [
                const DropdownMenuItem<int?>(value: null, child: Text('Все игроки')),
                ...players.map(
                  (p) => DropdownMenuItem<int?>(
                    value: p.id,
                    child: Text(p.name, overflow: TextOverflow.ellipsis),
                  ),
                ),
              ],
              onChanged: (id) {
                final list = players.where((p) => p.id == id).toList();
                onPlayerChanged(list.isEmpty ? null : list.first);
              },
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 38,
            height: 38,
            child: IconButton(
              tooltip: 'Обновить',
              onPressed: loading ? null : onRefresh,
              padding: EdgeInsets.zero,
              style: IconButton.styleFrom(
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xFF101214),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              icon: loading
                  ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2))
                  : const Icon(Icons.refresh_rounded, size: 21),
            ),
          ),
        ],
      ),
    );
  }
}


class _TrackerMatchRail extends StatelessWidget {
  const _TrackerMatchRail({
    required this.selectedIndex,
    required this.onSelect,
  });

  final int selectedIndex;
  final ValueChanged<int> onSelect;

  static const _items = [
    _TrackerRailItem(Icons.bluetooth_searching_rounded, 'BLE', 'Подкл.'),
    _TrackerRailItem(Icons.radio_button_checked_rounded, 'Live', 'Онлайн'),
    _TrackerRailItem(Icons.query_stats_rounded, 'ТТД', 'Анализ'),
    _TrackerRailItem(Icons.storage_rounded, 'Сессии', 'Записи'),
    _TrackerRailItem(Icons.local_fire_department_rounded, 'Heat', 'Карта'),
    _TrackerRailItem(Icons.map_rounded, 'Поле', 'GPS'),
    _TrackerRailItem(Icons.sensors_rounded, 'Датчики', 'Игроки'),
    _TrackerRailItem(Icons.tune_rounded, 'Настр.', 'Пороги'),
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 72,
      margin: const EdgeInsets.fromLTRB(8, 8, 0, 8),
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFF101214),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(.08)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.12),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 50,
            height: 50,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: selectedIndex == 1 ? Colors.white : const Color(0xFF181B1F),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(.08)),
              boxShadow: selectedIndex == 1
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(.08),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : const [],
            ),
            child: Icon(
              Icons.sports_soccer_rounded,
              color: selectedIndex == 1 ? const Color(0xFF101214) : Colors.white,
              size: 23,
            ),
          ),
          const SizedBox(height: 9),
          Expanded(
            child: ListView.separated(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
              physics: const BouncingScrollPhysics(),
              itemCount: _items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 7),
              itemBuilder: (context, i) {
                final item = _items[i];
                return _TrackerRailButton(
                  item: item,
                  selected: selectedIndex == i,
                  onTap: () => onSelect(i),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackerRailItem {
  const _TrackerRailItem(this.icon, this.title, this.subtitle);
  final IconData icon;
  final String title;
  final String subtitle;
}

class _TrackerRailButton extends StatefulWidget {
  const _TrackerRailButton({
    required this.item,
    required this.selected,
    required this.onTap,
  });

  final _TrackerRailItem item;
  final bool selected;
  final VoidCallback onTap;

  @override
  State<_TrackerRailButton> createState() => _TrackerRailButtonState();
}

class _TrackerRailButtonState extends State<_TrackerRailButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    const rail = Color(0xFF101214);
    const railText = Color(0xFFFFFFFF);
    const railMuted = Color(0xFF9CA3AF);
    const railHover = Color(0xFF181B1F);

    final bgColor = widget.selected
        ? Colors.white
        : _hovered
            ? railHover
            : Colors.transparent;
    final fg = widget.selected ? rail : railText;
    final textColor = widget.selected ? rail : railMuted;

    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: Tooltip(
        message: '${widget.item.title} — ${widget.item.subtitle}',
        waitDuration: const Duration(milliseconds: 250),
        preferBelow: false,
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: widget.onTap,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 8),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: widget.selected
                    ? Colors.white.withOpacity(.62)
                    : _hovered
                        ? Colors.white.withOpacity(.08)
                        : Colors.transparent,
              ),
              boxShadow: widget.selected
                  ? [
                      BoxShadow(
                        color: Colors.black.withOpacity(.08),
                        blurRadius: 14,
                        offset: const Offset(0, 6),
                      ),
                    ]
                  : const [],
            ),
            child: Stack(
              alignment: Alignment.center,
              clipBehavior: Clip.none,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      SizedBox(
                        width: 24,
                        height: 24,
                        child: Center(
                          child: Icon(widget.item.icon, color: fg, size: 21),
                        ),
                      ),
                      const SizedBox(height: 4),
                      SizedBox(
                        width: double.infinity,
                        child: Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 2),
                          child: Text(
                            widget.item.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              fontFamily: 'Roboto',
                              color: textColor,
                              fontSize: 9.05,
                              height: 1.0,
                              fontWeight: widget.selected ? FontWeight.w900 : FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (widget.selected)
                  Positioned(
                    right: 5,
                    top: 5,
                    child: Container(
                      width: 5,
                      height: 5,
                      decoration: const BoxDecoration(
                        color: Color(0xFF00A750),
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class _Header extends StatelessWidget {
  const _Header({
    required this.teamName,
    required this.selectedPlayer,
    required this.players,
    required this.onPlayerChanged,
    required this.onRefresh,
    required this.loading,
  });

  final String teamName;
  final TrackerPlayerOption? selectedPlayer;
  final List<TrackerPlayerOption> players;
  final ValueChanged<TrackerPlayerOption?> onPlayerChanged;
  final VoidCallback onRefresh;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final compact = c.maxWidth < 760;

        final title = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Sportoteka Tracking Center',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: _T.text,
                fontSize: 22,
                fontWeight: FontWeight.w900,
                letterSpacing: -0.35,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              '$teamName · матч-центр GPS · векторы · heatmap · нагрузка',
              maxLines: compact ? 2 : 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                color: _T.muted,
                fontSize: 12.5,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        );

        final playerSelect = SizedBox(
          width: compact ? double.infinity : 270,
          child: DropdownButtonFormField<int?>(
            value: selectedPlayer?.id,
            isExpanded: true,
            decoration: _inputDecoration('Игрок / группа'),
            items: [
              const DropdownMenuItem<int?>(value: null, child: Text('Все игроки')),
              ...players.map(
                (p) => DropdownMenuItem<int?>(
                  value: p.id,
                  child: Text(p.name, overflow: TextOverflow.ellipsis),
                ),
              ),
            ],
            onChanged: (id) {
              final list = players.where((p) => p.id == id).toList();
              onPlayerChanged(list.isEmpty ? null : list.first);
            },
          ),
        );

        final refresh = SizedBox(
          width: compact ? double.infinity : 54,
          height: 54,
          child: IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor: _T.black,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            ),
            onPressed: loading ? null : onRefresh,
            icon: loading
                ? const SizedBox(
                    width: 19,
                    height: 19,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                  )
                : const Icon(Icons.refresh_rounded),
          ),
        );

        final icon = Container(
          width: 62,
          height: 62,
          decoration: BoxDecoration(
            color: _T.greenSoft,
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: _T.green.withOpacity(.16)),
          ),
          child: const Icon(Icons.radar_rounded, color: _T.green, size: 31),
        );

        return Container(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 16),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(28),
            border: Border.all(color: _T.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.04),
                blurRadius: 24,
                offset: const Offset(0, 12),
              ),
            ],
          ),
          child: compact
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(children: [icon, const SizedBox(width: 13), Expanded(child: title)]),
                    const SizedBox(height: 12),
                    playerSelect,
                    const SizedBox(height: 10),
                    refresh,
                    const SizedBox(height: 10),
                    const _TrackerFeatureStrip(compact: true),
                  ],
                )
              : Row(
                  children: [
                    icon,
                    const SizedBox(width: 14),
                    Expanded(child: title),
                    const SizedBox(width: 12),
                    const _TrackerFeatureStrip(compact: false),
                    const SizedBox(width: 12),
                    playerSelect,
                    const SizedBox(width: 10),
                    refresh,
                  ],
                ),
        );
      },
    );
  }
}

class _TrackerFeatureStrip extends StatelessWidget {
  const _TrackerFeatureStrip({required this.compact});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final chips = const [
      _TrackerFeatureChip(icon: Icons.near_me_rounded, text: 'Векторы'),
      _TrackerFeatureChip(icon: Icons.local_fire_department_rounded, text: 'Heat'),
      _TrackerFeatureChip(icon: Icons.speed_rounded, text: 'Скорость'),
    ];

    if (compact) return Wrap(spacing: 8, runSpacing: 8, children: chips);

    return Row(mainAxisSize: MainAxisSize.min, children: [
      for (var i = 0; i < chips.length; i++) ...[
        if (i > 0) const SizedBox(width: 8),
        chips[i],
      ],
    ]);
  }
}

class _TrackerFeatureChip extends StatelessWidget {
  const _TrackerFeatureChip({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: BoxDecoration(
        color: _T.soft,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _T.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: _T.green),
          const SizedBox(width: 6),
          Text(
            text,
            style: const TextStyle(
              color: _T.text,
              fontSize: 11.5,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }
}


class _Tabs extends StatelessWidget {
  const _Tabs({required this.controller});

  final TabController controller;

  @override
  Widget build(BuildContext context) {
    final tabs = const [
      Tab(icon: Icon(Icons.bluetooth_searching_rounded), text: 'Подкл.'),
      Tab(icon: Icon(Icons.radio_button_checked_rounded), text: 'Live'),
      Tab(icon: Icon(Icons.query_stats_rounded), text: 'Аналитика'),
      Tab(icon: Icon(Icons.storage_rounded), text: 'Сессии'),
      Tab(icon: Icon(Icons.local_fire_department_rounded), text: 'Heat'),
      Tab(icon: Icon(Icons.map_rounded), text: 'Поле'),
      Tab(icon: Icon(Icons.sensors_rounded), text: 'Трекеры'),
      Tab(icon: Icon(Icons.tune_rounded), text: 'Настр.'),
    ];

    return Container(
      padding: const EdgeInsets.all(7),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: _T.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.035),
            blurRadius: 22,
            offset: const Offset(0, 12),
          ),
        ],
      ),
      child: TabBar(
        controller: controller,
        isScrollable: true,
        tabAlignment: TabAlignment.start,
        labelColor: Colors.white,
        unselectedLabelColor: _T.text,
        labelStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900),
        unselectedLabelStyle: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w800),
        indicatorSize: TabBarIndicatorSize.tab,
        dividerColor: Colors.transparent,
        indicator: BoxDecoration(
          color: _T.black,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.18),
              blurRadius: 16,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        tabs: tabs,
      ),
    );
  }
}

class _ConnectionTab extends StatelessWidget {
  const _ConnectionTab({
    required this.busy,
    required this.battery,
    required this.connected,
    required this.records,
    required this.selectedPlayer,
    required this.devicesStream,
    required this.logs,
    required this.onScan,
    required this.onConnect,
    required this.onLoadGps,
  });

  final bool busy;
  final ActionTrackerBatteryState? battery;
  final ActionTrackerDevice? connected;
  final List<ActionTrackerRecord> records;
  final TrackerPlayerOption? selectedPlayer;
  final Stream<List<ActionTrackerDevice>> devicesStream;
  final List<String> logs;
  final VoidCallback onScan;
  final ValueChanged<ActionTrackerDevice> onConnect;
  final ValueChanged<ActionTrackerRecord> onLoadGps;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 950;
      final left = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _PanelTitle(icon: Icons.bluetooth_rounded, title: 'Поиск и подключение', subtitle: 'Трекеры с именами \$ACT, \$ATP, \$GPS'),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(child: _InfoPill(icon: Icons.person_rounded, label: selectedPlayer?.name ?? 'Игрок не выбран', color: _T.green)),
          const SizedBox(width: 8),
          Expanded(child: _InfoPill(icon: Icons.battery_charging_full_rounded, label: battery == null ? 'Батарея —' : '${battery!.voltage.toStringAsFixed(2)} В · GPS ${battery!.gpsReady ? 'OK' : '—'}', color: _T.blue)),
        ]),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 46, child: FilledButton.icon(onPressed: busy ? null : onScan, icon: const Icon(Icons.bluetooth_searching_rounded), label: Text(busy ? 'Поиск...' : 'Найти трекер'), style: FilledButton.styleFrom(backgroundColor: _T.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))))),
        const SizedBox(height: 12),
        Expanded(child: StreamBuilder<List<ActionTrackerDevice>>(stream: devicesStream, initialData: const [], builder: (context, snapshot) {
          final devices = snapshot.data ?? const [];
          if (devices.isEmpty) return const _Empty(text: 'Нажмите «Найти трекер». Устройство должно быть включено и рядом.');
          return ListView.separated(itemCount: devices.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
            final d = devices[i];
            final active = connected?.id == d.id;
            return _ActionTile(icon: active ? Icons.bluetooth_connected_rounded : Icons.bluetooth_rounded, title: d.name, subtitle: '${d.id}\nRSSI: ${d.rssi}', active: active, actionText: active ? 'OK' : 'Подкл.', onTap: active || busy ? null : () => onConnect(d));
          });
        })),
      ]));

      final right = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        _PanelTitle(icon: Icons.folder_copy_rounded, title: 'Записи в трекере', subtitle: 'Выберите запись и выгрузите GPS-точки'),
        const SizedBox(height: 12),
        Expanded(child: records.isEmpty ? const _Empty(text: 'После подключения здесь появятся записи из памяти устройства.') : ListView.separated(itemCount: records.length, separatorBuilder: (_, __) => const SizedBox(height: 8), itemBuilder: (_, i) {
          final r = records[i];
          return _ActionTile(icon: Icons.route_rounded, title: 'Запись ${r.fileId}', subtitle: '${r.title} · ${r.length} точек · ${_stateText(r.state)}', actionText: 'GPS', onTap: () => onLoadGps(r));
        })),
        if (logs.isNotEmpty) ExpansionTile(title: const Text('Логи BLE', style: TextStyle(fontWeight: FontWeight.w900)), children: [SizedBox(height: 130, child: ListView.builder(itemCount: logs.length, itemBuilder: (_, i) => Text(logs[i], maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: _T.muted, fontFamily: 'monospace'))))]),
      ]));

      if (!wide) return ListView(padding: const EdgeInsets.all(12), children: [SizedBox(height: 520, child: left), const SizedBox(height: 12), SizedBox(height: 560, child: right)]);
      return Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: left), const SizedBox(width: 12), Expanded(child: right)]));
    });
  }

  static String _stateText(ActionTrackerRecordState state) => switch (state) {
        ActionTrackerRecordState.ready => 'готова',
        ActionTrackerRecordState.recording => 'запись идёт',
        ActionTrackerRecordState.finished => 'завершена',
        ActionTrackerRecordState.unknown => 'неизвестно',
      };
}

class _DashboardTab extends StatelessWidget {
  const _DashboardTab({required this.dashboard, required this.onSelectPlayer});

  final TrackerDashboardModel? dashboard;
  final ValueChanged<int?> onSelectPlayer;

  @override
  Widget build(BuildContext context) {
    final data = dashboard;
    if (data == null) return const Center(child: CircularProgressIndicator());

    return ListView(
      padding: const EdgeInsets.all(12),
      children: [
        _KpiGrid(summary: data.summary),
        const SizedBox(height: 12),
        _Card(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const _PanelTitle(icon: Icons.groups_rounded, title: 'Команда', subtitle: 'Сравнение игроков по нагрузке'),
            const SizedBox(height: 12),
            if (data.players.isEmpty) const _Empty(text: 'Пока нет обработанных сессий') else ...data.players.map((p) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _PlayerLoadRow(player: p, onTap: () => onSelectPlayer(p.playerId)))),
          ]),
        ),
      ],
    );
  }
}

class _SessionsTab extends StatelessWidget {
  const _SessionsTab({required this.sessions, required this.selectedSession, required this.selectedRecord, required this.points, required this.transferFinished, required this.saving, required this.onSave, required this.onSelectSession});

  final List<TrackerSessionModel> sessions;
  final TrackerSessionModel? selectedSession;
  final ActionTrackerRecord? selectedRecord;
  final List<ActionTrackerGpsPoint> points;
  final bool transferFinished;
  final bool saving;
  final VoidCallback onSave;
  final ValueChanged<TrackerSessionModel> onSelectSession;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 1000;
      final left = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _PanelTitle(icon: Icons.cloud_upload_rounded, title: 'Текущая выгрузка', subtitle: 'Проверьте точки и сохраните в базу Sportoteka'),
        const SizedBox(height: 12),
        _InfoPill(icon: transferFinished ? Icons.check_circle_rounded : Icons.timeline_rounded, label: selectedRecord == null ? 'Запись не выбрана' : 'Запись ${selectedRecord!.fileId} · ${points.length} точек ${transferFinished ? '· готово' : ''}', color: transferFinished ? _T.green : _T.blue),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 46, child: FilledButton.icon(onPressed: points.isEmpty || saving ? null : onSave, icon: saving ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_rounded), label: const Text('Сохранить и обработать'), style: FilledButton.styleFrom(backgroundColor: _T.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))))),
        const SizedBox(height: 12),
        Expanded(child: points.isEmpty ? const _Empty(text: 'GPS-точки появятся после выгрузки записи.') : ListView.builder(itemCount: points.length > 160 ? 160 : points.length, itemBuilder: (_, i) { final p=points[i]; return Text('${i+1}. t=${p.timeMs} · ${p.latitude.toStringAsFixed(6)}, ${p.longitude.toStringAsFixed(6)}', style: const TextStyle(fontSize: 12, fontFamily: 'monospace')); })),
      ]));
      final right = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _PanelTitle(icon: Icons.history_rounded, title: 'Сохранённые сессии', subtitle: 'История команды и игроков'),
        const SizedBox(height: 12),
        Expanded(child: sessions.isEmpty ? const _Empty(text: 'Сессий пока нет') : ListView.separated(itemCount: sessions.length, separatorBuilder: (_, __)=>const SizedBox(height: 8), itemBuilder: (_, i) { final s=sessions[i]; return _ActionTile(icon: Icons.route_rounded, title: s.playerName ?? s.title, subtitle: '${(s.distanceM/1000).toStringAsFixed(2)} км · ${s.maxSpeedKmh.toStringAsFixed(1)} км/ч · спринты ${s.sprintCount}', actionText: 'Карта', active: selectedSession?.id == s.id, onTap: () => onSelectSession(s)); })),
      ]));
      if (!wide) return ListView(padding: const EdgeInsets.all(12), children: [SizedBox(height: 520, child: left), const SizedBox(height: 12), SizedBox(height: 520, child: right)]);
      return Padding(padding: const EdgeInsets.all(12), child: Row(children: [Expanded(child: left), const SizedBox(width: 12), Expanded(child: right)]));
    });
  }
}

class _HeatmapTab extends StatelessWidget {
  const _HeatmapTab({required this.points, required this.selectedPlayer, required this.selectedSession, required this.selectedField});

  final List<TrackerHeatPoint> points;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerSessionModel? selectedSession;
  final TrackerFieldModel? selectedField;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: _Card(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _PanelTitle(icon: Icons.local_fire_department_rounded, title: 'Тепловая карта', subtitle: selectedField == null ? 'По GPS-точкам без калибровки поля' : '${selectedField!.title} · координаты x/y на поле'),
          const SizedBox(height: 12),
          Expanded(
            child: points.isEmpty
                ? const _Empty(text: 'Нет точек для тепловой карты. Сохраните и обработайте GPS-сессию.')
                : ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: CustomPaint(
                      painter: TrackerHeatmapPainter(points: points),
                      child: Container(color: const Color(0xFF0E7A3D).withOpacity(.08)),
                    ),
                  ),
          ),
          const SizedBox(height: 10),
          Text(selectedField == null ? 'Карта нормализована по границам GPS-точек. Для точной карты добавьте калибровку поля.' : 'Точки переведены из широты/долготы в координаты поля: x — длина, y — ширина.', style: TextStyle(color: _T.muted, fontSize: 12, fontWeight: FontWeight.w700)),
        ]),
      ),
    );
  }
}



class _FieldCalibrationTab extends StatefulWidget {
  const _FieldCalibrationTab({
    required this.fields,
    required this.selectedField,
    required this.onSelectField,
    required this.onSaveField,
    required this.clubId,
    required this.teamId,
    required this.latestTrackerPoint,
    required this.connectedTrackerName,
  });

  final List<TrackerFieldModel> fields;
  final TrackerFieldModel? selectedField;
  final Future<void> Function(TrackerFieldModel? field) onSelectField;
  final Future<void> Function(TrackerFieldModel field) onSaveField;
  final int clubId;
  final int teamId;
  final ActionTrackerGpsPoint? latestTrackerPoint;
  final String? connectedTrackerName;

  @override
  State<_FieldCalibrationTab> createState() => _FieldCalibrationTabState();
}

class _FieldCalibrationTabState extends State<_FieldCalibrationTab> {
  late final TextEditingController title;
  late final TextEditingController length;
  late final TextEditingController width;
  late final TextEditingController aLat;
  late final TextEditingController aLng;
  late final TextEditingController bLat;
  late final TextEditingController bLng;
  late final TextEditingController cLat;
  late final TextEditingController cLng;
  late final TextEditingController dLat;
  late final TextEditingController dLng;

  bool isDefault = true;
  int? editingId;
  String? _activeCorner = 'A';
  bool _capturing = false;

  @override
  void initState() {
    super.initState();
    title = TextEditingController();
    length = TextEditingController();
    width = TextEditingController();
    aLat = TextEditingController();
    aLng = TextEditingController();
    bLat = TextEditingController();
    bLng = TextEditingController();
    cLat = TextEditingController();
    cLng = TextEditingController();
    dLat = TextEditingController();
    dLng = TextEditingController();
    _fill(widget.selectedField);
  }

  @override
  void didUpdateWidget(covariant _FieldCalibrationTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedField?.id != widget.selectedField?.id) {
      _fill(widget.selectedField);
    }
  }

  @override
  void dispose() {
    for (final c in [title, length, width, aLat, aLng, bLat, bLng, cLat, cLng, dLat, dLng]) {
      c.dispose();
    }
    super.dispose();
  }

  void _fill(TrackerFieldModel? f) {
    editingId = f?.id;
    title.text = f?.title ?? 'Основное поле';
    length.text = (f?.lengthM ?? 105).toStringAsFixed(0);
    width.text = (f?.widthM ?? 68).toStringAsFixed(0);
    aLat.text = _s(f?.cornerALat);
    aLng.text = _s(f?.cornerALng);
    bLat.text = _s(f?.cornerBLat);
    bLng.text = _s(f?.cornerBLng);
    cLat.text = _s(f?.cornerCLat);
    cLng.text = _s(f?.cornerCLng);
    dLat.text = _s(f?.cornerDLat);
    dLng.text = _s(f?.cornerDLng);
    isDefault = f?.isDefault ?? true;
  }

  String _s(double? v) => v == null ? '' : v.toStringAsFixed(8);
  double _d(TextEditingController c, double fallback) => double.tryParse(c.text.trim().replaceAll(',', '.')) ?? fallback;
  double? _dn(TextEditingController c) {
    final text = c.text.trim().replaceAll(',', '.');
    if (text.isEmpty) return null;
    return double.tryParse(text);
  }

  Future<void> _save() async {
    final field = TrackerFieldModel(
      id: editingId,
      clubId: widget.clubId,
      teamId: widget.teamId,
      title: title.text.trim().isEmpty ? 'Поле' : title.text.trim(),
      lengthM: _d(length, 105),
      widthM: _d(width, 68),
      cornerALat: _dn(aLat),
      cornerALng: _dn(aLng),
      cornerBLat: _dn(bLat),
      cornerBLng: _dn(bLng),
      cornerCLat: _dn(cLat),
      cornerCLng: _dn(cLng),
      cornerDLat: _dn(dLat),
      cornerDLng: _dn(dLng),
      isDefault: isDefault,
    );
    await widget.onSaveField(field);
  }

  void _newField() {
    setState(() {
      editingId = null;
      title.text = 'Новое поле';
      length.text = '105';
      width.text = '68';
      for (final c in [aLat, aLng, bLat, bLng, cLat, cLng, dLat, dLng]) {
        c.clear();
      }
      isDefault = widget.fields.isEmpty;
      _activeCorner = 'A';
    });
  }

  Future<void> _capturePhonePoint() async {
    final corner = _activeCorner;
    if (corner == null) {
      _toast('Сначала выберите угол A, B, C или D');
      return;
    }

    setState(() => _capturing = true);
    try {
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        throw Exception('Нет разрешения на геолокацию');
      }

      final enabled = await Geolocator.isLocationServiceEnabled();
      if (!enabled) {
        throw Exception('Геолокация выключена на устройстве');
      }

      final position = await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.bestForNavigation,
        timeLimit: const Duration(seconds: 20),
      );

      _setCorner(corner, position.latitude, position.longitude);
      _toast('Точка $corner зафиксирована по телефону');
    } catch (e) {
      _toast('$e');
    } finally {
      if (mounted) setState(() => _capturing = false);
    }
  }

  void _captureTrackerPoint() {
    final corner = _activeCorner;
    final p = widget.latestTrackerPoint;
    if (corner == null) {
      _toast('Сначала выберите угол A, B, C или D');
      return;
    }
    if (p == null) {
      _toast('Нет последней GPS-точки трекера. Сначала выгрузите короткую запись или GPS-данные.');
      return;
    }
    _setCorner(corner, p.latitude, p.longitude);
    _toast('Точка $corner зафиксирована по последней точке трекера');
  }

  void _setCorner(String corner, double lat, double lng) {
    setState(() {
      switch (corner) {
        case 'A':
          aLat.text = lat.toStringAsFixed(8);
          aLng.text = lng.toStringAsFixed(8);
          _activeCorner = 'B';
          break;
        case 'B':
          bLat.text = lat.toStringAsFixed(8);
          bLng.text = lng.toStringAsFixed(8);
          _activeCorner = 'C';
          break;
        case 'C':
          cLat.text = lat.toStringAsFixed(8);
          cLng.text = lng.toStringAsFixed(8);
          _activeCorner = 'D';
          break;
        case 'D':
          dLat.text = lat.toStringAsFixed(8);
          dLng.text = lng.toStringAsFixed(8);
          _activeCorner = 'A';
          break;
      }
    });
  }

  void _toast(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  TrackerFieldModel get _draftField => TrackerFieldModel(
        id: editingId,
        clubId: widget.clubId,
        teamId: widget.teamId,
        title: title.text.trim().isEmpty ? 'Поле' : title.text.trim(),
        lengthM: _d(length, 105),
        widthM: _d(width, 68),
        cornerALat: _dn(aLat),
        cornerALng: _dn(aLng),
        cornerBLat: _dn(bLat),
        cornerBLng: _dn(bLng),
        cornerCLat: _dn(cLat),
        cornerCLng: _dn(cLng),
        cornerDLat: _dn(dLat),
        cornerDLng: _dn(dLng),
        isDefault: isDefault,
      );

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final wide = c.maxWidth >= 980;
      final list = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _PanelTitle(icon: Icons.map_rounded, title: 'Поля команды', subtitle: 'Одно поле используется для всех трекеров команды'),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 44, child: OutlinedButton.icon(onPressed: _newField, icon: const Icon(Icons.add_rounded), label: const Text('Новое поле'))),
        const SizedBox(height: 12),
        Expanded(child: widget.fields.isEmpty ? const _Empty(text: 'Добавьте поле и зафиксируйте 4 угла: A, B, C, D.') : ListView.separated(
          itemCount: widget.fields.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (_, i) {
            final f = widget.fields[i];
            final active = widget.selectedField?.id == f.id;
            return _ActionTile(
              icon: f.hasCalibration ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
              title: f.title,
              subtitle: '${f.lengthM.toStringAsFixed(0)} × ${f.widthM.toStringAsFixed(0)} м · ${f.hasCalibration ? 'координаты готовы' : 'нужны углы'}',
              actionText: active ? 'OK' : 'Выбрать',
              active: active,
              onTap: () async {
                await widget.onSelectField(f);
                if (mounted) setState(() => _fill(f));
              },
            );
          },
        )),
      ]));

      final form = _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _PanelTitle(icon: Icons.add_location_alt_rounded, title: 'Калибровка по точкам', subtitle: 'Подойдите к углу поля, выберите A/B/C/D и нажмите «Зафиксировать»'),
        const SizedBox(height: 12),
        Expanded(child: ListView(children: [
          TextField(controller: title, decoration: _inputDecoration('Название поля')),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: _num(length, 'Длина, м')), const SizedBox(width: 10), Expanded(child: _num(width, 'Ширина, м'))]),
          const SizedBox(height: 12),
          SizedBox(
            height: 230,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(24),
              child: CustomPaint(
                painter: TrackerFieldPainter(field: _draftField, activeCorner: _activeCorner),
                child: Container(color: const Color(0xFF0D7A3C)),
              ),
            ),
          ),
          const SizedBox(height: 12),
          _cornerSelector(),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: FilledButton.icon(
                onPressed: _capturing ? null : _capturePhonePoint,
                icon: _capturing ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.my_location_rounded),
                label: const Text('Зафиксировать телефоном'),
                style: FilledButton.styleFrom(backgroundColor: _T.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: OutlinedButton.icon(
                onPressed: _captureTrackerPoint,
                icon: const Icon(Icons.sensors_rounded),
                label: Text(widget.connectedTrackerName == null ? 'По точке трекера' : 'По ${widget.connectedTrackerName}'),
                style: OutlinedButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))),
              ),
            ),
          ]),
          const SizedBox(height: 14),
          _cornerRow('A · левый нижний', aLat, aLng),
          _cornerRow('B · правый нижний', bLat, bLng),
          _cornerRow('C · правый верхний', cLat, cLng),
          _cornerRow('D · левый верхний', dLat, dLng),
          const SizedBox(height: 8),
          SwitchListTile.adaptive(
            value: isDefault,
            onChanged: (v) => setState(() => isDefault = v),
            contentPadding: EdgeInsets.zero,
            title: const Text('Использовать по умолчанию для команды', style: TextStyle(fontWeight: FontWeight.w800)),
          ),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, height: 46, child: FilledButton.icon(onPressed: _save, icon: const Icon(Icons.save_rounded), label: const Text('Сохранить поле'), style: FilledButton.styleFrom(backgroundColor: _T.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))))),
          const SizedBox(height: 10),
          const Text('Это поле будет применяться ко всем трекерам команды. После сохранения новые сессии автоматически получат координаты x/y на поле.', style: TextStyle(color: _T.muted, fontSize: 12, fontWeight: FontWeight.w700, height: 1.3)),
        ])),
      ]));

      if (!wide) return ListView(padding: const EdgeInsets.all(12), children: [SizedBox(height: 430, child: list), const SizedBox(height: 12), SizedBox(height: 960, child: form)]);
      return Padding(padding: const EdgeInsets.all(12), child: Row(children: [SizedBox(width: 370, child: list), const SizedBox(width: 12), Expanded(child: form)]));
    });
  }

  Widget _cornerSelector() {
    final items = <Map<String, String>>[
      {'key': 'A', 'label': 'левый нижний'},
      {'key': 'B', 'label': 'правый нижний'},
      {'key': 'C', 'label': 'правый верхний'},
      {'key': 'D', 'label': 'левый верхний'},
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final item in items)
          ChoiceChip(
            selected: _activeCorner == item['key'],
            label: Text('${item['key']} · ${item['label']}'),
            onSelected: (_) => setState(() => _activeCorner = item['key']),
            selectedColor: _T.greenSoft,
            labelStyle: TextStyle(
              color: _activeCorner == item['key'] ? _T.green : _T.text,
              fontWeight: FontWeight.w900,
            ),
          ),
      ],
    );
  }

  Widget _num(TextEditingController controller, String label) => TextField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: _inputDecoration(label),
      );

  Widget _cornerRow(String label, TextEditingController lat, TextEditingController lng) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: _T.text, fontSize: 12.5, fontWeight: FontWeight.w900)),
        const SizedBox(height: 6),
        Row(children: [Expanded(child: _num(lat, 'Широта')), const SizedBox(width: 10), Expanded(child: _num(lng, 'Долгота'))]),
      ]),
    );
  }
}

class _DevicesTab extends StatelessWidget {
  const _DevicesTab({required this.devices, required this.players, required this.onBind});

  final List<TrackerDeviceModel> devices;
  final List<TrackerPlayerOption> players;
  final Future<void> Function(TrackerDeviceModel device, TrackerPlayerOption? player) onBind;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: _Card(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const _PanelTitle(icon: Icons.sensors_rounded, title: 'Трекеры команды', subtitle: 'Привязка устройства к игроку и смена владельца'),
          const SizedBox(height: 12),
          Expanded(child: devices.isEmpty ? const _Empty(text: 'Подключите трекер: он появится здесь для привязки к игроку.') : ListView.separated(itemCount: devices.length, separatorBuilder: (_, __)=>const SizedBox(height: 8), itemBuilder: (_, i) {
            final d = devices[i];
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: _T.soft, borderRadius: BorderRadius.circular(18), border: Border.all(color: _T.border)),
              child: Row(children: [
                const CircleAvatar(backgroundColor: _T.greenSoft, child: Icon(Icons.sensors_rounded, color: _T.green)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(d.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.text, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 3),
                  Text('${d.deviceUuid}\nИгрок: ${d.playerName ?? 'не назначен'}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.muted, fontSize: 11.5, fontWeight: FontWeight.w700)),
                ])),
                const SizedBox(width: 8),
                SizedBox(width: 230, child: DropdownButtonFormField<int?>(
                  value: d.playerId,
                  isExpanded: true,
                  decoration: _inputDecoration('Назначить'),
                  items: [const DropdownMenuItem<int?>(value: null, child: Text('Не назначен')), ...players.map((p)=>DropdownMenuItem<int?>(value: p.id, child: Text(p.name, overflow: TextOverflow.ellipsis)))],
                  onChanged: (id) {
                    final list = players.where((p)=>p.id==id).toList();
                    onBind(d, list.isEmpty ? null : list.first);
                  },
                )),
              ]),
            );
          })),
        ]),
      ),
    );
  }
}

class _SettingsTab extends StatefulWidget {
  const _SettingsTab({required this.settings, required this.onSave});

  final TrackerSpeedSettings settings;
  final ValueChanged<TrackerSpeedSettings> onSave;

  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  late TrackerSpeedSettings s;

  @override
  void initState() {
    super.initState();
    s = widget.settings;
  }

  @override
  void didUpdateWidget(covariant _SettingsTab oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.settings != widget.settings) s = widget.settings;
  }

  void _applyPreset(String preset) {
    setState(() {
      if (preset == 'professional') {
        s = const TrackerSpeedSettings(preset: 'professional', jogRuleMps: 2.0, mediumRuleMps: 4.0, highRuleMps: 5.5, sprintRuleMps: 7.0, sprintTimeSec: 2.0, accelerationRuleMps2: 0.3);
      } else if (preset == 'amateur') {
        s = const TrackerSpeedSettings(preset: 'amateur', jogRuleMps: 1.5, mediumRuleMps: 3.3, highRuleMps: 5.0, sprintRuleMps: 6.0, sprintTimeSec: 2.0, accelerationRuleMps2: 0.3);
      } else {
        s = const TrackerSpeedSettings(preset: 'youth', jogRuleMps: 1.2, mediumRuleMps: 3.0, highRuleMps: 4.6, sprintRuleMps: 5.5, sprintTimeSec: 2.0, accelerationRuleMps2: 0.3);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(12), children: [
      _Card(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const _PanelTitle(icon: Icons.tune_rounded, title: 'Настройки трекера', subtitle: 'Пороги скорости и правила спринтов'),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          value: s.preset,
          decoration: _inputDecoration('Профиль'),
          items: const [
            DropdownMenuItem(value: 'youth', child: Text('Юношеский')),
            DropdownMenuItem(value: 'amateur', child: Text('Любительский')),
            DropdownMenuItem(value: 'professional', child: Text('Профессиональный')),
          ],
          onChanged: (v) => _applyPreset(v ?? 'youth'),
        ),
        const SizedBox(height: 16),
        _SliderLine(label: 'Бег трусцой', value: s.jogRuleMps, min: 0.5, max: 3.5, onChanged: (v)=>setState(()=>s=s.copyWith(jogRuleMps: v))),
        _SliderLine(label: 'Средний бег', value: s.mediumRuleMps, min: 1.5, max: 5.5, onChanged: (v)=>setState(()=>s=s.copyWith(mediumRuleMps: v))),
        _SliderLine(label: 'Высокая скорость', value: s.highRuleMps, min: 3.0, max: 8.0, onChanged: (v)=>setState(()=>s=s.copyWith(highRuleMps: v))),
        _SliderLine(label: 'Спринт', value: s.sprintRuleMps, min: 4.0, max: 9.5, onChanged: (v)=>setState(()=>s=s.copyWith(sprintRuleMps: v))),
        _SliderLine(label: 'Время спринта', value: s.sprintTimeSec, min: 0.5, max: 5.0, suffix: 'сек', onChanged: (v)=>setState(()=>s=s.copyWith(sprintTimeSec: v))),
        _SliderLine(label: 'Порог ускорения', value: s.accelerationRuleMps2, min: 0.1, max: 2.0, suffix: 'м/с²', onChanged: (v)=>setState(()=>s=s.copyWith(accelerationRuleMps2: v))),
        const SizedBox(height: 12),
        SwitchListTile(
          value: s.isSprintTraceMode,
          onChanged: (v)=>setState(()=>s=s.copyWith(isSprintTraceMode: v)),
          title: const Text('Режим траектории спринтов', style: TextStyle(fontWeight: FontWeight.w900)),
          subtitle: const Text('Использовать отдельный анализ спринтов и рывков'),
        ),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, height: 48, child: FilledButton.icon(onPressed: () => widget.onSave(s), icon: const Icon(Icons.save_rounded), label: const Text('Сохранить настройки'), style: FilledButton.styleFrom(backgroundColor: _T.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15))))),
      ])),
    ]);
  }
}

class _SliderLine extends StatelessWidget {
  const _SliderLine({required this.label, required this.value, required this.min, required this.max, required this.onChanged, this.suffix = 'м/с'});

  final String label;
  final double value;
  final double min;
  final double max;
  final ValueChanged<double> onChanged;
  final String suffix;

  @override
  Widget build(BuildContext context) {
    return Padding(padding: const EdgeInsets.only(bottom: 10), child: Column(children: [
      Row(children: [Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900))), Text('${value.toStringAsFixed(2)} $suffix', style: const TextStyle(color: _T.green, fontWeight: FontWeight.w900))]),
      Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, divisions: 50, onChanged: onChanged),
    ]));
  }
}

class _KpiGrid extends StatelessWidget {
  const _KpiGrid({required this.summary});
  final Map<String, dynamic> summary;
  @override
  Widget build(BuildContext context) {
    final items = [
      ['Игроки', '${_i(summary['players_count'])}', Icons.groups_rounded],
      ['Сессии', '${_i(summary['sessions_count'])}', Icons.event_available_rounded],
      ['Дистанция', '${(_d(summary['total_distance_m']) / 1000).toStringAsFixed(1)} км', Icons.route_rounded],
      ['Нагрузка', _d(summary['avg_load_score']).toStringAsFixed(0), Icons.bolt_rounded],
      ['Макс. скорость', '${_d(summary['max_speed_kmh']).toStringAsFixed(1)} км/ч', Icons.speed_rounded],
      ['Спринты', '${_i(summary['sprint_count'])}', Icons.flash_on_rounded],
    ];
    return LayoutBuilder(builder: (_, c) {
      final cols = c.maxWidth >= 1150 ? 6 : c.maxWidth >= 760 ? 3 : 2;
      return GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: items.length, gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: cols, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 2.55), itemBuilder: (_, i) => _KpiCard(title: items[i][0] as String, value: items[i][1] as String, icon: items[i][2] as IconData));
    });
  }
  static int _i(dynamic v) => int.tryParse('$v') ?? (v is num ? v.toInt() : 0);
  static double _d(dynamic v) => double.tryParse('$v') ?? (v is num ? v.toDouble() : 0);
}

class _PlayerLoadRow extends StatelessWidget {
  const _PlayerLoadRow({required this.player, required this.onTap});
  final TrackerPlayerLoadRow player;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) {
    final level = player.loadScore >= 120 ? _T.red : player.loadScore >= 80 ? _T.orange : _T.green;
    return _ActionTile(icon: Icons.person_rounded, title: player.playerName, subtitle: '${(player.distanceM/1000).toStringAsFixed(1)} км · ${player.maxSpeedKmh.toStringAsFixed(1)} км/ч · спринты ${player.sprintCount}', actionText: player.loadScore.toStringAsFixed(0), actionColor: level, onTap: onTap);
  }
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({required this.title, required this.value, required this.icon});
  final String title;
  final String value;
  final IconData icon;
  @override
  Widget build(BuildContext context) => _Card(padding: const EdgeInsets.all(12), child: Row(children: [Container(width: 38, height: 38, decoration: BoxDecoration(color: _T.greenSoft, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: _T.green, size: 20)), const SizedBox(width: 10), Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.muted, fontSize: 11, fontWeight: FontWeight.w700)), Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.text, fontSize: 17, fontWeight: FontWeight.w900))]))]));
}

class _ActionTile extends StatelessWidget {
  const _ActionTile({required this.icon, required this.title, required this.subtitle, required this.actionText, this.actionColor = _T.green, this.active = false, this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final String actionText;
  final Color actionColor;
  final bool active;
  final VoidCallback? onTap;
  @override
  Widget build(BuildContext context) => Material(color: Colors.transparent, borderRadius: BorderRadius.circular(18), child: InkWell(onTap: onTap, borderRadius: BorderRadius.circular(18), child: Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: active ? _T.greenSoft : _T.soft, borderRadius: BorderRadius.circular(18), border: Border.all(color: active ? _T.green.withOpacity(.35) : _T.border)), child: Row(children: [CircleAvatar(radius: 19, backgroundColor: Colors.white, child: Icon(icon, color: active ? _T.green : _T.muted, size: 20)), const SizedBox(width: 11), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.text, fontSize: 13.5, fontWeight: FontWeight.w900)), const SizedBox(height: 3), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.muted, fontSize: 11.2, fontWeight: FontWeight.w700, height: 1.25))])), const SizedBox(width: 8), Text(actionText, style: TextStyle(color: actionColor, fontWeight: FontWeight.w900))]))));
}

class _InfoPill extends StatelessWidget {
  const _InfoPill({required this.icon, required this.label, required this.color});
  final IconData icon;
  final String label;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10), decoration: BoxDecoration(color: color.withOpacity(.09), borderRadius: BorderRadius.circular(16), border: Border.all(color: color.withOpacity(.15))), child: Row(children: [Icon(icon, color: color, size: 18), const SizedBox(width: 7), Expanded(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)))]));
}

class _PanelTitle extends StatelessWidget {
  const _PanelTitle({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;
  @override
  Widget build(BuildContext context) => Row(children: [Container(width: 40, height: 40, decoration: BoxDecoration(color: _T.greenSoft, borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: _T.green)), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.text, fontSize: 17, fontWeight: FontWeight.w900)), const SizedBox(height: 2), Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _T.muted, fontSize: 11.5, fontWeight: FontWeight.w700))]))]);
}

class _Card extends StatelessWidget {
  const _Card({required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsetsGeometry padding;
  @override
  Widget build(BuildContext context) => Container(padding: padding, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), border: Border.all(color: _T.border), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 22, offset: const Offset(0, 12))]), child: child);
}

class _Empty extends StatelessWidget {
  const _Empty({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(18), child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _T.muted, fontWeight: FontWeight.w700, height: 1.35))));
}

InputDecoration _inputDecoration(String label) => InputDecoration(labelText: label, filled: true, fillColor: _T.soft, isDense: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none));

class _T {
  static const Color bg = Color(0xFFF4F5F6);
  static const Color soft = Color(0xFFF8F9FA);
  static const Color border = Color(0xFFE5E7EB);
  static const Color text = Color(0xFF111827);
  static const Color muted = Color(0xFF475467);
  static const Color black = Color(0xFF101214);
  static const Color green = Color(0xFF00A750);
  static const Color greenSoft = Color(0xFFF3FBF6);
  static const Color blue = Color(0xFF344054);
  static const Color orange = Color(0xFFB7791F);
  static const Color red = Color(0xFFD92D20);
}
