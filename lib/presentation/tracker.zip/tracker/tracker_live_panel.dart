
import 'dart:async';
import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import 'models/action_tracker_protocol.dart';
import 'models/tracker_live_models.dart';
import 'models/tracker_pro_models.dart';
import 'services/action_tracker_ble_service.dart';
import 'services/tracker_live_api.dart';

enum TrackerLiveSourceMode {
  trackerExperimental,
  phoneGps,
}

class TrackerLivePanel extends StatefulWidget {
  const TrackerLivePanel({
    super.key,
    required this.clubId,
    required this.teamId,
    required this.teamName,
    required this.players,
    required this.selectedPlayer,
    required this.selectedField,
    required this.ble,
    this.batteryPercent,
  });

  final int clubId;
  final int teamId;
  final String teamName;
  final List<TrackerPlayerOption> players;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final ActionTrackerBleService ble;
  final int? batteryPercent;

  @override
  State<TrackerLivePanel> createState() => _TrackerLivePanelState();
}

class _TrackerLivePanelState extends State<TrackerLivePanel>
    with AutomaticKeepAliveClientMixin {
  final TrackerLiveApi _api = TrackerLiveApi();

  final List<String> _logs = <String>[];
  final Map<String, _RuntimeTrack> _tracks = <String, _RuntimeTrack>{};
  List<TrackerLiveSessionModel> _sessions = <TrackerLiveSessionModel>[];

  Timer? _pollTimer;
  Timer? _phoneTimer;
  Timer? _trackerTimer;
  Timer? _heartbeatTimer;
  StreamSubscription<ActionTrackerParseResult>? _bleSub;

  int? _myLiveSessionId;
  TrackerLiveSourceMode _mode = TrackerLiveSourceMode.trackerExperimental;
  int _candidateCommandIndex = 0;

  bool _starting = false;
  bool _savingPoint = false;
  bool _running = false;
  bool _testingCommands = false;
  bool _showDebug = true;

  bool _showVectors = true;
  bool _showHeatmap = true;
  bool _showTrace = true;
  bool _showLabels = true;

  String _lastRx = 'нет пакетов';
  String _lastTx = 'нет команд';
  String _lastGps = 'нет GPS';
  String _lastSave = 'нет сохранения';
  String _lastProblem = 'Ожидание старта Live';
  DateTime? _lastGpsAt;
  DateTime? _lastSaveAt;

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _listenBle();
    _startPolling();
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _phoneTimer?.cancel();
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();
    _bleSub?.cancel();
    super.dispose();
  }

  @override
  void didUpdateWidget(covariant TrackerLivePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedField?.id != widget.selectedField?.id) {
      _loadLiveState();
      _log('Изменено поле: ${widget.selectedField?.title ?? 'нет поля'}');
    }
  }

  void _listenBle() {
    _bleSub = widget.ble.dataStream.listen((event) async {
      final typeHex = '0x${event.packetType.toRadixString(16).toUpperCase()}';
      _lastRx = '${event.rawHex} · $typeHex';

      if (_mode == TrackerLiveSourceMode.trackerExperimental) {
        _log('RX $_lastRx');
      }

      if (!_running || _mode != TrackerLiveSourceMode.trackerExperimental) {
        if (mounted) setState(() {});
        return;
      }

      if (event.battery != null) {
        _log(
          'Батарея/GPS: ${event.battery!.voltage.toStringAsFixed(2)} В · '
          'GPS ${event.battery!.gpsReady ? 'готов' : 'не готов'} · это не координата',
        );
      }

      final chunk = event.gpsChunk;
      if (chunk == null || chunk.points.isEmpty) {
        final zeroGps = event.rawHex.contains('3B 00 00 00 00 00 00 00 00') ||
            event.rawHex.contains('44 00 00 00 00 00 00 00');
        _lastProblem = zeroGps
            ? 'Трекер отвечает нулевой GPS-точкой 0,0. Это не ошибка UI: нет актуальной координаты. Выйдите на улицу, дождитесь спутников или включите запись на трекере.'
            : 'Пакет $typeHex получен, но координат в нём нет';
        _lastGps = zeroGps ? '0.000000, 0.000000 · $typeHex · нет фиксации' : _lastGps;
        if (mounted) setState(() {});
        return;
      }

      final point = chunk.points.last;
      final nowMs = DateTime.now().millisecondsSinceEpoch;

      _lastGpsAt = DateTime.now();
      _lastGps =
          '${point.latitude.toStringAsFixed(6)}, ${point.longitude.toStringAsFixed(6)} · $typeHex';

      _log('GPS трекера: $_lastGps');

      await _handleGpsPoint(
        latitude: point.latitude,
        longitude: point.longitude,
        timeMs: nowMs,
        packetType: typeHex,
        rawHex: event.rawHex,
      );
    });
  }

  void _startPolling() {
    _log('Live открыт. Команда Live GPS: 3A → ответ 3B/44.');
    _loadLiveState();
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => _loadLiveState(),
    );
  }

  Future<void> _loadLiveState() async {
    try {
      final data = await _api.loadTeamLiveState(
        teamId: widget.teamId,
        fieldId: widget.selectedField?.id,
      );
      if (!mounted) return;
      setState(() => _sessions = data);
    } catch (e) {
      _lastProblem = 'Ошибка загрузки Live: $e';
      _log(_lastProblem);
    }
  }

  Future<void> _startLive() async {
    final field = widget.selectedField;
    if (field == null || !field.hasCalibration) {
      _toast('Сначала выберите и откалибруйте поле');
      _lastProblem = 'Нет калибровки поля';
      setState(() {});
      return;
    }

    final device = widget.ble.connectedInfo;
    if (_mode == TrackerLiveSourceMode.trackerExperimental && device == null) {
      _toast('Сначала подключите BLE-трекер во вкладке «Подключение»');
      _lastProblem = 'Трекер не подключён';
      setState(() {});
      return;
    }

    final deviceUuid = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-GPS-${widget.teamId}-${widget.selectedPlayer?.id ?? 0}'
        : device!.id;

    final deviceName = _mode == TrackerLiveSourceMode.phoneGps
        ? 'Телефон GPS'
        : device!.name;

    setState(() {
      _starting = true;
      _lastProblem = 'Старт Live...';
    });

    try {
      final id = await _api.startLiveSession(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: widget.selectedPlayer?.id,
        fieldId: field.id,
        deviceUuid: deviceUuid,
        deviceName: deviceName,
        source: _mode == TrackerLiveSourceMode.phoneGps ? 'phone' : 'tracker',
        batteryPercent: widget.batteryPercent,
      );

      if (id <= 0) throw Exception('сервер не вернул live_session_id');

      if (_mode == TrackerLiveSourceMode.phoneGps) {
        final serviceEnabled = await Geolocator.isLocationServiceEnabled();
        if (!serviceEnabled) throw Exception('геолокация выключена');

        var permission = await Geolocator.checkPermission();
        if (permission == LocationPermission.denied) {
          permission = await Geolocator.requestPermission();
        }
        if (permission == LocationPermission.denied ||
            permission == LocationPermission.deniedForever) {
          throw Exception('нет разрешения на геолокацию');
        }
      }

      _myLiveSessionId = id;
      _running = true;
      _lastProblem = 'Live активен';

      _trackForCurrentDevice();

      if (_mode == TrackerLiveSourceMode.phoneGps) {
        _startPhoneGpsLoop();
      } else {
        _startTrackerLoop();
      }

      _log('Live стартовал: session=$id');
      _serverLog('Live стартовал: session=$id', source: 'live_start');
      await _loadLiveState();
    } catch (e) {
      _lastProblem = 'Ошибка старта Live: $e';
      _log(_lastProblem);
      _toast('Live: $e');
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  void _startPhoneGpsLoop() {
    _phoneTimer?.cancel();

    Future<void> tick() async {
      if (!_running || _savingPoint) return;

      try {
        final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.bestForNavigation,
        );

        await _handleGpsPoint(
          latitude: pos.latitude,
          longitude: pos.longitude,
          timeMs: DateTime.now().millisecondsSinceEpoch,
          packetType: 'PHONE',
          rawHex: null,
        );
      } catch (e) {
        _lastProblem = 'GPS телефона: $e';
        _log(_lastProblem);
      }
    }

    tick();
    _phoneTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());
  }

  void _startTrackerLoop() {
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();

    Future<void> tick() async {
      if (!_running) return;

      final command =
          ActionTrackerBleProfile.commandCurrentGpsCandidates[_candidateCommandIndex];
      final cmd = command
          .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
          .join(' ');

      try {
        _lastTx = cmd;
        _log('TX current GPS кандидат ${_candidateCommandIndex + 1}: $cmd');
        await widget.ble.sendRawCommand(command);
      } catch (e) {
        _lastProblem = 'TX GPS: $e';
        _log(_lastProblem);
      }
    }

    tick();
    _trackerTimer = Timer.periodic(const Duration(seconds: 1), (_) => tick());

    _heartbeatTimer = Timer.periodic(const Duration(seconds: 5), (_) async {
      final id = _myLiveSessionId;
      if (!_running || id == null) return;
      try {
        await _api.heartbeatLiveSession(liveSessionId: id);
        await _loadLiveState();
      } catch (e) {
        _log('Heartbeat: $e');
      }
    });
  }

  Future<void> _handleGpsPoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
    String? rawHex,
  }) async {
    final track = _trackForCurrentDevice();
    final stat = track.addPoint(
      latitude: latitude,
      longitude: longitude,
      timeMs: DateTime.now().millisecondsSinceEpoch,
      packetType: packetType,
    );

    _lastGpsAt = DateTime.now();
    _lastGps =
        '${latitude.toStringAsFixed(6)}, ${longitude.toStringAsFixed(6)} · $packetType';

    if (stat.distanceDeltaM <= 0.25 && track.points.length > 1) {
      _lastProblem =
          'GPS приходит, но смещение меньше 25 см. Скорость будет около 0.';
    } else if (stat.rawSpeedKmh > 55) {
      _lastProblem =
          'GPS-скачок ${stat.rawSpeedKmh.toStringAsFixed(1)} км/ч. На экране скорость ограничена.';
    } else {
      _lastProblem = 'GPS принят, скорость считается локально';
    }

    if (mounted) setState(() {});

    await _savePoint(
      latitude: latitude,
      longitude: longitude,
      timeMs: timeMs,
      packetType: packetType,
      rawHex: rawHex,
    );
  }

  Future<void> _savePoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
    String? rawHex,
  }) async {
    final id = _myLiveSessionId;
    if (id == null || _savingPoint) return;

    final device = widget.ble.connectedInfo;
    final deviceUuid = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-GPS-${widget.teamId}-${widget.selectedPlayer?.id ?? 0}'
        : (device?.id ?? 'TRACKER');

    setState(() => _savingPoint = true);

    try {
      final result = await _api.saveLivePoint(
        TrackerLivePointPayload(
          liveSessionId: id,
          clubId: widget.clubId,
          teamId: widget.teamId,
          playerId: widget.selectedPlayer?.id,
          deviceUuid: deviceUuid,
          latitude: latitude,
          longitude: longitude,
          timeMs: timeMs,
          batteryPercent: widget.batteryPercent,
        ),
      );

      _lastSaveAt = DateTime.now();
      final speed = result['speed_kmh'] ?? 0;
      final delta = result['distance_delta_m'] ?? 0;
      final field = result['field'];
      final fieldWarning = field is Map ? field['field_warning'] : null;

      if (fieldWarning != null) {
        _lastProblem =
            'Сервер сохранил GPS, но координата поля вне диапазона. Проверьте калибровку.';
      } else {
        _lastProblem = 'Точка сохранена на сервере';
      }

      _lastSave = 'OK · $speed км/ч · +$delta м';
      _log('Точка сохранена: $_lastSave');
      await _serverLog(
        'point saved: $_lastSave · $packetType',
        source: 'save_point',
        rawHex: rawHex,
      );
      await _loadLiveState();
    } catch (e) {
      _lastSave = 'ОШИБКА: $e';
      _lastProblem = 'Сервер не сохранил точку: $e';
      _log('Сохранение точки: $e');
      await _serverLog(
        'save point error: $e',
        level: 'error',
        source: 'save_point',
        rawHex: rawHex,
      );
    } finally {
      if (mounted) setState(() => _savingPoint = false);
    }
  }

  Future<void> _stopLive() async {
    _running = false;
    _phoneTimer?.cancel();
    _trackerTimer?.cancel();
    _heartbeatTimer?.cancel();

    final id = _myLiveSessionId;
    if (id != null) {
      try {
        await _api.stopLiveSession(
          liveSessionId: id,
          createFinalSession: true,
        );
        _lastProblem = 'Live остановлен и сохранён как сессия';
        _log('Live остановлен: session=$id');
      } catch (e) {
        _lastProblem = 'Ошибка остановки Live: $e';
        _log(_lastProblem);
      }
    }

    _myLiveSessionId = null;
    await _loadLiveState();
    if (mounted) setState(() {});
  }


  Future<void> _addDebugLocalPoint() async {
    final startLat = 55.973505;
    final startLon = 37.399388;
    final track = _trackForCurrentDevice();

    final index = track.points.length;
    final lat = startLat + index * 0.000006;
    final lon = startLon + index * 0.000010;

    await _handleGpsPoint(
      latitude: lat,
      longitude: lon,
      timeMs: DateTime.now().millisecondsSinceEpoch,
      packetType: 'LOCAL-TEST',
      rawHex: null,
    );

    _lastProblem = 'Добавлена тестовая точка на устройстве. Если она двигается — UI работает, проблема в GPS/сервере.';
    if (mounted) setState(() {});
  }

  Future<void> _testGpsCommands() async {
    if (_testingCommands) return;

    final device = widget.ble.connectedInfo;
    if (device == null) {
      _toast('Сначала подключите BLE-трекер');
      return;
    }

    setState(() => _testingCommands = true);

    try {
      _log('--- Проверка команд GPS ---');
      final commands = ActionTrackerBleProfile.commandCurrentGpsCandidates;

      for (var i = 0; i < commands.length; i++) {
        if (!mounted) break;

        final cmd = commands[i]
            .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
            .join(' ');

        setState(() => _candidateCommandIndex = i);
        _log('TEST TX ${i + 1}/${commands.length}: $cmd');

        try {
          await widget.ble.sendRawCommand(commands[i]);
        } catch (e) {
          _log('TEST ERROR: $e');
        }

        await Future<void>.delayed(const Duration(milliseconds: 700));
      }

      _log('--- Проверка завершена ---');
    } finally {
      if (mounted) setState(() => _testingCommands = false);
    }
  }

  _RuntimeTrack _trackForCurrentDevice() {
    final device = widget.ble.connectedInfo;
    final key = _mode == TrackerLiveSourceMode.phoneGps
        ? 'PHONE-${widget.selectedPlayer?.id ?? 0}'
        : (device?.id ?? 'TRACKER');

    final playerName = widget.selectedPlayer?.name ?? 'Игрок';
    final deviceName = _mode == TrackerLiveSourceMode.phoneGps
        ? 'Телефон GPS'
        : (device?.name ?? 'Трекер');

    return _tracks.putIfAbsent(
      key,
      () => _RuntimeTrack(
        key: key,
        playerName: playerName,
        deviceName: deviceName,
      ),
    );
  }

  Future<void> _serverLog(
    String message, {
    String level = 'info',
    String source = 'live',
    String? rawHex,
  }) async {
    await _api.sendDebugLog(
      teamId: widget.teamId,
      playerId: widget.selectedPlayer?.id,
      liveSessionId: _myLiveSessionId,
      level: level,
      source: source,
      message: message,
      rawHex: rawHex,
    );
  }

  void _log(String text) {
    final line = '[${DateTime.now().toIso8601String()}] $text';
    // ignore: avoid_print
    print('[TRACKER_LIVE] $line');

    if (!mounted) return;
    setState(() {
      _logs.insert(0, line);
      if (_logs.length > 220) _logs.removeLast();
    });
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  _RuntimeTrack? get _mainTrack {
    if (_tracks.isEmpty) return null;
    if (widget.ble.connectedInfo != null) {
      final key = widget.ble.connectedInfo!.id;
      if (_tracks.containsKey(key)) return _tracks[key];
    }
    return _tracks.values.first;
  }

  double get _displaySpeedKmh {
    final local = _mainTrack?.speedKmh ?? 0;
    if (local > 0) return local;

    final server = _sessions.isEmpty ? 0.0 : _sessions.first.speedKmh;
    return server;
  }

  double get _displayDistanceM {
    final local = _mainTrack?.totalDistanceM ?? 0;
    if (local > 0) return local;

    final server = _sessions.isEmpty ? 0.0 : _sessions.first.totalDistanceM;
    return server;
  }

  int get _displayPoints => _tracks.values.fold<int>(0, (s, t) => s + t.points.length);

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final active = _sessions.where((s) => s.status == 'active').toList();
    final online = active.where((s) => s.isOnline).length;
    final wide = MediaQuery.of(context).size.width >= 1050;

    if (!wide) {
      return ListView(
        padding: const EdgeInsets.all(12),
        children: [
          _statusHeader(online, active.length),
          const SizedBox(height: 10),
          SizedBox(height: 360, child: _fieldCard()),
          const SizedBox(height: 10),
          _kpiGrid(columns: 2),
          const SizedBox(height: 10),
          _playersCard(height: 310),
          const SizedBox(height: 10),
          _debugCard(height: 420),
        ],
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final h = constraints.maxHeight;
        final safeHeight = h.isFinite && h > 0 ? h : MediaQuery.of(context).size.height - 220;

        return Padding(
          padding: const EdgeInsets.all(14),
          child: Row(
            children: [
              SizedBox(
                width: 390,
                height: safeHeight,
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    _statusHeader(online, active.length),
                    const SizedBox(height: 12),
                    SizedBox(height: 430, child: _debugCard()),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 7,
                child: SizedBox(
                  height: safeHeight,
                  child: Column(
                    children: [
                      Expanded(child: _fieldCard()),
                      const SizedBox(height: 12),
                      SizedBox(height: 168, child: _kpiGrid(columns: 4)),
                    ],
                  ),
                ),
              ),
              const SizedBox(width: 12),
              SizedBox(width: 360, height: safeHeight, child: _playersCard()),
            ],
          ),
        );
      },
    );
  }

  Widget _statusHeader(int online, int active) {
    final device = widget.ble.connectedInfo;
    final fieldReady = widget.selectedField?.hasCalibration == true;

    return _LiveCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _TitleRow(
            icon: Icons.analytics_rounded,
            title: 'Vector Tracking Center',
            subtitle: '${widget.teamName} · скорость, векторы, тепловая карта и нагрузка',
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _StatePill(
                icon: Icons.person_rounded,
                label: widget.selectedPlayer?.name ?? 'Игрок не выбран',
                ok: widget.selectedPlayer != null,
              ),
              _StatePill(
                icon: Icons.bluetooth_connected_rounded,
                label: device == null ? 'Трекер не подключён' : '${device.name}',
                ok: device != null,
              ),
              _StatePill(
                icon: Icons.map_rounded,
                label: fieldReady ? widget.selectedField!.title : 'Поле не готово',
                ok: fieldReady,
              ),
            ],
          ),
          const SizedBox(height: 12),
          SegmentedButton<TrackerLiveSourceMode>(
            segments: const [
              ButtonSegment(
                value: TrackerLiveSourceMode.phoneGps,
                icon: Icon(Icons.phone_iphone_rounded),
                label: Text('Телефон'),
              ),
              ButtonSegment(
                value: TrackerLiveSourceMode.trackerExperimental,
                icon: Icon(Icons.sensors_rounded),
                label: Text('Трекер'),
              ),
            ],
            selected: {_mode},
            onSelectionChanged: _running
                ? null
                : (v) => setState(() => _mode = v.first),
          ),
          if (_mode == TrackerLiveSourceMode.trackerExperimental) ...[
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              value: _candidateCommandIndex,
              decoration: _input('Команда Live GPS'),
              items: List.generate(
                ActionTrackerBleProfile.commandCurrentGpsCandidates.length,
                (i) {
                  final cmd = ActionTrackerBleProfile.commandCurrentGpsCandidates[i]
                      .map((b) => b.toRadixString(16).padLeft(2, '0').toUpperCase())
                      .join(' ');
                  return DropdownMenuItem(value: i, child: Text('Кандидат ${i + 1}: $cmd'));
                },
              ),
              onChanged: _running ? null : (v) => setState(() => _candidateCommandIndex = v ?? 0),
            ),
          ],
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: FilledButton.icon(
                  onPressed: _starting || _running ? null : _startLive,
                  style: FilledButton.styleFrom(
                    backgroundColor: _C.green,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(0, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  icon: _starting
                      ? const SizedBox(
                          width: 17,
                          height: 17,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                        )
                      : const Icon(Icons.play_arrow_rounded),
                  label: const Text('Старт Live'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: _running ? _stopLive : null,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _C.red,
                    side: const BorderSide(color: _C.green),
                    minimumSize: const Size(0, 48),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                  ),
                  icon: const Icon(Icons.stop_rounded),
                  label: const Text('Стоп'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: _running || _testingCommands ? null : _testGpsCommands,
            style: OutlinedButton.styleFrom(
              foregroundColor: _C.green,
              side: const BorderSide(color: _C.green),
              minimumSize: const Size(double.infinity, 42),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: _testingCommands
                ? const SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.bug_report_rounded),
            label: Text(_testingCommands ? 'Проверка команд...' : 'Debug: проверить команды GPS'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _addDebugLocalPoint,
            style: OutlinedButton.styleFrom(
              foregroundColor: _C.orange,
              side: const BorderSide(color: _C.orange),
              minimumSize: const Size(double.infinity, 42),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            ),
            icon: const Icon(Icons.playlist_add_rounded),
            label: const Text('Debug: добавить тестовую точку'),
          ),
          const SizedBox(height: 12),
          _ProblemBox(text: _lastProblem),
        ],
      ),
    );
  }

  Widget _fieldCard() {
    final track = _mainTrack;

    return _LiveCard(
      padding: EdgeInsets.zero,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Stack(
          children: [
            Positioned.fill(
              child: CustomPaint(
                painter: _RuntimeFieldPainter(
                  field: widget.selectedField,
                  tracks: _tracks.values.toList(),
                  showVectors: _showVectors,
                  showHeatmap: _showHeatmap,
                  showTrace: _showTrace,
                  showLabels: _showLabels,
                ),
              ),
            ),
            Positioned(
              left: 14,
              top: 14,
              right: 14,
              child: _FieldHud(
                title: 'Полевой радар',
                subtitle: _running
                    ? 'LIVE · ${track?.speedKmh.toStringAsFixed(1) ?? '0.0'} км/ч · ${track?.points.length ?? 0} точек'
                    : 'готов к старту · ${widget.selectedField?.title ?? 'поле не выбрано'}',
                speed: track?.speedKmh ?? _displaySpeedKmh,
                gpsAge: _lastGpsAt == null ? null : DateTime.now().difference(_lastGpsAt!).inSeconds,
              ),
            ),
            Positioned(
              left: 14,
              right: 14,
              bottom: 14,
              child: _FieldControlStrip(
                showTrace: _showTrace,
                showVectors: _showVectors,
                showHeatmap: _showHeatmap,
                showLabels: _showLabels,
                onTrace: () => setState(() => _showTrace = !_showTrace),
                onVectors: () => setState(() => _showVectors = !_showVectors),
                onHeatmap: () => setState(() => _showHeatmap = !_showHeatmap),
                onLabels: () => setState(() => _showLabels = !_showLabels),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _kpiGrid({required int columns}) {
    final track = _mainTrack;
    final lastDelta = track?.lastDeltaM ?? 0;

    final vector = track?.directionLabel ?? '—';
    final items = [
      _KpiData('Скорость', '${_displaySpeedKmh.toStringAsFixed(1)} км/ч', Icons.speed_rounded),
      _KpiData('Дистанция', '${(_displayDistanceM / 1000).toStringAsFixed(2)} км', Icons.route_rounded),
      _KpiData('Вектор', vector, Icons.near_me_rounded),
      _KpiData('Смещение', '${lastDelta.toStringAsFixed(1)} м', Icons.open_with_rounded),
    ];

    return GridView.builder(
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      itemCount: items.length,
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: columns,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: columns == 2 ? 2.6 : 1.95,
      ),
      itemBuilder: (_, i) => _KpiCard(data: items[i]),
    );
  }

  Widget _playersCard({double? height}) {
    final content = _LiveCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _TitleRow(
            icon: Icons.groups_rounded,
            title: 'Игроки онлайн',
            subtitle: 'Локальные данные + серверное состояние',
          ),
          const SizedBox(height: 12),
          Expanded(
            child: _tracks.isEmpty && _sessions.isEmpty
                ? const Center(
                    child: Text(
                      'Запустите Live, чтобы увидеть игрока',
                      style: TextStyle(color: _C.subtle, fontWeight: FontWeight.w700),
                    ),
                  )
                : ListView(
                    children: [
                      ..._tracks.values.map((track) => _RuntimePlayerTile(track: track)),
                      if (_sessions.isNotEmpty && _tracks.isNotEmpty)
                        const Padding(
                          padding: EdgeInsets.symmetric(vertical: 8),
                          child: Divider(height: 1),
                        ),
                      ..._sessions.map((s) => _ServerPlayerTile(session: s)),
                    ],
                  ),
          ),
        ],
      ),
    );

    return height == null ? content : SizedBox(height: height, child: content);
  }

  Widget _debugCard({double? height}) {
    final content = _LiveCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: _TitleRow(
                  icon: Icons.bug_report_rounded,
                  title: 'Debug на устройстве',
                  subtitle: 'Показывает, где именно ломается цепочка',
                ),
              ),
              IconButton(
                onPressed: () => setState(() => _showDebug = !_showDebug),
                icon: Icon(_showDebug ? Icons.expand_less_rounded : Icons.expand_more_rounded),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _DebugLine(label: 'TX', value: _lastTx),
          _DebugLine(label: 'RX', value: _lastRx),
          _DebugLine(label: 'GPS', value: _lastGps),
          _DebugLine(label: 'SAVE', value: _lastSave),
          _DebugLine(
            label: 'GPS age',
            value: _lastGpsAt == null
                ? 'нет'
                : '${DateTime.now().difference(_lastGpsAt!).inSeconds} сек назад',
          ),
          _DebugLine(
            label: 'Save age',
            value: _lastSaveAt == null
                ? 'нет'
                : '${DateTime.now().difference(_lastSaveAt!).inSeconds} сек назад',
          ),
          const SizedBox(height: 10),
          if (_showDebug)
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: const Color(0xFF0B0F14),
                  borderRadius: BorderRadius.circular(16),
                ),
                padding: const EdgeInsets.all(10),
                child: _logs.isEmpty
                    ? const Center(
                        child: Text(
                          'Логи появятся здесь',
                          style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w700),
                        ),
                      )
                    : ListView.builder(
                        itemCount: _logs.length,
                        itemBuilder: (_, i) => Padding(
                          padding: const EdgeInsets.only(bottom: 6),
                          child: Text(
                            _logs[i],
                            style: const TextStyle(
                              color: Color(0xFFE5E7EB),
                              fontSize: 10.8,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'monospace',
                              height: 1.25,
                            ),
                          ),
                        ),
                      ),
              ),
            ),
        ],
      ),
    );

    return height == null ? content : SizedBox(height: height, child: content);
  }
}

class _FieldHud extends StatelessWidget {
  const _FieldHud({
    required this.title,
    required this.subtitle,
    required this.speed,
    required this.gpsAge,
  });

  final String title;
  final String subtitle;
  final double speed;
  final int? gpsAge;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.34),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.16)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.16),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.radar_rounded, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white.withOpacity(.72),
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                speed.toStringAsFixed(1),
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 22,
                  fontWeight: FontWeight.w900,
                  fontFeatures: [FontFeature.tabularFigures()],
                ),
              ),
              Text(
                gpsAge == null ? 'GPS —' : 'GPS ${gpsAge}s',
                style: TextStyle(
                  color: Colors.white.withOpacity(.72),
                  fontSize: 10.5,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FieldControlStrip extends StatelessWidget {
  const _FieldControlStrip({
    required this.showTrace,
    required this.showVectors,
    required this.showHeatmap,
    required this.showLabels,
    required this.onTrace,
    required this.onVectors,
    required this.onHeatmap,
    required this.onLabels,
  });

  final bool showTrace;
  final bool showVectors;
  final bool showHeatmap;
  final bool showLabels;
  final VoidCallback onTrace;
  final VoidCallback onVectors;
  final VoidCallback onHeatmap;
  final VoidCallback onLabels;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(.34),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white.withOpacity(.14)),
      ),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _FieldToggleChip(label: 'Трек', icon: Icons.timeline_rounded, active: showTrace, onTap: onTrace),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Векторы', icon: Icons.near_me_rounded, active: showVectors, onTap: onVectors),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Тепло', icon: Icons.local_fire_department_rounded, active: showHeatmap, onTap: onHeatmap),
            const SizedBox(width: 7),
            _FieldToggleChip(label: 'Метки', icon: Icons.label_rounded, active: showLabels, onTap: onLabels),
          ],
        ),
      ),
    );
  }
}

class _FieldToggleChip extends StatelessWidget {
  const _FieldToggleChip({
    required this.label,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? Colors.white : Colors.white.withOpacity(.12),
      borderRadius: BorderRadius.circular(999),
      child: InkWell(
        borderRadius: BorderRadius.circular(999),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: active ? _C.text : Colors.white),
              const SizedBox(width: 5),
              Text(
                label,
                style: TextStyle(
                  color: active ? _C.text : Colors.white,
                  fontSize: 11.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RuntimePoint {
  final double lat;
  final double lon;
  final int timeMs;
  final double speedKmh;
  final double rawSpeedKmh;
  final double distanceDeltaM;
  final String packetType;

  const _RuntimePoint({
    required this.lat,
    required this.lon,
    required this.timeMs,
    required this.speedKmh,
    required this.rawSpeedKmh,
    required this.distanceDeltaM,
    required this.packetType,
  });
}

class _RuntimeTrack {
  _RuntimeTrack({
    required this.key,
    required this.playerName,
    required this.deviceName,
  });

  final String key;
  final String playerName;
  final String deviceName;
  final List<_RuntimePoint> points = <_RuntimePoint>[];

  double speedKmh = 0;
  double rawSpeedKmh = 0;
  double totalDistanceM = 0;
  double maxSpeedKmh = 0;
  double lastDeltaM = 0;
  double headingDeg = 0;
  int sprintCount = 0;

  String get directionLabel {
    if (points.length < 2 || lastDeltaM <= 0.25) return 'нет движения';
    return '${headingDeg.round()}°';
  }

  _RuntimePoint addPoint({
    required double latitude,
    required double longitude,
    required int timeMs,
    required String packetType,
  }) {
    double delta = 0;
    double speed = 0;
    double raw = 0;

    if (points.isNotEmpty) {
      final prev = points.last;
      delta = _haversineM(prev.lat, prev.lon, latitude, longitude);
      final dt = math.max(0.75, (timeMs - prev.timeMs) / 1000.0);
      raw = (delta / dt) * 3.6;
      speed = raw.clamp(0.0, 42.0).toDouble();
      headingDeg = _bearingDeg(prev.lat, prev.lon, latitude, longitude);

      if (raw <= 55.0) {
        totalDistanceM += delta;
      }

      if (speed >= 20.0 && (points.isEmpty || points.last.speedKmh < 20.0)) {
        sprintCount += 1;
      }
    }

    speedKmh = speed;
    rawSpeedKmh = raw;
    maxSpeedKmh = math.max(maxSpeedKmh, speed);
    lastDeltaM = delta;

    final p = _RuntimePoint(
      lat: latitude,
      lon: longitude,
      timeMs: timeMs,
      speedKmh: speed,
      rawSpeedKmh: raw,
      distanceDeltaM: delta,
      packetType: packetType,
    );

    points.add(p);
    if (points.length > 900) {
      points.removeAt(0);
    }

    return p;
  }
}

double _haversineM(double lat1, double lon1, double lat2, double lon2) {
  const r = 6371000.0;
  final dLat = _deg(lat2 - lat1);
  final dLon = _deg(lon2 - lon1);
  final a = math.sin(dLat / 2) * math.sin(dLat / 2) +
      math.cos(_deg(lat1)) *
          math.cos(_deg(lat2)) *
          math.sin(dLon / 2) *
          math.sin(dLon / 2);
  return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
}

double _deg(double v) => v * math.pi / 180.0;

double _bearingDeg(double lat1, double lon1, double lat2, double lon2) {
  final p1 = _deg(lat1);
  final p2 = _deg(lat2);
  final dLon = _deg(lon2 - lon1);
  final y = math.sin(dLon) * math.cos(p2);
  final x = math.cos(p1) * math.sin(p2) - math.sin(p1) * math.cos(p2) * math.cos(dLon);
  final bearing = math.atan2(y, x) * 180.0 / math.pi;
  return (bearing + 360.0) % 360.0;
}

class _RuntimeFieldPainter extends CustomPainter {
  _RuntimeFieldPainter({
    required this.field,
    required this.tracks,
    required this.showVectors,
    required this.showHeatmap,
    required this.showTrace,
    required this.showLabels,
  });

  final TrackerFieldModel? field;
  final List<_RuntimeTrack> tracks;
  final bool showVectors;
  final bool showHeatmap;
  final bool showTrace;
  final bool showLabels;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF087338), Color(0xFF12A05A)],
      ).createShader(rect);

    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(24)),
      bg,
    );

    final stripe = Paint()..color = Colors.white.withOpacity(.055);
    final stripeW = size.width / 10;
    for (var i = 0; i < 10; i += 2) {
      canvas.drawRect(Rect.fromLTWH(i * stripeW, 0, stripeW, size.height), stripe);
    }

    final pitch = Rect.fromLTWH(22, 20, size.width - 44, size.height - 40);
    final line = Paint()
      ..color = Colors.white.withOpacity(.9)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final thin = Paint()
      ..color = Colors.white.withOpacity(.66)
      ..strokeWidth = 1.35
      ..style = PaintingStyle.stroke;

    canvas.drawRect(pitch, line);
    canvas.drawLine(Offset(pitch.center.dx, pitch.top), Offset(pitch.center.dx, pitch.bottom), thin);
    canvas.drawCircle(pitch.center, math.min(pitch.width, pitch.height) * .115, thin);
    canvas.drawCircle(pitch.center, 3, Paint()..color = Colors.white.withOpacity(.9));

    final penaltyW = pitch.width * .165;
    final penaltyH = pitch.height * .52;
    final goalW = pitch.width * .055;
    final goalH = pitch.height * .23;

    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - penaltyW, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - goalW, pitch.center.dy - goalH / 2, goalW, goalH), thin);

    final allPoints = tracks.expand((t) => t.points).toList();
    if (allPoints.isEmpty) {
      _drawCenterText(canvas, size, field?.hasCalibration == true ? 'Ждём GPS от трекера' : 'Сначала откалибруйте поле');
      return;
    }

    double minLat = allPoints.first.lat;
    double maxLat = allPoints.first.lat;
    double minLon = allPoints.first.lon;
    double maxLon = allPoints.first.lon;

    for (final p in allPoints) {
      minLat = math.min(minLat, p.lat);
      maxLat = math.max(maxLat, p.lat);
      minLon = math.min(minLon, p.lon);
      maxLon = math.max(maxLon, p.lon);
    }

    if (showHeatmap) {
      _drawHeatmap(canvas, pitch, allPoints, minLat, maxLat, minLon, maxLon);
    }

    for (final track in tracks) {
      if (track.points.isEmpty) continue;

      if (showTrace) {
        final path = Path();
        var started = false;

        for (final p in track.points) {
          final pos = _project(p, pitch, minLat, maxLat, minLon, maxLon);
          if (!started) {
            path.moveTo(pos.dx, pos.dy);
            started = true;
          } else {
            path.lineTo(pos.dx, pos.dy);
          }
        }

        canvas.drawPath(
          path,
          Paint()
            ..color = Colors.white.withOpacity(.82)
            ..strokeWidth = 3
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeJoin = StrokeJoin.round,
        );
      }

      if (showVectors && track.points.length >= 2) {
        final last = track.points.last;
        final prev = track.points[track.points.length - 2];
        final a = _project(prev, pitch, minLat, maxLat, minLon, maxLon);
        final b = _project(last, pitch, minLat, maxLat, minLon, maxLon);
        _drawVector(canvas, a, b, track.speedKmh);
      }

      final last = track.points.last;
      final pos = _project(last, pitch, minLat, maxLat, minLon, maxLon);
      final color = _speedColor(track.speedKmh);

      canvas.drawCircle(
        pos,
        24,
        Paint()
          ..color = color.withOpacity(.24)
          ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 11),
      );
      canvas.drawCircle(pos, 11, Paint()..color = color);
      canvas.drawCircle(
        pos,
        15,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.4
          ..color = Colors.white.withOpacity(.94),
      );

      if (showLabels) {
        final label = '${track.playerName} · ${track.speedKmh.toStringAsFixed(1)} км/ч · ${track.directionLabel}';
        _drawLabel(canvas, pitch, pos, label);
      }
    }
  }

  void _drawHeatmap(
    Canvas canvas,
    Rect pitch,
    List<_RuntimePoint> points,
    double minLat,
    double maxLat,
    double minLon,
    double maxLon,
  ) {
    final step = points.length > 180 ? 4 : points.length > 90 ? 2 : 1;
    for (var i = 0; i < points.length; i += step) {
      final p = points[i];
      final pos = _project(p, pitch, minLat, maxLat, minLon, maxLon);
      final double radius = (18 + p.speedKmh * 1.4).clamp(18.0, 52.0).toDouble();
      final color = _speedColor(p.speedKmh);
      final heat = Paint()
        ..shader = RadialGradient(
          colors: [
            color.withOpacity(.28),
            color.withOpacity(.08),
            Colors.transparent,
          ],
          stops: const [.0, .45, 1],
        ).createShader(Rect.fromCircle(center: pos, radius: radius));
      canvas.drawCircle(pos, radius, heat);
    }
  }

  void _drawVector(Canvas canvas, Offset from, Offset to, double speedKmh) {
    final delta = to - from;
    final len = delta.distance;
    if (len < 2) return;

    final dir = delta / len;
    final double vectorLen = (18 + speedKmh * 1.8).clamp(24.0, 74.0).toDouble();
    final end = to + dir * vectorLen;
    final color = _speedColor(speedKmh);

    canvas.drawLine(
      to,
      end,
      Paint()
        ..color = Colors.black.withOpacity(.28)
        ..strokeWidth = 7
        ..strokeCap = StrokeCap.round,
    );
    canvas.drawLine(
      to,
      end,
      Paint()
        ..color = color
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round,
    );

    final angle = math.atan2(dir.dy, dir.dx);
    final left = end - Offset(math.cos(angle - .62), math.sin(angle - .62)) * 12;
    final right = end - Offset(math.cos(angle + .62), math.sin(angle + .62)) * 12;
    final head = Path()
      ..moveTo(end.dx, end.dy)
      ..lineTo(left.dx, left.dy)
      ..lineTo(right.dx, right.dy)
      ..close();

    canvas.drawPath(head, Paint()..color = color);
    canvas.drawPath(
      head,
      Paint()
        ..color = Colors.white.withOpacity(.86)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );
  }

  Color _speedColor(double speedKmh) {
    if (speedKmh >= 25) return const Color(0xFFE11D48);
    if (speedKmh >= 20) return _C.orange;
    if (speedKmh >= 13) return const Color(0xFFFACC15);
    if (speedKmh >= 6) return const Color(0xFF5EEAD4);
    return _C.greenLight;
  }

  void _drawLabel(Canvas canvas, Rect pitch, Offset pos, String label) {
    final text = label.length > 34 ? '${label.substring(0, 34)}…' : label;
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w900,
          shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 240);

    final bgRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        (pos.dx + 14).clamp(pitch.left, pitch.right - tp.width - 18).toDouble(),
        (pos.dy - 32).clamp(pitch.top, pitch.bottom - 24).toDouble(),
        tp.width + 16,
        24,
      ),
      const Radius.circular(10),
    );

    canvas.drawRRect(bgRect, Paint()..color = Colors.black.withOpacity(.34));
    canvas.drawRRect(
      bgRect,
      Paint()
        ..color = Colors.white.withOpacity(.20)
        ..strokeWidth = 1
        ..style = PaintingStyle.stroke,
    );
    tp.paint(canvas, Offset(bgRect.left + 8, bgRect.top + 5));
  }

  Offset _project(
    _RuntimePoint p,
    Rect pitch,
    double minLat,
    double maxLat,
    double minLon,
    double maxLon,
  ) {
    final lonRange = (maxLon - minLon).abs();
    final latRange = (maxLat - minLat).abs();

    final double nx = lonRange < 0.000001 ? 0.5 : ((p.lon - minLon) / lonRange).clamp(0.04, 0.96).toDouble();
    final double ny = latRange < 0.000001 ? 0.5 : ((p.lat - minLat) / latRange).clamp(0.04, 0.96).toDouble();

    return Offset(
      pitch.left + nx * pitch.width,
      pitch.bottom - ny * pitch.height,
    );
  }

  void _drawCenterText(Canvas canvas, Size size, String text) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(
          color: Colors.white.withOpacity(.88),
          fontSize: 16,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: size.width - 60);

    tp.paint(canvas, Offset((size.width - tp.width) / 2, (size.height - tp.height) / 2));
  }

  @override
  bool shouldRepaint(covariant _RuntimeFieldPainter oldDelegate) => true;
}

class _RuntimePlayerTile extends StatelessWidget {
  const _RuntimePlayerTile({required this.track});

  final _RuntimeTrack track;

  @override
  Widget build(BuildContext context) {
    final color = track.speedKmh >= 20 ? _C.orange : _C.green;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _C.greenSoft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.green.withOpacity(.22)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: Colors.white,
            child: Icon(Icons.radio_button_checked_rounded, color: color),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(track.playerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900)),
                const SizedBox(height: 3),
                Text(
                  '${track.speedKmh.toStringAsFixed(1)} км/ч · ${(track.totalDistanceM / 1000).toStringAsFixed(2)} км · точек ${track.points.length}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _C.muted, fontSize: 11.5, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Text('LIVE', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 12)),
        ],
      ),
    );
  }
}

class _ServerPlayerTile extends StatelessWidget {
  const _ServerPlayerTile({required this.session});

  final TrackerLiveSessionModel session;

  @override
  Widget build(BuildContext context) {
    final color = !session.isOnline ? _C.subtle : session.speedKmh >= 20 ? _C.orange : _C.green;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: session.isOnline ? _C.soft : Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.divider),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: _C.soft,
            child: Icon(session.isOnline ? Icons.cloud_done_rounded : Icons.cloud_off_rounded, color: color),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(session.playerName ?? session.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontWeight: FontWeight.w900)),
              const SizedBox(height: 3),
              Text('${session.speedKmh.toStringAsFixed(1)} км/ч · ${(session.totalDistanceM / 1000).toStringAsFixed(2)} км · сервер', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 11.5, fontWeight: FontWeight.w700)),
            ]),
          ),
          Text(session.isOnline ? 'SERVER' : 'OFF', style: TextStyle(color: color, fontWeight: FontWeight.w900, fontSize: 11)),
        ],
      ),
    );
  }
}

class _KpiData {
  const _KpiData(this.title, this.value, this.icon);
  final String title;
  final String value;
  final IconData icon;
}

class _KpiCard extends StatelessWidget {
  const _KpiCard({required this.data});
  final _KpiData data;

  @override
  Widget build(BuildContext context) {
    return _LiveCard(
      padding: const EdgeInsets.all(13),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(color: _C.greenSoft, borderRadius: BorderRadius.circular(15)),
            child: Icon(data.icon, color: _C.green),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(data.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 11.5, fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text(data.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 18, fontWeight: FontWeight.w900, fontFeatures: [FontFeature.tabularFigures()])),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _DebugLine extends StatelessWidget {
  const _DebugLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: _C.divider)),
      child: Row(
        children: [
          SizedBox(width: 72, child: Text(label, style: const TextStyle(color: _C.subtle, fontSize: 11, fontWeight: FontWeight.w900))),
          Expanded(
            child: Text(
              value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _C.text, fontSize: 11.2, fontWeight: FontWeight.w800, fontFamily: 'monospace'),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProblemBox extends StatelessWidget {
  const _ProblemBox({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    final isBad = text.toLowerCase().contains('ошибка') || text.toLowerCase().contains('нет ');
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isBad ? _C.redSoft : _C.greenSoft,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isBad ? _C.red.withOpacity(.18) : _C.green.withOpacity(.18)),
      ),
      child: Row(
        children: [
          Icon(isBad ? Icons.warning_amber_rounded : Icons.check_circle_rounded, color: isBad ? _C.red : _C.green),
          const SizedBox(width: 9),
          Expanded(
            child: Text(
              text,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(color: isBad ? _C.red : _C.greenDark, fontSize: 12, fontWeight: FontWeight.w900, height: 1.25),
            ),
          ),
        ],
      ),
    );
  }
}

class _StatePill extends StatelessWidget {
  const _StatePill({required this.icon, required this.label, required this.ok});
  final IconData icon;
  final String label;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    final color = ok ? _C.green : _C.orange;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(.16)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 6),
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 220),
            child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
  }
}

class _TitleRow extends StatelessWidget {
  const _TitleRow({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 42, height: 42, decoration: BoxDecoration(color: _C.greenSoft, borderRadius: BorderRadius.circular(15)), child: Icon(icon, color: _C.green)),
        const SizedBox(width: 11),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 17, fontWeight: FontWeight.w900, letterSpacing: -0.15)),
            const SizedBox(height: 3),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.subtle, fontSize: 11.5, fontWeight: FontWeight.w700)),
          ]),
        ),
      ],
    );
  }
}

class _LiveCard extends StatelessWidget {
  const _LiveCard({required this.child, this.padding = const EdgeInsets.all(16)});
  final Widget child;
  final EdgeInsetsGeometry padding;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.divider),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 22, offset: const Offset(0, 12)),
        ],
      ),
      child: child,
    );
  }
}

InputDecoration _input(String label) => InputDecoration(
      labelText: label,
      filled: true,
      fillColor: _C.soft,
      isDense: true,
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
    );

class _C {
  static const Color bg = Color(0xFFF5F6F7);
  static const Color panel = Colors.white;
  static const Color soft = Color(0xFFF8F9FA);
  static const Color text = Color(0xFF0B0F14);
  static const Color muted = Color(0xFF374151);
  static const Color subtle = Color(0xFF6B7280);
  static const Color divider = Color(0xFFE5E7EB);
  static const Color green = Color(0xFF00A750);
  static const Color greenLight = Color(0xFFB9FFDC);
  static const Color greenSoft = Color(0xFFF3FBF7);
  static const Color greenDark = Color(0xFF067A46);
  static const Color orange = Color(0xFFEA580C);
  static const Color red = Color(0xFFDC2626);
  static const Color redSoft = Color(0xFFFEF2F2);
}
