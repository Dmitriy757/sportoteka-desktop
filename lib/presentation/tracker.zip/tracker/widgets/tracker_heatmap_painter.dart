import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/tracker_pro_models.dart';

class TrackerHeatmapPainter extends CustomPainter {
  TrackerHeatmapPainter({required this.points});

  final List<TrackerHeatPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final field = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(22));
    final bg = Paint()..color = const Color(0xFF0B7A3B).withOpacity(.10);
    canvas.drawRRect(field, bg);

    final line = Paint()
      ..color = Colors.white.withOpacity(.85)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    final rect = Rect.fromLTWH(18, 18, size.width - 36, size.height - 36);
    canvas.drawRect(rect, line);
    canvas.drawLine(Offset(size.width / 2, 18), Offset(size.width / 2, size.height - 18), line);
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), math.min(size.width, size.height) * .10, line);
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), 3, line..style = PaintingStyle.fill);
    line.style = PaintingStyle.stroke;

    final maxValue = points.fold<double>(1, (m, p) => p.value > m ? p.value : m);

    for (final p in points) {
      final dx = (18 + p.x.clamp(0, 1) * (size.width - 36)).toDouble();
      final dy = (18 + p.y.clamp(0, 1) * (size.height - 36)).toDouble();
      final ratio = (p.value / maxValue).clamp(.05, 1.0).toDouble();
      final radius = 12 + 34 * ratio;

      final paint = Paint()
        ..shader = RadialGradient(
          colors: [
            const Color(0xFFD92D20).withOpacity(.48 * ratio),
            const Color(0xFFF79009).withOpacity(.26 * ratio),
            const Color(0xFF00A750).withOpacity(.02),
          ],
          stops: const [0, .45, 1],
        ).createShader(Rect.fromCircle(center: Offset(dx, dy), radius: radius));

      canvas.drawCircle(Offset(dx, dy), radius, paint);
    }
  }

  @override
  bool shouldRepaint(covariant TrackerHeatmapPainter oldDelegate) => oldDelegate.points != points;
}
