import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/tracker_pro_models.dart';

class TrackerFieldPainter extends CustomPainter {
  TrackerFieldPainter({
    required this.field,
    this.activeCorner,
  });

  final TrackerFieldModel? field;
  final String? activeCorner;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Offset.zero & size;
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [
          Color(0xFF0B7A3B),
          Color(0xFF0FA85A),
        ],
      ).createShader(outer);

    final outerR = RRect.fromRectAndRadius(outer, const Radius.circular(24));
    canvas.drawRRect(outerR, bg);

    final stripePaint = Paint()..color = Colors.white.withOpacity(.055);
    final stripeW = size.width / 8;
    for (var i = 0; i < 8; i += 2) {
      canvas.drawRect(Rect.fromLTWH(i * stripeW, 0, stripeW, size.height), stripePaint);
    }

    final pitch = Rect.fromLTWH(20, 18, size.width - 40, size.height - 36);
    final line = Paint()
      ..color = Colors.white.withOpacity(.92)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    final thin = Paint()
      ..color = Colors.white.withOpacity(.70)
      ..strokeWidth = 1.35
      ..style = PaintingStyle.stroke;

    canvas.drawRect(pitch, line);
    canvas.drawLine(Offset(pitch.center.dx, pitch.top), Offset(pitch.center.dx, pitch.bottom), thin);
    canvas.drawCircle(pitch.center, math.min(pitch.width, pitch.height) * .115, thin);
    canvas.drawCircle(pitch.center, 3, Paint()..color = Colors.white.withOpacity(.9));

    final penaltyW = pitch.width * .165;
    final penaltyH = pitch.height * .52;
    final goalW = pitch.width * .055;
    final goalH = pitch.height * .23;
    final leftPenalty = Rect.fromLTWH(pitch.left, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH);
    final rightPenalty = Rect.fromLTWH(pitch.right - penaltyW, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH);
    canvas.drawRect(leftPenalty, thin);
    canvas.drawRect(rightPenalty, thin);
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - goalW, pitch.center.dy - goalH / 2, goalW, goalH), thin);

    final accent = Paint()..color = const Color(0xFFB9FFDC);
    final missing = Paint()..color = Colors.white.withOpacity(.55);
    final active = Paint()..color = const Color(0xFFFFD166);

    void marker(String key, String label, Offset pos, bool ok) {
      final isActive = activeCorner == key;
      canvas.drawCircle(pos, isActive ? 10 : 8, isActive ? active : (ok ? accent : missing));
      canvas.drawCircle(
        pos,
        isActive ? 14 : 11,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = isActive ? 2.4 : 1.4
          ..color = Colors.white.withOpacity(isActive ? .95 : .65),
      );
      final tp = TextPainter(
        text: TextSpan(
          text: '$key · $label',
          style: TextStyle(
            color: Colors.white.withOpacity(.96),
            fontSize: 11,
            fontWeight: FontWeight.w900,
            shadows: const [Shadow(color: Colors.black38, blurRadius: 5)],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: 110);
      final double dx = pos.dx < pitch.center.dx ? 12.0 : -tp.width - 12.0;
      final double dy = pos.dy < pitch.center.dy ? 10.0 : -tp.height - 10.0;
      tp.paint(canvas, pos + Offset(dx, dy));
    }

    final f = field;
    final aOk = f?.cornerALat != null && f?.cornerALng != null;
    final bOk = f?.cornerBLat != null && f?.cornerBLng != null;
    final cOk = f?.cornerCLat != null && f?.cornerCLng != null;
    final dOk = f?.cornerDLat != null && f?.cornerDLng != null;

    marker('A', 'левый низ', pitch.bottomLeft, aOk);
    marker('B', 'правый низ', pitch.bottomRight, bOk);
    marker('C', 'правый верх', pitch.topRight, cOk);
    marker('D', 'левый верх', pitch.topLeft, dOk);

    final title = f == null
        ? 'Поле не выбрано'
        : '${f.title} · ${f.lengthM.toStringAsFixed(0)}×${f.widthM.toStringAsFixed(0)} м';
    final status = f?.hasCalibration == true ? 'Координаты готовы' : 'Нужно зафиксировать 4 угла';

    final titlePainter = TextPainter(
      text: TextSpan(
        children: [
          TextSpan(
            text: title,
            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: Colors.white),
          ),
          TextSpan(
            text: '\n$status',
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white.withOpacity(.78)),
          ),
        ],
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: size.width - 48);

    final badge = RRect.fromRectAndRadius(
      Rect.fromLTWH(16, 14, titlePainter.width + 22, titlePainter.height + 16),
      const Radius.circular(16),
    );
    canvas.drawRRect(badge, Paint()..color = Colors.black.withOpacity(.18));
    titlePainter.paint(canvas, Offset(badge.left + 11, badge.top + 8));
  }

  @override
  bool shouldRepaint(covariant TrackerFieldPainter oldDelegate) {
    return oldDelegate.field != field || oldDelegate.activeCorner != activeCorner;
  }
}
