import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/tracker_live_models.dart';
import '../models/tracker_pro_models.dart';

class TrackerLiveFieldPainter extends CustomPainter {
  TrackerLiveFieldPainter({
    required this.field,
    required this.sessions,
  });

  final TrackerFieldModel? field;
  final List<TrackerLiveSessionModel> sessions;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Offset.zero & size;
    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF087338), Color(0xFF12A05A)],
      ).createShader(outer);

    canvas.drawRRect(
      RRect.fromRectAndRadius(outer, const Radius.circular(26)),
      bg,
    );

    final stripe = Paint()..color = Colors.white.withOpacity(.055);
    final stripeW = size.width / 10;
    for (var i = 0; i < 10; i += 2) {
      canvas.drawRect(Rect.fromLTWH(i * stripeW, 0, stripeW, size.height), stripe);
    }

    final pitch = Rect.fromLTWH(22, 20, size.width - 44, size.height - 40);
    final line = Paint()
      ..color = Colors.white.withOpacity(.92)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    final thin = Paint()
      ..color = Colors.white.withOpacity(.7)
      ..strokeWidth = 1.35
      ..style = PaintingStyle.stroke;

    canvas.drawRect(pitch, line);
    canvas.drawLine(Offset(pitch.center.dx, pitch.top), Offset(pitch.center.dx, pitch.bottom), thin);
    canvas.drawCircle(pitch.center, math.min(pitch.width, pitch.height) * .115, thin);
    canvas.drawCircle(pitch.center, 3, Paint()..color = Colors.white.withOpacity(.9));

    final penaltyW = pitch.width * .165;
    final penaltyH = pitch.height * .52;
    final goalW = pitch.width * .055;
    final goalH = pitch.height * .23;
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - penaltyW, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - goalW, pitch.center.dy - goalH / 2, goalW, goalH), thin);

    final lengthM = field?.lengthM ?? 105;
    final widthM = field?.widthM ?? 68;

    final gpsSessions = sessions
        .where((s) => s.latitude != null && s.longitude != null)
        .toList();

    double? minLat;
    double? maxLat;
    double? minLon;
    double? maxLon;

    for (final s in gpsSessions) {
      final lat = s.latitude!;
      final lon = s.longitude!;
      minLat = minLat == null ? lat : math.min(minLat, lat);
      maxLat = maxLat == null ? lat : math.max(maxLat, lat);
      minLon = minLon == null ? lon : math.min(minLon, lon);
      maxLon = maxLon == null ? lon : math.max(maxLon, lon);
    }

    for (final s in sessions) {
      Offset? pos;

      final fx = s.fieldXM;
      final fy = s.fieldYM;

      if (fx != null && fy != null) {
        final nx = (fx / lengthM).clamp(0.0, 1.0);
        final ny = (fy / widthM).clamp(0.0, 1.0);

        pos = Offset(
          pitch.left + nx * pitch.width,
          pitch.bottom - ny * pitch.height,
        );
      } else if (s.latitude != null && s.longitude != null) {
        // Fallback: if the field is not calibrated or server did not calculate field_x/field_y,
        // still show the player on the custom pitch using normalized GPS bounds.
        final lat = s.latitude!;
        final lon = s.longitude!;

        if (minLat != null && maxLat != null && minLon != null && maxLon != null) {
          final latRange = (maxLat - minLat).abs();
          final lonRange = (maxLon - minLon).abs();

          final nx = lonRange < 0.000001 ? 0.5 : ((lon - minLon) / lonRange).clamp(0.06, 0.94);
          final ny = latRange < 0.000001 ? 0.5 : ((lat - minLat) / latRange).clamp(0.06, 0.94);

          pos = Offset(
            pitch.left + nx * pitch.width,
            pitch.bottom - ny * pitch.height,
          );
        }
      }

      if (pos == null) continue;

      final color = !s.isOnline
          ? const Color(0xFF94A3B8)
          : s.speedKmh >= 20
              ? const Color(0xFFFFD166)
              : const Color(0xFFB9FFDC);

      final glow = Paint()
        ..color = color.withOpacity(.22)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8);
      canvas.drawCircle(pos, 18, glow);
      canvas.drawCircle(pos, 9, Paint()..color = color);
      canvas.drawCircle(
        pos,
        12,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2
          ..color = Colors.white.withOpacity(.9),
      );

      final label = (s.playerName ?? s.deviceName).trim();
      final tp = TextPainter(
        text: TextSpan(
          text: label.length > 14 ? '${label.substring(0, 14)}…' : label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 11,
            fontWeight: FontWeight.w900,
            shadows: [Shadow(color: Colors.black54, blurRadius: 6)],
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: 120);

      final bgRect = RRect.fromRectAndRadius(
        Rect.fromLTWH(pos.dx - 8, pos.dy - 31, tp.width + 16, 22),
        const Radius.circular(9),
      );
      canvas.drawRRect(bgRect, Paint()..color = Colors.black.withOpacity(.25));
      tp.paint(canvas, Offset(pos.dx, pos.dy - 27));
    }

    if (sessions.isEmpty) {
      final tp = TextPainter(
        text: TextSpan(
          text: field?.hasCalibration == true
              ? 'Live-точки появятся после старта'
              : 'Сначала откалибруйте поле',
          style: TextStyle(
            color: Colors.white.withOpacity(.88),
            fontSize: 16,
            fontWeight: FontWeight.w900,
          ),
        ),
        textDirection: TextDirection.ltr,
      )..layout(maxWidth: size.width - 60);
      tp.paint(canvas, Offset((size.width - tp.width) / 2, (size.height - tp.height) / 2));
    }
  }

  @override
  bool shouldRepaint(covariant TrackerLiveFieldPainter oldDelegate) {
    return oldDelegate.field != field || oldDelegate.sessions != sessions;
  }
}
