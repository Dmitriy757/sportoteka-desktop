import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/action_tracker_protocol.dart';
import '../models/tracker_pro_models.dart';
import '../models/tracker_pitch_projection.dart';
import '../services/tracker_pro_api.dart';

class TrackerActionAnalyticsSuite extends StatefulWidget {
  const TrackerActionAnalyticsSuite({
    super.key,
    required this.api,
    required this.teamId,
    required this.teamName,
    required this.players,
    required this.selectedPlayer,
    required this.selectedField,
    required this.localPoints,
    required this.selectedSession,
    required this.onRefresh,
    required this.onSelectPlayer,
    required this.onSelectSession,
    required this.onOpenCalibration,
    required this.onOpenSessions,
    required this.onOpenLive,
    required this.onRequestOfflineRecords,
    required this.onSaveOfflineSession,
    required this.liveRunning,
    required this.commandChannelReady,
    required this.offlineRecordsCount,
    required this.localPointsCount,
    required this.onDebug,
  });

  final TrackerProApi api;
  final int teamId;
  final String teamName;
  final List<TrackerPlayerOption> players;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final List<ActionTrackerGpsPoint> localPoints;
  final TrackerSessionModel? selectedSession;
  final VoidCallback onRefresh;
  final ValueChanged<int> onSelectPlayer;
  final ValueChanged<TrackerSessionModel> onSelectSession;
  final VoidCallback onOpenCalibration;
  final VoidCallback onOpenSessions;
  final VoidCallback onOpenLive;
  final VoidCallback onRequestOfflineRecords;
  final VoidCallback onSaveOfflineSession;
  final bool liveRunning;
  final bool commandChannelReady;
  final int offlineRecordsCount;
  final int localPointsCount;
  final void Function(String message, Map<String, dynamic> context) onDebug;

  @override
  State<TrackerActionAnalyticsSuite> createState() => _TrackerActionAnalyticsSuiteState();
}

class _TrackerActionAnalyticsSuiteState extends State<TrackerActionAnalyticsSuite> {
  int _tab = 0;
  int _reload = 0;
  bool _gpsOffsetFix = true;
  String _gpsOffsetMode = 'auto';
  double _linearDepth = 3.0;
  double _mapRotationDeg = 0.0;
  double _sprintThresholdKmh = 18.0;
  double _hsrThresholdKmh = 14.0;
  bool _offlineGpsMode = true;
  bool _showSprintArrows = true;
  bool _showHeatMapMode = false;
  DateTime _selectedDate = DateTime.now();
  bool _onlySelectedDate = true;
  TimeOfDay? _startTime;
  TimeOfDay? _endTime;
  final Set<int> _selectedSessionIds = <int>{};
  bool _useAllSessionsForPeriod = true;

  @override
  void initState() {
    super.initState();
    final speedProfile = _YouthSpeedProfile.fromLabel(widget.teamName);
    _hsrThresholdKmh = speedProfile.hsrKmh;
    _sprintThresholdKmh = speedProfile.sprintKmh;
    _syncSelectedSessionFromWidget();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.onDebug('GPS-аналитика открыта', {
        'team_id': widget.teamId,
        'player_id': widget.selectedPlayer?.id,
        'field_id': widget.selectedField?.id,
        'local_points': widget.localPoints.length,
      });
    });
  }


  @override
  void didUpdateWidget(covariant TrackerActionAnalyticsSuite oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.selectedSession?.id != widget.selectedSession?.id) {
      setState(() {
        _syncSelectedSessionFromWidget(force: true);
        _reload++;
      });
    }
  }

  void _syncSelectedSessionFromWidget({bool force = false}) {
    final session = widget.selectedSession;
    if (session == null || session.id <= 0) return;
    final dt = _sessionDateTime(session);
    if (dt != null) _selectedDate = DateTime(dt.year, dt.month, dt.day);
    if (force || _selectedSessionIds.isEmpty) {
      _useAllSessionsForPeriod = false;
      _selectedSessionIds
        ..clear()
        ..add(session.id);
    }
  }

  void _refresh() {
    setState(() => _reload++);
    widget.onRefresh();
    widget.onDebug('GPS-аналитика обновлена', {
      'tab': _tab,
      'team_id': widget.teamId,
      'player_id': widget.selectedPlayer?.id,
      'field_id': widget.selectedField?.id,
    });
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final compact = width < 980;
    final mobile = width < 720;
    return Container(
      color: _AA.bg,
      child: Column(
        children: [
          if (!mobile)
            _Header(
              title: 'Спортотека GPS аналитика',
              subtitle: '${widget.teamName} · календарь сессий, теплокарта, спринты, скорость, команда и офлайн GPS',
              liveRunning: widget.liveRunning,
              commandChannelReady: widget.commandChannelReady,
              onRefresh: _refresh,
              onLive: widget.onOpenLive,
            ),
          _DateFilterBar(
            selectedDate: _selectedDate,
            onlySelectedDate: _onlySelectedDate,
            startTime: _startTime,
            endTime: _endTime,
            selectedSession: widget.selectedSession,
            sessionFilterLabel: _sessionFilterLabel(),
            liveRunning: widget.liveRunning,
            localPointsCount: _visibleLocalPoints().length,
            onOpenSessionPicker: _openSessionPicker,
            onPrev: () => _shiftDate(-1),
            onNext: () => _shiftDate(1),
            onToday: () => _setDate(DateTime.now()),
            onPick: _pickDate,
            onPickStart: () => _pickTime(isStart: true),
            onPickEnd: () => _pickTime(isStart: false),
            onClearTime: _clearTimeFilter,
            onToggleMode: (v) {
              setState(() {
                _onlySelectedDate = v;
                _reload++;
              });
              widget.onDebug('Фильтр сессий изменён', {
                'date': _dateIso(_selectedDate),
                'only_date': v,
                'from_time': _timeParam(_startTime),
                'to_time': _timeParam(_endTime),
              });
            },
          ),
          _TabStrip(
            selected: _tab,
            onSelect: (i) {
              setState(() => _tab = i);
              widget.onDebug('GPS-аналитика вкладка', {'tab': i, 'label': _tabs[i].label});
            },
          ),
          Expanded(
            child: FutureBuilder<_AnalyticsBundle>(
              key: ValueKey('gps_analytics_${widget.teamId}_${widget.selectedPlayer?.id ?? 0}_${widget.selectedField?.id ?? 0}_${_dateIso(_selectedDate)}_${_timeParam(_startTime) ?? 'all'}_${_timeParam(_endTime) ?? 'all'}_${widget.selectedSession?.id ?? 0}_${_useAllSessionsForPeriod ? 'all' : _selectedSessionIds.join('-')}_$_reload'),
              future: _loadBundle(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting && snapshot.data == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                if (snapshot.hasError) {
                  return _ErrorBox(error: '${snapshot.error}', onRetry: _refresh);
                }
                final bundle = snapshot.data ?? _AnalyticsBundle.empty();
                final visibleLocalPoints = _visibleLocalPoints();
                final analysisPoints = widget.liveRunning ? visibleLocalPoints : (bundle.sessionPoints.isNotEmpty ? bundle.sessionPoints : visibleLocalPoints);
                final effectiveSelectedSession = _effectiveSelectedSession(bundle.sessions);
                final local = _LocalTrackAnalysis.fromPoints(analysisPoints, sprintThresholdKmh: _sprintThresholdKmh, hsrThresholdKmh: _hsrThresholdKmh);
                switch (_tab) {
                  case 0:
                    return _OverviewTab(
                      compact: compact,
                      bundle: bundle,
                      local: local,
                      selectedPlayer: widget.selectedPlayer,
                      selectedField: widget.selectedField,
                      selectedSession: effectiveSelectedSession,
                      heatmap: bundle.heatmap,
                      usingLatestFallback: bundle.usingLatestFallback,
                      fallbackMessage: bundle.fallbackMessage,
                      onOpenCalibration: widget.onOpenCalibration,
                      onOpenSessions: widget.onOpenSessions,
                    );
                  case 1:
                    return _MapTab(
                      points: bundle.heatmap,
                      localPoints: analysisPoints,
                      field: widget.selectedField,
                      selectedPlayer: widget.selectedPlayer,
                      selectedSession: effectiveSelectedSession,
                      heatMode: _showHeatMapMode,
                      onHeatModeChanged: (v) => setState(() => _showHeatMapMode = v),
                      sprintThresholdKmh: _sprintThresholdKmh,
                      hsrThresholdKmh: _hsrThresholdKmh,
                      showSprintArrows: _showSprintArrows,
                      mapRotationDeg: _mapRotationDeg,
                      onOpenCalibration: widget.onOpenCalibration,
                    );
                  case 2:
                    return _SprintsTab(
                      bundle: bundle,
                      local: local,
                      localPoints: analysisPoints,
                      selectedSession: effectiveSelectedSession,
                      sprintThresholdKmh: _sprintThresholdKmh,
                      hsrThresholdKmh: _hsrThresholdKmh,
                      showSprintArrows: _showSprintArrows,
                      mapRotationDeg: _mapRotationDeg,
                    );
                  case 3:
                    return _SpeedTab(
                      bundle: bundle,
                      local: local,
                      selectedSession: effectiveSelectedSession,
                      hsrThresholdKmh: _hsrThresholdKmh,
                      sprintThresholdKmh: _sprintThresholdKmh,
                    );
                  case 4:
                    return _HeartRateAnalyticsTab(
                      heartRate: bundle.heartRate,
                      selectedPlayer: widget.selectedPlayer,
                    );
                  case 5:
                    return _TeamTab(
                      bundle: bundle,
                      selectedSession: effectiveSelectedSession,
                      local: local,
                      players: widget.players,
                      selectedPlayer: widget.selectedPlayer,
                      onSelectPlayer: widget.onSelectPlayer,
                    );
                  case 6:
                    return _RatingsTab(
                      bundle: bundle,
                      local: local,
                      teamName: widget.teamName,
                      selectedPlayer: widget.selectedPlayer,
                      selectedSession: effectiveSelectedSession,
                    );
                  case 7:
                    return _OfflineTab(
                      liveRunning: widget.liveRunning,
                      commandChannelReady: widget.commandChannelReady,
                      offlineRecordsCount: widget.offlineRecordsCount,
                      localPointsCount: widget.localPointsCount,
                      offlineGpsMode: _offlineGpsMode,
                      onToggleOfflineGpsMode: (v) {
                        setState(() => _offlineGpsMode = v);
                        widget.onDebug('Офлайн GPS режим изменён', {'enabled': v});
                      },
                      onRequestOfflineRecords: widget.onRequestOfflineRecords,
                      onSaveOfflineSession: widget.onSaveOfflineSession,
                      onOpenSessions: widget.onOpenSessions,
                    );
                  default:
                    return _SettingsTab(
                      field: widget.selectedField,
                      gpsOffsetFix: _gpsOffsetFix,
                      gpsOffsetMode: _gpsOffsetMode,
                      linearDepth: _linearDepth,
                      mapRotationDeg: _mapRotationDeg,
                      sprintThresholdKmh: _sprintThresholdKmh,
                      hsrThresholdKmh: _hsrThresholdKmh,
                      showSprintArrows: _showSprintArrows,
                      onOpenCalibration: widget.onOpenCalibration,
                      onSettingsChanged: ({bool? gpsOffsetFix, String? gpsOffsetMode, double? linearDepth, double? mapRotationDeg, double? sprintThresholdKmh, double? hsrThresholdKmh, bool? showSprintArrows}) {
                        setState(() {
                          if (gpsOffsetFix != null) _gpsOffsetFix = gpsOffsetFix;
                          if (gpsOffsetMode != null) _gpsOffsetMode = gpsOffsetMode;
                          if (linearDepth != null) _linearDepth = linearDepth;
                          if (mapRotationDeg != null) _mapRotationDeg = mapRotationDeg;
                          if (sprintThresholdKmh != null) _sprintThresholdKmh = sprintThresholdKmh;
                          if (hsrThresholdKmh != null) _hsrThresholdKmh = hsrThresholdKmh;
                          if (showSprintArrows != null) _showSprintArrows = showSprintArrows;
                        });
                        widget.onDebug('Настройки аналитики изменены', {
                          'gps_offset_fix': _gpsOffsetFix,
                          'gps_offset_mode': _gpsOffsetMode,
                          'linear_depth': _linearDepth,
                          'map_rotation_deg': _mapRotationDeg,
                          'sprint_threshold_kmh': _sprintThresholdKmh,
                          'hsr_threshold_kmh': _hsrThresholdKmh,
                          'show_sprint_arrows': _showSprintArrows,
                        });
                      },
                      onDebug: widget.onDebug,
                    );
                }
              },
            ),
          ),
        ],
      ),
    );
  }


  String _sessionFilterLabel() {
    if (_useAllSessionsForPeriod || _selectedSessionIds.isEmpty) return 'все за период';
    if (_selectedSessionIds.length == 1) {
      final id = _selectedSessionIds.first;
      return '#$id';
    }
    return '${_selectedSessionIds.length} выбрано';
  }

  List<TrackerSessionModel> _activeSessions(List<TrackerSessionModel> sessions) {
    // Даже в режиме «все за период» мы храним конкретный набор id, который
    // получился после фильтра по дате/игрокам. Иначе аналитика снова берёт
    // чужие/последние сессии и рейтинг выглядит одинаковым.
    if (_selectedSessionIds.isNotEmpty) {
      final selected = sessions.where((s) => _selectedSessionIds.contains(s.id)).toList(growable: false);
      if (selected.isNotEmpty) return selected;
    }
    return sessions;
  }

  int? _singleSelectedSessionId(List<TrackerSessionModel> sessions) {
    final active = _activeSessions(sessions);
    if (active.length == 1) return active.first.id;
    return null;
  }

  String _dateIso(DateTime d) {
    final local = DateTime(d.year, d.month, d.day);
    return '${local.year.toString().padLeft(4, '0')}-${local.month.toString().padLeft(2, '0')}-${local.day.toString().padLeft(2, '0')}';
  }

  void _setDate(DateTime value) {
    setState(() {
      _selectedDate = DateTime(value.year, value.month, value.day);
      _useAllSessionsForPeriod = true;
      _selectedSessionIds.clear();
      _reload++;
    });
    widget.onDebug('Календарь сессий: дата выбрана', {
      'date': _dateIso(_selectedDate),
      'only_date': _onlySelectedDate,
      'session_filter_reset': true,
    });
  }

  void _shiftDate(int days) => _setDate(_selectedDate.add(Duration(days: days)));

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate,
      firstDate: DateTime(DateTime.now().year - 3),
      lastDate: DateTime(DateTime.now().year + 1),
      helpText: 'Выберите дату сессий трекера',
      cancelText: 'Отмена',
      confirmText: 'Выбрать',
    );
    if (picked != null) _setDate(picked);
  }

  Future<void> _pickTime({required bool isStart}) async {
    final initial = isStart ? (_startTime ?? const TimeOfDay(hour: 0, minute: 0)) : (_endTime ?? const TimeOfDay(hour: 23, minute: 59));
    final picked = await showTimePicker(
      context: context,
      initialTime: initial,
      helpText: isStart ? 'Начало периода' : 'Конец периода',
      cancelText: 'Отмена',
      confirmText: 'Выбрать',
    );
    if (picked == null) return;
    setState(() {
      if (isStart) {
        _startTime = picked;
      } else {
        _endTime = picked;
      }
      _reload++;
    });
    widget.onDebug('Фильтр времени изменён', {
      'date': _dateIso(_selectedDate),
      'from_time': _timeParam(_startTime),
      'to_time': _timeParam(_endTime),
    });
  }

  void _clearTimeFilter() {
    setState(() {
      _startTime = null;
      _endTime = null;
      _reload++;
    });
    widget.onDebug('Фильтр времени очищен', {'date': _dateIso(_selectedDate)});
  }

  String? _timeParam(TimeOfDay? t) {
    if (t == null) return null;
    return '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  }

  DateTime? _sessionDateTime(TrackerSessionModel session) => _parseServerDateTime(session.createdAt);

  DateTime? _parseServerDateTime(String rawValue) {
    final raw = rawValue.trim();
    if (raw.isEmpty) return null;
    final normalized = raw.replaceFirst(' ', 'T');
    final hasZone = normalized.endsWith('Z') || RegExp(r'[+\-]\d{2}:?\d{2}$').hasMatch(normalized);
    final parsed = hasZone
        ? DateTime.tryParse(normalized)?.toLocal()
        : (DateTime.tryParse(normalized) ?? DateTime.tryParse(raw));
    return parsed;
  }

  bool _isSameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  List<ActionTrackerGpsPoint> _visibleLocalPoints() {
    // Live-точки показываем только если они относятся к выбранному периоду.
    // После остановки Live данные сессии грузятся с сервера через get_tracker_session_points.php,
    // чтобы карта/спринты/теплокарта не зависели от временного локального списка.
    if (widget.liveRunning) return widget.localPoints.where(_pointMatchesDateRange).toList(growable: false);
    if (widget.selectedSession != null) return const <ActionTrackerGpsPoint>[];
    return widget.localPoints.where(_pointMatchesDateRange).toList(growable: false);
  }

  bool _pointMatchesDateRange(ActionTrackerGpsPoint point) {
    if (point.timeMs <= 0) return widget.liveRunning;
    final dt = DateTime.fromMillisecondsSinceEpoch(point.timeMs);
    if (_onlySelectedDate && !_isSameDay(dt, _selectedDate)) return false;
    final start = _startTime;
    final end = _endTime;
    final minutes = dt.hour * 60 + dt.minute;
    if (start != null && minutes < start.hour * 60 + start.minute) return false;
    if (end != null && minutes > end.hour * 60 + end.minute) return false;
    return true;
  }

  bool _sessionMatchesDateRange(TrackerSessionModel session, String dateIso) {
    final raw = session.createdAt.trim();
    if (raw.isEmpty) return false;
    final dt = _sessionDateTime(session);
    if (dt == null) return raw.startsWith(dateIso) || raw.contains(dateIso);
    if (_onlySelectedDate && !_isSameDay(dt, _selectedDate)) return false;
    final start = _startTime;
    final end = _endTime;
    if (start != null) {
      final startMinutes = start.hour * 60 + start.minute;
      final current = dt.hour * 60 + dt.minute;
      if (current < startMinutes) return false;
    }
    if (end != null) {
      final endMinutes = end.hour * 60 + end.minute;
      final current = dt.hour * 60 + dt.minute;
      if (current > endMinutes) return false;
    }
    return true;
  }

  TrackerSessionModel? _effectiveSelectedSession(List<TrackerSessionModel> sessions) {
    final active = _activeSessions(sessions);
    // В режиме «все сессии периода» не подставляем одну сессию в радар/рейтинг.
    // Иначе обзор дня, карта и рейтинг выглядят как одна и та же запись.
    if (_useAllSessionsForPeriod) return null;
    if (active.length == 1) return active.first;
    final current = widget.selectedSession;
    if (current != null) {
      for (final s in active) {
        if (s.id == current.id) return s;
      }
    }
    return active.isNotEmpty ? active.first : (sessions.isNotEmpty ? sessions.first : null);
  }


  TrackerPlayerOption? _playerById(int? id) {
    if (id == null || id <= 0) return null;
    for (final p in widget.players) {
      if (p.id == id) return p;
    }
    return null;
  }

  String _shortPlayerName(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
    if (parts.isEmpty) return 'Игрок';
    if (parts.length == 1) return parts.first;
    final last = parts.first;
    final initial = parts.length > 1 && parts[1].isNotEmpty ? '${parts[1][0]}.' : '';
    return '$last $initial'.trim();
  }

  String _sessionPlayerName(TrackerSessionModel s) {
    final fromPlayer = _playerById(s.playerId)?.name;
    final raw = (s.playerName ?? '').trim();
    final looksGeneric = raw.isEmpty || RegExp(r'^(игрок|player)\s*#?\d+', caseSensitive: false).hasMatch(raw);
    final full = looksGeneric ? (fromPlayer ?? raw) : raw;
    if (full.trim().isEmpty) return s.playerId == null ? 'Игрок' : 'Игрок ${s.playerId}';
    return _shortPlayerName(full);
  }

  String _sessionSearchText(TrackerSessionModel s) {
    final player = _playerById(s.playerId);
    return [
      s.id,
      s.playerId,
      s.playerName,
      player?.name,
      player?.number,
      player?.position,
      s.createdAt,
      s.title,
    ].where((v) => v != null).join(' ').toLowerCase();
  }



  Future<void> _openSessionPicker() async {
    final date = _onlySelectedDate ? _dateIso(_selectedDate) : null;
    final fromTime = _timeParam(_startTime);
    final toTime = _timeParam(_endTime);
    var sessions = await widget.api.loadSessions(
      teamId: widget.teamId,
      playerId: null,
      date: date,
      fromTime: fromTime,
      toTime: toTime,
      limit: 300,
    );
    sessions = sessions.where((s) => _sessionMatchesDateRange(s, date ?? _dateIso(_selectedDate))).toList(growable: false);
    // Важно: если за выбранный день нет записей, показываем пустой список,
    // а не последнюю сессию. Иначе 25 июня может визуально смешиваться с 26 июня.
    const usingLatest = false;
    if (!mounted) return;

    final tempSessions = Set<int>.from(_selectedSessionIds);
    final tempPlayers = <int>{};
    var tempAllSessions = _useAllSessionsForPeriod || tempSessions.isEmpty;
    var query = '';
    var onlyWithData = false;

    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: _AA.card,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(8))),
      builder: (context) {
        return StatefulBuilder(builder: (context, modalSetState) {
          bool sessionHasData(TrackerSessionModel s) =>
              s.distanceM > 0 || s.maxSpeedKmh > 0 || s.sprintCount > 0 || s.accelCount > 0 || s.decelCount > 0 || s.durationSec > 0;

          final playerIdsInSessions = sessions.map((s) => s.playerId).whereType<int>().toSet();
          final players = widget.players.where((p) => playerIdsInSessions.contains(p.id)).toList(growable: false)
            ..sort((a, b) => a.name.compareTo(b.name));
          final selectedCount = tempAllSessions
              ? sessions.where((s) => tempPlayers.isEmpty || tempPlayers.contains(s.playerId)).length
              : tempSessions.length;

          List<TrackerSessionModel> filteredSessions() {
            return sessions.where((s) {
              if (tempPlayers.isNotEmpty && !tempPlayers.contains(s.playerId)) return false;
              if (onlyWithData && !sessionHasData(s)) return false;
              if (query.isNotEmpty && !_sessionSearchText(s).contains(query)) return false;
              return true;
            }).toList(growable: false);
          }

          Widget playerList() {
            final filteredPlayers = players.where((p) {
              if (query.isEmpty) return true;
              final text = '${p.name} ${p.number ?? ''} ${p.position ?? ''} ${p.id}'.toLowerCase();
              return text.contains(query);
            }).toList(growable: false);
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Container(
                height: 34,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                child: Row(children: [
                  const Icon(Icons.groups_rounded, color: _AA.green, size: 16),
                  const SizedBox(width: 7),
                  const Expanded(child: Text('Игроки', style: TextStyle(color: _AA.text, fontSize: 11, fontWeight: FontWeight.w900))),
                  Text(tempPlayers.isEmpty ? 'все' : '${tempPlayers.length}', style: const TextStyle(color: _AA.muted, fontSize: 9.5, fontWeight: FontWeight.w800)),
                ]),
              ),
              Expanded(
                child: filteredPlayers.isEmpty
                    ? const _Empty(icon: Icons.person_search_rounded, text: 'Игроки по фильтру не найдены')
                    : ListView.builder(
                        primary: false,
                        itemCount: filteredPlayers.length,
                        itemBuilder: (context, i) {
                          final p = filteredPlayers[i];
                          final active = tempPlayers.isEmpty || tempPlayers.contains(p.id);
                          final count = sessions.where((s) => s.playerId == p.id).length;
                          return InkWell(
                            onTap: () => modalSetState(() {
                              if (tempPlayers.isEmpty) {
                                tempPlayers.add(p.id);
                              } else if (tempPlayers.contains(p.id)) {
                                tempPlayers.remove(p.id);
                              } else {
                                tempPlayers.add(p.id);
                              }
                              tempAllSessions = true;
                            }),
                            child: Container(
                              height: 46,
                              padding: const EdgeInsets.symmetric(horizontal: 10),
                              decoration: BoxDecoration(color: active ? _AA.greenSoft : _AA.card, border: const Border(bottom: BorderSide(color: _AA.line))),
                              child: Row(children: [
                                _SessionAvatar(player: p),
                                const SizedBox(width: 8),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Text(_shortPlayerName(p.name), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10.3, fontWeight: FontWeight.w900)),
                                  Text('${p.number == null ? '' : '№${p.number} · '}${p.position ?? 'позиция не указана'} · $count сесс.', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
                                ])),
                                Icon(active ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, size: 16, color: active ? _AA.green : _AA.muted),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
            ]);
          }

          Widget sessionList() {
            final filtered = filteredSessions();
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Container(
                height: 34,
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                child: Row(children: [
                  const Icon(Icons.fact_check_rounded, color: _AA.green, size: 16),
                  const SizedBox(width: 7),
                  Expanded(child: Text(usingLatest ? 'Последние сессии' : 'Сессии периода', style: const TextStyle(color: _AA.text, fontSize: 11, fontWeight: FontWeight.w900))),
                  Text('$selectedCount выбрано', style: const TextStyle(color: _AA.green, fontSize: 9.5, fontWeight: FontWeight.w900)),
                ]),
              ),
              Expanded(
                child: filtered.isEmpty
                    ? const _Empty(icon: Icons.event_busy_rounded, text: 'Сессии не найдены')
                    : ListView.builder(
                        primary: false,
                        itemCount: filtered.length,
                        itemBuilder: (context, i) {
                          final s = filtered[i];
                          final player = _playerById(s.playerId);
                          final checked = tempAllSessions || tempSessions.contains(s.id);
                          return InkWell(
                            onTap: () => modalSetState(() {
                              tempAllSessions = false;
                              if (tempSessions.contains(s.id)) {
                                tempSessions.remove(s.id);
                              } else {
                                tempSessions.add(s.id);
                              }
                            }),
                            child: Container(
                              constraints: const BoxConstraints(minHeight: 52),
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                              child: Row(children: [
                                Icon(checked ? Icons.check_box_rounded : Icons.check_box_outline_blank_rounded, color: checked ? _AA.green : _AA.muted, size: 18),
                                const SizedBox(width: 7),
                                _SessionAvatar(player: player),
                                const SizedBox(width: 8),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                                  Text('#${s.id} · ${_sessionPlayerName(s)} · ${_formatSessionDateTime(s.createdAt)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10.3, fontWeight: FontWeight.w900)),
                                  Text('${player?.position ?? ''}${player?.number == null ? '' : ' · №${player!.number}'} · ${_meters(s.distanceM)} · max ${s.maxSpeedKmh.toStringAsFixed(1)} км/ч · ${s.sprintCount} спринтов · уск/торм ${s.accelCount}/${s.decelCount}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
                                ])),
                              ]),
                            ),
                          );
                        },
                      ),
              ),
            ]);
          }

          final wide = MediaQuery.sizeOf(context).width >= 860;
          final content = wide
              ? Row(children: [Expanded(flex: 5, child: sessionList()), const VerticalDivider(width: 1, color: _AA.line), Expanded(flex: 3, child: playerList())])
              : Column(children: [SizedBox(height: 170, child: playerList()), const Divider(height: 1, color: _AA.line), Expanded(child: sessionList())]);

          return SafeArea(
            child: SizedBox(
              height: MediaQuery.sizeOf(context).height * .82,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Container(
                  height: 44,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                  child: Row(children: [
                    const Icon(Icons.fact_check_rounded, color: _AA.green, size: 18),
                    const SizedBox(width: 8),
                    const Expanded(child: Text('Выбор сессий и игроков', style: TextStyle(color: _AA.text, fontSize: 12.4, fontWeight: FontWeight.w900))),
                    Text('$selectedCount выбрано', style: const TextStyle(color: _AA.green, fontSize: 10, fontWeight: FontWeight.w900)),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, size: 18)),
                  ]),
                ),
                if (usingLatest) const _InlineNotice(text: 'На выбранную дату/время нет сессий. Показаны последние сохранённые записи.'),
                Container(
                  height: 40,
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    _SmallButton(icon: Icons.done_all_rounded, label: 'Все за день', primary: tempAllSessions && tempPlayers.isEmpty, onTap: () => modalSetState(() { tempAllSessions = true; tempSessions.clear(); tempPlayers.clear(); })),
                    const SizedBox(width: 6),
                    _SmallButton(icon: Icons.person_rounded, label: 'Текущий игрок', onTap: () => modalSetState(() { tempPlayers..clear()..addAll(widget.selectedPlayer == null ? const <int>[] : <int>[widget.selectedPlayer!.id]); tempAllSessions = true; tempSessions.clear(); })),
                    const SizedBox(width: 6),
                    _SmallButton(icon: Icons.filter_alt_rounded, label: onlyWithData ? 'С данными' : 'Только с данными', primary: onlyWithData, onTap: () => modalSetState(() => onlyWithData = !onlyWithData)),
                    const SizedBox(width: 6),
                    _SmallButton(icon: Icons.cleaning_services_rounded, label: 'Очистить', onTap: () => modalSetState(() { tempAllSessions = false; tempSessions.clear(); tempPlayers.clear(); })),
                  ]),
                ),
                Container(
                  height: 42,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
                  child: TextField(
                    onChanged: (value) => modalSetState(() => query = value.trim().toLowerCase()),
                    style: const TextStyle(color: _AA.text, fontSize: 10.5, fontWeight: FontWeight.w700),
                    decoration: InputDecoration(
                      isDense: true,
                      prefixIcon: const Icon(Icons.search_rounded, size: 16, color: _AA.muted),
                      prefixIconConstraints: const BoxConstraints(minWidth: 30, minHeight: 24),
                      hintText: 'Поиск по игроку, номеру, позиции или ID сессии',
                      hintStyle: const TextStyle(color: _AA.muted, fontSize: 10, fontWeight: FontWeight.w600),
                      contentPadding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(5), borderSide: const BorderSide(color: _AA.line)),
                      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(5), borderSide: const BorderSide(color: _AA.line)),
                      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(5), borderSide: const BorderSide(color: _AA.green)),
                    ),
                  ),
                ),
                Expanded(child: content),
                Container(
                  height: 46,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                  decoration: const BoxDecoration(border: Border(top: BorderSide(color: _AA.line))),
                  child: Row(children: [
                    Expanded(child: Text(tempAllSessions ? 'Будут учтены все сессии выбранных игроков.' : 'Будут учтены отмеченные сессии.', style: const TextStyle(color: _AA.muted, fontSize: 9.2, fontWeight: FontWeight.w700))),
                    _SmallButton(icon: Icons.check_rounded, label: 'Применить', primary: true, onTap: () {
                      final filtered = filteredSessions();
                      setState(() {
                        _useAllSessionsForPeriod = tempAllSessions || tempSessions.isEmpty;
                        _selectedSessionIds
                          ..clear()
                          ..addAll(_useAllSessionsForPeriod ? filtered.map((s) => s.id) : tempSessions);
                        if (_selectedSessionIds.isEmpty && filtered.isNotEmpty) _selectedSessionIds.addAll(filtered.map((s) => s.id));
                        _reload++;
                      });
                      final chosen = sessions.where((s) => _selectedSessionIds.contains(s.id)).toList(growable: false);
                      if (chosen.length == 1) widget.onSelectSession(chosen.first);
                      if (chosen.length > 1) widget.onSelectSession(chosen.first);
                      widget.onDebug('Выбраны сессии и игроки аналитики', {
                        'all_period': _useAllSessionsForPeriod,
                        'session_ids': _selectedSessionIds.toList(),
                        'player_ids': tempPlayers.toList(),
                        'date': date,
                        'from_time': fromTime,
                        'to_time': toTime,
                      });
                      Navigator.pop(context);
                    }),
                  ]),
                ),
              ]),
            ),
          );
        });
      },
    );
  }


  List<TrackerHeatPoint> _heatmapFromGps(List<ActionTrackerGpsPoint> points, TrackerFieldModel? field) {
    return _heatmapFromGpsStatic(points, field);
  }


  Future<_AnalyticsBundle> _loadBundle() async {
    try {
      final date = _onlySelectedDate ? _dateIso(_selectedDate) : null;
      final fromTime = _timeParam(_startTime);
      final toTime = _timeParam(_endTime);

      var dashboard = await widget.api.loadDashboard(teamId: widget.teamId, date: date, fromTime: fromTime, toTime: toTime);
      final rawSessions = await widget.api.loadSessions(
        teamId: widget.teamId,
        playerId: null,
        date: date,
        fromTime: fromTime,
        toTime: toTime,
        limit: _onlySelectedDate ? 300 : 700,
      );

      var sessions = date == null
          ? rawSessions.where((s) => _sessionMatchesDateRange(s, _dateIso(_selectedDate))).toList(growable: false)
          : rawSessions.where((s) => _sessionMatchesDateRange(s, date)).toList(growable: false);
      final widgetSession = widget.selectedSession;
      if (widgetSession != null && widgetSession.id > 0 && _selectedSessionIds.contains(widgetSession.id) && !sessions.any((s) => s.id == widgetSession.id)) {
        sessions = <TrackerSessionModel>[widgetSession, ...sessions];
      }

      const usingLatestFallback = false;
      const fallbackMessage = '';

      // Если за выбранную дату/время пусто — оставляем период пустым.
      // Не подставляем последнюю сессию, чтобы отчёт и карта не показывали чужой день.
      if (sessions.isEmpty && !widget.liveRunning && _onlySelectedDate) {
        dashboard = const TrackerDashboardModel(summary: <String, dynamic>{}, players: <TrackerPlayerLoadRow>[], alerts: <Map<String, dynamic>>[]);
      }

      final activeSessions = _activeSessions(sessions);
      final singleSessionId = _singleSelectedSessionId(sessions);
      final selectedSessionIds = (!_useAllSessionsForPeriod && activeSessions.isNotEmpty)
          ? activeSessions.map((s) => s.id).where((id) => id > 0).toList(growable: false)
          : const <int>[];

      List<ActionTrackerGpsPoint> sessionPoints = const <ActionTrackerGpsPoint>[];
      if (!widget.liveRunning) {
        if (selectedSessionIds.length > 1) {
          final chunks = await Future.wait(selectedSessionIds.map((id) => widget.api.loadSessionPoints(
                teamId: widget.teamId,
                playerId: null,
                sessionId: id,
              )));
          sessionPoints = chunks.expand((e) => e).toList(growable: false)
            ..sort((a, b) => a.timeMs.compareTo(b.timeMs));
        } else {
          sessionPoints = await widget.api.loadSessionPoints(
            teamId: widget.teamId,
            playerId: selectedSessionIds.length == 1 ? null : widget.selectedPlayer?.id,
            sessionId: singleSessionId,
            date: singleSessionId != null ? null : date,
            fromTime: singleSessionId != null ? null : fromTime,
            toTime: singleSessionId != null ? null : toTime,
          );
        }
      }

      final heat = sessionPoints.isNotEmpty
          ? const <TrackerHeatPoint>[]
          : (activeSessions.isEmpty && !widget.liveRunning
              ? const <TrackerHeatPoint>[]
              : await widget.api.loadHeatmap(
                  teamId: widget.teamId,
                  playerId: widget.selectedPlayer?.id,
                  sessionId: singleSessionId,
                  fieldId: null,
                  date: singleSessionId != null ? null : date,
                  fromTime: singleSessionId != null ? null : fromTime,
                  toTime: singleSessionId != null ? null : toTime,
                ));
      final gpsHeat = _heatmapFromGps(sessionPoints, widget.selectedField);
      final effectiveHeat = _isHeatCollapsed(heat) ? gpsHeat : (heat.isNotEmpty ? heat : gpsHeat);
      final hrSessionIds = singleSessionId == null
          ? activeSessions.map((s) => s.id).where((id) => id > 0).toList(growable: false)
          : const <int>[];
      final hrJson = await widget.api.loadHeartRateSummary(
        teamId: widget.teamId,
        playerId: widget.selectedPlayer?.id,
        sessionId: singleSessionId,
        sessionIds: hrSessionIds,
        date: (singleSessionId == null && hrSessionIds.isEmpty) ? date : null,
        fromTime: (singleSessionId == null && hrSessionIds.isEmpty) ? fromTime : null,
        toTime: (singleSessionId == null && hrSessionIds.isEmpty) ? toTime : null,
      );
      final heartRate = _AnalyticsHeartRate.fromJson(hrJson);
      return _AnalyticsBundle(
        dashboard: dashboard,
        sessions: activeSessions.isNotEmpty ? activeSessions : sessions,
        heatmap: effectiveHeat,
        sessionPoints: sessionPoints,
        heartRate: heartRate,
        usingLatestFallback: usingLatestFallback,
        fallbackMessage: fallbackMessage,
      );
    } catch (e) {
      // Аналитика не должна закрывать весь экран из-за одной ошибки API.
      // Серверная причина остаётся видна в debug/console, а UI показывает пустой период.
      // ignore: avoid_print
      print('[TRACKER_ANALYTICS_BUNDLE] fallback: $e');
      return _AnalyticsBundle.empty();
    }
  }

}



List<TrackerHeatPoint> _heatmapFromGpsStatic(List<ActionTrackerGpsPoint> points, TrackerFieldModel? field) {
  if (points.length < 2) return const <TrackerHeatPoint>[];

  List<TrackerHeatPoint> buildFromOffsets(List<Offset> offsets) {
    final buckets = <String, double>{};
    for (final o in offsets) {
      final x = (o.dx.clamp(0.0, 1.0) * 105.0).toDouble();
      final y = (o.dy.clamp(0.0, 1.0) * 68.0).toDouble();
      final key = '${x.toStringAsFixed(1)}:${y.toStringAsFixed(1)}';
      buckets[key] = (buckets[key] ?? 0) + 1;
    }
    return buckets.entries.map((e) {
      final parts = e.key.split(':');
      return TrackerHeatPoint(
        x: double.tryParse(parts[0]) ?? 0,
        y: double.tryParse(parts[1]) ?? 0,
        value: e.value,
      );
    }).toList(growable: false);
  }

  if (_shouldUseFieldProjection(points, field)) {
    final projected = <Offset>[];
    for (final p in points) {
      final q = TrackerPitchProjector.projectGps(field, latitude: p.latitude, longitude: p.longitude);
      if (q != null) projected.add(Offset(q.clampedNx, q.clampedNy));
    }
    if (projected.length >= 2) return buildFromOffsets(projected);
  }

  final bounds = _Bounds.fromGps(points);
  final offsets = points.map((p) {
    final x = ((p.longitude - bounds.minLng) / (bounds.maxLng - bounds.minLng)).clamp(0.0, 1.0).toDouble();
    final y = (1 - ((p.latitude - bounds.minLat) / (bounds.maxLat - bounds.minLat)).clamp(0.0, 1.0)).toDouble();
    return Offset(x, y);
  }).toList(growable: false);
  return buildFromOffsets(offsets);
}

bool _isHeatCollapsed(List<TrackerHeatPoint> points) {
  if (points.length < 2) return points.isNotEmpty;
  var minX = points.first.x, maxX = points.first.x, minY = points.first.y, maxY = points.first.y;
  var total = 0.0;
  for (final p in points) {
    minX = math.min(minX, p.x); maxX = math.max(maxX, p.x);
    minY = math.min(minY, p.y); maxY = math.max(maxY, p.y);
    total += p.value;
  }
  return total > 0 && ((maxX - minX).abs() < 1.0 && (maxY - minY).abs() < 1.0);
}


String _formatSessionDateTime(String raw) {
  final dt = _parseTrackerDateTime(raw);
  if (dt == null) return raw.isEmpty ? 'без времени' : raw;
  return '${dt.day.toString().padLeft(2, '0')}.${dt.month.toString().padLeft(2, '0')}.${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
}

DateTime? _parseTrackerDateTime(String rawValue) {
  final raw = rawValue.trim();
  if (raw.isEmpty) return null;
  final normalized = raw.replaceFirst(' ', 'T');
  final hasZone = normalized.endsWith('Z') || RegExp(r'[+\-]\d{2}:?\d{2}$').hasMatch(normalized);
  final parsed = hasZone
      ? DateTime.tryParse(normalized)?.toLocal()
      : (DateTime.tryParse(normalized) ?? DateTime.tryParse(raw));
  return parsed;
}

class _AnalyticsBundle {
  const _AnalyticsBundle({
    required this.dashboard,
    required this.sessions,
    required this.heatmap,
    required this.sessionPoints,
    required this.heartRate,
    this.usingLatestFallback = false,
    this.fallbackMessage = '',
  });

  final TrackerDashboardModel dashboard;
  final List<TrackerSessionModel> sessions;
  final List<TrackerHeatPoint> heatmap;
  final List<ActionTrackerGpsPoint> sessionPoints;
  final _AnalyticsHeartRate heartRate;
  final bool usingLatestFallback;
  final String fallbackMessage;

  factory _AnalyticsBundle.empty() => _AnalyticsBundle(
        dashboard: const TrackerDashboardModel(summary: <String, dynamic>{}, players: <TrackerPlayerLoadRow>[], alerts: <Map<String, dynamic>>[]),
        sessions: <TrackerSessionModel>[],
        heatmap: <TrackerHeatPoint>[],
        sessionPoints: <ActionTrackerGpsPoint>[],
        heartRate: _AnalyticsHeartRate.empty(),
      );
}


class _AnalyticsHeartRate {
  const _AnalyticsHeartRate({required this.players, required this.timeline, required this.avgBpm, required this.maxBpm, required this.samplesCount, required this.playersCount});
  final List<_AnalyticsHrPlayer> players;
  final List<_AnalyticsHrPoint> timeline;
  final double avgBpm;
  final int maxBpm;
  final int samplesCount;
  final int playersCount;

  factory _AnalyticsHeartRate.empty() => const _AnalyticsHeartRate(players: <_AnalyticsHrPlayer>[], timeline: <_AnalyticsHrPoint>[], avgBpm: 0, maxBpm: 0, samplesCount: 0, playersCount: 0);

  factory _AnalyticsHeartRate.fromJson(Map<String, dynamic> json) {
    final summary = Map<String, dynamic>.from(json['summary'] as Map? ?? const {});
    final rawPlayers = json['items'] as List? ?? const [];
    final rawTimeline = json['timeline'] as List? ?? json['heart_rate_timeline'] as List? ?? const [];
    final players = rawPlayers.whereType<Map>().map((e) => _AnalyticsHrPlayer.fromJson(Map<String, dynamic>.from(e))).where((p) => p.samplesCount > 0).toList(growable: false);
    final timeline = rawTimeline.whereType<Map>().map((e) => _AnalyticsHrPoint.fromJson(Map<String, dynamic>.from(e))).where((p) => p.bpm > 0).toList(growable: false)
      ..sort((a, b) => (a.timeMs > 0 ? a.timeMs : a.minute).compareTo(b.timeMs > 0 ? b.timeMs : b.minute));
    return _AnalyticsHeartRate(
      players: players,
      timeline: timeline,
      avgBpm: _jsonDouble(summary['avg_bpm']),
      maxBpm: _jsonInt(summary['max_bpm']),
      samplesCount: _jsonInt(summary['samples_count']),
      playersCount: _jsonInt(summary['players_count']),
    );
  }
}

class _AnalyticsHrPlayer {
  const _AnalyticsHrPlayer({required this.playerId, required this.playerName, required this.avgBpm, required this.maxBpm, required this.samplesCount, required this.z1, required this.z2, required this.z3, required this.z4, required this.z5});
  final int? playerId;
  final String playerName;
  final double avgBpm;
  final int maxBpm;
  final int samplesCount;
  final int z1;
  final int z2;
  final int z3;
  final int z4;
  final int z5;

  factory _AnalyticsHrPlayer.fromJson(Map<String, dynamic> json) => _AnalyticsHrPlayer(
        playerId: int.tryParse('${json['player_id'] ?? ''}'),
        playerName: '${json['player_name'] ?? json['name'] ?? 'Игрок'}',
        avgBpm: _jsonDouble(json['avg_bpm'] ?? json['heart_rate_avg_bpm']),
        maxBpm: _jsonInt(json['max_bpm'] ?? json['heart_rate_max_bpm']),
        samplesCount: _jsonInt(json['samples_count'] ?? json['heart_rate_samples_count']),
        z1: _jsonInt(json['z1'] ?? json['hr_z1_samples']),
        z2: _jsonInt(json['z2'] ?? json['hr_z2_samples']),
        z3: _jsonInt(json['z3'] ?? json['hr_z3_samples']),
        z4: _jsonInt(json['z4'] ?? json['hr_z4_samples']),
        z5: _jsonInt(json['z5'] ?? json['hr_z5_samples']),
      );
}

class _AnalyticsHrPoint {
  const _AnalyticsHrPoint({required this.playerId, required this.playerName, required this.timeMs, required this.minute, required this.bpm, required this.zone, required this.hrLoad});
  final int? playerId;
  final String playerName;
  final int timeMs;
  final int minute;
  final int bpm;
  final String zone;
  final double hrLoad;

  factory _AnalyticsHrPoint.fromJson(Map<String, dynamic> json) => _AnalyticsHrPoint(
        playerId: int.tryParse('${json['player_id'] ?? ''}'),
        playerName: '${json['player_name'] ?? json['name'] ?? ''}',
        timeMs: _jsonInt(json['time_ms'] ?? json['timestamp_ms']),
        minute: _jsonInt(json['minute'] ?? json['minute_index']),
        bpm: _jsonInt(json['bpm'] ?? json['hr'] ?? json['heart_rate']),
        zone: '${json['hr_zone'] ?? json['zone'] ?? ''}'.toLowerCase(),
        hrLoad: _jsonDouble(json['hr_load'] ?? json['load'] ?? json['hr_exertion']),
      );
}

int _jsonInt(dynamic value, [int fallback = 0]) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}

double _jsonDouble(dynamic value, [double fallback = 0]) {
  if (value is num) return value.toDouble();
  return double.tryParse('$value'.replaceAll(',', '.')) ?? fallback;
}

class _HeartRateAnalyticsTab extends StatelessWidget {
  const _HeartRateAnalyticsTab({required this.heartRate, required this.selectedPlayer});
  final _AnalyticsHeartRate heartRate;
  final TrackerPlayerOption? selectedPlayer;

  @override
  Widget build(BuildContext context) {
    final title = selectedPlayer == null ? 'Polar H10 / команда' : 'Polar H10 / ${selectedPlayer!.name}';
    if (heartRate.samplesCount <= 0 && heartRate.timeline.isEmpty && heartRate.players.isEmpty) {
      return const _Empty(icon: Icons.favorite_border_rounded, text: 'По выбранному периоду нет данных Polar H10. Проверьте привязку датчика и время сессии.');
    }
    return LayoutBuilder(builder: (context, c) {
      final compact = c.maxWidth < 900;
      final summary = _HeartRateSummaryPanel(heartRate: heartRate);
      final chart = _Panel(title: 'Пульс по времени', subtitle: 'красная линия — bpm, тёмная — нагрузка по ЧСС', child: _AnalyticsHrLineChart(heartRate: heartRate));
      final zones = _Panel(title: 'Зоны ЧСС', subtitle: 'распределение по Z1–Z5 без вертикальных столбцов', child: _AnalyticsHrZonesPanel(heartRate: heartRate));
      final players = _Panel(title: title, subtitle: 'игроки с Polar H10', child: _AnalyticsHrPlayersList(heartRate: heartRate));
      if (compact) {
        return ListView(padding: const EdgeInsets.all(8), children: [
          SizedBox(height: 96, child: summary),
          const SizedBox(height: 8),
          SizedBox(height: 300, child: chart),
          const SizedBox(height: 8),
          SizedBox(height: 190, child: zones),
          const SizedBox(height: 8),
          SizedBox(height: 260, child: players),
        ]);
      }
      return Row(children: [
        Expanded(flex: 6, child: Column(children: [Expanded(flex: 2, child: summary), Expanded(flex: 7, child: chart)])),
        Expanded(flex: 4, child: Column(children: [Expanded(flex: 4, child: zones), Expanded(flex: 6, child: players)])),
      ]);
    });
  }
}

class _HeartRateSummaryPanel extends StatelessWidget {
  const _HeartRateSummaryPanel({required this.heartRate});
  final _AnalyticsHeartRate heartRate;
  @override
  Widget build(BuildContext context) => _Panel(
        title: 'Сводка ЧСС',
        subtitle: 'средний, максимум, записи, игроки',
        child: Row(children: [
          Expanded(child: _MiniNumber(title: 'Средний', value: heartRate.avgBpm > 0 ? heartRate.avgBpm.toStringAsFixed(0) : '—', note: 'bpm')),
          Expanded(child: _MiniNumber(title: 'Максимум', value: heartRate.maxBpm > 0 ? '${heartRate.maxBpm}' : '—', note: 'bpm')),
          Expanded(child: _MiniNumber(title: 'HR-записи', value: '${heartRate.samplesCount}', note: 'точек')),
          Expanded(child: _MiniNumber(title: 'Игроки', value: '${heartRate.playersCount}', note: 'Polar')),
        ]),
      );
}

class _AnalyticsHrLineChart extends StatelessWidget {
  const _AnalyticsHrLineChart({required this.heartRate});
  final _AnalyticsHeartRate heartRate;
  @override
  Widget build(BuildContext context) {
    if (heartRate.timeline.isEmpty) return const _Empty(icon: Icons.show_chart_rounded, text: 'Таймлайн ЧСС пока не получен. Нажмите Обновить после завершения Live или проверьте endpoint get_tracker_heart_rate_summary.php.');
    return ClipRect(child: CustomPaint(painter: _AnalyticsHrLinePainter(points: heartRate.timeline), child: const SizedBox.expand()));
  }
}

class _AnalyticsHrZonesPanel extends StatelessWidget {
  const _AnalyticsHrZonesPanel({required this.heartRate});
  final _AnalyticsHeartRate heartRate;
  @override
  Widget build(BuildContext context) {
    final z = <int>[
      heartRate.players.fold<int>(0, (a, p) => a + p.z1),
      heartRate.players.fold<int>(0, (a, p) => a + p.z2),
      heartRate.players.fold<int>(0, (a, p) => a + p.z3),
      heartRate.players.fold<int>(0, (a, p) => a + p.z4),
      heartRate.players.fold<int>(0, (a, p) => a + p.z5),
    ];
    final total = z.fold<int>(0, (a, b) => a + b);
    if (total <= 0) return const _Empty(icon: Icons.favorite_border_rounded, text: 'Зоны ЧСС пока не рассчитаны.');
    const labels = ['Z1', 'Z2', 'Z3', 'Z4', 'Z5'];
    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        for (var i = 0; i < z.length; i++) ...[
          Row(children: [
            SizedBox(width: 28, child: Text(labels[i], style: const TextStyle(color: _AA.text, fontSize: 10, fontWeight: FontWeight.w900))),
            Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(99), child: Stack(children: [Container(height: 12, color: const Color(0xFFF3F4F6)), FractionallySizedBox(widthFactor: (z[i] / total).clamp(0.0, 1.0).toDouble(), child: Container(height: 12, color: _analyticsZoneColor(labels[i].toLowerCase())))]))),
            const SizedBox(width: 8),
            SizedBox(width: 52, child: Text('${(z[i] / total * 100).toStringAsFixed(0)}%', textAlign: TextAlign.right, style: const TextStyle(color: _AA.muted, fontSize: 9, fontWeight: FontWeight.w900))),
          ]),
          if (i != z.length - 1) const SizedBox(height: 9),
        ],
      ]),
    );
  }
}

class _AnalyticsHrPlayersList extends StatelessWidget {
  const _AnalyticsHrPlayersList({required this.heartRate});
  final _AnalyticsHeartRate heartRate;
  @override
  Widget build(BuildContext context) {
    if (heartRate.players.isEmpty) return const _Empty(icon: Icons.groups_rounded, text: 'Нет игроков с Polar H10.');
    return ListView.separated(
      itemCount: heartRate.players.length,
      separatorBuilder: (_, __) => const Divider(height: 1, color: _AA.line),
      itemBuilder: (context, i) {
        final p = heartRate.players[i];
        final high = p.z4 + p.z5;
        final highPct = p.samplesCount <= 0 ? 0 : high / p.samplesCount;
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          child: Row(children: [
            Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(9), border: Border.all(color: _AA.greenLine)), child: const Icon(Icons.favorite_rounded, color: _AA.red, size: 16)),
            const SizedBox(width: 8),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(p.playerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10.8, fontWeight: FontWeight.w900)),
              Text('средний ${p.avgBpm.toStringAsFixed(0)} bpm · максимум ${p.maxBpm} · Z4/Z5 ${(highPct * 100).toStringAsFixed(0)}%', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
            ])),
          ]),
        );
      },
    );
  }
}

Color _analyticsZoneColor(String zone) {
  switch (zone) {
    case 'z5': return const Color(0xFFE11D48);
    case 'z4': return const Color(0xFFF97316);
    case 'z3': return const Color(0xFFFACC15);
    case 'z2': return const Color(0xFF84CC16);
    default: return const Color(0xFFA3E635);
  }
}

abstract class _BaseChartPainter extends CustomPainter {
  void drawGrid(Canvas canvas, Rect rect, {int lines = 5}) {
    final paint = Paint()
      ..color = _AA.line
      ..strokeWidth = 1;
    for (var i = 0; i <= lines; i++) {
      final y = rect.bottom - rect.height * i / lines;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), paint);
    }
  }

  void text(
    Canvas canvas,
    String value,
    Offset offset, {
    double size = 10,
    Color color = _AA.text,
    FontWeight weight = FontWeight.w700,
    TextAlign align = TextAlign.left,
    double maxWidth = 120,
  }) {
    final tp = TextPainter(
      text: TextSpan(text: value, style: TextStyle(color: color, fontSize: size, fontWeight: weight)),
      textDirection: TextDirection.ltr,
      textAlign: align,
      maxLines: 2,
    )..layout(maxWidth: maxWidth);
    tp.paint(canvas, offset);
  }
}

class _AnalyticsHrLinePainter extends _BaseChartPainter {
  _AnalyticsHrLinePainter({required this.points});
  final List<_AnalyticsHrPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final list = points.where((p) => p.bpm > 0).toList(growable: false);
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(46, 28, math.max(10.0, size.width - 76), math.max(10.0, size.height - 74));
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, size.width, size.height));
    drawGrid(canvas, rect);
    int xKey(_AnalyticsHrPoint p) => p.timeMs > 0 ? p.timeMs : p.minute * 60000;
    final minX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a < b ? a : b).toDouble();
    var maxX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a > b ? a : b).toDouble();
    if ((maxX - minX).abs() < 1) maxX = minX + 60000;
    final minBpm = math.max(40.0, list.map((p) => p.bpm).fold<int>(list.first.bpm, (a, b) => a < b ? a : b).toDouble() - 10);
    final maxBpm = math.max(130.0, list.map((p) => p.bpm).fold<int>(list.first.bpm, (a, b) => a > b ? a : b).toDouble() + 12);
    Offset map(_AnalyticsHrPoint p, double value) => Offset(
      rect.left + rect.width * ((xKey(p) - minX) / (maxX - minX)).clamp(0.0, 1.0).toDouble(),
      rect.bottom - rect.height * ((value - minBpm) / (maxBpm - minBpm)).clamp(0.0, 1.0).toDouble(),
    );
    for (final z in [120, 140, 160, 180]) {
      if (z < minBpm || z > maxBpm) continue;
      final y = rect.bottom - rect.height * ((z - minBpm) / (maxBpm - minBpm)).clamp(0.0, 1.0).toDouble();
      final color = z >= 180 ? const Color(0xFFE11D48) : (z >= 160 ? const Color(0xFFF97316) : (z >= 140 ? const Color(0xFFFACC15) : const Color(0xFF84CC16)));
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), Paint()..color = color.withOpacity(.45)..strokeWidth = 1.1);
      text(canvas, 'Z${z == 120 ? 2 : z == 140 ? 3 : z == 160 ? 4 : 5}', Offset(rect.right - 24, y - 14), size: 8.8, color: color, weight: FontWeight.w900, maxWidth: 24);
    }
    final bpm = Path();
    final load = Path();
    var first = true;
    for (final p in list) {
      final bp = map(p, p.bpm.toDouble());
      final lp = map(p, minBpm + (maxBpm - minBpm) * (p.hrLoad.clamp(0, 200).toDouble() / 200.0));
      if (first) { bpm.moveTo(bp.dx, bp.dy); load.moveTo(lp.dx, lp.dy); first = false; } else { bpm.lineTo(bp.dx, bp.dy); load.lineTo(lp.dx, lp.dy); }
    }
    canvas.drawPath(load, Paint()..color = const Color(0xFF7F1D1D).withOpacity(.36)..style = PaintingStyle.stroke..strokeWidth = 2.0..strokeCap = StrokeCap.round);
    canvas.drawPath(bpm, Paint()..color = _AA.red..style = PaintingStyle.stroke..strokeWidth = 2.8..strokeCap = StrokeCap.round);
    final every = math.max(1, (list.length / 8).ceil());
    for (var i = 0; i < list.length; i += every) {
      final p = list[i];
      final o = map(p, p.bpm.toDouble());
      canvas.drawCircle(o, 4, Paint()..color = _analyticsZoneColor(p.zone));
      text(canvas, '${p.bpm}', o + const Offset(-9, -19), size: 8.3, color: _AA.green, weight: FontWeight.w900, maxWidth: 30);
    }
    text(canvas, '0 мин', Offset(rect.left, rect.bottom + 9), size: 9, color: _AA.muted, weight: FontWeight.w900, maxWidth: 48);
    text(canvas, '${math.max(1, ((maxX - minX) / 60000).round())} мин', Offset(rect.right - 48, rect.bottom + 9), size: 9, color: _AA.muted, weight: FontWeight.w900, maxWidth: 58);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _AnalyticsHrLinePainter oldDelegate) => oldDelegate.points != points;
}

class _LocalTrackAnalysis {
  const _LocalTrackAnalysis({
    required this.distanceM,
    required this.durationSec,
    required this.maxSpeedKmh,
    required this.avgSpeedKmh,
    required this.sprintCount,
    required this.sprintDistanceM,
    required this.hsrDistanceM,
    required this.accelCount,
    required this.decelCount,
    required this.speedSamples,
  });

  final double distanceM;
  final int durationSec;
  final double maxSpeedKmh;
  final double avgSpeedKmh;
  final int sprintCount;
  final double sprintDistanceM;
  final double hsrDistanceM;
  final int accelCount;
  final int decelCount;
  final List<double> speedSamples;

  static _LocalTrackAnalysis fromPoints(List<ActionTrackerGpsPoint> points, {double sprintThresholdKmh = 18.0, double hsrThresholdKmh = 14.0}) {
    if (points.length < 2) {
      return const _LocalTrackAnalysis(
        distanceM: 0,
        durationSec: 0,
        maxSpeedKmh: 0,
        avgSpeedKmh: 0,
        sprintCount: 0,
        sprintDistanceM: 0,
        hsrDistanceM: 0,
        accelCount: 0,
        decelCount: 0,
        speedSamples: <double>[],
      );
    }
    double distance = 0;
    double maxSpeed = 0;
    double sprintDistance = 0;
    double hsrDistance = 0;
    int sprintCount = 0;
    int accelCount = 0;
    int decelCount = 0;
    double? prevSpeed;
    bool inSprint = false;
    int activeMs = 0;
    final samples = <double>[];

    for (var i = 1; i < points.length; i++) {
      final a = points[i - 1];
      final b = points[i];
      if (_segmentBreaks(a, b)) {
        prevSpeed = null;
        inSprint = false;
        continue;
      }
      final rawDtMs = (b.timeMs - a.timeMs).abs();
      final dtMs = rawDtMs <= 0 ? 1000 : rawDtMs;
      if (dtMs > 60000) {
        prevSpeed = null;
        inSprint = false;
        continue;
      }
      final d = (b.distanceDeltaM != null && b.distanceDeltaM!.isFinite && b.distanceDeltaM! > 0 && b.distanceDeltaM! <= 80)
          ? b.distanceDeltaM!
          : _distanceMeters(a.latitude, a.longitude, b.latitude, b.longitude);
      if (d <= 0 || d > 80) continue;
      final storedSpeed = b.speedKmh;
      final speed = storedSpeed != null && storedSpeed.isFinite && storedSpeed > 0 && storedSpeed <= 45
          ? storedSpeed
          : (d / (dtMs / 1000.0)) * 3.6;
      if (speed.isNaN || speed.isInfinite || speed > 45) continue;
      activeMs += dtMs;
      distance += d;
      maxSpeed = math.max(maxSpeed, speed);
      samples.add(speed);
      if (speed >= hsrThresholdKmh) hsrDistance += d;
      if (speed >= sprintThresholdKmh) {
        sprintDistance += d;
        if (!inSprint) sprintCount++;
        inSprint = true;
      } else if (speed < sprintThresholdKmh * .88) {
        inSprint = false;
      }
      if (prevSpeed != null) {
        final accMps2 = ((speed - prevSpeed!) / 3.6) / (dtMs / 1000.0);
        if (accMps2 >= 1.0) accelCount++;
        if (accMps2 <= -1.0) decelCount++;
      }
      prevSpeed = speed;
    }

    final rawDurationSec = ((points.last.timeMs - points.first.timeMs).abs() / 1000).round();
    final activeDurationSec = (activeMs / 1000).round();
    final durationSec = activeDurationSec > 0 ? activeDurationSec : (rawDurationSec <= 0 ? math.max(1, points.length - 1) : rawDurationSec);
    final avg = durationSec <= 0 ? 0.0 : (distance / durationSec) * 3.6;
    return _LocalTrackAnalysis(
      distanceM: distance,
      durationSec: durationSec,
      maxSpeedKmh: maxSpeed,
      avgSpeedKmh: avg,
      sprintCount: sprintCount,
      sprintDistanceM: sprintDistance,
      hsrDistanceM: hsrDistance,
      accelCount: accelCount,
      decelCount: decelCount,
      speedSamples: samples,
    );
  }

  static double _distanceMeters(double lat1, double lon1, double lat2, double lon2) {
    const r = 6371000.0;
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dp = (lat2 - lat1) * math.pi / 180;
    final dl = (lon2 - lon1) * math.pi / 180;
    final a = math.sin(dp / 2) * math.sin(dp / 2) + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) * math.sin(dl / 2);
    return r * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }
}

const _tabs = <_AnalyticsTab>[
  _AnalyticsTab('Обзор', Icons.dashboard_rounded),
  _AnalyticsTab('Карта', Icons.map_rounded),
  _AnalyticsTab('Спринты', Icons.flash_on_rounded),
  _AnalyticsTab('Скорость', Icons.speed_rounded),
  _AnalyticsTab('Пульс', Icons.favorite_rounded),
  _AnalyticsTab('Команда', Icons.groups_rounded),
  _AnalyticsTab('Рейтинг', Icons.leaderboard_rounded),
  _AnalyticsTab('Офлайн GPS', Icons.cloud_download_rounded),
  _AnalyticsTab('Настройки', Icons.tune_rounded),
];

class _AnalyticsTab {
  const _AnalyticsTab(this.label, this.icon);
  final String label;
  final IconData icon;
}

class _AA {
  static const bg = Color(0xFFFFFFFF);
  static const card = Color(0xFFFFFFFF);
  static const soft = Color(0xFFF1FAF5);
  static const greenSoft = Color(0xFFF3FBF7);
  static const greenLine = Color(0xFFCBEEDD);
  static const line = Color(0xFFE5E7EB);
  static const text = Color(0xFF111827);
  static const muted = Color(0xFF667085);
  static const green = Color(0xFF00A750);
  static const blue = Color(0xFF2563EB);
  static const orange = Color(0xFFF59E0B);
  static const red = Color(0xFFDC2626);
}

class _YouthSpeedProfile {
  const _YouthSpeedProfile({required this.label, required this.hsrKmh, required this.sprintKmh});

  final String label;
  final double hsrKmh;
  final double sprintKmh;

  static _YouthSpeedProfile fromLabel(String value) {
    final raw = value.toUpperCase();
    final age = int.tryParse(RegExp(r'U\s*([0-9]{1,2})').firstMatch(raw)?.group(1) ?? '');
    if (age == null || age <= 0) {
      return const _YouthSpeedProfile(label: 'ДЮФ', hsrKmh: 14.0, sprintKmh: 18.0);
    }
    if (age <= 8) return const _YouthSpeedProfile(label: 'U6–U8', hsrKmh: 11.5, sprintKmh: 14.5);
    if (age <= 10) return const _YouthSpeedProfile(label: 'U9–U10', hsrKmh: 12.5, sprintKmh: 15.5);
    if (age <= 12) return const _YouthSpeedProfile(label: 'U11–U12', hsrKmh: 13.5, sprintKmh: 17.0);
    if (age <= 13) return const _YouthSpeedProfile(label: 'U13', hsrKmh: 14.0, sprintKmh: 18.0);
    if (age <= 15) return const _YouthSpeedProfile(label: 'U14–U15', hsrKmh: 16.0, sprintKmh: 20.0);
    if (age <= 17) return const _YouthSpeedProfile(label: 'U16–U17', hsrKmh: 18.0, sprintKmh: 22.0);
    return const _YouthSpeedProfile(label: 'Профи', hsrKmh: 19.8, sprintKmh: 25.2);
  }
}


class _DateFilterBar extends StatelessWidget {
  const _DateFilterBar({
    required this.selectedDate,
    required this.onlySelectedDate,
    required this.startTime,
    required this.endTime,
    required this.selectedSession,
    required this.sessionFilterLabel,
    required this.liveRunning,
    required this.localPointsCount,
    required this.onOpenSessionPicker,
    required this.onPrev,
    required this.onNext,
    required this.onToday,
    required this.onPick,
    required this.onPickStart,
    required this.onPickEnd,
    required this.onClearTime,
    required this.onToggleMode,
  });

  final DateTime selectedDate;
  final bool onlySelectedDate;
  final TimeOfDay? startTime;
  final TimeOfDay? endTime;
  final TrackerSessionModel? selectedSession;
  final String sessionFilterLabel;
  final bool liveRunning;
  final int localPointsCount;
  final VoidCallback onOpenSessionPicker;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onToday;
  final VoidCallback onPick;
  final VoidCallback onPickStart;
  final VoidCallback onPickEnd;
  final VoidCallback onClearTime;
  final ValueChanged<bool> onToggleMode;

  String get _date => '${selectedDate.day.toString().padLeft(2, '0')}.${selectedDate.month.toString().padLeft(2, '0')}.${selectedDate.year}';
  String _time(TimeOfDay? t, String fallback) => t == null ? fallback : '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final hasTime = startTime != null || endTime != null;
    final chips = <Widget>[
      _FilterPill(icon: Icons.calendar_month_rounded, label: 'Период', value: onlySelectedDate ? _date : 'все даты', onTap: onPick, primary: true),
      _FilterPill(icon: Icons.event_note_rounded, label: 'Сессии', value: sessionFilterLabel, onTap: onOpenSessionPicker, primary: true),
      _IconOnlyButton(icon: Icons.chevron_left_rounded, onTap: onPrev),
      _IconOnlyButton(icon: Icons.chevron_right_rounded, onTap: onNext),
      _SmallButton(icon: Icons.today_rounded, label: 'Сегодня', onTap: onToday),
      _FilterPill(icon: Icons.access_time_rounded, label: 'Начало', value: _time(startTime, 'с начала'), onTap: onPickStart),
      _FilterPill(icon: Icons.schedule_rounded, label: 'Конец', value: _time(endTime, 'до конца'), onTap: onPickEnd),
      if (hasTime) _SmallButton(icon: Icons.close_rounded, label: 'Сброс времени', onTap: onClearTime),
      _TogglePill(label: onlySelectedDate ? 'Только дата' : 'Все даты', value: onlySelectedDate, onChanged: onToggleMode),
      if (liveRunning) _FilterPill(icon: Icons.radio_button_checked_rounded, label: 'Live', value: 'точек $localPointsCount', onTap: null, primary: true),
    ];
    final mobile = MediaQuery.sizeOf(context).width < 720;
    return Container(
      height: mobile ? 36 : null,
      constraints: mobile ? null : const BoxConstraints(minHeight: 34),
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
      decoration: const BoxDecoration(color: _AA.card, border: Border(bottom: BorderSide(color: _AA.line))),
      child: mobile
          ? ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: chips.length,
              separatorBuilder: (_, __) => const SizedBox(width: 4),
              itemBuilder: (context, index) => chips[index],
            )
          : Wrap(
              spacing: 4,
              runSpacing: 4,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: chips,
            ),
    );
  }
}

class _FilterPill extends StatelessWidget {
  const _FilterPill({required this.icon, required this.label, required this.value, this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final String value;
  final VoidCallback? onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(4),
      child: Container(
        height: 27,
        padding: const EdgeInsets.symmetric(horizontal: 7),
        decoration: BoxDecoration(
          color: primary ? _AA.soft : const Color(0xFFFFFFFF),
          borderRadius: BorderRadius.circular(4),
          border: Border.all(color: primary ? _AA.green.withOpacity(.28) : _AA.line),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: _AA.green),
          const SizedBox(width: 4),
          Text('$label: ', style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
          Text(value, style: const TextStyle(color: _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _TogglePill extends StatelessWidget {
  const _TogglePill({required this.label, required this.value, required this.onChanged});
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(4),
      onTap: () => onChanged(!value),
      child: Container(
        height: 27,
        padding: const EdgeInsets.symmetric(horizontal: 7),
        decoration: BoxDecoration(color: value ? _AA.green : _AA.card, borderRadius: BorderRadius.circular(4), border: Border.all(color: value ? _AA.green : _AA.line)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(value ? Icons.check_circle_rounded : Icons.calendar_view_month_rounded, size: 14, color: value ? Colors.white : _AA.green),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: value ? Colors.white : _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _IconOnlyButton extends StatelessWidget {
  const _IconOnlyButton({required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(4),
      child: Container(
        width: 26,
        height: 26,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(4), border: Border.all(color: _AA.line)),
        child: Icon(icon, size: 16, color: _AA.green),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({
    required this.title,
    required this.subtitle,
    required this.liveRunning,
    required this.commandChannelReady,
    required this.onRefresh,
    required this.onLive,
  });
  final String title;
  final String subtitle;
  final bool liveRunning;
  final bool commandChannelReady;
  final VoidCallback onRefresh;
  final VoidCallback onLive;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: const BoxDecoration(color: _AA.card, border: Border(bottom: BorderSide(color: _AA.line))),
      child: Row(children: [
        Container(width: 28, height: 28, decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(4)), child: const Icon(Icons.analytics_rounded, color: _AA.green, size: 16)),
        const SizedBox.shrink(),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 13, fontWeight: FontWeight.w800)),
          Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 9, fontWeight: FontWeight.w600)),
        ])),
        if (liveRunning) ...[
          Container(
            height: 26,
            padding: const EdgeInsets.symmetric(horizontal: 9),
            alignment: Alignment.center,
            decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(4), border: Border.all(color: _AA.greenLine)),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.radio_button_checked_rounded, size: 14, color: _AA.green),
              SizedBox(width: 5),
              Text('Live идёт', style: TextStyle(color: _AA.green, fontSize: 9.2, fontWeight: FontWeight.w900)),
            ]),
          ),
          const SizedBox(width: 4),
        ],
        _SmallButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: onRefresh),
      ]),
    );
  }
}

class _TabStrip extends StatelessWidget {
  const _TabStrip({required this.selected, required this.onSelect});
  final int selected;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      decoration: const BoxDecoration(color: _AA.card, border: Border(bottom: BorderSide(color: _AA.line))),
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
        scrollDirection: Axis.horizontal,
        itemCount: _tabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 0),
        itemBuilder: (context, i) {
          final tab = _tabs[i];
          final active = selected == i;
          return InkWell(
            borderRadius: BorderRadius.circular(4),
            onTap: () => onSelect(i),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: BoxDecoration(
                color: active ? _AA.soft : Colors.transparent,
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: active ? _AA.green.withOpacity(.35) : Colors.transparent),
              ),
              child: Row(children: [
                Icon(tab.icon, size: 14, color: active ? _AA.green : _AA.muted),
                const SizedBox(width: 4),
                Text(tab.label, style: TextStyle(color: active ? _AA.text : _AA.muted, fontSize: 9.8, fontWeight: active ? FontWeight.w900 : FontWeight.w800)),
              ]),
            ),
          );
        },
      ),
    );
  }
}

class _OverviewTab extends StatelessWidget {
  const _OverviewTab({
    required this.compact,
    required this.bundle,
    required this.local,
    required this.selectedPlayer,
    required this.selectedField,
    required this.selectedSession,
    required this.heatmap,
    required this.usingLatestFallback,
    required this.fallbackMessage,
    required this.onOpenCalibration,
    required this.onOpenSessions,
  });

  final bool compact;
  final _AnalyticsBundle bundle;
  final _LocalTrackAnalysis local;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final TrackerSessionModel? selectedSession;
  final List<TrackerHeatPoint> heatmap;
  final bool usingLatestFallback;
  final String fallbackMessage;
  final VoidCallback onOpenCalibration;
  final VoidCallback onOpenSessions;

  @override
  Widget build(BuildContext context) {
    final rows = _rowsForAnalytics(bundle, selectedSession, local, selectedPlayer);
    final total = _DayTotal.fromRows(rows, sessionsCount: bundle.sessions.length, fallbackSession: selectedSession, local: local);
    final cards = <_Metric>[
      _Metric(icon: Icons.route_rounded, title: 'Объём дня', value: _meters(total.distanceM), note: '${total.sessionsCount} сессий'),
      _Metric(icon: Icons.groups_rounded, title: 'Игроков', value: '${total.playersCount}', note: 'с данными'),
      _Metric(icon: Icons.speed_rounded, title: 'Макс. скорость', value: '${total.maxSpeedKmh.toStringAsFixed(1)}', note: 'км/ч'),
      _Metric(icon: Icons.flash_on_rounded, title: 'Спринты', value: '${total.sprintCount}', note: _meters(total.sprintDistanceM)),
      _Metric(icon: Icons.local_fire_department_rounded, title: 'HIR/VHIR', value: _meters(total.hirDistanceM), note: 'интенсивность'),
      _Metric(icon: Icons.compare_arrows_rounded, title: 'Уск./торм.', value: '${total.accelCount}/${total.decelCount}', note: 'механика'),
      _Metric(icon: Icons.bolt_rounded, title: 'Нагрузка', value: total.loadScore.toStringAsFixed(0), note: 'суммарная'),
    ];

    return Column(children: [
      if (usingLatestFallback) _InlineNotice(text: fallbackMessage),
      SizedBox(
        height: compact ? 156 : 86,
        child: GridView.count(
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: compact ? 2 : 7,
          crossAxisSpacing: 0,
          mainAxisSpacing: 0,
          childAspectRatio: compact ? 3.25 : 1.72,
          children: cards,
        ),
      ),
      Expanded(
        child: compact
            ? ListView(children: [
                _DaySummaryPanel(total: total, selectedField: selectedField, selectedPlayer: selectedPlayer, onOpenSessions: onOpenSessions),
                SizedBox(height: 260, child: _PlayerActivityProfilePanel(selectedPlayer: selectedPlayer, selectedSession: selectedSession, local: local, heatmap: heatmap, title: 'Радар выбранной сессии')),
                SizedBox(height: 360, child: _DayRankingsPanel(rows: rows)),
              ])
            : Row(children: [
                Expanded(flex: 5, child: _DaySummaryPanel(total: total, selectedField: selectedField, selectedPlayer: selectedPlayer, onOpenSessions: onOpenSessions)),
                Expanded(flex: 5, child: _PlayerActivityProfilePanel(selectedPlayer: selectedPlayer, selectedSession: selectedSession, local: local, heatmap: heatmap, title: 'Радар выбранной сессии')),
                Expanded(flex: 8, child: _DayRankingsPanel(rows: rows)),
              ]),
      ),
    ]);
  }
}

class _DaySummaryPanel extends StatelessWidget {
  const _DaySummaryPanel({required this.total, required this.selectedField, required this.selectedPlayer, required this.onOpenSessions});
  final _DayTotal total;
  final TrackerFieldModel? selectedField;
  final TrackerPlayerOption? selectedPlayer;
  final VoidCallback onOpenSessions;

  @override
  Widget build(BuildContext context) {
    return _Panel(
      title: 'Обзор дня / периода',
      subtitle: 'итог по всем выбранным сессиям',
      child: Column(children: [
        _InfoLine(title: 'Поле', value: selectedField?.title ?? 'не выбрано'),
        _InfoLine(title: 'Фокус игрока', value: selectedPlayer?.name ?? 'вся команда'),
        _InfoLine(title: 'Сессий', value: '${total.sessionsCount}'),
        _InfoLine(title: 'Игроков с данными', value: '${total.playersCount}'),
        _InfoLine(title: 'Дистанция команды', value: _meters(total.distanceM)),
        _InfoLine(title: 'Спринтов / дистанция', value: '${total.sprintCount} / ${_meters(total.sprintDistanceM)}'),
        _InfoLine(title: 'Ускорения / торможения', value: '${total.accelCount} / ${total.decelCount}'),
        _InfoLine(title: 'Внутренняя нагрузка', value: total.loadScore <= 0 ? 'нет данных' : '${total.loadScore.toStringAsFixed(0)} ед.'),
        const Spacer(),
        _SmallButton(icon: Icons.assignment_rounded, label: 'Открыть отчёты', primary: true, onTap: onOpenSessions),
      ]),
    );
  }
}

class _DayRankingsPanel extends StatelessWidget {
  const _DayRankingsPanel({required this.rows});
  final List<TrackerPlayerLoadRow> rows;

  @override
  Widget build(BuildContext context) {
    final distance = [...rows]..sort((a, b) => b.distanceM.compareTo(a.distanceM));
    final speed = [...rows]..sort((a, b) => b.maxSpeedKmh.compareTo(a.maxSpeedKmh));
    final sprint = [...rows]..sort((a, b) => b.sprintCount.compareTo(a.sprintCount));
    final load = [...rows]..sort((a, b) => b.loadScore.compareTo(a.loadScore));
    if (rows.isEmpty) return const _Panel(title: 'Рейтинги дня', subtitle: 'нет обработанных сессий', child: _Empty(icon: Icons.leaderboard_rounded, text: 'После сохранения сессий здесь появятся лидеры по дистанции, скорости, спринтам и нагрузке.'));
    return _Panel(
      title: 'Рейтинги дня',
      subtitle: 'по всем ключевым элементам',
      child: GridView.count(
        crossAxisCount: 2,
        childAspectRatio: 2.35,
        children: [
          _RankingMini(title: 'Дистанция', rows: distance, value: (r) => _meters(r.distanceM), icon: Icons.route_rounded),
          _RankingMini(title: 'Макс. скорость', rows: speed, value: (r) => '${r.maxSpeedKmh.toStringAsFixed(1)} км/ч', icon: Icons.speed_rounded),
          _RankingMini(title: 'Спринты', rows: sprint, value: (r) => '${r.sprintCount} / ${_meters(r.sprintDistanceM)}', icon: Icons.flash_on_rounded),
          _RankingMini(title: 'Нагрузка', rows: load, value: (r) => r.loadScore.toStringAsFixed(0), icon: Icons.bolt_rounded),
        ],
      ),
    );
  }
}

class _RankingMini extends StatelessWidget {
  const _RankingMini({required this.title, required this.rows, required this.value, required this.icon});
  final String title;
  final List<TrackerPlayerLoadRow> rows;
  final String Function(TrackerPlayerLoadRow row) value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(border: Border(right: BorderSide(color: _AA.line), bottom: BorderSide(color: _AA.line))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Container(
          height: 28,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
          child: Row(children: [Icon(icon, size: 14, color: _AA.green), const SizedBox(width: 5), Text(title, style: const TextStyle(color: _AA.text, fontSize: 10, fontWeight: FontWeight.w900))]),
        ),
        Expanded(child: ListView.builder(
          itemCount: math.min(5, rows.length),
          itemBuilder: (context, i) {
            final r = rows[i];
            return Container(
              height: 32,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
              child: Row(children: [
                Text('${i + 1}', style: const TextStyle(color: _AA.muted, fontSize: 9, fontWeight: FontWeight.w800)),
                const SizedBox(width: 6),
                Expanded(child: Text(r.playerName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800))),
                Text(value(r), style: const TextStyle(color: _AA.green, fontSize: 9.4, fontWeight: FontWeight.w900)),
              ]),
            );
          },
        )),
      ]),
    );
  }
}


class _MapTab extends StatefulWidget {
  const _MapTab({
    required this.points,
    required this.localPoints,
    required this.field,
    required this.selectedPlayer,
    required this.selectedSession,
    required this.heatMode,
    required this.onHeatModeChanged,
    required this.sprintThresholdKmh,
    required this.hsrThresholdKmh,
    required this.showSprintArrows,
    required this.mapRotationDeg,
    required this.onOpenCalibration,
  });

  final List<TrackerHeatPoint> points;
  final List<ActionTrackerGpsPoint> localPoints;
  final TrackerFieldModel? field;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerSessionModel? selectedSession;
  final bool heatMode;
  final ValueChanged<bool> onHeatModeChanged;
  final double sprintThresholdKmh;
  final double hsrThresholdKmh;
  final bool showSprintArrows;
  final double mapRotationDeg;
  final VoidCallback onOpenCalibration;

  @override
  State<_MapTab> createState() => _MapTabState();
}

class _MapTabState extends State<_MapTab> {
  String _activityFilter = 'all';
  _MapPointInfo? _selectedPoint;

  List<ActionTrackerGpsPoint> get _visiblePoints {
    if (widget.heatMode) return const <ActionTrackerGpsPoint>[];
    return widget.localPoints;
  }

  @override
  Widget build(BuildContext context) {
    final compact = MediaQuery.sizeOf(context).width < 980;
    final visiblePoints = _visiblePoints;
    final local = _LocalTrackAnalysis.fromPoints(widget.localPoints, sprintThresholdKmh: widget.sprintThresholdKmh, hsrThresholdKmh: widget.hsrThresholdKmh);
    final sprintSegments = _SprintSegment.fromPoints(widget.localPoints, thresholdKmh: widget.sprintThresholdKmh);
    final heatPoints = widget.points.isNotEmpty ? widget.points : _heatmapFromGpsStatic(widget.localPoints, widget.field);

    final mapPanel = _Panel(
      title: widget.heatMode ? 'Тепловая карта' : 'Карта активности',
      subtitle: widget.points.isEmpty && widget.localPoints.isEmpty
          ? 'нет точек выбранной сессии'
          : '${widget.localPoints.length} GPS · ${heatPoints.length} heat · ${sprintSegments.length} спринтов',
      child: Column(children: [
        Container(
          height: 30,
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
          child: Row(children: [
            _MapModeButton(label: 'Карта активности', icon: Icons.timeline_rounded, active: !widget.heatMode, onTap: () => widget.onHeatModeChanged(false)),
            _MapModeButton(label: 'Тепловая карта', icon: Icons.local_fire_department_rounded, active: widget.heatMode, onTap: () => widget.onHeatModeChanged(true)),
            const Spacer(),
            _SmallButton(icon: Icons.open_in_full_rounded, label: 'Расширить', onTap: _openExpandedMap),
          ]),
        ),
        if (!widget.heatMode)
          Container(
            height: 31,
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3), children: [
              _ActivityFilterChip(label: 'Все', value: 'all', current: _activityFilter, onTap: _setFilter),
              _ActivityFilterChip(label: 'Ходьба', value: 'walk', current: _activityFilter, onTap: _setFilter),
              _ActivityFilterChip(label: 'Бег', value: 'run', current: _activityFilter, onTap: _setFilter),
              _ActivityFilterChip(label: 'Высокая', value: 'hir', current: _activityFilter, onTap: _setFilter),
              _ActivityFilterChip(label: 'Спринт', value: 'sprint', current: _activityFilter, onTap: _setFilter),
              _ActivityFilterChip(label: 'Повороты', value: 'turn', current: _activityFilter, onTap: _setFilter),
            ]),
          ),
        Expanded(child: LayoutBuilder(builder: (context, constraints) {
          final mapSize = Size(constraints.maxWidth, constraints.maxHeight);
          return GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTapDown: widget.heatMode ? null : (details) {
              final info = _nearestPointInfo(details.localPosition, mapSize, visiblePoints, widget.field, widget.hsrThresholdKmh, widget.sprintThresholdKmh);
              if (info != null) setState(() => _selectedPoint = info);
            },
            child: CustomPaint(
              painter: _ActionPitchPainter(
                heat: widget.heatMode ? heatPoints : const <TrackerHeatPoint>[],
                local: widget.heatMode ? const <ActionTrackerGpsPoint>[] : visiblePoints,
                field: widget.field,
                sprintThresholdKmh: widget.sprintThresholdKmh,
                hsrThresholdKmh: widget.hsrThresholdKmh,
                activityFilter: _activityFilter,
                showSprintArrows: widget.showSprintArrows,
                mapRotationDeg: widget.mapRotationDeg,
              ),
              child: const SizedBox.expand(),
            ),
          );
        })),
      ]),
    );

    final chartPanel = _Panel(
      title: widget.heatMode ? 'Плотность и зоны' : 'График скорости',
      subtitle: widget.heatMode ? 'точки тепловой карты и распределение' : 'цифры, точки, HIR/SPR, активность',
      child: Column(children: [
        Expanded(flex: 7, child: CustomPaint(painter: _SpeedPainter(samples: local.speedSamples, hsrThresholdKmh: widget.hsrThresholdKmh, sprintThresholdKmh: widget.sprintThresholdKmh, maxSpeedKmh: local.maxSpeedKmh), child: const SizedBox.expand())),
        Container(height: 1, color: _AA.line),
        Expanded(flex: 4, child: _SpeedZonesPanel(hsrThresholdKmh: widget.hsrThresholdKmh, sprintThresholdKmh: widget.sprintThresholdKmh, maxSpeedKmh: local.maxSpeedKmh, speedSamples: local.speedSamples)),
      ]),
    );

    final infoPanel = _Panel(
      title: _selectedPoint == null ? 'Поле, сессия и точка' : 'Выбранный отрезок',
      subtitle: widget.field?.title ?? 'поле не выбрано',
      child: _selectedPoint == null
          ? Column(children: [
              _InfoLine(title: 'Игрок', value: widget.selectedPlayer?.name ?? widget.selectedSession?.playerName ?? 'Команда'),
              _InfoLine(title: 'Сессия', value: widget.selectedSession == null ? 'период / Live' : '#${widget.selectedSession!.id}'),
              _InfoLine(title: 'Поле', value: widget.field?.title ?? 'Не выбрано'),
              _InfoLine(title: 'Размер', value: widget.field == null ? '105×68 м' : '${widget.field!.lengthM.toStringAsFixed(0)}×${widget.field!.widthM.toStringAsFixed(0)} м'),
              _InfoLine(title: 'GPS-точек', value: '${widget.localPoints.length}'),
              _InfoLine(title: 'Поворотов', value: '${_turnPoints(widget.localPoints).length}'),
              _InfoLine(title: 'Уск./торм.', value: '${local.accelCount}/${local.decelCount}'),
              _InfoLine(title: 'Дистанция', value: _meters(local.distanceM)),
              _InfoLine(title: 'Max скорость', value: '${local.maxSpeedKmh.toStringAsFixed(1)} км/ч'),
              const Spacer(),
              _SmallButton(icon: Icons.map_rounded, label: 'Открыть калибровку', onTap: widget.onOpenCalibration),
            ])
          : _SelectedMapPointCard(info: _selectedPoint!, onClear: () => setState(() => _selectedPoint = null)),
    );

    if (compact) {
      return ListView(primary: false, children: [
        SizedBox(height: 360, child: mapPanel),
        SizedBox(height: 260, child: chartPanel),
        SizedBox(height: 280, child: infoPanel),
      ]);
    }
    return Row(children: [
      Expanded(flex: 7, child: mapPanel),
      Expanded(flex: 4, child: chartPanel),
      Expanded(flex: 3, child: infoPanel),
    ]);
  }

  void _setFilter(String value) {
    setState(() {
      _activityFilter = value;
      _selectedPoint = null;
    });
  }

  void _openExpandedMap() {
    showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        insetPadding: const EdgeInsets.all(12),
        backgroundColor: Colors.white,
        child: SizedBox(
          width: 1100,
          height: 760,
          child: Column(children: [
            Container(
              height: 42,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
              child: Row(children: [
                Icon(widget.heatMode ? Icons.local_fire_department_rounded : Icons.timeline_rounded, color: _AA.green, size: 18),
                const SizedBox(width: 8),
                Expanded(child: Text(widget.heatMode ? 'Тепловая карта — полный экран' : 'Карта активности — полный экран', style: const TextStyle(color: _AA.text, fontSize: 12, fontWeight: FontWeight.w900))),
                IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded, size: 18)),
              ]),
            ),
            Expanded(
              child: CustomPaint(
                painter: _ActionPitchPainter(
                  heat: widget.heatMode ? (widget.points.isNotEmpty ? widget.points : _heatmapFromGpsStatic(widget.localPoints, widget.field)) : const <TrackerHeatPoint>[],
                  local: widget.heatMode ? const <ActionTrackerGpsPoint>[] : _visiblePoints,
                  field: widget.field,
                  sprintThresholdKmh: widget.sprintThresholdKmh,
                  hsrThresholdKmh: widget.hsrThresholdKmh,
                  activityFilter: _activityFilter,
                  showSprintArrows: widget.showSprintArrows,
                  mapRotationDeg: widget.mapRotationDeg,
                ),
                child: const SizedBox.expand(),
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _ActivityFilterChip extends StatelessWidget {
  const _ActivityFilterChip({required this.label, required this.value, required this.current, required this.onTap});
  final String label;
  final String value;
  final String current;
  final ValueChanged<String> onTap;
  @override
  Widget build(BuildContext context) {
    final active = value == current;
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: InkWell(
        onTap: () => onTap(value),
        borderRadius: BorderRadius.circular(4),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: active ? _AA.green : _AA.card, borderRadius: BorderRadius.circular(4), border: Border.all(color: active ? _AA.green : _AA.line)),
          child: Text(label, style: TextStyle(color: active ? Colors.white : _AA.text, fontSize: 9, fontWeight: FontWeight.w900)),
        ),
      ),
    );
  }
}

class _MapPointInfo {
  const _MapPointInfo({required this.index, required this.speedKmh, required this.distanceM, required this.accelMps2, required this.activity, required this.position});
  final int index;
  final double speedKmh;
  final double distanceM;
  final double accelMps2;
  final String activity;
  final Offset position;
}

class _SelectedMapPointCard extends StatelessWidget {
  const _SelectedMapPointCard({required this.info, required this.onClear});
  final _MapPointInfo info;
  final VoidCallback onClear;

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      _InfoLine(title: 'Отрезок', value: '#${info.index}'),
      _InfoLine(title: 'Тип', value: info.activity),
      _InfoLine(title: 'Скорость', value: '${info.speedKmh.toStringAsFixed(1)} км/ч'),
      _InfoLine(title: 'Дистанция', value: '${info.distanceM.toStringAsFixed(1)} м'),
      _InfoLine(title: 'Ускорение', value: '${info.accelMps2.toStringAsFixed(2)} м/с²'),
      _InfoLine(title: 'Позиция', value: '${info.position.dx.toStringAsFixed(1)} / ${info.position.dy.toStringAsFixed(1)}'),
      const Spacer(),
      _SmallButton(icon: Icons.close_rounded, label: 'Снять выбор', onTap: onClear),
    ]);
  }
}

bool _segmentBreaks(ActionTrackerGpsPoint a, ActionTrackerGpsPoint b) {
  if (b.breakBefore) return true;
  if (a.playerId != null && b.playerId != null && a.playerId != b.playerId) return true;
  if (a.liveSessionId != null && b.liveSessionId != null && a.liveSessionId != b.liveSessionId) return true;
  if (a.sessionId != null && b.sessionId != null && a.sessionId != b.sessionId) return true;
  return false;
}

bool _segmentMatchesActivity(double speed, String filter, {double hsrThresholdKmh = 14.0, double sprintThresholdKmh = 18.0}) {
  if (filter == 'all') return true;
  if (speed <= 0) return false;
  if (filter == 'walk') return speed < 7.0;
  if (filter == 'run') return speed >= 7.0 && speed < hsrThresholdKmh;
  if (filter == 'hir') return speed >= hsrThresholdKmh && speed < sprintThresholdKmh;
  if (filter == 'sprint') return speed >= sprintThresholdKmh;
  return true;
}

List<ActionTrackerGpsPoint> _filterActivityPoints(List<ActionTrackerGpsPoint> points, String filter, double sprintThresholdKmh, {double hsrThresholdKmh = 14.0}) {
  if (filter == 'all' || points.length < 2) return points;
  final turns = _turnPoints(points).toSet();
  final out = <ActionTrackerGpsPoint>[];
  double? prevSpeed;
  void addPoint(ActionTrackerGpsPoint p) {
    if (out.isEmpty || !identical(out.last, p)) out.add(p);
  }
  for (var i = 1; i < points.length; i++) {
    if (_segmentBreaks(points[i - 1], points[i])) { prevSpeed = null; continue; }
    final speed = _segmentSpeed(points, i);
    final acc = prevSpeed == null ? 0.0 : ((speed - prevSpeed) / 3.6);
    prevSpeed = speed <= 0 ? null : speed;
    var keep = false;
    if (filter == 'walk') keep = speed > 0 && speed < 7;
    if (filter == 'run') keep = speed >= 7 && speed < hsrThresholdKmh;
    if (filter == 'hir') keep = speed >= hsrThresholdKmh && speed < sprintThresholdKmh;
    if (filter == 'sprint') keep = speed >= sprintThresholdKmh;
    if (filter == 'turn') keep = turns.contains(i);
    if (filter == 'accel') keep = acc >= 1.0;
    if (keep) {
      // Важно: рисуем именно подходящий отрезок prev->current, а не соединяем
      // все выбранные точки одной длинной диагональю.
      addPoint(points[i - 1]);
      addPoint(points[i]);
    }
  }
  return out.isEmpty ? <ActionTrackerGpsPoint>[] : out;
}

double _segmentSpeed(List<ActionTrackerGpsPoint> points, int i) {
  if (i <= 0 || i >= points.length) return 0.0;
  final a = points[i - 1];
  final b = points[i];
  if (_segmentBreaks(a, b)) return 0.0;
  final stored = b.speedKmh;
  if (stored != null && stored.isFinite && stored > 0 && stored <= 45) return stored;
  final rawDtMs = (b.timeMs - a.timeMs).abs();
  final dtMs = rawDtMs <= 0 ? 1000 : rawDtMs;
  if (dtMs > 60000) return 0.0;
  final d = (b.distanceDeltaM != null && b.distanceDeltaM!.isFinite && b.distanceDeltaM! > 0 && b.distanceDeltaM! <= 80)
      ? b.distanceDeltaM!
      : _LocalTrackAnalysis._distanceMeters(a.latitude, a.longitude, b.latitude, b.longitude);
  if (d <= 0 || d > 80) return 0.0;
  final speed = (d / (dtMs / 1000.0)) * 3.6;
  return speed.isFinite && speed > 0 ? math.min(44.0, speed) : 0.0;
}

_MapPointInfo? _nearestPointInfo(Offset tap, Size size, List<ActionTrackerGpsPoint> points, TrackerFieldModel? field, double hsrThresholdKmh, double sprintThresholdKmh) {
  if (points.isEmpty) return null;
  final bounds = points.length > 1 ? _Bounds.fromGps(points) : null;
  final useFieldProjection = _shouldUseFieldProjection(points, field);
  var bestIndex = -1;
  var bestDistance = double.infinity;
  Offset? bestOffset;
  for (var i = 0; i < points.length; i++) {
    final offset = _projectGpsForSize(points[i], size, field, bounds, useFieldProjection: useFieldProjection);
    final d = (offset - tap).distance;
    if (d < bestDistance) {
      bestDistance = d;
      bestIndex = i;
      bestOffset = offset;
    }
  }
  if (bestIndex < 0 || bestOffset == null || bestDistance > 28) return null;
  final speed = _segmentSpeed(points, bestIndex);
  final dist = bestIndex <= 0 ? 0.0 : _LocalTrackAnalysis._distanceMeters(points[bestIndex - 1].latitude, points[bestIndex - 1].longitude, points[bestIndex].latitude, points[bestIndex].longitude);
  final prevSpeed = bestIndex <= 1 ? speed : _segmentSpeed(points, bestIndex - 1);
  final dtMs = bestIndex <= 0 ? 1000 : (points[bestIndex].timeMs - points[bestIndex - 1].timeMs).abs();
  final accel = ((speed - prevSpeed) / 3.6) / ((dtMs <= 0 ? 1000 : dtMs) / 1000.0);
  final activity = speed >= sprintThresholdKmh ? 'спринт' : (speed >= hsrThresholdKmh ? 'высокая интенсивность' : (speed >= 7 ? 'бег' : 'ходьба'));
  return _MapPointInfo(index: bestIndex, speedKmh: speed, distanceM: dist, accelMps2: accel.isFinite ? accel : 0.0, activity: activity, position: bestOffset);
}

Offset _projectGpsForSize(
  ActionTrackerGpsPoint p,
  Size size,
  TrackerFieldModel? field,
  _Bounds? bounds, {
  bool useFieldProjection = true,
}) {
  if (useFieldProjection) {
    final raw = TrackerPitchProjector.projectGps(field, latitude: p.latitude, longitude: p.longitude);
    if (raw != null) {
      return _fitPointToPitch(Offset(raw.clampedNx * size.width, raw.clampedNy * size.height), size);
    }
  }
  if (bounds != null) return _fitPointToPitch(bounds.project(p, size), size);
  return Offset(size.width / 2, size.height / 2);
}

bool _shouldUseFieldProjection(List<ActionTrackerGpsPoint> points, TrackerFieldModel? field) {
  if (field == null || !field.hasCalibration || points.length < 2) return false;
  final xs = <double>[];
  final ys = <double>[];
  var inside = 0;
  var clipped = 0;
  for (final p in points) {
    final q = TrackerPitchProjector.projectGps(field, latitude: p.latitude, longitude: p.longitude);
    if (q == null) continue;
    xs.add(q.nx);
    ys.add(q.ny);
    if (q.isInside) inside++;
    if (q.nx < 0 || q.nx > 1 || q.ny < 0 || q.ny > 1) clipped++;
  }
  if (xs.length < 2) return false;
  final minX = xs.reduce(math.min), maxX = xs.reduce(math.max);
  final minY = ys.reduce(math.min), maxY = ys.reduce(math.max);
  final spreadX = (maxX - minX).abs();
  final spreadY = (maxY - minY).abs();
  final insideRatio = inside / xs.length;
  final clippedRatio = clipped / xs.length;
  // Если калибровка отправляет все GPS-точки в один угол/за границу,
  // используем GPS-bounds. Так карта не схлопывается справа/слева.
  if (spreadX < .018 && spreadY < .018) return false;
  if (insideRatio < .35 && clippedRatio > .45) return false;
  return true;
}

Offset _fitPointToPitch(Offset raw, Size size) {
  final inner = _pitchInnerRect(size);
  final nx = size.width <= 0 ? .5 : (raw.dx / size.width).clamp(0.0, 1.0);
  final ny = size.height <= 0 ? .5 : (raw.dy / size.height).clamp(0.0, 1.0);
  return Offset(inner.left + nx * inner.width, inner.top + ny * inner.height);
}

Rect _pitchInnerRect(Size size) => Rect.fromLTWH(10, 10, math.max(1.0, size.width - 20), math.max(1.0, size.height - 20));

class _SprintsTab extends StatelessWidget {
  const _SprintsTab({
    required this.bundle,
    required this.local,
    required this.localPoints,
    required this.selectedSession,
    required this.sprintThresholdKmh,
    required this.hsrThresholdKmh,
    required this.showSprintArrows,
    required this.mapRotationDeg,
  });

  final _AnalyticsBundle bundle;
  final _LocalTrackAnalysis local;
  final List<ActionTrackerGpsPoint> localPoints;
  final TrackerSessionModel? selectedSession;
  final double sprintThresholdKmh;
  final double hsrThresholdKmh;
  final bool showSprintArrows;
  final double mapRotationDeg;

  @override
  Widget build(BuildContext context) {
    final players = [..._rowsForAnalytics(bundle, selectedSession, local, null)]..sort((a, b) => b.sprintCount.compareTo(a.sprintCount));
    final sprintCount = local.sprintCount > 0 ? local.sprintCount : (selectedSession?.sprintCount ?? 0);
    final sprintDistance = local.sprintDistanceM > 0 ? local.sprintDistanceM : (selectedSession?.sprintDistanceM ?? 0);
    final hirDistance = local.hsrDistanceM > 0 ? local.hsrDistanceM : ((selectedSession?.hirDistanceM ?? 0) + (selectedSession?.vhirDistanceM ?? 0));
    final maxSpeed = local.maxSpeedKmh > 0 ? local.maxSpeedKmh : (selectedSession?.maxSpeedKmh ?? 0);
    final segments = _SprintSegment.fromPoints(localPoints, thresholdKmh: sprintThresholdKmh);
    return Row(children: [
      Expanded(
        flex: 7,
        child: _Panel(
          title: 'Спринты на карте',
          subtitle: '${segments.length} отрезков · стрелки направления и зона спринта',
          child: CustomPaint(
            painter: _ActionPitchPainter(
              heat: const <TrackerHeatPoint>[],
              local: localPoints,
              field: null,
              sprintThresholdKmh: sprintThresholdKmh,
              hsrThresholdKmh: hsrThresholdKmh,
              activityFilter: 'sprint',
              showSprintArrows: showSprintArrows,
              mapRotationDeg: mapRotationDeg,
            ),
            child: const SizedBox.expand(),
          ),
        ),
      ),
      Expanded(
        flex: 4,
        child: _Panel(
          title: 'Спринты и интенсивная работа',
          subtitle: 'цифры + график по каждой точке скорости',
          child: Column(children: [
            SizedBox(height: 58, child: Row(children: [
              Expanded(child: _MiniNumber(title: 'Спринты', value: '$sprintCount', note: _meters(sprintDistance))),
              Expanded(child: _MiniNumber(title: 'HIR/VHIR', value: _meters(hirDistance), note: '>${hsrThresholdKmh.toStringAsFixed(1)} км/ч')),
              Expanded(child: _MiniNumber(title: 'Макс.', value: maxSpeed.toStringAsFixed(1), note: 'км/ч')),
              Expanded(child: _MiniNumber(title: 'Уск/торм', value: '${local.accelCount}/${local.decelCount}', note: 'механика')),
            ])),
            Expanded(child: CustomPaint(painter: _SprintPainter(samples: local.speedSamples, hsrThresholdKmh: hsrThresholdKmh, sprintThresholdKmh: sprintThresholdKmh), child: const SizedBox.expand())),
          ]),
        ),
      ),
      Expanded(flex: 3, child: _Panel(title: 'Лидеры спринтов', subtitle: '${players.length} игроков', child: _PlayerRanking(players: players, mode: _RankingMode.sprints))),
    ]);
  }
}

class _SpeedTab extends StatelessWidget {
  const _SpeedTab({required this.bundle, required this.local, required this.selectedSession, required this.hsrThresholdKmh, required this.sprintThresholdKmh});
  final _AnalyticsBundle bundle;
  final _LocalTrackAnalysis local;
  final TrackerSessionModel? selectedSession;
  final double hsrThresholdKmh;
  final double sprintThresholdKmh;

  @override
  Widget build(BuildContext context) {
    final maxSpeed = local.maxSpeedKmh > 0 ? local.maxSpeedKmh : (selectedSession?.maxSpeedKmh ?? 0);
    final avgSpeed = local.avgSpeedKmh > 0 ? local.avgSpeedKmh : (selectedSession?.avgSpeedKmh ?? 0);
    final metersPerMin = selectedSession?.metersPerMinute ?? (local.durationSec <= 0 ? 0 : local.distanceM / (local.durationSec / 60.0));
    final duration = local.durationSec > 0 ? local.durationSec : (selectedSession?.durationSec ?? 0);
    final rows = [..._rowsForAnalytics(bundle, selectedSession, local, null)]..sort((a, b) => b.maxSpeedKmh.compareTo(a.maxSpeedKmh));
    return Row(children: [
      Expanded(
        flex: 7,
        child: _Panel(
          title: 'График скорости',
          subtitle: 'подписи скорости на точках + зоны HIR/SPR',
          child: Column(children: [
            SizedBox(height: 58, child: Row(children: [
              Expanded(child: _MiniNumber(title: 'Средняя', value: avgSpeed.toStringAsFixed(1), note: 'км/ч')),
              Expanded(child: _MiniNumber(title: 'Максимальная', value: maxSpeed.toStringAsFixed(1), note: 'км/ч')),
              Expanded(child: _MiniNumber(title: 'м/мин', value: metersPerMin.toStringAsFixed(1), note: _time(duration))),
              Expanded(child: _MiniNumber(title: 'Точек', value: '${local.speedSamples.length}', note: 'GPS скорость')),
            ])),
            Expanded(child: CustomPaint(painter: _SpeedPainter(samples: local.speedSamples, hsrThresholdKmh: hsrThresholdKmh, sprintThresholdKmh: sprintThresholdKmh, maxSpeedKmh: maxSpeed), child: const SizedBox.expand())),
          ]),
        ),
      ),
      Expanded(
        flex: 4,
        child: _Panel(
          title: 'Пороговые зоны',
          subtitle: 'скорость, HIR, спринт',
          child: _SpeedZonesPanel(hsrThresholdKmh: hsrThresholdKmh, sprintThresholdKmh: sprintThresholdKmh, maxSpeedKmh: maxSpeed, speedSamples: local.speedSamples),
        ),
      ),
      Expanded(flex: 3, child: _Panel(title: 'Рейтинг скорости', subtitle: '${rows.length} игроков', child: _PlayerRanking(players: rows, mode: _RankingMode.speed))),
    ]);
  }
}

List<TrackerPlayerLoadRow> _periodRowsFromSessions(List<TrackerSessionModel> sessions) {
  final byPlayer = <int, _SessionAccumulator>{};
  for (final s in sessions) {
    final id = s.playerId ?? -1;
    final acc = byPlayer.putIfAbsent(id, () => _SessionAccumulator(id, s.playerName ?? 'Команда'));
    acc.sessions++;
    acc.distance += s.distanceM;
    acc.maxSpeed = math.max(acc.maxSpeed, s.maxSpeedKmh);
    acc.sprints += s.sprintCount;
    acc.sprintDistance += s.sprintDistanceM;
    acc.hsr += s.hsrDistanceM + s.hirDistanceM + s.vhirDistanceM;
    acc.accel += s.accelCount;
    acc.decel += s.decelCount;
    acc.load += s.loadScore;
  }
  return byPlayer.values.map((a) => TrackerPlayerLoadRow(
    playerId: a.playerId > 0 ? a.playerId : null,
    playerName: a.playerName,
    sessionsCount: a.sessions,
    distanceM: a.distance,
    avgSpeedKmh: 0,
    maxSpeedKmh: a.maxSpeed,
    highSpeedDistanceM: a.hsr,
    sprintDistanceM: a.sprintDistance,
    sprintCount: a.sprints,
    accelerationCount: a.accel,
    decelerationCount: a.decel,
    loadScore: a.sessions <= 0 ? 0 : a.load / a.sessions,
  )).toList()
    ..sort((a, b) => b.distanceM.compareTo(a.distanceM));
}


TrackerPlayerLoadRow? _rowFromSession(TrackerSessionModel? session, _LocalTrackAnalysis local, TrackerPlayerOption? selectedPlayer) {
  if (session == null && local.distanceM <= 0 && local.speedSamples.isEmpty) return null;
  final distance = local.distanceM > 0 ? local.distanceM : (session?.distanceM ?? 0);
  final maxSpeed = local.maxSpeedKmh > 0 ? local.maxSpeedKmh : (session?.maxSpeedKmh ?? 0);
  final avgSpeed = local.avgSpeedKmh > 0 ? local.avgSpeedKmh : (session?.avgSpeedKmh ?? 0);
  final sprintDistance = local.sprintDistanceM > 0 ? local.sprintDistanceM : (session?.sprintDistanceM ?? 0);
  final sprintCount = local.sprintCount > 0 ? local.sprintCount : (session?.sprintCount ?? 0);
  final hir = local.hsrDistanceM > 0 ? local.hsrDistanceM : ((session?.hirDistanceM ?? 0) + (session?.vhirDistanceM ?? 0) + (session?.hsrDistanceM ?? 0));
  final accel = local.accelCount > 0 ? local.accelCount : (session?.accelCount ?? 0);
  final decel = local.decelCount > 0 ? local.decelCount : (session?.decelCount ?? 0);
  final load = (session?.loadScore ?? 0) > 0 ? session!.loadScore : (distance / 10.0 + sprintDistance * .35 + hir * .18 + (accel + decel) * 2.5);
  return TrackerPlayerLoadRow(
    playerId: session?.playerId ?? selectedPlayer?.id,
    playerName: session?.playerName ?? selectedPlayer?.name ?? 'Игрок',
    avatar: selectedPlayer?.avatar,
    sessionsCount: session == null ? 0 : 1,
    distanceM: distance,
    avgSpeedKmh: avgSpeed,
    maxSpeedKmh: maxSpeed,
    highSpeedDistanceM: hir,
    sprintDistanceM: sprintDistance,
    sprintCount: sprintCount,
    accelerationCount: accel,
    decelerationCount: decel,
    loadScore: load,
  );
}


List<TrackerPlayerLoadRow> _rowsForAnalytics(_AnalyticsBundle bundle, TrackerSessionModel? selectedSession, _LocalTrackAnalysis local, TrackerPlayerOption? selectedPlayer) {
  final periodRows = _periodRowsFromSessions(bundle.sessions);
  var rows = periodRows.isNotEmpty ? periodRows : bundle.dashboard.players;
  final sessionRow = _rowFromSession(selectedSession, local, selectedPlayer);
  if (sessionRow != null) {
    final exists = rows.any((r) => r.playerId == sessionRow.playerId && sessionRow.playerId != null);
    rows = exists ? rows.map((r) => r.playerId == sessionRow.playerId ? sessionRow : r).toList(growable: false) : <TrackerPlayerLoadRow>[sessionRow, ...rows];
  }
  return rows;
}

class _DayTotal {
  const _DayTotal({
    required this.sessionsCount,
    required this.playersCount,
    required this.distanceM,
    required this.maxSpeedKmh,
    required this.sprintCount,
    required this.sprintDistanceM,
    required this.hirDistanceM,
    required this.accelCount,
    required this.decelCount,
    required this.loadScore,
  });

  final int sessionsCount;
  final int playersCount;
  final double distanceM;
  final double maxSpeedKmh;
  final int sprintCount;
  final double sprintDistanceM;
  final double hirDistanceM;
  final int accelCount;
  final int decelCount;
  final double loadScore;

  factory _DayTotal.fromRows(List<TrackerPlayerLoadRow> rows, {required int sessionsCount, TrackerSessionModel? fallbackSession, required _LocalTrackAnalysis local}) {
    if (rows.isEmpty) {
      final r = _rowFromSession(fallbackSession, local, null);
      if (r == null) {
        return const _DayTotal(sessionsCount: 0, playersCount: 0, distanceM: 0, maxSpeedKmh: 0, sprintCount: 0, sprintDistanceM: 0, hirDistanceM: 0, accelCount: 0, decelCount: 0, loadScore: 0);
      }
      return _DayTotal.fromRows(<TrackerPlayerLoadRow>[r], sessionsCount: sessionsCount <= 0 ? 1 : sessionsCount, fallbackSession: null, local: const _LocalTrackAnalysis(distanceM: 0, durationSec: 0, maxSpeedKmh: 0, avgSpeedKmh: 0, sprintCount: 0, sprintDistanceM: 0, hsrDistanceM: 0, accelCount: 0, decelCount: 0, speedSamples: <double>[]));
    }
    return _DayTotal(
      sessionsCount: sessionsCount <= 0 ? rows.fold<int>(0, (s, r) => s + math.max(1, r.sessionsCount)) : sessionsCount,
      playersCount: rows.where((r) => (r.playerId ?? 0) > 0).map((r) => r.playerId).toSet().length,
      distanceM: rows.fold<double>(0, (s, r) => s + r.distanceM),
      maxSpeedKmh: rows.fold<double>(0, (s, r) => math.max(s, r.maxSpeedKmh)),
      sprintCount: rows.fold<int>(0, (s, r) => s + r.sprintCount),
      sprintDistanceM: rows.fold<double>(0, (s, r) => s + r.sprintDistanceM),
      hirDistanceM: rows.fold<double>(0, (s, r) => s + r.highSpeedDistanceM),
      accelCount: rows.fold<int>(0, (s, r) => s + r.accelerationCount),
      decelCount: rows.fold<int>(0, (s, r) => s + r.decelerationCount),
      loadScore: rows.fold<double>(0, (s, r) => s + r.loadScore),
    );
  }
}

class _SessionAccumulator {
  _SessionAccumulator(this.playerId, this.playerName);
  final int playerId;
  final String playerName;
  int sessions = 0;
  double distance = 0;
  double maxSpeed = 0;
  int sprints = 0;
  double sprintDistance = 0;
  double hsr = 0;
  int accel = 0;
  int decel = 0;
  double load = 0;
}

class _TeamTab extends StatelessWidget {
  const _TeamTab({required this.bundle, required this.selectedSession, required this.local, required this.players, required this.selectedPlayer, required this.onSelectPlayer});
  final _AnalyticsBundle bundle;
  final TrackerSessionModel? selectedSession;
  final _LocalTrackAnalysis local;
  final List<TrackerPlayerOption> players;
  final TrackerPlayerOption? selectedPlayer;
  final ValueChanged<int> onSelectPlayer;

  @override
  Widget build(BuildContext context) {
    var rows = _rowsForAnalytics(bundle, selectedSession, local, selectedPlayer);
    final teamRows = rows;
    final selectedRows = selectedPlayer?.id == null ? rows : rows.where((r) => r.playerId == selectedPlayer!.id).toList(growable: false);
    final radarPlayerRows = selectedRows.isNotEmpty ? selectedRows : rows;
    return Row(children: [
      Expanded(flex: 6, child: _Panel(title: 'Командная статистика', subtitle: '${rows.length} игроков · выбранный период/сессия', child: _TeamTable(rows: rows, selectedPlayer: selectedPlayer, onSelectPlayer: onSelectPlayer))),
      Expanded(flex: 4, child: _Panel(title: 'Радар команды', subtitle: 'средний профиль всех игроков', child: CustomPaint(painter: _RadarPainter(rows: teamRows), child: const SizedBox.expand()))),
      Expanded(flex: 4, child: _Panel(title: selectedPlayer == null ? 'Радар игрока' : 'Радар игрока: ${selectedPlayer!.name}', subtitle: selectedSession == null ? 'период / live' : 'сессия #${selectedSession!.id}', child: CustomPaint(painter: _RadarPainter(rows: radarPlayerRows, baselineRows: teamRows), child: const SizedBox.expand()))),
      Expanded(flex: 4, child: _Panel(title: 'Расшифровка сессии', subtitle: selectedSession?.title ?? 'выберите запись', child: selectedSession == null ? const _Empty(icon: Icons.radar_rounded, text: 'Выберите дату или сессию, чтобы увидеть профиль игрока и команды.') : _SessionSummary(session: selectedSession!, local: local))),
    ]);
  }
}


class _RatingsTab extends StatefulWidget {
  const _RatingsTab({required this.bundle, required this.local, required this.teamName, required this.selectedPlayer, required this.selectedSession});
  final _AnalyticsBundle bundle;
  final _LocalTrackAnalysis local;
  final String teamName;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerSessionModel? selectedSession;

  @override
  State<_RatingsTab> createState() => _RatingsTabState();
}

class _RatingsTabState extends State<_RatingsTab> {
  _RankingMode _mode = _RankingMode.distance;

  @override
  Widget build(BuildContext context) {
    final rows = _rowsForAnalytics(widget.bundle, widget.selectedSession, widget.local, widget.selectedPlayer);
    final allRows = _rowsForAnalytics(widget.bundle, widget.selectedSession, widget.local, null);
    final selectedRows = widget.selectedPlayer?.id == null ? <TrackerPlayerLoadRow>[] : allRows.where((r) => r.playerId == widget.selectedPlayer!.id).toList(growable: false);
    final sorted = [...rows]..sort((a, b) => _value(b).compareTo(_value(a)));
    final total = _DayTotal.fromRows(allRows, sessionsCount: widget.bundle.sessions.length, fallbackSession: widget.selectedSession, local: widget.local);
    return Row(children: [
      Expanded(
        flex: 5,
        child: _Panel(
          title: 'Рейтинг игроков',
          subtitle: 'по выбранным сессиям',
          child: Column(children: [
            SizedBox(
              height: 34,
              child: ListView(scrollDirection: Axis.horizontal, children: [
                _RankModeChip(label: 'Дистанция', mode: _RankingMode.distance, value: _mode, onChanged: _setMode),
                _RankModeChip(label: 'Скорость', mode: _RankingMode.speed, value: _mode, onChanged: _setMode),
                _RankModeChip(label: 'Спринты', mode: _RankingMode.sprints, value: _mode, onChanged: _setMode),
                _RankModeChip(label: 'Нагрузка', mode: _RankingMode.load, value: _mode, onChanged: _setMode),
              ]),
            ),
            Expanded(child: _PlayerRanking(players: sorted, mode: _mode)),
          ]),
        ),
      ),
      Expanded(
        flex: 4,
        child: _Panel(
          title: 'Рейтинг команды',
          subtitle: 'сравнение доступных команд / групп',
          child: Column(children: [
            _TeamCompareRow(name: widget.teamName, value: _meters(total.distanceM), note: '${total.playersCount} игроков · ${total.sessionsCount} сессий', rank: 1),
            const _InlineNotice(text: 'Когда появятся данные других команд, они будут показаны здесь для сравнения по тем же выбранным сессиям.'),
            Expanded(child: CustomPaint(painter: _RadarPainter(rows: allRows), child: const SizedBox.expand())),
          ]),
        ),
      ),
      Expanded(
        flex: 4,
        child: _Panel(
          title: 'Сравнение игрока',
          subtitle: 'игрок против среднего команды',
          child: CustomPaint(painter: _RadarPainter(rows: selectedRows.isNotEmpty ? selectedRows : rows, baselineRows: allRows), child: const SizedBox.expand()),
        ),
      ),
    ]);
  }

  void _setMode(_RankingMode mode) => setState(() => _mode = mode);

  double _value(TrackerPlayerLoadRow row) {
    switch (_mode) {
      case _RankingMode.speed:
        return row.maxSpeedKmh;
      case _RankingMode.sprints:
        return row.sprintCount.toDouble() * 1000 + row.sprintDistanceM;
      case _RankingMode.load:
        return row.loadScore;
      case _RankingMode.distance:
      default:
        return row.distanceM;
    }
  }
}

class _RankModeChip extends StatelessWidget {
  const _RankModeChip({required this.label, required this.mode, required this.value, required this.onChanged});
  final String label;
  final _RankingMode mode;
  final _RankingMode value;
  final ValueChanged<_RankingMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final active = mode == value;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: _SmallButton(icon: Icons.leaderboard_rounded, label: label, primary: active, onTap: () => onChanged(mode)),
    );
  }
}

class _TeamCompareRow extends StatelessWidget {
  const _TeamCompareRow({required this.name, required this.value, required this.note, required this.rank});
  final String name;
  final String value;
  final String note;
  final int rank;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
      child: Row(children: [
        Text('$rank', style: const TextStyle(color: _AA.muted, fontSize: 10, fontWeight: FontWeight.w900)),
        const SizedBox(width: 8),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10.5, fontWeight: FontWeight.w900)),
          Text(note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
        ])),
        Text(value, style: const TextStyle(color: _AA.green, fontSize: 10.2, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _SessionsTab extends StatelessWidget {
  const _SessionsTab({
    required this.sessions,
    required this.selectedSession,
    required this.selectedDate,
    required this.onlySelectedDate,
    required this.onPrevDate,
    required this.onNextDate,
    required this.onToday,
    required this.onPickDate,
    required this.onSelectSession,
    required this.onOpenSessions,
    this.usingLatestFallback = false,
    this.fallbackMessage = '',
  });

  final List<TrackerSessionModel> sessions;
  final TrackerSessionModel? selectedSession;
  final DateTime selectedDate;
  final bool onlySelectedDate;
  final VoidCallback onPrevDate;
  final VoidCallback onNextDate;
  final VoidCallback onToday;
  final VoidCallback onPickDate;
  final ValueChanged<TrackerSessionModel> onSelectSession;
  final VoidCallback onOpenSessions;
  final bool usingLatestFallback;
  final String fallbackMessage;

  String get _dateLabel => '${selectedDate.day.toString().padLeft(2, '0')}.${selectedDate.month.toString().padLeft(2, '0')}.${selectedDate.year}';

  @override
  Widget build(BuildContext context) {
    final byPlayer = <int, int>{};
    for (final s in sessions) {
      final id = s.playerId ?? -1;
      byPlayer[id] = (byPlayer[id] ?? 0) + 1;
    }

    return Row(children: [
      Expanded(flex: 4, child: _Panel(title: 'Календарь сессий', subtitle: onlySelectedDate ? 'выбран день $_dateLabel' : 'все даты', child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Row(children: [
          _IconOnlyButton(icon: Icons.chevron_left_rounded, onTap: onPrevDate),
          Expanded(child: InkWell(onTap: onPickDate, borderRadius: BorderRadius.circular(4), child: Container(
            height: 38,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(4), border: Border.all(color: _AA.green.withOpacity(.25))),
            child: Text(_dateLabel, style: const TextStyle(color: _AA.text, fontWeight: FontWeight.w900)),
          ))),
          _IconOnlyButton(icon: Icons.chevron_right_rounded, onTap: onNextDate),
        ]),
        const SizedBox(height: 0),
        _SmallButton(icon: Icons.today_rounded, label: 'Сегодня', onTap: onToday),
        const SizedBox(height: 0),
        _InfoLine(title: usingLatestFallback ? 'Показано' : 'Сессий за период', value: usingLatestFallback ? 'последняя сессия' : '${sessions.length}'),
        _InfoLine(title: 'Игроков с данными', value: '${byPlayer.keys.where((e) => e > 0).length}'),
        if (usingLatestFallback) _Hint(text: fallbackMessage),
        const SizedBox(height: 0),
        const _Hint(text: 'Данные больше не смешиваются бесконечно: выбирайте дату или конкретную сессию. Live-точки остаются на экране отдельно, пока сессия идёт.'),
      ]))),
      const SizedBox.shrink(),
      Expanded(flex: 6, child: _Panel(title: 'История сессий', subtitle: '${sessions.length} записей', child: sessions.isEmpty
          ? const _Empty(icon: Icons.event_note_rounded, text: 'Сессии появятся после Live, стопа с сохранением или выгрузки офлайн GPS.')
          : ListView(children: sessions.map((s) {
              final active = selectedSession?.id == s.id;
              return _ListRow(
                icon: Icons.assignment_rounded,
                title: s.title,
                subtitle: '${s.playerName ?? 'Команда'} · ${s.createdAt} · ${_meters(s.distanceM)} · ${s.sprintCount} спринтов',
                trailing: s.processingStatus == 'done' ? 'готово' : s.processingStatus,
                active: active,
                onTap: () => onSelectSession(s),
              );
            }).toList()))),
      const SizedBox.shrink(),
      Expanded(flex: 5, child: _Panel(title: 'Расшифровка', subtitle: selectedSession?.title ?? 'выберите сессию', child: selectedSession == null
          ? const _Empty(icon: Icons.analytics_rounded, text: 'Выберите сессию слева: карта, спринты, скорость и команда будут строиться по выбранной записи.')
          : _SessionSummary(session: selectedSession!))),
      const SizedBox.shrink(),
      Expanded(flex: 3, child: _Panel(title: 'Действия', subtitle: 'отчёты и экспорт', child: Column(children: [
        _SmallButton(icon: Icons.table_chart_rounded, label: 'Открыть отчёты', primary: true, onTap: onOpenSessions),
        const SizedBox(height: 0),
        const _Hint(text: 'Для командной аналитики передавайте датчик другому игроку после остановки и сохранения текущей сессии. У каждого игрока будет своя запись в календаре.'),
      ]))),
    ]);
  }
}

class _OfflineTab extends StatelessWidget {
  const _OfflineTab({
    required this.liveRunning,
    required this.commandChannelReady,
    required this.offlineRecordsCount,
    required this.localPointsCount,
    required this.offlineGpsMode,
    required this.onToggleOfflineGpsMode,
    required this.onRequestOfflineRecords,
    required this.onSaveOfflineSession,
    required this.onOpenSessions,
  });

  final bool liveRunning;
  final bool commandChannelReady;
  final int offlineRecordsCount;
  final int localPointsCount;
  final bool offlineGpsMode;
  final ValueChanged<bool> onToggleOfflineGpsMode;
  final VoidCallback onRequestOfflineRecords;
  final VoidCallback onSaveOfflineSession;
  final VoidCallback onOpenSessions;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(flex: 5, child: _Panel(title: 'Офлайн GPS с датчика', subtitle: commandChannelReady ? 'BLE TX/RX готов' : 'нужен реальный BLE-канал', child: Column(children: [
        SwitchListTile.adaptive(
          dense: true,
          contentPadding: EdgeInsets.zero,
          value: offlineGpsMode,
          onChanged: onToggleOfflineGpsMode,
          title: const Text('Режим офлайн-выгрузки', style: TextStyle(fontWeight: FontWeight.w900, color: _AA.text)),
          subtitle: const Text('Сначала читаем список записей с датчика, затем загружаем GPS-точки и сохраняем как сессию.', style: TextStyle(color: _AA.muted, fontSize: 10.2)),
        ),
        _InfoLine(title: 'BLE канал', value: commandChannelReady ? 'TX/RX готов' : 'нет TX/RX'),
        _InfoLine(title: 'Live', value: liveRunning ? 'идёт' : 'не запущен'),
        _InfoLine(title: 'Записей в датчике', value: '$offlineRecordsCount'),
        _InfoLine(title: 'Загружено точек', value: '$localPointsCount'),
        const Spacer(),
        _SmallButton(icon: Icons.download_rounded, label: 'Прочитать записи', primary: true, onTap: onRequestOfflineRecords),
        const SizedBox(height: 0),
        _SmallButton(icon: Icons.cloud_upload_rounded, label: 'Сохранить как сессию', onTap: onSaveOfflineSession),
      ]))),
      const SizedBox.shrink(),
      Expanded(flex: 5, child: _Panel(title: 'Как работает офлайн', subtitle: 'без постоянного Live', child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: const [
        _Hint(text: '1. Датчик записывает GPS внутри себя.\n2. После тренировки подключаем датчик.\n3. Нажимаем «Прочитать записи».\n4. Выбираем запись в «Сессиях».\n5. Загружаем GPS-точки и сохраняем тренировку.'),
        SizedBox(height: 10),
        _Hint(text: 'Кнопка чтения использует реальную команду списка записей датчика, а сохранение отправляет загруженные GPS-точки в API сессий.'),
      ]))),
      const SizedBox.shrink(),
      Expanded(flex: 4, child: _Panel(title: 'Сессии', subtitle: 'открыть полный список', child: Column(children: [
        const _Empty(icon: Icons.event_note_rounded, text: 'В полном разделе видны записи датчика, серверные сессии и встроенный отчёт.'),
        const SizedBox(height: 0),
        _SmallButton(icon: Icons.event_note_rounded, label: 'Открыть сессии', onTap: onOpenSessions),
      ]))),
    ]);
  }
}

class _SettingsTab extends StatelessWidget {
  const _SettingsTab({
    required this.field,
    required this.gpsOffsetFix,
    required this.gpsOffsetMode,
    required this.linearDepth,
    required this.mapRotationDeg,
    required this.sprintThresholdKmh,
    required this.hsrThresholdKmh,
    required this.showSprintArrows,
    required this.onOpenCalibration,
    required this.onSettingsChanged,
    required this.onDebug,
  });

  final TrackerFieldModel? field;
  final bool gpsOffsetFix;
  final String gpsOffsetMode;
  final double linearDepth;
  final double mapRotationDeg;
  final double sprintThresholdKmh;
  final double hsrThresholdKmh;
  final bool showSprintArrows;
  final VoidCallback onOpenCalibration;
  final void Function({bool? gpsOffsetFix, String? gpsOffsetMode, double? linearDepth, double? mapRotationDeg, double? sprintThresholdKmh, double? hsrThresholdKmh, bool? showSprintArrows}) onSettingsChanged;
  final void Function(String message, Map<String, dynamic> context) onDebug;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(flex: 5, child: _Panel(title: 'Калибровка поля', subtitle: field?.title ?? 'нет поля', child: Column(children: [
        _CalibrationMini(field: field),
        const SizedBox(height: 0),
        _InfoLine(title: 'A/B/C/D', value: field?.hasCalibration == true ? 'сохранены' : 'не готовы'),
        _InfoLine(title: 'Поворот карты', value: '${mapRotationDeg.toStringAsFixed(0)}°'),
        _SmallButton(icon: Icons.map_rounded, label: 'Калибровать A/B/C/D', primary: true, onTap: onOpenCalibration),
      ]))),
      const SizedBox.shrink(),
      Expanded(flex: 6, child: _Panel(title: 'Настройки карты и GPS', subtitle: 'смещение, глубина, поворот', child: ListView(children: [
        SwitchListTile.adaptive(
          dense: true,
          contentPadding: EdgeInsets.zero,
          value: gpsOffsetFix,
          onChanged: (v) => onSettingsChanged(gpsOffsetFix: v),
          title: const Text('Коррекция GPS-смещения', style: TextStyle(fontWeight: FontWeight.w900, color: _AA.text)),
          subtitle: const Text('Коррекция смещения GPS перед построением карты.', style: TextStyle(color: _AA.muted, fontSize: 10.2)),
        ),
        _ChoiceLine(
          label: 'Режим коррекции',
          value: gpsOffsetMode,
          values: const {'auto': 'Авто', 'soft': 'Мягко', 'hard': 'Жёстко'},
          onChanged: (v) => onSettingsChanged(gpsOffsetMode: v),
        ),
        _SliderLine(label: 'Глубина сглаживания', value: linearDepth, min: 1, max: 8, divisions: 7, suffix: 'x', onChanged: (v) => onSettingsChanged(linearDepth: v)),
        _SliderLine(label: 'Поворот карты', value: mapRotationDeg, min: -180, max: 180, divisions: 12, suffix: '°', onChanged: (v) => onSettingsChanged(mapRotationDeg: v)),
        SwitchListTile.adaptive(
          dense: true,
          contentPadding: EdgeInsets.zero,
          value: showSprintArrows,
          onChanged: (v) => onSettingsChanged(showSprintArrows: v),
          title: const Text('Спринты стрелками', style: TextStyle(fontWeight: FontWeight.w900, color: _AA.text)),
          subtitle: const Text('На карте спринты показываются направленными стрелками.', style: TextStyle(color: _AA.muted, fontSize: 10.2)),
        ),
      ]))),
      const SizedBox.shrink(),
      Expanded(flex: 5, child: _Panel(title: 'Пороги и отладка', subtitle: 'скорость / спринты / высокая интенсивность', child: ListView(children: [
        _SliderLine(label: 'Высокая интенсивность', value: hsrThresholdKmh, min: 10, max: 24, divisions: 14, suffix: 'км/ч', onChanged: (v) => onSettingsChanged(hsrThresholdKmh: v)),
        _SliderLine(label: 'Спринт', value: sprintThresholdKmh, min: 14, max: 30, divisions: 16, suffix: 'км/ч', onChanged: (v) => onSettingsChanged(sprintThresholdKmh: v)),
        const _ZoneLine(label: 'Профиль', value: 'ДЮФ: пороги ниже взрослой методики'),
        const _ZoneLine(label: 'Фильтр стояния', value: 'GPS прыжки режутся'),
        const SizedBox(height: 0),
        _SmallButton(icon: Icons.bug_report_rounded, label: 'Отправить отладку', onTap: () => onDebug('Отладка настроек аналитики', {
          'field_ready': field?.hasCalibration == true,
          'field_id': field?.id,
          'gps_offset_fix': gpsOffsetFix,
          'gps_offset_mode': gpsOffsetMode,
          'linear_depth': linearDepth,
          'map_rotation_deg': mapRotationDeg,
          'sprint_threshold_kmh': sprintThresholdKmh,
          'hsr_threshold_kmh': hsrThresholdKmh,
          'show_sprint_arrows': showSprintArrows,
        })),
      ]))),
    ]);
  }
}

class _Panel extends StatelessWidget {
  const _Panel({required this.title, required this.subtitle, required this.child});
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(color: _AA.card, border: Border(right: BorderSide(color: _AA.line))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          height: 32,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
          child: Row(children: [
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10.6, fontWeight: FontWeight.w800)),
              Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w600)),
            ])),
          ]),
        ),
        Expanded(child: Padding(padding: const EdgeInsets.all(6), child: child)),
      ]),
    );
  }
}


class _InlineNotice extends StatelessWidget {
  const _InlineNotice({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 28,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: const BoxDecoration(color: Color(0xFFFFFBEB), border: Border(bottom: BorderSide(color: _AA.line))),
      child: Row(children: [
        const Icon(Icons.info_outline_rounded, color: _AA.orange, size: 14),
        const SizedBox(width: 6),
        Expanded(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 9.6, fontWeight: FontWeight.w700))),
      ]),
    );
  }
}

class _MiniNumber extends StatelessWidget {
  const _MiniNumber({required this.title, required this.value, required this.note});
  final String title;
  final String value;
  final String note;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: const BoxDecoration(border: Border(right: BorderSide(color: _AA.line), bottom: BorderSide(color: _AA.line))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.5, fontWeight: FontWeight.w700)),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 12.2, fontWeight: FontWeight.w900)),
        Text(note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.2, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _PlayerActivityProfilePanel extends StatelessWidget {
  const _PlayerActivityProfilePanel({required this.selectedPlayer, required this.selectedSession, required this.local, required this.heatmap, required this.title});
  final TrackerPlayerOption? selectedPlayer;
  final TrackerSessionModel? selectedSession;
  final _LocalTrackAnalysis local;
  final List<TrackerHeatPoint> heatmap;
  final String title;

  @override
  Widget build(BuildContext context) {
    final axes = _activityAxes(local: local, session: selectedSession);
    return _Panel(
      title: title,
      subtitle: '${selectedPlayer?.name ?? selectedSession?.playerName ?? 'Команда'} · радар + мини-теплокарта',
      child: Column(children: [
        Expanded(flex: 7, child: CustomPaint(painter: _ActivityRadarPainter(axes: axes), child: const SizedBox.expand())),
        Container(height: 1, color: _AA.line),
        Expanded(flex: 5, child: CustomPaint(painter: _MiniHeatmapPainter(points: heatmap), child: const SizedBox.expand())),
        Container(height: 1, color: _AA.line),
        SizedBox(height: 46, child: Row(children: [
          Expanded(child: _MiniNumber(title: 'Уск/торм', value: '${local.accelCount > 0 ? local.accelCount : selectedSession?.accelCount ?? 0}/${local.decelCount > 0 ? local.decelCount : selectedSession?.decelCount ?? 0}', note: 'механика')),
          Expanded(child: _MiniNumber(title: 'Нагрузка', value: (selectedSession?.loadScore ?? 0).toStringAsFixed(0), note: 'сессия')),
          Expanded(child: _MiniNumber(title: 'Теплокарта', value: '${heatmap.length}', note: 'точек')),
        ])),
      ]),
    );
  }
}

class _ActivityAxisValue {
  const _ActivityAxisValue(this.label, this.value);
  final String label;
  final double value;
}

List<_ActivityAxisValue> _activityAxes({required _LocalTrackAnalysis local, required TrackerSessionModel? session}) {
  double clamp(double v) => v.isNaN || v.isInfinite ? 0 : v.clamp(0.0, 1.0).toDouble();
  final distance = local.distanceM > 0 ? local.distanceM : (session?.distanceM ?? 0);
  final maxSpeed = local.maxSpeedKmh > 0 ? local.maxSpeedKmh : (session?.maxSpeedKmh ?? 0);
  final sprintDistance = local.sprintDistanceM > 0 ? local.sprintDistanceM : (session?.sprintDistanceM ?? 0);
  final sprintCount = local.sprintCount > 0 ? local.sprintCount : (session?.sprintCount ?? 0);
  final hir = local.hsrDistanceM > 0 ? local.hsrDistanceM : ((session?.hirDistanceM ?? 0) + (session?.vhirDistanceM ?? 0));
  final accel = local.accelCount > 0 ? local.accelCount : (session?.accelCount ?? 0);
  final decel = local.decelCount > 0 ? local.decelCount : (session?.decelCount ?? 0);
  final load = session?.loadScore ?? 0;
  return <_ActivityAxisValue>[
    _ActivityAxisValue('Объём', clamp(distance / 9000.0)),
    _ActivityAxisValue('Скорость', clamp(maxSpeed / 34.0)),
    _ActivityAxisValue('Спринт', clamp((sprintDistance / 650.0 + sprintCount / 35.0) / 2.0)),
    _ActivityAxisValue('Интенс.', clamp(hir / 1800.0)),
    _ActivityAxisValue('Манёвр', clamp((accel + decel) / 140.0)),
    _ActivityAxisValue('Load', clamp(load / 1000.0)),
  ];
}

class _SpeedZonesPanel extends StatelessWidget {
  const _SpeedZonesPanel({required this.hsrThresholdKmh, required this.sprintThresholdKmh, required this.maxSpeedKmh, this.speedSamples = const <double>[]});
  final double hsrThresholdKmh;
  final double sprintThresholdKmh;
  final double maxSpeedKmh;
  final List<double> speedSamples;

  @override
  Widget build(BuildContext context) {
    final samples = speedSamples.where((v) => v.isFinite && v >= 0).toList(growable: false);
    final total = samples.length;
    double share(bool Function(double v) test) {
      if (total <= 0) return 0;
      return samples.where(test).length / total;
    }
    String note(bool Function(double v) test, String range) {
      if (total <= 0) return range;
      final count = samples.where(test).length;
      final percent = (count * 100 / total).round();
      return '$range · $percent% · $count точ.';
    }

    return ListView(children: [
      _ZoneProgress(label: 'Ходьба / лёгкая работа', range: note((v) => v < 7, '< 7 км/ч'), value: share((v) => v < 7), color: _AA.green.withOpacity(.50)),
      _ZoneProgress(label: 'Бег', range: note((v) => v >= 7 && v < hsrThresholdKmh, '7–${hsrThresholdKmh.toStringAsFixed(1)} км/ч'), value: share((v) => v >= 7 && v < hsrThresholdKmh), color: _AA.green),
      _ZoneProgress(label: 'Высокая интенсивность', range: note((v) => v >= hsrThresholdKmh && v < sprintThresholdKmh, '${hsrThresholdKmh.toStringAsFixed(1)}–${sprintThresholdKmh.toStringAsFixed(1)} км/ч'), value: share((v) => v >= hsrThresholdKmh && v < sprintThresholdKmh), color: _AA.orange),
      _ZoneProgress(label: 'Спринт', range: note((v) => v >= sprintThresholdKmh, '> ${sprintThresholdKmh.toStringAsFixed(1)} км/ч'), value: share((v) => v >= sprintThresholdKmh), color: _AA.red),
      const SizedBox(height: 6),
      _Hint(text: total > 0
          ? 'Полосы показывают долю GPS-точек в зоне, а не просто факт достижения максимальной скорости.'
          : 'Нет GPS-точек speed_kmh для расчёта долей зон. Максимальная скорость: ${maxSpeedKmh.toStringAsFixed(1)} км/ч.'),
    ]);
  }
}

class _ZoneProgress extends StatelessWidget {
  const _ZoneProgress({required this.label, required this.range, required this.value, required this.color});
  final String label;
  final String range;
  final double value;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 7),
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _AA.line))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(color: _AA.text, fontSize: 9.8, fontWeight: FontWeight.w800))),
          Text(range, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
        ]),
        const SizedBox(height: 5),
        ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(value: value.clamp(0.0, 1.0).toDouble(), minHeight: 5, backgroundColor: const Color(0xFFE5E7EB), valueColor: AlwaysStoppedAnimation<Color>(color)),
        ),
      ]),
    );
  }
}


class _MapModeButton extends StatelessWidget {
  const _MapModeButton({required this.label, required this.icon, required this.active, required this.onTap});
  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 32,
        padding: const EdgeInsets.symmetric(horizontal: 9),
        decoration: BoxDecoration(
          color: active ? _AA.soft : _AA.card,
          border: const Border(right: BorderSide(color: _AA.line)),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 14, color: active ? _AA.green : _AA.muted),
          const SizedBox(width: 5),
          Text(label, style: TextStyle(color: active ? _AA.green : _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  const _Metric({required this.icon, required this.title, required this.value, required this.note});
  final IconData icon;
  final String title;
  final String value;
  final String note;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: const BoxDecoration(color: _AA.card, border: Border(bottom: BorderSide(color: _AA.line))),
      child: Row(children: [
        Container(width: 24, height: 24, decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(6)), child: Icon(icon, color: _AA.green, size: 15)),
        const SizedBox(width: 4),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w700)),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 12.4, fontWeight: FontWeight.w800)),
          Text(note, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.4, fontWeight: FontWeight.w600)),
        ])),
      ]),
    );
  }
}

class _StatusCard extends StatelessWidget {
  const _StatusCard({required this.selectedPlayer, required this.selectedField, required this.onOpenCalibration});
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final VoidCallback onOpenCalibration;

  @override
  Widget build(BuildContext context) {
    return _Panel(title: 'Готовность аналитики', subtitle: 'игрок, поле, карта', child: Column(children: [
      _InfoLine(title: 'Игрок', value: selectedPlayer?.name ?? 'Команда'),
      _InfoLine(title: 'Поле', value: selectedField?.title ?? 'не выбрано'),
      _InfoLine(title: 'Калибровка', value: selectedField?.hasCalibration == true ? 'A/B/C/D сохранены' : 'нужно настроить'),
      const SizedBox(height: 0),
      _SmallButton(icon: Icons.map_rounded, label: 'Калибровка поля', primary: selectedField?.hasCalibration != true, onTap: onOpenCalibration),
    ]));
  }
}

class _WorkflowCard extends StatelessWidget {
  const _WorkflowCard({required this.onOpenCalibration, required this.onOpenSessions});
  final VoidCallback onOpenCalibration;
  final VoidCallback onOpenSessions;

  @override
  Widget build(BuildContext context) {
    return _Panel(title: 'Рабочий процесс', subtitle: 'логика модулей', child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      const _Hint(text: '1. Подключить датчики.\n2. Калибровать поле A/B/C/D.\n3. Запустить Live или выгрузить GPS.\n4. Открыть теплокарту, спринты, скорость, команду и отчёт.'),
      const Spacer(),
      _SmallButton(icon: Icons.map_rounded, label: 'Поле', onTap: onOpenCalibration),
      const SizedBox(height: 0),
      _SmallButton(icon: Icons.event_note_rounded, label: 'Сессии', onTap: onOpenSessions),
    ]));
  }
}

class _TeamLeadersCard extends StatelessWidget {
  const _TeamLeadersCard({required this.bundle});
  final _AnalyticsBundle bundle;

  @override
  Widget build(BuildContext context) {
    final rows = [...(_periodRowsFromSessions(bundle.sessions).isNotEmpty ? _periodRowsFromSessions(bundle.sessions) : bundle.dashboard.players)]..sort((a, b) => b.distanceM.compareTo(a.distanceM));
    return _Panel(title: 'Лидеры команды', subtitle: '${rows.length} игроков', child: rows.isEmpty
        ? const _Empty(icon: Icons.groups_rounded, text: 'Командная статистика появится после обработки сессий.')
        : ListView(children: rows.take(12).map((p) => _ListRow(
              icon: Icons.person_rounded,
              title: p.playerName,
              subtitle: '${_meters(p.distanceM)} · ${p.maxSpeedKmh.toStringAsFixed(1)} км/ч · ${p.sprintCount} спринтов',
            )).toList()));
  }
}

class _PlayerRanking extends StatelessWidget {
  const _PlayerRanking({required this.players, required this.mode});
  final List<TrackerPlayerLoadRow> players;
  final _RankingMode mode;

  @override
  Widget build(BuildContext context) {
    if (players.isEmpty) return const _Empty(icon: Icons.leaderboard_rounded, text: 'Нет обработанных данных для рейтинга.');
    return ListView(children: players.take(14).map((p) {
      final value = _valueText(p);
      return _ListRow(
        icon: mode == _RankingMode.sprints ? Icons.flash_on_rounded : (mode == _RankingMode.speed ? Icons.speed_rounded : (mode == _RankingMode.load ? Icons.bolt_rounded : Icons.route_rounded)),
        title: p.playerName,
        subtitle: '${_meters(p.distanceM)} · max ${p.maxSpeedKmh.toStringAsFixed(1)} км/ч · SPR ${p.sprintCount} · Load ${p.loadScore.toStringAsFixed(0)}',
        trailing: value,
      );
    }).toList());
  }

  String _valueText(TrackerPlayerLoadRow p) {
    switch (mode) {
      case _RankingMode.speed:
        return '${p.maxSpeedKmh.toStringAsFixed(1)} км/ч';
      case _RankingMode.sprints:
        return '${p.sprintCount}';
      case _RankingMode.load:
        return p.loadScore.toStringAsFixed(0);
      case _RankingMode.distance:
      default:
        return _meters(p.distanceM);
    }
  }
}

enum _RankingMode { distance, sprints, speed, load }

class _TeamTable extends StatelessWidget {
  const _TeamTable({required this.rows, required this.selectedPlayer, required this.onSelectPlayer});
  final List<TrackerPlayerLoadRow> rows;
  final TrackerPlayerOption? selectedPlayer;
  final ValueChanged<int> onSelectPlayer;

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const _Empty(icon: Icons.table_chart_rounded, text: 'Нет командных данных.');
    return ListView(children: rows.map((p) {
      final active = selectedPlayer?.id == p.playerId;
      return _ListRow(
        icon: Icons.person_rounded,
        title: p.playerName,
        subtitle: '${_meters(p.distanceM)} · HIR ${_meters(p.highSpeedDistanceM)} · Уск/торм ${p.accelerationCount}/${p.decelerationCount} · Load ${p.loadScore.toStringAsFixed(0)}',
        trailing: '${p.maxSpeedKmh.toStringAsFixed(1)} км/ч',
        active: active,
        onTap: p.playerId == null ? null : () => onSelectPlayer(p.playerId!),
      );
    }).toList());
  }
}

class _SessionSummary extends StatelessWidget {
  const _SessionSummary({required this.session, this.local});
  final TrackerSessionModel session;
  final _LocalTrackAnalysis? local;

  @override
  Widget build(BuildContext context) {
    final l = local;
    final distance = (l?.distanceM ?? 0) > 0 ? l!.distanceM : session.distanceM;
    final maxSpeed = (l?.maxSpeedKmh ?? 0) > 0 ? l!.maxSpeedKmh : session.maxSpeedKmh;
    final sprintCount = (l?.sprintCount ?? 0) > 0 ? l!.sprintCount : session.sprintCount;
    final sprintDistance = (l?.sprintDistanceM ?? 0) > 0 ? l!.sprintDistanceM : session.sprintDistanceM;
    final accel = (l?.accelCount ?? 0) > 0 ? l!.accelCount : session.accelCount;
    final decel = (l?.decelCount ?? 0) > 0 ? l!.decelCount : session.decelCount;
    final load = session.loadScore > 0 ? session.loadScore : (distance / 10.0 + sprintDistance * .35 + (accel + decel) * 2.5);
    return Column(children: [
      _InfoLine(title: 'Игрок', value: session.playerName ?? 'Команда'),
      _InfoLine(title: 'Дата', value: _formatSessionDateTime(session.createdAt)),
      _InfoLine(title: 'Дистанция', value: _meters(distance)),
      _InfoLine(title: 'Макс. скорость', value: '${maxSpeed.toStringAsFixed(1)} км/ч'),
      _InfoLine(title: 'Спринты', value: '$sprintCount · ${_meters(sprintDistance)}'),
      _InfoLine(title: 'Ускорения / торможения', value: '$accel / $decel'),
      _InfoLine(title: 'Нагрузка', value: '${load.toStringAsFixed(0)} · ${session.loadPerMinute.toStringAsFixed(1)}/мин'),
      const SizedBox(height: 0),
      const _Hint(text: 'Полный отчёт открывается в разделе «Отчёты». Этот блок сделан как быстрый экран сессии в стиле официальной программы.'),
    ]);
  }
}

class _CalibrationMini extends StatelessWidget {
  const _CalibrationMini({required this.field});
  final TrackerFieldModel? field;

  @override
  Widget build(BuildContext context) {
    return CustomPaint(painter: _CalibrationMiniPainter(field: field), child: const SizedBox.expand());
  }
}

class _SessionAvatar extends StatelessWidget {
  const _SessionAvatar({required this.player});
  final TrackerPlayerOption? player;

  @override
  Widget build(BuildContext context) {
    final avatar = player?.avatar;
    final initials = (player?.name ?? 'И').trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).take(2).map((e) => e.substring(0, 1)).join().toUpperCase();
    return Container(
      width: 28,
      height: 28,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(14), border: Border.all(color: _AA.line)),
      child: avatar != null && avatar.isNotEmpty
          ? Image.network(avatar, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Center(child: Text(initials.isEmpty ? 'И' : initials, style: const TextStyle(color: _AA.text, fontSize: 9, fontWeight: FontWeight.w900))))
          : Center(child: Text(initials.isEmpty ? 'И' : initials, style: const TextStyle(color: _AA.text, fontSize: 9, fontWeight: FontWeight.w900))),
    );
  }
}

class _ListRow extends StatelessWidget {
  const _ListRow({required this.icon, required this.title, required this.subtitle, this.trailing, this.active = false, this.onTap});
  final IconData icon;
  final String title;
  final String subtitle;
  final String? trailing;
  final bool active;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minHeight: 38),
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
        decoration: BoxDecoration(
          color: active ? _AA.soft : _AA.card,
          border: const Border(bottom: BorderSide(color: _AA.line)),
        ),
        child: Row(children: [
          Container(width: 24, height: 24, alignment: Alignment.center, decoration: BoxDecoration(color: active ? _AA.green.withOpacity(.10) : const Color(0xFFF3F4F6), borderRadius: BorderRadius.circular(12)), child: Icon(icon, color: active ? _AA.green : _AA.muted, size: 15)),
          const SizedBox(width: 4),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 10, fontWeight: FontWeight.w800)),
            const SizedBox(height: 1),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.muted, fontSize: 8.8, fontWeight: FontWeight.w600)),
          ])),
          if (trailing != null) Text(trailing!, style: const TextStyle(color: _AA.green, fontSize: 9.4, fontWeight: FontWeight.w800)),
          const SizedBox(width: 4),
          const Icon(Icons.chevron_right_rounded, color: _AA.muted, size: 18),
        ]),
      ),
    );
  }
}

class _InfoLine extends StatelessWidget {
  const _InfoLine({required this.title, required this.value});
  final String title;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(children: [
        Expanded(child: Text(title, style: const TextStyle(color: _AA.muted, fontSize: 9.4, fontWeight: FontWeight.w700))),
        Flexible(child: Text(value, textAlign: TextAlign.right, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800))),
      ]),
    );
  }
}

class _ZoneLine extends StatelessWidget {
  const _ZoneLine({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) => _InfoLine(title: label, value: value);
}


class _SliderLine extends StatelessWidget {
  const _SliderLine({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.suffix,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final String suffix;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Expanded(child: Text(label, style: const TextStyle(color: _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800))),
          Text('${value.toStringAsFixed(suffix == '°' ? 0 : 1)} $suffix', style: const TextStyle(color: _AA.green, fontSize: 9.4, fontWeight: FontWeight.w800)),
        ]),
        Slider(value: value.clamp(min, max).toDouble(), min: min, max: max, divisions: divisions, label: value.toStringAsFixed(1), onChanged: onChanged),
      ]),
    );
  }
}

class _ChoiceLine extends StatelessWidget {
  const _ChoiceLine({required this.label, required this.value, required this.values, required this.onChanged});

  final String label;
  final String value;
  final Map<String, String> values;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(children: [
        Expanded(child: Text(label, style: const TextStyle(color: _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800))),
        DropdownButton<String>(
          value: values.containsKey(value) ? value : values.keys.first,
          underline: const SizedBox.shrink(),
          items: values.entries.map((e) => DropdownMenuItem<String>(value: e.key, child: Text(e.value))).toList(),
          onChanged: (v) { if (v != null) onChanged(v); },
        ),
      ]),
    );
  }
}

class _SmallButton extends StatelessWidget {
  const _SmallButton({required this.icon, required this.label, required this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(4),
      onTap: onTap,
      child: Container(
        height: 28,
        padding: const EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(color: primary ? _AA.green : _AA.card, borderRadius: BorderRadius.circular(4), border: Border.all(color: primary ? _AA.green : _AA.line)),
        child: Row(mainAxisSize: MainAxisSize.min, mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 15, color: primary ? Colors.white : _AA.green),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(color: primary ? Colors.white : _AA.text, fontSize: 9.4, fontWeight: FontWeight.w800)),
        ]),
      ),
    );
  }
}

class _Hint extends StatelessWidget {
  const _Hint({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(8),
      decoration: BoxDecoration(color: _AA.soft, borderRadius: BorderRadius.circular(4), border: Border.all(color: _AA.green.withOpacity(.18))),
      child: Text(text, style: const TextStyle(color: _AA.muted, fontSize: 9.4, height: 1.25, fontWeight: FontWeight.w600)),
    );
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: _AA.muted, size: 28),
      const SizedBox(height: 0),
      Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _AA.muted, fontSize: 10, fontWeight: FontWeight.w700)),
    ]));
  }
}

class _ErrorBox extends StatelessWidget {
  const _ErrorBox({required this.error, required this.onRetry});
  final String error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return _Panel(title: 'Ошибка аналитики', subtitle: 'сервер или данные', child: Column(children: [
      Expanded(child: _Empty(icon: Icons.error_outline_rounded, text: error)),
      _SmallButton(icon: Icons.refresh_rounded, label: 'Повторить', onTap: onRetry),
    ]));
  }
}


class _SprintSegment {
  const _SprintSegment(this.from, this.to, this.speedKmh);
  final ActionTrackerGpsPoint from;
  final ActionTrackerGpsPoint to;
  final double speedKmh;

  static List<_SprintSegment> fromPoints(List<ActionTrackerGpsPoint> points, {required double thresholdKmh}) {
    if (points.length < 2) return const <_SprintSegment>[];
    final out = <_SprintSegment>[];
    for (var i = 1; i < points.length; i++) {
      final a = points[i - 1];
      final b = points[i];
      if (_segmentBreaks(a, b)) continue;
      final speed = _segmentSpeed(points, i);
      if (!speed.isFinite || speed <= 0 || speed > 45) continue;
      if (speed >= thresholdKmh) out.add(_SprintSegment(a, b, speed));
    }
    return out;
  }
}


List<int> _turnPoints(List<ActionTrackerGpsPoint> points) {
  if (points.length < 3) return const <int>[];
  final out = <int>[];
  final bounds = _Bounds.fromGps(points);
  const size = Size(105, 68);
  for (var i = 2; i < points.length; i++) {
    if (_segmentBreaks(points[i - 2], points[i - 1]) || _segmentBreaks(points[i - 1], points[i])) continue;
    final prev = bounds.project(points[i - 2], size);
    final a = bounds.project(points[i - 1], size);
    final b = bounds.project(points[i], size);
    final v1 = a - prev;
    final v2 = b - a;
    if (v1.distance < .2 || v2.distance < .2) continue;
    final dot = ((v1.dx * v2.dx + v1.dy * v2.dy) / (v1.distance * v2.distance)).clamp(-1.0, 1.0);
    if (math.acos(dot) > .75) out.add(i - 1);
  }
  return out;
}

class _ActionPitchPainter extends CustomPainter {
  _ActionPitchPainter({
    required this.heat,
    required this.local,
    required this.field,
    this.sprintThresholdKmh = 18.0,
    this.hsrThresholdKmh = 14.0,
    this.activityFilter = 'all',
    this.showSprintArrows = true,
    this.mapRotationDeg = 0,
  });

  final List<TrackerHeatPoint> heat;
  final List<ActionTrackerGpsPoint> local;
  final TrackerFieldModel? field;
  final double sprintThresholdKmh;
  final double hsrThresholdKmh;
  final String activityFilter;
  final bool showSprintArrows;
  final double mapRotationDeg;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    if (mapRotationDeg.abs() > .1) {
      final center = Offset(size.width / 2, size.height / 2);
      canvas.translate(center.dx, center.dy);
      canvas.rotate(mapRotationDeg * math.pi / 180.0);
      canvas.translate(-center.dx, -center.dy);
    }

    _drawPitch(canvas, size);
    if (heat.isNotEmpty) {
      final inner = _pitchInnerRect(size);
      final maxHeat = heat.map((p) => p.value).fold<double>(1.0, math.max);
      canvas.save();
      canvas.clipRRect(RRect.fromRectAndRadius(inner, const Radius.circular(12)));
      for (final p in heat.take(1600)) {
        final nx = (p.x.abs() <= 1.2 ? p.x : p.x / 105.0).clamp(0.0, 1.0).toDouble();
        final ny = (p.y.abs() <= 1.2 ? p.y : p.y / 68.0).clamp(0.0, 1.0).toDouble();
        final ratio = (p.value / maxHeat).clamp(0.0, 1.0).toDouble();
        final center = Offset(inner.left + nx * inner.width, inner.top + ny * inner.height);
        final r = heat.length <= 2 ? 18.0 : (12.0 + ratio * 26.0);
        final color = Color.lerp(const Color(0xFF22C55E), const Color(0xFFDC2626), ratio) ?? _AA.green;
        final paint = Paint()
          ..shader = RadialGradient(colors: [color.withOpacity(.55), color.withOpacity(.24), color.withOpacity(0.0)], stops: const [0.0, .50, 1.0]).createShader(Rect.fromCircle(center: center, radius: r));
        canvas.drawCircle(center, r, paint);
      }
      canvas.restore();
    }

    if (local.length > 1) {
      final bounds = _Bounds.fromGps(local);
      final useFieldProjection = _shouldUseFieldProjection(local, field);
      for (var i = 1; i < local.length; i++) {
        final aPoint = local[i - 1];
        final bPoint = local[i];
        final a = _project(aPoint, size, bounds, useFieldProjection);
        final b = _project(bPoint, size, bounds, useFieldProjection);
        if (_segmentBreaks(aPoint, bPoint)) continue;
        final speed = _segmentSpeed(local, i);
        if (!speed.isFinite || speed <= 0) continue;
        if (!_segmentMatchesActivity(speed, activityFilter, hsrThresholdKmh: hsrThresholdKmh, sprintThresholdKmh: sprintThresholdKmh)) continue;
        final color = speed >= sprintThresholdKmh
            ? _AA.red
            : (speed >= hsrThresholdKmh ? _AA.orange : (speed >= 7 ? _AA.green : _AA.blue));
        final segmentPaint = Paint()
          ..color = color.withOpacity(.78)
          ..strokeWidth = speed >= sprintThresholdKmh ? 3.0 : (activityFilter == 'all' ? 2.0 : 2.6)
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(a, b, segmentPaint);
        if (showSprintArrows && (i % 6 == 0 || speed >= sprintThresholdKmh)) {
          _drawArrowHead(canvas, a, b, Paint()..color = color.withOpacity(.92)..style = PaintingStyle.fill);
        }
        if (i > 1) {
          final prev = _project(local[i - 2], size, bounds, useFieldProjection);
          final v1 = a - prev;
          final v2 = b - a;
          final l1 = v1.distance;
          final l2 = v2.distance;
          if (l1 > 5 && l2 > 5) {
            final dot = ((v1.dx * v2.dx + v1.dy * v2.dy) / (l1 * l2)).clamp(-1.0, 1.0);
            final angle = math.acos(dot);
            if (angle > .75) {
              canvas.drawCircle(a, 3.3, Paint()..color = _AA.orange.withOpacity(.95));
              canvas.drawCircle(a, 5.2, Paint()..color = _AA.orange.withOpacity(.18));
            }
          }
        }
      }

      // Отдельный слой GPS-точек: в фильтре точка получает скорость именно
      // выбранного отрезка. Иначе начало отрезка могло подсвечиваться цветом
      // предыдущего сегмента, и карта отчёта визуально расходилась с аналитикой.
      final visiblePointSpeeds = <int, double>{};
      if (activityFilter != 'all') {
        for (var i = 1; i < local.length; i++) {
          final aPoint = local[i - 1];
          final bPoint = local[i];
          if (_segmentBreaks(aPoint, bPoint)) continue;
          final speed = _segmentSpeed(local, i);
          if (_segmentMatchesActivity(speed, activityFilter, hsrThresholdKmh: hsrThresholdKmh, sprintThresholdKmh: sprintThresholdKmh)) {
            visiblePointSpeeds[i - 1] = speed;
            visiblePointSpeeds[i] = speed;
          }
        }
      }
      for (var i = 0; i < local.length; i++) {
        if (activityFilter != 'all' && !visiblePointSpeeds.containsKey(i)) continue;
        final current = local[i];
        final o = _project(current, size, bounds, useFieldProjection);
        double speed = visiblePointSpeeds[i] ?? 0.0;
        if (activityFilter == 'all' && i > 0 && !_segmentBreaks(local[i - 1], current)) {
          speed = _segmentSpeed(local, i);
        }
        final c = speed >= sprintThresholdKmh ? _AA.red : (speed >= hsrThresholdKmh ? _AA.orange : (speed >= 7 ? _AA.green : _AA.blue));
        final r = speed >= sprintThresholdKmh ? 4.8 : (speed >= 7 ? 3.8 : 3.0);
        canvas.drawCircle(o, r + 2.8, Paint()..color = c.withOpacity(.16));
        canvas.drawCircle(o, r, Paint()..color = c.withOpacity(.95));
        if (i == 0 || i == local.length - 1 || speed >= sprintThresholdKmh || i % 8 == 0) {
          _paintChartText(canvas, speed.toStringAsFixed(1), o + const Offset(6, -10), 8.0, c);
        }
      }

      double? prevSpeed;
      for (var i = 1; i < local.length; i++) {
        final aPoint = local[i - 1];
        final bPoint = local[i];
        if (_segmentBreaks(aPoint, bPoint)) { prevSpeed = null; continue; }
        final rawDtMs = (bPoint.timeMs - aPoint.timeMs).abs();
        final dtMs = rawDtMs <= 0 ? 1000 : rawDtMs;
        final speed = _segmentSpeed(local, i);
        if (speed <= 0) continue;
        if (prevSpeed != null) {
          final acc = ((speed - prevSpeed!) / 3.6) / (dtMs / 1000.0);
          if (acc.abs() >= 1.0) {
            final o = _project(bPoint, size, bounds, useFieldProjection);
            final c = acc > 0 ? _AA.green : _AA.red;
            canvas.drawCircle(o, 4.0, Paint()..color = c.withOpacity(.92));
            canvas.drawCircle(o, 7.0, Paint()..color = c.withOpacity(.16));
          }
        }
        prevSpeed = speed;
      }
    }    canvas.restore();
  }


  Offset _project(ActionTrackerGpsPoint p, Size size, _Bounds bounds, bool useFieldProjection) {
    if (useFieldProjection) {
      final projected = TrackerPitchProjector.projectGps(field, latitude: p.latitude, longitude: p.longitude);
      if (projected != null) {
        return _fitPointToPitch(Offset(projected.clampedNx * size.width, projected.clampedNy * size.height), size);
      }
    }
    return _fitPointToPitch(bounds.project(p, size), size);
  }

  void _drawArrowHead(Canvas canvas, Offset a, Offset b, Paint paint) {
    final dx = b.dx - a.dx;
    final dy = b.dy - a.dy;
    final len = math.sqrt(dx * dx + dy * dy);
    if (len < 7) return;
    final ux = dx / len;
    final uy = dy / len;
    final tip = b;
    final left = Offset(tip.dx - ux * 10 - uy * 5, tip.dy - uy * 10 + ux * 5);
    final right = Offset(tip.dx - ux * 10 + uy * 5, tip.dy - uy * 10 - ux * 5);
    final path = Path()..moveTo(tip.dx, tip.dy)..lineTo(left.dx, left.dy)..lineTo(right.dx, right.dy)..close();
    canvas.drawPath(path, paint);
  }

  void _drawPitch(Canvas canvas, Size size) {
    final border = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(16));
    canvas.drawRRect(border, Paint()..color = const Color(0xFF6E8A70));
    final clip = Path()..addRRect(border.deflate(8));
    canvas.save();
    canvas.clipPath(clip);
    final stripeW = math.max(36.0, size.width / 12);
    for (var i = 0; i < 14; i++) {
      final color = i.isEven ? const Color(0xFF678469) : const Color(0xFF789376);
      canvas.drawRect(Rect.fromLTWH(8 + i * stripeW, 8, stripeW, size.height - 16), Paint()..color = color);
    }
    canvas.restore();
    final line = Paint()..color = Colors.white.withOpacity(.78)..strokeWidth = 1.5..style = PaintingStyle.stroke;
    final inner = Rect.fromLTWH(10, 10, size.width - 20, size.height - 20);
    canvas.drawRRect(RRect.fromRectAndRadius(inner, const Radius.circular(12)), line);
    canvas.drawLine(Offset(size.width / 2, 10), Offset(size.width / 2, size.height - 10), line);
    canvas.drawCircle(Offset(size.width / 2, size.height / 2), math.min(size.width, size.height) * .12, line);
    canvas.drawRect(Rect.fromLTWH(10, size.height * .28, size.width * .17, size.height * .44), line);
    canvas.drawRect(Rect.fromLTWH(10, size.height * .38, size.width * .08, size.height * .24), line);
    canvas.drawRect(Rect.fromLTWH(size.width - 10 - size.width * .17, size.height * .28, size.width * .17, size.height * .44), line);
    canvas.drawRect(Rect.fromLTWH(size.width - 10 - size.width * .08, size.height * .38, size.width * .08, size.height * .24), line);
    canvas.drawCircle(Offset(size.width * .13, size.height / 2), 3, Paint()..color = Colors.white.withOpacity(.75));
    canvas.drawCircle(Offset(size.width * .87, size.height / 2), 3, Paint()..color = Colors.white.withOpacity(.75));
  }

  @override
  bool shouldRepaint(covariant _ActionPitchPainter oldDelegate) =>
      oldDelegate.heat != heat ||
      oldDelegate.local != local ||
      oldDelegate.field != field ||
      oldDelegate.sprintThresholdKmh != sprintThresholdKmh ||
      oldDelegate.hsrThresholdKmh != hsrThresholdKmh ||
      oldDelegate.activityFilter != activityFilter ||
      oldDelegate.showSprintArrows != showSprintArrows ||
      oldDelegate.mapRotationDeg != mapRotationDeg;
}

class _Bounds {
  const _Bounds(this.minLat, this.maxLat, this.minLng, this.maxLng);
  final double minLat;
  final double maxLat;
  final double minLng;
  final double maxLng;

  factory _Bounds.fromGps(List<ActionTrackerGpsPoint> points) {
    var minLat = points.first.latitude, maxLat = points.first.latitude, minLng = points.first.longitude, maxLng = points.first.longitude;
    for (final p in points) {
      minLat = math.min(minLat, p.latitude); maxLat = math.max(maxLat, p.latitude);
      minLng = math.min(minLng, p.longitude); maxLng = math.max(maxLng, p.longitude);
    }
    if ((maxLat - minLat).abs() < .00001) maxLat += .00001;
    if ((maxLng - minLng).abs() < .00001) maxLng += .00001;
    return _Bounds(minLat, maxLat, minLng, maxLng);
  }

  Offset project(ActionTrackerGpsPoint p, Size size) {
    final x = ((p.longitude - minLng) / (maxLng - minLng)).clamp(0.0, 1.0) * size.width;
    final y = (1 - ((p.latitude - minLat) / (maxLat - minLat)).clamp(0.0, 1.0)) * size.height;
    return Offset(x, y);
  }
}

class _SpeedPainter extends CustomPainter {
  _SpeedPainter({required this.samples, required this.hsrThresholdKmh, required this.sprintThresholdKmh, required this.maxSpeedKmh});
  final List<double> samples;
  final double hsrThresholdKmh;
  final double sprintThresholdKmh;
  final double maxSpeedKmh;

  @override
  void paint(Canvas canvas, Size size) {
    _chartBg(canvas, size);
    final double sampleMax = samples.isEmpty ? 0.0 : samples.reduce(math.max);
    final double maxV = math.max(34.0, math.max(maxSpeedKmh, sampleMax)).toDouble();
    _drawThreshold(canvas, size, maxV, hsrThresholdKmh, _AA.orange, 'HIR ${hsrThresholdKmh.toStringAsFixed(1)}');
    _drawThreshold(canvas, size, maxV, sprintThresholdKmh, _AA.red, 'SPR ${sprintThresholdKmh.toStringAsFixed(1)}');
    _paintAxis(canvas, size, maxV);
    if (samples.length < 2) {
      _paintChartText(canvas, 'Нет GPS-точек скорости', Offset(size.width / 2, size.height / 2), 10.5, _AA.muted);
      return;
    }
    final path = Path();
    final points = <Offset>[];
    for (var i = 0; i < samples.length; i++) {
      final x = i / (samples.length - 1) * size.width;
      final y = size.height - (samples[i] / maxV).clamp(0.0, 1.0) * size.height;
      points.add(Offset(x, y));
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    canvas.drawPath(path, Paint()..color = _AA.green..strokeWidth = 2.0..style = PaintingStyle.stroke..strokeCap = StrokeCap.round);
    final every = math.max(1, samples.length ~/ 8);
    for (var i = 0; i < points.length; i += every) {
      final v = samples[i];
      final c = v >= sprintThresholdKmh ? _AA.red : (v >= hsrThresholdKmh ? _AA.orange : _AA.green);
      canvas.drawCircle(points[i], 3.4, Paint()..color = c);
      canvas.drawCircle(points[i], 6.0, Paint()..color = c.withOpacity(.13));
      _paintChartText(canvas, v.toStringAsFixed(1), points[i] + const Offset(0, -13), 7.8, c);
    }
    _paintChartText(canvas, 'max ${maxSpeedKmh.toStringAsFixed(1)} км/ч', const Offset(8, 8), 9.4, _AA.text, alignLeft: true);
  }

  void _paintAxis(Canvas canvas, Size size, double maxV) {
    for (var i = 0; i <= 4; i++) {
      final value = maxV * (4 - i) / 4;
      final y = i / 4 * size.height;
      _paintChartText(canvas, value.toStringAsFixed(0), Offset(4, y + 2), 7.5, _AA.muted, alignLeft: true);
    }
  }

  void _drawThreshold(Canvas canvas, Size size, double maxV, double value, Color color, String label) {
    if (value <= 0 || maxV <= 0) return;
    final y = size.height - (value / maxV).clamp(0.0, 1.0) * size.height;
    final paint = Paint()..color = color.withOpacity(.55)..strokeWidth = 1..style = PaintingStyle.stroke;
    canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    _paintChartText(canvas, label, Offset(size.width - 6, math.max(8.0, y - 8).toDouble()), 8.4, color, alignLeft: false);
  }

  @override
  bool shouldRepaint(covariant _SpeedPainter oldDelegate) => oldDelegate.samples != samples || oldDelegate.hsrThresholdKmh != hsrThresholdKmh || oldDelegate.sprintThresholdKmh != sprintThresholdKmh || oldDelegate.maxSpeedKmh != maxSpeedKmh;
}

class _SprintPainter extends CustomPainter {
  _SprintPainter({required this.samples, required this.hsrThresholdKmh, required this.sprintThresholdKmh});
  final List<double> samples;
  final double hsrThresholdKmh;
  final double sprintThresholdKmh;

  @override
  void paint(Canvas canvas, Size size) {
    _chartBg(canvas, size);
    if (samples.isEmpty) {
      _paintChartText(canvas, 'Нет сохранённых точек скорости', Offset(size.width / 2, size.height / 2), 10.5, _AA.muted);
      return;
    }
    final double maxV = math.max(34.0, samples.reduce(math.max)).toDouble();
    final hsrY = size.height - (hsrThresholdKmh / maxV).clamp(0.0, 1.0) * size.height;
    final sprintY = size.height - (sprintThresholdKmh / maxV).clamp(0.0, 1.0) * size.height;
    canvas.drawLine(Offset(0, hsrY), Offset(size.width, hsrY), Paint()..color = _AA.orange.withOpacity(.45)..strokeWidth = 1);
    canvas.drawLine(Offset(0, sprintY), Offset(size.width, sprintY), Paint()..color = _AA.red.withOpacity(.50)..strokeWidth = 1);
    final double barW = math.max(2.0, size.width / samples.length).toDouble();
    var sprintBars = 0;
    var hsrBars = 0;
    for (var i = 0; i < samples.length; i++) {
      final v = samples[i];
      final h = (v / maxV).clamp(0.0, 1.0) * size.height;
      final color = v >= sprintThresholdKmh ? _AA.red : (v >= hsrThresholdKmh ? _AA.orange : _AA.green.withOpacity(.42));
      if (v >= sprintThresholdKmh) sprintBars++;
      if (v >= hsrThresholdKmh) hsrBars++;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(i * barW, size.height - h, barW * .72, h), const Radius.circular(2)), Paint()..color = color);
    }
    _paintChartText(canvas, 'HIR ${hsrThresholdKmh.toStringAsFixed(1)} · точек $hsrBars', Offset(6, math.max(9.0, hsrY - 9).toDouble()), 8.2, _AA.orange, alignLeft: true);
    _paintChartText(canvas, 'SPR ${sprintThresholdKmh.toStringAsFixed(1)} · точек $sprintBars', Offset(6, math.max(9.0, sprintY - 9).toDouble()), 8.2, _AA.red, alignLeft: true);
    _paintChartText(canvas, 'max ${samples.reduce(math.max).toStringAsFixed(1)} км/ч', Offset(size.width - 8, 8), 8.4, _AA.text);
  }

  @override
  bool shouldRepaint(covariant _SprintPainter oldDelegate) => oldDelegate.samples != samples || oldDelegate.hsrThresholdKmh != hsrThresholdKmh || oldDelegate.sprintThresholdKmh != sprintThresholdKmh;
}

class _ActivityRadarPainter extends CustomPainter {
  const _ActivityRadarPainter({required this.axes});
  final List<_ActivityAxisValue> axes;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) * .34;
    final grid = Paint()..color = _AA.line..style = PaintingStyle.stroke..strokeWidth = 1;
    for (var ring = 1; ring <= 4; ring++) {
      canvas.drawCircle(c, r * ring / 4, grid);
    }
    if (axes.isEmpty) return;
    final path = Path();
    for (var i = 0; i < axes.length; i++) {
      final a = -math.pi / 2 + i * math.pi * 2 / axes.length;
      final end = c + Offset(math.cos(a) * r, math.sin(a) * r);
      canvas.drawLine(c, end, grid);
      final labelPos = c + Offset(math.cos(a) * (r + 18), math.sin(a) * (r + 18));
      _paintChartText(canvas, axes[i].label, labelPos, 8.6, _AA.muted);
      final p = c + Offset(math.cos(a) * r * axes[i].value.clamp(0.0, 1.0), math.sin(a) * r * axes[i].value.clamp(0.0, 1.0));
      if (i == 0) path.moveTo(p.dx, p.dy); else path.lineTo(p.dx, p.dy);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = _AA.green.withOpacity(.18)..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = _AA.green..style = PaintingStyle.stroke..strokeWidth = 1.8);
  }

  @override
  bool shouldRepaint(covariant _ActivityRadarPainter oldDelegate) => oldDelegate.axes != axes;
}

class _MiniHeatmapPainter extends CustomPainter {
  const _MiniHeatmapPainter({required this.points});
  final List<TrackerHeatPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFEFFAF3);
    final rect = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(4));
    canvas.drawRRect(rect, bg);
    final line = Paint()..color = _AA.green.withOpacity(.40)..style = PaintingStyle.stroke..strokeWidth = 1;
    final inner = Rect.fromLTWH(8, 8, size.width - 16, size.height - 16);
    canvas.drawRect(inner, line);
    canvas.drawLine(Offset(size.width / 2, 8), Offset(size.width / 2, size.height - 8), line);
    if (points.isEmpty) {
      _paintChartText(canvas, 'Нет теплокарты сессии', Offset(size.width / 2, size.height / 2), 9.2, _AA.muted);
      return;
    }
    final maxValue = points.map((p) => p.value).fold<double>(1, math.max);
    final paint = Paint()..style = PaintingStyle.fill;
    for (final p in points.take(350)) {
      final x = inner.left + (p.x / 105.0).clamp(0.0, 1.0) * inner.width;
      final y = inner.top + (p.y / 68.0).clamp(0.0, 1.0) * inner.height;
      final ratio = (p.value / maxValue).clamp(0.0, 1.0).toDouble();
      paint.color = Color.lerp(_AA.green.withOpacity(.14), _AA.red.withOpacity(.48), ratio) ?? _AA.green.withOpacity(.2);
      canvas.drawCircle(Offset(x, y), 2.5 + ratio * 5, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _MiniHeatmapPainter oldDelegate) => oldDelegate.points != points;
}

class _RadarPainter extends CustomPainter {
  _RadarPainter({required this.rows, this.baselineRows = const <TrackerPlayerLoadRow>[]});
  final List<TrackerPlayerLoadRow> rows;
  final List<TrackerPlayerLoadRow> baselineRows;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = math.min(size.width, size.height) * .36;
    final grid = Paint()..color = _AA.line..style = PaintingStyle.stroke..strokeWidth = 1;
    for (var ring = 1; ring <= 4; ring++) {
      canvas.drawCircle(c, r * ring / 4, grid);
    }
    final axes = 5;
    final labels = ['объём', 'скорость', 'спринты', 'HIR', 'нагрузка'];
    for (var i = 0; i < axes; i++) {
      final a = -math.pi / 2 + i * math.pi * 2 / axes;
      final end = c + Offset(math.cos(a) * r, math.sin(a) * r);
      canvas.drawLine(c, end, grid);
      final tp = c + Offset(math.cos(a) * (r + 18), math.sin(a) * (r + 18));
      _paintText(canvas, labels[i], tp, 10);
    }
    if (rows.isEmpty && baselineRows.isEmpty) return;

    final baseline = baselineRows.isNotEmpty ? _radarValues(baselineRows) : const <double>[];
    final values = _radarValues(rows);
    if (baseline.isNotEmpty) {
      _drawRadarPath(canvas, c, r, baseline, fill: _AA.muted.withOpacity(.08), stroke: _AA.muted.withOpacity(.55), strokeWidth: 1.35);
    }
    if (values.isNotEmpty) {
      _drawRadarPath(canvas, c, r, values, fill: _AA.green.withOpacity(.18), stroke: _AA.green, strokeWidth: 2.1);
    }
  }

  List<double> _radarValues(List<TrackerPlayerLoadRow> src) {
    if (src.isEmpty) return const <double>[];
    double avg(double Function(TrackerPlayerLoadRow r) pick) => src.map(pick).fold<double>(0, (a, b) => a + b) / src.length;
    double clamp(double v) => v.isNaN || v.isInfinite ? 0 : v.clamp(0.0, 1.0).toDouble();

    // Не нормируем по максимуму текущего списка: при одном игроке это всегда полный одинаковый пятиугольник.
    return <double>[
      clamp(avg((r) => r.distanceM) / 6000.0),
      clamp(avg((r) => r.maxSpeedKmh) / 34.0),
      clamp(avg((r) => r.sprintCount.toDouble()) / 25.0),
      clamp(avg((r) => r.highSpeedDistanceM) / 1200.0),
      clamp(avg((r) => r.loadScore) / 1000.0),
    ];
  }

  void _drawRadarPath(Canvas canvas, Offset c, double r, List<double> values, {required Color fill, required Color stroke, required double strokeWidth}) {
    if (values.isEmpty) return;
    final path = Path();
    for (var i = 0; i < values.length; i++) {
      final a = -math.pi / 2 + i * math.pi * 2 / values.length;
      final level = values[i].clamp(0.0, 1.0).toDouble();
      final p = c + Offset(math.cos(a) * r * level, math.sin(a) * r * level);
      if (i == 0) {
        path.moveTo(p.dx, p.dy);
      } else {
        path.lineTo(p.dx, p.dy);
      }
    }
    path.close();
    canvas.drawPath(path, Paint()..color = fill..style = PaintingStyle.fill);
    canvas.drawPath(path, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = strokeWidth);
  }

  void _paintText(Canvas canvas, String text, Offset center, double size) {
    final tp = TextPainter(text: TextSpan(text: text, style: TextStyle(color: _AA.muted, fontSize: size, fontWeight: FontWeight.w800)), textDirection: TextDirection.ltr)..layout();
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _RadarPainter oldDelegate) => oldDelegate.rows != rows || oldDelegate.baselineRows != baselineRows;
}

class _CalibrationMiniPainter extends CustomPainter {
  _CalibrationMiniPainter({required this.field});
  final TrackerFieldModel? field;

  @override
  void paint(Canvas canvas, Size size) {
    final bg = Paint()..color = const Color(0xFFEFFAF3);
    final line = Paint()..color = _AA.green.withOpacity(.45)..style = PaintingStyle.stroke..strokeWidth = 1.2;
    final rect = RRect.fromRectAndRadius(Offset.zero & size, const Radius.circular(14));
    canvas.drawRRect(rect, bg);
    canvas.drawRRect(rect.deflate(10), line);
    final ready = field?.hasCalibration == true;
    final points = [
      Offset(16, 16),
      Offset(size.width - 16, 16),
      Offset(size.width - 16, size.height - 16),
      Offset(16, size.height - 16),
    ];
    final labels = ['A', 'B', 'C', 'D'];
    for (var i = 0; i < 4; i++) {
      canvas.drawCircle(points[i], 10, Paint()..color = ready ? _AA.green : _AA.orange);
      final tp = TextPainter(text: TextSpan(text: labels[i], style: const TextStyle(color: Colors.white, fontSize: 9.6, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, points[i] - Offset(tp.width / 2, tp.height / 2));
    }
  }

  @override
  bool shouldRepaint(covariant _CalibrationMiniPainter oldDelegate) => oldDelegate.field != field;
}

void _chartBg(Canvas canvas, Size size) {
  final line = Paint()..color = _AA.line..strokeWidth = 1;
  for (var i = 0; i <= 4; i++) {
    final y = i / 4 * size.height;
    canvas.drawLine(Offset(0, y), Offset(size.width, y), line);
  }
}

void _paintChartText(Canvas canvas, String text, Offset center, double size, Color color, {bool alignLeft = false}) {
  final tp = TextPainter(
    text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: FontWeight.w800)),
    textDirection: TextDirection.ltr,
    maxLines: 1,
  )..layout();
  final offset = alignLeft ? center : center - Offset(tp.width / 2, tp.height / 2);
  tp.paint(canvas, offset);
}


String _meters(double value) {
  if (value >= 1000) return '${(value / 1000).toStringAsFixed(2)} км';
  return '${value.toStringAsFixed(0)} м';
}

String _time(int sec) {
  if (sec <= 0) return '0:00';
  final m = sec ~/ 60;
  final s = sec % 60;
  return '$m:${s.toString().padLeft(2, '0')}';
}

double _num(dynamic value, double fallback) {
  if (value is num) return value.toDouble();
  return double.tryParse('$value') ?? fallback;
}

int _int(dynamic value, int fallback) {
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
