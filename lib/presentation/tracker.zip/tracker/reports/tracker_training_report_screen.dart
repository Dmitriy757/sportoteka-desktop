import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'tracker_export_viewer.dart';

import 'tracker_training_report_api.dart';
import 'tracker_training_report_models.dart';

class TrackerTrainingReportScreen extends StatefulWidget {
  const TrackerTrainingReportScreen({
    super.key,
    required this.sessionId,
    required this.teamId,
    required this.teamName,
    this.api,
    this.embedded = false,
  });

  final int sessionId;
  final int teamId;
  final String teamName;
  final TrackerTrainingReportApi? api;
  final bool embedded;

  @override
  State<TrackerTrainingReportScreen> createState() => _TrackerTrainingReportScreenState();
}

class _TrackerTrainingReportScreenState extends State<TrackerTrainingReportScreen> {
  late final TrackerTrainingReportApi _api;
  late Future<TrackerTrainingReport> _future;
  int _tab = 0;
  Uri? _exportPreviewUri;
  String _exportPreviewTitle = 'Экспорт';
  final Set<int> _selectedReportPlayerIds = <int>{};

  int _playerSelectionKey(TrackerTrainingPlayerRow player, int index) {
    final id = player.playerId;
    if (id != null && id > 0) return id;
    // fallback for rows that come from diagnostic/report API without player_id
    return -100000 - index;
  }

  List<TrackerTrainingPlayerRow> _filterPlayerRows(List<TrackerTrainingPlayerRow> rows) {
    if (_selectedReportPlayerIds.isEmpty) return rows;
    final result = <TrackerTrainingPlayerRow>[];
    for (var i = 0; i < rows.length; i++) {
      if (_selectedReportPlayerIds.contains(_playerSelectionKey(rows[i], i))) {
        result.add(rows[i]);
      }
    }
    return result;
  }

  @override
  void initState() {
    super.initState();
    _api = widget.api ?? TrackerTrainingReportApi();
    _future = _api.loadTrainingReport(sessionId: widget.sessionId, teamId: widget.teamId);
  }

  void _reload() {
    setState(() {
      _future = _api.loadTrainingReport(sessionId: widget.sessionId, teamId: widget.teamId);
    });
  }

  void _openExport(Uri uri, {required String title}) {
    setState(() {
      _exportPreviewUri = uri;
      _exportPreviewTitle = title;
    });
  }

  void _closeExportPreview() {
    setState(() => _exportPreviewUri = null);
  }


  TrackerTrainingReport _filteredReport(TrackerTrainingReport report) {
    if (_selectedReportPlayerIds.isEmpty) return report;

    final players = _filterPlayerRows(report.players);
    final diagnostic = _filterPlayerRows(report.diagnosticPlayers);

    // GPS / ЧСС можно точно отфильтровать только когда сервер прислал player_id.
    // Если строка игрока пришла без id, оставляем точки на карте, чтобы отчёт не становился пустым.
    final positiveIds = _selectedReportPlayerIds.where((id) => id > 0).toSet();
    bool keepPoint(TrackerReportPoint p) => positiveIds.isEmpty || (p.playerId != null && positiveIds.contains(p.playerId));
    bool keepHr(TrackerHeartRatePoint p) => positiveIds.isEmpty || (p.playerId != null && positiveIds.contains(p.playerId));
    final routePoints = report.routePoints.where(keepPoint).toList(growable: false);
    final heatmapPoints = report.heatmapPoints.where(keepPoint).toList(growable: false);

    return TrackerTrainingReport(
      sessionId: report.sessionId,
      sessionIds: report.sessionIds,
      title: report.title,
      dateLabel: report.dateLabel,
      teamId: report.teamId,
      teamName: report.teamName,
      teamLogoUrl: report.teamLogoUrl,
      opponent: report.opponent,
      durationLabel: report.durationLabel,
      playersCount: players.isNotEmpty ? players.length : diagnostic.length,
      pointsCount: routePoints.length,
      hasData: players.isNotEmpty || diagnostic.isNotEmpty,
      dataStatus: report.dataStatus,
      summary: report.summary,
      periods: report.periods,
      microcycle: report.microcycle,
      players: players,
      diagnosticPlayers: diagnostic,
      routePoints: routePoints,
      heatmapPoints: heatmapPoints,
      speedZones: report.speedZones,
      heartRateTimeline: report.heartRateTimeline.where(keepHr).toList(growable: false),
    );
  }

  Future<void> _openPlayerFilter(TrackerTrainingReport sourceReport) async {
    final basePlayers = sourceReport.players.isNotEmpty ? sourceReport.players : sourceReport.diagnosticPlayers;
    final players = basePlayers.toList(growable: false);
    if (players.isEmpty) {
      ScaffoldMessenger.maybeOf(context)?.showSnackBar(const SnackBar(content: Text('В этой сессии пока нет игроков для выбора.')));
      return;
    }
    final playerKeys = <int>[for (var i = 0; i < players.length; i++) _playerSelectionKey(players[i], i)];
    final temp = Set<int>.from(_selectedReportPlayerIds);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (context) {
        return StatefulBuilder(builder: (context, modalSetState) {
          return SafeArea(
            child: SizedBox(
              height: MediaQuery.sizeOf(context).height * .74,
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Container(
                  height: 52,
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _R.border))),
                  child: Row(children: [
                    const Icon(Icons.groups_rounded, color: _R.green, size: 20),
                    const SizedBox(width: 8),
                    Expanded(child: Text(temp.isEmpty ? 'Игроки в отчёте: все' : 'Игроки в отчёте: ${temp.length}', style: const TextStyle(color: _R.text, fontSize: 14, fontWeight: FontWeight.w900))),
                    TextButton(onPressed: () => modalSetState(() => temp.clear()), child: const Text('Все')),
                    IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  ]),
                ),
                Expanded(
                  child: ListView.separated(
                    itemCount: players.length,
                    separatorBuilder: (_, __) => const Divider(height: 1, color: _R.border),
                    itemBuilder: (context, i) {
                      final player = players[i];
                      final id = playerKeys[i];
                      final selected = temp.isEmpty || temp.contains(id);
                      return ListTile(
                        onTap: () => modalSetState(() {
                          if (temp.isEmpty) {
                            temp.addAll(playerKeys.where((v) => v != id));
                          } else if (temp.contains(id)) {
                            temp.remove(id);
                          } else {
                            temp.add(id);
                          }
                          if (temp.length == players.length) temp.clear();
                        }),
                        leading: _PlayerAvatar(player: player, size: 36),
                        title: Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 13, fontWeight: FontWeight.w900)),
                        subtitle: Text('GPS ${player.pointsCount} · ЧСС ${player.heartRateSamplesCount} · ${player.distanceM.toStringAsFixed(0)} м', style: const TextStyle(color: _R.muted, fontSize: 10, fontWeight: FontWeight.w700)),
                        trailing: Icon(selected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded, color: selected ? _R.green : _R.muted),
                      );
                    },
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(12),
                  child: SizedBox(
                    height: 44,
                    child: ElevatedButton.icon(
                      onPressed: () {
                        setState(() {
                          _selectedReportPlayerIds
                            ..clear()
                            ..addAll(temp);
                        });
                        Navigator.pop(context);
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: _R.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                      icon: const Icon(Icons.check_rounded),
                      label: const Text('Применить игроков к отчёту', style: TextStyle(fontWeight: FontWeight.w900)),
                    ),
                  ),
                ),
              ]),
            ),
          );
        });
      },
    );
  }

  Future<void> _openReportDetail(String title, Widget child, {double initialChildSize = .88}) async {
    final width = MediaQuery.sizeOf(context).width;
    if (width < 700) {
      await showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (context) => DraggableScrollableSheet(
          initialChildSize: initialChildSize.clamp(.54, .96).toDouble(),
          minChildSize: .46,
          maxChildSize: .96,
          builder: (context, controller) => _ReportAdaptiveSheet(
            title: title,
            controller: controller,
            child: child,
          ),
        ),
      );
      return;
    }

    await showDialog<void>(
      context: context,
      builder: (context) => Dialog(
        backgroundColor: Colors.transparent,
        insetPadding: const EdgeInsets.all(24),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1120, maxHeight: 820),
          child: _ReportAdaptiveSheet(title: title, child: child),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final content = ScrollConfiguration(
      behavior: ScrollConfiguration.of(context).copyWith(scrollbars: false),
      child: FutureBuilder<TrackerTrainingReport>(
        future: _future,
        builder: (context, snapshot) {
          final sourceReport = snapshot.data ?? TrackerTrainingReport.empty(sessionId: widget.sessionId, teamName: widget.teamName);
          final report = _filteredReport(sourceReport);
          return LayoutBuilder(builder: (context, constraints) {
            final mobile = constraints.maxWidth < 700;
            final mobileTab = _tab >= 0 && _tab <= 2 ? _tab : 0;
            final loading = snapshot.connectionState == ConnectionState.waiting;
            return Stack(
              children: [
                if (mobile)
                  _MobileReportShell(
                    report: report,
                    loading: loading,
                    selectedTab: mobileTab,
                    showBack: !widget.embedded,
                    onBack: () => Navigator.of(context).maybePop(),
                    onRefresh: _reload,
                    onPdf: () => _openExport(_api.pdfExportUri(sessionId: widget.sessionId, teamId: widget.teamId), title: 'PDF отчёт'),
                    onExcel: () => _openExport(_api.csvExportUri(sessionId: widget.sessionId, teamId: widget.teamId), title: 'Excel / CSV отчёт'),
                    onPlayers: () => _openPlayerFilter(sourceReport),
                    onSelectTab: (i) => setState(() => _tab = i),
                    onOpenDetail: (title, child) { _openReportDetail(title, child); },
                    selectedPlayersCount: _selectedReportPlayerIds.length,
                    error: snapshot.hasError ? '${snapshot.error}' : null,
                  )
                else
                  Column(
                    children: [
                      _Header(
                        report: report,
                        loading: loading,
                        showBack: !widget.embedded,
                        onBack: () => Navigator.of(context).maybePop(),
                        onRefresh: _reload,
                        onPdf: () => _openExport(_api.pdfExportUri(sessionId: widget.sessionId, teamId: widget.teamId), title: 'PDF отчёт'),
                        onExcel: () => _openExport(_api.csvExportUri(sessionId: widget.sessionId, teamId: widget.teamId), title: 'Excel / CSV отчёт'),
                        onPlayers: () => _openPlayerFilter(sourceReport),
                        selectedPlayersCount: _selectedReportPlayerIds.length,
                      ),
                      _Tabs(
                        selected: _tab,
                        onSelect: (i) => setState(() => _tab = i),
                      ),
                      if (snapshot.hasError)
                        Expanded(child: _ErrorView(error: '${snapshot.error}', onRetry: _reload))
                      else
                        Expanded(child: _buildTab(report)),
                    ],
                  ),
                if (_exportPreviewUri != null)
                  Positioned.fill(
                    child: _ExportPreviewWindow(
                      title: _exportPreviewTitle,
                      uri: _exportPreviewUri!,
                      onClose: _closeExportPreview,
                    ),
                  ),
              ],
            );
          });
        },
      ),
    );

    final scaled = MediaQuery(
      data: MediaQuery.of(context).copyWith(textScaler: const TextScaler.linear(.88)),
      child: content,
    );

    if (widget.embedded) {
      return ColoredBox(color: _R.bg, child: scaled);
    }

    return Scaffold(
      backgroundColor: _R.bg,
      body: SafeArea(child: scaled),
    );
  }

  Widget _buildTab(TrackerTrainingReport report) {
    switch (_tab) {
      case 0:
        return _SummaryTab(report: report);
      case 1:
        return _LocomotorTab(report: report);
      case 2:
        return _MechanicalTab(report: report);
      case 3:
        return _InternalLoadTab(report: report);
      case 4:
        return _MicrocycleTab(report: report);
      default:
        return _SummaryTab(report: report);
    }
  }
}


class _ExportPreviewWindow extends StatelessWidget {
  const _ExportPreviewWindow({required this.title, required this.uri, required this.onClose});

  final String title;
  final Uri uri;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, c) {
        final tablet = c.maxWidth < 1180;
        final margin = tablet ? 8.0 : 18.0;
        final width = tablet ? c.maxWidth - margin * 2 : math.min(1080.0, c.maxWidth - margin * 2);
        final height = tablet ? c.maxHeight - margin * 2 : math.min(760.0, c.maxHeight - margin * 2);

        return Container(
          color: Colors.white.withOpacity(.92),
          alignment: Alignment.center,
          padding: EdgeInsets.all(margin),
          child: SizedBox(
            width: width,
            height: height,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(tablet ? 14 : 18),
                border: Border.all(color: _R.border),
                boxShadow: const [BoxShadow(color: Color(0x16000000), blurRadius: 30, offset: Offset(0, 18))],
              ),
              clipBehavior: Clip.antiAlias,
              child: Column(
                children: [
                  Container(
                    height: tablet ? 42 : 46,
                    padding: const EdgeInsets.symmetric(horizontal: 10),
                    decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _R.border))),
                    child: Row(
                      children: [
                        _RoundIconButton(icon: Icons.close_rounded, onTap: onClose),
                        const SizedBox(width: 8),
                        Container(
                          width: tablet ? 28 : 32,
                          height: tablet ? 28 : 32,
                          decoration: BoxDecoration(color: _R.soft, borderRadius: BorderRadius.circular(10), border: Border.all(color: _R.border)),
                          child: const Icon(Icons.picture_as_pdf_rounded, color: _R.graphite, size: 16),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 12, fontWeight: FontWeight.w800)),
                              const Text('PDF показывается внутри окна, без вывода ссылки', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _R.muted, fontSize: 9.5, fontWeight: FontWeight.w600)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Expanded(child: TrackerExportViewer(uri: uri)),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({required this.icon, required this.onTap});

  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _R.soft,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          width: 34,
          height: 34,
          child: Icon(icon, size: 17, color: _R.graphite),
        ),
      ),
    );
  }
}


class _ReportAdaptiveSheet extends StatelessWidget {
  const _ReportAdaptiveSheet({required this.title, required this.child, this.controller});

  final String title;
  final Widget child;
  final ScrollController? controller;

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: const BoxDecoration(
          color: _R.bg,
          borderRadius: BorderRadius.vertical(top: Radius.circular(24), bottom: Radius.circular(18)),
        ),
        child: Column(
          children: [
            Container(
              width: 46,
              height: 4,
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              decoration: BoxDecoration(color: _R.border, borderRadius: BorderRadius.circular(99)),
            ),
            Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _R.border))),
              child: Row(children: [
                Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 14, fontWeight: FontWeight.w900))),
                const SizedBox(width: 8),
                _RoundIconButton(icon: Icons.close_rounded, onTap: () => Navigator.of(context).pop()),
              ]),
            ),
            Expanded(
              child: SingleChildScrollView(
                controller: controller,
                padding: const EdgeInsets.all(12),
                child: child,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MobileReportShell extends StatelessWidget {
  const _MobileReportShell({
    required this.report,
    required this.loading,
    required this.selectedTab,
    required this.onBack,
    required this.onRefresh,
    required this.onPdf,
    required this.onExcel,
    required this.onPlayers,
    required this.onSelectTab,
    required this.onOpenDetail,
    this.selectedPlayersCount = 0,
    this.showBack = true,
    this.error,
  });

  final TrackerTrainingReport report;
  final bool loading;
  final int selectedTab;
  final bool showBack;
  final VoidCallback onBack;
  final VoidCallback onRefresh;
  final VoidCallback onPdf;
  final VoidCallback onExcel;
  final VoidCallback onPlayers;
  final ValueChanged<int> onSelectTab;
  final void Function(String title, Widget child) onOpenDetail;
  final int selectedPlayersCount;
  final String? error;

  @override
  Widget build(BuildContext context) {
    late final Widget body;
    if (error != null) {
      body = _ErrorView(error: error!, onRetry: onRefresh);
    } else if (selectedTab == 1) {
      body = _MobileReportPlayers(report: report, onOpenDetail: onOpenDetail);
    } else if (selectedTab == 2) {
      body = _MobileReportCharts(report: report, onOpenDetail: onOpenDetail);
    } else {
      body = _MobileReportOverview(report: report, onOpenDetail: onOpenDetail);
    }
    return ListView(
      padding: EdgeInsets.zero,
      physics: const AlwaysScrollableScrollPhysics(),
      children: [
        _MobileReportHeader(
          report: report,
          loading: loading,
          showBack: showBack,
          onBack: onBack,
          onRefresh: onRefresh,
          onPdf: onPdf,
          onExcel: onExcel,
          onPlayers: onPlayers,
          selectedPlayersCount: selectedPlayersCount,
        ),
        _MobileReportTabs(selected: selectedTab, onSelect: onSelectTab),
        body,
        const SizedBox(height: 18),
      ],
    );
  }
}

class _MobileReportHeader extends StatelessWidget {
  const _MobileReportHeader({
    required this.report,
    required this.loading,
    required this.onBack,
    required this.onRefresh,
    required this.onPdf,
    required this.onExcel,
    required this.onPlayers,
    required this.selectedPlayersCount,
    required this.showBack,
  });

  final TrackerTrainingReport report;
  final bool loading;
  final bool showBack;
  final VoidCallback onBack;
  final VoidCallback onRefresh;
  final VoidCallback onPdf;
  final VoidCallback onExcel;
  final VoidCallback onPlayers;
  final int selectedPlayersCount;

  @override
  Widget build(BuildContext context) {
    final title = report.title.trim().isNotEmpty ? report.title.trim() : 'Сессия #${report.sessionId}';
    final subtitle = [
      if (report.teamName.trim().isNotEmpty) report.teamName.trim(),
      if (report.dateLabel.trim().isNotEmpty) report.dateLabel.trim(),
      if (report.durationLabel.trim().isNotEmpty) report.durationLabel.trim(),
      '${report.playersCount} игрок(ов)',
    ].join(' · ');
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _R.border))),
      child: Row(children: [
        if (showBack) ...[
          _RoundIconButton(icon: Icons.arrow_back_rounded, onTap: onBack),
          const SizedBox(width: 8),
        ],
        _TeamLogo(url: report.teamLogoUrl, title: report.teamName, size: 40),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 14, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 10, fontWeight: FontWeight.w800)),
          ]),
        ),
        if (loading) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: _R.green, strokeWidth: 2)),
        const SizedBox(width: 4),
        _MobilePlayerFilterButton(count: selectedPlayersCount, onTap: onPlayers),
        PopupMenuButton<String>(
          tooltip: 'Действия отчёта',
          icon: const Icon(Icons.more_horiz_rounded, color: _R.graphite),
          onSelected: (value) {
            switch (value) {
              case 'refresh':
                onRefresh();
                break;
              case 'players':
                onPlayers();
                break;
              case 'pdf':
                onPdf();
                break;
              case 'excel':
                onExcel();
                break;
            }
          },
          itemBuilder: (context) => [
            const PopupMenuItem(value: 'refresh', child: Text('Обновить')),
            PopupMenuItem(value: 'players', child: Text(selectedPlayersCount > 0 ? 'Игроки: $selectedPlayersCount' : 'Игроки: все')),
            const PopupMenuItem(value: 'pdf', child: Text('PDF / печать')),
            const PopupMenuItem(value: 'excel', child: Text('Excel / CSV')),
          ],
        ),
      ]),
    );
  }
}

class _MobilePlayerFilterButton extends StatelessWidget {
  const _MobilePlayerFilterButton({required this.count, required this.onTap});

  final int count;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final active = count > 0;
    return Tooltip(
      message: active ? 'Игроки отчёта: $count' : 'Выбрать игроков отчёта',
      child: Material(
        color: active ? _R.softGreen : _R.soft,
        borderRadius: BorderRadius.circular(13),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(13),
          child: Container(
            width: 36,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: active ? _R.greenLine : _R.border),
            ),
            child: Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(Icons.groups_rounded, color: active ? _R.green : _R.graphite, size: 17),
                if (active)
                  Positioned(
                    right: -7,
                    top: -7,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                      decoration: BoxDecoration(color: _R.green, borderRadius: BorderRadius.circular(99), border: Border.all(color: Colors.white, width: 1.2)),
                      child: Text('$count', style: const TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w900)),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _MobileReportTabs extends StatelessWidget {
  const _MobileReportTabs({required this.selected, required this.onSelect});
  final int selected;
  final ValueChanged<int> onSelect;

  static const icons = [Icons.dashboard_rounded, Icons.groups_rounded, Icons.insert_chart_rounded];
  static const labels = ['Обзор', 'Игроки', 'Графики'];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
      color: Colors.white,
      child: Row(children: [
        for (var i = 0; i < labels.length; i++) ...[
          Expanded(child: _MobileTabButton(icon: icons[i], label: labels[i], active: selected == i, onTap: () => onSelect(i))),
          if (i != labels.length - 1) const SizedBox(width: 7),
        ],
      ]),
    );
  }
}

class _MobileTabButton extends StatelessWidget {
  const _MobileTabButton({required this.icon, required this.label, required this.active, required this.onTap});
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? _R.softGreen : _R.soft,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: Border.all(color: active ? _R.greenLine : _R.border)),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 15, color: active ? _R.green : _R.graphite),
            const SizedBox(width: 5),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? _R.greenDark : _R.graphite, fontSize: 10.5, fontWeight: FontWeight.w900))),
          ]),
        ),
      ),
    );
  }
}

class _MobileReportOverview extends StatelessWidget {
  const _MobileReportOverview({required this.report, required this.onOpenDetail});
  final TrackerTrainingReport report;
  final void Function(String title, Widget child) onOpenDetail;

  @override
  Widget build(BuildContext context) {
    final hasData = _hasMeaningfulTrainingData(report);
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _MobileHeroCard(report: report),
        const SizedBox(height: 10),
        if (!hasData) ...[
          _NoMovementNotice(report: report),
          const SizedBox(height: 10),
        ],
        _MobileCoachCard(report: report),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Карта активности',
          subtitle: '${report.pointsCount} GPS-точек · тепловая карта · спринты',
          icon: Icons.map_rounded,
          previewHeight: 190,
          preview: _MobileMapPreview(report: report),
          onOpen: () => onOpenDetail('Карта активности / тепловая карта', _ActivityMapPanel(report: report)),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Скорость и зоны',
          subtitle: 'линия скорости, HIR и спринты',
          icon: Icons.speed_rounded,
          previewHeight: 168,
          preview: _MobileSpeedPreview(report: report),
          onOpen: () => onOpenDetail('График скорости и зоны', SizedBox(height: 560, child: _ReportSpeedGraphPanel(report: report))),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Внутренняя нагрузка',
          subtitle: 'ЧСС, зоны и нагрузка игрока',
          icon: Icons.favorite_rounded,
          previewHeight: 190,
          preview: _HrPlayerSummaryChart(players: _reportPlayers(report)),
          onOpen: () => onOpenDetail('Пульс и внутренняя нагрузка', _MobileInternalLoadDetails(report: report)),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Лидеры по объёму',
          subtitle: 'быстрое сравнение игроков',
          icon: Icons.leaderboard_rounded,
          previewHeight: 190,
          preview: _MobileTopPlayersBars(report: report),
          onOpen: () => onOpenDetail('Игроки и локомоторика', _MobilePlayersDetails(report: report)),
        ),
      ]),
    );
  }
}

class _MobileReportPlayers extends StatelessWidget {
  const _MobileReportPlayers({required this.report, required this.onOpenDetail});
  final TrackerTrainingReport report;
  final void Function(String title, Widget child) onOpenDetail;

  @override
  Widget build(BuildContext context) {
    final players = _reportPlayers(report);
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _MobileSectionHeader(
          title: 'Игроки в отчёте',
          subtitle: players.isEmpty ? 'нет игроков' : '${players.length} игрок(ов) · карточки без широкой таблицы',
          actionLabel: 'Таблица',
          onAction: () => onOpenDetail('Полная таблица игроков', _MobilePlayersDetails(report: report)),
        ),
        const SizedBox(height: 8),
        if (players.isEmpty)
          const _EmptyBlock('В отчёте пока нет игроков.')
        else
          for (var i = 0; i < players.length; i++) ...[
            _PlayerReportCompactCard(player: players[i]),
            if (i != players.length - 1) const SizedBox(height: 8),
          ],
      ]),
    );
  }
}

class _MobileReportCharts extends StatelessWidget {
  const _MobileReportCharts({required this.report, required this.onOpenDetail});
  final TrackerTrainingReport report;
  final void Function(String title, Widget child) onOpenDetail;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 8, 10, 18),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        _MobileSectionHeader(title: 'Графики тренировки', subtitle: 'нажмите карточку, чтобы открыть большое окно'),
        const SizedBox(height: 8),
        _MobilePreviewCard(
          title: 'Средний / максимальный пульс',
          subtitle: 'зелёная точка — средний bpm, красная — максимум',
          icon: Icons.favorite_rounded,
          previewHeight: 210,
          preview: _HrPlayerSummaryChart(players: _reportPlayers(report)),
          onOpen: () => onOpenDetail('Средний / максимальный пульс', SizedBox(height: 430, child: _HrPlayerSummaryChart(players: _reportPlayers(report)))),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Пульс по времени',
          subtitle: 'красная линия и зоны ЧСС',
          icon: Icons.monitor_heart_rounded,
          previewHeight: 210,
          preview: _HeartRateTimelineChart(report: report),
          onOpen: () => onOpenDetail('Пульс по времени / красная нагрузка', SizedBox(height: 460, child: _HeartRateTimelineChart(report: report))),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Ускорения / торможения',
          subtitle: 'механика игрока',
          icon: Icons.compare_arrows_rounded,
          previewHeight: 220,
          preview: _DualBarChart(players: _reportPlayers(report), first: (p) => p.accelerations.toDouble(), second: (p) => p.decelerations.toDouble(), firstLabel: 'Ускорения', secondLabel: 'Торможения'),
          onOpen: () => onOpenDetail('Механика: ускорения и торможения', SizedBox(height: 430, child: _DualBarChart(players: _reportPlayers(report), first: (p) => p.accelerations.toDouble(), second: (p) => p.decelerations.toDouble(), firstLabel: 'Ускорения', secondLabel: 'Торможения'))),
        ),
        const SizedBox(height: 10),
        _MobilePreviewCard(
          title: 'Микроцикл',
          subtitle: 'динамика дистанции и интенсивности',
          icon: Icons.calendar_month_rounded,
          previewHeight: 230,
          preview: _MicrocycleChart(points: report.microcycle),
          onOpen: () => onOpenDetail('Динамика микроцикла', SizedBox(height: 460, child: _MicrocycleChart(points: report.microcycle))),
        ),
      ]),
    );
  }
}

class _MobileHeroCard extends StatelessWidget {
  const _MobileHeroCard({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final metrics = _mobileCoreMetrics(report);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: _R.border), boxShadow: const [BoxShadow(color: Color(0x07000000), blurRadius: 18, offset: Offset(0, 8))]),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _TeamLogo(url: report.teamLogoUrl, title: report.teamName, size: 46),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Сессия #${report.sessionId}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 16, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text([report.teamName, report.dateLabel, report.durationLabel].where((v) => v.trim().isNotEmpty).join(' · '), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 10.5, height: 1.2, fontWeight: FontWeight.w800)),
          ])),
          _ReportStatusPill(report: report),
        ]),
        const SizedBox(height: 12),
        _MobileKpiGrid(metrics: metrics),
      ]),
    );
  }
}

class _MobileKpiGrid extends StatelessWidget {
  const _MobileKpiGrid({required this.metrics});
  final List<_Metric> metrics;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: metrics.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 66,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
      ),
      itemBuilder: (context, i) => _MetricTile(metric: metrics[i]),
    );
  }
}

class _MobileCoachCard extends StatelessWidget {
  const _MobileCoachCard({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final messages = _reportCoachMessages(report).take(2).toList(growable: false);
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: _R.greenLine)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Icon(Icons.tips_and_updates_rounded, color: _R.green, size: 18),
          SizedBox(width: 8),
          Text('Итог тренера', style: TextStyle(color: _R.text, fontSize: 13.5, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 8),
        for (final message in messages) ...[
          Text(message, style: const TextStyle(color: _R.graphite, fontSize: 11.2, height: 1.32, fontWeight: FontWeight.w700)),
          if (message != messages.last) const SizedBox(height: 6),
        ],
      ]),
    );
  }
}

class _MobilePreviewCard extends StatelessWidget {
  const _MobilePreviewCard({required this.title, required this.subtitle, required this.icon, required this.preview, required this.previewHeight, required this.onOpen});
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget preview;
  final double previewHeight;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        onTap: onOpen,
        borderRadius: BorderRadius.circular(20),
        child: Container(
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: _R.border), boxShadow: const [BoxShadow(color: Color(0x05000000), blurRadius: 14, offset: Offset(0, 7))]),
          clipBehavior: Clip.antiAlias,
          child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 8, 8),
              child: Row(children: [
                Container(width: 34, height: 34, decoration: BoxDecoration(color: _R.softGreen, borderRadius: BorderRadius.circular(12), border: Border.all(color: _R.greenLine)), child: Icon(icon, color: _R.green, size: 18)),
                const SizedBox(width: 10),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 13, fontWeight: FontWeight.w900)),
                  const SizedBox(height: 2),
                  Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 9.8, fontWeight: FontWeight.w800)),
                ])),
                const SizedBox(width: 6),
                Container(width: 34, height: 34, decoration: BoxDecoration(color: _R.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: _R.border)), child: const Icon(Icons.open_in_full_rounded, color: _R.graphite, size: 16)),
              ]),
            ),
            Container(height: 1, color: _R.border),
            SizedBox(height: previewHeight, child: Padding(padding: const EdgeInsets.all(8), child: preview)),
          ]),
        ),
      ),
    );
  }
}


class _MobileMapPreview extends StatelessWidget {
  const _MobileMapPreview({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final points = report.heatmapPoints.isNotEmpty ? report.heatmapPoints : report.routePoints;
    return Center(
      child: AspectRatio(
        aspectRatio: 1.72,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: CustomPaint(
            painter: _ReportPitchPainter(points: points, heatMode: report.heatmapPoints.isNotEmpty, hsrKmh: _reportHsrThreshold(report), sprintKmh: _reportSprintThreshold(report)),
            child: points.isEmpty
                ? const Center(child: Text('Нет GPS-точек', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w900)))
                : const SizedBox.expand(),
          ),
        ),
      ),
    );
  }
}

class _MobileSpeedPreview extends StatelessWidget {
  const _MobileSpeedPreview({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final samples = report.routePoints.map((p) => p.speedKmh).where((v) => v.isFinite && v >= 0).toList();
    final maxSpeed = samples.isEmpty ? report.summary.maxSpeedKmh : samples.fold<double>(report.summary.maxSpeedKmh, math.max);
    if (samples.isEmpty && maxSpeed <= 0) return const _EmptyBlock('Скорость появится после GPS-точек.');
    return CustomPaint(
      painter: _ReportSpeedPainter(samples: samples, maxSpeedKmh: maxSpeed, hsrKmh: _reportHsrThreshold(report), sprintKmh: _reportSprintThreshold(report)),
      child: const SizedBox.expand(),
    );
  }
}

class _MobileTopPlayersBars extends StatelessWidget {
  const _MobileTopPlayersBars({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final players = _reportPlayers(report).where((p) => p.distanceM > 0 || p.playerLoad > 0 || p.heartRateSamplesCount > 0).take(8).toList(growable: false);
    if (players.isEmpty) return const _EmptyBlock('Нет данных игроков для сравнения.');
    return CustomPaint(
      painter: _BarChartPainter(players: players, value: (p) => math.max(p.distanceM, p.playerLoad), label: 'объём'),
      child: const SizedBox.expand(),
    );
  }
}

class _MobileSectionHeader extends StatelessWidget {
  const _MobileSectionHeader({required this.title, required this.subtitle, this.actionLabel, this.onAction});
  final String title;
  final String subtitle;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: _R.text, fontSize: 15, fontWeight: FontWeight.w900)),
        const SizedBox(height: 2),
        Text(subtitle, style: const TextStyle(color: _R.muted, fontSize: 10.4, fontWeight: FontWeight.w800)),
      ])),
      if (actionLabel != null && onAction != null)
        TextButton(onPressed: onAction, child: Text(actionLabel!, style: const TextStyle(color: _R.greenDark, fontWeight: FontWeight.w900))),
    ]);
  }
}

class _MobileInternalLoadDetails extends StatelessWidget {
  const _MobileInternalLoadDetails({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _Card(title: 'РЕКОМЕНДАЦИИ ПО ЧСС', child: _HrRecommendations(report: report)),
      const SizedBox(height: 10),
      _Card(title: 'ПУЛЬС ПО ВРЕМЕНИ', child: SizedBox(height: 420, child: _HeartRateTimelineChart(report: report))),
      const SizedBox(height: 10),
      _Card(title: 'ЗОНЫ ЧСС', child: SizedBox(height: 126, child: _HrZoneTimeStrip(report: report))),
      const SizedBox(height: 10),
      _Card(title: 'СРЕДНИЙ / МАКСИМАЛЬНЫЙ ПУЛЬС', child: SizedBox(height: 360, child: _HrPlayerSummaryChart(players: _reportPlayers(report)))),
    ]);
  }
}

class _MobilePlayersDetails extends StatelessWidget {
  const _MobilePlayersDetails({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final players = _reportPlayers(report);
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      _Card(title: 'ИГРОКИ И ТРЕКЕРЫ', child: _PlayersOverview(report: report)),
      const SizedBox(height: 10),
      _Card(title: 'ЛОКОМОТОРИКА ПО ИГРОКАМ', child: _LocomotorCards(players: players)),
    ]);
  }
}

List<_Metric> _mobileCoreMetrics(TrackerTrainingReport report) {
  final s = report.summary;
  return [
    _Metric('Время', report.durationLabel.trim().isEmpty ? '—' : report.durationLabel, 'длительность'),
    _Metric('Дистанция', '${s.averageDistanceM.toStringAsFixed(0)} м', 'средняя'),
    _Metric('Макс. скорость', s.maxSpeedKmh > 0 ? s.maxSpeedKmh.toStringAsFixed(1) : '—', 'км/ч'),
    _Metric('Игроки', '${report.playersCount}', 'в отчёте'),
    _Metric('GPS-точки', '${report.pointsCount}', 'записей'),
    _Metric('Пульс', s.heartRateAvgBpm > 0 ? s.heartRateAvgBpm.toStringAsFixed(0) : '—', 'средний bpm'),
  ];
}

class _Header extends StatelessWidget {
  const _Header({
    required this.report,
    required this.loading,
    required this.onBack,
    required this.onRefresh,
    required this.onPdf,
    required this.onExcel,
    required this.onPlayers,
    this.selectedPlayersCount = 0,
    this.showBack = true,
  });

  final TrackerTrainingReport report;
  final bool loading;
  final bool showBack;
  final VoidCallback onBack;
  final VoidCallback onRefresh;
  final VoidCallback onPdf;
  final VoidCallback onExcel;
  final VoidCallback onPlayers;
  final int selectedPlayersCount;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final compact = c.maxWidth < 760;
      final hideLabels = c.maxWidth < 520;
      final subtitle = [
        report.teamName.trim().isEmpty ? 'команда не указана' : report.teamName,
        report.dateLabel.trim().isEmpty ? 'дата не указана' : report.dateLabel,
        report.durationLabel,
        '${report.playersCount} игрок(ов)',
        '${report.pointsCount} GPS-точек',
      ].where((e) => e.trim().isNotEmpty).join(' · ');
      return Container(
        constraints: BoxConstraints(minHeight: compact ? 64 : 72),
        padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 12, vertical: compact ? 7 : 9),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(bottom: BorderSide(color: _R.border)),
        ),
        child: Row(
          children: [
            if (showBack) ...[
              _RoundIconButton(icon: Icons.arrow_back_rounded, onTap: onBack),
              const SizedBox(width: 8),
            ],
            _TeamLogo(url: report.teamLogoUrl, title: report.teamName, size: compact ? 42 : 48),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Спортотека. Отчёт',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: _R.text, fontSize: compact ? 15 : 18, fontWeight: FontWeight.w900, letterSpacing: .1),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    subtitle,
                    maxLines: compact ? 2 : 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _R.muted, fontSize: 10.5, fontWeight: FontWeight.w800),
                  ),
                ],
              ),
            ),
            if (loading)
              const Padding(
                padding: EdgeInsets.only(right: 12),
                child: SizedBox(width: 18, height: 18, child: CircularProgressIndicator(color: _R.green, strokeWidth: 2)),
              ),
            if (!compact) _HeaderButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: onRefresh),
            if (!compact) const SizedBox(width: 8),
            _HeaderButton(icon: Icons.groups_rounded, label: hideLabels ? 'Игроки' : (selectedPlayersCount > 0 ? 'Игроки: $selectedPlayersCount' : 'Игроки: все'), onTap: onPlayers),
            const SizedBox(width: 8),
            _HeaderButton(icon: Icons.picture_as_pdf_rounded, label: hideLabels ? 'PDF' : 'PDF / печать', onTap: onPdf),
            const SizedBox(width: 8),
            _HeaderButton(icon: Icons.table_chart_rounded, label: hideLabels ? 'XLS' : 'Excel', onTap: onExcel),
          ],
        ),
      );
    });
  }
}

class _TeamLogo extends StatelessWidget {
  const _TeamLogo({required this.url, required this.title, this.size = 46});
  final String url;
  final String title;
  final double size;

  @override
  Widget build(BuildContext context) {
    final letter = title.trim().isNotEmpty ? title.trim().substring(0, 1).toUpperCase() : 'S';
    final child = url.trim().isEmpty
        ? Text(letter, style: TextStyle(color: _R.greenDark, fontWeight: FontWeight.w900, fontSize: size * .42))
        : ClipRRect(
            borderRadius: BorderRadius.circular(size * .26),
            child: Image.network(
              url,
              width: size,
              height: size,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Center(child: Text(letter, style: TextStyle(color: _R.greenDark, fontWeight: FontWeight.w900, fontSize: size * .42))),
            ),
          );
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(color: _R.softGreen, borderRadius: BorderRadius.circular(size * .28), border: Border.all(color: _R.greenLine)),
      clipBehavior: Clip.antiAlias,
      child: child,
    );
  }
}

class _HeaderButton extends StatelessWidget {
  const _HeaderButton({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _R.soft,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 32,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(border: Border.all(color: _R.border), borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, color: _R.graphite, size: 15),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(color: _R.graphite, fontWeight: FontWeight.w800, fontSize: 10.5)),
          ]),
        ),
      ),
    );
  }
}

class _Tabs extends StatelessWidget {
  const _Tabs({required this.selected, required this.onSelect});
  final int selected;
  final ValueChanged<int> onSelect;

  static const items = ['Сводка', 'Локомоторика', 'Механика', 'Внутренняя', 'Микроцикл'];

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 42,
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, i) {
          final active = i == selected;
          return InkWell(
            onTap: () => onSelect(i),
            borderRadius: BorderRadius.circular(9),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active ? _R.softGreen : _R.soft,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: active ? _R.greenLine : _R.border),
              ),
              child: Text(items[i], style: TextStyle(color: active ? _R.greenDark : _R.graphite, fontWeight: FontWeight.w800, fontSize: 10.5)),
            ),
          );
        },
      ),
    );
  }
}

class _SummaryTab extends StatelessWidget {
  const _SummaryTab({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return _ScrollPage(
      children: [
        _ReportBrandStrip(report: report),
        const SizedBox(height: 10),
        _SectionTitle('ПОЛНЫЙ ОТЧЁТ ПО ТРЕНИРОВКЕ'),
        LayoutBuilder(builder: (context, c) {
          final desktop = c.maxWidth >= 1180;
          final tablet = c.maxWidth >= 720 && c.maxWidth < 1180;
          final twoColumns = desktop;
          final gap = tablet || desktop ? 12.0 : 9.0;
          final hasData = _hasMeaningfulTrainingData(report);
          final mapCard = _Card(title: 'КАРТА АКТИВНОСТИ / ТЕПЛОВАЯ КАРТА', child: _ActivityMapPanel(report: report, expandedTablet: tablet));
          final left = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _Card(title: 'ОБЩАЯ ИНФОРМАЦИЯ', child: _SummaryGrid(report: report)),
            SizedBox(height: gap),
            if (!hasData) ...[
              _NoMovementNotice(report: report),
              SizedBox(height: gap),
            ],
            _Card(title: 'ИГРОКИ И ТРЕКЕРЫ', child: _PlayersOverview(report: report)),
            SizedBox(height: gap),
            _Card(title: 'ПОЛНАЯ ТАБЛИЦА ЛОКОМОТОРИКИ', child: desktop ? _LocomotorTable(players: _reportPlayers(report)) : _LocomotorCards(players: _reportPlayers(report))),
            SizedBox(height: gap),
            _Card(title: 'ПЕРИОДЫ / УПРАЖНЕНИЯ', child: _PeriodsTable(periods: report.periods)),
          ]);
          final right = Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            _Card(title: 'ГРАФИК СКОРОСТИ', child: SizedBox(height: desktop ? 370 : 320, child: _ReportSpeedGraphPanel(report: report))),
            SizedBox(height: gap),
            if (!tablet) ...[
              mapCard,
              SizedBox(height: gap),
            ],
            _Card(title: 'РЕЙТИНГ И СРАВНЕНИЕ ИГРОКА', child: SizedBox(height: desktop ? 360 : 330, child: _RadarComparisonPanel(report: report))),
            SizedBox(height: gap),
            _Card(title: 'МЕХАНИКА: УСКОРЕНИЯ И ТОРМОЖЕНИЯ', child: SizedBox(height: desktop ? 280 : 240, child: _DualBarChart(players: _reportPlayers(report), first: (p) => p.accelerations.toDouble(), second: (p) => p.decelerations.toDouble(), firstLabel: 'Ускорения', secondLabel: 'Торможения'))),
            SizedBox(height: gap),
            _Card(title: 'ДИНАМИКА МИКРОЦИКЛА', child: SizedBox(height: desktop ? 260 : 230, child: _MicrocycleChart(points: report.microcycle))),
            SizedBox(height: gap),
            _Card(title: '% ОТ СРЕДНИХ ЗНАЧЕНИЙ МАТЧА', child: SizedBox(height: desktop ? 250 : 300, child: _PercentBarChart(values: _mdComparison(report)))),
          ]);
          if (tablet) {
            return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              mapCard,
              SizedBox(height: gap),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: left),
                SizedBox(width: gap),
                Expanded(child: right),
              ]),
            ]);
          }
          if (!twoColumns) {
            return Column(children: [left, SizedBox(height: gap), right]);
          }
          return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(flex: desktop ? 6 : 1, child: left),
            SizedBox(width: gap),
            Expanded(flex: desktop ? 7 : 1, child: right),
          ]);
        }),
      ],
    );
  }
}

List<TrackerTrainingPlayerRow> _reportPlayers(TrackerTrainingReport report) {
  return report.players.isNotEmpty ? report.players : report.diagnosticPlayers;
}

class _ReportBrandStrip extends StatelessWidget {
  const _ReportBrandStrip({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _R.border),
        boxShadow: const [BoxShadow(color: Color(0x08000000), blurRadius: 18, offset: Offset(0, 8))],
      ),
      child: Row(children: [
        _TeamLogo(url: report.teamLogoUrl, title: report.teamName, size: 52),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Спортотека. Отчёт', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _R.text, fontSize: 20, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Text(
              '${report.teamName.isEmpty ? 'Команда' : report.teamName} · ${report.dateLabel.isEmpty ? 'дата не указана' : report.dateLabel}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _R.muted, fontSize: 11, fontWeight: FontWeight.w800),
            ),
          ]),
        ),
        const SizedBox(width: 8),
        _ReportStatusPill(report: report),
      ]),
    );
  }
}

class _ReportStatusPill extends StatelessWidget {
  const _ReportStatusPill({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final ok = _hasMeaningfulTrainingData(report);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: ok ? _R.softGreen : const Color(0xFFFFFAEB),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: ok ? _R.greenLine : const Color(0xFFFEDC7A)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(ok ? Icons.check_circle_rounded : Icons.info_outline_rounded, size: 15, color: ok ? _R.greenDark : const Color(0xFFB7791F)),
        const SizedBox(width: 6),
        Text(ok ? 'данные готовы' : 'нет движения', style: TextStyle(color: ok ? _R.greenDark : const Color(0xFF92400E), fontSize: 10, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _PlayersOverview extends StatelessWidget {
  const _PlayersOverview({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final players = _reportPlayers(report);
    if (players.isEmpty) return const _EmptyBlock('В отчёте пока нет игроков. Проверьте выбранную сессию и привязку датчиков.');
    return LayoutBuilder(builder: (context, c) {
      if (c.maxWidth < 460) {
        return Column(children: [
          for (var i = 0; i < players.length; i++) ...[
            _PlayerReportCompactCard(player: players[i]),
            if (i != players.length - 1) const SizedBox(height: 8),
          ],
        ]);
      }
      final columns = c.maxWidth >= 720 ? 3 : 2;
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: players.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          mainAxisExtent: 116,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (_, i) => _PlayerReportCard(player: players[i]),
      );
    });
  }
}

class _PlayerReportCard extends StatelessWidget {
  const _PlayerReportCard({required this.player});
  final TrackerTrainingPlayerRow player;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(color: const Color(0xFFF8FAF8), borderRadius: BorderRadius.circular(11), border: Border.all(color: _R.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          _PlayerAvatar(player: player, size: 38),
          const SizedBox(width: 8),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 11.5, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text([if (player.number.isNotEmpty) '#${player.number}', if (player.position.isNotEmpty) player.position, if (player.deviceName.isNotEmpty) player.deviceName].join(' · '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 9.2, fontWeight: FontWeight.w800)),
          ])),
        ]),
        const SizedBox(height: 8),
        Expanded(
          child: Row(children: [
            Expanded(child: _MiniMetric(label: 'Дист.', value: '${player.distanceM.toStringAsFixed(0)} м')),
            const SizedBox(width: 6),
            Expanded(child: _MiniMetric(label: 'Макс.', value: '${player.maxSpeedKmh.toStringAsFixed(1)}')),
            const SizedBox(width: 6),
            Expanded(child: _MiniMetric(label: 'GPS', value: '${player.pointsCount}')),
          ]),
        ),
      ]),
    );
  }
}

class _PlayerReportCompactCard extends StatelessWidget {
  const _PlayerReportCompactCard({required this.player});
  final TrackerTrainingPlayerRow player;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: _R.border)),
      child: Row(children: [
        _PlayerAvatar(player: player, size: 36),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 12, fontWeight: FontWeight.w900)),
            const SizedBox(height: 3),
            Wrap(spacing: 5, runSpacing: 5, children: [
              _TinyPill(label: 'Дист.', value: '${player.distanceM.toStringAsFixed(0)} м'),
              _TinyPill(label: 'Макс.', value: player.maxSpeedKmh.toStringAsFixed(1)),
              _TinyPill(label: 'GPS', value: '${player.pointsCount}'),
            ]),
          ]),
        ),
      ]),
    );
  }
}

class _TinyPill extends StatelessWidget {
  const _TinyPill({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(color: _R.soft, borderRadius: BorderRadius.circular(999), border: Border.all(color: _R.border)),
      child: Text('$label $value', style: const TextStyle(color: _R.graphite, fontSize: 9.2, fontWeight: FontWeight.w900)),
    );
  }
}

class _PlayerAvatar extends StatelessWidget {
  const _PlayerAvatar({required this.player, this.size = 34});
  final TrackerTrainingPlayerRow player;
  final double size;

  @override
  Widget build(BuildContext context) {
    final letter = player.name.trim().isNotEmpty ? player.name.trim().substring(0, 1).toUpperCase() : '?';
    final fallback = Center(child: Text(letter, style: TextStyle(color: _R.greenDark, fontSize: size * .38, fontWeight: FontWeight.w900)));
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(color: _R.softGreen, borderRadius: BorderRadius.circular(size / 2), border: Border.all(color: _R.greenLine)),
      child: player.avatarUrl.trim().isEmpty
          ? fallback
          : Image.network(player.avatarUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => fallback),
    );
  }
}


class _ActivityMapPanel extends StatefulWidget {
  const _ActivityMapPanel({required this.report, this.expandedTablet = false});
  final TrackerTrainingReport report;
  final bool expandedTablet;

  @override
  State<_ActivityMapPanel> createState() => _ActivityMapPanelState();
}

class _ActivityMapPanelState extends State<_ActivityMapPanel> {
  bool _heatMode = false;
  String _filter = 'all';

  @override
  Widget build(BuildContext context) {
    final report = widget.report;
    final rawRoute = report.routePoints;
    final hsrKmh = _reportHsrThreshold(report);
    final sprintKmh = _reportSprintThreshold(report);
    final route = _filteredReportPoints(rawRoute, _filter, hsrKmh: hsrKmh, sprintKmh: sprintKmh);
    final heat = report.heatmapPoints.isNotEmpty ? report.heatmapPoints : rawRoute;
    final hasPoints = rawRoute.isNotEmpty || heat.isNotEmpty;
    final sprintCount = rawRoute.where((p) => p.speedKmh >= sprintKmh).length;
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      LayoutBuilder(builder: (context, c) {
        final compact = c.maxWidth < 430;
        final stats = '${rawRoute.length} GPS · ${heat.length} heat · $sprintCount спринтов';
        if (compact) {
          return Container(
            padding: const EdgeInsets.fromLTRB(6, 6, 6, 7),
            decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _R.border))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              Row(children: [
                Expanded(child: _MapModeButton(label: 'Карта', icon: Icons.timeline_rounded, active: !_heatMode, onTap: () => setState(() => _heatMode = false))),
                const SizedBox(width: 6),
                Expanded(child: _MapModeButton(label: 'Тепловая', icon: Icons.local_fire_department_rounded, active: _heatMode, onTap: () => setState(() => _heatMode = true))),
              ]),
              const SizedBox(height: 5),
              Text(stats, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: _R.muted, fontSize: 9.5, fontWeight: FontWeight.w800)),
            ]),
          );
        }
        return Container(
          height: 36,
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _R.border))),
          child: Row(children: [
            _MapModeButton(label: 'Карта активности', icon: Icons.timeline_rounded, active: !_heatMode, onTap: () => setState(() => _heatMode = false)),
            _MapModeButton(label: 'Тепловая карта', icon: Icons.local_fire_department_rounded, active: _heatMode, onTap: () => setState(() => _heatMode = true)),
            const Spacer(),
            Text(stats, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 9.7, fontWeight: FontWeight.w800)),
          ]),
        );
      }),
      if (!_heatMode)
        Container(
          height: 38,
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _R.border))),
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5), children: [
            _ActivityFilterChip(label: 'Все', value: 'all', current: _filter, onTap: _setFilter),
            _ActivityFilterChip(label: 'Ходьба', value: 'walk', current: _filter, onTap: _setFilter),
            _ActivityFilterChip(label: 'Бег', value: 'run', current: _filter, onTap: _setFilter),
            _ActivityFilterChip(label: 'Высокая', value: 'hir', current: _filter, onTap: _setFilter),
            _ActivityFilterChip(label: 'Спринт', value: 'sprint', current: _filter, onTap: _setFilter),
            _ActivityFilterChip(label: 'Повороты', value: 'turn', current: _filter, onTap: _setFilter),
          ]),
        ),
      const SizedBox(height: 8),
      LayoutBuilder(builder: (context, c) {
        final mapHeight = widget.expandedTablet
            ? math.min(520.0, math.max(360.0, c.maxWidth / 1.72))
            : null;
        final map = ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: hasPoints
              ? CustomPaint(
                  painter: _ReportPitchPainter(points: _heatMode ? heat : route, heatMode: _heatMode, hsrKmh: hsrKmh, sprintKmh: sprintKmh),
                  child: const SizedBox.expand(),
                )
              : CustomPaint(
                  painter: _ReportPitchPainter(points: const []),
                  child: const Center(child: Text('Нет GPS-точек для карты выбранной сессии', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.w800))),
                ),
        );
        if (mapHeight != null) {
          return SizedBox(width: double.infinity, height: mapHeight, child: map);
        }
        return AspectRatio(aspectRatio: 1.72, child: map);
      }),
    ]);
  }

  void _setFilter(String value) => setState(() => _filter = value);
}

class _MapModeButton extends StatelessWidget {
  const _MapModeButton({required this.label, required this.icon, required this.active, required this.onTap});
  final String label;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(0),
      child: Container(
        height: 36,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(color: active ? _R.softGreen : Colors.white, border: Border(right: BorderSide(color: _R.border))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 15, color: active ? _R.green : _R.muted),
          const SizedBox(width: 7),
          ConstrainedBox(constraints: const BoxConstraints(maxWidth: 150), child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? _R.green : _R.text, fontWeight: FontWeight.w900, fontSize: 11))),
        ]),
      ),
    );
  }
}

class _ActivityFilterChip extends StatelessWidget {
  const _ActivityFilterChip({required this.label, required this.value, required this.current, required this.onTap});
  final String label;
  final String value;
  final String current;
  final ValueChanged<String> onTap;

  @override
  Widget build(BuildContext context) {
    final active = value == current;
    return Padding(
      padding: const EdgeInsets.only(right: 6),
      child: InkWell(
        onTap: () => onTap(value),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.center,
          decoration: BoxDecoration(color: active ? _R.green : Colors.white, borderRadius: BorderRadius.circular(8), border: Border.all(color: active ? _R.green : _R.border)),
          child: Text(label, style: TextStyle(color: active ? Colors.white : _R.text, fontSize: 10.3, fontWeight: FontWeight.w900)),
        ),
      ),
    );
  }
}

double _reportSprintThreshold(TrackerTrainingReport report) {
  for (final z in report.speedZones) {
    if (z.label.toLowerCase().contains('спринт')) return z.fromKmh;
  }
  return report.teamName.toUpperCase().contains('U13') ? 18.0 : 18.0;
}

double _reportHsrThreshold(TrackerTrainingReport report) {
  for (final z in report.speedZones) {
    if (z.label.toLowerCase().contains('высок')) return z.fromKmh;
  }
  return report.teamName.toUpperCase().contains('U13') ? 14.0 : 14.0;
}

List<TrackerReportPoint> _filteredReportPoints(List<TrackerReportPoint> points, String filter, {required double hsrKmh, required double sprintKmh}) {
  if (filter == 'all' || points.length < 2) return points;
  final out = <TrackerReportPoint>[];
  TrackerReportPoint clonePoint(TrackerReportPoint p, {required bool breakBefore, double? displaySpeed}) => TrackerReportPoint(
    playerId: p.playerId,
    playerName: p.playerName,
    x: p.x,
    y: p.y,
    speedKmh: displaySpeed ?? p.speedKmh,
    value: p.value,
    distanceM: p.distanceM,
    timeMs: p.timeMs,
    breakBefore: breakBefore,
  );
  for (var i = 1; i < points.length; i++) {
    final p = points[i];
    final prev = points[i - 1];
    if (p.breakBefore) continue;
    final dt = (p.timeMs - prev.timeMs).abs();
    if (dt > 60000) continue;
    var keep = false;
    if (filter == 'walk') keep = p.speedKmh > 0 && p.speedKmh < 7;
    if (filter == 'run') keep = p.speedKmh >= 7 && p.speedKmh < hsrKmh;
    if (filter == 'hir') keep = p.speedKmh >= hsrKmh && p.speedKmh < sprintKmh;
    if (filter == 'sprint') keep = p.speedKmh >= sprintKmh;
    if (filter == 'turn' && i < points.length - 1) {
      final a = points[i - 1], b = points[i], c = points[i + 1];
      final v1 = Offset(b.x - a.x, b.y - a.y);
      final v2 = Offset(c.x - b.x, c.y - b.y);
      if (v1.distance >= .01 && v2.distance >= .01) {
        final dot = ((v1.dx * v2.dx + v1.dy * v2.dy) / (v1.distance * v2.distance)).clamp(-1.0, 1.0);
        keep = math.acos(dot) > .7;
      }
    }
    if (keep) {
      // Добавляем пару prev->current, чтобы фильтр не соединял далекие точки
      // одной неправильной диагональю. Обе точки получают скорость выбранного
      // сегмента — тогда цвет/подпись фильтра совпадают с линией аналитики.
      out.add(clonePoint(points[i - 1], breakBefore: true, displaySpeed: p.speedKmh));
      out.add(clonePoint(p, breakBefore: false, displaySpeed: p.speedKmh));
    }
  }
  return out;
}

class _SpeedZonesPanel extends StatelessWidget {
  const _SpeedZonesPanel({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final zones = report.speedZones;
    if (zones.isEmpty) return const _EmptyBlock('Скоростные зоны появятся после получения точек со speed_kmh.');
    final totalDistance = zones.fold<double>(0, (m, z) => m + math.max(0.0, z.distanceM));
    final totalPoints = zones.fold<int>(0, (m, z) => m + math.max(0, z.pointsCount));
    return Column(children: [
      for (final z in zones) ...[
        Builder(builder: (context) {
          final useDistance = totalDistance > 0;
          final raw = useDistance ? math.max(0.0, z.distanceM) : math.max(0, z.pointsCount).toDouble();
          final total = useDistance ? totalDistance : math.max(1, totalPoints).toDouble();
          final percent = total > 0 ? (raw * 100 / total).round() : 0;
          final label = useDistance ? '${z.distanceM.toStringAsFixed(0)} м · $percent%' : '${z.pointsCount} точ. · $percent%';
          return Row(children: [
            SizedBox(width: 126, child: Text(z.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 10.5, fontWeight: FontWeight.w900))),
            Expanded(child: ClipRRect(borderRadius: BorderRadius.circular(999), child: LinearProgressIndicator(value: (raw / total).clamp(0, 1).toDouble(), minHeight: 9, backgroundColor: _R.soft, valueColor: AlwaysStoppedAnimation<Color>(_zoneColor(z.fromKmh))))),
            const SizedBox(width: 8),
            SizedBox(width: 92, child: Text(label, textAlign: TextAlign.right, style: const TextStyle(color: _R.graphite, fontSize: 10, fontWeight: FontWeight.w900))),
          ]);
        }),
        const SizedBox(height: 8),
      ],
    ]);
  }
}



Color _zoneColor(double fromKmh) {
  if (fromKmh >= 18.0) return _R.red;
  if (fromKmh >= 14.0) return const Color(0xFFF59E0B);
  if (fromKmh >= 14) return const Color(0xFFFACC15);
  if (fromKmh >= 7) return _R.green;
  return const Color(0xFF6CCB91);
}

class _ReportPitchPainter extends CustomPainter {
  _ReportPitchPainter({required this.points, this.heatMode = false, this.speedMode = false, this.hsrKmh = 14.0, this.sprintKmh = 18.0});
  final List<TrackerReportPoint> points;
  final bool heatMode;
  final bool speedMode;
  final double hsrKmh;
  final double sprintKmh;

  @override
  void paint(Canvas canvas, Size size) {
    final outer = Offset.zero & size;
    canvas.drawRRect(RRect.fromRectAndRadius(outer, const Radius.circular(14)), Paint()..color = const Color(0xFF6E8C6F));
    final pitch = Rect.fromLTWH(12, 12, size.width - 24, size.height - 24);
    final clip = RRect.fromRectAndRadius(pitch, const Radius.circular(13));
    canvas.save();
    canvas.clipRRect(clip);
    canvas.drawRect(pitch, Paint()..color = const Color(0xFF78936F));
    final stripeW = pitch.width / 11;
    for (var i = 0; i < 11; i++) {
      canvas.drawRect(Rect.fromLTWH(pitch.left + i * stripeW, pitch.top, stripeW, pitch.height), Paint()..color = (i.isEven ? Colors.white : Colors.black).withOpacity(i.isEven ? .08 : .04));
    }
    canvas.restore();
    _drawPitchLines(canvas, pitch, clip);
    if (points.isEmpty) return;

    if (heatMode) {
      final maxValue = points.fold<double>(1, (m, p) => math.max(m, p.value <= 0 ? 1 : p.value));
      canvas.save();
      canvas.clipRRect(clip);
      for (final p in points.take(1500)) {
        final o = _point(pitch, p);
        final ratio = ((p.value <= 0 ? 1 : p.value) / maxValue).clamp(.05, 1).toDouble();
        final c = ratio > .66 ? const Color(0xFFE11D48) : ratio > .34 ? const Color(0xFFF59E0B) : const Color(0xFF22C55E);
        final r = 18 + 34 * ratio;
        canvas.drawCircle(o, r, Paint()..shader = RadialGradient(colors: [c.withOpacity(.46), c.withOpacity(.22), Colors.transparent], stops: const [0, .52, 1]).createShader(Rect.fromCircle(center: o, radius: r)));
      }
      canvas.restore();
      return;
    }

    final local = points.take(1400).toList();
    if (local.length > 1) {
      for (var i = 1; i < local.length; i++) {
        final a = _point(pitch, local[i - 1]);
        final b = _point(pitch, local[i]);
        final p = local[i];
        if (p.breakBefore) continue;
        final dt = (p.timeMs - local[i - 1].timeMs).abs();
        if (dt > 60000) continue;
        final speed = p.speedKmh;
        final color = _reportSpeedColor(speed, hsrKmh: hsrKmh, sprintKmh: sprintKmh);
        canvas.drawLine(a, b, Paint()
          ..color = color.withOpacity(speed >= hsrKmh ? .92 : .78)
          ..strokeWidth = speed >= sprintKmh ? 3.2 : 2.35
          ..strokeCap = StrokeCap.round);
        if (i % 7 == 0 || speed >= hsrKmh) _drawArrow(canvas, a, b, Paint()..color = color.withOpacity(.9));
      }
    }
    for (var i = 0; i < local.length; i++) {
      final p = local[i];
      final o = _point(pitch, p);
      final color = _reportSpeedColor(p.speedKmh, hsrKmh: hsrKmh, sprintKmh: sprintKmh);
      final r = p.speedKmh >= sprintKmh ? 4.8 : (p.speedKmh >= 7 ? 4.1 : 3.3);
      canvas.drawCircle(o, r + 4, Paint()..color = color.withOpacity(.18));
      canvas.drawCircle(o, r, Paint()..color = color.withOpacity(.96));
      if (i == 0 || i == local.length - 1 || p.speedKmh >= hsrKmh || i % 12 == 0) {
        _paintSmallText(canvas, p.speedKmh.toStringAsFixed(1), o + const Offset(6, -13), color);
      }
    }
  }

  Offset _point(Rect pitch, TrackerReportPoint p) => Offset(pitch.left + p.x.clamp(0, 1).toDouble() * pitch.width, pitch.top + p.y.clamp(0, 1).toDouble() * pitch.height);

  void _drawPitchLines(Canvas canvas, Rect pitch, RRect clip) {
    final line = Paint()..color = Colors.white.withOpacity(.82)..style = PaintingStyle.stroke..strokeWidth = 2.0;
    final thin = Paint()..color = Colors.white.withOpacity(.75)..style = PaintingStyle.stroke..strokeWidth = 1.6;
    canvas.drawRRect(clip, line);
    canvas.drawLine(Offset(pitch.center.dx, pitch.top), Offset(pitch.center.dx, pitch.bottom), line);
    canvas.drawCircle(pitch.center, math.min(pitch.width, pitch.height) * .125, thin);
    canvas.drawCircle(pitch.center, 3.3, Paint()..color = Colors.white.withOpacity(.88));
    final penaltyW = pitch.width * .18;
    final penaltyH = pitch.height * .52;
    final goalW = pitch.width * .085;
    final goalH = pitch.height * .28;
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), line);
    canvas.drawRect(Rect.fromLTWH(pitch.right - penaltyW, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), line);
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - goalW, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawCircle(Offset(pitch.left + penaltyW * .68, pitch.center.dy), 3.2, Paint()..color = Colors.white.withOpacity(.9));
    canvas.drawCircle(Offset(pitch.right - penaltyW * .68, pitch.center.dy), 3.2, Paint()..color = Colors.white.withOpacity(.9));
  }

  void _drawArrow(Canvas canvas, Offset a, Offset b, Paint paint) {
    final d = b - a;
    if (d.distance < 4) return;
    final u = d / d.distance;
    final p = Offset(-u.dy, u.dx);
    final tip = b;
    final path = Path()
      ..moveTo(tip.dx, tip.dy)
      ..lineTo((tip - u * 10 + p * 5).dx, (tip - u * 10 + p * 5).dy)
      ..lineTo((tip - u * 10 - p * 5).dx, (tip - u * 10 - p * 5).dy)
      ..close();
    canvas.drawPath(path, paint);
  }

  void _paintSmallText(Canvas canvas, String text, Offset offset, Color color) {
    final tp = TextPainter(text: TextSpan(text: text, style: TextStyle(color: color, fontSize: 8.5, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout(maxWidth: 42);
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _ReportPitchPainter oldDelegate) => true;
}

Color _reportSpeedColor(double speed, {double hsrKmh = 14.0, double sprintKmh = 18.0}) {
  if (speed >= sprintKmh) return _R.red;
  if (speed >= hsrKmh) return const Color(0xFFF59E0B);
  if (speed >= 7) return _R.green;
  return const Color(0xFF2563EB);
}

class _ReportSpeedGraphPanel extends StatelessWidget {
  const _ReportSpeedGraphPanel({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final samples = report.routePoints.map((p) => p.speedKmh).where((v) => v.isFinite && v >= 0).toList();
    final maxSpeed = samples.isEmpty ? report.summary.maxSpeedKmh : samples.fold<double>(report.summary.maxSpeedKmh, math.max);
    if (samples.isEmpty && maxSpeed <= 0) return const _EmptyBlock('График скорости появится после загрузки GPS-точек со speed_kmh.');
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      SizedBox(
        height: 52,
        child: Row(children: [
          Expanded(child: _MiniMetric(label: 'Средняя', value: '${report.summary.avgSpeedKmh.toStringAsFixed(1)} км/ч')),
          const SizedBox(width: 6),
          Expanded(child: _MiniMetric(label: 'Макс.', value: '${maxSpeed.toStringAsFixed(1)} км/ч')),
          const SizedBox(width: 6),
          Expanded(child: _MiniMetric(label: 'GPS', value: '${report.routePoints.length}')),
          const SizedBox(width: 6),
          Expanded(child: _MiniMetric(label: 'Спринты', value: '${report.summary.sprintCount}')),
        ]),
      ),
      const SizedBox(height: 6),
      Expanded(child: CustomPaint(painter: _ReportSpeedPainter(samples: samples, maxSpeedKmh: maxSpeed, hsrKmh: _reportHsrThreshold(report), sprintKmh: _reportSprintThreshold(report)), child: const SizedBox.expand())),
      Container(height: 1, color: _R.border),
      SizedBox(height: 146, child: SingleChildScrollView(primary: false, child: _SpeedZonesPanel(report: report))),
    ]);
  }
}

class _ReportSpeedPainter extends CustomPainter {
  const _ReportSpeedPainter({required this.samples, required this.maxSpeedKmh, this.hsrKmh = 14.0, this.sprintKmh = 18.0});
  final List<double> samples;
  final double maxSpeedKmh;
  final double hsrKmh;
  final double sprintKmh;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(36, 10, size.width - 46, size.height - 30);
    final grid = Paint()..color = _R.border..strokeWidth = 1;
    final maxY = math.max(34.0, math.max(maxSpeedKmh, samples.fold<double>(0, math.max)) + 3);
    for (var i = 0; i <= 4; i++) {
      final y = rect.bottom - rect.height * i / 4;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
      _chartText(canvas, (maxY * i / 4).round().toString(), Offset(4, y - 8), _R.muted, 9, FontWeight.w800);
    }
    void threshold(double value, Color color, String label) {
      if (value <= 0 || value > maxY) return;
      final y = rect.bottom - rect.height * value / maxY;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), Paint()..color = color.withOpacity(.72)..strokeWidth = 1.4);
      _chartText(canvas, label, Offset(rect.right - 58, y - 16), color, 10, FontWeight.w900);
    }
    threshold(hsrKmh, const Color(0xFFF59E0B), 'HIR ${hsrKmh.toStringAsFixed(1)}');
    threshold(sprintKmh, _R.red, 'SPR ${sprintKmh.toStringAsFixed(1)}');
    if (samples.isEmpty) return;
    final path = Path();
    for (var i = 0; i < samples.length; i++) {
      final x = rect.left + rect.width * (samples.length == 1 ? 0 : i / (samples.length - 1));
      final y = rect.bottom - rect.height * samples[i].clamp(0, maxY).toDouble() / maxY;
      if (i == 0) path.moveTo(x, y); else path.lineTo(x, y);
    }
    canvas.drawPath(path, Paint()..color = _R.green..strokeWidth = 2.6..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round);
    final step = math.max(1, (samples.length / 8).ceil());
    for (var i = 0; i < samples.length; i += step) {
      final x = rect.left + rect.width * (samples.length == 1 ? 0 : i / (samples.length - 1));
      final y = rect.bottom - rect.height * samples[i].clamp(0, maxY).toDouble() / maxY;
      final c = _reportSpeedColor(samples[i], hsrKmh: hsrKmh, sprintKmh: sprintKmh);
      canvas.drawCircle(Offset(x, y), 7, Paint()..color = c.withOpacity(.15));
      canvas.drawCircle(Offset(x, y), 4, Paint()..color = c);
      _chartText(canvas, samples[i].toStringAsFixed(1), Offset(x - 10, y - 24), c, 9, FontWeight.w900);
    }
  }

  void _chartText(Canvas canvas, String text, Offset offset, Color color, double size, FontWeight weight) {
    final tp = TextPainter(text: TextSpan(text: text, style: TextStyle(color: color, fontSize: size, fontWeight: weight)), textDirection: TextDirection.ltr)..layout(maxWidth: 80);
    tp.paint(canvas, offset);
  }

  @override
  bool shouldRepaint(covariant _ReportSpeedPainter oldDelegate) => true;
}

class _RadarComparisonPanel extends StatelessWidget {
  const _RadarComparisonPanel({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final players = _reportPlayers(report);
    return LayoutBuilder(builder: (context, c) {
      final two = c.maxWidth >= 560;
      final left = _RadarMiniCard(
        title: 'Рейтинг команды',
        subtitle: '${report.teamName.isEmpty ? 'Команда' : report.teamName} · ${players.length} игроков',
        child: _ReportRadarPainter(players: players),
      );
      final right = _RadarMiniCard(
        title: 'Сравнение игрока',
        subtitle: players.isEmpty ? 'игрок против среднего команды' : '${players.first.name} против среднего команды',
        child: _ReportRadarPainter(players: players.isEmpty ? players : [players.first], baselinePlayers: players),
      );
      if (!two) return Column(children: [Expanded(child: left), const SizedBox(height: 8), Expanded(child: right)]);
      return Row(children: [Expanded(child: left), const SizedBox(width: 8), Expanded(child: right)]);
    });
  }
}

class _RadarMiniCard extends StatelessWidget {
  const _RadarMiniCard({required this.title, required this.subtitle, required this.child});
  final String title;
  final String subtitle;
  final CustomPainter child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, border: Border.all(color: _R.border), borderRadius: BorderRadius.circular(10)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 4),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 11.5, fontWeight: FontWeight.w900)),
            Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 9.6, fontWeight: FontWeight.w800)),
          ]),
        ),
        Expanded(child: CustomPaint(painter: child, child: const SizedBox.expand())),
      ]),
    );
  }
}

class _ReportRadarPainter extends CustomPainter {
  _ReportRadarPainter({required this.players, this.baselinePlayers = const <TrackerTrainingPlayerRow>[]});
  final List<TrackerTrainingPlayerRow> players;
  final List<TrackerTrainingPlayerRow> baselinePlayers;

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2 + 8);
    final r = math.min(size.width, size.height) * .33;
    final grid = Paint()..color = _R.border..style = PaintingStyle.stroke..strokeWidth = 1.1;
    for (var ring = 1; ring <= 4; ring++) canvas.drawCircle(c, r * ring / 4, grid);
    final labels = ['объём', 'скорость', 'спринты', 'HIR', 'нагрузка'];
    for (var i = 0; i < labels.length; i++) {
      final a = -math.pi / 2 + i * math.pi * 2 / labels.length;
      final end = c + Offset(math.cos(a) * r, math.sin(a) * r);
      canvas.drawLine(c, end, grid);
      _radarText(canvas, labels[i], c + Offset(math.cos(a) * (r + 19), math.sin(a) * (r + 19)), 10);
    }
    if (players.isEmpty && baselinePlayers.isEmpty) return;
    // Нормировки должны совпадать с аналитикой (_RadarPainter), иначе отчёт рисует другой профиль.
    List<double> radarValues(List<TrackerTrainingPlayerRow> src) {
      if (src.isEmpty) return const <double>[];
      double avg(double Function(TrackerTrainingPlayerRow p) pick) => src.map(pick).fold<double>(0, (a, b) => a + b) / src.length;
      double clamp(double v) => v.isNaN || v.isInfinite ? 0 : v.clamp(0.0, 1.0).toDouble();
      return <double>[
        clamp(avg((p) => p.distanceM) / 6000.0),
        clamp(avg((p) => p.maxSpeedKmh) / 34.0),
        clamp(avg((p) => p.sprintCount.toDouble()) / 25.0),
        clamp(avg((p) => p.highSpeedWorkM) / 1200.0),
        clamp(avg((p) => p.playerLoad) / 1000.0),
      ];
    }

    void drawPath(List<double> values, {required Color fill, required Color stroke, required double strokeWidth}) {
      if (values.isEmpty) return;
      final path = Path();
      for (var i = 0; i < values.length; i++) {
        final a = -math.pi / 2 + i * math.pi * 2 / values.length;
        final level = values[i].clamp(0.0, 1.0).toDouble();
        final p = c + Offset(math.cos(a) * r * level, math.sin(a) * r * level);
        if (i == 0) path.moveTo(p.dx, p.dy); else path.lineTo(p.dx, p.dy);
      }
      path.close();
      canvas.drawPath(path, Paint()..color = fill..style = PaintingStyle.fill);
      canvas.drawPath(path, Paint()..color = stroke..style = PaintingStyle.stroke..strokeWidth = strokeWidth);
    }

    final baseline = radarValues(baselinePlayers);
    final values = radarValues(players);
    if (baseline.isNotEmpty) {
      drawPath(baseline, fill: _R.muted.withOpacity(.08), stroke: _R.muted.withOpacity(.50), strokeWidth: 1.4);
    }
    if (values.isNotEmpty) {
      drawPath(values, fill: _R.green.withOpacity(.17), stroke: _R.green, strokeWidth: 2.4);
    }
  }

  void _radarText(Canvas canvas, String text, Offset center, double size) {
    final tp = TextPainter(text: TextSpan(text: text, style: TextStyle(color: _R.muted, fontSize: size, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout(maxWidth: 72);
    tp.paint(canvas, center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant _ReportRadarPainter oldDelegate) => oldDelegate.players != players || oldDelegate.baselinePlayers != baselinePlayers;
}

bool _hasMeaningfulTrainingData(TrackerTrainingReport report) {
  if (report.summary.averageDistanceM > 1 ||
      report.summary.maxSpeedKmh > .5 ||
      report.summary.highSpeedDistanceM > 1 ||
      report.summary.playerLoad > 1 ||
      report.summary.heartRateSamplesCount > 0 ||
      report.summary.accelerationCount > 0 ||
      report.summary.decelerationCount > 0) {
    return true;
  }
  return report.players.any((p) =>
      p.distanceM > 1 ||
      p.maxSpeedKmh > .5 ||
      p.highSpeedWorkM > 1 ||
      p.playerLoad > 1 ||
      p.heartRateSamplesCount > 0 ||
      p.accelerations > 0 ||
      p.decelerations > 0 ||
      p.sprintCount > 0);
}

class _NoMovementNotice extends StatelessWidget {
  const _NoMovementNotice({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final players = report.players.isEmpty ? 'игроки не найдены' : '${report.players.length} игрок(ов)';
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFAEB),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFEDC7A)),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 34,
          height: 34,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFFEDC7A))),
          child: const Icon(Icons.info_outline_rounded, color: Color(0xFFB7791F), size: 18),
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('В этой сессии нет подтверждённого движения', style: TextStyle(color: _R.text, fontSize: 11.5, fontWeight: FontWeight.w900)),
            const SizedBox(height: 4),
            Text(
              '$players · дистанция и скорость равны нулю. Карты и рейтинги не должны строиться как полноценная тренировка, пока датчик не отдаст реальные GPS-точки.',
              style: const TextStyle(color: _R.muted, fontSize: 10.2, height: 1.3, fontWeight: FontWeight.w700),
            ),
          ]),
        ),
      ]),
    );
  }
}

class _SummaryGrid extends StatelessWidget {
  const _SummaryGrid({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final s = report.summary;
    final tiles = [
      _Metric('Время тренировки', report.durationLabel, 'длительность'),
      _Metric('Дистанция', s.averageDistanceM.toStringAsFixed(0), 'м'),
      _Metric('Игроки', '${report.playersCount}', 'с движением'),
      _Metric('GPS-точки', '${report.pointsCount}', 'записей'),
      _Metric('Средняя скорость', s.avgSpeedKmh.toStringAsFixed(1), 'км/ч'),
      _Metric('Макс. скорость', s.maxSpeedKmh.toStringAsFixed(1), 'км/ч'),
      _Metric('Скоростная работа', s.highSpeedDistanceM.toStringAsFixed(0), 'м'),
      _Metric('V3 бег', s.v3RunM.toStringAsFixed(0), 'м'),
      _Metric('V4 ВСБ', s.v4HsrM.toStringAsFixed(0), 'м'),
      _Metric('V5 спринт', s.v5SprintM.toStringAsFixed(0), 'м'),
      _Metric('Спринты', '${s.sprintCount}', 'кол-во'),
      _Metric('Ускор./торм.', s.accDecPerMin.toStringAsFixed(1), 'в мин'),
      _Metric('Ускорения', '${s.accelerationCount}', 'кол-во'),
      _Metric('Торможения', '${s.decelerationCount}', 'кол-во'),
      _Metric('Взрывные', '${s.explosiveActions}', 'действия'),
      _Metric('Нагрузка', s.playerLoad.toStringAsFixed(0), 'усл. ед.'),
      _Metric('Средний пульс', s.heartRateAvgBpm > 0 ? s.heartRateAvgBpm.toStringAsFixed(0) : '—', 'bpm'),
      _Metric('Макс. пульс', s.heartRateMaxBpm > 0 ? s.heartRateMaxBpm.toStringAsFixed(0) : '—', 'bpm'),
      _Metric('HR-записи', '${s.heartRateSamplesCount}', 'точек'),
    ];
    return LayoutBuilder(builder: (context, c) {
      final compact = c.maxWidth < 460;
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: tiles.length,
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
          maxCrossAxisExtent: compact ? 176 : 190,
          mainAxisExtent: compact ? 62 : 72,
          crossAxisSpacing: compact ? 7 : 8,
          mainAxisSpacing: compact ? 7 : 8,
        ),
        itemBuilder: (_, i) => _MetricTile(metric: tiles[i]),
      );
    });
  }
}

class _LocomotorTab extends StatelessWidget {
  const _LocomotorTab({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return _ScrollPage(children: [
      _SectionTitle('ЛОКОМОТОРНАЯ РАБОТА'),
      LayoutBuilder(builder: (context, c) {
        if (c.maxWidth >= 980) {
          return _Card(
            title: report.title,
            child: _LocomotorTable(players: report.players),
          );
        }
        return _Card(
          title: report.title,
          child: _LocomotorCards(players: report.players),
        );
      }),
    ]);
  }
}

class _MechanicalTab extends StatelessWidget {
  const _MechanicalTab({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return _ScrollPage(children: [
      _SectionTitle('МЕХАНИЧЕСКАЯ РАБОТА'),
      _TwoByTwo(
        a: _ChartCard(title: 'УСКОРЕНИЯ/ТОРМОЖЕНИЯ (ОБЩЕЕ КОЛ-ВО)', child: _DualBarChart(players: report.players, first: (p) => p.accelerations.toDouble(), second: (p) => p.decelerations.toDouble(), firstLabel: 'Ускорения', secondLabel: 'Торможения')),
        b: _ChartCard(title: 'УСКОРЕНИЯ/ТОРМОЖЕНИЯ (МАКС ИНТ)', child: _BarChart(players: report.players, value: (p) => p.accDecPerMin, label: 'УСК+ТОР/мин')),
        c: _ChartCard(title: 'ИЗМЕНЕНИЕ НАПРАВЛЕНИЯ ДВИЖЕНИЯ', child: _BarChart(players: report.players, value: (p) => p.highSpeedActions.toDouble(), label: 'Кол-во')),
        d: _ChartCard(title: 'ВЗРЫВНЫЕ ДЕЙСТВИЯ', child: _BarChart(players: report.players, value: (p) => p.explosiveActions.toDouble(), label: 'Действия')),
      ),
    ]);
  }
}

class _InternalLoadTab extends StatelessWidget {
  const _InternalLoadTab({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return _ScrollPage(children: [
      _SectionTitle('ВНУТРЕННЯЯ НАГРУЗКА'),
      _Card(title: 'АНАЛИЗ ПО ПУЛЬСУ И GPS', child: _HrRecommendations(report: report)),
      const SizedBox(height: 12),
      _ChartCard(title: 'ПУЛЬС ПО ВРЕМЕНИ / КРАСНАЯ НАГРУЗКА', child: _HeartRateTimelineChart(report: report)),
      const SizedBox(height: 12),
      _Card(title: 'ЗОНЫ ЧСС ПО ВРЕМЕНИ', child: SizedBox(height: 96, child: _HrZoneTimeStrip(report: report))),
      const SizedBox(height: 12),
      _TwoByTwo(
        a: _ChartCard(title: 'ИТОГ ПО ЗОНАМ ЧСС', child: _HrZoneSummaryBars(players: report.players)),
        b: _ChartCard(title: 'СРЕДНИЙ / МАКСИМАЛЬНЫЙ ПУЛЬС', child: _HrPlayerSummaryChart(players: report.players)),
        c: _ChartCard(title: 'СРЕДНИЙ % ОТ ЧСС МАКС', child: _BarChart(players: report.players, value: (p) => p.heartRateMaxPercent, label: '% ЧСС')),
        d: _ChartCard(title: 'НАПРЯЖЕНИЕ ПО ЧСС + НАГРУЗКА ИГРОКА', child: _DualBarChart(players: report.players, first: (p) => p.hrExertion, second: (p) => p.playerLoad, firstLabel: 'Напряжение по ЧСС', secondLabel: 'Нагрузка игрока')),
      ),
    ]);
  }
}



List<String> _reportCoachMessages(TrackerTrainingReport report) {
  final withHr = report.players.where((p) => p.heartRateSamplesCount > 0).toList();
  final messages = <String>[];
  if (withHr.isEmpty) {
    messages.add('Нет данных Polar H10: подключите пульсометры, назначьте их игрокам и запустите Live-сессию — тогда отчёт совместит ЧСС с GPS-нагрузкой.');
  } else {
    final avgHr = withHr.map((p) => p.heartRateAvgBpm).fold<double>(0, (a, b) => a + b) / withHr.length;
    final maxHr = withHr.map((p) => p.heartRateMaxBpm).fold<double>(0, math.max);
    final highZone = withHr.where((p) => (p.hrZ4Samples + p.hrZ5Samples) > (p.heartRateSamplesCount * .35)).toList();
    final highGpsLowHr = withHr.where((p) => p.highSpeedWorkM > 250 && p.heartRateAvgBpm > 0 && p.heartRateAvgBpm < 135).toList();
    final highHrLowGps = withHr.where((p) => p.heartRateAvgBpm >= 165 && p.distanceM < 500).toList();
    messages.add('Пульс есть у ${withHr.length} игрок(ов): средний ${avgHr.toStringAsFixed(0)} bpm, максимум ${maxHr.toStringAsFixed(0)} bpm.');
    if (highZone.isNotEmpty) {
      messages.add('Контроль восстановления: ${highZone.map((p) => p.name).take(4).join(', ')} провели много времени в Z4/Z5 — после тренировки стоит проверить самочувствие и снизить повторную высокую нагрузку.');
    }
    if (highGpsLowHr.isNotEmpty) {
      messages.add('Хорошая готовность: ${highGpsLowHr.map((p) => p.name).take(4).join(', ')} дали скоростную работу при умеренной ЧСС. Можно оставить их в основной группе.');
    }
    if (highHrLowGps.isNotEmpty) {
      messages.add('Возможная усталость/стресс: ${highHrLowGps.map((p) => p.name).take(4).join(', ')} показывают высокий пульс при небольшой дистанции. Нужна проверка ремня H10, самочувствия и восстановления.');
    }
    if (messages.length == 1) {
      messages.add('Критичных перекосов по ЧСС и GPS не видно: нагрузку можно оценивать по обычным метрикам дистанции, скорости, ускорений и зонам пульса.');
    }
  }
  return messages;
}

class _HrRecommendations extends StatelessWidget {
  const _HrRecommendations({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final messages = _reportCoachMessages(report);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: messages.map((m) => Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.favorite_rounded, color: _R.red, size: 15),
        const SizedBox(width: 8),
        Expanded(child: Text(m, style: const TextStyle(color: _R.text, fontSize: 11.2, height: 1.35, fontWeight: FontWeight.w700))),
      ]),
    )).toList());
  }
}

class _MicrocycleTab extends StatelessWidget {
  const _MicrocycleTab({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    return _ScrollPage(children: [
      _SectionTitle('ДИНАМИКА МИКРОЦИКЛА'),
      LayoutBuilder(builder: (context, c) {
        final twoColumns = c.maxWidth >= 720;
        final first = _Card(title: 'Дистанция / высокоинтенсивный бег / ускорения-торможения', child: SizedBox(height: twoColumns ? 360 : 420, child: _MicrocycleChart(points: report.microcycle)));
        final second = _Card(title: 'СРАВНЕНИЕ MD-5', child: SizedBox(height: twoColumns ? 360 : 320, child: _PercentBarChart(values: _mdComparison(report))));
        if (!twoColumns) return Column(children: [first, const SizedBox(height: 12), second]);
        return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(child: first), const SizedBox(width: 12), Expanded(child: second)]);
      }),
    ]);
  }
}

class _ScrollPage extends StatelessWidget {
  const _ScrollPage({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(8),
      children: children,
    );
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: _R.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          height: 30,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          alignment: Alignment.centerLeft,
          decoration: const BoxDecoration(color: _R.soft, border: Border(bottom: BorderSide(color: _R.border))),
          child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontWeight: FontWeight.w800, fontSize: 11.5)),
        ),
        Padding(padding: const EdgeInsets.all(8), child: child),
      ]),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Center(child: Text(text, style: const TextStyle(color: _R.text, fontSize: 17, fontWeight: FontWeight.w800, letterSpacing: .1))),
    );
  }
}

class _Metric {
  const _Metric(this.title, this.value, this.subtitle);
  final String title;
  final String value;
  final String subtitle;
}

class _MetricTile extends StatelessWidget {
  const _MetricTile({required this.metric});
  final _Metric metric;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final compact = c.maxWidth < 150;
      return Container(
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: _R.border),
          borderRadius: BorderRadius.circular(12),
          boxShadow: const [BoxShadow(color: Color(0x06000000), blurRadius: 10, offset: Offset(0, 4))],
        ),
        padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 10, vertical: compact ? 6 : 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(metric.title.toUpperCase(), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _R.muted, fontSize: compact ? 7.6 : 8.5, fontWeight: FontWeight.w900, letterSpacing: .15)),
          SizedBox(height: compact ? 3 : 5),
          FittedBox(alignment: Alignment.centerLeft, fit: BoxFit.scaleDown, child: Text(metric.value, maxLines: 1, style: TextStyle(color: _R.text, fontSize: compact ? 16 : 18, fontWeight: FontWeight.w900))),
          Text(metric.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _R.muted, fontSize: compact ? 8.2 : 9, fontWeight: FontWeight.w800)),
        ]),
      );
    });
  }
}

class _PeriodsTable extends StatelessWidget {
  const _PeriodsTable({required this.periods});
  final List<TrackerExercisePeriod> periods;

  @override
  Widget build(BuildContext context) {
    if (periods.isEmpty) return const _EmptyBlock('Периоды пока не сохранены. Используйте + Период в Live.');
    return Table(
      border: TableBorder.all(color: _R.border),
      columnWidths: const {0: FlexColumnWidth(2.2), 1: FlexColumnWidth(1.2), 2: FlexColumnWidth(1.2), 3: FlexColumnWidth(.9), 4: FlexColumnWidth(.9)},
      children: [
        _tableRow(['Упражнение', 'Начало', 'Конец', 'Дист.', 'Уск/торм'], header: true),
        ...periods.map((p) => _tableRow([p.title, p.startLabel, p.endLabel, '${p.distanceM.toStringAsFixed(0)} м', '${p.accDecCount}'])),
      ],
    );
  }
}

class _LocomotorCards extends StatelessWidget {
  const _LocomotorCards({required this.players});
  final List<TrackerTrainingPlayerRow> players;

  @override
  Widget build(BuildContext context) {
    if (players.isEmpty) return const _EmptyBlock('Нет игроков в отчёте.');
    return LayoutBuilder(builder: (context, c) {
      final twoColumns = c.maxWidth >= 560;
      final compact = c.maxWidth < 460;
      final cards = [...players, _avgRow(players)];
      if (compact) {
        return Column(children: [
          for (var i = 0; i < cards.length; i++) ...[
            _LocomotorCompactRow(player: cards[i], average: cards[i].name == 'СРЕДНЕЕ'),
            if (i != cards.length - 1) const SizedBox(height: 8),
          ],
        ]);
      }
      if (!twoColumns) {
        return Column(children: [
          for (var i = 0; i < cards.length; i++) ...[
            _LocomotorPlayerCard(player: cards[i], average: cards[i].name == 'СРЕДНЕЕ'),
            if (i != cards.length - 1) const SizedBox(height: 8),
          ],
        ]);
      }
      return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: cards.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisExtent: 152,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (_, i) => _LocomotorPlayerCard(player: cards[i], average: cards[i].name == 'СРЕДНЕЕ'),
      );
    });
  }
}

class _LocomotorCompactRow extends StatelessWidget {
  const _LocomotorCompactRow({required this.player, required this.average});
  final TrackerTrainingPlayerRow player;
  final bool average;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: average ? const Color(0xFFF0FDF4) : Colors.white,
        border: Border.all(color: average ? _R.greenLine : _R.border),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          if (!average) ...[_PlayerAvatar(player: player, size: 34), const SizedBox(width: 8)],
          Expanded(child: Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 12, fontWeight: FontWeight.w900))),
          Text(player.duration, style: const TextStyle(color: _R.muted, fontSize: 9.5, fontWeight: FontWeight.w900)),
        ]),
        const SizedBox(height: 8),
        Wrap(spacing: 6, runSpacing: 6, children: [
          _TinyPill(label: 'Дист.', value: '${player.distanceM.toStringAsFixed(0)} м'),
          _TinyPill(label: 'м/мин', value: player.metersPerMin.toStringAsFixed(1)),
          _TinyPill(label: 'Ср.', value: player.avgSpeedKmh.toStringAsFixed(1)),
          _TinyPill(label: 'Макс.', value: player.maxSpeedKmh.toStringAsFixed(1)),
          _TinyPill(label: 'Уск.', value: '${player.accelerations}'),
          _TinyPill(label: 'Торм.', value: '${player.decelerations}'),
          _TinyPill(label: 'GPS', value: '${player.pointsCount}'),
        ]),
      ]),
    );
  }
}

class _LocomotorPlayerCard extends StatelessWidget {
  const _LocomotorPlayerCard({required this.player, required this.average});
  final TrackerTrainingPlayerRow player;
  final bool average;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: average ? const Color(0xFFF0FDF4) : const Color(0xFFF8FAF8),
        border: Border.all(color: average ? _R.greenLine : _R.border),
        borderRadius: BorderRadius.circular(10),
      ),
      padding: const EdgeInsets.all(10),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          if (!average) ...[_PlayerAvatar(player: player, size: 32), const SizedBox(width: 8)],
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 12, fontWeight: FontWeight.w900)),
            if (!average) Text([if (player.number.isNotEmpty) '#${player.number}', if (player.position.isNotEmpty) player.position].join(' · '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 8.7, fontWeight: FontWeight.w800)),
          ])),
          Text(player.duration, style: const TextStyle(color: _R.muted, fontSize: 9.5, fontWeight: FontWeight.w800)),
        ]),
        const SizedBox(height: 8),
        SizedBox(
          height: 74,
          child: GridView.count(
            crossAxisCount: 4,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.95,
            mainAxisSpacing: 6,
            crossAxisSpacing: 6,
            children: [
              _MiniMetric(label: 'Дист.', value: '${player.distanceM.toStringAsFixed(0)} м'),
              _MiniMetric(label: 'м/мин', value: player.metersPerMin.toStringAsFixed(1)),
              _MiniMetric(label: 'Ср.', value: '${player.avgSpeedKmh.toStringAsFixed(1)}'),
              _MiniMetric(label: 'Макс.', value: '${player.maxSpeedKmh.toStringAsFixed(1)}'),
              _MiniMetric(label: 'Уск.', value: '${player.accelerations}'),
              _MiniMetric(label: 'Торм.', value: '${player.decelerations}'),
              _MiniMetric(label: 'Спр.', value: '${player.sprintCount}'),
              _MiniMetric(label: 'GPS', value: '${player.pointsCount}'),
            ],
          ),
        ),
      ]),
    );
  }
}

class _MiniMetric extends StatelessWidget {
  const _MiniMetric({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(7), border: Border.all(color: _R.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 7.8, fontWeight: FontWeight.w800)),
        const SizedBox(height: 2),
        FittedBox(alignment: Alignment.centerLeft, fit: BoxFit.scaleDown, child: Text(value, maxLines: 1, style: const TextStyle(color: _R.text, fontSize: 10.2, fontWeight: FontWeight.w900))),
      ]),
    );
  }
}

class _LocomotorTable extends StatelessWidget {
  const _LocomotorTable({required this.players});
  final List<TrackerTrainingPlayerRow> players;

  @override
  Widget build(BuildContext context) {
    if (players.isEmpty) return const _EmptyBlock('Нет игроков в отчёте.');
    final avg = _avgRow(players);
    final rows = [...players, avg];
    return SingleChildScrollView(
      primary: false,
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: 1680,
        child: Table(
            border: TableBorder.all(color: const Color(0xFFD0D5DD)),
            columnWidths: const {
              0: FlexColumnWidth(2.8),
              1: FlexColumnWidth(1.1),
              2: FlexColumnWidth(1),
              3: FlexColumnWidth(1),
              4: FlexColumnWidth(1),
              5: FlexColumnWidth(1),
              6: FlexColumnWidth(.8),
              7: FlexColumnWidth(.8),
              8: FlexColumnWidth(.9),
              9: FlexColumnWidth(.9),
              10: FlexColumnWidth(1),
              11: FlexColumnWidth(1),
              12: FlexColumnWidth(1),
              13: FlexColumnWidth(.8),
              14: FlexColumnWidth(1),
              15: FlexColumnWidth(.8),
              16: FlexColumnWidth(.8),
            },
            children: [
              _tableRow(['Игрок', 'Время', 'Дист. м', 'м/мин', 'Ср. км/ч', 'Макс.', 'Уск.', 'Торм.', 'УСК+ТОР', 'Взрыв.', 'V3 бег', 'V4 ВСБ', 'V5 спринт', 'Спр.', 'V4+V5', 'Действ.', 'GPS'], header: true),
              ...rows.map((p) => _playerRow(p, p.name == 'СРЕДНЕЕ')),
            ],
          ),
        ),
      );
  }

  TableRow _playerRow(TrackerTrainingPlayerRow p, bool avg) {
    return TableRow(
      decoration: BoxDecoration(color: avg ? const Color(0xFFE5E7EB) : Colors.white),
      children: [
        _playerCell(p, avg),
        _cell(p.duration),
        _heatCell(p.distanceM.toStringAsFixed(0), p.distanceM, 4500),
        _heatCell(p.metersPerMin.toStringAsFixed(1), p.metersPerMin, 130),
        _heatCell(p.avgSpeedKmh.toStringAsFixed(1), p.avgSpeedKmh, 16),
        _heatCell(p.maxSpeedKmh.toStringAsFixed(1), p.maxSpeedKmh, 30),
        _barCell('${p.accelerations}', p.accelerations.toDouble(), 24, _R.green),
        _barCell('${p.decelerations}', p.decelerations.toDouble(), 28, _R.red),
        _heatCell(p.accDecPerMin.toStringAsFixed(1), p.accDecPerMin, 3),
        _barCell('${p.explosiveActions}', p.explosiveActions.toDouble(), 30, _R.red),
        _heatCell(p.v3RunM.toStringAsFixed(0), p.v3RunM, 1300),
        _heatCell(p.v4HsrM.toStringAsFixed(0), p.v4HsrM, 450),
        _heatCell(p.v5SprintM.toStringAsFixed(0), p.v5SprintM, 110),
        _cell('${p.sprintCount}'),
        _heatCell(p.highSpeedWorkM.toStringAsFixed(0), p.highSpeedWorkM, 550),
        _cell('${p.highSpeedActions}'),
        _cell('${p.pointsCount}'),
      ],
    );
  }
}

class _TwoByTwo extends StatelessWidget {
  const _TwoByTwo({required this.a, required this.b, required this.c, required this.d});
  final Widget a;
  final Widget b;
  final Widget c;
  final Widget d;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final wide = constraints.maxWidth >= 640;
      if (!wide) {
        return Column(children: [a, const SizedBox(height: 12), b, const SizedBox(height: 12), c, const SizedBox(height: 12), d]);
      }
      return Column(children: [
        Row(children: [Expanded(child: a), const SizedBox(width: 12), Expanded(child: b)]),
        const SizedBox(height: 12),
        Row(children: [Expanded(child: c), const SizedBox(width: 12), Expanded(child: d)]),
      ]);
    });
  }
}

class _ChartCard extends StatelessWidget {
  const _ChartCard({required this.title, required this.child});
  final String title;
  final Widget child;
  @override
  Widget build(BuildContext context) => _Card(title: title, child: SizedBox(height: 320, child: child));
}

class _BarChart extends StatelessWidget {
  const _BarChart({required this.players, required this.value, required this.label});
  final List<TrackerTrainingPlayerRow> players;
  final double Function(TrackerTrainingPlayerRow) value;
  final String label;
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _BarChartPainter(players: players, value: value, label: label), child: const SizedBox.expand());
}

class _DualBarChart extends StatelessWidget {
  const _DualBarChart({required this.players, required this.first, required this.second, required this.firstLabel, required this.secondLabel});
  final List<TrackerTrainingPlayerRow> players;
  final double Function(TrackerTrainingPlayerRow) first;
  final double Function(TrackerTrainingPlayerRow) second;
  final String firstLabel;
  final String secondLabel;
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _DualBarChartPainter(players: players, first: first, second: second, firstLabel: firstLabel, secondLabel: secondLabel), child: const SizedBox.expand());
}


class _HeartRateTimelineChart extends StatelessWidget {
  const _HeartRateTimelineChart({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final points = _reportHrTimeline(report);
    if (points.isEmpty) return const _EmptyBlock('Пульс по времени не найден. Проверьте, что Polar H10 был привязан к игроку и сессия завершена.');
    return ClipRect(
      child: CustomPaint(
        painter: _HeartRateTimelinePainter(points: points),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _HrZoneTimeStrip extends StatelessWidget {
  const _HrZoneTimeStrip({required this.report});
  final TrackerTrainingReport report;

  @override
  Widget build(BuildContext context) {
    final points = _reportHrTimeline(report);
    if (points.isEmpty) return const _EmptyBlock('Зоны ЧСС по времени пока не найдены.');
    return ClipRect(
      child: CustomPaint(
        painter: _HrZoneTimeStripPainter(points: points),
        child: const SizedBox.expand(),
      ),
    );
  }
}

class _HrZoneSummaryBars extends StatelessWidget {
  const _HrZoneSummaryBars({required this.players});
  final List<TrackerTrainingPlayerRow> players;

  @override
  Widget build(BuildContext context) {
    final withHr = players.where((p) => p.heartRateSamplesCount > 0).toList(growable: false);
    if (withHr.isEmpty) return const _EmptyBlock('Нет записей Polar H10 для выбранных игроков.');
    final totals = <int>[
      withHr.fold<int>(0, (a, p) => a + p.hrZ1Samples),
      withHr.fold<int>(0, (a, p) => a + p.hrZ2Samples),
      withHr.fold<int>(0, (a, p) => a + p.hrZ3Samples),
      withHr.fold<int>(0, (a, p) => a + p.hrZ4Samples),
      withHr.fold<int>(0, (a, p) => a + p.hrZ5Samples),
    ];
    final total = totals.fold<int>(0, (a, b) => a + b);
    if (total <= 0) return const _EmptyBlock('Зоны ЧСС не рассчитаны.');
    const names = ['Z1 восстановление', 'Z2 лёгкая', 'Z3 рабочая', 'Z4 высокая', 'Z5 пик'];
    const colors = [Color(0xFFA3E635), Color(0xFF84CC16), Color(0xFFFACC15), Color(0xFFF97316), Color(0xFFE11D48)];
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          for (var i = 0; i < totals.length; i++) ...[
            _HrZoneSummaryRow(label: names[i], color: colors[i], value: totals[i], total: total),
            if (i != totals.length - 1) const SizedBox(height: 10),
          ],
        ],
      ),
    );
  }
}

class _HrZoneSummaryRow extends StatelessWidget {
  const _HrZoneSummaryRow({required this.label, required this.color, required this.value, required this.total});
  final String label;
  final Color color;
  final int value;
  final int total;

  @override
  Widget build(BuildContext context) {
    final ratio = total <= 0 ? 0.0 : (value / total).clamp(0.0, 1.0).toDouble();
    final seconds = value; // Polar usually saves one HR sample per second; if frequency differs, percentage remains correct.
    final min = seconds ~/ 60;
    final sec = seconds % 60;
    return Row(children: [
      SizedBox(width: 118, child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 10, fontWeight: FontWeight.w900))),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: Stack(children: [
            Container(height: 13, color: const Color(0xFFF3F4F6)),
            FractionallySizedBox(widthFactor: ratio, child: Container(height: 13, color: color)),
          ]),
        ),
      ),
      const SizedBox(width: 10),
      SizedBox(width: 74, child: Text('${min}:${sec.toString().padLeft(2, '0')} · ${(ratio * 100).toStringAsFixed(0)}%', textAlign: TextAlign.right, style: const TextStyle(color: _R.muted, fontSize: 9.5, fontWeight: FontWeight.w900))),
    ]);
  }
}

class _HrPlayerSummaryChart extends StatelessWidget {
  const _HrPlayerSummaryChart({required this.players});
  final List<TrackerTrainingPlayerRow> players;

  @override
  Widget build(BuildContext context) {
    final list = players.where((p) => p.heartRateSamplesCount > 0).take(12).toList(growable: false);
    if (list.isEmpty) return const _EmptyBlock('По выбранным игрокам нет данных ЧСС.');
    return ClipRect(child: CustomPaint(painter: _HrPlayerSummaryPainter(players: list), child: const SizedBox.expand()));
  }
}

List<TrackerHeartRatePoint> _reportHrTimeline(TrackerTrainingReport report) {
  if (report.heartRateTimeline.isNotEmpty) return report.heartRateTimeline;
  final players = report.players.where((p) => p.heartRateSamplesCount > 0 && p.heartRateAvgBpm > 0).take(12).toList(growable: false);
  if (players.isEmpty) return const <TrackerHeartRatePoint>[];
  final out = <TrackerHeartRatePoint>[];
  for (var i = 0; i < players.length; i++) {
    final p = players[i];
    out.add(TrackerHeartRatePoint(playerId: p.playerId, playerName: p.name, timeMs: 0, minute: i, bpm: p.heartRateAvgBpm.round(), hrLoad: p.hrExertion, zone: _zoneFromBpm(p.heartRateAvgBpm.round())));
    if (p.heartRateMaxBpm > p.heartRateAvgBpm) {
      out.add(TrackerHeartRatePoint(playerId: p.playerId, playerName: p.name, timeMs: 0, minute: i + 1, bpm: p.heartRateMaxBpm.round(), hrLoad: p.hrExertion, zone: _zoneFromBpm(p.heartRateMaxBpm.round())));
    }
  }
  return out;
}

String _zoneFromBpm(int bpm) {
  if (bpm >= 180) return 'z5';
  if (bpm >= 160) return 'z4';
  if (bpm >= 140) return 'z3';
  if (bpm >= 120) return 'z2';
  return 'z1';
}

Color _hrZoneColor(String zone) {
  switch (zone.toLowerCase()) {
    case 'z5': return const Color(0xFFE11D48);
    case 'z4': return const Color(0xFFF97316);
    case 'z3': return const Color(0xFFFACC15);
    case 'z2': return const Color(0xFF84CC16);
    default: return const Color(0xFFA3E635);
  }
}

class _HeartRateTimelinePainter extends _BaseChartPainter {
  _HeartRateTimelinePainter({required this.points});
  final List<TrackerHeartRatePoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final list = points.where((p) => p.bpm > 0).toList(growable: false);
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(52, 30, math.max(10.0, size.width - 86), math.max(10.0, size.height - 86));
    final clip = Path()..addRect(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.save();
    canvas.clipPath(clip);
    drawGrid(canvas, rect);

    int xKey(TrackerHeartRatePoint p) => p.timeMs > 0 ? p.timeMs : p.minute * 60000;
    final minX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a < b ? a : b).toDouble();
    var maxX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a > b ? a : b).toDouble();
    if ((maxX - minX).abs() < 1) maxX = minX + 60000;
    final minBpm = math.max(40.0, list.map((p) => p.bpm).fold<int>(list.first.bpm, (a, b) => a < b ? a : b).toDouble() - 10);
    final maxBpm = math.max(130.0, list.map((p) => p.bpm).fold<int>(list.first.bpm, (a, b) => a > b ? a : b).toDouble() + 14);
    Offset mapPoint(TrackerHeartRatePoint p, double yValue) {
      final x = rect.left + rect.width * ((xKey(p) - minX) / (maxX - minX)).clamp(0.0, 1.0).toDouble();
      final y = rect.bottom - rect.height * ((yValue - minBpm) / (maxBpm - minBpm)).clamp(0.0, 1.0).toDouble();
      return Offset(x, y);
    }

    for (final z in [120, 140, 160, 180]) {
      if (z < minBpm || z > maxBpm) continue;
      final y = rect.bottom - rect.height * ((z - minBpm) / (maxBpm - minBpm)).clamp(0.0, 1.0).toDouble();
      final color = z >= 180 ? const Color(0xFFE11D48) : (z >= 160 ? const Color(0xFFF97316) : (z >= 140 ? const Color(0xFFFACC15) : const Color(0xFF84CC16)));
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), Paint()..color = color.withOpacity(.55)..strokeWidth = 1.2);
      text(canvas, 'Z${z == 120 ? 2 : z == 140 ? 3 : z == 160 ? 4 : 5}', Offset(rect.right - 28, y - 16), size: 9.5, color: color, weight: FontWeight.w900, maxWidth: 28);
    }

    final bpmPath = Path();
    final loadPath = Path();
    var first = true;
    for (final p in list) {
      final bp = mapPoint(p, p.bpm.toDouble());
      final lp = mapPoint(p, minBpm + (maxBpm - minBpm) * (p.hrLoad.clamp(0, 200).toDouble() / 200.0));
      if (first) { bpmPath.moveTo(bp.dx, bp.dy); loadPath.moveTo(lp.dx, lp.dy); first = false; } else { bpmPath.lineTo(bp.dx, bp.dy); loadPath.lineTo(lp.dx, lp.dy); }
    }
    canvas.drawPath(loadPath, Paint()..color = const Color(0xFF7F1D1D).withOpacity(.38)..style = PaintingStyle.stroke..strokeWidth = 2.0..strokeCap = StrokeCap.round);
    canvas.drawPath(bpmPath, Paint()..color = _R.red..style = PaintingStyle.stroke..strokeWidth = 3.0..strokeCap = StrokeCap.round);

    final every = math.max(1, (list.length / 8).ceil());
    for (var i = 0; i < list.length; i += every) {
      final p = list[i];
      final o = mapPoint(p, p.bpm.toDouble());
      canvas.drawCircle(o, 4.6, Paint()..color = _hrZoneColor(p.zone));
      canvas.drawCircle(o, 7.8, Paint()..color = _hrZoneColor(p.zone).withOpacity(.16));
      text(canvas, '${p.bpm}', o + const Offset(-10, -22), size: 9, color: _R.green, weight: FontWeight.w900, maxWidth: 36);
    }

    final minLabel = '0 мин';
    final maxLabel = '${math.max(1, ((maxX - minX) / 60000).round())} мин';
    text(canvas, minLabel, Offset(rect.left, rect.bottom + 10), size: 10, color: _R.muted, weight: FontWeight.w900, maxWidth: 60);
    text(canvas, maxLabel, Offset(rect.right - 55, rect.bottom + 10), size: 10, color: _R.muted, weight: FontWeight.w900, maxWidth: 70);
    text(canvas, 'ЧСС bpm — красная линия · нагрузка по ЧСС — тёмно-красная', Offset(rect.left, 0), size: 10.5, color: _R.text, weight: FontWeight.w900, maxWidth: rect.width);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _HeartRateTimelinePainter oldDelegate) => oldDelegate.points != points;
}

class _HrZoneTimeStripPainter extends _BaseChartPainter {
  _HrZoneTimeStripPainter({required this.points});
  final List<TrackerHeartRatePoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final list = points.where((p) => p.bpm > 0).toList(growable: false);
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(58, 30, math.max(20.0, size.width - 96), 22);
    int xKey(TrackerHeartRatePoint p) => p.timeMs > 0 ? p.timeMs : p.minute * 60000;
    final minX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a < b ? a : b).toDouble();
    var maxX = list.map(xKey).fold<int>(xKey(list.first), (a, b) => a > b ? a : b).toDouble();
    if ((maxX - minX).abs() < 1) maxX = minX + 60000;
    canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(999)), Paint()..color = const Color(0xFFF3F4F6));
    for (var i = 0; i < list.length; i++) {
      final p = list[i];
      final x1 = rect.left + rect.width * ((xKey(p) - minX) / (maxX - minX)).clamp(0.0, 1.0).toDouble();
      final x2 = i + 1 < list.length ? rect.left + rect.width * ((xKey(list[i + 1]) - minX) / (maxX - minX)).clamp(0.0, 1.0).toDouble() : math.min(rect.right, x1 + math.max(8.0, rect.width / math.max(1, list.length)));
      canvas.drawRect(Rect.fromLTRB(x1, rect.top, math.max(x1 + 3, x2), rect.bottom), Paint()..color = _hrZoneColor(p.zone));
    }
    text(canvas, '0 мин', Offset(rect.left, rect.bottom + 10), size: 10, color: _R.muted, weight: FontWeight.w900, maxWidth: 60);
    text(canvas, '${math.max(1, ((maxX - minX) / 60000).round())} мин', Offset(rect.right - 54, rect.bottom + 10), size: 10, color: _R.muted, weight: FontWeight.w900, maxWidth: 64);
    const labels = ['Z1', 'Z2', 'Z3', 'Z4', 'Z5'];
    for (var i = 0; i < labels.length; i++) {
      final x = rect.left + i * 44.0;
      canvas.drawCircle(Offset(x, 12), 5, Paint()..color = _hrZoneColor(labels[i].toLowerCase()));
      text(canvas, labels[i], Offset(x + 8, 5), size: 9.5, color: _R.text, weight: FontWeight.w900, maxWidth: 32);
    }
  }

  @override
  bool shouldRepaint(covariant _HrZoneTimeStripPainter oldDelegate) => oldDelegate.points != points;
}

class _HrPlayerSummaryPainter extends _BaseChartPainter {
  _HrPlayerSummaryPainter({required this.players});
  final List<TrackerTrainingPlayerRow> players;

  @override
  void paint(Canvas canvas, Size size) {
    if (players.isEmpty) return;
    final rect = Rect.fromLTWH(48, 26, math.max(10.0, size.width - 70), math.max(10.0, size.height - 86));
    canvas.save();
    canvas.clipRect(Rect.fromLTWH(0, 0, size.width, size.height));
    drawGrid(canvas, rect);
    final maxValue = math.max(130.0, players.map((p) => p.heartRateMaxBpm).fold<double>(1, (a, b) => a > b ? a : b) + 12);
    final minValue = math.max(40.0, players.map((p) => p.heartRateMinBpm > 0 ? p.heartRateMinBpm : p.heartRateAvgBpm).fold<double>(999, (a, b) => a < b ? a : b) - 8);
    final gap = rect.width / players.length;
    for (var i = 0; i < players.length; i++) {
      final p = players[i];
      final x = rect.left + gap * i + gap / 2;
      final avgY = rect.bottom - rect.height * ((p.heartRateAvgBpm - minValue) / (maxValue - minValue)).clamp(0.0, 1.0).toDouble();
      final maxY = rect.bottom - rect.height * ((p.heartRateMaxBpm - minValue) / (maxValue - minValue)).clamp(0.0, 1.0).toDouble();
      canvas.drawLine(Offset(x, avgY), Offset(x, maxY), Paint()..color = _R.red.withOpacity(.45)..strokeWidth = 5..strokeCap = StrokeCap.round);
      canvas.drawCircle(Offset(x, avgY), 5, Paint()..color = _R.green);
      canvas.drawCircle(Offset(x, maxY), 5, Paint()..color = _R.red);
      text(canvas, '${p.heartRateAvgBpm.toStringAsFixed(0)}', Offset(x - 14, avgY + 8), size: 8.5, color: _R.green, weight: FontWeight.w900, maxWidth: 32, align: TextAlign.center);
      text(canvas, shortName(p.name), Offset(x - gap * .42, rect.bottom + 8), size: 8, color: _R.muted, maxWidth: gap * .86, align: TextAlign.center);
    }
    text(canvas, 'зелёная точка — средний bpm · красная — максимум', Offset(rect.left, 0), size: 10.5, color: _R.text, weight: FontWeight.w900, maxWidth: rect.width);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant _HrPlayerSummaryPainter oldDelegate) => oldDelegate.players != players;
}

class _StackedHrChart extends StatelessWidget {
  const _StackedHrChart({required this.players, required this.distanceMode});
  final List<TrackerTrainingPlayerRow> players;
  final bool distanceMode;
  @override
  Widget build(BuildContext context) => CustomPaint(painter: _StackedHrPainter(players: players, distanceMode: distanceMode), child: const SizedBox.expand());
}

class _MicrocycleChart extends StatelessWidget {
  const _MicrocycleChart({required this.points});
  final List<TrackerMicrocyclePoint> points;
  @override
  Widget build(BuildContext context) {
    if (points.isEmpty) return const _EmptyBlock('Микроцикл появится после реальных сессий выбранной команды.');
    return CustomPaint(painter: _MicrocyclePainter(points: points), child: const SizedBox.expand());
  }
}

class _PercentBarChart extends StatelessWidget {
  const _PercentBarChart({required this.values});
  final List<_NamedValue> values;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      // На планшетных окнах график с 12 вертикальными подписями выглядит тяжело.
      // Для узких блоков показываем аккуратные 2-колоночные карточки,
      // а полноценную диаграмму оставляем для широкого desktop-отчёта.
      if (constraints.maxWidth < 720) {
        return _PercentCards(values: values);
      }
      return CustomPaint(painter: _PercentPainter(values: values), child: const SizedBox.expand());
    });
  }
}

class _PercentCards extends StatelessWidget {
  const _PercentCards({required this.values});
  final List<_NamedValue> values;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final columns = c.maxWidth >= 520 ? 2 : 1;
      return GridView.builder(
        padding: const EdgeInsets.all(2),
        physics: const NeverScrollableScrollPhysics(),
        itemCount: values.length,
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: columns,
          mainAxisExtent: 38,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
        ),
        itemBuilder: (_, i) {
          final item = values[i];
          final v = item.value.clamp(0, 100).toDouble();
          return Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
            decoration: BoxDecoration(color: const Color(0xFFF8FAF8), borderRadius: BorderRadius.circular(9), border: Border.all(color: _R.border)),
            child: Row(children: [
              Expanded(child: Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 9.7, fontWeight: FontWeight.w800))),
              const SizedBox(width: 8),
              Text('${v.toStringAsFixed(0)}%', style: const TextStyle(color: _R.darkGreen, fontSize: 11.5, fontWeight: FontWeight.w900)),
              const SizedBox(width: 8),
              SizedBox(
                width: 54,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(999),
                  child: LinearProgressIndicator(
                    value: v / 100,
                    minHeight: 6,
                    backgroundColor: Colors.white,
                    valueColor: const AlwaysStoppedAnimation<Color>(Color(0xFFF9D976)),
                  ),
                ),
              ),
            ]),
          );
        },
      );
    });
  }
}

abstract class _BaseChartPainter extends CustomPainter {
  void drawGrid(Canvas canvas, Rect rect, {int lines = 5}) {
    final paint = Paint()..color = const Color(0xFFE5E7EB)..strokeWidth = 1;
    for (var i = 0; i <= lines; i++) {
      final y = rect.bottom - rect.height * i / lines;
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), paint);
    }
  }

  void text(Canvas canvas, String value, Offset offset, {double size = 10, Color color = _R.text, FontWeight weight = FontWeight.w700, TextAlign align = TextAlign.left, double maxWidth = 120}) {
    final tp = TextPainter(text: TextSpan(text: value, style: TextStyle(color: color, fontSize: size, fontWeight: weight)), textDirection: TextDirection.ltr, textAlign: align, maxLines: 2)..layout(maxWidth: maxWidth);
    tp.paint(canvas, offset);
  }

  String shortName(String name) {
    final parts = name.split(RegExp(r'\s+')).where((e) => e.trim().isNotEmpty).toList();
    if (parts.length <= 1) return name.length > 8 ? name.substring(0, 8) : name;
    return '${parts.first}\n${parts.last.length > 7 ? parts.last.substring(0, 7) : parts.last}';
  }
}

class _BarChartPainter extends _BaseChartPainter {
  _BarChartPainter({required this.players, required this.value, required this.label});
  final List<TrackerTrainingPlayerRow> players;
  final double Function(TrackerTrainingPlayerRow) value;
  final String label;

  @override
  void paint(Canvas canvas, Size size) {
    final list = players.take(12).toList();
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(48, 20, size.width - 70, size.height - 78);
    drawGrid(canvas, rect);
    final maxValue = list.map(value).fold<double>(1, math.max);
    final gap = rect.width / list.length;
    final barW = math.min(34.0, gap * .48);
    for (var i = 0; i < list.length; i++) {
      final p = list[i];
      final v = value(p).clamp(0, maxValue);
      final h = rect.height * v / maxValue;
      final x = rect.left + gap * i + (gap - barW) / 2;
      final r = RRect.fromRectAndRadius(Rect.fromLTWH(x, rect.bottom - h, barW, h), const Radius.circular(4));
      canvas.drawRRect(r, Paint()..color = _R.lime);
      text(canvas, v.toStringAsFixed(v >= 10 ? 0 : 1), Offset(x - 2, rect.bottom - h - 16), size: 9, maxWidth: 44, align: TextAlign.center);
      text(canvas, shortName(p.name), Offset(x - gap * .25, rect.bottom + 8), size: 8, color: _R.muted, maxWidth: gap * .9, align: TextAlign.center);
    }
    text(canvas, label, Offset(rect.left, 0), size: 11, color: _R.darkGreen, weight: FontWeight.w900);
  }

  @override
  bool shouldRepaint(covariant _BarChartPainter oldDelegate) => true;
}

class _DualBarChartPainter extends _BaseChartPainter {
  _DualBarChartPainter({required this.players, required this.first, required this.second, required this.firstLabel, required this.secondLabel});
  final List<TrackerTrainingPlayerRow> players;
  final double Function(TrackerTrainingPlayerRow) first;
  final double Function(TrackerTrainingPlayerRow) second;
  final String firstLabel;
  final String secondLabel;

  @override
  void paint(Canvas canvas, Size size) {
    final list = players.take(12).toList();
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(48, 26, size.width - 70, size.height - 86);
    drawGrid(canvas, rect);
    final maxValue = list.expand((p) => [first(p), second(p)]).fold<double>(1, math.max);
    final gap = rect.width / list.length;
    final barW = math.min(16.0, gap * .22);
    for (var i = 0; i < list.length; i++) {
      final p = list[i];
      final x = rect.left + gap * i + (gap - barW * 2 - 4) / 2;
      final h1 = rect.height * first(p) / maxValue;
      final h2 = rect.height * second(p) / maxValue;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, rect.bottom - h1, barW, h1), const Radius.circular(3)), Paint()..color = _R.green);
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x + barW + 4, rect.bottom - h2, barW, h2), const Radius.circular(3)), Paint()..color = _R.red);
      text(canvas, shortName(p.name), Offset(x - gap * .2, rect.bottom + 8), size: 8, color: _R.muted, maxWidth: gap * .9, align: TextAlign.center);
    }
    text(canvas, '$firstLabel / $secondLabel', Offset(rect.left, 0), size: 11, color: _R.darkGreen, weight: FontWeight.w900);
  }

  @override
  bool shouldRepaint(covariant _DualBarChartPainter oldDelegate) => true;
}

class _StackedHrPainter extends _BaseChartPainter {
  _StackedHrPainter({required this.players, required this.distanceMode});
  final List<TrackerTrainingPlayerRow> players;
  final bool distanceMode;

  @override
  void paint(Canvas canvas, Size size) {
    final list = players.take(12).toList();
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(48, 20, size.width - 70, size.height - 78);
    drawGrid(canvas, rect);
    final double maxValue = list
        .map<double>((p) => distanceMode
            ? p.distanceM.toDouble()
            : math.max(1.0, p.duration == '00:00:00' ? 1.0 : 20.0).toDouble())
        .fold<double>(1.0, (previous, value) => math.max(previous, value).toDouble());
    final gap = rect.width / list.length;
    final barW = math.min(34.0, gap * .48);
    for (var i = 0; i < list.length; i++) {
      final p = list[i];
      final zoneSamples = <double>[
        p.hrZ1Samples.toDouble(),
        p.hrZ2Samples.toDouble(),
        p.hrZ3Samples.toDouble(),
        (p.hrZ4Samples + p.hrZ5Samples).toDouble(),
      ];
      final sampleTotal = zoneSamples.fold<double>(0, (a, b) => a + b);
      final total = distanceMode ? math.max(1.0, p.distanceM) : math.max(1.0, sampleTotal > 0 ? sampleTotal : 18.0);
      final zones = sampleTotal > 0
          ? (distanceMode ? zoneSamples.map((z) => total * z / sampleTotal).toList() : zoneSamples)
          : (distanceMode
              ? [total * .42, total * .36, total * .16, total * .06]
              : [total * .38, total * .34, total * .18, total * .10]);
      var y = rect.bottom;
      final x = rect.left + gap * i + (gap - barW) / 2;
      final colors = [_R.lime, const Color(0xFFFFC857), const Color(0xFFF97316), const Color(0xFFE11D48)];
      for (var z = 0; z < zones.length; z++) {
        final h = rect.height * zones[z] / maxValue;
        y -= h;
        canvas.drawRect(Rect.fromLTWH(x, y, barW, h), Paint()..color = colors[z]);
      }
      text(canvas, shortName(p.name), Offset(x - gap * .25, rect.bottom + 8), size: 8, color: _R.muted, maxWidth: gap * .9, align: TextAlign.center);
    }
  }

  @override
  bool shouldRepaint(covariant _StackedHrPainter oldDelegate) => true;
}

class _MicrocyclePainter extends _BaseChartPainter {
  _MicrocyclePainter({required this.points});
  final List<TrackerMicrocyclePoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final list = points;
    if (list.isEmpty) return;
    final rect = Rect.fromLTWH(54, 20, size.width - 82, size.height - 78);
    drawGrid(canvas, rect);
    final maxDist = list.map((p) => p.distanceM).fold<double>(1, math.max);
    final maxLine = list.expand((p) => [p.highSpeedRunningM, p.accDec]).fold<double>(1, math.max);
    final gap = rect.width / list.length;
    final barW = math.min(54.0, gap * .42);
    final hsrPath = Path();
    final accPath = Path();
    for (var i = 0; i < list.length; i++) {
      final p = list[i];
      final x = rect.left + gap * i + gap / 2;
      final barH = rect.height * p.distanceM / maxDist;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x - barW / 2, rect.bottom - barH, barW, barH), const Radius.circular(4)), Paint()..color = _R.lime);
      final y1 = rect.bottom - rect.height * p.highSpeedRunningM / maxLine;
      final y2 = rect.bottom - rect.height * p.accDec / maxLine;
      if (i == 0) {
        hsrPath.moveTo(x, y1);
        accPath.moveTo(x, y2);
      } else {
        hsrPath.lineTo(x, y1);
        accPath.lineTo(x, y2);
      }
      text(canvas, p.label, Offset(x - gap * .45, rect.bottom + 10), size: 9, color: _R.muted, maxWidth: gap * .9, align: TextAlign.center);
    }
    canvas.drawPath(hsrPath, Paint()..color = const Color(0xFFE11D48)..strokeWidth = 2..style = PaintingStyle.stroke);
    canvas.drawPath(accPath, Paint()..color = const Color(0xFF3B82F6)..strokeWidth = 2..style = PaintingStyle.stroke);
    text(canvas, 'Дистанция / высокоинтенсивный бег / ускорения-торможения', Offset(rect.left, 0), size: 11, color: _R.darkGreen, weight: FontWeight.w900);
  }


  @override
  bool shouldRepaint(covariant _MicrocyclePainter oldDelegate) => true;
}

class _PercentPainter extends _BaseChartPainter {
  _PercentPainter({required this.values});
  final List<_NamedValue> values;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Rect.fromLTWH(44, 20, size.width - 70, size.height - 92);
    drawGrid(canvas, rect);
    final list = values;
    final gap = rect.width / list.length;
    final barW = math.min(28.0, gap * .58);
    for (var i = 0; i < list.length; i++) {
      final item = list[i];
      final v = item.value.clamp(0, 100).toDouble();
      final h = rect.height * v / 100;
      final x = rect.left + gap * i + (gap - barW) / 2;
      canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(x, rect.bottom - h, barW, h), const Radius.circular(3)), Paint()..color = const Color(0xFFF9D976));
      text(canvas, '${v.toStringAsFixed(0)}%', Offset(x - 4, rect.bottom - h - 15), size: 9, maxWidth: 40, align: TextAlign.center);
      canvas.save();
      canvas.translate(x + barW / 2, rect.bottom + 8);
      canvas.rotate(-math.pi / 2);
      text(canvas, item.name, const Offset(0, -6), size: 8, color: _R.text, maxWidth: 92);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant _PercentPainter oldDelegate) => true;
}

class _NamedValue {
  const _NamedValue(this.name, this.value);
  final String name;
  final double value;
}

List<_NamedValue> _mdComparison(TrackerTrainingReport report) {
  final s = report.summary;
  return [
    _NamedValue('Дистанция', _percent(s.averageDistanceM, 7792)),
    _NamedValue('Метры/мин', _percent(s.distancePerMin, 116)),
    _NamedValue('Макс скорость', _percent(s.maxSpeedKmh, 29)),
    _NamedValue('Ускорения', _percent(s.accelerationCount.toDouble(), 20)),
    _NamedValue('Торможения', _percent(s.decelerationCount.toDouble(), 27)),
    _NamedValue('УСК+ТОР', _percent(s.accDecPerMin, 3)),
    _NamedValue('Взрывные', _percent(s.explosiveActions.toDouble(), 25)),
    _NamedValue('V3 бег', _percent(report.players.fold<double>(0, (a, p) => a + p.v3RunM) / math.max(1, report.players.length), 1228)),
    _NamedValue('V4 ВСБ', _percent(report.players.fold<double>(0, (a, p) => a + p.v4HsrM) / math.max(1, report.players.length), 426)),
    _NamedValue('V5 спринт', _percent(report.players.fold<double>(0, (a, p) => a + p.v5SprintM) / math.max(1, report.players.length), 100)),
    _NamedValue('Спринты', _percent(report.players.fold<double>(0, (a, p) => a + p.sprintCount) / math.max(1, report.players.length), 5)),
    _NamedValue('V4+V5', _percent(s.highSpeedDistanceM, 526)),
  ];
}

double _percent(double value, double benchmark) => benchmark <= 0 ? 0 : (value / benchmark * 100).clamp(0, 140).toDouble();

TrackerTrainingPlayerRow _avgRow(List<TrackerTrainingPlayerRow> rows) {
  final n = rows.length.toDouble();
  double avg(double Function(TrackerTrainingPlayerRow p) get) => rows.fold<double>(0, (a, p) => a + get(p)) / math.max(1, n);
  int avgi(int Function(TrackerTrainingPlayerRow p) get) => (rows.fold<int>(0, (a, p) => a + get(p)) / math.max(1, n)).round();
  return TrackerTrainingPlayerRow(
    name: 'СРЕДНЕЕ',
    duration: rows.isEmpty ? '00:00:00' : rows.first.duration,
    distanceM: avg((p) => p.distanceM),
    metersPerMin: avg((p) => p.metersPerMin),
    maxSpeedKmh: avg((p) => p.maxSpeedKmh),
    avgSpeedKmh: avg((p) => p.avgSpeedKmh),
    accelerations: avgi((p) => p.accelerations),
    decelerations: avgi((p) => p.decelerations),
    accDecPerMin: avg((p) => p.accDecPerMin),
    explosiveActions: avgi((p) => p.explosiveActions),
    v3RunM: avg((p) => p.v3RunM),
    v4HsrM: avg((p) => p.v4HsrM),
    v5SprintM: avg((p) => p.v5SprintM),
    sprintCount: avgi((p) => p.sprintCount),
    highSpeedWorkM: avg((p) => p.highSpeedWorkM),
    highSpeedActions: avgi((p) => p.highSpeedActions),
    playerLoad: avg((p) => p.playerLoad),
    heartRateMaxPercent: avg((p) => p.heartRateMaxPercent),
    hrExertion: avg((p) => p.hrExertion),
    pointsCount: avgi((p) => p.pointsCount),
    sessionsCount: avgi((p) => p.sessionsCount),
    hasMovement: rows.any((p) => p.hasMovement),
  );
}

TableRow _tableRow(List<String> values, {bool header = false}) {
  return TableRow(
    decoration: BoxDecoration(color: header ? const Color(0xFFE5E7EB) : Colors.white),
    children: values.map((v) => _cell(v, bold: header)).toList(),
  );
}

Widget _cell(String text, {bool bold = false, TextAlign align = TextAlign.center}) {
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
    child: Text(text, textAlign: align, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(color: _R.text, fontSize: 9.5, fontWeight: bold ? FontWeight.w800 : FontWeight.w600)),
  );
}

Widget _playerCell(TrackerTrainingPlayerRow p, bool average) {
  if (average) return _cell(p.name, bold: true, align: TextAlign.left);
  return Padding(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
    child: Row(children: [
      _PlayerAvatar(player: p, size: 28),
      const SizedBox(width: 7),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.text, fontSize: 9.8, fontWeight: FontWeight.w900)),
        Text([if (p.number.isNotEmpty) '#${p.number}', if (p.position.isNotEmpty) p.position, if (p.deviceName.isNotEmpty) p.deviceName].join(' · '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _R.muted, fontSize: 8.1, fontWeight: FontWeight.w700)),
      ])),
    ]),
  );
}

Widget _heatCell(String text, double value, double max) {
  final ratio = (value / max).clamp(0, 1).toDouble();
  final color = ratio > .82 ? const Color(0xFFEF4444).withOpacity(.34) : ratio > .58 ? const Color(0xFFFACC15).withOpacity(.50) : const Color(0xFF22C55E).withOpacity(.20 + .25 * ratio);
  return Container(color: color, child: _cell(text, bold: ratio > .82));
}

Widget _barCell(String text, double value, double max, Color color) {
  final ratio = (value / max).clamp(0, 1).toDouble();
  return Stack(children: [
    Positioned.fill(child: FractionallySizedBox(widthFactor: ratio, alignment: Alignment.centerLeft, child: Container(color: color.withOpacity(.45)))),
    _cell(text),
  ]);
}

class _EmptyBlock extends StatelessWidget {
  const _EmptyBlock(this.text);
  final String text;
  @override
  Widget build(BuildContext context) => Container(height: 92, alignment: Alignment.center, child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _R.muted, fontSize: 10.5, fontWeight: FontWeight.w700)));
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.error, required this.onRetry});
  final String error;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 560),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: _R.border)),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.warning_amber_rounded, color: _R.red, size: 44),
          const SizedBox(height: 10),
          Text(error, textAlign: TextAlign.center, style: const TextStyle(color: _R.text, fontWeight: FontWeight.w800)),
          const SizedBox(height: 12),
          FilledButton.icon(onPressed: onRetry, icon: const Icon(Icons.refresh_rounded), label: const Text('Повторить')),
        ]),
      ),
    );
  }
}

class _R {
  static const bg = Color(0xFFF6F7F9);
  static const panel = Color(0xFFFFFFFF);
  static const soft = Color(0xFFF6F7F9);
  static const border = Color(0xFFE5E7EB);
  static const text = Color(0xFF111827);
  static const graphite = Color(0xFF374151);
  static const muted = Color(0xFF667085);
  static const darkGreen = Color(0xFF0B4F2D);
  static const greenDark = Color(0xFF067A46);
  static const green = Color(0xFF00A750);
  static const greenLine = Color(0xFFCBEEDD);
  static const softGreen = Color(0xFFEAF8F0);
  static const lightGreen = Color(0xFFEAF8F0);
  static const lime = Color(0xFFA3E635);
  static const red = Color(0xFFEF4444);
}
