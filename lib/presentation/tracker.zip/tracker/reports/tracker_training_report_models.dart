class TrackerTrainingReport {
  final int sessionId;
  final List<int> sessionIds;
  final String title;
  final String dateLabel;
  final int teamId;
  final String teamName;
  final String teamLogoUrl;
  final String opponent;
  final String durationLabel;
  final int playersCount;
  final int pointsCount;
  final bool hasData;
  final String dataStatus;
  final TrackerReportSummary summary;
  final List<TrackerExercisePeriod> periods;
  final List<TrackerMicrocyclePoint> microcycle;
  final List<TrackerTrainingPlayerRow> players;
  final List<TrackerTrainingPlayerRow> diagnosticPlayers;
  final List<TrackerReportPoint> routePoints;
  final List<TrackerReportPoint> heatmapPoints;
  final List<TrackerSpeedZone> speedZones;
  final List<TrackerHeartRatePoint> heartRateTimeline;

  const TrackerTrainingReport({
    required this.sessionId,
    this.sessionIds = const [],
    required this.title,
    required this.dateLabel,
    this.teamId = 0,
    required this.teamName,
    this.teamLogoUrl = '',
    required this.opponent,
    required this.durationLabel,
    required this.playersCount,
    this.pointsCount = 0,
    this.hasData = false,
    this.dataStatus = '',
    required this.summary,
    required this.periods,
    required this.microcycle,
    required this.players,
    this.diagnosticPlayers = const [],
    this.routePoints = const [],
    this.heatmapPoints = const [],
    this.speedZones = const [],
    this.heartRateTimeline = const [],
  });

  factory TrackerTrainingReport.fromJson(Map<String, dynamic> json) {
    return TrackerTrainingReport(
      sessionId: _i(json['session_id'] ?? json['id']),
      sessionIds: (json['session_ids'] as List? ?? const []).map((e) => _i(e)).where((e) => e > 0).toList(),
      title: '${json['title'] ?? 'Отчёт по тренировке'}',
      dateLabel: '${json['date_label'] ?? json['date'] ?? ''}',
      teamId: _i(json['team_id']),
      teamName: '${json['team_name'] ?? ''}',
      teamLogoUrl: _s(json['team_logo_url'] ?? json['team_logo'] ?? json['logo_url']),
      opponent: '${json['opponent'] ?? ''}',
      durationLabel: '${json['duration_label'] ?? '00:00:00'}',
      playersCount: _i(json['players_count']),
      pointsCount: _i(json['points_count'] ?? json['gps_points_count']),
      hasData: _b(json['has_data']),
      dataStatus: _s(json['data_status']),
      summary: TrackerReportSummary.fromJson(Map<String, dynamic>.from(json['summary'] as Map? ?? const {})),
      periods: (json['periods'] as List? ?? const [])
          .map((e) => TrackerExercisePeriod.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      microcycle: (json['microcycle'] as List? ?? const [])
          .map((e) => TrackerMicrocyclePoint.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      players: (json['players'] as List? ?? const [])
          .map((e) => TrackerTrainingPlayerRow.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      diagnosticPlayers: (json['diagnostic_players'] as List? ?? const [])
          .map((e) => TrackerTrainingPlayerRow.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      routePoints: (json['route_points'] as List? ?? const [])
          .map((e) => TrackerReportPoint.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      heatmapPoints: (json['heatmap_points'] as List? ?? const [])
          .map((e) => TrackerReportPoint.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      speedZones: (json['speed_zones'] as List? ?? const [])
          .map((e) => TrackerSpeedZone.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      heartRateTimeline: _hrPointList(json['heart_rate_timeline'] ?? json['hr_timeline'] ?? json['heartRateTimeline']),
    );
  }

  factory TrackerTrainingReport.empty({required int sessionId, required String teamName}) {
    return TrackerTrainingReport(
      sessionId: sessionId,
      sessionIds: sessionId > 0 ? [sessionId] : const [],
      title: 'Отчёт по тренировке',
      dateLabel: '',
      teamName: teamName,
      opponent: '',
      durationLabel: '00:00:00',
      playersCount: 0,
      pointsCount: 0,
      hasData: false,
      summary: const TrackerReportSummary(),
      periods: const [],
      microcycle: const [],
      players: const [],
      diagnosticPlayers: const [],
      routePoints: const [],
      heatmapPoints: const [],
      speedZones: const [],
      heartRateTimeline: const [],
    );
  }
}

class TrackerReportSummary {
  final double averageDistanceM;
  final double totalDistanceM;
  final double highSpeedDistanceM;
  final double playerLoad;
  final double accDecPerMin;
  final double maxSpeedKmh;
  final double avgSpeedKmh;
  final double distancePerMin;
  final int accelerationCount;
  final int decelerationCount;
  final int explosiveActions;
  final int sprintCount;
  final double sprintDistanceM;
  final double v3RunM;
  final double v4HsrM;
  final double v5SprintM;
  final double heartRateAvgBpm;
  final double heartRateMaxBpm;
  final int heartRateSamplesCount;

  const TrackerReportSummary({
    this.averageDistanceM = 0,
    this.totalDistanceM = 0,
    this.highSpeedDistanceM = 0,
    this.playerLoad = 0,
    this.accDecPerMin = 0,
    this.maxSpeedKmh = 0,
    this.avgSpeedKmh = 0,
    this.distancePerMin = 0,
    this.accelerationCount = 0,
    this.decelerationCount = 0,
    this.explosiveActions = 0,
    this.sprintCount = 0,
    this.sprintDistanceM = 0,
    this.v3RunM = 0,
    this.v4HsrM = 0,
    this.v5SprintM = 0,
    this.heartRateAvgBpm = 0,
    this.heartRateMaxBpm = 0,
    this.heartRateSamplesCount = 0,
  });

  factory TrackerReportSummary.fromJson(Map<String, dynamic> json) {
    return TrackerReportSummary(
      averageDistanceM: _d(json['average_distance_m'] ?? json['avg_distance_m']),
      totalDistanceM: _d(json['total_distance_m'] ?? json['distance_m']),
      highSpeedDistanceM: _d(json['high_speed_distance_m'] ?? json['hsr_m']),
      playerLoad: _d(json['player_load'] ?? json['load_score']),
      accDecPerMin: _d(json['acc_dec_per_min']),
      maxSpeedKmh: _d(json['max_speed_kmh']),
      avgSpeedKmh: _d(json['avg_speed_kmh'] ?? json['average_speed_kmh']),
      distancePerMin: _d(json['distance_per_min_m'] ?? json['meters_per_min']),
      accelerationCount: _i(json['acceleration_count'] ?? json['accelerations']),
      decelerationCount: _i(json['deceleration_count'] ?? json['decelerations']),
      explosiveActions: _i(json['explosive_actions']),
      sprintCount: _i(json['sprint_count']),
      sprintDistanceM: _d(json['sprint_distance_m']),
      v3RunM: _d(json['v3_run_m']),
      v4HsrM: _d(json['v4_hsr_m'] ?? json['v4_vsb_m']),
      v5SprintM: _d(json['v5_sprint_m'] ?? json['sprint_distance_m']),
      heartRateAvgBpm: _d(json['heart_rate_avg_bpm'] ?? json['avg_bpm']),
      heartRateMaxBpm: _d(json['heart_rate_max_bpm'] ?? json['max_bpm']),
      heartRateSamplesCount: _i(json['heart_rate_samples_count'] ?? json['samples_count']),
    );
  }
}

class TrackerExercisePeriod {
  final String title;
  final String startLabel;
  final String endLabel;
  final int durationSec;
  final double distanceM;
  final double highSpeedDistanceM;
  final int accDecCount;

  const TrackerExercisePeriod({
    required this.title,
    required this.startLabel,
    required this.endLabel,
    required this.durationSec,
    this.distanceM = 0,
    this.highSpeedDistanceM = 0,
    this.accDecCount = 0,
  });

  factory TrackerExercisePeriod.fromJson(Map<String, dynamic> json) {
    return TrackerExercisePeriod(
      title: '${json['title'] ?? json['name'] ?? 'Период'}',
      startLabel: '${json['start_label'] ?? json['start_time'] ?? ''}',
      endLabel: '${json['end_label'] ?? json['end_time'] ?? ''}',
      durationSec: _i(json['duration_sec']),
      distanceM: _d(json['distance_m']),
      highSpeedDistanceM: _d(json['high_speed_distance_m']),
      accDecCount: _i(json['acc_dec_count']),
    );
  }
}

class TrackerMicrocyclePoint {
  final String label;
  final double distanceM;
  final double highSpeedRunningM;
  final double accDec;

  const TrackerMicrocyclePoint({
    required this.label,
    required this.distanceM,
    required this.highSpeedRunningM,
    required this.accDec,
  });

  factory TrackerMicrocyclePoint.fromJson(Map<String, dynamic> json) {
    return TrackerMicrocyclePoint(
      label: '${json['label'] ?? json['date'] ?? ''}',
      distanceM: _d(json['distance_m']),
      highSpeedRunningM: _d(json['high_speed_running_m'] ?? json['hsr_m']),
      accDec: _d(json['acc_dec'] ?? json['accdec']),
    );
  }
}

class TrackerTrainingPlayerRow {
  final int? playerId;
  final String name;
  final String avatarUrl;
  final String number;
  final String position;
  final String deviceName;
  final String trackerUid;
  final String duration;
  final double distanceM;
  final double metersPerMin;
  final double maxSpeedKmh;
  final double avgSpeedKmh;
  final int accelerations;
  final int decelerations;
  final double accDecPerMin;
  final int explosiveActions;
  final double v3RunM;
  final double v4HsrM;
  final double v5SprintM;
  final int sprintCount;
  final double highSpeedWorkM;
  final int highSpeedActions;
  final double playerLoad;
  final double heartRateMaxPercent;
  final double hrExertion;
  final double heartRateAvgBpm;
  final double heartRateMaxBpm;
  final double heartRateMinBpm;
  final int heartRateSamplesCount;
  final int hrZ1Samples;
  final int hrZ2Samples;
  final int hrZ3Samples;
  final int hrZ4Samples;
  final int hrZ5Samples;
  final int pointsCount;
  final int sessionsCount;
  final bool hasMovement;

  const TrackerTrainingPlayerRow({
    this.playerId,
    required this.name,
    this.avatarUrl = '',
    this.number = '',
    this.position = '',
    this.deviceName = '',
    this.trackerUid = '',
    required this.duration,
    required this.distanceM,
    required this.metersPerMin,
    required this.maxSpeedKmh,
    this.avgSpeedKmh = 0,
    required this.accelerations,
    required this.decelerations,
    required this.accDecPerMin,
    required this.explosiveActions,
    required this.v3RunM,
    required this.v4HsrM,
    required this.v5SprintM,
    required this.sprintCount,
    required this.highSpeedWorkM,
    required this.highSpeedActions,
    required this.playerLoad,
    required this.heartRateMaxPercent,
    required this.hrExertion,
    this.heartRateAvgBpm = 0,
    this.heartRateMaxBpm = 0,
    this.heartRateMinBpm = 0,
    this.heartRateSamplesCount = 0,
    this.hrZ1Samples = 0,
    this.hrZ2Samples = 0,
    this.hrZ3Samples = 0,
    this.hrZ4Samples = 0,
    this.hrZ5Samples = 0,
    this.pointsCount = 0,
    this.sessionsCount = 0,
    this.hasMovement = false,
  });

  factory TrackerTrainingPlayerRow.fromJson(Map<String, dynamic> json) {
    return TrackerTrainingPlayerRow(
      playerId: int.tryParse('${json['player_id'] ?? ''}'),
      name: '${json['name'] ?? json['player_name'] ?? 'Игрок'}',
      avatarUrl: _s(json['avatar_url'] ?? json['avatar'] ?? json['photo'] ?? json['image']),
      number: _s(json['number'] ?? json['shirt_number'] ?? json['game_number']),
      position: _s(json['position'] ?? json['role'] ?? json['amplua']),
      deviceName: _s(json['device_name'] ?? json['tracker_name']),
      trackerUid: _s(json['tracker_uid'] ?? json['device_uid'] ?? json['device_mac']),
      duration: '${json['duration'] ?? json['duration_label'] ?? '00:00:00'}',
      distanceM: _d(json['distance_m']),
      metersPerMin: _d(json['meters_per_min'] ?? json['distance_per_min_m']),
      maxSpeedKmh: _d(json['max_speed_kmh']),
      avgSpeedKmh: _d(json['avg_speed_kmh'] ?? json['average_speed_kmh']),
      accelerations: _i(json['accelerations'] ?? json['acceleration_count']),
      decelerations: _i(json['decelerations'] ?? json['deceleration_count']),
      accDecPerMin: _d(json['acc_dec_per_min']),
      explosiveActions: _i(json['explosive_actions']),
      v3RunM: _d(json['v3_run_m']),
      v4HsrM: _d(json['v4_hsr_m'] ?? json['v4_vsb_m']),
      v5SprintM: _d(json['v5_sprint_m'] ?? json['sprint_distance_m']),
      sprintCount: _i(json['sprint_count']),
      highSpeedWorkM: _d(json['high_speed_work_m'] ?? json['high_speed_distance_m']),
      highSpeedActions: _i(json['high_speed_actions']),
      playerLoad: _d(json['player_load'] ?? json['load_score']),
      heartRateMaxPercent: _d(json['heart_rate_max_percent']),
      hrExertion: _d(json['hr_exertion']),
      heartRateAvgBpm: _d(json['heart_rate_avg_bpm'] ?? json['avg_bpm']),
      heartRateMaxBpm: _d(json['heart_rate_max_bpm'] ?? json['max_bpm']),
      heartRateMinBpm: _d(json['heart_rate_min_bpm'] ?? json['min_bpm']),
      heartRateSamplesCount: _i(json['heart_rate_samples_count'] ?? json['samples_count']),
      hrZ1Samples: _i(json['hr_z1_samples'] ?? json['z1']),
      hrZ2Samples: _i(json['hr_z2_samples'] ?? json['z2']),
      hrZ3Samples: _i(json['hr_z3_samples'] ?? json['z3']),
      hrZ4Samples: _i(json['hr_z4_samples'] ?? json['z4']),
      hrZ5Samples: _i(json['hr_z5_samples'] ?? json['z5']),
      pointsCount: _i(json['points_count'] ?? json['gps_points_count']),
      sessionsCount: _i(json['sessions_count']),
      hasMovement: _b(json['has_movement']),
    );
  }
}

class TrackerReportPoint {
  final int? playerId;
  final String playerName;
  final double x;
  final double y;
  final double speedKmh;
  final double value;
  final double distanceM;
  final int timeMs;
  final bool breakBefore;

  const TrackerReportPoint({
    this.playerId,
    this.playerName = '',
    required this.x,
    required this.y,
    this.speedKmh = 0,
    this.value = 1,
    this.distanceM = 0,
    this.timeMs = 0,
    this.breakBefore = false,
  });

  factory TrackerReportPoint.fromJson(Map<String, dynamic> json) {
    return TrackerReportPoint(
      playerId: int.tryParse('${json['player_id'] ?? ''}'),
      playerName: _s(json['player_name'] ?? json['name']),
      x: _pointCoord(json, isY: false),
      y: _pointCoord(json, isY: true),
      speedKmh: _d(json['speed_kmh'] ?? json['speed']),
      value: _d(json['value'] ?? json['intensity'] ?? json['count'], 1),
      distanceM: _d(json['distance_m'] ?? json['total_distance_m']),
      timeMs: _i(json['time_ms']),
      breakBefore: _b(json['break_before']),
    );
  }
}

class TrackerSpeedZone {
  final String label;
  final double fromKmh;
  final double toKmh;
  final double distanceM;
  final int pointsCount;

  const TrackerSpeedZone({
    required this.label,
    required this.fromKmh,
    required this.toKmh,
    required this.distanceM,
    required this.pointsCount,
  });

  factory TrackerSpeedZone.fromJson(Map<String, dynamic> json) {
    return TrackerSpeedZone(
      label: _s(json['label'] ?? json['name']),
      fromKmh: _d(json['from_kmh']),
      toKmh: _d(json['to_kmh']),
      distanceM: _d(json['distance_m']),
      pointsCount: _i(json['points_count']),
    );
  }
}

class TrackerHeartRatePoint {
  final int? playerId;
  final String playerName;
  final int timeMs;
  final int minute;
  final int bpm;
  final double hrLoad;
  final String zone;
  final double speedKmh;

  const TrackerHeartRatePoint({
    this.playerId,
    this.playerName = '',
    required this.timeMs,
    required this.minute,
    required this.bpm,
    this.hrLoad = 0,
    this.zone = '',
    this.speedKmh = 0,
  });

  factory TrackerHeartRatePoint.fromJson(Map<String, dynamic> json) {
    final measured = _s(json['measured_at'] ?? json['created_at'] ?? json['time']);
    final parsed = measured.isEmpty ? null : DateTime.tryParse(measured.replaceFirst(' ', 'T'));
    final rawTimeMs = _i(json['time_ms'] ?? json['timestamp_ms'] ?? json['ts_ms']);
    final timeMs = rawTimeMs > 0 ? rawTimeMs : (parsed == null ? 0 : parsed.millisecondsSinceEpoch);
    final minute = _i(json['minute'] ?? json['minute_index'] ?? json['t_min']);
    final bpm = _i(json['bpm'] ?? json['heart_rate'] ?? json['hr']);
    return TrackerHeartRatePoint(
      playerId: int.tryParse('${json['player_id'] ?? ''}'),
      playerName: _s(json['player_name'] ?? json['name']),
      timeMs: timeMs,
      minute: minute,
      bpm: bpm,
      hrLoad: _d(json['hr_load'] ?? json['load'] ?? json['hr_exertion']),
      zone: _s(json['hr_zone'] ?? json['zone']).toLowerCase(),
      speedKmh: _d(json['speed_kmh'] ?? json['speed']),
    );
  }
}

List<TrackerHeartRatePoint> _hrPointList(dynamic raw) {
  dynamic list = raw;
  if (list is Map) list = list['items'] ?? list['points'] ?? list['timeline'] ?? const [];
  if (list is! List) return const <TrackerHeartRatePoint>[];
  final out = <TrackerHeartRatePoint>[];
  for (final e in list) {
    if (e is Map) {
      final point = TrackerHeartRatePoint.fromJson(Map<String, dynamic>.from(e));
      if (point.bpm > 0) out.add(point);
    }
  }
  out.sort((a, b) {
    final ta = a.timeMs > 0 ? a.timeMs : a.minute;
    final tb = b.timeMs > 0 ? b.timeMs : b.minute;
    return ta.compareTo(tb);
  });
  return out;
}


double _pointCoord(Map<String, dynamic> json, {required bool isY}) {
  // Отчётный API теперь отдаёт x/y уже нормализованными (0..1).
  // Но старые серверные файлы могли отдавать x/y в метрах, из-за этого все точки
  // схлопывались в угол после clamp(0..1). Поэтому нормализованными считаем
  // только значения около диапазона 0..1; большие значения трактуем как метры поля.
  final normalized = json[isY ? 'ny' : 'nx'] ?? json[isY ? 'field_y_norm' : 'field_x_norm'];
  if (normalized != null) return _d(normalized).clamp(0.0, 1.0).toDouble();

  final direct = json[isY ? 'y' : 'x'];
  if (direct != null) {
    final v = _d(direct);
    if (v >= -0.05 && v <= 1.05) return v.clamp(0.0, 1.0).toDouble();
    final denom = isY ? 68.0 : 105.0;
    return (v / denom).clamp(0.0, 1.0).toDouble();
  }

  final meters = json[isY ? 'field_y_m' : 'field_x_m'] ?? json[isY ? 'field_y' : 'field_x'] ?? json[isY ? 'local_y' : 'local_x'];
  final v = _d(meters);
  if (v.abs() <= 1.25) return v.clamp(0.0, 1.0).toDouble();
  final denom = isY ? 68.0 : 105.0;
  return (v / denom).clamp(0.0, 1.0).toDouble();
}

String _s(dynamic value) => value == null ? '' : '$value'.trim();

bool _b(dynamic value) {
  if (value is bool) return value;
  if (value is num) return value != 0;
  final s = '$value'.toLowerCase().trim();
  return s == 'true' || s == '1' || s == 'yes' || s == 'ok';
}

double _d(dynamic value, [double fallback = 0]) {
  if (value is num) return value.toDouble();
  return double.tryParse('$value'.replaceAll(',', '.')) ?? fallback;
}

int _i(dynamic value, [int fallback = 0]) {
  if (value is int) return value;
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? fallback;
}
