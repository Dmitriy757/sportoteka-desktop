import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';
import 'package:url_launcher/url_launcher.dart';

class TrackerExportViewer extends StatelessWidget {
  const TrackerExportViewer({super.key, required this.uri});

  final Uri uri;

  Future<void> _openExternal(BuildContext context) async {
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Не удалось открыть отчёт: $uri')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final url = uri.toString().toLowerCase();
    final isPrintableSportotekaReport = url.contains('export_training_report_pdf');
    final isPdf = !isPrintableSportotekaReport && (url.endsWith('.pdf') || url.contains('format=pdf') || url.contains('template=clean'));

    if (isPrintableSportotekaReport) {
      return Container(
        color: const Color(0xFFFFFFFF),
        padding: const EdgeInsets.all(18),
        alignment: Alignment.center,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 620),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(color: const Color(0xFF00A750), borderRadius: BorderRadius.circular(18)),
                child: const Center(child: Text('S', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.w900))),
              ),
              const SizedBox(height: 16),
              const Text('Спортотека GPS отчёт', textAlign: TextAlign.center, style: TextStyle(color: Color(0xFF111827), fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text(
                'Откройте отчёт в браузере: внутри будут шапка Спортотека, таблицы игроков, график скорости, карта активности, тепловая карта и аналитические графики по выбранной сессии.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF667085), fontSize: 12, height: 1.35, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 18),
              ElevatedButton.icon(
                onPressed: () => _openExternal(context),
                icon: const Icon(Icons.open_in_new_rounded),
                label: const Text('Открыть отчёт'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00A750), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 13), textStyle: const TextStyle(fontWeight: FontWeight.w900)),
              ),
              const SizedBox(height: 12),
              SelectableText(uri.toString(), textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFF667085), fontSize: 10, fontWeight: FontWeight.w600)),
            ],
          ),
        ),
      );
    }

    if (!isPdf) {
      return Container(
        color: const Color(0xFFF7F8FA),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(18),
        child: SelectableText(
          uri.toString(),
          textAlign: TextAlign.center,
          style: const TextStyle(color: Color(0xFF374151), fontSize: 11, fontWeight: FontWeight.w600),
        ),
      );
    }

    return ColoredBox(
      color: Colors.white,
      child: SfPdfViewer.network(
        uri.toString(),
        canShowScrollHead: true,
        canShowScrollStatus: true,
        canShowPaginationDialog: false,
      ),
    );
  }
}
