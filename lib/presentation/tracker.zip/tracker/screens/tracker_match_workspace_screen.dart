import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;
import 'dart:io';

import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../models/action_tracker_protocol.dart';
import '../models/tracker_pro_models.dart';
import '../services/action_tracker_ble_service.dart';
import '../services/polar_heart_rate_ble_service.dart';
import '../services/tracker_permissions.dart';
import '../services/tracker_pro_api.dart';
import '../services/tracker_live_api.dart';
import '../tracker_live_panel.dart';
import '../tracker_player_activity_screen.dart';
import '../widgets/tracker_pro_analytics_panel.dart';
import '../widgets/tracker_action_analytics_suite.dart';
import '../reports/tracker_training_report_screen.dart';

enum TrackerWorkspaceSection { dashboard, live, analytics, activity, sessions, devices, field, settings, debug }

List<TrackerWorkspaceSection> get _trackerVisibleSections => TrackerWorkspaceSection.values
    .where((section) => section != TrackerWorkspaceSection.activity && section != TrackerWorkspaceSection.debug)
    .toList(growable: false);

enum _TrackerExitAction { stay, pauseAndMinimize, saveAndExit, exitWithoutSaving }
enum _TrackerLiveSwitchAction { stayInLive, keepRunning, saveAndSwitch }

class TrackerMatchWorkspaceScreen extends StatefulWidget {
  const TrackerMatchWorkspaceScreen({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teamId,
    required this.teamName,
    required this.userId,
    this.initialPlayers = const [],
    this.embeddedInClubWorkspace = false,
  });

  final int clubId;
  final String clubName;
  final int teamId;
  final String teamName;
  final int userId;
  final List<Map<String, dynamic>> initialPlayers;

  /// true — экран трекера открыт внутри Club Workspace.
  /// В этом режиме внешний Windows-подобный taskbar клуба остаётся на месте,
  /// а разделы трекера показываются как вкладки отдельной «программы».
  final bool embeddedInClubWorkspace;

  @override
  State<TrackerMatchWorkspaceScreen> createState() => _TrackerMatchWorkspaceScreenState();
}

class _TrackerMatchWorkspaceScreenState extends State<TrackerMatchWorkspaceScreen> {
  late final ActionTrackerBleService _ble;
  late final HeartRateBleService _heart;
  late final TrackerProApi _api;
  late final TrackerLiveApi _liveApi;

  final List<String> _logs = <String>[];
  final List<ActionTrackerRecord> _records = <ActionTrackerRecord>[];
  final List<ActionTrackerGpsPoint> _points = <ActionTrackerGpsPoint>[];
  final Set<String> _offlineAutoSyncedRecordKeys = <String>{};
  final List<ActionTrackerGpsPoint> _calibrationCorners = <ActionTrackerGpsPoint>[];

  List<TrackerPlayerOption> _players = <TrackerPlayerOption>[];
  List<TrackerDeviceModel> _savedDevices = <TrackerDeviceModel>[];
  List<TrackerFieldModel> _fields = <TrackerFieldModel>[];

  TrackerWorkspaceSection _section = TrackerWorkspaceSection.dashboard;
  late final PageController _mobileSectionController;
  TrackerPlayerOption? _selectedPlayer;
  TrackerFieldModel? _selectedField;
  ActionTrackerDevice? _connected;
  HeartRateBleDevice? _connectedHeart;
  ActionTrackerBatteryState? _battery;
  ActionTrackerRecord? _selectedRecord;
  TrackerSessionModel? _selectedReportSession;

  StreamSubscription<ActionTrackerParseResult>? _dataSub;
  StreamSubscription<String>? _logSub;
  StreamSubscription<HeartRateSample>? _heartSub;
  StreamSubscription<String>? _heartLogSub;

  bool _loading = true;
  bool _scanning = false;
  bool _scanningHeart = false;
  bool _connecting = false;
  bool _connectingHeart = false;
  bool _savingRecord = false;
  bool _offlineAutoSyncInProgress = false;
  bool _offlineAutoSaveAfterTransfer = false;
  String? _offlineAutoSyncKey;
  String _trackerRecordingStatus = 'запись на трекере не проверялась';
  DateTime? _lastRecordListAt;
  bool _liveRunning = false;
  int? _activeLiveSessionId;

  bool _calibrationCapturing = false;
  int? _calibrationCapturingIndex;
  int _calibrationFlashSeed = 0;
  String? _calibrationFlashLabel;
  Timer? _calibrationFlashTimer;

  ActionTrackerGpsPoint? _lastWorkspaceGpsPoint;
  DateTime? _lastWorkspaceGpsAt;
  DateTime? _lastTrackerPacketAt;
  DateTime? _lastRemoteRxLogAt;
  String _lastWorkspaceRx = 'нет пакетов';
  String _lastWorkspaceGps = 'нет GPS';
  String _lastRemoteDebug = 'debug ещё не отправлялся';
  final List<Map<String, dynamic>> _remoteDebugLogs = <Map<String, dynamic>>[];
  final List<_RemoteTrackerPresence> _remoteConnectedTrackers = <_RemoteTrackerPresence>[];
  Timer? _remoteDebugPollTimer;
  Timer? _remoteStatusHeartbeatTimer;
  bool _remoteDebugLoading = false;
  bool _remoteConsoleAutoRefresh = true;
  bool _hideSavedDevices = true;
  DateTime? _lastRemoteConsoleLoadAt;

  final Map<String, int?> _heartDevicePlayerIds = <String, int?>{};
  final Map<int, HeartRateSample> _latestHeartByPlayerId = <int, HeartRateSample>{};
  final Map<String, DateTime> _lastHeartSampleUploadAt = <String, DateTime>{};
  final Set<String> _heartSampleUploadInFlight = <String>{};
  HeartRateSample? _latestHeartSample;
  String? _selectedHeartDeviceId;

  int _liveStartRequestSignal = 0;
  int _livePauseRequestSignal = 0;
  int _liveStopRequestSignal = 0;
  int _liveExitWithoutSaveRequestSignal = 0;
  bool _trackerWindowMinimized = false;
  bool _trackerWindowMaximized = false;
  bool _trackerSideCollapsed = false;

  @override
  void initState() {
    super.initState();
    final initialSectionIndex = _trackerVisibleSections.indexOf(_section);
    _mobileSectionController = PageController(initialPage: initialSectionIndex < 0 ? 0 : initialSectionIndex);
    _api = TrackerProApi();
    _liveApi = TrackerLiveApi();
    _ble = ActionTrackerBleService();
    _heart = HeartRateBleService();
    _players = widget.initialPlayers.map(TrackerPlayerOption.fromJson).where((p) => p.id > 0).toList();
    _logs.insert(0, '[TEAM] init → ${widget.teamName} (${widget.teamId})');
    _init();
  }

  String _localClockLabel(DateTime dt) {
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
  }

  void _pushLocalLog(String message, {bool dedupe = false}) {
    final clean = message.trim();
    if (clean.isEmpty) return;

    final duplicate = dedupe &&
        _logs.isNotEmpty &&
        _logs.first.replaceFirst(RegExp(r'^\[[^\]]+\]\s*'), '').trim() == clean;
    if (duplicate) return;

    void mutate() {
      _logs.insert(0, '[${_localClockLabel(DateTime.now())}] $clean');
      if (_logs.length > 260) _logs.removeRange(260, _logs.length);
    }

    if (mounted) {
      setState(mutate);
    } else {
      mutate();
    }
  }


  @override
  void didUpdateWidget(covariant TrackerMatchWorkspaceScreen oldWidget) {
    super.didUpdateWidget(oldWidget);

    if (oldWidget.teamId != widget.teamId || oldWidget.clubId != widget.clubId) {
      _resetTeamRuntimeState();

      if (widget.initialPlayers.isNotEmpty) {
        _players = widget.initialPlayers
            .map(TrackerPlayerOption.fromJson)
            .where((p) => p.id > 0)
            .toList();
      }

      _loadServerData();
    }
  }

  void _resetTeamRuntimeState() {
    setState(() {
      _loading = true;
      _records.clear();
      _points.clear();
      _calibrationCorners.clear();
      _calibrationCapturing = false;
      _calibrationCapturingIndex = null;
      _calibrationFlashLabel = null;
      _lastWorkspaceGpsPoint = null;
      _lastWorkspaceGpsAt = null;
      _lastTrackerPacketAt = null;
      _lastRemoteRxLogAt = null;
      _lastWorkspaceRx = 'нет пакетов';
      _lastWorkspaceGps = 'нет GPS';
      _lastRemoteDebug = 'debug ещё не отправлялся';
      _remoteDebugLogs.clear();
      _remoteConnectedTrackers.clear();
      _lastRemoteConsoleLoadAt = null;
      _savedDevices.clear();
      _fields.clear();
      _selectedPlayer = null;
      _selectedField = null;
      _selectedRecord = null;
      _selectedReportSession = null;
      _battery = null;
      _connected = _ble.connectedInfo;
      _connectedHeart = _heart.connectedInfo;
      _latestHeartSample = null;
      _latestHeartByPlayerId.clear();
      _heartDevicePlayerIds.clear();
      _lastHeartSampleUploadAt.clear();
      _heartSampleUploadInFlight.clear();
      _selectedHeartDeviceId = null;
      _liveRunning = false;
      _activeLiveSessionId = null;
      _liveStartRequestSignal = 0;
      _livePauseRequestSignal = 0;
      _liveStopRequestSignal = 0;
      _liveExitWithoutSaveRequestSignal = 0;
      _logs.insert(0, '[TEAM] переключение команды → ${widget.teamName} (${widget.teamId})');
      if (_logs.length > 220) _logs.removeRange(220, _logs.length);
    });
  }

  @override
  void dispose() {
    _calibrationFlashTimer?.cancel();
    _remoteDebugPollTimer?.cancel();
    _remoteStatusHeartbeatTimer?.cancel();
    _dataSub?.cancel();
    _logSub?.cancel();
    _heartSub?.cancel();
    _heartLogSub?.cancel();
    _ble.dispose();
    _heart.dispose();
    _mobileSectionController.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    _bindBle();
    _bindHeartRate();
    _startRemoteDebugTools();
    try {
      await _ble.init();
    } catch (e) {
      _toast('Bluetooth', '$e');
    }
    try {
      await _heart.init();
    } catch (e) {
      _toast('Polar H10', '$e');
    }
    await _loadServerData();
  }

  void _bindBle() {
    _dataSub = _ble.dataStream.listen((event) {
      if (!mounted) return;

      final now = DateTime.now();
      final chunk = event.gpsChunk;
      final validPoints = chunk == null
          ? const <ActionTrackerGpsPoint>[]
          : chunk.points.where(_isValidGpsPoint).toList(growable: false);

      setState(() {
        _lastTrackerPacketAt = now;
        _lastWorkspaceRx = event.rawHex;

        if (event.battery != null) _battery = event.battery;
        if (event.records.isNotEmpty) {
          _records
            ..clear()
            ..addAll(event.records);
          _lastRecordListAt = now;
          _trackerRecordingStatus = _formatTrackerRecordingStatus(event.records);
        }

        if (event.transferFinished) {
          _trackerRecordingStatus = _offlineAutoSaveAfterTransfer
              ? 'загрузка записи завершена · сохраняю на сервер'
              : 'загрузка записи завершена · можно сохранить в отчёт';
        }

        if (validPoints.isNotEmpty) {
          _points.addAll(validPoints);
          _lastWorkspaceGpsPoint = validPoints.last;
          _lastWorkspaceGpsAt = now;
          _lastWorkspaceGps = '${validPoints.last.latitude.toStringAsFixed(6)}, ${validPoints.last.longitude.toStringAsFixed(6)}';
        }
      });

      if (validPoints.isNotEmpty) {
        final shouldSend = _lastRemoteRxLogAt == null || now.difference(_lastRemoteRxLogAt!).inSeconds >= 5;
        if (shouldSend) {
          _lastRemoteRxLogAt = now;
          unawaited(_logRemote(
            'RX GPS: ${validPoints.length} точек · last=$_lastWorkspaceGps · всего=${_points.length}',
            source: 'workspace_rx_gps',
            rawHex: event.rawHex,
          ));
        }
      } else if (chunk != null && chunk.points.isNotEmpty) {
        unawaited(_logRemote(
          'RX GPS отброшен: невалидная координата или 0,0 · points=${chunk.points.length}',
          level: 'warning',
          source: 'workspace_rx_gps_invalid',
          rawHex: event.rawHex,
        ));
      }

      if (event.records.isNotEmpty) {
        unawaited(_autoSyncLatestFinishedRecordIfNeeded());
      }
      if (event.transferFinished || event.gpsChunk?.finished == true) {
        unawaited(_finishOfflineAutoSyncAfterTransfer());
      }
    });

    _logSub = _ble.logStream.listen((line) {
      if (!mounted) return;
      setState(() {
        _logs.insert(0, line);
        if (_logs.length > 220) _logs.removeLast();
      });

      final lower = line.toLowerCase();
      if (lower.contains('tx пропущен') || lower.contains('отключился') || lower.contains('not connected') || lower.contains('reconnect scan failed')) {
        // Не сбрасываем выбранный датчик во время активного Live.
        // Раньше это меняло key у TrackerLivePanel, виджет пересоздавался,
        // dispose() останавливал live-сессию, и кнопка «Старт» отжималась через несколько секунд.
        if (!_liveRunning && _connected != null) {
          setState(() => _connected = null);
        }
      }

      final remoteBleLevel = _remoteBleLogLevel(line);
      if (remoteBleLevel != null) {
        unawaited(_logRemote(line, level: remoteBleLevel, source: 'workspace_ble_log'));
      }
    });
  }


  void _bindHeartRate() {
    _heartSub?.cancel();
    _heartSub = _heart.sampleStream.listen((sample) {
      if (!mounted) return;
      final playerId = _heartDevicePlayerIds[sample.deviceId];
      setState(() {
        _latestHeartSample = sample;
        _connectedHeart = _heart.connectedInfo;
        _selectedHeartDeviceId ??= sample.deviceId;
        if (playerId != null && playerId > 0) {
          _heartDevicePlayerIds[sample.deviceId] = playerId;
          _latestHeartByPlayerId[playerId] = sample;
        }
      });
      unawaited(_uploadHeartRateSample(sample, playerId: playerId));
    });

    _heartLogSub?.cancel();
    _heartLogSub = _heart.logStream.listen((line) {
      if (!mounted) return;
      setState(() {
        _logs.insert(0, line.replaceFirst(']', '] HEART'));
        if (_logs.length > 220) _logs.removeLast();
      });
      final lower = line.toLowerCase();
      if (lower.contains('error') || lower.contains('ошиб') || lower.contains('not found') || lower.contains('не найден') || lower.contains('отключ')) {
        unawaited(_logRemote(line, level: lower.contains('не найден') || lower.contains('not found') ? 'warning' : 'error', source: 'workspace_heart_rate_log'));
      }
    });
  }

  Future<void> _uploadHeartRateSample(HeartRateSample sample, {int? playerId}) async {
    final liveId = _activeLiveSessionId;
    if (liveId == null || liveId <= 0) return;
    if (playerId == null || playerId <= 0) return;

    final now = DateTime.now();
    final last = _lastHeartSampleUploadAt[sample.deviceId];
    if (last != null && now.difference(last).inMilliseconds < 1800) return;
    if (_heartSampleUploadInFlight.contains(sample.deviceId)) return;

    _lastHeartSampleUploadAt[sample.deviceId] = now;
    _heartSampleUploadInFlight.add(sample.deviceId);
    try {
      await _liveApi.saveHeartRateSample(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: playerId,
        liveSessionId: liveId,
        sample: sample,
      );
    } catch (e) {
      unawaited(_logRemote('Ошибка сохранения Polar H10: $e', level: 'warning', source: 'workspace_heart_rate_save_error'));
    } finally {
      _heartSampleUploadInFlight.remove(sample.deviceId);
    }
  }

  bool _isValidGpsPoint(ActionTrackerGpsPoint p) {
    if (p.latitude == 0 || p.longitude == 0) return false;
    if (p.latitude < -90 || p.latitude > 90) return false;
    if (p.longitude < -180 || p.longitude > 180) return false;
    return true;
  }

  String? _remoteBleLogLevel(String line) {
    final lower = line.toLowerCase();
    if (lower.contains('reconnect wait') ||
        lower.contains('вне зоны') ||
        lower.contains('write characteristic is null') ||
        lower.contains('gps-датчик пока вне зоны') ||
        lower.contains('live-сессия на сервере продолжается')) {
      return 'warning';
    }
    if (lower.contains('ошиб') ||
        lower.contains('error') ||
        lower.contains('not connected') ||
        lower.contains('disconnected') ||
        lower.contains('отключ') ||
        lower.contains('пропущен') ||
        lower.contains('failed')) {
      return 'error';
    }
    if (lower.contains('warning') || lower.contains('not found') || lower.contains('не найден') || lower.contains('fallback')) {
      return 'warning';
    }
    if (lower.contains('scan') ||
        lower.contains('ble diag') ||
        lower.contains('gps sensor') ||
        lower.contains('tracker?') ||
        lower.contains('probe?') ||
        lower.contains('reset') ||
        lower.contains('tx/rx') ||
        lower.contains('подключ')) {
      return 'info';
    }
    return null;
  }

  ActionTrackerDevice? get _remoteConnectedDevice => _ble.commandChannelReady ? (_connected ?? _ble.connectedInfo) : null;

  ActionTrackerDevice? get _lastKnownBleDevice => _connected ?? _ble.connectedInfo ?? _ble.lastKnownInfo;

  String _remoteClientLabel() {
    final device = _remoteConnectedDevice;
    final player = _selectedPlayer?.name ?? 'игрок не выбран';
    final deviceTitle = device == null ? 'BLE не подключён' : '${device.name} / ${device.id}';
    return '${widget.teamName} · $player · $deviceTitle';
  }

  Map<String, dynamic> _remoteDebugContext() {
    final packetAge = _lastTrackerPacketAt == null ? null : DateTime.now().difference(_lastTrackerPacketAt!).inSeconds;
    final gpsAge = _lastWorkspaceGpsAt == null ? null : DateTime.now().difference(_lastWorkspaceGpsAt!).inSeconds;
    final device = _remoteConnectedDevice;
    final lastKnown = _lastKnownBleDevice;
    return <String, dynamic>{
      'club_id': widget.clubId,
      'club_name': widget.clubName,
      'team_id': widget.teamId,
      'team_name': widget.teamName,
      'user_id': widget.userId,
      'player_id': _selectedPlayer?.id,
      'player_name': _selectedPlayer?.name,
      'ble_connected': device != null,
      'ble_command_channel_ready': _ble.commandChannelReady,
      'ble_device_uuid': device?.id ?? lastKnown?.id,
      'ble_device_name': device?.name ?? lastKnown?.name,
      'ble_rssi': device?.rssi ?? lastKnown?.rssi,
      'ble_state_note': device == null && lastKnown != null ? 'выбран/был подключён, но TX/RX канал сейчас закрыт' : null,
      'live_running': _liveRunning,
      'live_session_id': _activeLiveSessionId,
      'field_id': _selectedField?.id,
      'field_title': _selectedField?.title,
      'field_calibrated': _selectedField?.hasCalibration == true,
      'points_count': _points.length,
      'last_packet_age_sec': packetAge,
      'last_gps_age_sec': gpsAge,
      'last_rx': _lastWorkspaceRx,
      'last_gps': _lastWorkspaceGps,
      'battery_percent': _batteryPercent,
      'saved_devices_count': _savedDevices.length,
      'saved_devices_hidden': _hideSavedDevices,
      'ble_reset_available': true,
      'clean_scan_available': true,
      'client_time': DateTime.now().toIso8601String(),
    };
  }

  void _startRemoteDebugTools() {
    _remoteDebugPollTimer?.cancel();
    _remoteStatusHeartbeatTimer?.cancel();

    _remoteDebugPollTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      if (!mounted || !_remoteConsoleAutoRefresh) return;
      if (_section != TrackerWorkspaceSection.debug && _section != TrackerWorkspaceSection.devices && _section != TrackerWorkspaceSection.live) return;
      unawaited(_loadRemoteDebugLogs(silent: true));
    });

    _remoteStatusHeartbeatTimer = Timer.periodic(const Duration(seconds: 15), (_) {
      if (!mounted) return;
      unawaited(_sendRemoteStatusHeartbeat());
    });

    unawaited(_sendRemoteStatusHeartbeat(source: 'workspace_open'));
    unawaited(_loadRemoteDebugLogs(silent: true));
  }

  Future<void> _sendRemoteStatusHeartbeat({String source = 'workspace_status'}) async {
    final device = _remoteConnectedDevice;
    // Чтобы администратор, который просто открыл удалённый терминал без BLE,
    // не засорял общую ленту пустыми статусами. Ошибки scan/connect всё равно уходят отдельно.
    final lastKnown = _lastKnownBleDevice;
    if (device == null && lastKnown == null && !_liveRunning && _points.isEmpty && _lastTrackerPacketAt == null) return;

    final hasFreshGps = _lastWorkspaceGpsAt != null && DateTime.now().difference(_lastWorkspaceGpsAt!).inSeconds <= 20;
    final level = device == null ? 'warning' : (hasFreshGps || !_liveRunning ? 'info' : 'warning');
    final status = device == null
        ? 'REMOTE STATUS: BLE TX/RX не готов${lastKnown == null ? '' : ' · выбран ${lastKnown.name} / ${lastKnown.id}'} · ${_remoteClientLabel()}'
        : 'REMOTE STATUS: ${_remoteClientLabel()} · live=$_liveRunning · gps=${hasFreshGps ? _lastWorkspaceGps : 'нет свежего GPS'} · field=${_selectedField?.title ?? 'нет'}';
    await _logRemote(status, level: level, source: source);
  }

  Future<void> _loadRemoteDebugLogs({bool silent = false}) async {
    if (_remoteDebugLoading) return;
    if (mounted && !silent) setState(() => _remoteDebugLoading = true);
    _remoteDebugLoading = true;
    try {
      final logs = await _liveApi.loadDebugLogs(teamId: widget.teamId, limit: 180);
      if (!mounted) return;
      final remoteTrackers = _RemoteTrackerPresence.fromLogs(logs);
      setState(() {
        _remoteDebugLogs
          ..clear()
          ..addAll(logs);
        _remoteConnectedTrackers
          ..clear()
          ..addAll(remoteTrackers);
        _lastRemoteConsoleLoadAt = DateTime.now();
      });
      if (!silent) {
        _pushLocalLog('[REMOTE TERMINAL OK] получено ${logs.length} строк с сервера');
      }
    } catch (e) {
      if (!mounted) return;
      _pushLocalLog('[REMOTE TERMINAL ERROR] $e', dedupe: true);
    } finally {
      _remoteDebugLoading = false;
      if (mounted && !silent) setState(() {});
    }
  }

  Future<void> _logRemote(
    String message, {
    String level = 'info',
    String source = 'workspace',
    String? rawHex,
    Map<String, dynamic>? extra,
  }) async {
    try {
      final device = _remoteConnectedDevice;
      await _liveApi.sendDebugLog(
        teamId: widget.teamId,
        playerId: null,
        liveSessionId: _activeLiveSessionId,
        level: level,
        source: source,
        message: message,
        rawHex: rawHex,
        platform: 'flutter_tracker',
        appVersion: 'tracker_62_tablet_report_ble_debug' ,
        deviceUuid: device?.id,
        deviceName: device?.name,
        context: <String, dynamic>{..._remoteDebugContext(), if (extra != null) ...extra},
      );
      _lastRemoteDebug = 'OK · $source · ${DateTime.now().toIso8601String()}';
      if (source != 'workspace_status') {
        _pushLocalLog('[REMOTE DEBUG OK] $source отправлен на сервер');
      }
    } catch (e) {
      _lastRemoteDebug = 'ОШИБКА debug endpoint: $e';
      _pushLocalLog('[REMOTE DEBUG ERROR] $e', dedupe: true);
      // Удалённый debug не должен ломать работу трекера.
    }
  }

  double _distanceMeters(ActionTrackerGpsPoint a, ActionTrackerGpsPoint b) {
    const earthRadiusM = 6371000.0;
    final lat1 = a.latitude * math.pi / 180.0;
    final lat2 = b.latitude * math.pi / 180.0;
    final dLat = (b.latitude - a.latitude) * math.pi / 180.0;
    final dLon = (b.longitude - a.longitude) * math.pi / 180.0;
    final h = math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(lat1) * math.cos(lat2) * math.sin(dLon / 2) * math.sin(dLon / 2);
    return earthRadiusM * 2 * math.atan2(math.sqrt(h), math.sqrt(1 - h));
  }

  int? _tooCloseCalibrationCornerIndex(ActionTrackerGpsPoint point) {
    for (var i = 0; i < _calibrationCorners.length; i++) {
      if (_distanceMeters(_calibrationCorners[i], point) < 2.0) return i;
    }
    return null;
  }

  void _showCalibrationFlash(String label) {
    _calibrationFlashTimer?.cancel();
    setState(() {
      _calibrationFlashLabel = label;
      _calibrationFlashSeed++;
    });
    _calibrationFlashTimer = Timer(const Duration(milliseconds: 1500), () {
      if (!mounted) return;
      setState(() => _calibrationFlashLabel = null);
    });
  }

  Future<ActionTrackerGpsPoint?> _waitForFreshCalibrationPoint(int nextIndex) async {
    final beforeCount = _points.length;
    final beforeGpsAt = _lastWorkspaceGpsAt;
    final beforePoint = _lastWorkspaceGpsPoint;

    final commands = ActionTrackerBleProfile.commandCurrentGpsCandidates;
    final maxCandidates = math.min(commands.length, 8);
    var candidateIndex = 0;
    var lastTxAt = DateTime.fromMillisecondsSinceEpoch(0);

    Future<void> sendCandidate() async {
      final now = DateTime.now();
      if (now.difference(lastTxAt).inMilliseconds < 900) return;
      lastTxAt = now;
      final command = commands[candidateIndex];
      final hex = command.map((e) => e.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' ');
      try {
        await _ble.sendRawCommand(command);
        unawaited(_logRemote(
          'Калибровка: TX $hex для угла ${['A', 'B', 'C', 'D'][nextIndex]} · candidate=${candidateIndex + 1}/$maxCandidates',
          source: 'workspace_calibration_tx',
          rawHex: hex,
        ));
      } catch (e) {
        unawaited(_logRemote(
          'Калибровка: не удалось отправить GPS-запрос $hex: $e',
          level: 'error',
          source: 'workspace_calibration_tx_error',
          rawHex: hex,
        ));
      }
      candidateIndex = (candidateIndex + 1) % maxCandidates;
    }

    await sendCandidate();

    final deadline = DateTime.now().add(const Duration(seconds: 8));
    while (mounted && DateTime.now().isBefore(deadline)) {
      await Future<void>.delayed(const Duration(milliseconds: 220));
      if (_points.length > beforeCount && _isValidGpsPoint(_points.last)) return _points.last;
      final latest = _lastWorkspaceGpsPoint;
      if (latest != null && _lastWorkspaceGpsAt != null && _lastWorkspaceGpsAt != beforeGpsAt && _isValidGpsPoint(latest)) {
        return latest;
      }
      await sendCandidate();
    }

    final latest = _lastWorkspaceGpsPoint;
    final gpsAgeOk = _lastWorkspaceGpsAt != null && DateTime.now().difference(_lastWorkspaceGpsAt!).inSeconds <= 10;
    if (latest != null && gpsAgeOk && _isValidGpsPoint(latest)) {
      if (beforePoint == null || _distanceMeters(beforePoint, latest) > 0.2 || _calibrationCorners.isEmpty) return latest;
    }

    return null;
  }

  String _workspaceDebugDump() {
    final packetAge = _lastTrackerPacketAt == null ? 'нет' : '${DateTime.now().difference(_lastTrackerPacketAt!).inSeconds}s';
    final gpsAge = _lastWorkspaceGpsAt == null ? 'нет' : '${DateTime.now().difference(_lastWorkspaceGpsAt!).inSeconds}s';
    return [
      'team=${widget.teamId} ${widget.teamName}',
      'player=${_selectedPlayer?.id ?? 'none'} ${_selectedPlayer?.name ?? ''}',
      'ble=${_ble.commandChannelReady ? (_ble.connectedInfo?.name ?? 'ready') : 'off'} ${_ble.connectedInfo?.id ?? _ble.lastKnownInfo?.id ?? ''}',
      'ble_command_channel=${_ble.commandChannelReady ? 'ready' : 'not_ready'}',
      'live_running=$_liveRunning live_id=${_activeLiveSessionId ?? 'none'}',
      'field=${_selectedField?.id ?? 'none'} ${_selectedField?.title ?? ''} calibration=${_selectedField?.hasCalibration == true}',
      'points=${_points.length} calibration_corners=${_calibrationCorners.length}',
      'last_packet_age=$packetAge',
      'last_rx=$_lastWorkspaceRx',
      'last_gps=$_lastWorkspaceGps gps_age=$gpsAge',
      'remote_debug=$_lastRemoteDebug',
      'battery=${_batteryPercent ?? 'нет'}',
      'logs=${_logs.take(20).join(' | ')}',
    ].join('\n');
  }

  Future<void> _sendManualDebugDump() async {
    await _logRemote(_workspaceDebugDump(), source: 'workspace_manual_debug');
    await _loadRemoteDebugLogs(silent: true);
    _toast('Debug', 'Диагностика отправлена на сервер');
  }

  Future<void> _requestCurrentGpsFromDebug() async {
    try {
      await _ble.requestCurrentGpsCandidate(candidateIndex: 0);
      await _logRemote('Ручной debug: TX 3A запрос текущей GPS-точки', source: 'workspace_manual_gps_tx', rawHex: '3A');
      _toast('Debug', 'Запрос GPS отправлен в трекер');
    } catch (e) {
      await _logRemote('Ручной debug GPS ошибка: $e', level: 'error', source: 'workspace_manual_gps_error');
      _toast('Debug', '$e');
    }
  }

  List<ActionTrackerGpsPoint> _savedFieldCalibrationCorners(TrackerFieldModel? field) {
    if (field == null || !field.hasCalibration) return const <ActionTrackerGpsPoint>[];
    return <ActionTrackerGpsPoint>[
      ActionTrackerGpsPoint(timeMs: 0, latitude: field.cornerALat!, longitude: field.cornerALng!),
      ActionTrackerGpsPoint(timeMs: 0, latitude: field.cornerBLat!, longitude: field.cornerBLng!),
      ActionTrackerGpsPoint(timeMs: 0, latitude: field.cornerCLat!, longitude: field.cornerCLng!),
      ActionTrackerGpsPoint(timeMs: 0, latitude: field.cornerDLat!, longitude: field.cornerDLng!),
    ];
  }

  String _formatCalibrationCoordinate(ActionTrackerGpsPoint point) {
    return '${point.latitude.toStringAsFixed(6)}\n${point.longitude.toStringAsFixed(6)}';
  }

  String _savedFieldCoordinateSubtitle(TrackerFieldModel field) {
    final corners = _savedFieldCalibrationCorners(field);
    if (corners.length < 4) return 'координаты не сохранены';
    return 'A ${corners[0].latitude.toStringAsFixed(5)}, ${corners[0].longitude.toStringAsFixed(5)} · B ${corners[1].latitude.toStringAsFixed(5)}, ${corners[1].longitude.toStringAsFixed(5)}';
  }

  void _startRecalibrationCurrentField() {
    final field = _selectedField;
    setState(() {
      _calibrationCorners.clear();
      if (field != null) {
        _selectedField = TrackerFieldModel(
          id: field.id,
          clubId: field.clubId ?? widget.clubId,
          teamId: field.teamId ?? widget.teamId,
          title: field.title,
          lengthM: field.lengthM,
          widthM: field.widthM,
          isDefault: field.isDefault,
        );
      }
    });
    _toast('Калибровка', 'Можно перезаписать углы A → B → C → D для выбранного поля.');
  }

  Future<void> _loadServerData() async {
    if (mounted) setState(() => _loading = true);
    try {
      final results = await Future.wait<dynamic>([
        if (_players.isEmpty) _api.loadPlayers(teamId: widget.teamId) else Future<List<TrackerPlayerOption>>.value(_players),
        _api.loadDevices(teamId: widget.teamId),
        _api.loadFields(teamId: widget.teamId),
      ]);
      if (!mounted) return;
      setState(() {
        _players = results[0] as List<TrackerPlayerOption>;
        _savedDevices = results[1] as List<TrackerDeviceModel>;
        _fields = results[2] as List<TrackerFieldModel>;
        if (_selectedPlayer == null || !_players.any((p) => p.id == _selectedPlayer!.id)) {
          _selectedPlayer = _players.isNotEmpty ? _players.first : null;
        }

        if (_fields.isEmpty) {
          _selectedField = null;
        } else if (_selectedField == null || !_fields.any((f) => f.id == _selectedField!.id)) {
          _selectedField = _fields.firstWhere((f) => f.isDefault, orElse: () => _fields.first);
        }
      });
    } catch (e) {
      unawaited(_logRemote('Ошибка загрузки данных трекера: $e', level: 'error', source: 'workspace_load_error'));
      _toast('Трекер', 'Ошибка загрузки: $e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  String get _livePanelKeySuffix {
    // Ключ LivePanel должен быть стабильным даже если BLE на секунду потерялся.
    // Нельзя включать сюда _connected/_ble.connectedInfo: при временном разрыве
    // менялся key, LivePanel пересоздавался и dispose() завершал сессию.
    return '${_selectedPlayer?.id ?? 0}_${_selectedField?.id ?? 0}';
  }

  int? get _batteryPercent {
    final battery = _battery;
    if (battery == null) return null;
    return (battery.voltage * 10).round().clamp(0, 100);
  }

  String _friendlyBleError(Object error) {
    final raw = '$error';
    final lower = raw.toLowerCase();
    final isIOS = !kIsWeb && Platform.isIOS;
    final isMac = !kIsWeb && Platform.isMacOS;
    final isAndroid = !kIsWeb && Platform.isAndroid;

    if (raw.contains('CBManagerStateUnsupported')) {
      return isIOS
          ? 'Bluetooth недоступен на этом iPhone/iPad. Проверьте, что Bluetooth включён и приложение собрано с iOS Bluetooth-разрешениями.'
          : 'Bluetooth недоступен в текущей среде. На macOS запустите именно desktop-приложение, включите Bluetooth и проверьте разрешения для приложения.';
    }
    if (lower.contains('bluetooth must be turned on') || lower.contains('poweredoff')) {
      if (isIOS) return 'Bluetooth выключен. На iPhone откройте Пункт управления или Настройки → Bluetooth, включите Bluetooth и повторите поиск трекера.';
      if (isAndroid) return 'Bluetooth выключен. Включите Bluetooth и разрешение «Устройства поблизости», затем повторите поиск трекера.';
      return 'Bluetooth выключен. Включите Bluetooth на Mac и повторите поиск трекера.';
    }
    if (lower.contains('permission') || lower.contains('unauthorized') || lower.contains('denied') || lower.contains('restricted')) {
      if (isIOS) {
        return 'Нет разрешения Bluetooth для поиска трекера. Откройте iPhone → Настройки → Спортотека → Bluetooth и включите доступ. Если такого переключателя нет, добавьте в ios/Runner/Info.plist ключи NSBluetoothAlwaysUsageDescription и NSBluetoothPeripheralUsageDescription, затем пересоберите приложение.';
      }
      if (isAndroid) {
        return 'Нет разрешения Bluetooth. Откройте настройки приложения и разрешите «Устройства поблизости»/Bluetooth, а для старых Android также геолокацию.';
      }
      if (isMac) {
        return 'Нет разрешения на Bluetooth. Откройте Системные настройки macOS → Конфиденциальность и безопасность → Bluetooth и разрешите доступ приложению.';
      }
      return 'Нет разрешения Bluetooth для поиска трекера. Проверьте системные настройки приложения.';
    }
    return raw;
  }

  List<String> _knownBleIdsForScan() {
    return <String>{
      ..._savedDevices.map((d) => d.deviceUuid),
      ..._remoteConnectedTrackers.map((r) => r.uuid),
      if (_ble.lastKnownInfo != null) _ble.lastKnownInfo!.id,
      if (_ble.connectedInfo != null) _ble.connectedInfo!.id,
    }.where((e) => e.trim().isNotEmpty).toList(growable: false);
  }

  List<String> _knownBleNamesForScan() {
    return <String>{
      ..._savedDevices.map((d) => d.deviceName),
      ..._remoteConnectedTrackers.map((r) => r.name),
      if (_ble.lastKnownInfo != null) _ble.lastKnownInfo!.name,
      if (_ble.connectedInfo != null) _ble.connectedInfo!.name,
    }.where((e) => e.trim().isNotEmpty).toList(growable: false);
  }

  Future<void> _scan({bool clean = false, bool universalMode = false}) async {
    setState(() => _scanning = true);
    try {
      await TrackerPermissions.ensureBlePermissions();
      final diagnostics = await TrackerPermissions.diagnostics();
      final knownIds = _knownBleIdsForScan();
      final knownNames = _knownBleNamesForScan();
      _pushLocalLog('[BLE DIAG] $diagnostics · knownIds=${knownIds.length} · knownNames=${knownNames.length} · mode=${universalMode ? 'universal-compatible' : 'auto'}');
      unawaited(_logRemote(
        'BLE поиск запущен: clean=$clean · mode=${universalMode ? 'universal-compatible' : 'auto'} · $diagnostics',
        source: clean ? 'workspace_ble_clean_scan_start' : 'workspace_ble_scan_start',
        extra: <String, dynamic>{'known_ids': knownIds, 'known_names': knownNames, 'clean_scan': clean, 'universal_mode': universalMode},
      ));
      unawaited(_logRemote(
        'BLE диагностика перед поиском: $diagnostics · knownIds=${knownIds.length} · knownNames=${knownNames.length} · mode=${universalMode ? 'universal-compatible' : 'auto'}',
        source: 'workspace_ble_diagnostics',
        extra: <String, dynamic>{'known_ids': knownIds, 'known_names': knownNames, 'universal_mode': universalMode},
      ));

      if (clean) {
        unawaited(_logRemote('Чистый поиск BLE: локальный канал сброшен перед scan', source: 'workspace_ble_clean_scan_reset')); 
        _logs.insert(0, '[BLE] CLEAN SCAN START → reset + universal scan');
        await _ble.cleanScan(knownDeviceIds: knownIds, knownDeviceNames: knownNames, universalMode: universalMode);
        unawaited(_logRemote('Чистый поиск BLE завершён. Смотрите GPS SCAN RAW TOP / CANDIDATES TOP в debug.', source: 'workspace_ble_clean_scan_end')); 
      } else {
        await _ble.scan(knownDeviceIds: knownIds, knownDeviceNames: knownNames, universalMode: universalMode);
      }
    } catch (e) {
      unawaited(_logRemote('Ошибка BLE scan: $e', level: 'error', source: clean ? 'workspace_ble_clean_scan_error' : 'workspace_ble_scan_error'));
      _toast('Bluetooth', _friendlyBleError(e));
    } finally {
      unawaited(_sendRemoteStatusHeartbeat(source: 'workspace_ble_scan_status'));
      unawaited(_loadRemoteDebugLogs(silent: true));
      if (mounted) setState(() => _scanning = false);
    }
  }

  Future<void> _resetBleState() async {
    try {
      await _ble.resetLocalState(clearKnownDevice: true);
      setState(() {
        _connected = null;
        _battery = null;
        _points.clear();
        _records.clear();
        _selectedRecord = null;
        _offlineAutoSyncInProgress = false;
        _offlineAutoSaveAfterTransfer = false;
        _offlineAutoSyncKey = null;
        _trackerRecordingStatus = 'запись на трекере не проверялась';
        _lastRecordListAt = null;
        _lastWorkspaceGpsPoint = null;
        _lastWorkspaceGpsAt = null;
        _lastTrackerPacketAt = null;
        _lastWorkspaceRx = 'нет пакетов';
        _lastWorkspaceGps = 'нет GPS';
      });
      _logs.insert(0, '[BLE] RESET DONE → очищены device/TX/RX/GPS/records');
      unawaited(_logRemote('BLE сброшен локально: device/TX/RX/GPS очищены, серверные привязки сохранены', source: 'workspace_ble_reset'));
      _toast('BLE', 'Локальный BLE сброшен. Сохранённые серверные привязки не удалены.');
    } catch (e) {
      unawaited(_logRemote('Ошибка BLE reset: $e', level: 'error', source: 'workspace_ble_reset_error'));
      _toast('BLE reset', '$e');
    }
  }

  Future<void> _connect(ActionTrackerDevice device) async {
    setState(() => _connecting = true);
    try {
      await TrackerPermissions.ensureBlePermissions();
      await _ble.connect(device);
      _connected = device;
      await _api.registerOrBindDevice(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: null,
        deviceUuid: device.id,
        deviceName: device.name,
        batteryPercent: _batteryPercent,
      );
      unawaited(_logRemote(
        'BLE подключён: ${device.name} / ${device.id} → ${_selectedPlayer?.name ?? 'игрок не выбран'}',
        source: 'workspace_ble_connected',
      ));
      _toast('Подключено', _selectedPlayer == null ? device.name : '${device.name} → ${_selectedPlayer!.name}');
      await _loadServerData();
    } catch (e) {
      unawaited(_logRemote('Ошибка BLE connect: $e', level: 'error', source: 'workspace_ble_connect_error'));
      _toast('Подключение', '$e');
    } finally {
      if (mounted) setState(() => _connecting = false);
    }
  }


  Future<void> _scanHeartRate({bool showAllBleCandidates = false}) async {
    setState(() => _scanningHeart = true);
    try {
      await TrackerPermissions.ensureBlePermissions();
      final diagnostics = await TrackerPermissions.diagnostics();
      final mode = showAllBleCandidates ? 'all-ble-diagnostic' : 'heart-rate-180D';
      _pushLocalLog('[HEART DIAG] $diagnostics · mode=$mode');
      unawaited(_logRemote('Поиск пульсометра запущен: Polar H10 / $mode · $diagnostics', source: 'workspace_heart_rate_scan_start'));
      await _heart.scan(showAllBleCandidates: showAllBleCandidates);
    } catch (e) {
      unawaited(_logRemote('Ошибка Heart Rate scan: $e', level: 'error', source: 'workspace_heart_rate_scan_error'));
      _toast('Polar H10', _friendlyBleError(e));
    } finally {
      if (mounted) setState(() => _scanningHeart = false);
    }
  }

  Future<void> _connectHeartRate(HeartRateBleDevice device) async {
    setState(() {
      _connectingHeart = true;
      _selectedHeartDeviceId = device.id;
    });
    try {
      await TrackerPermissions.ensureBlePermissions();
      await _heart.connect(device);
      setState(() {
        _connectedHeart = _heart.connectedDevice(device.id) ?? device;
        _selectedHeartDeviceId = device.id;
      });
      unawaited(_logRemote(
        'Пульсометр подключён: ${device.name} / ${device.id} · выберите игрока в строке датчика · всего ${_heart.connectedCount}/12',
        source: 'workspace_heart_rate_connected',
      ));
      _toast('Polar H10', 'Подключён ${device.name}. Теперь выберите игрока в строке этого датчика.');
    } catch (e) {
      unawaited(_logRemote('Ошибка Heart Rate connect: $e', level: 'error', source: 'workspace_heart_rate_connect_error'));
      _toast('Polar H10', '$e');
    } finally {
      if (mounted) setState(() => _connectingHeart = false);
    }
  }

  Future<void> _resetHeartRateState() async {
    try {
      await _heart.resetLocalState();
      setState(() {
        _connectedHeart = null;
        _latestHeartSample = null;
        _latestHeartByPlayerId.clear();
        _heartDevicePlayerIds.clear();
        _selectedHeartDeviceId = null;
        _lastHeartSampleUploadAt.clear();
        _heartSampleUploadInFlight.clear();
      });
      _toast('Polar H10', 'Подключение пульсометра очищено.');
    } catch (e) {
      _toast('Polar H10', '$e');
    }
  }

  void _bindHeartRateToSelectedPlayer() {
    final selectedId = _selectedHeartDeviceId ?? _heart.connectedInfo?.id ?? _connectedHeart?.id;
    final device = selectedId == null ? null : (_heart.connectedDevice(selectedId) ?? _heart.connectedInfo ?? _connectedHeart);
    final player = _selectedPlayer;
    if (device == null) {
      _toast('Polar H10', 'Сначала подключите пульсометр или нажмите его в списке.');
      return;
    }
    if (player == null) {
      _toast('Polar H10', 'Сначала выберите игрока в составе.');
      return;
    }
    setState(() {
      _selectedHeartDeviceId = device.id;
      _heartDevicePlayerIds[device.id] = player.id;
      final sample = _heart.lastSampleForDevice(device.id) ?? (_latestHeartSample?.deviceId == device.id ? _latestHeartSample : null);
      if (sample != null) _latestHeartByPlayerId[player.id] = sample;
    });
    final sample = _heart.lastSampleForDevice(device.id);
    if (sample != null) unawaited(_uploadHeartRateSample(sample, playerId: player.id));
    _toast('Polar H10', '${device.name} назначен игроку ${player.name}');
  }


  void _bindHeartRateDeviceToPlayer(HeartRateBleDevice device, int? playerId) {
    final oldPlayerId = _heartDevicePlayerIds[device.id];
    TrackerPlayerOption? player;
    if (playerId != null) {
      final matches = _players.where((p) => p.id == playerId).toList();
      if (matches.isNotEmpty) player = matches.first;
    }
    final sample = _heart.lastSampleForDevice(device.id) ?? (_latestHeartSample?.deviceId == device.id ? _latestHeartSample : null);

    setState(() {
      _selectedHeartDeviceId = device.id;
      if (oldPlayerId != null && oldPlayerId != playerId) {
        final oldSample = _latestHeartByPlayerId[oldPlayerId];
        if (oldSample?.deviceId == device.id) _latestHeartByPlayerId.remove(oldPlayerId);
      }
      if (playerId == null || playerId <= 0) {
        _heartDevicePlayerIds.remove(device.id);
      } else {
        _heartDevicePlayerIds[device.id] = playerId;
        if (sample != null) _latestHeartByPlayerId[playerId] = sample;
      }
    });

    if (playerId != null && playerId > 0 && sample != null) {
      unawaited(_uploadHeartRateSample(sample, playerId: playerId));
    }
    unawaited(_api.registerOrBindDevice(
      clubId: widget.clubId,
      teamId: widget.teamId,
      playerId: playerId != null && playerId > 0 ? playerId : null,
      deviceUuid: device.id,
      deviceName: device.name,
      batteryPercent: sample?.batteryPercent,
    ).then((_) => _loadServerData()).catchError((e) {
      unawaited(_logRemote('Ошибка сохранения привязки Polar H10: $e', level: 'warning', source: 'workspace_heart_rate_bind_save_error'));
    }));
    _toast('Polar H10', player == null ? '${device.name}: игрок снят' : '${device.name} → ${player.name}');
  }

  bool _isHeartRateDeviceModel(TrackerDeviceModel device) {
    final text = '${device.deviceName} ${device.deviceUuid}'.toLowerCase();
    return text.contains('polar') || text.contains('h10') || text.contains('heart') || text.contains('hrm');
  }

  List<TrackerDeviceModel> _gpsDevicesForPlayer(int playerId) {
    return _savedDevices
        .where((d) => d.playerId == playerId && !_isHeartRateDeviceModel(d))
        .toList(growable: false);
  }

  List<String> _heartDeviceNamesForPlayer(int playerId) {
    final names = <String>[];
    for (final entry in _heartDevicePlayerIds.entries) {
      if (entry.value != playerId) continue;
      final sample = _heart.lastSampleForDevice(entry.key);
      final device = _heart.connectedDevice(entry.key) ?? _connectedHeart;
      names.add(sample?.deviceName ?? device?.name ?? 'Polar H10');
    }
    for (final d in _savedDevices.where((d) => d.playerId == playerId && _isHeartRateDeviceModel(d))) {
      if (!names.any((n) => n == d.deviceName)) names.add(d.deviceName);
    }
    return names;
  }

  String _equipmentStatusForPlayer(TrackerPlayerOption player) {
    final gps = _gpsDevicesForPlayer(player.id).map((d) => d.deviceName).toList(growable: false);
    final polar = _heartDeviceNamesForPlayer(player.id);
    final parts = <String>[
      gps.isEmpty ? 'GPS —' : 'GPS ${gps.first}${gps.length > 1 ? ' +${gps.length - 1}' : ''}',
      polar.isEmpty ? 'Polar —' : 'Polar ${polar.first}${polar.length > 1 ? ' +${polar.length - 1}' : ''}',
    ];
    return parts.join(' · ');
  }

  List<TrackerDeviceModel> _teamGpsDeviceCandidates({List<ActionTrackerDevice> scannedDevices = const <ActionTrackerDevice>[]}) {
    final byUuid = <String, TrackerDeviceModel>{};

    void addCandidate({
      required String uuid,
      required String name,
      int? batteryPercent,
      int? playerId,
      String? playerName,
      bool isNearby = false,
    }) {
      final id = uuid.trim();
      if (id.isEmpty) return;
      final title = name.trim().isEmpty ? 'BLE ${id.length > 6 ? id.substring(id.length - 6) : id}' : name.trim();
      final existing = byUuid[id];
      byUuid[id] = TrackerDeviceModel(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: playerId ?? existing?.playerId,
        playerName: playerName ?? existing?.playerName,
        deviceUuid: id,
        deviceName: existing?.deviceName.isNotEmpty == true && !isNearby ? existing!.deviceName : title,
        batteryPercent: batteryPercent ?? existing?.batteryPercent ?? _batteryPercent,
        isNearby: isNearby || (existing?.isNearby ?? false),
      );
    }

    for (final d in _mergedSavedDevices) {
      if (_isHeartRateDeviceModel(d) || d.deviceUuid.trim().isEmpty) continue;
      addCandidate(
        uuid: d.deviceUuid,
        name: d.deviceName,
        batteryPercent: d.batteryPercent,
        playerId: d.playerId,
        playerName: d.playerName,
        isNearby: d.isNearby,
      );
    }

    for (final d in scannedDevices) {
      addCandidate(uuid: d.id, name: d.name, isNearby: true);
    }

    final connected = _ble.connectedInfo;
    if (connected != null && connected.id.trim().isNotEmpty) {
      addCandidate(uuid: connected.id, name: connected.name, batteryPercent: _batteryPercent, isNearby: true);
    }

    return byUuid.values.toList(growable: false)
      ..sort((a, b) {
        final an = a.isNearby == true ? 0 : 1;
        final bn = b.isNearby == true ? 0 : 1;
        if (an != bn) return an.compareTo(bn);
        final aa = a.playerId == null ? 0 : 1;
        final bb = b.playerId == null ? 0 : 1;
        if (aa != bb) return aa.compareTo(bb);
        return a.deviceName.compareTo(b.deviceName);
      });
  }

  Future<void> _assignTrackerDeviceToPlayer(TrackerDeviceModel device, TrackerPlayerOption? player) async {
    try {
      await _api.registerOrBindDevice(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: player?.id,
        deviceUuid: device.deviceUuid,
        deviceName: device.deviceName,
        batteryPercent: device.batteryPercent ?? _batteryPercent,
      );
      if (mounted && player != null) {
        setState(() => _selectedPlayer = player);
      }
      await _loadServerData();
      _toast('GPS-трекер', player == null ? '${device.deviceName}: игрок снят' : '${device.deviceName} → ${player.name}');
    } catch (e) {
      unawaited(_logRemote('Ошибка назначения GPS-трекера: $e', level: 'error', source: 'workspace_device_assign_error'));
      _toast('GPS-трекер', '$e');
    }
  }

  Future<void> _connectAndAssignHeartRate(HeartRateBleDevice device, TrackerPlayerOption player) async {
    try {
      if (!_heart.isConnected(device.id)) {
        await _connectHeartRate(device);
      }
      _bindHeartRateDeviceToPlayer(device, player.id);
    } catch (e) {
      _toast('Polar H10', '$e');
    }
  }

  InputDecoration _equipmentInput(String label) => InputDecoration(
        labelText: label,
        filled: true,
        fillColor: Colors.white,
        isDense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _TD.borderStrong)),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _TD.borderStrong)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: _TD.greenBorder)),
      );

  Future<void> _openTeamEquipmentModal({TrackerPlayerOption? initialPlayer}) async {
    if (_players.isEmpty) {
      _toast('Оборудование', 'Игроки команды не загружены. Сначала обновите состав.');
      return;
    }

    TrackerPlayerOption selected = initialPlayer ?? _selectedPlayer ?? _players.first;

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (dialogContext, setModalState) {
            final width = MediaQuery.of(dialogContext).size.width;
            final compact = width < 760;

            Widget playerCard(TrackerPlayerOption player) {
              final active = selected.id == player.id;
              final gps = _gpsDevicesForPlayer(player.id);
              final polar = _heartDeviceNamesForPlayer(player.id);
              return Material(
                color: active ? _TD.greenSoft : Colors.white,
                borderRadius: BorderRadius.circular(16),
                child: InkWell(
                  borderRadius: BorderRadius.circular(16),
                  onTap: () {
                    setModalState(() => selected = player);
                    setState(() => _selectedPlayer = player);
                  },
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: active ? _TD.greenBorder : _TD.borderStrong),
                    ),
                    child: Row(children: [
                      _PlayerAvatarDark(
                        url: player.avatar,
                        initials: _playerInitials(player.name),
                        size: 36,
                        active: active,
                      ),
                      const SizedBox(width: 10),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 12.2, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Wrap(spacing: 5, runSpacing: 5, children: [
                          _EquipmentMiniBadge(icon: Icons.sensors_rounded, label: gps.isEmpty ? 'GPS —' : 'GPS ${gps.length}', active: gps.isNotEmpty),
                          _EquipmentMiniBadge(icon: Icons.favorite_rounded, label: polar.isEmpty ? 'Polar —' : 'Polar ${polar.length}', active: polar.isNotEmpty),
                        ]),
                      ])),
                      if (active) const Icon(Icons.check_circle_rounded, color: _TD.green, size: 19),
                    ]),
                  ),
                ),
              );
            }

            Widget playersList() {
              return ListView.separated(
                padding: EdgeInsets.zero,
                itemCount: _players.length,
                separatorBuilder: (_, __) => const SizedBox(height: 8),
                itemBuilder: (_, index) => playerCard(_players[index]),
              );
            }

            Widget assignmentPane(List<HeartRateBleDevice> discoveredHeartDevices, List<ActionTrackerDevice> discoveredGpsDevices) {
              final gpsCandidates = _teamGpsDeviceCandidates(scannedDevices: discoveredGpsDevices);
              final assignedGps = _gpsDevicesForPlayer(selected.id);
              final heartById = <String, HeartRateBleDevice>{};
              for (final d in discoveredHeartDevices) {
                heartById[d.id] = d;
              }
              for (final d in _heart.connectedInfos) {
                heartById[d.id] = d;
              }
              final heartCandidates = heartById.values.toList(growable: false)
                ..sort((a, b) {
                  final ac = _heart.isConnected(a.id) ? 0 : 1;
                  final bc = _heart.isConnected(b.id) ? 0 : 1;
                  if (ac != bc) return ac.compareTo(bc);
                  return b.rssi.compareTo(a.rssi);
                });
              final assignedHeartId = _heartDevicePlayerIds.entries
                  .where((e) => e.value == selected.id)
                  .map((e) => e.key)
                  .cast<String?>()
                  .firstWhere((_) => true, orElse: () => null);
              final gpsValue = assignedGps.isEmpty ? null : assignedGps.first.deviceUuid;
              final heartValue = assignedHeartId != null && heartCandidates.any((d) => d.id == assignedHeartId) ? assignedHeartId : null;

              Widget scanStateLine({required bool active, required int count, required String emptyText}) {
                return Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(top: 8),
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), border: Border.all(color: _TD.borderStrong)),
                  child: Row(children: [
                    if (active) ...[
                      const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: _TD.green)),
                      const SizedBox(width: 8),
                    ] else
                      Icon(count > 0 ? Icons.bluetooth_connected_rounded : Icons.bluetooth_searching_rounded, color: count > 0 ? _TD.green : _TD.muted, size: 16),
                    if (!active) const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        active ? 'Идёт сканирование Bluetooth… найдено: $count' : (count > 0 ? 'Найдено Bluetooth-устройств: $count' : emptyText),
                        style: const TextStyle(color: _TD.muted, fontSize: 10.4, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ]),
                );
              }

              Widget gpsDeviceList() {
                if (gpsCandidates.isEmpty) {
                  return scanStateLine(active: _scanning, count: 0, emptyText: 'Список GPS/BLE пока пуст. Нажмите «Сканировать GPS» — найденные датчики появятся прямо здесь.');
                }
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  scanStateLine(active: _scanning, count: gpsCandidates.length, emptyText: ''),
                  const SizedBox(height: 8),
                  ...gpsCandidates.map((d) {
                    final assignedToSelected = d.playerId == selected.id;
                    final free = d.playerId == null;
                    final owner = d.playerName ?? (free ? 'свободен' : 'игрок #${d.playerId}');
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Material(
                        color: assignedToSelected ? _TD.greenSoft : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () async {
                            await _assignTrackerDeviceToPlayer(d, selected);
                            if (mounted) setModalState(() {});
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: assignedToSelected ? _TD.greenBorder : _TD.borderStrong),
                            ),
                            child: Row(children: [
                              Icon(Icons.sensors_rounded, color: assignedToSelected ? _TD.green : _TD.graphite, size: 17),
                              const SizedBox(width: 8),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(d.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 11.2, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 2),
                                Text('${d.isNearby ? 'в зоне BLE' : 'сохранён'} · $owner', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.8, fontWeight: FontWeight.w700)),
                              ])),
                              Text(assignedToSelected ? 'назначен' : 'выбрать', style: TextStyle(color: assignedToSelected ? _TD.green : _TD.muted, fontSize: 9.8, fontWeight: FontWeight.w900)),
                            ]),
                          ),
                        ),
                      ),
                    );
                  }),
                ]);
              }

              Widget heartDeviceList() {
                if (heartCandidates.isEmpty) {
                  return scanStateLine(active: _scanningHeart, count: 0, emptyText: 'Список Polar/BLE пока пуст. Нажмите «Сканировать Polar» или «Все BLE рядом».');
                }
                return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  scanStateLine(active: _scanningHeart, count: heartCandidates.length, emptyText: ''),
                  const SizedBox(height: 8),
                  ...heartCandidates.map((d) {
                    final ownerId = _heartDevicePlayerIds[d.id];
                    final ownerList = ownerId == null ? const <TrackerPlayerOption>[] : _players.where((p) => p.id == ownerId).toList(growable: false);
                    final ownerName = ownerList.isEmpty ? 'свободен' : ownerList.first.name;
                    final assignedToSelected = ownerId == selected.id;
                    final connected = _heart.isConnected(d.id);
                    final sample = _heart.lastSampleForDevice(d.id);
                    final bpm = sample == null ? 'bpm —' : '${sample.bpm} bpm';
                    final marker = d.serviceHit ? 'Heart Rate' : (d.rawProbe ? 'BLE-кандидат' : 'Polar');
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 6),
                      child: Material(
                        color: assignedToSelected ? _TD.greenSoft : Colors.white,
                        borderRadius: BorderRadius.circular(14),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(14),
                          onTap: () async {
                            await _connectAndAssignHeartRate(d, selected);
                            if (mounted) setModalState(() {});
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: assignedToSelected ? _TD.greenBorder : _TD.borderStrong),
                            ),
                            child: Row(children: [
                              Icon(Icons.monitor_heart_rounded, color: assignedToSelected ? _TD.green : _TD.graphite, size: 17),
                              const SizedBox(width: 8),
                              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(d.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 11.2, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 2),
                                Text('$marker · $bpm · RSSI ${d.rssi} · $ownerName', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.8, fontWeight: FontWeight.w700)),
                              ])),
                              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                                Text(assignedToSelected ? 'назначен' : 'выбрать', style: TextStyle(color: assignedToSelected ? _TD.green : _TD.muted, fontSize: 9.8, fontWeight: FontWeight.w900)),
                                const SizedBox(height: 2),
                                Text(connected ? 'online' : 'подключить', style: TextStyle(color: connected ? _TD.green : _TD.dim, fontSize: 8.8, fontWeight: FontWeight.w800)),
                              ]),
                            ]),
                          ),
                        ),
                      ),
                    );
                  }),
                ]);
              }

              return ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(color: _TD.greenSoft, borderRadius: BorderRadius.circular(18), border: Border.all(color: _TD.greenBorder)),
                    child: Row(children: [
                      _PlayerAvatarDark(url: selected.avatar, initials: _playerInitials(selected.name), size: 42, active: true),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(selected.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 15, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 4),
                        Text(_equipmentStatusForPlayer(selected), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 11, fontWeight: FontWeight.w800)),
                      ])),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  _EquipmentAssignmentBox(
                    icon: Icons.sensors_rounded,
                    title: 'GPS-трекер',
                    subtitle: assignedGps.isEmpty ? 'можно оставить пустым: Live всё равно пойдёт по Polar' : 'назначено: ${assignedGps.map((d) => d.deviceName).join(', ')}',
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      DropdownButtonFormField<String?>(
                        value: gpsValue,
                        isExpanded: true,
                        decoration: _equipmentInput('Выбрать GPS-трекер'),
                        items: <DropdownMenuItem<String?>>[
                          const DropdownMenuItem<String?>(value: null, child: Text('Без GPS-трекера')),
                          ...gpsCandidates.map((d) {
                            final playerName = d.playerName ?? (d.playerId == null ? 'свободен' : 'игрок #${d.playerId}');
                            return DropdownMenuItem<String?>(
                              value: d.deviceUuid,
                              child: Text('${d.deviceName} · $playerName', maxLines: 1, overflow: TextOverflow.ellipsis),
                            );
                          }),
                        ],
                        onChanged: (value) async {
                          if (value == null) {
                            for (final d in assignedGps) {
                              await _assignTrackerDeviceToPlayer(d, null);
                            }
                          } else {
                            final device = gpsCandidates.firstWhere((d) => d.deviceUuid == value);
                            await _assignTrackerDeviceToPlayer(device, selected);
                          }
                          if (mounted) setModalState(() {});
                        },
                      ),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        _DarkActionButton(
                          icon: Icons.tablet_android_rounded,
                          label: _scanning ? 'Идёт поиск...' : 'Сканировать GPS',
                          primary: gpsCandidates.isEmpty,
                          onTap: _scanning
                              ? null
                              : () async {
                                  setModalState(() {});
                                  await _scan(clean: true, universalMode: true);
                                  if (mounted) setModalState(() {});
                                },
                        ),
                      ]),
                      gpsDeviceList(),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  _EquipmentAssignmentBox(
                    icon: Icons.monitor_heart_rounded,
                    title: 'Polar H10',
                    subtitle: assignedHeartId == null ? 'можно назначить Polar без GPS-трекера' : 'назначено: ${_heart.lastSampleForDevice(assignedHeartId)?.deviceName ?? _heart.connectedDevice(assignedHeartId)?.name ?? 'Polar H10'}',
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      DropdownButtonFormField<String?>(
                        value: heartValue,
                        isExpanded: true,
                        decoration: _equipmentInput('Выбрать Polar H10'),
                        items: <DropdownMenuItem<String?>>[
                          const DropdownMenuItem<String?>(value: null, child: Text('Без Polar H10')),
                          ...heartCandidates.map((d) {
                            final ownerId = _heartDevicePlayerIds[d.id];
                            final owner = ownerId == null ? null : _players.where((p) => p.id == ownerId).toList();
                            final ownerName = owner == null || owner.isEmpty ? 'свободен' : owner.first.name;
                            final sample = _heart.lastSampleForDevice(d.id);
                            final bpm = sample == null ? 'bpm —' : '${sample.bpm} bpm';
                            return DropdownMenuItem<String?>(
                              value: d.id,
                              child: Text('${d.name} · $bpm · $ownerName', maxLines: 1, overflow: TextOverflow.ellipsis),
                            );
                          }),
                        ],
                        onChanged: (value) async {
                          if (value == null) {
                            for (final entry in _heartDevicePlayerIds.entries.where((e) => e.value == selected.id).toList()) {
                              final dev = _heart.connectedDevice(entry.key) ?? heartById[entry.key];
                              if (dev != null) _bindHeartRateDeviceToPlayer(dev, null);
                            }
                          } else {
                            final device = heartCandidates.firstWhere((d) => d.id == value);
                            await _connectAndAssignHeartRate(device, selected);
                          }
                          if (mounted) setModalState(() {});
                        },
                      ),
                      const SizedBox(height: 8),
                      Wrap(spacing: 6, runSpacing: 6, children: [
                        _DarkActionButton(
                          icon: Icons.monitor_heart_rounded,
                          label: _scanningHeart ? 'Поиск Polar...' : 'Сканировать Polar',
                          primary: heartCandidates.isEmpty,
                          onTap: _scanningHeart
                              ? null
                              : () async {
                                  setModalState(() {});
                                  await _scanHeartRate();
                                  if (mounted) setModalState(() {});
                                },
                        ),
                        _DarkActionButton(
                          icon: Icons.radar_rounded,
                          label: 'Все BLE рядом',
                          onTap: _scanningHeart
                              ? null
                              : () async {
                                  setModalState(() {});
                                  await _scanHeartRate(showAllBleCandidates: true);
                                  if (mounted) setModalState(() {});
                                },
                        ),
                      ]),
                      heartDeviceList(),
                    ]),
                  ),
                  const SizedBox(height: 12),
                  const _DarkHint(text: 'У игрока может быть GPS-трекер, Polar H10 или оба датчика одновременно. Live запускается по команде: у кого есть GPS — пишется трек/скорость, у кого есть Polar — пишется пульс.'),
                ],
              );
            }

            return Dialog(
              backgroundColor: Colors.transparent,
              insetPadding: EdgeInsets.symmetric(horizontal: compact ? 8 : 24, vertical: compact ? 8 : 22),
              child: Container(
                constraints: BoxConstraints(maxWidth: 1040, maxHeight: compact ? MediaQuery.of(dialogContext).size.height - 24 : 720),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(24), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.18), blurRadius: 30, offset: const Offset(0, 18))]),
                child: Column(children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(18, 16, 12, 12),
                    child: Row(children: [
                      Container(width: 38, height: 38, alignment: Alignment.center, decoration: BoxDecoration(color: _TD.greenSoft, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.hub_rounded, color: _TD.green, size: 21)),
                      const SizedBox(width: 12),
                      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text('Оборудование команды', style: TextStyle(color: _TD.text, fontSize: 16, fontWeight: FontWeight.w900)),
                        SizedBox(height: 2),
                        Text('назначение GPS-трекеров и Polar H10 игрокам', style: TextStyle(color: _TD.muted, fontSize: 11, fontWeight: FontWeight.w700)),
                      ])),
                      IconButton(onPressed: () => Navigator.of(dialogContext).pop(), icon: const Icon(Icons.close_rounded, color: _TD.muted)),
                    ]),
                  ),
                  const _WorkspacePaneDivider.horizontal(),
                  Expanded(
                    child: StreamBuilder<List<ActionTrackerDevice>>(
                      stream: _ble.devicesStream,
                      builder: (_, gpsSnapshot) {
                        final gpsDevices = gpsSnapshot.data ?? const <ActionTrackerDevice>[];
                        return StreamBuilder<List<HeartRateBleDevice>>(
                          stream: _heart.devicesStream,
                          builder: (_, heartSnapshot) {
                            final heartDevices = heartSnapshot.data ?? _heart.connectedInfos;
                            if (compact) {
                              return ListView(
                                padding: const EdgeInsets.all(12),
                                children: [
                                  SizedBox(height: 250, child: playersList()),
                                  const SizedBox(height: 12),
                                  SizedBox(height: 430, child: assignmentPane(heartDevices, gpsDevices)),
                                ],
                              );
                            }
                            return Padding(
                              padding: const EdgeInsets.all(14),
                              child: Row(children: [
                                SizedBox(width: 330, child: playersList()),
                                const SizedBox(width: 14),
                                Expanded(child: assignmentPane(heartDevices, gpsDevices)),
                              ]),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ]),
              ),
            );
          },
        );
      },
    );
  }


  Future<void> _bindSavedDevice(TrackerDeviceModel device, TrackerPlayerOption? player) async {
    try {
      await _api.registerOrBindDevice(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: player?.id,
        deviceUuid: device.deviceUuid,
        deviceName: device.deviceName,
        batteryPercent: device.batteryPercent,
      );
      if (mounted) {
        setState(() {
          _selectedPlayer = player;
          _connected = _ble.connectedInfo;
          _selectedRecord = null;
          _points.clear();
        });
      }
      _toast('Датчик', player == null ? 'Привязка снята' : '${device.deviceName} → ${player.name}');
      await _loadServerData();
    } catch (e) {
      unawaited(_logRemote('Ошибка привязки датчика: $e', level: 'error', source: 'workspace_device_bind_error'));
      _toast('Датчик', '$e');
    }
  }

  Future<void> _forgetSavedDevice(TrackerDeviceModel device) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Удалить серверную запись?'),
        content: Text(
          'Это удалит только запись привязки на сервере: ${device.deviceName} / ${device.deviceUuid}. '
          'BLE-канал приложения и память самого GPS-трекера не меняются.',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Отмена')),
          FilledButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Удалить')),
        ],
      ),
    );
    if (confirmed != true) return;

    try {
      final result = await _api.forgetServerDevice(
        teamId: widget.teamId,
        deviceId: device.id,
        deviceUuid: device.deviceUuid,
        deviceName: device.deviceName,
      );
      final deleted = int.tryParse('${result['deleted'] ?? result['affected'] ?? 0}') ?? 0;
      _toast('Серверная запись', deleted > 0 ? 'Удалено записей: $deleted' : 'Запись очищена или уже отсутствовала');
      unawaited(_logRemote(
        'Удалена серверная запись датчика: ${device.deviceName} / ${device.deviceUuid} · deleted=$deleted',
        source: 'workspace_device_server_forget',
      ));
      await _loadServerData();
    } catch (e) {
      _toast('Удаление привязки', '$e');
      unawaited(_logRemote('Ошибка удаления серверной записи датчика: $e', level: 'error', source: 'workspace_device_server_forget_error'));
    }
  }

  Future<void> _requestGpsRecordsFromTracker() async {
    try {
      await TrackerPermissions.ensureBlePermissions();
      if (!_ble.commandChannelReady) {
        _toast('GPS-записи', 'Сначала подключите трекер: нужен реальный TX/RX канал');
        unawaited(_logRemote(
          'Запрос GPS-записей отменён: BLE TX/RX не готов',
          level: 'warning',
          source: 'workspace_offline_records_blocked',
        ));
        return;
      }
      setState(() => _trackerRecordingStatus = 'запрашиваю список записей с трекера');
      await _ble.requestRecordList();
      unawaited(_logRemote('Запрос GPS-записей с трекера отправлен', source: 'workspace_offline_records_request'));
      _toast('GPS-записи', 'Запрос отправлен. Список записей появится после ответа датчика.');
    } catch (e) {
      unawaited(_logRemote('Ошибка загрузки GPS-записей с трекера: $e', level: 'error', source: 'workspace_offline_records_error'));
      _toast('GPS-записи', '$e');
    }
  }


  String _formatTrackerRecordingStatus(List<ActionTrackerRecord> records) {
    if (records.isEmpty) return 'на датчике нет записей';
    final recording = records.where((r) => r.state == ActionTrackerRecordState.recording).toList();
    if (recording.isNotEmpty) {
      final r = recording.first;
      return 'идёт запись на трекере · file ${r.fileId} · ${r.length} байт';
    }
    final finished = records.where((r) => r.state == ActionTrackerRecordState.finished || r.length > 0).toList()
      ..sort((a, b) {
        final byEnd = b.endTimeMs.compareTo(a.endTimeMs);
        if (byEnd != 0) return byEnd;
        return b.fileId.compareTo(a.fileId);
      });
    if (finished.isNotEmpty) {
      final r = finished.first;
      return 'есть готовая запись · file ${r.fileId} · ${r.length} байт';
    }
    return 'запись на трекере не идёт';
  }

  String _offlineRecordKey(ActionTrackerDevice device, ActionTrackerRecord record) {
    return '${device.id}:${record.fileId}:${record.length}:${record.startDateRaw}:${record.startTimeMs}';
  }

  TrackerPlayerOption? _playerForConnectedTracker() {
    final id = (_connected ?? _ble.connectedInfo ?? _ble.lastKnownInfo)?.id;
    if (id == null || id.trim().isEmpty) return _selectedPlayer;
    final exact = _savedDevices.where((d) => d.deviceUuid == id && (d.playerId ?? 0) > 0).toList();
    if (exact.isEmpty) return _selectedPlayer;
    final playerId = exact.first.playerId;
    if (playerId == null || playerId <= 0) return _selectedPlayer;
    final players = _players.where((p) => p.id == playerId).toList();
    return players.isEmpty ? _selectedPlayer : players.first;
  }

  Future<void> _autoSyncLatestFinishedRecordIfNeeded() async {
    if (!mounted || _offlineAutoSyncInProgress || _savingRecord || !_ble.commandChannelReady) return;
    final connected = _connected ?? _ble.connectedInfo;
    if (connected == null) return;
    final finished = _records
        .where((r) => (r.state == ActionTrackerRecordState.finished || r.length > 0) && r.state != ActionTrackerRecordState.recording)
        .toList()
      ..sort((a, b) {
        final byEnd = b.endTimeMs.compareTo(a.endTimeMs);
        if (byEnd != 0) return byEnd;
        return b.fileId.compareTo(a.fileId);
      });
    if (finished.isEmpty) return;
    final record = finished.first;
    final key = _offlineRecordKey(connected, record);
    if (_offlineAutoSyncedRecordKeys.contains(key)) return;

    _offlineAutoSyncInProgress = true;
    _offlineAutoSyncKey = key;
    _trackerRecordingStatus = 'автовыгрузка: загружаю file ${record.fileId} с трекера';
    if (mounted) setState(() {});
    unawaited(_logRemote(
      'Автовыгрузка офлайн-записи: ${connected.name} / ${connected.id} · file=${record.fileId} · points_buffer=${_points.length}',
      source: 'workspace_offline_auto_sync_start',
    ));
    await _loadGpsRecord(record, autoSave: true);
  }

  Future<void> _finishOfflineAutoSyncAfterTransfer() async {
    if (!_offlineAutoSaveAfterTransfer || !_offlineAutoSyncInProgress) return;
    if (_selectedRecord == null || _points.length < 2) {
      _trackerRecordingStatus = 'запись загружена, но точек мало для сохранения';
      _offlineAutoSyncInProgress = false;
      _offlineAutoSaveAfterTransfer = false;
      _offlineAutoSyncKey = null;
      if (mounted) setState(() {});
      return;
    }
    _trackerRecordingStatus = 'сохраняю офлайн-запись на сервер';
    if (mounted) setState(() {});
    await _saveRecordAsSession(auto: true);
    if (mounted) {
      setState(() {
        _trackerRecordingStatus = 'офлайн-запись выгружена на сервер и попала в отчёт';
      });
    }
  }

  Future<void> _loadGpsRecord(ActionTrackerRecord record, {bool autoSave = false}) async {
    setState(() {
      _selectedRecord = record;
      _points.clear();
      _offlineAutoSaveAfterTransfer = autoSave;
    });
    try {
      await _ble.requestGpsRecord(record);
      _toast('GPS', autoSave ? 'Автовыгрузка записи началась' : 'Загрузка записи началась');
    } catch (e) {
      _offlineAutoSaveAfterTransfer = false;
      _offlineAutoSyncInProgress = false;
      _offlineAutoSyncKey = null;
      unawaited(_logRemote('Ошибка загрузки GPS-записи: $e', level: 'error', source: 'workspace_gps_record_error'));
      _toast('GPS', '$e');
    }
  }

  Future<void> _saveRecordAsSession({bool auto = false}) async {
    final connected = _connected ?? _ble.connectedInfo;
    final record = _selectedRecord;
    final player = _playerForConnectedTracker() ?? _selectedPlayer;
    if (connected == null || record == null || _points.length < 2) {
      _toast('Сессия', 'Нужно подключить трекер, выбрать запись и иметь GPS-точки');
      return;
    }
    setState(() => _savingRecord = true);
    try {
      final result = await _api.saveGpsSession(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: player?.id,
        deviceUuid: connected.id,
        deviceName: connected.name,
        fieldId: _selectedField?.id,
        record: record,
        points: _points,
      );
      final sessionId = int.tryParse('${result['session_id'] ?? result['existing_session_id'] ?? 0}') ?? 0;
      if (sessionId > 0 && result['already_exists'] != true) {
        try {
          await _api.processSession(sessionId: sessionId);
        } catch (_) {}
      }
      if (auto && _offlineAutoSyncKey != null) _offlineAutoSyncedRecordKeys.add(_offlineAutoSyncKey!);
      _toast('Сессия', result['already_exists'] == true ? 'Запись уже была на сервере' : 'Запись сохранена');
      await _loadServerData();
    } catch (e) {
      unawaited(_logRemote('Ошибка сохранения GPS-сессии: $e', level: 'error', source: 'workspace_session_save_error'));
      _toast('Сессия', '$e');
    } finally {
      if (auto) {
        _offlineAutoSyncInProgress = false;
        _offlineAutoSaveAfterTransfer = false;
        _offlineAutoSyncKey = null;
      }
      if (mounted) setState(() => _savingRecord = false);
    }
  }

  void _createNewFieldDraft() {
    final index = _fields.length + 1;
    setState(() {
      _selectedField = TrackerFieldModel(
        clubId: widget.clubId,
        teamId: widget.teamId,
        title: index <= 1 ? 'Основное поле' : 'Поле $index',
        lengthM: 105,
        widthM: 68,
        isDefault: true,
      );
      _calibrationCorners.clear();
    });
    _toast('Поле', 'Создано новое поле. Пройдите углы A → B → C → D и нажмите «Сохранить».');
  }

  void _resetCalibrationCorners() {
    setState(() => _calibrationCorners.clear());
    _toast('Калибровка', 'Точки A/B/C/D сброшены.');
  }

  Future<void> _handleCornerTap(int index) async {
    if (index != _calibrationCorners.length) {
      final labels = const ['A', 'B', 'C', 'D'];
      _toast('Калибровка', 'Сейчас нужна точка ${labels[_calibrationCorners.length.clamp(0, 3)]}. Идите по порядку A → B → C → D.');
      return;
    }
    await _captureCalibrationPoint();
  }

  Future<void> _captureCalibrationPoint() async {
    final labels = const ['A', 'B', 'C', 'D'];
    if (_calibrationCapturing) return;

    if (_calibrationCorners.length >= 4) {
      _toast('Калибровка', 'Все 4 точки уже получены. Нажмите «Сохранить» или «Сбросить».');
      return;
    }

    final nextIndex = _calibrationCorners.length;

    setState(() {
      _calibrationCapturing = true;
      _calibrationCapturingIndex = nextIndex;
    });

    try {
      final point = await _waitForFreshCalibrationPoint(nextIndex);
      if (point == null) {
        _toast('Калибровка', 'Трекер не дал свежую GPS-точку. Проверьте GPS/улицу и нажмите ещё раз.');
        await _logRemote(
          'Калибровка: нет свежей GPS-точки для ${labels[nextIndex]} · RX=$_lastWorkspaceRx · lastGPS=$_lastWorkspaceGps',
          level: 'warning',
          source: 'workspace_calibration_no_fresh_gps',
        );
        return;
      }

      final duplicateIndex = _tooCloseCalibrationCornerIndex(point);
      if (duplicateIndex != null) {
        final distance = _distanceMeters(_calibrationCorners[duplicateIndex], point);
        _toast(
          'Калибровка',
          'Координата почти такая же, как точка ${labels[duplicateIndex]} (${distance.toStringAsFixed(1)} м). Отойдите к следующему углу и дождитесь нового GPS.',
        );
        await _logRemote(
          'Калибровка: дубль угла ${labels[nextIndex]} ≈ ${labels[duplicateIndex]} · distance=${distance.toStringAsFixed(1)}m · lat=${point.latitude}, lng=${point.longitude}',
          level: 'warning',
          source: 'workspace_calibration_duplicate_point',
          rawHex: _lastWorkspaceRx == 'нет пакетов' ? null : _lastWorkspaceRx,
        );
        return;
      }

      setState(() {
        _calibrationCorners.add(point);
      });

      _showCalibrationFlash(labels[nextIndex]);
      await _logRemote(
        'Калибровка: точка ${labels[nextIndex]} сохранена (${_calibrationCorners.length}/4) · ${point.latitude.toStringAsFixed(6)}, ${point.longitude.toStringAsFixed(6)}',
        source: 'workspace_calibration_point_saved',
        rawHex: _lastWorkspaceRx == 'нет пакетов' ? null : _lastWorkspaceRx,
      );

      _toast(
        'Калибровка',
        'Точка ${labels[nextIndex]} сохранена (${_calibrationCorners.length}/4).',
      );
    } finally {
      if (mounted) {
        setState(() {
          _calibrationCapturing = false;
          _calibrationCapturingIndex = null;
        });
      }
    }
  }

  Future<void> _saveCapturedField() async {
    if (_calibrationCorners.length < 4) {
      _toast('Калибровка', 'Нужно 4 угла поля');
      return;
    }
    final field = TrackerFieldModel(
      id: _selectedField?.id,
      clubId: widget.clubId,
      teamId: widget.teamId,
      title: _selectedField?.title ?? 'Основное поле',
      lengthM: _selectedField?.lengthM ?? 105,
      widthM: _selectedField?.widthM ?? 68,
      cornerALat: _calibrationCorners[0].latitude,
      cornerALng: _calibrationCorners[0].longitude,
      cornerBLat: _calibrationCorners[1].latitude,
      cornerBLng: _calibrationCorners[1].longitude,
      cornerCLat: _calibrationCorners[2].latitude,
      cornerCLng: _calibrationCorners[2].longitude,
      cornerDLat: _calibrationCorners[3].latitude,
      cornerDLng: _calibrationCorners[3].longitude,
      isDefault: true,
    );
    try {
      final response = await _api.saveField(clubId: widget.clubId, teamId: widget.teamId, field: field);
      final responseData = response['data'];
      final responseFieldId = responseData is Map ? responseData['id'] : null;
      final savedId = int.tryParse('${response['field_id'] ?? response['id'] ?? responseFieldId ?? field.id ?? ''}');
      final optimisticField = TrackerFieldModel(
        id: savedId ?? field.id,
        clubId: field.clubId,
        teamId: field.teamId,
        title: field.title,
        lengthM: field.lengthM,
        widthM: field.widthM,
        cornerALat: field.cornerALat,
        cornerALng: field.cornerALng,
        cornerBLat: field.cornerBLat,
        cornerBLng: field.cornerBLng,
        cornerCLat: field.cornerCLat,
        cornerCLng: field.cornerCLng,
        cornerDLat: field.cornerDLat,
        cornerDLng: field.cornerDLng,
        isDefault: field.isDefault,
      );

      setState(() {
        _calibrationCorners.clear();
        _selectedField = optimisticField;
        final sameIndex = _fields.indexWhere((f) => (optimisticField.id != null && f.id == optimisticField.id) || f.title == optimisticField.title);
        if (sameIndex >= 0) {
          _fields[sameIndex] = optimisticField;
        } else {
          _fields.insert(0, optimisticField);
        }
      });

      _toast('Поле', 'Калибровка сохранена');
      await _logRemote(
        'Поле сохранено: id=${optimisticField.id ?? 'new'} title=${optimisticField.title} · A=${optimisticField.cornerALat?.toStringAsFixed(6)},${optimisticField.cornerALng?.toStringAsFixed(6)} · B=${optimisticField.cornerBLat?.toStringAsFixed(6)},${optimisticField.cornerBLng?.toStringAsFixed(6)} · C=${optimisticField.cornerCLat?.toStringAsFixed(6)},${optimisticField.cornerCLng?.toStringAsFixed(6)} · D=${optimisticField.cornerDLat?.toStringAsFixed(6)},${optimisticField.cornerDLng?.toStringAsFixed(6)} · response=$response',
        source: 'workspace_field_saved',
      );
      await _loadServerData();

      if (mounted && (_selectedField == null || _selectedField?.hasCalibration != true)) {
        setState(() {
          _selectedField = optimisticField;
          if (!_fields.any((f) => (optimisticField.id != null && f.id == optimisticField.id) || f.title == optimisticField.title)) {
            _fields.insert(0, optimisticField);
          }
        });
      }
    } catch (e) {
      await _logRemote('Ошибка сохранения поля: $e', level: 'error', source: 'workspace_field_save_error');
      _toast('Поле', '$e');
    }
  }

  Future<void> _saveSettingsPreset(TrackerSpeedSettings settings) async {
    try {
      await _api.saveSettings(teamId: widget.teamId, settings: settings);
      _toast('Настройки', 'Профиль ${_settingsPresetTitle(settings.preset)} сохранён');
      unawaited(_logRemote('Пороги трекера сохранены: preset=${settings.preset}', source: 'workspace_settings_saved', extra: settings.toJson()));
      setState(() {});
    } catch (e) {
      unawaited(_logRemote('Ошибка сохранения порогов: $e', level: 'error', source: 'workspace_settings_save_error', extra: settings.toJson()));
      _toast('Настройки', '$e');
    }
  }

  String _settingsPresetTitle(String preset) {
    switch (TrackerSpeedSettings.normalizePreset(preset)) {
      case 'u13':
        return 'U13 / Академия';
      case 'u17':
        return 'U17 / Полупрофи';
      case 'pro':
        return 'Профи / Элита';
      case 'custom':
        return 'Свой';
      default:
        return 'Юношеский';
    }
  }

  Future<bool> _confirmExitTrackerIfNeeded() async {
    if (!_liveRunning) return true;

    final action = await showDialog<_TrackerExitAction>(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          title: const Text(
            'Live-сессия активна',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          content: const Text(
            'Идёт Live-сессия трекера. Чтобы не потерять GPS/BLE точки и отчёт по нагрузке, выберите действие перед выходом.',
            style: TextStyle(height: 1.35, fontWeight: FontWeight.w500),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(_TrackerExitAction.stay),
              child: const Text('Остаться'),
            ),
            TextButton.icon(
              onPressed: () => Navigator.of(context).pop(_TrackerExitAction.pauseAndMinimize),
              icon: const Icon(Icons.pause_circle_outline_rounded, size: 17),
              label: const Text('Приостановить'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(_TrackerExitAction.exitWithoutSaving),
              child: const Text('Выйти без сохранения'),
            ),
            FilledButton.icon(
              style: FilledButton.styleFrom(
                backgroundColor: _TD.green,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _activeLiveSessionId == null
                  ? null
                  : () => Navigator.of(context).pop(_TrackerExitAction.saveAndExit),
              icon: const Icon(Icons.save_rounded, size: 16),
              label: const Text('Сохранить и выйти'),
            ),
          ],
        );
      },
    );

    if (action == null || action == _TrackerExitAction.stay) return false;

    if (action == _TrackerExitAction.pauseAndMinimize) {
      if (mounted) {
        setState(() {
          _livePauseRequestSignal++;
          _trackerWindowMinimized = true;
        });
      }
      _toast('Live', 'Сессия приостановлена. Окно трекера свернуто, данные не удалены.');
      return false;
    }

    if (action == _TrackerExitAction.exitWithoutSaving) {
      final id = _activeLiveSessionId;
      if (id != null) {
        try {
          await _liveApi.stopLiveSession(liveSessionId: id, createFinalSession: false);
        } catch (e) {
          _toast('Сессия', 'Не удалось закрыть Live без сохранения: $e');
          return false;
        }
      }
      if (mounted) {
        setState(() {
          _liveRunning = false;
          _activeLiveSessionId = null;
          _liveExitWithoutSaveRequestSignal++;
        });
      }
      _toast('Сессия', 'Live закрыт без создания финальной сессии');
      return true;
    }

    if (action == _TrackerExitAction.saveAndExit) {
      final id = _activeLiveSessionId;
      if (id != null) {
        try {
          await _liveApi.stopLiveSession(liveSessionId: id, createFinalSession: true);
          if (mounted) {
            setState(() {
              _liveRunning = false;
              _activeLiveSessionId = null;
              _liveStopRequestSignal++;
            });
          }
          _toast('Сессия', 'Live остановлен и сохранён');
        } catch (e) {
          _toast('Сессия', 'Не удалось сохранить перед выходом: $e');
          return false;
        }
      }
      return true;
    }

    return false;
  }

  Future<void> _selectSectionSafely(TrackerWorkspaceSection section) async {
    if (!mounted || section == _section) return;

    if (_liveRunning && _section == TrackerWorkspaceSection.live && section != TrackerWorkspaceSection.live) {
      final action = await showDialog<_TrackerLiveSwitchAction>(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          return AlertDialog(
            backgroundColor: Colors.white,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            title: const Text('Live-сессия продолжает идти', style: TextStyle(fontWeight: FontWeight.w900)),
            content: const Text(
              'Можно перейти в другой раздел, а Live оставить активным. Чтобы завершить тренировку полностью, нажмите «Сохранить и перейти».',
              style: TextStyle(height: 1.35, fontWeight: FontWeight.w600),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(_TrackerLiveSwitchAction.stayInLive),
                child: const Text('Остаться в Live'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(_TrackerLiveSwitchAction.keepRunning),
                child: const Text('Перейти, Live оставить'),
              ),
              FilledButton.icon(
                style: FilledButton.styleFrom(
                  backgroundColor: _TD.green,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: _activeLiveSessionId == null
                    ? null
                    : () => Navigator.of(context).pop(_TrackerLiveSwitchAction.saveAndSwitch),
                icon: const Icon(Icons.save_rounded, size: 16),
                label: const Text('Сохранить и перейти'),
              ),
            ],
          );
        },
      );

      if (action == null || action == _TrackerLiveSwitchAction.stayInLive) return;

      if (action == _TrackerLiveSwitchAction.saveAndSwitch) {
        final id = _activeLiveSessionId;
        if (id != null) {
          try {
            await _liveApi.stopLiveSession(liveSessionId: id, createFinalSession: true);
            if (!mounted) return;
            setState(() {
              _liveRunning = false;
              _activeLiveSessionId = null;
              _liveStopRequestSignal++;
            });
            _toast('Сессия', 'Live остановлен и сохранён');
          } catch (e) {
            _toast('Сессия', 'Не удалось сохранить перед переходом: $e');
            return;
          }
        }
      }
    }

    if (!mounted) return;
    setState(() => _section = section);
    final sectionIndex = _trackerVisibleSections.indexOf(section);
    if (_mobileSectionController.hasClients) {
      _mobileSectionController.animateToPage(sectionIndex, duration: const Duration(milliseconds: 220), curve: Curves.easeOutCubic);
    }
    if (section == TrackerWorkspaceSection.debug) {
      unawaited(_loadRemoteDebugLogs());
    }
  }

  void _selectSectionForMobile(TrackerWorkspaceSection section) {
    if (!mounted) return;
    setState(() => _section = section);
    final sectionIndex = _trackerVisibleSections.indexOf(section);
    if (sectionIndex >= 0 && _mobileSectionController.hasClients) {
      _mobileSectionController.animateToPage(
        sectionIndex,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOutCubic,
      );
    }
    if (section == TrackerWorkspaceSection.debug) {
      unawaited(_loadRemoteDebugLogs());
    }
  }

  void _openTrackerSection(TrackerWorkspaceSection section) {
    final width = MediaQuery.maybeOf(context)?.size.width ?? 1200;
    if (widget.embeddedInClubWorkspace && width < 720) {
      _selectSectionForMobile(section);
      return;
    }
    if (!mounted) return;
    setState(() => _section = section);
    if (section == TrackerWorkspaceSection.debug) {
      unawaited(_loadRemoteDebugLogs());
    }
  }

  Future<void> _handleBackPressed() async {
    final canClose = await _confirmExitTrackerIfNeeded();
    if (!mounted || !canClose) return;
    Navigator.of(context).maybePop();
  }

  Future<void> _closeTrackerWindowSafely() async {
    final canClose = await _confirmExitTrackerIfNeeded();
    if (!mounted || !canClose) return;
    if (widget.embeddedInClubWorkspace) {
      setState(() => _trackerWindowMinimized = true);
      return;
    }
    Navigator.of(context).maybePop();
  }

  void _toast(String title, String message) {
    if (!mounted) return;
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.white,
      colorText: _TD.text,
      borderColor: _TD.softLine,
      borderWidth: 1,
      icon: Icon(
        title.toLowerCase().contains('bluetooth')
            ? Icons.bluetooth_disabled_rounded
            : Icons.info_outline_rounded,
        color: _TD.graphiteSoft,
        size: 18,
      ),
      margin: const EdgeInsets.all(14),
      duration: const Duration(seconds: 4),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.embeddedInClubWorkspace) {
      return WillPopScope(
        onWillPop: _confirmExitTrackerIfNeeded,
        child: _buildEmbeddedTrackerProgram(),
      );
    }

    return WillPopScope(
      onWillPop: _confirmExitTrackerIfNeeded,
      child: Scaffold(
        backgroundColor: _TD.bg,
        body: SafeArea(
          child: Row(
            children: [
              _DarkRail(
                selected: _section,
                onSelect: (section) { _selectSectionSafely(section); },
                onBack: _handleBackPressed,
              ),
              Expanded(
                child: Column(
                  children: [
                    if (_section != TrackerWorkspaceSection.live)
                      _TopBar(
                        teamName: widget.teamName,
                        clubName: widget.clubName,
                        selectedPlayer: _selectedPlayer?.name ?? 'Игрок не выбран',
                        selectedSection: _section,
                        loading: _loading,
                        onRefresh: _loadServerData,
                      ),
                    Expanded(
                      child: Padding(
                        padding: _section == TrackerWorkspaceSection.live
                            ? EdgeInsets.zero
                            : const EdgeInsets.fromLTRB(0, 6, 6, 6),
                        child: _buildSection(),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmbeddedTrackerProgram() {
    if (_trackerWindowMinimized) {
      return _TrackerProgramCollapsedBar(
        clubName: widget.clubName,
        teamName: widget.teamName,
        liveRunning: _liveRunning,
        connected: _ble.commandChannelReady,
        onRestore: () => setState(() => _trackerWindowMinimized = false),
        onClose: _closeTrackerWindowSafely,
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final compactNav = constraints.maxWidth < 1180;
        final mobile = constraints.maxWidth < 720;
        final tablet = constraints.maxWidth >= 720 && constraints.maxWidth < 1180;
        // На планшете рабочая область важнее широкого меню: оставляем
        // иконки, как в компактном CMR, чтобы Live/PDF не превращались
        // в маленькие прокручиваемые окна. На ПК меню остаётся раскрытым.
        final forceIconNav = mobile || tablet || _trackerSideCollapsed;
        final navWidth = mobile ? 46.0 : (forceIconNav ? 52.0 : 156.0);

        if (mobile) {
          final sections = _trackerVisibleSections;
          final window = Container(
            clipBehavior: Clip.antiAlias,
            decoration: _TD.unifiedWindow(radius: _trackerWindowMaximized ? 12 : 18),
            child: Column(
              children: [
                _TrackerMobileHeader(
                  clubName: widget.clubName,
                  teamName: widget.teamName,
                  selectedPlayer: _selectedPlayer?.name ?? 'Игрок не выбран',
                  selected: _section,
                  loading: _loading,
                  liveRunning: _liveRunning,
                  connected: _ble.commandChannelReady,
                  onRefresh: _loadServerData,
                  onClose: _closeTrackerWindowSafely,
                  onMinimize: () => setState(() => _trackerWindowMinimized = true),
                ),
                const _WorkspacePaneDivider.horizontal(),
                _TrackerMobileTabs(
                  sections: sections,
                  selected: _section,
                  onSelect: _selectSectionForMobile,
                ),
                const _WorkspacePaneDivider.horizontal(),
                Expanded(
                  child: PageView.builder(
                    controller: _mobileSectionController,
                    itemCount: sections.length,
                    onPageChanged: (index) {
                      if (index < 0 || index >= sections.length) return;
                      final next = sections[index];
                      if (_section != next) {
                        setState(() => _section = next);
                        if (next == TrackerWorkspaceSection.debug) {
                          unawaited(_loadRemoteDebugLogs());
                        }
                      }
                    },
                    itemBuilder: (context, index) => _KeepAlivePage(child: _sectionWidget(sections[index])),
                  ),
                ),
              ],
            ),
          );

          return Container(
            decoration: _TD.workspaceBg(),
            padding: EdgeInsets.all(_trackerWindowMaximized ? 0 : 4),
            child: Stack(
              children: [
                Positioned.fill(child: window),
                Positioned(
                  right: _trackerWindowMaximized ? 6 : 10,
                  bottom: _trackerWindowMaximized ? 6 : 10,
                  child: _TrackerWindowCornerButton(
                    maximized: _trackerWindowMaximized,
                    onTap: () => setState(() => _trackerWindowMaximized = !_trackerWindowMaximized),
                  ),
                ),
              ],
            ),
          );
        }

        final window = Container(
          clipBehavior: Clip.antiAlias,
          decoration: _TD.unifiedWindow(radius: _trackerWindowMaximized ? 16 : 24),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SizedBox(
                width: navWidth,
                child: _TrackerProgramSidePanel(
                  clubName: widget.clubName,
                  teamName: widget.teamName,
                  selectedPlayer: _selectedPlayer?.name ?? 'Игрок не выбран',
                  selected: _section,
                  loading: _loading,
                  liveRunning: _liveRunning,
                  connected: _ble.commandChannelReady,
                  compact: forceIconNav,
                  collapsed: forceIconNav,
                  onSelect: (section) { _selectSectionSafely(section); },
                  onRefresh: _loadServerData,
                  onClose: _closeTrackerWindowSafely,
                  onMinimize: () => setState(() => _trackerWindowMinimized = true),
                  onToggleCollapsed: (compactNav || mobile) ? null : () => setState(() => _trackerSideCollapsed = !_trackerSideCollapsed),
                ),
              ),
              Container(width: 1, color: _TD.softLine),
              Expanded(child: _buildSection()),
            ],
          ),
        );

        return Container(
          decoration: _TD.workspaceBg(),
          padding: EdgeInsets.all(_trackerWindowMaximized ? 0 : (tablet ? 4 : 10)),
          child: Stack(
            children: [
              Positioned.fill(child: window),
              Positioned(
                right: _trackerWindowMaximized ? 8 : 18,
                bottom: _trackerWindowMaximized ? 8 : 18,
                child: _TrackerWindowCornerButton(
                  maximized: _trackerWindowMaximized,
                  onTap: () => setState(() => _trackerWindowMaximized = !_trackerWindowMaximized),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSection() {
    final sections = _trackerVisibleSections;
    return IndexedStack(
      index: math.max(0, sections.indexOf(_section)),
      sizing: StackFit.expand,
      children: sections.map(_sectionWidget).toList(growable: false),
    );
  }

  Widget _sectionWidget(TrackerWorkspaceSection section) {
    switch (section) {
      case TrackerWorkspaceSection.dashboard:
        return _dashboard();
      case TrackerWorkspaceSection.live:
        return _live();
      case TrackerWorkspaceSection.analytics:
        return _analytics();
      case TrackerWorkspaceSection.activity:
        return _activity();
      case TrackerWorkspaceSection.sessions:
        return _sessions();
      case TrackerWorkspaceSection.devices:
        return _devices();
      case TrackerWorkspaceSection.field:
        return _field();
      case TrackerWorkspaceSection.settings:
        return _settings();
      case TrackerWorkspaceSection.debug:
        return _debug();
    }
  }

  Widget _dashboard() {
    return FutureBuilder<TrackerDashboardModel>(
      future: _api.loadDashboard(teamId: widget.teamId),
      builder: (context, snapshot) {
        final dashboard = snapshot.data;
        final summary = dashboard?.summary ?? const <String, dynamic>{};
        final rows = dashboard?.players ?? const <TrackerPlayerLoadRow>[];
        final connected = _savedDevices.where((d) => d.playerId != null).length;
        final readyFields = _fields.where((f) => f.hasCalibration).length;
        final gpsReady = _points.isNotEmpty || _ble.commandChannelReady;

        return _DarkPage(
          title: 'Tracker Pro',
          subtitle: 'Профессиональный режим: подключение, Live, команда, отчёты и поле в одном рабочем сценарии',
          icon: Icons.dashboard_customize_rounded,
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _DarkActionButton(
                icon: Icons.play_arrow_rounded,
                label: 'Открыть Live',
                primary: true,
                onTap: () => _openTrackerSection(TrackerWorkspaceSection.live),
              ),
              const SizedBox(width: 4),
              _DarkActionButton(
                icon: Icons.sensors_rounded,
                label: 'Трекеры',
                onTap: () => _openTrackerSection(TrackerWorkspaceSection.devices),
              ),
            ],
          ),
          child: LayoutBuilder(
            builder: (context, c) {
              final compact = c.maxWidth < 920;
              final kpi = _dashboardKpis(summary, rows.length, connected, readyFields);
              final left = _DarkCard(
                title: 'Готовность команды',
                subtitle: '$connected/${_players.length} трекеров',
                child: Column(
                  children: [
                    _ReadinessRow(title: 'Игроки', text: _players.isEmpty ? 'Состав не загружен' : '${_players.length} игроков', ok: _players.isNotEmpty),
                    const SizedBox(height: 4),
                    _ReadinessRow(title: 'Трекеры', text: connected == 0 ? 'Подключите датчики' : '$connected подключено', ok: connected > 0),
                    const SizedBox(height: 4),
                    _ReadinessRow(title: 'Поле', text: readyFields == 0 ? 'Нужна калибровка' : '$readyFields готово', ok: readyFields > 0),
                    const SizedBox(height: 4),
                    _ReadinessRow(title: 'GPS', text: gpsReady ? 'Сигнал есть' : 'Ожидаем пакет', ok: gpsReady),
                    const Spacer(),
                    _DarkActionButton(
                      icon: Icons.sensors_rounded,
                      label: connected == 0 ? 'Подключить трекеры' : 'Управлять трекерами',
                      primary: connected == 0,
                      onTap: () => _openTrackerSection(TrackerWorkspaceSection.devices),
                    ),
                    const SizedBox(height: 4),
                    _DarkActionButton(
                      icon: Icons.map_rounded,
                      label: readyFields == 0 ? 'Настроить поле' : 'Проверить поле',
                      onTap: () => _openTrackerSection(TrackerWorkspaceSection.field),
                    ),
                  ],
                ),
              );

              final center = _DarkCard(
                title: 'Команда онлайн',
                subtitle: snapshot.connectionState == ConnectionState.waiting && dashboard == null ? 'загрузка' : '${rows.length} игроков в аналитике',
                child: rows.isEmpty
                    ? const _DarkEmpty(icon: Icons.groups_rounded, text: 'После подключения трекеров и запуска Live здесь появится таблица игроков.')
                    : ListView(
                        children: rows.take(12).map((p) {
                          return _DarkListTile(
                            icon: Icons.person_rounded,
                            avatarUrl: p.avatar,
                            initials: _playerInitials(p.playerName),
                            title: p.playerName,
                            subtitle: '${(p.distanceM / 1000).toStringAsFixed(2)} км · макс. ${p.maxSpeedKmh.toStringAsFixed(1)} км/ч · спринты ${p.sprintCount}',
                            trailing: 'анализ',
                            active: _selectedPlayer?.id == p.playerId,
                            onTap: () {
                              final matches = _players.where((x) => x.id == p.playerId).toList();
                              setState(() {
                                if (matches.isNotEmpty) _selectedPlayer = matches.first;
                                _section = TrackerWorkspaceSection.activity;
                              });
                            },
                          );
                        }).toList(),
                      ),
              );

              final right = _DarkCard(
                title: 'Рабочий сценарий',
                subtitle: 'профессиональный мониторинг',
                child: Column(
                  children: [
                    _ScenarioButton(step: '1', title: 'Подключить трекеры', text: 'Датчики и привязка к игрокам', icon: Icons.sensors_rounded, onTap: () => _openTrackerSection(TrackerWorkspaceSection.devices)),
                    const SizedBox(height: 4),
                    _ScenarioButton(step: '2', title: 'Проверить поле', text: 'Калибровка A/B/C/D', icon: Icons.map_rounded, onTap: () => _openTrackerSection(TrackerWorkspaceSection.field)),
                    const SizedBox(height: 4),
                    _ScenarioButton(step: '3', title: 'Начать Live', text: 'Поле, точки, зоны, сигналы', icon: Icons.play_arrow_rounded, onTap: () => _openTrackerSection(TrackerWorkspaceSection.live)),
                    const SizedBox(height: 4),
                    _ScenarioButton(step: '4', title: 'Аналитика Pro', text: 'Теплокарта, спринты, скорость, команда', icon: Icons.analytics_rounded, onTap: () => _openTrackerSection(TrackerWorkspaceSection.analytics)),
                    const SizedBox(height: 4),
                    _ScenarioButton(step: '5', title: 'Открыть отчёты', text: 'Сессии, таблицы, экспорт', icon: Icons.table_chart_rounded, onTap: () => _openTrackerSection(TrackerWorkspaceSection.sessions)),
                    const Spacer(),
                    const _DarkHint(text: 'Главная показывает команду и готовность. Live — только рабочий мониторинг. Активность — графики игрока. Сессии — отчёты и экспорт.'),
                  ],
                ),
              );

              final mobileList = c.maxWidth < 520;
              final content = compact
                  ? ListView(
                      children: [
                        Container(
                          height: 48,
                          padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
                          decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
                          child: _TrackerToolbarScroller(children: [
                            _DarkActionButton(icon: Icons.play_arrow_rounded, label: 'Live', primary: true, onTap: () => _openTrackerSection(TrackerWorkspaceSection.live)),
                            _DarkActionButton(icon: Icons.sensors_rounded, label: 'Трекеры', onTap: () => _openTrackerSection(TrackerWorkspaceSection.devices)),
                            _DarkActionButton(icon: Icons.table_chart_rounded, label: 'Отчёты', onTap: () => _openTrackerSection(TrackerWorkspaceSection.sessions)),
                            _DarkActionButton(icon: Icons.analytics_rounded, label: 'Аналитика', onTap: () => _openTrackerSection(TrackerWorkspaceSection.analytics)),
                          ]),
                        ),
                        SizedBox(height: 118, child: _DashboardKpiStrip(items: kpi)),
                        const _WorkspacePaneDivider.horizontal(),
                        SizedBox(height: 320, child: center),
                        const _WorkspacePaneDivider.horizontal(),
                        SizedBox(height: 270, child: left),
                        const _WorkspacePaneDivider.horizontal(),
                        SizedBox(height: 320, child: right),
                      ],
                    )
                  : Column(
                      children: [
                        SizedBox(height: 118, child: _DashboardKpiStrip(items: kpi)),
                        const SizedBox(height: 0),
                        Expanded(
                          child: Row(
                            children: [
                              Expanded(flex: 3, child: left),
                              const _WorkspacePaneDivider.vertical(),
                              Expanded(flex: 6, child: center),
                              const _WorkspacePaneDivider.vertical(),
                              Expanded(flex: 3, child: right),
                            ],
                          ),
                        ),
                      ],
                    );

              return content;
            },
          ),
        );
      },
    );
  }

  List<_DashboardKpiData> _dashboardKpis(Map<String, dynamic> summary, int analyticPlayers, int connected, int readyFields) {
    double d(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;
    int i(dynamic v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
    return [
      _DashboardKpiData(icon: Icons.groups_rounded, title: 'Игроки онлайн', value: '$connected/${_players.length}', subtitle: 'трекеры'),
      _DashboardKpiData(icon: Icons.route_rounded, title: 'Дистанция', value: '${(d(summary['total_distance_m']) / 1000).toStringAsFixed(2)} км', subtitle: 'команда'),
      _DashboardKpiData(icon: Icons.speed_rounded, title: 'Макс. скорость', value: '${d(summary['max_speed_kmh']).toStringAsFixed(1)}', subtitle: 'км/ч'),
      _DashboardKpiData(icon: Icons.local_fire_department_rounded, title: 'Спринты', value: '${i(summary['sprint_count'])}', subtitle: 'команда'),
      _DashboardKpiData(icon: Icons.monitor_heart_rounded, title: 'Нагрузка', value: d(summary['avg_load_score']).toStringAsFixed(1), subtitle: 'средняя'),
      _DashboardKpiData(icon: Icons.map_rounded, title: 'Поля', value: '$readyFields/${_fields.length}', subtitle: 'калибровка'),
    ];
  }

  Widget _live() {
    return TrackerLivePanel(
      key: ValueKey('live_${widget.clubId}_${widget.teamId}_$_livePanelKeySuffix'),
      clubId: widget.clubId,
      teamId: widget.teamId,
      teamName: widget.teamName,
      players: _players,
      selectedPlayer: _selectedPlayer,
      selectedField: _selectedField,
      ble: _ble,
      savedDevices: _savedDevices,
      heartRateByPlayerId: Map<int, HeartRateSample>.unmodifiable(_latestHeartByPlayerId),
      heartRateConnectedCount: _heart.connectedCount,
      batteryPercent: _batteryPercent,
      scanningBluetooth: _scanning,
      onScanBluetooth: _scanning ? null : () => _scan(clean: true, universalMode: true),
      onManageTrackers: () => _openTrackerSection(TrackerWorkspaceSection.devices),
      onLiveRunningChanged: (running) {
        if (!mounted || _liveRunning == running) return;
        setState(() {
          _liveRunning = running;
          if (running) {
            // Новая Live-сессия должна начинаться с чистой локальной траектории.
            // Иначе карта/локомоторика показывают хвосты предыдущего игрока/даты.
            _points.clear();
            _lastWorkspaceGpsPoint = null;
            _lastWorkspaceGpsAt = null;
            _lastWorkspaceGps = 'нет GPS';
          }
        });
        unawaited(_logRemote(
          running ? 'Live включён' : 'Live остановлен/поставлен на паузу',
          source: running ? 'workspace_live_started' : 'workspace_live_stopped',
        ));
        if (!running) {
          // После стопа Live сервер создаёт финальную сессию. Обновляем поля/устройства/сессии,
          // чтобы аналитика и календарь не показывали старые накопленные данные.
          Future<void>.delayed(const Duration(milliseconds: 800), () async {
            if (mounted) await _loadServerData();
          });
        }
      },
      pauseRequestSignal: _livePauseRequestSignal,
      stopRequestSignal: _liveStopRequestSignal,
      exitWithoutSaveRequestSignal: _liveExitWithoutSaveRequestSignal,
      startRequestSignal: _liveStartRequestSignal,
      onLiveSessionIdChanged: (id) {
        if (!mounted || _activeLiveSessionId == id) return;
        setState(() => _activeLiveSessionId = id);
        if (id != null) {
          unawaited(_logRemote('Live session id=$id', source: 'workspace_live_session'));
        }
      },
    );
  }

  void _requestLiveFromAnalytics() {
    final ctx = <String, dynamic>{
      'team_id': widget.teamId,
      'player_id': _selectedPlayer?.id,
      'field_id': _selectedField?.id,
      'live_running': _liveRunning,
      'live_session_id': _activeLiveSessionId,
      'ble_command_channel_ready': _ble.commandChannelReady,
      'local_points': _points.length,
    };

    unawaited(_logRemote(
      _liveRunning
          ? 'Аналитика: Live уже идёт, данные связаны с текущей сессией'
          : 'Аналитика: внешний запуск Live без перехода на отдельный экран',
      source: _liveRunning ? 'analytics_live_already_running' : 'analytics_live_start_signal',
      extra: ctx,
    ));

    if (_liveRunning) {
      _toast('Live', 'Live уже идёт. Аналитика связана с текущей сессией и продолжит получать точки.');
      return;
    }

    final width = MediaQuery.maybeOf(context)?.size.width ?? 1200;
    final openLivePanel = width < 720;
    setState(() {
      if (openLivePanel) _section = TrackerWorkspaceSection.live;
      _liveStartRequestSignal++;
    });
    _toast('Live', openLivePanel ? 'Открываю Live и запускаю запись.' : 'Запускаю Live из аналитики без перехода на другой экран.');
  }

  Widget _analytics() {
    return TrackerActionAnalyticsSuite(
      api: _api,
      teamId: widget.teamId,
      teamName: widget.teamName,
      players: _players,
      selectedPlayer: _selectedPlayer,
      selectedField: _selectedField,
      localPoints: List<ActionTrackerGpsPoint>.unmodifiable(_points),
      selectedSession: _selectedReportSession,
      onRefresh: () => setState(() {}),
      onSelectPlayer: (id) {
        final matches = _players.where((p) => p.id == id).toList();
        if (matches.isNotEmpty) setState(() => _selectedPlayer = matches.first);
      },
      onSelectSession: (session) => setState(() => _selectedReportSession = session),
      onOpenCalibration: () => _openTrackerSection(TrackerWorkspaceSection.field),
      onOpenSessions: () => _openTrackerSection(TrackerWorkspaceSection.sessions),
      onOpenLive: _requestLiveFromAnalytics,
      liveRunning: _liveRunning,
      commandChannelReady: _ble.commandChannelReady,
      offlineRecordsCount: _records.length,
      localPointsCount: _points.length,
      onRequestOfflineRecords: () {
        unawaited(() async {
          try {
            _pushLocalLog('OFFLINE GPS: запрос списка записей с датчика');
            await _ble.requestRecordList();
            await _logRemote('Офлайн GPS: запрос списка записей отправлен', source: 'workspace_offline_records_request');
            _toast('Офлайн GPS', 'Запрос списка записей отправлен');
          } catch (e) {
            await _logRemote('Офлайн GPS ошибка чтения записей: $e', level: 'error', source: 'workspace_offline_records_error');
            _toast('Офлайн GPS', '$e');
          }
        }());
      },
      onSaveOfflineSession: () => unawaited(_saveRecordAsSession()),
      onDebug: (message, context) => unawaited(_logRemote(message, source: 'workspace_gps_analytics', level: 'info', extra: context)),
    );
  }

  Widget _activity() {
    return TrackerPlayerActivityScreen(
      key: ValueKey('activity_${widget.clubId}_${widget.teamId}_${_selectedPlayer?.id ?? 0}_${_selectedField?.id ?? 0}'),
      teamId: widget.teamId,
      teamName: widget.teamName,
      rosterPlayers: _players,
      selectedPlayer: _selectedPlayer,
      fieldId: _selectedField?.id,
    );
  }

  Widget _sessions() {
    Future<void> processSession(TrackerSessionModel session) async {
      try {
        await _api.processSession(sessionId: session.id);
        _toast('Сессия', 'Обработка запущена');
        setState(() {});
      } catch (e) {
        _toast('Сессия', '$e');
      }
    }

    return LayoutBuilder(
      builder: (context, outer) {
        final compact = outer.maxWidth < 980;
        if (compact) {
          // На телефоне не держим вторую тяжёлую шапку «Отчёты / сессии» и большую строку действий.
          // Сессия, обработка, экспорт и загрузка доступны в компактной панели самого мобильного отчёта.
          return _DarkPage(
            title: '',
            subtitle: '',
            icon: Icons.table_chart_rounded,
            child: _MobileSessionsReportPane(
              api: _api,
              teamId: widget.teamId,
              teamName: widget.teamName,
              selectedSession: _selectedReportSession,
              onSelect: (session) => setState(() => _selectedReportSession = session),
              onProcess: processSession,
              onRefresh: () => setState(() {}),
              onDownloadRecords: _requestGpsRecordsFromTracker,
              onSaveGps: _savingRecord ? null : _saveRecordAsSession,
              savingRecord: _savingRecord,
            ),
          );
        }

        return _DarkPage(
          title: 'Отчёты / сессии',
          subtitle: 'календарь тренировок, расшифровка, PDF и Excel',
          icon: Icons.table_chart_rounded,
          trailing: _TrackerToolbarScroller(children: [
            _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () => setState(() {})),
            _DarkActionButton(
              icon: Icons.download_rounded,
              label: 'Загрузить записи',
              primary: true,
              onTap: _requestGpsRecordsFromTracker,
            ),
            _DarkActionButton(
              icon: Icons.save_alt_rounded,
              label: _savingRecord ? 'Сохраняю...' : 'Сохранить GPS',
              onTap: _savingRecord ? null : _saveRecordAsSession,
            ),
          ]),
          child: LayoutBuilder(
            builder: (context, constraints) {
              final sessionsList = _SessionsListPane(
                api: _api,
                teamId: widget.teamId,
                playerId: null,
                selectedSession: _selectedReportSession,
                onSelect: (session) => setState(() => _selectedReportSession = session),
                onProcess: processSession,
              );
              final report = _SelectedTrainingReportPane(
                session: _selectedReportSession,
                teamId: widget.teamId,
                teamName: widget.teamName,
              );

              return Row(children: [
                Expanded(flex: 4, child: sessionsList),
                const _WorkspacePaneDivider.vertical(),
                Expanded(flex: 9, child: report),
              ]);
            },
          ),
        );
      },
    );
  }


  String _normalizeTrackerName(String value) {
    final v = value.trim().toUpperCase();
    if (v.isEmpty) return '';
    return v.replaceAll(RegExp(r'\s+'), ' ');
  }

  String _normalizeDeviceId(String value) {
    return value.trim().toUpperCase().replaceAll(RegExp(r'[^0-9A-F]'), '');
  }

  String _savedDeviceGroupKey(TrackerDeviceModel device) {
    final name = _normalizeTrackerName(device.deviceName);
    final id = _normalizeDeviceId(device.deviceUuid);
    // iOS/macOS может хранить один и тот же датчик как UUID, а сам датчик отдаёт MAC.
    // Для $ATP/$ACT/$GPS объединяем по имени, чтобы не показывать две одинаковые карточки.
    if (name.startsWith(r'$ATP') || name.startsWith(r'$ACT') || name.startsWith(r'$GPS')) {
      return 'name:$name';
    }
    return id.isEmpty ? 'name:$name' : 'id:$id';
  }

  bool _trackerIdOrNameMatches(String uuid, String name, TrackerDeviceModel device) {
    final a = _normalizeDeviceId(uuid);
    final b = _normalizeDeviceId(device.deviceUuid);
    if (a.isNotEmpty && b.isNotEmpty) {
      if (a == b) return true;
      if (a.length >= 12 && b.length >= 12 && (a.endsWith(b) || b.endsWith(a))) return true;
    }
    final rn = _normalizeTrackerName(name);
    final dn = _normalizeTrackerName(device.deviceName);
    return rn.isNotEmpty && dn.isNotEmpty && rn == dn;
  }

  List<TrackerDeviceModel> get _mergedSavedDevices {
    final byKey = <String, TrackerDeviceModel>{};
    for (final device in _savedDevices) {
      final key = _savedDeviceGroupKey(device);
      final old = byKey[key];
      if (old == null) {
        byKey[key] = device;
        continue;
      }
      // Предпочитаем запись с игроком и более «родным» MAC-like id, если она есть.
      final oldHasPlayer = old.playerId != null || (old.playerName ?? '').trim().isNotEmpty;
      final newHasPlayer = device.playerId != null || (device.playerName ?? '').trim().isNotEmpty;
      final oldLooksMac = old.deviceUuid.contains(':');
      final newLooksMac = device.deviceUuid.contains(':');
      if ((!oldHasPlayer && newHasPlayer) || (!oldLooksMac && newLooksMac)) {
        byKey[key] = device;
      }
    }
    return byKey.values.toList(growable: false);
  }

  int _savedDeviceAliasCount(TrackerDeviceModel device) {
    final key = _savedDeviceGroupKey(device);
    return _savedDevices.where((d) => _savedDeviceGroupKey(d) == key).length;
  }

  String _savedDeviceStatus(TrackerDeviceModel device) {
    final connected = _ble.commandChannelReady && _ble.connectedInfo != null &&
        _trackerIdOrNameMatches(_ble.connectedInfo!.id, _ble.connectedInfo!.name, device);
    if (connected) return 'реальный BLE TX/RX готов';
    final remote = _remoteConnectedTrackers.any((r) => _trackerIdOrNameMatches(r.uuid, r.name, device));
    if (remote) return 'реально занят: другое окно/устройство';
    if (device.playerId != null || (device.playerName ?? '').trim().isNotEmpty) return 'только серверная запись: игрок назначен';
    return 'только серверная запись: без игрока';
  }

  Color _savedDeviceStatusColor(TrackerDeviceModel device) {
    final status = _savedDeviceStatus(device);
    if (status.contains('TX/RX')) return _TD.green;
    if (status.contains('занят')) return _TD.orange;
    return _TD.muted;
  }

  bool _isBleDebugMap(Map<String, dynamic> log) {
    final text = '${log['message'] ?? ''} ${log['source'] ?? ''}'.toLowerCase();
    return text.contains('ble') || text.contains('scan') || text.contains('gps sensor') || text.contains('tracker') || text.contains('connect') || text.contains('rx') || text.contains('tx');
  }

  List<String> get _localBleDebugLines => _logs
      .where((line) {
        final lower = line.toLowerCase();
        return lower.contains('ble') || lower.contains('scan') || lower.contains('gps') || lower.contains('rx') || lower.contains('tx') || lower.contains('подключ');
      })
      .take(24)
      .toList(growable: false);

  Widget _scanDebugCard({required bool compact}) {
    final remote = _remoteDebugLogs.where(_isBleDebugMap).take(18).toList(growable: false);
    final local = _localBleDebugLines.take(compact ? 8 : 10).toList(growable: false);
    return _DarkCard(
      title: 'Онлайн debug поиска',
      subtitle: _remoteConsoleSubtitle(),
      child: Column(children: [
        Row(children: [
          Expanded(
            child: _DarkHint(
              text: 'Здесь видно поиск с этого планшета и других устройств команды: разрешения, raw_seen, кандидаты, ошибки подключения и TX/RX. Если raw_seen=0 — устройство вообще не видит BLE вокруг.',
            ),
          ),
          const SizedBox(width: 4),
          _DarkActionButton(icon: Icons.refresh_rounded, label: _remoteDebugLoading ? '...' : 'Логи', onTap: _remoteDebugLoading ? null : () => _loadRemoteDebugLogs()),
          const SizedBox(width: 4),
          _DarkActionButton(icon: Icons.restart_alt_rounded, label: _scanning ? 'Поиск...' : 'Сброс + поиск', primary: true, onTap: _scanning ? null : () => _scan(clean: true, universalMode: true)),
        ]),
        const SizedBox(height: 6),
        Expanded(
          child: remote.isEmpty && local.isEmpty
              ? const _DarkEmpty(icon: Icons.terminal_rounded, text: 'Пока нет debug-строк. Нажмите «Сброс + поиск» — появятся adapter, raw_seen, кандидаты и причина, почему трекер не найден.')
              : ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    if (remote.isNotEmpty)
                      const Padding(
                        padding: EdgeInsets.only(bottom: 4),
                        child: Text('Сервер / другие устройства', style: TextStyle(color: _TD.greenDark, fontSize: 10.2, fontWeight: FontWeight.w900)),
                      ),
                    ...remote.map((log) {
                      final level = '${log['level'] ?? 'info'}';
                      final message = '${log['message'] ?? ''}'.trim();
                      final source = '${log['source'] ?? ''}'.trim();
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 5),
                        child: Text(
                          '${_remoteLogTimeLabel(log)} [$level] $source · ${message.isEmpty ? '—' : message}',
                          maxLines: compact ? 2 : 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: _TD.muted, fontFamily: 'monospace', fontSize: 9.2, fontWeight: FontWeight.w600),
                        ),
                      );
                    }),
                    if (local.isNotEmpty) ...[
                      const SizedBox(height: 5),
                      const Padding(
                        padding: EdgeInsets.only(bottom: 4),
                        child: Text('Локально', style: TextStyle(color: _TD.greenDark, fontSize: 10.2, fontWeight: FontWeight.w900)),
                      ),
                      ...local.map((line) => Padding(
                            padding: const EdgeInsets.only(bottom: 5),
                            child: Text(
                              line,
                              maxLines: compact ? 2 : 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: _TD.muted, fontFamily: 'monospace', fontSize: 9.2, fontWeight: FontWeight.w600),
                            ),
                          )),
                    ],
                  ],
                ),
        ),
      ]),
    );
  }

  Widget _devices() {
    Widget nearbyCard({required bool compact}) {
      return _DarkCard(
        title: 'Трекеры рядом',
        subtitle: _remoteConnectedTrackers.isEmpty
            ? (_ble.commandChannelReady ? (_ble.connectedInfo?.name ?? 'подключён') : 'не подключён')
            : 'рядом + ${_remoteConnectedTrackers.length} удалённо подключён',
        child: Column(children: [
          if (_remoteConnectedTrackers.isNotEmpty) ...[
            _RemoteConnectedTrackersStrip(
              items: _remoteConnectedTrackers,
              onRefresh: () => _loadRemoteDebugLogs(silent: true),
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          _DarkListTile(
            icon: _ble.commandChannelReady ? Icons.cloud_done_rounded : Icons.cloud_sync_rounded,
            title: _ble.commandChannelReady ? 'BLE в зоне · сервер обновляется' : 'Трекер вне зоны · Live не остановлен',
            subtitle: '${_trackerRecordingStatus}${_lastRecordListAt == null ? '' : ' · проверено ${DateTime.now().difference(_lastRecordListAt!).inSeconds}с назад'}',
            active: _ble.commandChannelReady,
            trailing: _offlineAutoSyncInProgress ? 'sync' : (_ble.commandChannelReady ? 'готово' : 'ожидание'),
            onTap: _ble.commandChannelReady ? _requestGpsRecordsFromTracker : null,
          ),
          const _WorkspacePaneDivider.horizontal(),
          if (compact) ...[
            const _DarkHint(
              text: 'Найти трекер: единый поиск для всех планшетов. Сначала очищает локальный BLE-канал, затем ищет быстро и расширенно, показывает кандидатов и проверяет TX/RX после подключения.',
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          Expanded(
            child: StreamBuilder<List<ActionTrackerDevice>>(
              stream: _ble.devicesStream,
              builder: (context, snapshot) {
                final devices = snapshot.data ?? const <ActionTrackerDevice>[];
                if (_scanning) return const Center(child: CircularProgressIndicator());
                if (devices.isEmpty) {
                  return _DarkEmpty(
                    icon: _remoteConnectedTrackers.isEmpty ? Icons.bluetooth_disabled_rounded : Icons.sensors_off_rounded,
                    text: _remoteConnectedTrackers.isEmpty
                        ? 'Нажмите «Найти трекер». Это единая кнопка: сброс локального BLE + быстрый поиск + расширенный поиск кандидатов.'
                        : 'Рядом не найден, но выше видно, что трекер уже подключён в другом окне/устройстве.',
                  );
                }
                return ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: devices.length,
                  itemBuilder: (context, index) {
                    final d = devices[index];
                    final active = _ble.commandChannelReady && _ble.connectedInfo?.id == d.id;
                    final remote = _remoteConnectedTrackers.where((r) => r.uuid == d.id).toList();
                    final remoteText = remote.isEmpty ? '' : ' · удалённо: ${remote.first.playerName ?? remote.first.teamName ?? 'другое окно'}';
                    return _DarkListTile(
                      icon: active ? Icons.check_circle_rounded : Icons.sensors_rounded,
                      title: d.name,
                      subtitle: '${d.id} · RSSI ${d.rssi}$remoteText',
                      active: active,
                      trailing: active ? 'подключено' : (remote.isEmpty ? 'подключить' : 'занят'),
                      onTap: active || _connecting ? null : () => _connect(d),
                    );
                  },
                );
              },
            ),
          ),
        ]),
      );
    }


    Widget heartRateCard({required bool compact}) {
      String boundPlayerName(String deviceId) {
        final playerId = _heartDevicePlayerIds[deviceId];
        if (playerId == null || playerId <= 0) return 'игрок не выбран';
        final matches = _players.where((p) => p.id == playerId).toList();
        return matches.isEmpty ? 'игрок #$playerId' : matches.first.name;
      }

      final connectedList = _heart.connectedInfos;
      final connectedCount = connectedList.length;
      final selectedId = _selectedHeartDeviceId ?? _heart.connectedInfo?.id ?? _connectedHeart?.id;
      final selectedDevice = selectedId == null ? null : (_heart.connectedDevice(selectedId) ?? _heart.connectedInfo ?? _connectedHeart);
      final selectedSample = selectedId == null ? null : _heart.lastSampleForDevice(selectedId);
      final selectedText = _selectedPlayer == null ? 'выберите игрока в составе' : 'назначить: ${_selectedPlayer!.name}';
      final bpmText = selectedSample == null ? 'bpm нет' : '${selectedSample.bpm} bpm';

      return _DarkCard(
        title: 'Пульсометры Polar H10',
        subtitle: connectedCount == 0
            ? 'не подключены · можно подключить до 12 H10 на команду'
            : 'подключено $connectedCount/12 · ${selectedDevice?.name ?? connectedList.last.name} · $bpmText · ${selectedDevice == null ? 'игрок не выбран' : boundPlayerName(selectedDevice.id)}',
        child: Column(children: [
          if (compact) ...[
            const _DarkHint(
              text: 'Polar H10 подключаются отдельно от GPS-трекеров. Для команды: найти H10 → подключить → выбрать игрока → назначить → повторить для следующего датчика.',
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 8),
            child: Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _DarkActionButton(
                  icon: Icons.monitor_heart_rounded,
                  label: _scanningHeart ? 'Поиск Polar...' : 'Найти Polar H10',
                  primary: true,
                  onTap: _scanningHeart ? null : () => _scanHeartRate(),
                ),
                _DarkActionButton(
                  icon: Icons.radar_rounded,
                  label: 'Показать все BLE рядом',
                  onTap: _scanningHeart ? null : () => _scanHeartRate(showAllBleCandidates: true),
                ),
                _DarkActionButton(
                  icon: Icons.hub_rounded,
                  label: 'Назначить игрокам',
                  onTap: () => _openTeamEquipmentModal(),
                ),
                _DarkActionButton(
                  icon: Icons.restart_alt_rounded,
                  label: 'Сброс пульса',
                  onTap: _resetHeartRateState,
                ),
              ],
            ),
          ),
          if (_latestHeartByPlayerId.isNotEmpty) ...[
            SizedBox(
              height: compact ? 86 : 96,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: _latestHeartByPlayerId.entries.map((entry) {
                  final player = _players.where((p) => p.id == entry.key).toList();
                  final name = player.isEmpty ? 'Игрок ${entry.key}' : player.first.name;
                  final sample = entry.value;
                  final fresh = DateTime.now().difference(sample.measuredAt).inSeconds <= 20;
                  return Container(
                    width: 152,
                    margin: const EdgeInsets.only(right: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: const Color(0xFFF6F8FA), borderRadius: BorderRadius.circular(14)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Row(children: [
                          Icon(Icons.favorite_rounded, size: 15, color: fresh ? const Color(0xFFE11D48) : const Color(0xFF8A94A6)),
                          const SizedBox(width: 5),
                          Expanded(child: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: _TD.text))),
                        ]),
                        const SizedBox(height: 7),
                        Text('${sample.bpm} bpm', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: _TD.text)),
                        const SizedBox(height: 2),
                        Text(fresh ? 'online · ${sample.deviceName}' : 'устарело · ${sample.deviceName}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 9.5, color: _TD.muted)),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          Expanded(
            child: StreamBuilder<List<HeartRateBleDevice>>(
              stream: _heart.devicesStream,
              builder: (context, snapshot) {
                final devices = snapshot.data ?? const <HeartRateBleDevice>[];
                if (_scanningHeart) return const Center(child: CircularProgressIndicator());
                if (devices.isEmpty) {
                  return const _DarkEmpty(
                    icon: Icons.monitor_heart_outlined,
                    text: 'Нажмите «Найти Polar H10». Если пусто — нажмите «Показать все BLE рядом» и попробуйте ближайший кандидат с сильным RSSI. H10 должен быть надет на грудь.',
                  );
                }
                return ListView.builder(
                  padding: EdgeInsets.zero,
                  itemCount: devices.length,
                  itemBuilder: (context, index) {
                    final d = devices[index];
                    final active = _heart.isConnected(d.id);
                    final selected = selectedId == d.id;
                    final sample = _heart.lastSampleForDevice(d.id);
                    final sampleText = sample == null ? 'bpm нет' : '${sample.bpm} bpm';
                    final boundId = _heartDevicePlayerIds[d.id];
                    return _HeartRateDeviceDarkTile(
                      device: d,
                      active: active,
                      selected: selected,
                      connecting: _connectingHeart,
                      players: _players,
                      selectedPlayerId: boundId,
                      sampleText: sampleText,
                      onSelect: () => setState(() => _selectedHeartDeviceId = d.id),
                      onConnect: _connectingHeart
                          ? null
                          : () {
                              setState(() => _selectedHeartDeviceId = d.id);
                              if (!active) unawaited(_connectHeartRate(d));
                            },
                      onPlayerChanged: (playerId) => _bindHeartRateDeviceToPlayer(d, playerId),
                    );
                  },
                );
              },
            ),
          ),
        ]),
      );
    }

    Widget bindingsCard() {
      return _DarkCard(
        title: 'Архив привязок (не BLE)',
        subtitle: _hideSavedDevices
            ? '${_savedDevices.length} привязок скрыто'
            : '${_mergedSavedDevices.length} карточек · ${_savedDevices.length} записей на сервере',
        child: Column(children: [
          _DarkActionButton(
            icon: _hideSavedDevices ? Icons.visibility_rounded : Icons.visibility_off_rounded,
            label: _hideSavedDevices ? 'Показать архив' : 'Скрыть архив',
            onTap: () => setState(() => _hideSavedDevices = !_hideSavedDevices),
          ),
          const SizedBox(height: 4),
          const _DarkHint(
            text: 'Это архив записей на сервере, а не живое подключение. Если здесь виден трекер без игрока — он не «завис» локально, это старая серверная запись. Её можно удалить кнопкой «Удалить запись». Аппаратный сброс самого GPS выполняется только на устройстве.',
          ),
          const _WorkspacePaneDivider.horizontal(),
          Expanded(
            child: _hideSavedDevices
                ? const _DarkEmpty(icon: Icons.visibility_off_rounded, text: 'Архив скрыт, чтобы не путать старые серверные записи с реальным BLE-подключением.')
                : (_mergedSavedDevices.isEmpty
                    ? const _DarkEmpty(icon: Icons.sensors_off_rounded, text: 'После подключения или привязки датчик появится здесь.')
                    : ListView.builder(
                        padding: EdgeInsets.zero,
                        itemCount: _mergedSavedDevices.length,
                        itemBuilder: (context, index) {
                          final d = _mergedSavedDevices[index];
                          return _SavedDeviceDarkTile(
                            device: d,
                            players: _players,
                            onBind: (p) => _bindSavedDevice(d, p),
                            onForget: () => _forgetSavedDevice(d),
                            aliasCount: _savedDeviceAliasCount(d),
                            status: _savedDeviceStatus(d),
                            statusColor: _savedDeviceStatusColor(d),
                          );
                        },
                      )),
          ),
        ]),
      );
    }

    Widget rosterCard() {
      return _DarkCard(
        title: 'Привязка состава',
        subtitle: '${_players.length} игроков',
        child: _players.isEmpty
            ? const _DarkEmpty(icon: Icons.groups_rounded, text: 'Игроки не загружены.')
            : ListView.builder(
                padding: EdgeInsets.zero,
                itemCount: _players.length,
                itemBuilder: (context, index) {
                  final p = _players[index];
                  return _DarkListTile(
                    icon: Icons.person_rounded,
                    avatarUrl: p.avatar,
                    initials: _playerInitials(p.name),
                    title: p.name,
                    subtitle: _equipmentStatusForPlayer(p),
                    active: _selectedPlayer?.id == p.id,
                    trailing: p.number == null ? null : '#${p.number}',
                    onTap: () => _openTeamEquipmentModal(initialPlayer: p),
                  );
                },
              ),
      );
    }

    Widget mobileBleActions() {
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
        decoration: const BoxDecoration(
          color: _TD.panel,
          border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Поиск трекера',
              style: TextStyle(color: _TD.text, fontSize: 11.2, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                _DarkActionButton(icon: Icons.hub_rounded, label: 'Назначить игрокам', primary: true, onTap: () => _openTeamEquipmentModal()),
                _DarkActionButton(icon: Icons.tablet_android_rounded, label: _scanning ? 'Идёт поиск...' : 'Найти трекер', primary: true, onTap: _scanning ? null : () => _scan(clean: true, universalMode: true)),
                _DarkActionButton(icon: Icons.monitor_heart_rounded, label: _scanningHeart ? 'Поиск Polar...' : 'Найти Polar H10', primary: true, onTap: _scanningHeart ? null : () => _scanHeartRate()),
                _DarkActionButton(icon: Icons.radar_rounded, label: 'Все BLE рядом', onTap: _scanningHeart ? null : () => _scanHeartRate(showAllBleCandidates: true)),
                _DarkActionButton(icon: Icons.restart_alt_rounded, label: 'Сброс BLE', onTap: _resetBleState),
                _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () { _loadServerData(); _loadRemoteDebugLogs(silent: true); }),
              ],
            ),
          ],
        ),
      );
    }

    return _DarkPage(
      title: 'Датчики / BLE',
      subtitle: 'поиск, подключение, привязка игроков и датчиков',
      icon: Icons.sensors_rounded,
      trailing: _TrackerToolbarScroller(children: [
        _DarkActionButton(icon: Icons.hub_rounded, label: 'Назначить игрокам', primary: true, onTap: () => _openTeamEquipmentModal()),
        _DarkActionButton(icon: Icons.restart_alt_rounded, label: 'Сбросить локальный BLE', onTap: _resetBleState),
        _DarkActionButton(icon: Icons.tablet_android_rounded, label: _scanning ? 'Идёт поиск...' : 'Найти трекер', primary: true, onTap: _scanning ? null : () => _scan(clean: true, universalMode: true)),
        _DarkActionButton(icon: Icons.monitor_heart_rounded, label: _scanningHeart ? 'Поиск Polar...' : 'Найти Polar H10', primary: true, onTap: _scanningHeart ? null : () => _scanHeartRate()),
        _DarkActionButton(icon: Icons.radar_rounded, label: 'Все BLE рядом', onTap: _scanningHeart ? null : () => _scanHeartRate(showAllBleCandidates: true)),
        _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () { _loadServerData(); _loadRemoteDebugLogs(silent: true); }),
      ]),
      child: LayoutBuilder(builder: (context, constraints) {
        final compact = constraints.maxWidth < 820;
        if (compact) {
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              mobileBleActions(),
              SizedBox(height: 340, child: nearbyCard(compact: true)),
              const _WorkspacePaneDivider.horizontal(),
              SizedBox(height: 360, child: heartRateCard(compact: true)),
              const _WorkspacePaneDivider.horizontal(),
              SizedBox(height: 320, child: bindingsCard()),
              const _WorkspacePaneDivider.horizontal(),
              SizedBox(height: 340, child: rosterCard()),
            ],
          );
        }
        return Column(children: [
          Expanded(
            child: Row(children: [
              Expanded(
                child: Column(children: [
                  Expanded(child: nearbyCard(compact: false)),
                  const _WorkspacePaneDivider.horizontal(),
                  Expanded(child: heartRateCard(compact: false)),
                ]),
              ),
              const _WorkspacePaneDivider.vertical(),
              Expanded(child: bindingsCard()),
              const _WorkspacePaneDivider.vertical(),
              Expanded(child: rosterCard()),
            ]),
          ),
        ]);
      }),
    );
  }

  Widget _heatmap() {
    return _DarkPage(
      title: 'Теплокарта / карта спринтов',
      subtitle: 'зоны активности, HIR/VHIR, интенсивность и карта покрытия',
      icon: Icons.local_fire_department_rounded,
      trailing: _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () => setState(() {})),
      child: FutureBuilder<List<TrackerHeatPoint>>(
        future: _api.loadHeatmap(teamId: widget.teamId, playerId: null, fieldId: _selectedField?.id),
        builder: (context, snapshot) {
          final points = snapshot.data ?? const <TrackerHeatPoint>[];
          if (snapshot.connectionState == ConnectionState.waiting && snapshot.data == null) return const Center(child: CircularProgressIndicator());
          if (snapshot.hasError) return _DarkError(error: '${snapshot.error}', onRetry: () => setState(() {}));

          Widget mapCard() => _DarkCard(
                title: 'Теплокарта поля',
                subtitle: points.isEmpty ? 'нет точек' : '${points.length} точек',
                child: CustomPaint(painter: _DarkHeatmapPainter(points: points), child: const SizedBox.expand()),
              );
          Widget filtersCard() => _DarkCard(
                title: 'Фильтры',
                subtitle: _selectedPlayer?.name ?? 'team',
                child: Column(children: [
                  _DarkMetricTile(icon: Icons.person_rounded, title: 'Игрок', value: _selectedPlayer?.name ?? 'All', subtitle: 'фильтр'),
                  const SizedBox(height: 4),
                  _DarkMetricTile(icon: Icons.map_rounded, title: 'Поле', value: _selectedField?.title ?? 'None', subtitle: _selectedField?.hasCalibration == true ? 'откалибровано' : 'нужны углы'),
                  const SizedBox(height: 4),
                  _DarkMetricTile(icon: Icons.local_fire_department_rounded, title: 'Точки теплокарты', value: '${points.length}', subtitle: 'показано'),
                  const Spacer(),
                  const _DarkHint(text: 'Здесь можно переключать карта спринтов / карта ускорений / зоны усталости / теплокарта.'),
                ]),
              );

          return LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 860;
            if (compact) {
              return ListView(
                padding: EdgeInsets.zero,
                children: [
                  SizedBox(height: math.max(280.0, constraints.maxWidth * .62), child: mapCard()),
                  const _WorkspacePaneDivider.horizontal(),
                  SizedBox(height: 260, child: filtersCard()),
                ],
              );
            }
            return Row(children: [
              Expanded(flex: 8, child: mapCard()),
              const _WorkspacePaneDivider.vertical(),
              Expanded(flex: 3, child: filtersCard()),
            ]);
          });
        },
      ),
    );
  }

  Widget _trackerSignalBanner({bool compact = false}) {
    final packetAge = _lastTrackerPacketAt == null ? null : DateTime.now().difference(_lastTrackerPacketAt!).inSeconds;
    final gpsAge = _lastWorkspaceGpsAt == null ? null : DateTime.now().difference(_lastWorkspaceGpsAt!).inSeconds;
    final bleConnected = _ble.commandChannelReady;
    final trackerActive = bleConnected && packetAge != null && packetAge < 20;
    final gpsActive = bleConnected && gpsAge != null && gpsAge < 20;
    final title = !bleConnected
        ? 'BLE не подключён'
        : (trackerActive ? 'Трекер передаёт данные' : 'Нет свежих пакетов от трекера');
    final subtitle = !bleConnected
        ? 'Выберите устройство в списке и нажмите подключить. Пока BLE off, GPS-пакетов не будет.'
        : (gpsActive
            ? 'GPS: $_lastWorkspaceGps · ${gpsAge}s назад · точек=${_points.length}'
            : 'RX: $_lastWorkspaceRx · пакет: ${packetAge == null ? 'нет' : '${packetAge}s назад'}');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: trackerActive ? _TD.green.withOpacity(.10) : _TD.orange.withOpacity(.10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: trackerActive ? _TD.green.withOpacity(.25) : _TD.orange.withOpacity(.28)),
      ),
      child: Row(children: [
        TweenAnimationBuilder<double>(
          tween: Tween<double>(begin: .65, end: 1),
          duration: const Duration(milliseconds: 680),
          builder: (context, v, child) => Transform.scale(scale: trackerActive ? v : 1, child: child),
          child: Icon(trackerActive ? Icons.sensors_rounded : Icons.sensors_off_rounded, color: trackerActive ? _TD.green : _TD.orange, size: compact ? 16 : 18),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
            Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 11.5, fontWeight: FontWeight.w800)),
            const SizedBox(height: 2),
            Text(subtitle, maxLines: compact ? 1 : 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 10.2, fontWeight: FontWeight.w600)),
          ]),
        ),
        const SizedBox(width: 4),
        _MiniDebugPill(label: !bleConnected ? 'BLE off' : (gpsActive ? 'GPS OK' : 'GPS нет'), active: gpsActive),
      ]),
    );
  }

  Widget _calibrationFieldPreview(
    int nextIndex, {
    List<ActionTrackerGpsPoint>? corners,
    bool saved = false,
  }) {
    final drawCorners = corners ?? _calibrationCorners;
    return Stack(
      children: [
        CustomPaint(
          painter: _DarkCalibrationPainter(
            corners: drawCorners,
            activeIndex: saved ? -1 : (_calibrationCapturing ? (_calibrationCapturingIndex ?? nextIndex) : nextIndex),
            capturing: _calibrationCapturing,
          ),
          child: const SizedBox.expand(),
        ),
        Positioned.fill(
          child: IgnorePointer(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 240),
              child: _calibrationFlashLabel == null
                  ? const SizedBox.shrink()
                  : Center(
                      key: ValueKey(_calibrationFlashSeed),
                      child: TweenAnimationBuilder<double>(
                        tween: Tween<double>(begin: 0, end: 1),
                        duration: const Duration(milliseconds: 950),
                        builder: (context, v, child) {
                          final opacity = v < .72 ? 1.0 : (1.0 - ((v - .72) / .28)).clamp(0.0, 1.0);
                          return Opacity(
                            opacity: opacity,
                            child: Transform.scale(
                              scale: .72 + v * .42,
                              child: child,
                            ),
                          );
                        },
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(18),
                            boxShadow: [BoxShadow(color: Colors.black.withOpacity(.16), blurRadius: 24, offset: const Offset(0, 12))],
                            border: Border.all(color: _TD.green.withOpacity(.38)),
                          ),
                          child: Row(mainAxisSize: MainAxisSize.min, children: [
                            const Icon(Icons.add_circle_rounded, color: _TD.green, size: 22),
                            const SizedBox(width: 4),
                            Text('+ точка $_calibrationFlashLabel', style: const TextStyle(color: _TD.text, fontSize: 14, fontWeight: FontWeight.w900)),
                          ]),
                        ),
                      ),
                    ),
            ),
          ),
        ),
        if (saved)
          Positioned(
            left: 12,
            top: 12,
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.95),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: _TD.green.withOpacity(.24)),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.08), blurRadius: 14, offset: const Offset(0, 6))],
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: const [
                  Icon(Icons.check_circle_rounded, color: _TD.green, size: 16),
                  SizedBox(width: 6),
                  Text('Координаты сохранены', style: TextStyle(color: _TD.text, fontSize: 10.5, fontWeight: FontWeight.w800)),
                ]),
              ),
            ),
          ),
        if (_calibrationCapturing)
          Positioned(
            left: 12,
            right: 12,
            bottom: 12,
            child: IgnorePointer(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.95),
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.12), blurRadius: 18, offset: const Offset(0, 8))],
                ),
                child: Row(children: const [
                  SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2)),
                  SizedBox(width: 8),
                  Expanded(child: Text('Запрашиваю свежую GPS-точку у трекера...', style: TextStyle(color: _TD.text, fontSize: 10.8, fontWeight: FontWeight.w800))),
                ]),
              ),
            ),
          ),
      ],
    );
  }

  Widget _field() {
    final labels = const ['A', 'B', 'C', 'D'];
    final savedCorners = _savedFieldCalibrationCorners(_selectedField);
    final showingSavedCalibration = _calibrationCorners.isEmpty && savedCorners.length >= 4;
    final visibleCorners = showingSavedCalibration ? savedCorners : _calibrationCorners;
    final nextIndex = showingSavedCalibration ? -1 : (_calibrationCorners.length >= 4 ? -1 : _calibrationCorners.length);
    final nextLabel = nextIndex < 0 ? 'готово' : labels[nextIndex];

    Widget fieldsCard() {
      return _DarkCard(
        title: 'Поля команды',
        subtitle: '${_fields.length} полей',
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            _DarkActionButton(icon: Icons.add_rounded, label: 'Новое поле', onTap: _createNewFieldDraft),
            const SizedBox(height: 4),
            if (_selectedField?.id == null && _selectedField != null)
              _DarkListTile(
                icon: Icons.add_location_alt_rounded,
                title: _selectedField!.title,
                subtitle: '${_selectedField!.lengthM.toStringAsFixed(0)}×${_selectedField!.widthM.toStringAsFixed(0)} м · черновик, нужны 4 точки',
                active: true,
                trailing: 'новое',
                onTap: () {},
              ),
            if (_fields.isEmpty && _selectedField == null)
              const _DarkEmpty(icon: Icons.map_rounded, text: 'Нажмите «Новое поле», затем поставьте 4 угла GPS-трекером.'),
            ..._fields.map((f) => _DarkListTile(
                  icon: f.hasCalibration ? Icons.check_circle_rounded : Icons.warning_amber_rounded,
                  title: f.title,
                  subtitle: f.hasCalibration
                      ? '${f.lengthM.toStringAsFixed(0)}×${f.widthM.toStringAsFixed(0)} м · откалибровано · ${_savedFieldCoordinateSubtitle(f)}'
                      : '${f.lengthM.toStringAsFixed(0)}×${f.widthM.toStringAsFixed(0)} м · нужна калибровка',
                  active: _selectedField?.id == f.id,
                  trailing: _selectedField?.id == f.id ? 'выбрано' : 'выбрать',
                  onTap: () => setState(() {
                    _selectedField = f;
                    _calibrationCorners.clear();
                  }),
                )),
          ],
        ),
      );
    }

    Widget calibrationCard({required bool compact}) {
      return _DarkCard(
        title: 'Калибровка по 4 точкам',
        subtitle: nextIndex < 0 ? 'все точки получены' : 'следующая точка: $nextLabel',
        child: LayoutBuilder(builder: (context, constraints) {
          final previewHeight = compact
              ? math.max(180.0, math.min(270.0, constraints.maxWidth * .58))
              : math.max(230.0, constraints.maxHeight - 210.0);
          return SingleChildScrollView(
            child: Column(children: [
              _trackerSignalBanner(compact: compact),
              const SizedBox(height: 6),
              _CalibrationStatusBanner(
                nextLabel: nextLabel,
                done: nextIndex < 0,
                pointCount: visibleCorners.length,
                saved: showingSavedCalibration,
              ),
              const SizedBox(height: 6),
              SizedBox(
                height: previewHeight,
                child: _calibrationFieldPreview(
                  nextIndex,
                  corners: visibleCorners,
                  saved: showingSavedCalibration,
                ),
              ),
              const SizedBox(height: 6),
              _DarkHint(
                text: showingSavedCalibration
                    ? 'Сохранённые координаты выбранного поля показаны ниже: A/B/C/D. Чтобы заменить их, нажмите «Перекалибровать». Последняя GPS-точка трекера: $_lastWorkspaceGps.'
                    : (_points.isEmpty
                        ? 'GPS-точек пока нет. Подключите трекер, выйдите на поле и дождитесь координат.'
                        : 'Последняя GPS-точка: $_lastWorkspaceGps. Нажмите ${nextIndex < 0 ? '«Сохранить»' : '«GPS $nextLabel»'} — приложение запросит свежий пакет и не даст сохранить дубль.'),
              ),
              const SizedBox(height: 6),
              Wrap(spacing: 8, runSpacing: 8, children: List.generate(4, (i) {
                final ready = visibleCorners.length > i;
                final active = !showingSavedCalibration && !ready && i == _calibrationCorners.length && _calibrationCorners.length < 4;
                return _DarkCornerChip(
                  label: labels[i],
                  value: ready
                      ? _formatCalibrationCoordinate(visibleCorners[i])
                      : active
                          ? 'ожидает GPS'
                          : 'после предыдущей',
                  ready: ready,
                  active: active,
                  saved: showingSavedCalibration && ready,
                  onTap: showingSavedCalibration ? null : () => _handleCornerTap(i),
                );
              })),
              if (compact) const SizedBox(height: 12),
            ]),
          );
        }),
      );
    }

    return _DarkPage(
      title: 'Калибровка поля',
      subtitle: 'создайте поле и пройдите углы GPS-трекером: A верхний левый → B верхний правый → C нижний правый → D нижний левый',
      icon: Icons.map_rounded,
      trailing: _TrackerToolbarScroller(children: [
        _DarkActionButton(icon: Icons.add_rounded, label: 'Новое поле', onTap: _createNewFieldDraft),
        _DarkActionButton(
          icon: Icons.gps_fixed_rounded,
          label: _calibrationCapturing ? 'Жду GPS...' : (nextIndex < 0 ? 'GPS готов' : 'GPS $nextLabel'),
          primary: true,
          onTap: nextIndex < 0 || _calibrationCapturing ? null : _captureCalibrationPoint,
        ),
        _DarkActionButton(
          icon: showingSavedCalibration ? Icons.edit_location_alt_rounded : Icons.restart_alt_rounded,
          label: showingSavedCalibration ? 'Перекалибровать' : 'Сбросить',
          onTap: showingSavedCalibration
              ? _startRecalibrationCurrentField
              : (_calibrationCorners.isEmpty ? null : _resetCalibrationCorners),
        ),
        _DarkActionButton(icon: Icons.save_rounded, label: 'Сохранить', onTap: _calibrationCorners.length >= 4 ? _saveCapturedField : null),
      ]),
      child: LayoutBuilder(builder: (context, constraints) {
        final compact = constraints.maxWidth < 900;
        if (compact) {
          final draftRows = (_selectedField?.id == null && _selectedField != null) ? 1 : 0;
          final fieldRows = _fields.length + draftRows;
          final fieldsHeight = math.min(360.0, math.max(230.0, 96.0 + fieldRows * 46.0));
          return ListView(
            padding: EdgeInsets.zero,
            children: [
              Container(
                height: 48,
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
                decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
                child: _TrackerToolbarScroller(children: [
                  _DarkActionButton(icon: Icons.add_rounded, label: 'Новое поле', onTap: _createNewFieldDraft),
                  _DarkActionButton(
                    icon: Icons.gps_fixed_rounded,
                    label: _calibrationCapturing ? 'Жду GPS...' : (nextIndex < 0 ? 'GPS готов' : 'GPS $nextLabel'),
                    primary: true,
                    onTap: nextIndex < 0 || _calibrationCapturing ? null : _captureCalibrationPoint,
                  ),
                  _DarkActionButton(
                    icon: showingSavedCalibration ? Icons.edit_location_alt_rounded : Icons.restart_alt_rounded,
                    label: showingSavedCalibration ? 'Перекалибровать' : 'Сбросить',
                    onTap: showingSavedCalibration ? _startRecalibrationCurrentField : (_calibrationCorners.isEmpty ? null : _resetCalibrationCorners),
                  ),
                  _DarkActionButton(icon: Icons.save_rounded, label: 'Сохранить', onTap: _calibrationCorners.length >= 4 ? _saveCapturedField : null),
                ]),
              ),
              SizedBox(height: fieldsHeight, child: fieldsCard()),
              const _WorkspacePaneDivider.horizontal(),
              SizedBox(height: 720, child: calibrationCard(compact: true)),
            ],
          );
        }
        return Row(children: [
          Expanded(flex: 4, child: fieldsCard()),
          const _WorkspacePaneDivider.vertical(),
          Expanded(flex: 8, child: calibrationCard(compact: false)),
        ]);
      }),
    );
  }

  Widget _video() {
    return const _DarkPage(
      title: 'Синхронизация видео / мастер событий',
      subtitle: 'синхронизация трекера, видео и автоматической нарезки',
      icon: Icons.video_library_rounded,
      child: Row(children: [
        Expanded(flex: 8, child: _DarkCard(title: 'Лента видео', subtitle: 'событий from speed/load alerts', child: CustomPaint(painter: _DarkTimelinePainter(), child: SizedBox.expand()))),
        SizedBox(width: 10),
        Expanded(flex: 4, child: _DarkCard(title: 'Мастер событий', subtitle: 'auto clips', child: Column(children: [
          _DarkHint(text: 'Сценарии: спринт > 30 км/ч, усталость > 70%, падение скорости > 20%, рывок в штрафной, частые COD.'),
          SizedBox(height: 10),
          _DarkMetricTile(icon: Icons.content_cut_rounded, title: 'Автонарезки', value: '0', subtitle: 'пока не создано'),
          SizedBox(height: 8),
          _DarkMetricTile(icon: Icons.sync_rounded, title: 'Sync', value: 'GPS + видео', subtitle: 'roadmap'),
        ]))),
      ]),
    );
  }

  Widget _settings() {
    return _DarkPage(
      title: 'Пороги / настройки',
      subtitle: 'скоростные зоны, пороги спринта и правила ускорений',
      icon: Icons.tune_rounded,
      trailing: _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () => setState(() {})),
      child: FutureBuilder<TrackerSpeedSettings>(
        future: _api.loadSettings(teamId: widget.teamId),
        builder: (context, snapshot) {
          final settings = snapshot.data ?? const TrackerSpeedSettings();

          Widget thresholdsCard({required bool compact}) => _DarkCard(
                title: 'Текущие пороги',
                subtitle: settings.preset,
                child: GridView.count(
                  padding: EdgeInsets.zero,
                  crossAxisCount: compact ? 1 : 2,
                  crossAxisSpacing: 6,
                  mainAxisSpacing: 6,
                  childAspectRatio: compact ? 4.8 : 2.25,
                  children: [
                    _DarkMetricTile(icon: Icons.directions_walk_rounded, title: 'Лёгкий бег', value: '${settings.jogRuleMps.toStringAsFixed(1)} m/s', subtitle: 'низкая зона'),
                    _DarkMetricTile(icon: Icons.speed_rounded, title: 'Средний бег', value: '${settings.mediumRuleMps.toStringAsFixed(1)} m/s', subtitle: 'беговая зона'),
                    _DarkMetricTile(icon: Icons.local_fire_department_rounded, title: 'Высокая инт.', value: '${settings.highRuleMps.toStringAsFixed(1)} m/s', subtitle: 'высокая интенсивность'),
                    _DarkMetricTile(icon: Icons.flash_on_rounded, title: 'Спринт', value: '${settings.sprintRuleMps.toStringAsFixed(1)} m/s', subtitle: 'sprint'),
                    _DarkMetricTile(icon: Icons.timer_rounded, title: 'Время спринта', value: '${settings.sprintTimeSec.toStringAsFixed(1)} s', subtitle: 'минимум'),
                    _DarkMetricTile(icon: Icons.compare_arrows_rounded, title: 'Ускор.', value: '${settings.accelerationRuleMps2.toStringAsFixed(1)} m/s²', subtitle: 'ускорение'),
                  ],
                ),
              );

          Widget presetsCard() => _DarkCard(
                title: 'Профили',
                subtitle: 'быстрое применение',
                child: Column(children: [
                  _PresetDarkButton(title: 'U13 / Академия', subtitle: 'мягкие зоны для детского футбола', onTap: () => _saveSettingsPreset(settings.copyWith(preset: 'u13', jogRuleMps: 1.2, mediumRuleMps: 3.0, highRuleMps: 4.0, sprintRuleMps: 5.5, accelerationRuleMps2: 1.8))),
                  _PresetDarkButton(title: 'U17 / Полупрофи', subtitle: 'усиленные зоны высокой интенсивности', onTap: () => _saveSettingsPreset(settings.copyWith(preset: 'u17', jogRuleMps: 1.5, mediumRuleMps: 3.5, highRuleMps: 5.0, sprintRuleMps: 6.4, accelerationRuleMps2: 2.0))),
                  _PresetDarkButton(title: 'Профи / Элита', subtitle: 'порог спринта выше', onTap: () => _saveSettingsPreset(settings.copyWith(preset: 'pro', jogRuleMps: 1.8, mediumRuleMps: 4.0, highRuleMps: 5.5, sprintRuleMps: 7.0, accelerationRuleMps2: 2.5))),
                  const Spacer(),
                  const _DarkHint(text: 'Пороги используются для зон высокой интенсивности, спринтов и ускорений. Если сервер ругается на preset, обновите save_tracker_settings.php из архива.'),
                ]),
              );

          return LayoutBuilder(builder: (context, constraints) {
            final compact = constraints.maxWidth < 860;
            if (compact) {
              return ListView(
                padding: EdgeInsets.zero,
                children: [
                  Container(
                    height: 48,
                    padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
                    decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
                    child: _TrackerToolbarScroller(children: [
                      _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', onTap: () => setState(() {})),
                      _DarkActionButton(icon: Icons.play_arrow_rounded, label: 'Live', onTap: () => _openTrackerSection(TrackerWorkspaceSection.live)),
                      _DarkActionButton(icon: Icons.table_chart_rounded, label: 'Отчёты', onTap: () => _openTrackerSection(TrackerWorkspaceSection.sessions)),
                    ]),
                  ),
                  SizedBox(height: 330, child: thresholdsCard(compact: true)),
                  const _WorkspacePaneDivider.horizontal(),
                  SizedBox(height: 330, child: presetsCard()),
                ],
              );
            }
            return Row(children: [
              Expanded(child: thresholdsCard(compact: false)),
              const _WorkspacePaneDivider.vertical(),
              Expanded(child: presetsCard()),
            ]);
          });
        },
      ),
    );
  }

  String _remoteLogTimeLabel(Map<String, dynamic> log) {
    final raw = '${log['created_at'] ?? ''}'.trim();
    if (raw.isEmpty) return '—';
    try {
      final normalized = raw.contains('T') ? raw : raw.replaceFirst(' ', 'T');
      final dt = DateTime.parse(normalized).toLocal();
      return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
    } catch (_) {
      return raw.length > 19 ? raw.substring(11, 19) : raw;
    }
  }

  String _remoteConsoleSubtitle() {
    if (_lastRemoteConsoleLoadAt == null) return 'ждём данные с сервера';
    final age = DateTime.now().difference(_lastRemoteConsoleLoadAt!).inSeconds;
    return 'обновлено ${age}s назад · ${_remoteDebugLogs.length} строк';
  }

  Color _remoteLogLevelColor(String level) {
    final l = level.toLowerCase();
    if (l.contains('error')) return _TD.red;
    if (l.contains('warn')) return _TD.orange;
    return _TD.greenDark;
  }

  String _remoteLogDeviceLabel(Map<String, dynamic> log) {
    final name = '${log['device_name'] ?? ''}'.trim();
    final uuid = '${log['device_uuid'] ?? ''}'.trim();
    if (name.isEmpty && uuid.isEmpty) return 'без BLE';
    if (uuid.isEmpty) return name;
    final shortUuid = uuid.length > 10 ? uuid.substring(0, 10) : uuid;
    return name.isEmpty ? shortUuid : '$name · $shortUuid';
  }

  Widget _remoteTerminalPanel() {
    final logs = _remoteDebugLogs;
    return _DarkCard(
      title: 'Удалённый терминал',
      subtitle: _remoteConsoleSubtitle(),
      child: Column(children: [
        Row(children: [
          Expanded(
            child: _DarkHint(
              text: 'Это общий терминал команды. Если другой человек открыл трекер и интернет есть — здесь будут его BLE, GPS, поле, Live и ошибки API.',
            ),
          ),
          const SizedBox(width: 4),
          _DarkActionButton(
            icon: _remoteConsoleAutoRefresh ? Icons.pause_rounded : Icons.play_arrow_rounded,
            label: _remoteConsoleAutoRefresh ? 'Авто' : 'Пауза',
            onTap: () => setState(() => _remoteConsoleAutoRefresh = !_remoteConsoleAutoRefresh),
          ),
          const SizedBox(width: 4),
          _DarkActionButton(
            icon: Icons.refresh_rounded,
            label: _remoteDebugLoading ? '...' : 'Логи',
            primary: true,
            onTap: _remoteDebugLoading ? null : () => _loadRemoteDebugLogs(),
          ),
        ]),
        const SizedBox(height: 0),
        Expanded(
          child: logs.isEmpty
              ? const _DarkEmpty(icon: Icons.terminal_rounded, text: 'Удалённых логов пока нет. На устройстве с трекером должен быть интернет и открыто окно трекера.')
              : ListView.builder(
                  itemCount: logs.length,
                  itemBuilder: (_, i) {
                    final log = logs[i];
                    final level = '${log['level'] ?? 'info'}';
                    final source = '${log['source'] ?? 'app'}';
                    final message = '${log['message'] ?? ''}'.trim();
                    final raw = '${log['raw_hex'] ?? ''}'.trim();
                    final playerId = '${log['player_id'] ?? ''}'.trim();
                    final liveId = '${log['live_session_id'] ?? ''}'.trim();
                    return Container(
                      margin: const EdgeInsets.only(bottom: 7),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: _TD.soft2,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: _TD.border),
                      ),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(color: _remoteLogLevelColor(level), shape: BoxShape.circle),
                          ),
                          const SizedBox(width: 7),
                          Expanded(
                            child: Text(
                              '${_remoteLogTimeLabel(log)}  [$level] $source',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(color: _TD.text, fontSize: 11, fontWeight: FontWeight.w900, fontFamily: 'monospace'),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 5),
                        Text(
                          _remoteLogDeviceLabel(log),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: _TD.greenDark, fontSize: 11, fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 5),
                        Text(
                          message.isEmpty ? '—' : message,
                          style: const TextStyle(color: _TD.muted, fontSize: 11.5, height: 1.25, fontFamily: 'monospace', fontWeight: FontWeight.w600),
                        ),
                        if (raw.isNotEmpty) ...[
                          const SizedBox(height: 5),
                          Text('RX/TX: $raw', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.dim, fontSize: 10.5, fontFamily: 'monospace')),
                        ],
                        if (playerId.isNotEmpty || liveId.isNotEmpty) ...[
                          const SizedBox(height: 5),
                          Text('player=$playerId  live=$liveId', style: const TextStyle(color: _TD.dim, fontSize: 10.5, fontFamily: 'monospace')),
                        ],
                      ]),
                    );
                  },
                ),
        ),
      ]),
    );
  }

  Widget _debug() {
    return _DarkPage(
      title: 'Диагностика устройства / RX-TX',
      subtitle: 'слева локально на этом устройстве, справа удалённый терминал команды',
      icon: Icons.bug_report_rounded,
      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
        _DarkActionButton(icon: Icons.cloud_upload_rounded, label: 'Debug сервер', onTap: _sendManualDebugDump),
        const SizedBox(width: 4),
        _DarkActionButton(icon: Icons.gps_fixed_rounded, label: 'Запрос GPS', onTap: _requestCurrentGpsFromDebug),
        const SizedBox(width: 4),
        _DarkActionButton(icon: Icons.restart_alt_rounded, label: _scanning ? 'Поиск...' : 'Сброс + поиск', primary: true, onTap: _scanning ? null : () => _scan(clean: true, universalMode: true)),
        const SizedBox(width: 4),
        _DarkActionButton(icon: Icons.delete_outline_rounded, label: 'Очистить', onTap: () => setState(() => _logs.clear())),
        const SizedBox(width: 4),
        _DarkActionButton(icon: Icons.refresh_rounded, label: 'Обновить', primary: true, onTap: _loadServerData),
      ]),
      child: Row(children: [
        Expanded(
          flex: 6,
          child: _DarkCard(
            title: 'Локальный терминал этого окна',
            subtitle: '${_logs.length} строк · только этот компьютер/планшет',
            child: _logs.isEmpty
                ? const _DarkEmpty(icon: Icons.terminal_rounded, text: 'Здесь локальные действия этого окна: отправка debug, ошибки API, запрос GPS, поиск BLE. Удалённый трекер другого человека показывается справа.')
                : ListView.builder(
                    itemCount: _logs.length,
                    itemBuilder: (_, i) => Padding(
                      padding: const EdgeInsets.only(bottom: 5),
                      child: Text(
                        _logs[i],
                        style: const TextStyle(color: _TD.muted, fontFamily: 'monospace', fontSize: 9.4, fontWeight: FontWeight.w600),
                      ),
                    ),
                  ),
          ),
        ),
        const _WorkspacePaneDivider.vertical(),
        Expanded(flex: 7, child: _remoteTerminalPanel()),
        const _WorkspacePaneDivider.vertical(),
        Expanded(flex: 4, child: _DarkCard(title: 'Состояние', subtitle: 'быстрая диагностика', child: Column(children: [
          _trackerSignalBanner(compact: true),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.bluetooth_rounded, title: 'BLE', value: _ble.commandChannelReady ? (_ble.connectedInfo?.name ?? 'подключён') : 'TX/RX не готов', subtitle: _ble.connectedInfo?.id ?? _ble.lastKnownInfo?.id ?? 'сначала выберите трекер'),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.person_rounded, title: 'Игрок', value: _selectedPlayer?.name ?? 'none', subtitle: 'active'),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.map_rounded, title: 'Поле', value: _selectedField?.title ?? 'none', subtitle: _selectedField?.hasCalibration == true ? 'откалибровано' : 'не готово'),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.route_rounded, title: 'GPS-точки', value: '${_points.length}', subtitle: 'последняя: $_lastWorkspaceGps'),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.cloud_sync_rounded, title: 'Remote debug', value: _lastRemoteDebug.startsWith('OK') ? 'OK' : 'ошибка', subtitle: _lastRemoteDebug),
          const SizedBox(height: 4),
          _DarkMetricTile(icon: Icons.receipt_long_rounded, title: 'RX', value: _lastWorkspaceRx, subtitle: 'последний пакет'),
        ]))),
      ]),
    );
  }
}




class _MobileSessionsReportPane extends StatefulWidget {
  const _MobileSessionsReportPane({
    required this.api,
    required this.teamId,
    required this.teamName,
    required this.selectedSession,
    required this.onSelect,
    required this.onProcess,
    required this.onRefresh,
    required this.onDownloadRecords,
    required this.onSaveGps,
    required this.savingRecord,
  });

  final TrackerProApi api;
  final int teamId;
  final String teamName;
  final TrackerSessionModel? selectedSession;
  final ValueChanged<TrackerSessionModel> onSelect;
  final ValueChanged<TrackerSessionModel> onProcess;
  final VoidCallback onRefresh;
  final VoidCallback onDownloadRecords;
  final VoidCallback? onSaveGps;
  final bool savingRecord;

  @override
  State<_MobileSessionsReportPane> createState() => _MobileSessionsReportPaneState();
}

class _MobileSessionsReportPaneState extends State<_MobileSessionsReportPane> {
  void _handleMobileAction(String value) {
    switch (value) {
      case 'refresh':
        widget.onRefresh();
        setState(() {});
        break;
      case 'download':
        widget.onDownloadRecords();
        break;
      case 'save':
        widget.onSaveGps?.call();
        break;
    }
  }

  Future<void> _openReportFullSheet(TrackerSessionModel session) async {
    widget.onSelect(session);
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => DraggableScrollableSheet(
        initialChildSize: .96,
        minChildSize: .64,
        maxChildSize: .99,
        builder: (context, controller) {
          return Container(
            clipBehavior: Clip.antiAlias,
            decoration: const BoxDecoration(
              color: _TD.bg,
              borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
            ),
            child: Column(
              children: [
                Container(
                  width: 46,
                  height: 4,
                  margin: const EdgeInsets.only(top: 10, bottom: 8),
                  decoration: BoxDecoration(color: _TD.borderStrong, borderRadius: BorderRadius.circular(99)),
                ),
                Container(
                  height: 46,
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _TD.softLine))),
                  child: Row(children: [
                    const Icon(Icons.table_chart_rounded, color: _TD.green, size: 18),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        '${session.title} · отчёт',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: _TD.text, fontSize: 13.5, fontWeight: FontWeight.w900),
                      ),
                    ),
                    IconButton(onPressed: () => Navigator.of(context).pop(), icon: const Icon(Icons.close_rounded, color: _TD.dim)),
                  ]),
                ),
                Expanded(
                  child: PrimaryScrollController(
                    controller: controller,
                    child: _SelectedTrainingReportPane(
                      session: session,
                      teamId: widget.teamId,
                      teamName: widget.teamName,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> _refreshMobileReports() async {
    widget.onRefresh();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<TrackerSessionModel>>(
      future: widget.api.loadSessions(teamId: widget.teamId, playerId: null),
      builder: (context, snapshot) {
        final sessions = snapshot.data ?? const <TrackerSessionModel>[];
        final selected = widget.selectedSession ?? (sessions.isNotEmpty ? sessions.first : null);

        if (snapshot.connectionState == ConnectionState.waiting && snapshot.data == null) {
          return const _DarkCard(title: 'Отчёты', subtitle: 'загрузка сессий', child: Center(child: CircularProgressIndicator()));
        }

        if (snapshot.hasError) {
          return _DarkCard(
            title: 'Отчёты',
            subtitle: 'ошибка загрузки',
            child: _DarkError(error: '${snapshot.error}', onRetry: () => setState(() {})),
          );
        }

        return RefreshIndicator(
          color: _TD.green,
          onRefresh: _refreshMobileReports,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 20),
            children: [
              _MobileReportsActionRail(
                savingRecord: widget.savingRecord,
                onRefresh: () => _handleMobileAction('refresh'),
                onDownload: () => _handleMobileAction('download'),
                onSave: widget.onSaveGps == null ? null : () => _handleMobileAction('save'),
              ),
              const SizedBox(height: 10),
              if (selected == null)
                const _MobileReportsEmptySelector()
              else
                _MobileSelectedSessionCard(
                  session: selected,
                  sessionsCount: sessions.length,
                  onOpen: () => _openReportFullSheet(selected),
                  onProcess: () => widget.onProcess(selected),
                ),
              const SizedBox(height: 12),
              if (sessions.isNotEmpty) ...[
                _MobileReportsSectionTitle(
                  title: 'Быстрый выбор',
                  subtitle: '${sessions.length} тренировок · листайте вправо',
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 112,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: sessions.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (context, index) {
                      final s = sessions[index];
                      final active = selected?.id == s.id;
                      return _MobileSessionChipCard(
                        session: s,
                        active: active,
                        onTap: () {
                          widget.onSelect(s);
                          setState(() {});
                        },
                        onOpen: () => _openReportFullSheet(s),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 12),
              ],
              _MobileReportsSectionTitle(
                title: 'Сессии',
                subtitle: sessions.isEmpty ? 'после Live здесь появятся тренировки' : 'нажмите на строку, чтобы открыть отчёт',
              ),
              const SizedBox(height: 8),
              if (sessions.isEmpty)
                const _DarkEmpty(icon: Icons.storage_rounded, text: 'Сессии появятся после Live или сохранения GPS-записи.')
              else
                for (var i = 0; i < sessions.length; i++) ...[
                  _MobileSessionListCard(
                    session: sessions[i],
                    active: selected?.id == sessions[i].id,
                    onTap: () => _openReportFullSheet(sessions[i]),
                    onProcess: () => widget.onProcess(sessions[i]),
                  ),
                  if (i != sessions.length - 1) const SizedBox(height: 7),
                ],
            ],
          ),
        );
      },
    );
  }
}

class _MobileReportsActionRail extends StatelessWidget {
  const _MobileReportsActionRail({
    required this.savingRecord,
    required this.onRefresh,
    required this.onDownload,
    required this.onSave,
  });

  final bool savingRecord;
  final VoidCallback onRefresh;
  final VoidCallback onDownload;
  final VoidCallback? onSave;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 46,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          _MobileReportActionChip(icon: Icons.refresh_rounded, label: 'Обновить', onTap: onRefresh),
          const SizedBox(width: 8),
          _MobileReportActionChip(icon: Icons.download_rounded, label: 'Загрузить записи', primary: true, onTap: onDownload),
          const SizedBox(width: 8),
          _MobileReportActionChip(icon: Icons.save_alt_rounded, label: savingRecord ? 'Сохраняю GPS…' : 'Сохранить GPS', onTap: savingRecord ? null : onSave),
        ],
      ),
    );
  }
}

class _MobileReportActionChip extends StatelessWidget {
  const _MobileReportActionChip({required this.icon, required this.label, required this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return Material(
      color: primary && enabled ? _TD.green : _TD.card,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: primary && enabled ? _TD.green : _TD.borderStrong),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 17, color: primary && enabled ? Colors.white : (enabled ? _TD.graphite : _TD.dim)),
            const SizedBox(width: 7),
            Text(
              label,
              style: TextStyle(
                color: primary && enabled ? Colors.white : (enabled ? _TD.graphite : _TD.dim),
                fontSize: 11.2,
                fontWeight: FontWeight.w900,
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

class _MobileSelectedSessionCard extends StatelessWidget {
  const _MobileSelectedSessionCard({required this.session, required this.sessionsCount, required this.onOpen, required this.onProcess});
  final TrackerSessionModel session;
  final int sessionsCount;
  final VoidCallback onOpen;
  final VoidCallback onProcess;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _TD.greenBorder),
        boxShadow: _TD.cardShadow,
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: _TD.greenSoft, borderRadius: BorderRadius.circular(15), border: Border.all(color: _TD.greenBorder)),
            child: const Icon(Icons.assignment_turned_in_rounded, color: _TD.green, size: 21),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(session.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 15, fontWeight: FontWeight.w900)),
              const SizedBox(height: 2),
              Text(
                '${session.playerName ?? 'Команда'} · ${session.createdAt} · ${(session.distanceM / 1000).toStringAsFixed(2)} км · $sessionsCount сессий',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: _TD.muted, fontSize: 10.5, fontWeight: FontWeight.w800),
              ),
            ]),
          ),
        ]),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: FilledButton.icon(
              onPressed: onOpen,
              style: FilledButton.styleFrom(backgroundColor: _TD.green, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)), padding: const EdgeInsets.symmetric(horizontal: 10)),
              icon: const Icon(Icons.open_in_full_rounded, size: 16),
              label: const Text('Открыть отчёт', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.3, fontWeight: FontWeight.w900)),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: OutlinedButton.icon(
              onPressed: onProcess,
              style: OutlinedButton.styleFrom(foregroundColor: _TD.graphite, side: const BorderSide(color: _TD.borderStrong), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)), padding: const EdgeInsets.symmetric(horizontal: 10)),
              icon: const Icon(Icons.playlist_add_check_rounded, size: 16),
              label: const Text('Обраб.', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 11.3, fontWeight: FontWeight.w900)),
            ),
          ),
        ]),
      ]),
    );
  }
}

class _MobileReportsEmptySelector extends StatelessWidget {
  const _MobileReportsEmptySelector();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: _TD.borderStrong)),
      child: const Row(children: [
        Icon(Icons.storage_rounded, color: _TD.dim, size: 24),
        SizedBox(width: 10),
        Expanded(child: Text('Сессия не выбрана. После Live или сохранения GPS здесь появится список отчётов.', style: TextStyle(color: _TD.muted, fontSize: 11.5, fontWeight: FontWeight.w800))),
      ]),
    );
  }
}

class _MobileReportsSectionTitle extends StatelessWidget {
  const _MobileReportsSectionTitle({required this.title, required this.subtitle});
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(width: 34, height: 34, decoration: BoxDecoration(color: _TD.greenSoft, borderRadius: BorderRadius.circular(12), border: Border.all(color: _TD.greenBorder)), child: const Icon(Icons.table_chart_rounded, color: _TD.green, size: 17)),
      const SizedBox(width: 9),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 14, fontWeight: FontWeight.w900)),
        Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 10.2, fontWeight: FontWeight.w700)),
      ])),
    ]);
  }
}

class _MobileSessionChipCard extends StatelessWidget {
  const _MobileSessionChipCard({required this.session, required this.active, required this.onTap, required this.onOpen});
  final TrackerSessionModel session;
  final bool active;
  final VoidCallback onTap;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 210,
      child: Material(
        color: active ? _TD.greenSoft : Colors.white,
        borderRadius: BorderRadius.circular(16),
        child: InkWell(
          onTap: onTap,
          onLongPress: onOpen,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(16), border: Border.all(color: active ? _TD.greenBorder : _TD.borderStrong)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Icon(active ? Icons.check_circle_rounded : Icons.assignment_rounded, color: active ? _TD.green : _TD.dim, size: 18),
                const SizedBox(width: 6),
                Expanded(child: Text(session.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 12.2, fontWeight: FontWeight.w900))),
              ]),
              const SizedBox(height: 5),
              Text(session.playerName ?? 'Команда', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 10, fontWeight: FontWeight.w800)),
              const Spacer(),
              Row(children: [
                Expanded(child: Text('${(session.distanceM / 1000).toStringAsFixed(2)} км · ${session.maxSpeedKmh.toStringAsFixed(1)} км/ч', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.dim, fontSize: 9.6, fontWeight: FontWeight.w700))),
                InkWell(
                  onTap: onOpen,
                  borderRadius: BorderRadius.circular(10),
                  child: Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: _TD.borderStrong)), child: const Icon(Icons.open_in_new_rounded, color: _TD.green, size: 15)),
                ),
              ]),
            ]),
          ),
        ),
      ),
    );
  }
}

class _MobileSessionListCard extends StatelessWidget {
  const _MobileSessionListCard({required this.session, required this.active, required this.onTap, required this.onProcess});
  final TrackerSessionModel session;
  final bool active;
  final VoidCallback onTap;
  final VoidCallback onProcess;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? _TD.greenSoft : Colors.white,
      borderRadius: BorderRadius.circular(15),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(15),
        child: Container(
          padding: const EdgeInsets.fromLTRB(10, 9, 8, 9),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(15), border: Border.all(color: active ? _TD.greenBorder : _TD.borderStrong)),
          child: Row(children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(color: active ? Colors.white : _TD.soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: active ? _TD.greenBorder : _TD.softLine)),
              child: Icon(active ? Icons.checklist_rounded : Icons.assignment_rounded, color: active ? _TD.green : _TD.dim, size: 18),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(session.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 12.6, fontWeight: FontWeight.w900)),
                const SizedBox(height: 2),
                Text(
                  '${session.playerName ?? 'Команда'} · ${session.createdAt} · ${(session.distanceM / 1000).toStringAsFixed(2)} км',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _TD.muted, fontSize: 10, fontWeight: FontWeight.w700),
                ),
              ]),
            ),
            const SizedBox(width: 8),
            IconButton(
              visualDensity: VisualDensity.compact,
              tooltip: 'Обработать',
              onPressed: onProcess,
              icon: const Icon(Icons.playlist_add_check_rounded, color: _TD.green, size: 18),
            ),
            const Icon(Icons.chevron_right_rounded, color: _TD.dim, size: 20),
          ]),
        ),
      ),
    );
  }
}

class _SessionsListPane extends StatelessWidget {
  const _SessionsListPane({
    required this.api,
    required this.teamId,
    required this.playerId,
    required this.selectedSession,
    required this.onSelect,
    required this.onProcess,
  });

  final TrackerProApi api;
  final int teamId;
  final int? playerId;
  final TrackerSessionModel? selectedSession;
  final ValueChanged<TrackerSessionModel> onSelect;
  final ValueChanged<TrackerSessionModel> onProcess;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<TrackerSessionModel>>(
      future: api.loadSessions(teamId: teamId, playerId: playerId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting && snapshot.data == null) {
          return const _DarkCard(title: 'Сессии', subtitle: 'загрузка', child: Center(child: CircularProgressIndicator()));
        }
        if (snapshot.hasError) {
          return _DarkCard(
            title: 'Сессии',
            subtitle: 'ошибка',
            child: _DarkError(error: '${snapshot.error}', onRetry: () {}),
          );
        }
        final sessions = snapshot.data ?? const <TrackerSessionModel>[];
        return _DarkCard(
          title: 'Сессии',
          subtitle: '${sessions.length} тренировок',
          child: sessions.isEmpty
              ? const _DarkEmpty(icon: Icons.storage_rounded, text: 'Сессии появятся после Live или сохранения GPS-записи.')
              : ListView.builder(
                  itemCount: sessions.length,
                  itemBuilder: (context, index) {
                    final s = sessions[index];
                    final active = selectedSession?.id == s.id || (selectedSession == null && index == 0);
                    return _DarkListTile(
                      icon: Icons.assignment_rounded,
                      title: s.title,
                      subtitle: '${s.playerName ?? 'Команда'} · ${s.createdAt} · ${(s.distanceM / 1000).toStringAsFixed(2)} км · макс. ${s.maxSpeedKmh.toStringAsFixed(1)}',
                      active: active,
                      trailing: active ? 'отчёт' : 'открыть',
                      onTap: () => onSelect(s),
                    );
                  },
                ),
        );
      },
    );
  }
}


String _recordStateLabel(ActionTrackerRecordState state) {
  switch (state) {
    case ActionTrackerRecordState.recording:
      return 'идёт запись';
    case ActionTrackerRecordState.finished:
      return 'готова';
    case ActionTrackerRecordState.ready:
      return 'готово';
    case ActionTrackerRecordState.unknown:
      return 'неизвестно';
  }
}

class _GpsRecordsPane extends StatelessWidget {
  const _GpsRecordsPane({
    required this.records,
    required this.selectedRecord,
    required this.pointsCount,
    required this.onLoad,
  });

  final List<ActionTrackerRecord> records;
  final ActionTrackerRecord? selectedRecord;
  final int pointsCount;
  final ValueChanged<ActionTrackerRecord> onLoad;

  @override
  Widget build(BuildContext context) {
    return _DarkCard(
      title: 'GPS-записи',
      subtitle: selectedRecord == null ? '${records.length} записей · ${records.any((r) => r.state == ActionTrackerRecordState.recording) ? 'идёт запись' : 'готово'}' : 'Запись ${selectedRecord!.fileId} · $pointsCount точек',
      child: records.isEmpty
          ? const _DarkEmpty(icon: Icons.download_rounded, text: 'Подключите трекер и загрузите записи.')
          : ListView(
              children: records
                  .map((r) => _DarkListTile(
                        icon: Icons.route_rounded,
                        title: 'Record ${r.fileId}',
                        subtitle: '${r.title} · ${_recordStateLabel(r.state)} · ${r.length} байт${selectedRecord?.fileId == r.fileId ? ' · $pointsCount точек' : ''}',
                        active: selectedRecord?.fileId == r.fileId,
                        trailing: selectedRecord?.fileId == r.fileId ? 'выбрано' : 'загрузить',
                        onTap: () => onLoad(r),
                      ))
                  .toList(),
            ),
    );
  }
}

class _SelectedTrainingReportPane extends StatelessWidget {
  const _SelectedTrainingReportPane({
    required this.session,
    required this.teamId,
    required this.teamName,
  });

  final TrackerSessionModel? session;
  final int teamId;
  final String teamName;

  @override
  Widget build(BuildContext context) {
    final s = session;
    if (s == null) {
      return const _DarkCard(
        title: 'Отчёт тренировки',
        subtitle: 'выберите сессию слева',
        child: _DarkEmpty(icon: Icons.analytics_rounded, text: 'Выберите тренировку в списке «Сессии», чтобы открыть сводку, локомоторную, механическую и внутреннюю нагрузку.'),
      );
    }
    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: TrackerTrainingReportScreen(
        key: ValueKey('training_report_${s.id}'),
        sessionId: s.id,
        teamId: teamId,
        teamName: teamName,
        embedded: true,
      ),
    );
  }
}

class _TD {
  // Та же светлая CMR / Windows 11 схема, что в CMR Team Matches.
  static const bg = Color(0xFFF6F7F9);
  static const rail = Color(0xFFFFFFFF);
  static const panel = Color(0xFFFFFFFF);
  static const glass = Color(0xF8FFFFFF);
  static const card = Color(0xFFFFFFFF);
  static const card2 = Color(0xFFFAFBFC);
  static const soft = Color(0xFFF6F7F9);
  static const soft2 = Color(0xFFF5F7FB);
  static const border = Color(0xFFF0F2F4);
  static const borderStrong = Color(0xFFE5E7EB);
  static const softLine = Color(0xFFF0F2F4);
  static const grid = Color(0xFFD8DEE6);

  static const text = Color(0xFF0B0F14);
  static const graphite = Color(0xFF344054);
  static const graphiteSoft = Color(0xFF475467);
  static const muted = Color(0xFF374151);
  static const dim = Color(0xFF6B7280);

  static const green = Color(0xFF00A750);
  static const greenDark = Color(0xFF067A46);
  static const greenSoft = Color(0xFFF3FBF7);
  static const greenBorder = Color(0xFFDCEFE5);
  static const yellow = Color(0xFFF59E0B);
  static const orange = Color(0xFFF59E0B);
  static const red = Color(0xFFDC2626);
  static const redSoft = Color(0xFFFEF2F2);
  static const blue = Color(0xFF2563EB);
  static const blueSoft = Color(0xFFF4F7FF);
  static const cyan = Color(0xFF06B6D4);
  static const violet = Color(0xFF7C3AED);

  static List<BoxShadow> get windowShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(.055),
          blurRadius: 38,
          spreadRadius: -18,
          offset: const Offset(0, 22),
        ),
        BoxShadow(
          color: blue.withOpacity(.035),
          blurRadius: 24,
          spreadRadius: -18,
          offset: const Offset(0, 10),
        ),
      ];

  static List<BoxShadow> get cardShadow => [
        BoxShadow(
          color: Colors.black.withOpacity(.025),
          blurRadius: 14,
          spreadRadius: -10,
          offset: const Offset(0, 8),
        ),
      ];

  static BoxDecoration programWindowDecoration({double radius = 22}) => BoxDecoration(
        color: glass,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Colors.white.withOpacity(.86), width: 1),
        boxShadow: windowShadow,
      );

  static BoxDecoration unifiedWindow({double radius = 20}) => BoxDecoration(
        color: glass,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Colors.white.withOpacity(.86), width: 1),
        boxShadow: windowShadow,
      );


  static BoxDecoration workspaceBg() => const BoxDecoration(
        color: bg,
      );

  static BoxDecoration seamlessPane({double radius = 0}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
      );

  static BoxDecoration softSurface({double radius = 12, bool active = false}) => BoxDecoration(
        color: active ? greenSoft : panel,
        borderRadius: BorderRadius.circular(math.min(radius, 4)),
        border: Border.all(color: active ? greenBorder : borderStrong.withOpacity(.72), width: 1),
      );
}


extension _SectionExt on TrackerWorkspaceSection {
  String get title => switch (this) {
        TrackerWorkspaceSection.dashboard => 'Главная',
        TrackerWorkspaceSection.live => 'Live',
        TrackerWorkspaceSection.analytics => 'Аналитика',
        TrackerWorkspaceSection.activity => 'Игроки',
        TrackerWorkspaceSection.sessions => 'Отчёты',
        TrackerWorkspaceSection.devices => 'Трекеры',
        TrackerWorkspaceSection.field => 'Поле',
        TrackerWorkspaceSection.settings => 'Пороги',
        TrackerWorkspaceSection.debug => 'Диагн.',
      };

  IconData get icon => switch (this) {
        TrackerWorkspaceSection.dashboard => Icons.dashboard_customize_rounded,
        TrackerWorkspaceSection.live => Icons.radio_button_checked_rounded,
        TrackerWorkspaceSection.analytics => Icons.analytics_rounded,
        TrackerWorkspaceSection.activity => Icons.monitor_heart_rounded,
        TrackerWorkspaceSection.sessions => Icons.table_chart_rounded,
        TrackerWorkspaceSection.devices => Icons.sensors_rounded,
        TrackerWorkspaceSection.field => Icons.map_rounded,
        TrackerWorkspaceSection.settings => Icons.tune_rounded,
        TrackerWorkspaceSection.debug => Icons.bug_report_rounded,
      };
}


class _KeepAlivePage extends StatefulWidget {
  const _KeepAlivePage({required this.child});

  final Widget child;

  @override
  State<_KeepAlivePage> createState() => _KeepAlivePageState();
}

class _KeepAlivePageState extends State<_KeepAlivePage> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return widget.child;
  }
}

class _TrackerProgramCollapsedBar extends StatelessWidget {
  const _TrackerProgramCollapsedBar({
    required this.clubName,
    required this.teamName,
    required this.liveRunning,
    required this.connected,
    required this.onRestore,
    required this.onClose,
  });

  final String clubName;
  final String teamName;
  final bool liveRunning;
  final bool connected;
  final VoidCallback onRestore;
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: Alignment.topCenter,
      child: Container(
        height: 64,
        margin: const EdgeInsets.all(10),
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: _TD.panel,
          borderRadius: BorderRadius.circular(18),
          boxShadow: _TD.windowShadow,
        ),
        child: Row(
          children: [
            _MacWindowControls(
              maximized: false,
              onClose: onClose,
              onMinimize: onRestore,
              onToggleMaximize: onRestore,
            ),
            const SizedBox(width: 4),
            Container(
              width: 36,
              height: 36,
              decoration: BoxDecoration(
                color: _TD.card2,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.sensors_rounded, color: _TD.dim, size: 19),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Tracker Pro свернут',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(color: _TD.text, fontSize: 10, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '$clubName · $teamName',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _TD.muted, fontSize: 9.4, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            _TrackerStatusDot(
              color: liveRunning ? _TD.green : _TD.dim,
              label: liveRunning ? 'LIVE' : (connected ? 'ГОТОВО' : 'ВЫКЛ'),
            ),
            const SizedBox(width: 10),
            _DarkActionButton(
              icon: Icons.open_in_full_rounded,
              label: 'Открыть',
              primary: true,
              onTap: onRestore,
            ),
          ],
        ),
      ),
    );
  }
}



class _TrackerMobileHeader extends StatelessWidget {
  const _TrackerMobileHeader({
    required this.clubName,
    required this.teamName,
    required this.selectedPlayer,
    required this.selected,
    required this.loading,
    required this.liveRunning,
    required this.connected,
    required this.onRefresh,
    required this.onClose,
    required this.onMinimize,
  });

  final String clubName;
  final String teamName;
  final String selectedPlayer;
  final TrackerWorkspaceSection selected;
  final bool loading;
  final bool liveRunning;
  final bool connected;
  final VoidCallback onRefresh;
  final VoidCallback onClose;
  final VoidCallback onMinimize;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 48,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      color: Colors.transparent,
      child: Row(
        children: [
          _TrackerSmallGhostButton(icon: Icons.close_rounded, onTap: onClose, tooltip: 'Закрыть'),
          const SizedBox(width: 4),
          _TrackerSmallGhostButton(icon: Icons.remove_rounded, onTap: onMinimize, tooltip: 'Свернуть'),
          const SizedBox(width: 8),
          Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(color: _TD.soft, borderRadius: BorderRadius.circular(4)),
            child: Icon(selected.icon, color: liveRunning ? _TD.green : _TD.graphite, size: 16),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${selected.title} · $teamName',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _TD.text, fontSize: 10.8, fontWeight: FontWeight.w800),
                ),
                Text(
                  '$clubName · $selectedPlayer',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _TD.muted, fontSize: 8.8, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          _TrackerStatusDot(color: liveRunning ? _TD.green : (connected ? _TD.green : _TD.dim), label: liveRunning ? 'LIVE' : (connected ? 'BLE' : 'OFF')),
          const SizedBox(width: 6),
          _TrackerSmallGhostButton(icon: loading ? Icons.hourglass_top_rounded : Icons.refresh_rounded, onTap: loading ? null : onRefresh, tooltip: 'Обновить'),
        ],
      ),
    );
  }
}

class _TrackerMobileTabs extends StatelessWidget {
  const _TrackerMobileTabs({required this.sections, required this.selected, required this.onSelect});
  final List<TrackerWorkspaceSection> sections;
  final TrackerWorkspaceSection selected;
  final ValueChanged<TrackerWorkspaceSection> onSelect;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 58,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(8, 7, 8, 7),
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: sections.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (context, index) {
          final section = sections[index];
          final active = section == selected;
          return Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(14),
              onTap: () => onSelect(section),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                height: 44,
                constraints: BoxConstraints(minWidth: active ? 104 : 74),
                padding: EdgeInsets.symmetric(horizontal: active ? 12 : 10),
                decoration: BoxDecoration(
                  color: active ? _TD.greenSoft : _TD.soft,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: active ? _TD.green.withOpacity(.32) : _TD.softLine, width: 1),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(section.icon, size: 16, color: active ? _TD.green : _TD.graphiteSoft),
                    const SizedBox(width: 7),
                    Text(
                      section.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: active ? _TD.text : _TD.muted,
                        fontSize: 10.6,
                        fontWeight: active ? FontWeight.w900 : FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

class _TrackerToolbarScroller extends StatelessWidget {
  const _TrackerToolbarScroller({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 620),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            for (var i = 0; i < children.length; i++) ...[
              if (i > 0) const SizedBox(width: 4),
              children[i],
            ],
          ],
        ),
      ),
    );
  }
}

class _TrackerProgramSidePanel extends StatelessWidget {
  const _TrackerProgramSidePanel({
    required this.clubName,
    required this.teamName,
    required this.selectedPlayer,
    required this.selected,
    required this.loading,
    required this.liveRunning,
    required this.connected,
    required this.compact,
    required this.collapsed,
    required this.onSelect,
    required this.onRefresh,
    required this.onClose,
    required this.onMinimize,
    this.onToggleCollapsed,
  });

  final String clubName;
  final String teamName;
  final String selectedPlayer;
  final TrackerWorkspaceSection selected;
  final bool loading;
  final bool liveRunning;
  final bool connected;
  final bool compact;
  final bool collapsed;
  final ValueChanged<TrackerWorkspaceSection> onSelect;
  final VoidCallback onRefresh;
  final VoidCallback onClose;
  final VoidCallback onMinimize;
  final VoidCallback? onToggleCollapsed;

  @override
  Widget build(BuildContext context) {
    final sections = _trackerVisibleSections;

    if (compact) {
      return Container(
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 6),
        child: Column(
          children: [
            _TrackerSideIconButton(
              icon: Icons.sensors_rounded,
              active: liveRunning,
              tooltip: liveRunning ? 'Live идёт' : (connected ? 'Трекер готов' : 'Трекер выключен'),
              onTap: onRefresh,
            ),
            if (onToggleCollapsed != null) ...[
              const SizedBox(height: 4),
              _TrackerSideIconButton(
                icon: Icons.keyboard_double_arrow_right_rounded,
                active: false,
                tooltip: 'Развернуть меню',
                onTap: onToggleCollapsed,
              ),
            ],
            const SizedBox(height: 0),
            Container(height: 1, color: _TD.softLine),
            const SizedBox(height: 0),
            Expanded(
              child: ListView.separated(
                padding: EdgeInsets.zero,
                itemCount: sections.length,
                separatorBuilder: (_, __) => const SizedBox(height: 4),
                itemBuilder: (_, i) {
                  final section = sections[i];
                  return _TrackerSideIconButton(
                    icon: section.icon,
                    active: section == selected,
                    tooltip: section.title,
                    onTap: () => onSelect(section),
                  );
                },
              ),
            ),
            const SizedBox(height: 4),
            _TrackerSideIconButton(
              icon: Icons.close_rounded,
              active: false,
              tooltip: liveRunning ? 'Закрыть / сохранить Live' : 'Закрыть окно трекера',
              onTap: onClose,
            ),
            const SizedBox(height: 6),
            _TrackerSideIconButton(
              icon: loading ? Icons.hourglass_top_rounded : Icons.refresh_rounded,
              active: false,
              tooltip: 'Обновить',
              onTap: loading ? null : onRefresh,
            ),
          ],
        ),
      );
    }

    return Container(
      color: Colors.transparent,
      padding: const EdgeInsets.fromLTRB(9, 12, 8, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F5F8),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: Stack(
                  children: [
                    const Center(child: Icon(Icons.sensors_rounded, color: _TD.dim, size: 20)),
                    Positioned(
                      right: 9,
                      bottom: 9,
                      child: Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(
                          color: liveRunning ? _TD.green : _TD.dim,
                          shape: BoxShape.circle,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Flexible(
                          child: Text(
                            'Трекер',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: _TD.text, fontSize: 15.5, fontWeight: FontWeight.w700, letterSpacing: -.45),
                          ),
                        ),
                        const SizedBox(width: 4),
                        _TrackerStatusDot(
                          color: liveRunning ? _TD.green : _TD.dim,
                          label: liveRunning ? 'LIVE' : (connected ? 'ГОТОВО' : 'ВЫКЛ'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 3),
                    Text(
                      teamName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: _TD.muted, fontSize: 12, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              _TrackerSmallGhostButton(
                icon: Icons.close_rounded,
                onTap: onClose,
                tooltip: liveRunning ? 'Закрыть / сохранить Live' : 'Закрыть окно трекера',
              ),
              const SizedBox(width: 6),
              _TrackerSmallGhostButton(
                icon: loading ? Icons.hourglass_top_rounded : Icons.refresh_rounded,
                onTap: loading ? null : onRefresh,
                tooltip: 'Обновить',
              ),
              if (onToggleCollapsed != null) ...[
                const SizedBox(width: 6),
                _TrackerSmallGhostButton(
                  icon: Icons.keyboard_double_arrow_left_rounded,
                  onTap: onToggleCollapsed,
                  tooltip: 'Сузить меню',
                ),
              ],
            ],
          ),
          const SizedBox(height: 4),
          Text(
            clubName,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _TD.muted, fontSize: 10.8, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 3),
          Text(
            selectedPlayer,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(color: _TD.dim, fontSize: 10.5, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.separated(
              padding: EdgeInsets.zero,
              itemCount: sections.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (_, i) {
                final section = sections[i];
                return _TrackerSideNavItem(
                  section: section,
                  active: section == selected,
                  onTap: () => onSelect(section),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackerSideNavItem extends StatelessWidget {
  const _TrackerSideNavItem({required this.section, required this.active, required this.onTap});

  final TrackerWorkspaceSection section;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: active ? _TD.greenSoft : Colors.transparent,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 34,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: active ? Border.all(color: _TD.green.withOpacity(.16), width: 1) : null,
          ),
          child: Row(
            children: [
              Icon(section.icon, color: active ? _TD.green : _TD.dim, size: 18),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  section.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: active ? _TD.text : _TD.graphite,
                    fontSize: 10.8,
                    fontWeight: active ? FontWeight.w700 : FontWeight.w600,
                    letterSpacing: -.12,
                  ),
                ),
              ),
              if (active)
                Container(
                  width: 6,
                  height: 6,
                  decoration: const BoxDecoration(color: _TD.green, shape: BoxShape.circle),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrackerSideIconButton extends StatelessWidget {
  const _TrackerSideIconButton({required this.icon, required this.active, required this.tooltip, this.onTap});

  final IconData icon;
  final bool active;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: active ? _TD.greenSoft : _TD.soft,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: active ? Border.all(color: _TD.green.withOpacity(.16)) : null,
            ),
            child: Icon(icon, color: active ? _TD.green : _TD.dim, size: 18),
          ),
        ),
      ),
    );
  }
}

class _TrackerSmallGhostButton extends StatelessWidget {
  const _TrackerSmallGhostButton({required this.icon, required this.onTap, required this.tooltip});

  final IconData icon;
  final VoidCallback? onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: _TD.soft,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: SizedBox(
            width: 34,
            height: 34,
            child: Icon(icon, color: _TD.dim, size: 18),
          ),
        ),
      ),
    );
  }
}

class _TrackerSideFooterAction extends StatelessWidget {
  const _TrackerSideFooterAction({required this.icon, required this.label, required this.onTap});

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _TD.soft,
      borderRadius: BorderRadius.circular(12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          height: 34,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: _TD.dim, size: 16),
              const SizedBox(width: 4),
              Text(label, style: const TextStyle(color: _TD.graphite, fontSize: 10.8, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrackerWindowCornerButton extends StatelessWidget {
  const _TrackerWindowCornerButton({required this.maximized, required this.onTap});

  final bool maximized;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: maximized ? 'Свернуть окно' : 'Развернуть окно',
      child: Material(
        color: const Color(0xFFF3F5F8),
        shape: const CircleBorder(),
        child: InkWell(
          onTap: onTap,
          customBorder: const CircleBorder(),
          child: Container(
            width: 28,
            height: 28,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color: _TD.softLine),
              boxShadow: _TD.cardShadow,
            ),
            child: Icon(maximized ? Icons.close_fullscreen_rounded : Icons.open_in_full_rounded, size: 15, color: _TD.dim),
          ),
        ),
      ),
    );
  }
}

class _TrackerProgramTabsBar extends StatelessWidget {
  const _TrackerProgramTabsBar({
    required this.clubName,
    required this.teamName,
    required this.selectedPlayer,
    required this.selected,
    required this.loading,
    required this.liveRunning,
    required this.connected,
    required this.maximized,
    required this.onSelect,
    required this.onRefresh,
    required this.onClose,
    required this.onMinimize,
    required this.onToggleMaximize,
  });

  final String clubName;
  final String teamName;
  final String selectedPlayer;
  final TrackerWorkspaceSection selected;
  final bool loading;
  final bool liveRunning;
  final bool connected;
  final bool maximized;
  final ValueChanged<TrackerWorkspaceSection> onSelect;
  final VoidCallback onRefresh;
  final VoidCallback onClose;
  final VoidCallback onMinimize;
  final VoidCallback onToggleMaximize;

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final compact = width < 1180;

    return Container(
      height: compact ? 56 : 60,
      padding: EdgeInsets.fromLTRB(compact ? 10 : 14, 5, compact ? 10 : 14, 5),
      decoration: BoxDecoration(
        color: _TD.panel,
        border: Border(bottom: BorderSide(color: _TD.softLine.withOpacity(.88), width: 1)),
      ),
      child: Row(
        children: [
          Container(
            width: compact ? 34 : 38,
            height: compact ? 34 : 38,
            decoration: BoxDecoration(
              color: _TD.card2,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Stack(
              children: [
                const Center(
                  child: Icon(Icons.sensors_rounded, color: _TD.dim, size: 20),
                ),
                Positioned(
                  right: 7,
                  bottom: 7,
                  child: Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: connected ? _TD.green : _TD.dim,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          SizedBox(
            width: compact ? 148 : 198,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(
                      child: Text(
                        'Tracker Pro',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _TD.text,
                          fontSize: compact ? 13.5 : 14,
                          fontWeight: FontWeight.w500,
                          letterSpacing: -.15,
                        ),
                      ),
                    ),
                    const SizedBox(width: 7),
                    _TrackerStatusDot(
                      color: liveRunning ? _TD.green : _TD.dim,
                      label: liveRunning ? 'LIVE' : (connected ? 'ГОТОВО' : 'ВЫКЛ'),
                    ),
                  ],
                ),
                const SizedBox(height: 3),
                Text(
                  '$clubName · $teamName',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _TD.muted,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w500,
                  ),
                ),

              ],
            ),
          ),
          Expanded(
            child: Align(
              alignment: Alignment.center,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                child: Row(
                  children: _trackerVisibleSections.map((section) {
                    return Padding(
                      padding: const EdgeInsets.only(right: 6),
                      child: _TrackerProgramTab(
                        section: section,
                        active: section == selected,
                        compact: compact,
                        onTap: () => onSelect(section),
                      ),
                    );
                  }).toList(growable: false),
                ),
              ),
            ),
          ),
          const SizedBox(width: 4),
          _TrackerProgramIconButton(
            icon: Icons.refresh_rounded,
            tooltip: 'Обновить данные трекера',
            loading: loading,
            onTap: loading ? null : onRefresh,
          ),
        ],
      ),
    );
  }
}

class _MacWindowControls extends StatelessWidget {
  const _MacWindowControls({
    required this.maximized,
    required this.onClose,
    required this.onMinimize,
    required this.onToggleMaximize,
  });

  final bool maximized;
  final VoidCallback onClose;
  final VoidCallback onMinimize;
  final VoidCallback onToggleMaximize;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _MacWindowButton(
          icon: Icons.close_rounded,
          tooltip: 'Закрыть окно трекера',
          onTap: onClose,
        ),
        const SizedBox(width: 7),
        _MacWindowButton(
          icon: Icons.remove_rounded,
          tooltip: 'Свернуть',
          onTap: onMinimize,
        ),
        const SizedBox(width: 7),
        _MacWindowButton(
          icon: maximized ? Icons.close_fullscreen_rounded : Icons.open_in_full_rounded,
          tooltip: maximized ? 'Вернуть размер' : 'Развернуть',
          onTap: onToggleMaximize,
        ),
      ],
    );
  }
}

class _MacWindowButton extends StatefulWidget {
  const _MacWindowButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  State<_MacWindowButton> createState() => _MacWindowButtonState();
}

class _MacWindowButtonState extends State<_MacWindowButton> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: widget.tooltip,
      waitDuration: const Duration(milliseconds: 450),
      child: MouseRegion(
        onEnter: (_) => setState(() => _hovered = true),
        onExit: (_) => setState(() => _hovered = false),
        child: Material(
          color: _hovered ? const Color(0xFFE9EDF2) : const Color(0xFFF3F5F8),
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: widget.onTap,
            child: SizedBox(
              width: 22,
              height: 22,
              child: Icon(widget.icon, size: 12, color: _TD.dim),
            ),
          ),
        ),
      ),
    );
  }
}

class _TrackerProgramTab extends StatefulWidget {
  const _TrackerProgramTab({
    required this.section,
    required this.active,
    required this.compact,
    required this.onTap,
  });

  final TrackerWorkspaceSection section;
  final bool active;
  final bool compact;
  final VoidCallback onTap;

  @override
  State<_TrackerProgramTab> createState() => _TrackerProgramTabState();
}

class _TrackerProgramTabState extends State<_TrackerProgramTab> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final active = widget.active;
    final bg = active ? Colors.white.withOpacity(.92) : (_hovered ? _TD.soft : Colors.transparent);
    final fg = active ? _TD.text : _TD.graphiteSoft;
    final iconColor = active ? _TD.green : _TD.dim;

    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        height: widget.compact ? 34 : 36,
        constraints: BoxConstraints(minWidth: widget.compact ? 42 : 82),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(13),
          border: active ? Border.all(color: _TD.greenBorder) : Border.all(color: Colors.transparent),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(13),
            onTap: widget.onTap,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: widget.compact ? 10 : 12),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(widget.section.icon, size: 18, color: iconColor),
                  if (!widget.compact) ...[
                    const SizedBox(width: 7),
                    Text(
                      widget.section.title,
                      style: TextStyle(
                        color: fg,
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        letterSpacing: -.15,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TrackerStatusDot extends StatelessWidget {
  const _TrackerStatusDot({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: color.withOpacity(.10),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 6,
            height: 6,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 5),
          Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 9,
              fontWeight: FontWeight.w500,
              letterSpacing: .2,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackerProgramIconButton extends StatelessWidget {
  const _TrackerProgramIconButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.loading = false,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: _TD.card2,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Container(
            width: 42,
            height: 42,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
            ),
            child: loading
                ? const SizedBox(
                    width: 17,
                    height: 17,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Icon(icon, size: 20, color: _TD.text),
          ),
        ),
      ),
    );
  }
}

class _DarkRail extends StatelessWidget {
  const _DarkRail({
    required this.selected,
    required this.onSelect,
    required this.onBack,
  });

  final TrackerWorkspaceSection selected;
  final ValueChanged<TrackerWorkspaceSection> onSelect;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final items = _trackerVisibleSections;
    return Container(
      width: 72,
      padding: const EdgeInsets.fromLTRB(6, 6, 4, 6),
      child: Container(
        decoration: BoxDecoration(
          color: _TD.rail,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(.045),
              blurRadius: 18,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Column(
          children: [
            Expanded(
              child: ListView.separated(
                padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 6),
                itemCount: items.length,
                separatorBuilder: (_, __) => const SizedBox(height: 5),
                itemBuilder: (context, i) {
                  final item = items[i];
                  return _RailButton(
                    icon: item.icon,
                    label: item.title,
                    active: item == selected,
                    onTap: () => onSelect(item),
                  );
                },
              ),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 6),
              child: SizedBox(height: 10),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 0, 6, 6),
              child: _RailButton(
                icon: Icons.arrow_back_rounded,
                label: 'Назад',
                active: false,
                onTap: onBack,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RailButton extends StatefulWidget {
  const _RailButton({required this.icon, required this.label, required this.active, required this.onTap});
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;
  @override
  State<_RailButton> createState() => _RailButtonState();
}

class _RailButtonState extends State<_RailButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final bg = widget.active ? _TD.green.withOpacity(.10) : Colors.transparent;
    final fg = widget.active ? _TD.green : _TD.text;
    final subFg = widget.active ? _TD.green : _TD.muted;
    return Listener(
      onPointerDown: (_) => setState(() => _pressed = true),
      onPointerUp: (_) => setState(() => _pressed = false),
      onPointerCancel: (_) => setState(() => _pressed = false),
      child: AnimatedScale(
        duration: const Duration(milliseconds: 110),
        scale: _pressed ? .95 : 1,
        child: Material(
          color: bg,
          borderRadius: BorderRadius.circular(11),
          child: InkWell(
            onTap: widget.onTap,
            borderRadius: BorderRadius.circular(11),
            child: Container(
              height: 50,
              padding: const EdgeInsets.fromLTRB(4, 5, 4, 4),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(11),
              ),
              child: Stack(
                children: [
                  Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(widget.icon, color: fg, size: 18),
                        const SizedBox(height: 4),
                        Text(
                          widget.label,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: subFg,
                            fontSize: 8.3,
                            fontWeight: FontWeight.w500,
                            letterSpacing: -.15,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.teamName, required this.clubName, required this.selectedPlayer, required this.selectedSection, required this.loading, required this.onRefresh});
  final String teamName;
  final String clubName;
  final String selectedPlayer;
  final TrackerWorkspaceSection selectedSection;
  final bool loading;
  final VoidCallback onRefresh;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 54,
      margin: const EdgeInsets.fromLTRB(0, 8, 8, 0),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: const BoxDecoration(color: Colors.transparent, border: Border(bottom: BorderSide(color: _TD.softLine))),
      child: Row(children: [
        Container(width: 34, height: 34, decoration: _TD.softSurface(radius: 12), child: Icon(selectedSection.icon, color: _TD.dim, size: 18)),
        const SizedBox(width: 10),
        Expanded(child: Text('Спортотека Трекинг · ${selectedSection.title}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w700, fontSize: 10.5))),
        _TopPill(label: clubName, value: teamName),
        const SizedBox(width: 4),
        _TopPill(label: 'Игрок', value: selectedPlayer),
        const SizedBox(width: 4),
        IconButton(onPressed: loading ? null : onRefresh, icon: loading ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.refresh_rounded, color: _TD.text)),
      ]),
    );
  }
}

class _TopPill extends StatelessWidget {
  const _TopPill({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 38,
      constraints: const BoxConstraints(maxWidth: 230),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: _TD.softSurface(radius: 12),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(color: _TD.dim, fontSize: 8.5, fontWeight: FontWeight.w500)),
        Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 9.4, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _WorkspacePaneDivider extends StatelessWidget {
  const _WorkspacePaneDivider.vertical({this.thickness = 1, this.padding = 0}) : axis = Axis.vertical;
  const _WorkspacePaneDivider.horizontal({this.thickness = 1, this.padding = 0}) : axis = Axis.horizontal;

  final Axis axis;
  final double thickness;
  final double padding;

  @override
  Widget build(BuildContext context) {
    final line = Container(color: _TD.border.withOpacity(.82));
    if (axis == Axis.vertical) {
      return Padding(
        padding: EdgeInsets.symmetric(horizontal: padding),
        child: SizedBox(width: thickness, child: line),
      );
    }
    return Padding(
      padding: EdgeInsets.symmetric(vertical: padding),
      child: SizedBox(height: thickness, child: line),
    );
  }
}

class _DarkPage extends StatelessWidget {
  const _DarkPage({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.child,
    this.trailing,
  });

  final String title;
  final String subtitle;
  final IconData icon;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    // Не рисуем второе окно внутри трекера: внешний programWindowDecoration
    // уже является общей рамкой. На телефоне секционная шапка не должна
    // висеть отдельным неподвижным блоком: весь мобильный раздел собирается
    // как roster-лента из горизонтальных действий и карточек.
    final hasToolbar = title.trim().isNotEmpty || trailing != null;
    final mq = MediaQuery.maybeOf(context);
    final mobile = mq != null && mq.size.width < 720;

    if (mobile) {
      return Container(color: Colors.transparent, child: child);
    }

    return Container(
      color: Colors.transparent,
      child: Column(
        children: [
          if (hasToolbar) ...[
            _WorkspaceFlatHeader(
              icon: icon,
              title: title,
              subtitle: subtitle,
              trailing: trailing,
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          Expanded(child: child),
        ],
      ),
    );
  }
}

class _WorkspaceFlatHeader extends StatelessWidget {
  const _WorkspaceFlatHeader({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.trailing,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    Widget titleRow({bool compact = false}) {
      return Row(
        children: [
          Container(
            width: compact ? 26 : 28,
            height: compact ? 26 : 28,
            decoration: BoxDecoration(
              color: _TD.greenSoft,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: _TD.green.withOpacity(.12)),
            ),
            child: Icon(icon, color: _TD.green, size: compact ? 14 : 15),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _TD.text,
                    fontSize: compact ? 11.0 : 11.4,
                    fontWeight: FontWeight.w800,
                    letterSpacing: -.28,
                  ),
                ),
                if (subtitle.trim().isNotEmpty)
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _TD.muted,
                      fontSize: 8.8,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
              ],
            ),
          ),
        ],
      );
    }

    return LayoutBuilder(builder: (context, constraints) {
      final compact = constraints.maxWidth < 720;
      if (compact && trailing != null) {
        return Container(
          height: 78,
          padding: const EdgeInsets.fromLTRB(8, 6, 8, 6),
          color: Colors.transparent,
          child: Column(
            children: [
              SizedBox(height: 30, child: titleRow(compact: true)),
              const SizedBox(height: 6),
              SizedBox(
                height: 30,
                width: double.infinity,
                child: Align(alignment: Alignment.centerLeft, child: trailing!),
              ),
            ],
          ),
        );
      }

      return Container(
        height: compact ? 42 : 38,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        color: Colors.transparent,
        child: Row(
          children: [
            Expanded(child: titleRow(compact: compact)),
            if (trailing != null) ...[
              const SizedBox(width: 8),
              Flexible(
                fit: FlexFit.loose,
                child: Align(alignment: Alignment.centerRight, child: trailing!),
              ),
            ],
          ],
        ),
      );
    });
  }
}

class _DarkCard extends StatelessWidget {
  const _DarkCard({
    required this.title,
    required this.subtitle,
    required this.child,
  });

  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final hasHeader = title.trim().isNotEmpty || subtitle.trim().isNotEmpty;
    final mobile = MediaQuery.of(context).size.width < 720;

    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: mobile
          ? const BoxDecoration(color: Colors.transparent, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7)))
          : _TD.seamlessPane(),
      child: Column(
        children: [
          if (hasHeader) ...[
            Container(
              height: 32,
              padding: const EdgeInsets.symmetric(horizontal: 8),
              color: Colors.transparent,
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _TD.text,
                        fontSize: 10.8,
                        fontWeight: FontWeight.w700,
                        letterSpacing: -.18,
                      ),
                    ),
                  ),
                  if (subtitle.trim().isNotEmpty)
                    Flexible(
                      child: Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        textAlign: TextAlign.right,
                        style: const TextStyle(
                          color: _TD.dim,
                          fontSize: 8.8,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const _WorkspacePaneDivider.horizontal(),
          ],
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(6),
              child: child,
            ),
          ),
        ],
      ),
    );
  }
}

class _DarkActionButton extends StatefulWidget {
  const _DarkActionButton({required this.icon, required this.label, required this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool primary;
  @override
  State<_DarkActionButton> createState() => _DarkActionButtonState();
}

class _DarkActionButtonState extends State<_DarkActionButton> {
  bool _pressed = false;
  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    return Listener(
      onPointerDown: enabled ? (_) => setState(() => _pressed = true) : null,
      onPointerUp: enabled ? (_) => setState(() => _pressed = false) : null,
      onPointerCancel: enabled ? (_) => setState(() => _pressed = false) : null,
      child: AnimatedScale(
        scale: _pressed ? .97 : 1,
        duration: const Duration(milliseconds: 90),
        child: Material(
          color: widget.primary ? _TD.green : _TD.panel,
          borderRadius: BorderRadius.circular(4),
          child: InkWell(
            onTap: widget.onTap,
            borderRadius: BorderRadius.circular(4),
            child: Container(
              height: 30,
              padding: const EdgeInsets.symmetric(horizontal: 9),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(4),
                border: Border.all(color: widget.primary ? _TD.green : _TD.borderStrong.withOpacity(.82)),
              ),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(widget.icon, color: widget.primary ? Colors.white : _TD.graphite, size: 14),
                const SizedBox(width: 5),
                Text(widget.label, style: TextStyle(color: widget.primary ? Colors.white : _TD.graphite, fontSize: 9.4, fontWeight: FontWeight.w700)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}

class _DarkMetricTile extends StatelessWidget {
  const _DarkMetricTile({required this.icon, required this.title, required this.value, required this.subtitle});
  final IconData icon;
  final String title;
  final String value;
  final String subtitle;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
      padding: const EdgeInsets.all(8),
      child: Row(children: [
        Icon(icon, color: _TD.graphite, size: 16),
        const SizedBox(width: 9),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9, fontWeight: FontWeight.w600)),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 10, fontWeight: FontWeight.w700)),
          Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.dim, fontSize: 8.6, fontWeight: FontWeight.w600)),
        ])),
      ]),
    );
  }
}

class _EquipmentMiniBadge extends StatelessWidget {
  const _EquipmentMiniBadge({required this.icon, required this.label, required this.active});
  final IconData icon;
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: active ? _TD.greenSoft : const Color(0xFFF4F6F8),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: active ? _TD.greenBorder : _TD.borderStrong),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, size: 12, color: active ? _TD.green : _TD.muted),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: active ? _TD.green : _TD.muted, fontSize: 9.4, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _EquipmentAssignmentBox extends StatelessWidget {
  const _EquipmentAssignmentBox({required this.icon, required this.title, required this.subtitle, required this.child});
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(color: const Color(0xFFF7F9FB), borderRadius: BorderRadius.circular(18), border: Border.all(color: _TD.borderStrong)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(width: 32, height: 32, alignment: Alignment.center, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: _TD.borderStrong)), child: Icon(icon, color: _TD.green, size: 17)),
          const SizedBox(width: 9),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(color: _TD.text, fontSize: 12.2, fontWeight: FontWeight.w900)),
            const SizedBox(height: 2),
            Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 10.2, fontWeight: FontWeight.w700)),
          ])),
        ]),
        const SizedBox(height: 11),
        child,
      ]),
    );
  }
}


class _DarkListTile extends StatelessWidget {
  const _DarkListTile({required this.icon, required this.title, required this.subtitle, this.trailing, this.active = false, this.onTap, this.avatarUrl, this.initials});
  final IconData icon;
  final String title;
  final String subtitle;
  final String? trailing;
  final bool active;
  final VoidCallback? onTap;
  final String? avatarUrl;
  final String? initials;
  @override
  Widget build(BuildContext context) {
    final color = active ? _TD.green : _TD.muted;
    return Material(
      color: active ? _TD.greenSoft : _TD.panel,
      child: InkWell(
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: 42),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
          child: Row(children: [
            avatarUrl == null && initials == null
                ? Container(width: 28, height: 28, alignment: Alignment.center, decoration: BoxDecoration(color: _TD.soft, borderRadius: BorderRadius.circular(4)), child: Icon(icon, color: color, size: 15))
                : _PlayerAvatarDark(
                    url: avatarUrl,
                    initials: initials ?? _playerInitials(title),
                    size: 30,
                    active: active,
                  ),
            const SizedBox(width: 4),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w700, fontSize: 10.8)),
              const SizedBox(height: 1),
              Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.2, fontWeight: FontWeight.w600)),
            ])),
            if (trailing != null) Text(trailing!, style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 9.4)),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right_rounded, color: _TD.dim, size: 17),
          ]),
        ),
      ),
    );
  }
}


class _HeartRateDeviceDarkTile extends StatelessWidget {
  const _HeartRateDeviceDarkTile({
    required this.device,
    required this.players,
    required this.selectedPlayerId,
    required this.sampleText,
    required this.active,
    required this.selected,
    required this.connecting,
    required this.onSelect,
    required this.onConnect,
    required this.onPlayerChanged,
  });

  final HeartRateBleDevice device;
  final List<TrackerPlayerOption> players;
  final int? selectedPlayerId;
  final String sampleText;
  final bool active;
  final bool selected;
  final bool connecting;
  final VoidCallback onSelect;
  final VoidCallback? onConnect;
  final ValueChanged<int?> onPlayerChanged;

  @override
  Widget build(BuildContext context) {
    final stateColor = active ? _TD.green : (selected ? _TD.green : _TD.muted);
    final validValue = selectedPlayerId != null && players.any((p) => p.id == selectedPlayerId) ? selectedPlayerId : null;
    final status = active ? 'подключено' : (device.rawProbe ? 'проверить' : 'подключить');
    return Material(
      color: selected || active ? _TD.greenSoft : _TD.panel,
      child: InkWell(
        onTap: onSelect,
        child: Container(
          padding: const EdgeInsets.all(9),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(width: 30, height: 30, alignment: Alignment.center, decoration: BoxDecoration(color: _TD.soft, borderRadius: BorderRadius.circular(8)), child: Icon(active ? Icons.check_circle_rounded : Icons.monitor_heart_rounded, color: stateColor, size: 16)),
              const SizedBox(width: 8),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(device.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w800, fontSize: 11.2)),
                const SizedBox(height: 2),
                Text('${device.id} · RSSI ${device.rssi} · $sampleText${device.serviceHit ? ' · Heart Rate 180D' : (device.rawProbe ? ' · BLE-кандидат' : '')}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.1, fontWeight: FontWeight.w600)),
              ])),
              const SizedBox(width: 8),
              Text(status, style: TextStyle(color: stateColor, fontWeight: FontWeight.w800, fontSize: 9.4)),
            ]),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(
                child: Container(
                  height: 42,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: _TD.borderStrong)),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int?>(
                      value: validValue,
                      isExpanded: true,
                      icon: const Icon(Icons.expand_more_rounded, size: 18, color: _TD.muted),
                      hint: const Text('Назначить игроку', style: TextStyle(color: _TD.muted, fontSize: 10.2, fontWeight: FontWeight.w700)),
                      items: <DropdownMenuItem<int?>>[
                        const DropdownMenuItem<int?>(value: null, child: Text('Игрок не выбран', style: TextStyle(fontSize: 10.4, fontWeight: FontWeight.w700))),
                        ...players.map((p) => DropdownMenuItem<int?>(value: p.id, child: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.4, fontWeight: FontWeight.w800)))),
                      ],
                      onChanged: onPlayerChanged,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              SizedBox(
                height: 42,
                child: OutlinedButton.icon(
                  onPressed: connecting ? null : onConnect,
                  style: OutlinedButton.styleFrom(
                    foregroundColor: _TD.green,
                    side: const BorderSide(color: _TD.greenBorder),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: Icon(active ? Icons.touch_app_rounded : Icons.bluetooth_connected_rounded, size: 15),
                  label: Text(active ? 'выбрать' : 'подключить', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
                ),
              ),
            ]),
          ]),
        ),
      ),
    );
  }
}

class _SavedDeviceDarkTile extends StatelessWidget {
  const _SavedDeviceDarkTile({required this.device, required this.players, required this.onBind, this.onForget, this.aliasCount = 1, this.status = 'серверная запись', this.statusColor = _TD.muted});
  final TrackerDeviceModel device;
  final List<TrackerPlayerOption> players;
  final ValueChanged<TrackerPlayerOption?> onBind;
  final VoidCallback? onForget;
  final int aliasCount;
  final String status;
  final Color statusColor;
  @override
  Widget build(BuildContext context) {
    final boundPlayers = players.where((p) => p.id == device.playerId).toList();
    final boundPlayer = boundPlayers.isEmpty ? null : boundPlayers.first;

    return Container(
      margin: EdgeInsets.zero,
      padding: const EdgeInsets.all(8),
      decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          children: [
            _PlayerAvatarDark(
              url: boundPlayer?.avatar,
              initials: _playerInitials(boundPlayer?.name ?? device.playerName ?? device.deviceName),
              size: 30,
              active: boundPlayer != null,
              fallbackIcon: Icons.sensors_rounded,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(
                      child: Text(device.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w700, fontSize: 11)),
                    ),
                    if (aliasCount > 1) ...[
                      const SizedBox(width: 6),
                      Text('дублей: $aliasCount', style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w600, fontSize: 9.2)),
                    ],
                  ]),
                  const SizedBox(height: 3),
                  Text(
                    '${device.deviceUuid}${boundPlayer == null && device.playerName == null ? '' : ' · ${boundPlayer?.name ?? device.playerName}'}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: _TD.muted, fontSize: 9.2, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 4),
                  Row(children: [
                    Icon(status.contains('TX/RX') ? Icons.bluetooth_connected_rounded : (status.contains('занят') ? Icons.cloud_sync_rounded : Icons.link_rounded), size: 13, color: statusColor),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(status, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: statusColor, fontSize: 9.2, fontWeight: FontWeight.w700)),
                    ),
                  ]),
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        DropdownButtonFormField<int?>(
          value: players.any((p) => p.id == device.playerId) ? device.playerId : null,
          dropdownColor: _TD.card,
          isExpanded: true,
          decoration: InputDecoration(
            isDense: true,
            labelText: 'Игрок',
            labelStyle: const TextStyle(color: _TD.muted),
            filled: true,
            fillColor: _TD.panel,
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(4), borderSide: BorderSide.none),
          ),
          style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w600, fontSize: 10.5),
          items: [
            const DropdownMenuItem<int?>(
              value: null,
              child: Text('Без игрока'),
            ),
            ...players.map(
              (p) => DropdownMenuItem<int?>(
                value: p.id,
                child: Row(
                  children: [
                    _PlayerAvatarDark(
                      url: p.avatar,
                      initials: _playerInitials(p.name),
                      size: 24,
                      active: true,
                    ),
                    const SizedBox(width: 4),
                    Expanded(
                      child: Text(
                        p.name,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
          onChanged: (id) {
            final matches = players.where((p) => p.id == id).toList();
            onBind(matches.isEmpty ? null : matches.first);
          },
        ),
        const SizedBox(height: 6),
        Row(children: [
          Expanded(
            child: Text(
              'Не live: это только запись в базе. Для поиска используйте «Сброс + поиск» выше.',
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _TD.muted, fontSize: 9.0, fontWeight: FontWeight.w600),
            ),
          ),
          const SizedBox(width: 6),
          InkWell(
            onTap: onForget,
            borderRadius: BorderRadius.circular(8),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
              child: Row(mainAxisSize: MainAxisSize.min, children: const [
                Icon(Icons.delete_outline_rounded, size: 14, color: _TD.red),
                SizedBox(width: 3),
                Text('Удалить запись', style: TextStyle(color: _TD.red, fontWeight: FontWeight.w800, fontSize: 9.4)),
              ]),
            ),
          ),
        ]),
      ]),
    );
  }
}


class _PlayerAvatarDark extends StatelessWidget {
  const _PlayerAvatarDark({
    required this.url,
    required this.initials,
    this.size = 30,
    this.active = false,
    this.fallbackIcon,
  });

  final String? url;
  final String initials;
  final double size;
  final bool active;
  final IconData? fallbackIcon;

  @override
  Widget build(BuildContext context) {
    final imageUrl = _normalizeAvatarUrl(url);
    final borderColor = active ? _TD.green : _TD.border;

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        boxShadow: active
            ? [
                BoxShadow(
                  color: _TD.blue.withOpacity(.10),
                  blurRadius: 12,
                  offset: const Offset(0, 4),
                ),
              ]
            : null,
      ),
      child: ClipOval(
        child: imageUrl == null
            ? _AvatarFallback(
                initials: initials,
                size: size,
                icon: fallbackIcon,
              )
            : Image.network(
                imageUrl,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => _AvatarFallback(
                  initials: initials,
                  size: size,
                  icon: fallbackIcon,
                ),
              ),
      ),
    );
  }
}

class _AvatarFallback extends StatelessWidget {
  const _AvatarFallback({
    required this.initials,
    required this.size,
    this.icon,
  });

  final String initials;
  final double size;
  final IconData? icon;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        color: Color(0xFFF2F4F7),
      ),
      child: icon != null
          ? Icon(icon, color: _TD.green, size: size * .48)
          : Text(
              initials,
              maxLines: 1,
              overflow: TextOverflow.clip,
              style: TextStyle(
                color: _TD.text,
                fontSize: size * .33,
                fontWeight: FontWeight.w500,
                letterSpacing: -.4,
              ),
            ),
    );
  }
}

String _playerInitials(String name) {
  final parts = name
      .trim()
      .split(RegExp(r'\s+'))
      .where((p) => p.trim().isNotEmpty)
      .toList();

  if (parts.isEmpty) return 'И';
  if (parts.length == 1) {
    final s = parts.first;
    return s.length <= 2 ? s.toUpperCase() : s.substring(0, 2).toUpperCase();
  }

  return '${parts[0].substring(0, 1)}${parts[1].substring(0, 1)}'.toUpperCase();
}

String? _normalizeAvatarUrl(String? raw) {
  final value = (raw ?? '').trim();
  if (value.isEmpty || value == 'null') return null;

  if (value.startsWith('http://') || value.startsWith('https://')) {
    return value;
  }

  final cleaned = value.startsWith('/') ? value.substring(1) : value;

  // Основной домен API/загрузок, который используется в проекте.
  return 'https://sportotekaapp.ru/$cleaned';
}


class _DashboardKpiData {
  const _DashboardKpiData({required this.icon, required this.title, required this.value, required this.subtitle});
  final IconData icon;
  final String title;
  final String value;
  final String subtitle;
}

class _DashboardKpiStrip extends StatelessWidget {
  const _DashboardKpiStrip({required this.items});
  final List<_DashboardKpiData> items;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, c) {
      final mobileList = false;
      return ListView.separated(
        scrollDirection: mobileList ? Axis.vertical : Axis.horizontal,
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox.shrink(),
        itemBuilder: (context, index) {
          final item = items[index];
          if (mobileList) {
            return Container(
              height: 48,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: const BoxDecoration(
                color: Colors.transparent,
                border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7)),
              ),
              child: Row(
                children: [
                  Icon(item.icon, color: _TD.graphite, size: 17),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.6, fontWeight: FontWeight.w600)),
                        Text(item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.dim, fontSize: 8.8, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  Text(item.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 12.2, fontWeight: FontWeight.w800, letterSpacing: -.35)),
                ],
              ),
            );
          }

          return Container(
            width: 150,
            padding: const EdgeInsets.all(8),
            decoration: const BoxDecoration(
              color: Colors.transparent,
              border: Border(right: BorderSide(color: _TD.borderStrong, width: .7), bottom: BorderSide(color: _TD.borderStrong, width: .7)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 30,
                      height: 30,
                      decoration: BoxDecoration(color: _TD.green.withOpacity(.10), borderRadius: BorderRadius.circular(4)),
                      child: Icon(item.icon, color: _TD.graphite, size: 18),
                    ),
                    const Spacer(),
                    Text(item.subtitle, style: const TextStyle(color: _TD.dim, fontSize: 8.8, fontWeight: FontWeight.w600)),
                  ],
                ),
                const Spacer(),
                Text(item.value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontSize: 12.8, fontWeight: FontWeight.w700, letterSpacing: -.4)),
                const SizedBox(height: 2),
                Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9.4, fontWeight: FontWeight.w600)),
              ],
            ),
          );
        },
      );
    });
  }
}

class _ReadinessRow extends StatelessWidget {
  const _ReadinessRow({required this.title, required this.text, required this.ok});
  final String title;
  final String text;
  final bool ok;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
      decoration: BoxDecoration(color: ok ? _TD.greenSoft : _TD.panel, border: const Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle_rounded : Icons.warning_amber_rounded, color: ok ? _TD.green : _TD.orange, size: 15),
          const SizedBox(width: 9),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w700, fontSize: 10.5)),
              Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w600, fontSize: 9.2)),
            ]),
          ),
        ],
      ),
    );
  }
}

class _ScenarioButton extends StatelessWidget {
  const _ScenarioButton({required this.step, required this.title, required this.text, required this.icon, required this.onTap});
  final String step;
  final String title;
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: _TD.panel,
      borderRadius: BorderRadius.circular(0),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(0),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 7),
          decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))),
          child: Row(
            children: [
              CircleAvatar(radius: 12, backgroundColor: _TD.green.withOpacity(.12), child: Text(step, style: const TextStyle(color: _TD.green, fontSize: 9.4, fontWeight: FontWeight.w600))),
              const SizedBox(width: 10),
              Icon(icon, color: _TD.graphite, size: 15),
              const SizedBox(width: 9),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w700, fontSize: 10.4)),
                  Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w600, fontSize: 9.0)),
                ]),
              ),
              const Icon(Icons.chevron_right_rounded, color: _TD.dim),
            ],
          ),
        ),
      ),
    );
  }
}

class _DarkEmpty extends StatelessWidget {
  const _DarkEmpty({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) {
    return Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 360), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 30, color: _TD.dim),
      const SizedBox(height: 0),
      Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w500)),
    ])));
  }
}

class _DarkError extends StatelessWidget {
  const _DarkError({required this.error, required this.onRetry});
  final String error;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) {
    return Center(child: Container(constraints: const BoxConstraints(maxWidth: 560), padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Color(0xFFFFF1F1), borderRadius: BorderRadius.circular(10)), child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.warning_amber_rounded, color: _TD.red),
      const SizedBox(height: 4),
      Text(error, textAlign: TextAlign.center, style: const TextStyle(color: _TD.red, fontWeight: FontWeight.w500)),
      const SizedBox(height: 0),
      _DarkActionButton(icon: Icons.refresh_rounded, label: 'Повторить', onTap: onRetry),
    ])));
  }
}

class _PresetDarkButton extends StatelessWidget {
  const _PresetDarkButton({required this.title, required this.subtitle, required this.onTap});
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => _DarkListTile(icon: Icons.tune_rounded, title: title, subtitle: subtitle, trailing: 'применить', onTap: onTap);
}

class _MiniDebugPill extends StatelessWidget {
  const _MiniDebugPill({required this.label, required this.active});
  final String label;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: active ? _TD.green.withOpacity(.12) : _TD.orange.withOpacity(.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 6, height: 6, decoration: BoxDecoration(color: active ? _TD.green : _TD.orange, shape: BoxShape.circle)),
        const SizedBox(width: 5),
        Text(label, style: TextStyle(color: active ? _TD.greenDark : _TD.orange, fontSize: 9.6, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _DarkHint extends StatelessWidget {
  const _DarkHint({required this.text});
  final String text;
  @override
  Widget build(BuildContext context) {
    return Container(width: double.infinity, padding: const EdgeInsets.all(8), decoration: const BoxDecoration(color: _TD.panel, border: Border(bottom: BorderSide(color: _TD.borderStrong, width: .7))), child: Text(text, style: const TextStyle(color: _TD.graphiteSoft, fontWeight: FontWeight.w600, fontSize: 9.6, height: 1.22)));
  }
}

class _DarkCornerChip extends StatelessWidget {
  const _DarkCornerChip({
    required this.label,
    required this.value,
    required this.ready,
    this.active = false,
    this.saved = false,
    this.onTap,
  });

  final String label;
  final String value;
  final bool ready;
  final bool active;
  final bool saved;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = ready ? _TD.green : active ? const Color(0xFF2563EB) : _TD.dim;
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        width: 230,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: ready
              ? _TD.green.withOpacity(.10)
              : active
                  ? const Color(0xFF2563EB).withOpacity(.10)
                  : _TD.card2,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(children: [
          CircleAvatar(
            radius: 15,
            backgroundColor: color,
            child: ready
                ? const Icon(Icons.check_rounded, color: Colors.white, size: 15)
                : Text(label, style: const TextStyle(color: _TD.bg, fontSize: 9.4, fontWeight: FontWeight.w600)),
          ),
          const SizedBox(width: 10),
          Expanded(child: Text(value, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontSize: 9, fontWeight: FontWeight.w600))),
        ]),
      ),
    );
  }
}


class _RemoteTrackerPresence {
  const _RemoteTrackerPresence({
    required this.uuid,
    required this.name,
    required this.message,
    required this.createdAtLabel,
    this.playerName,
    this.teamName,
    this.fieldTitle,
    this.rssi,
    this.liveRunning = false,
    this.fieldCalibrated = false,
    this.hasFreshGps = false,
  });

  final String uuid;
  final String name;
  final String message;
  final String createdAtLabel;
  final String? playerName;
  final String? teamName;
  final String? fieldTitle;
  final int? rssi;
  final bool liveRunning;
  final bool fieldCalibrated;
  final bool hasFreshGps;

  static List<_RemoteTrackerPresence> fromLogs(List<Map<String, dynamic>> logs) {
    final byUuid = <String, _RemoteTrackerPresence>{};
    for (final log in logs) {
      final ctx = _decodeContext(log['context_json'] ?? log['context']);
      final rawTime = '${log['created_at'] ?? ctx['client_time'] ?? ''}';
      if (!_isFresh(rawTime, maxAgeSeconds: 65)) continue;

      final txRxReady = _asBool(ctx['ble_command_channel_ready']);
      final liveRunning = _asBool(ctx['live_running']);
      final bleConnected = _asBool(ctx['ble_connected']);
      final message = '${log['message'] ?? ''}'.toLowerCase();
      if (!(txRxReady || liveRunning || bleConnected)) continue;
      if (message.contains('tx/rx не готов') || message.contains('not connected') || message.contains('отключ')) continue;

      final uuid = '${ctx['ble_device_uuid'] ?? log['device_uuid'] ?? ''}'.trim();
      if (uuid.isEmpty || byUuid.containsKey(uuid)) continue;

      final name = '${ctx['ble_device_name'] ?? log['device_name'] ?? 'BLE ${uuid.length <= 8 ? uuid : uuid.substring(0, 8)}'}'.trim();
      final gpsText = '${ctx['last_gps'] ?? ''}'.trim().toLowerCase();
      final hasGps = gpsText.isNotEmpty && !gpsText.contains('нет gps') && !gpsText.contains('no gps');
      byUuid[uuid] = _RemoteTrackerPresence(
        uuid: uuid,
        name: name.isEmpty ? 'BLE ${uuid.length <= 8 ? uuid : uuid.substring(0, 8)}' : name,
        message: '${log['message'] ?? ''}'.trim(),
        createdAtLabel: _timeLabel('${log['created_at'] ?? ctx['client_time'] ?? ''}'),
        playerName: _emptyToNull('${ctx['player_name'] ?? ''}'),
        teamName: _emptyToNull('${ctx['team_name'] ?? ''}'),
        fieldTitle: _emptyToNull('${ctx['field_title'] ?? ''}'),
        rssi: int.tryParse('${ctx['ble_rssi'] ?? ''}'),
        liveRunning: _asBool(ctx['live_running']),
        fieldCalibrated: _asBool(ctx['field_calibrated']),
        hasFreshGps: hasGps,
      );
    }
    return byUuid.values.toList(growable: false);
  }

  static Map<String, dynamic> _decodeContext(Object? raw) {
    if (raw is Map) return Map<String, dynamic>.from(raw);
    final text = '${raw ?? ''}'.trim();
    if (text.isEmpty || text == 'null') return <String, dynamic>{};
    try {
      final decoded = jsonDecode(text);
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {}
    return <String, dynamic>{};
  }

  static bool _asBool(Object? value) {
    if (value is bool) return value;
    if (value is num) return value != 0;
    final text = '${value ?? ''}'.toLowerCase().trim();
    return text == 'true' || text == '1' || text == 'yes' || text == 'да';
  }

  static String? _emptyToNull(String value) {
    final v = value.trim();
    if (v.isEmpty || v == 'null') return null;
    return v;
  }

  static bool _isFresh(String raw, {required int maxAgeSeconds}) {
    final text = raw.trim();
    if (text.isEmpty) return true;
    DateTime? dt = DateTime.tryParse(text);
    dt ??= DateTime.tryParse(text.replaceFirst(' ', 'T'));
    if (dt == null) return true;
    final diff = DateTime.now().difference(dt);
    if (diff.isNegative) return true;
    return diff.inSeconds <= maxAgeSeconds;
  }

  static String _timeLabel(String raw) {
    final text = raw.trim();
    if (text.length >= 19) return text.substring(11, 19);
    if (text.length >= 8) return text.substring(text.length - 8);
    return 'только что';
  }
}

class _RemoteConnectedTrackersStrip extends StatelessWidget {
  const _RemoteConnectedTrackersStrip({required this.items, required this.onRefresh});

  final List<_RemoteTrackerPresence> items;
  final VoidCallback onRefresh;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _TD.greenSoft,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _TD.greenBorder),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const Icon(Icons.cloud_done_rounded, color: _TD.green, size: 18),
          const SizedBox(width: 4),
          Expanded(
            child: Text(
              'Удалённо подключены: ${items.length}',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w800, fontSize: 12),
            ),
          ),
          InkWell(
            onTap: onRefresh,
            borderRadius: BorderRadius.circular(10),
            child: const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
              child: Text('обновить', style: TextStyle(color: _TD.green, fontWeight: FontWeight.w800, fontSize: 10.5)),
            ),
          ),
        ]),
        const SizedBox(height: 4),
        ...items.take(4).map((item) {
          final details = <String>[
            item.uuid,
            if (item.rssi != null) 'RSSI ${item.rssi}',
            if (item.playerName != null) item.playerName!,
            if (item.fieldTitle != null) item.fieldTitle!,
            item.liveRunning ? 'Live идёт' : 'Live нет',
            item.hasFreshGps ? 'GPS OK' : 'GPS нет',
            item.createdAtLabel,
          ];
          return Container(
            margin: const EdgeInsets.only(bottom: 6),
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(color: Colors.white.withOpacity(.72), borderRadius: BorderRadius.circular(10)),
            child: Row(children: [
              Icon(item.liveRunning ? Icons.sensors_rounded : Icons.bluetooth_connected_rounded, color: item.liveRunning ? _TD.green : _TD.orange, size: 17),
              const SizedBox(width: 4),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.text, fontWeight: FontWeight.w800, fontSize: 11.5)),
                  const SizedBox(height: 2),
                  Text(details.join(' · '), maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w600, fontSize: 10.2)),
                ]),
              ),
              const SizedBox(width: 4),
              Text('занят', style: TextStyle(color: item.liveRunning ? _TD.green : _TD.orange, fontWeight: FontWeight.w900, fontSize: 10.5)),
            ]),
          );
        }),
      ]),
    );
  }
}

class _CalibrationStatusBanner extends StatelessWidget {
  const _CalibrationStatusBanner({
    required this.nextLabel,
    required this.done,
    required this.pointCount,
    this.saved = false,
  });

  final String nextLabel;
  final bool done;
  final int pointCount;
  final bool saved;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: done ? _TD.green.withOpacity(.10) : const Color(0xFF2563EB).withOpacity(.08),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Icon(done ? Icons.check_circle_rounded : Icons.gps_fixed_rounded, color: done ? _TD.green : const Color(0xFF2563EB)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              saved
                  ? 'Поле уже сохранено. Координаты A/B/C/D показаны ниже.'
                  : (done
                      ? 'Все 4 угла получены. Нажмите «Сохранить».'
                      : 'Следующий угол: $nextLabel · перейдите в угол поля и нажмите GPS $nextLabel'),
              style: TextStyle(
                color: done ? _TD.green : _TD.text,
                fontWeight: FontWeight.w500,
                fontSize: 12,
              ),
            ),
          ),
          Text('$pointCount/4', style: const TextStyle(color: _TD.muted, fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

class _DarkHeatmapPainter extends CustomPainter {
  const _DarkHeatmapPainter({required this.points});
  final List<TrackerHeatPoint> points;
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = _TD.card2);
    final pitch = _fitPitch(rect.deflate(18));
    _drawPitch(canvas, pitch);
    if (points.isEmpty) {
      _drawText(canvas, size, 'Нет данных теплокарты');
      return;
    }
    final maxValue = points.fold<double>(1, (m, p) => math.max(m, p.value));
    for (final p in points) {
      final x = pitch.left + (p.x.clamp(0, 105) / 105.0) * pitch.width;
      final y = pitch.top + (p.y.clamp(0, 68) / 68.0) * pitch.height;
      final ratio = (p.value / maxValue).clamp(0.0, 1.0);
      final radius = 18 + 42 * ratio;
      final color = ratio > .7 ? _TD.red : ratio > .4 ? _TD.orange : _TD.green;
      canvas.drawCircle(Offset(x, y), radius, Paint()..shader = RadialGradient(colors: [color.withOpacity(.38), color.withOpacity(.08), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(x, y), radius: radius)));
    }
  }

  Rect _fitPitch(Rect area) {
    const aspect = 105 / 68;
    var w = area.width;
    var h = w / aspect;
    if (h > area.height) {
      h = area.height;
      w = h * aspect;
    }
    return Rect.fromCenter(center: area.center, width: w, height: h);
  }

  void _drawPitch(Canvas canvas, Rect pitch) {
    canvas.drawRRect(RRect.fromRectAndRadius(pitch, const Radius.circular(8)), Paint()..color = const Color(0xFF0A7F39));
    for (var i = 0; i < 12; i++) {
      canvas.drawRect(Rect.fromLTWH(pitch.left + pitch.width * i / 12, pitch.top, pitch.width / 12, pitch.height), Paint()..color = i.isEven ? Colors.white.withOpacity(.04) : Colors.black.withOpacity(.05));
    }
    final inner = pitch.deflate(12);
    final line = Paint()
      ..color = Colors.white.withOpacity(.85)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    canvas.drawRect(inner, line);
    canvas.drawLine(Offset(inner.center.dx, inner.top), Offset(inner.center.dx, inner.bottom), line);
    canvas.drawCircle(inner.center, inner.width * .085, line);
    canvas.drawRect(Rect.fromLTWH(inner.left, inner.center.dy - inner.height * .22, inner.width * .16, inner.height * .44), line);
    canvas.drawRect(Rect.fromLTWH(inner.right - inner.width * .16, inner.center.dy - inner.height * .22, inner.width * .16, inner.height * .44), line);
  }

  void _drawText(Canvas canvas, Size size, String text) {
    final tp = TextPainter(text: TextSpan(text: text, style: const TextStyle(color: _TD.muted, fontSize: 10, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout(maxWidth: size.width - 40);
    tp.paint(canvas, Offset((size.width - tp.width) / 2, (size.height - tp.height) / 2));
  }

  @override
  bool shouldRepaint(covariant _DarkHeatmapPainter oldDelegate) => true;
}

class _DarkCalibrationPainter extends CustomPainter {
  const _DarkCalibrationPainter({required this.corners, this.activeIndex = -1, this.capturing = false});

  final List<ActionTrackerGpsPoint> corners;
  final int activeIndex;
  final bool capturing;

  @override
  void paint(Canvas canvas, Size size) {
    final area = (Offset.zero & size).deflate(18);
    const aspect = 105 / 68;
    var w = area.width;
    var h = w / aspect;
    if (h > area.height) {
      h = area.height;
      w = h * aspect;
    }
    final pitch = Rect.fromCenter(center: area.center, width: w, height: h);
    _DarkHeatmapPainter(points: const [])._drawPitch(canvas, pitch);

    final cornersPos = [
      pitch.topLeft + const Offset(18, 18),
      pitch.topRight + const Offset(-18, 18),
      pitch.bottomRight + const Offset(-18, -18),
      pitch.bottomLeft + const Offset(18, -18),
    ];

    for (var i = 0; i < 4; i++) {
      final ready = corners.length > i;
      final active = i == activeIndex;
      final p = cornersPos[i];
      final color = ready ? _TD.green : active ? const Color(0xFF2563EB) : _TD.dim;
      if (active) {
        canvas.drawCircle(p, capturing ? 30 : 25, Paint()..color = color.withOpacity(.13));
        canvas.drawCircle(p, capturing ? 23 : 20, Paint()..color = color.withOpacity(.24));
      }
      canvas.drawCircle(p, active ? 18 : 16, Paint()..color = color);
      if (ready) {
        final check = TextPainter(
          text: const TextSpan(text: '✓', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13.5)),
          textDirection: TextDirection.ltr,
        )..layout();
        check.paint(canvas, p - Offset(check.width / 2, check.height / 2));
      } else if (active) {
        final plus = TextPainter(
          text: const TextSpan(text: '+', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 20)),
          textDirection: TextDirection.ltr,
        )..layout();
        plus.paint(canvas, p - Offset(plus.width / 2, plus.height / 2 + 1));
      } else {
        final tp = TextPainter(
          text: TextSpan(text: ['A', 'B', 'C', 'D'][i], style: const TextStyle(color: _TD.bg, fontWeight: FontWeight.w700)),
          textDirection: TextDirection.ltr,
        )..layout();
        tp.paint(canvas, p - Offset(tp.width / 2, tp.height / 2));
      }
    }
  }

  @override
  bool shouldRepaint(covariant _DarkCalibrationPainter oldDelegate) => true;
}

class _DarkTimelinePainter extends CustomPainter {
  const _DarkTimelinePainter();
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = _TD.card2);
    final y = size.height * .5;
    canvas.drawLine(Offset(30, y), Offset(size.width - 30, y), Paint()..color = _TD.border..strokeWidth = 2);
    for (var i = 0; i <= 8; i++) {
      final x = 30 + (size.width - 60) * i / 8;
      canvas.drawCircle(Offset(x, y), 5, Paint()..color = i.isEven ? _TD.green : _TD.orange);
      final tp = TextPainter(text: TextSpan(text: '${i * 15}’', style: const TextStyle(color: _TD.muted, fontSize: 9, fontWeight: FontWeight.w600)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(x - tp.width / 2, y + 14));
    }
  }
  @override
  bool shouldRepaint(covariant _DarkTimelinePainter oldDelegate) => false;
}
