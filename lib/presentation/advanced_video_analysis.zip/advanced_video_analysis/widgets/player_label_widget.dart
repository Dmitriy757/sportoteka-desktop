// lib/presentation/advanced_video_analysis/widgets/player_label_widget.dart

import 'package:flutter/material.dart';
import '../models/player_detection.dart';

class PlayerLabelWidget extends StatelessWidget {
  final PlayerDetection player;
  final Size overlaySize;
  final Size sourceVideoSize;

  const PlayerLabelWidget({
    Key? key,
    required this.player,
    required this.overlaySize,
    required this.sourceVideoSize,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final rect = _mapBoxToOverlay(
      bbox: player.bbox,
      overlaySize: overlaySize,
      sourceSize: sourceVideoSize,
    );

    if (rect.width <= 2 || rect.height <= 2) {
      return const SizedBox.shrink();
    }

    final Color teamColor = Color(player.teamColor);
    final String title = _labelText();

    return Positioned(
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height,
      child: IgnorePointer(
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  border: Border.all(color: teamColor, width: 2.2),
                  borderRadius: BorderRadius.circular(5),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.35),
                      blurRadius: 4,
                    ),
                  ],
                ),
              ),
            ),
            if (title.isNotEmpty)
              Positioned(
                left: 0,
                top: -24,
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 160),
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
                  decoration: BoxDecoration(
                    color: teamColor.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.white.withOpacity(0.85), width: 1),
                  ),
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      height: 1,
                    ),
                  ),
                ),
              ),
            Positioned(
              right: -5,
              bottom: -5,
              child: Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: teamColor,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 1.2),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _labelText() {
    if (player.number > 0 && player.name.isNotEmpty) return '#${player.number} ${player.name}';
    if (player.number > 0) return '#${player.number}';
    if (player.name.isNotEmpty) return player.name;
    if (player.trackId > 0) return 'ID ${player.trackId}';
    return 'Игрок';
  }

  Rect _mapBoxToOverlay({
    required Rect bbox,
    required Size overlaySize,
    required Size sourceSize,
  }) {
    if (overlaySize.width <= 0 || overlaySize.height <= 0) return Rect.zero;

    double sourceW = sourceSize.width <= 0 ? 1920 : sourceSize.width;
    double sourceH = sourceSize.height <= 0 ? 1080 : sourceSize.height;

    Rect sourceBox = bbox;

    // Если сервер отдаёт bbox в нормализованных координатах 0..1.
    if (bbox.right <= 1.5 && bbox.bottom <= 1.5) {
      sourceBox = Rect.fromLTRB(
        bbox.left * sourceW,
        bbox.top * sourceH,
        bbox.right * sourceW,
        bbox.bottom * sourceH,
      );
    }

    // Если bbox пришёл как x/y/w/h, но был прочитан как left/top/right/bottom,
    // правый/нижний край окажется меньше левого/верхнего. Исправляем безопасно.
    if (sourceBox.right < sourceBox.left || sourceBox.bottom < sourceBox.top) {
      sourceBox = Rect.fromLTWH(
        sourceBox.left,
        sourceBox.top,
        sourceBox.right.abs(),
        sourceBox.bottom.abs(),
      );
    }

    final scale = (overlaySize.width / sourceW) < (overlaySize.height / sourceH)
        ? overlaySize.width / sourceW
        : overlaySize.height / sourceH;

    final displayedW = sourceW * scale;
    final displayedH = sourceH * scale;
    final dx = (overlaySize.width - displayedW) / 2;
    final dy = (overlaySize.height - displayedH) / 2;

    final mapped = Rect.fromLTRB(
      dx + sourceBox.left * scale,
      dy + sourceBox.top * scale,
      dx + sourceBox.right * scale,
      dy + sourceBox.bottom * scale,
    );

    return Rect.fromLTRB(
      mapped.left.clamp(0.0, overlaySize.width),
      mapped.top.clamp(0.0, overlaySize.height),
      mapped.right.clamp(0.0, overlaySize.width),
      mapped.bottom.clamp(0.0, overlaySize.height),
    );
  }
}
