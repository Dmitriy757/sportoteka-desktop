// lib/presentation/advanced_video_analysis/advanced_video_analysis_screen.dart

import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:sportoteka/presentation/advanced_video_analysis/widgets/analysis_overlay_widget.dart';
import 'package:sportoteka/presentation/advanced_video_analysis/services/websocket_service.dart';
import 'package:sportoteka/presentation/advanced_video_analysis/models/player_detection.dart';
import 'package:sportoteka/presentation/advanced_video_analysis/models/analysis_result.dart';

class AdvancedVideoAnalysisScreen extends StatefulWidget {
  final Map<String, dynamic> params;
  
  const AdvancedVideoAnalysisScreen({
    Key? key, 
    required this.params
  }) : super(key: key);

  @override
  State<AdvancedVideoAnalysisScreen> createState() => _AdvancedVideoAnalysisScreenState();
}

class _AdvancedVideoAnalysisScreenState extends State<AdvancedVideoAnalysisScreen> {
  late WebViewController _webController;
  final WebSocketService _wsService = WebSocketService();
  bool _isLoading = true;
  bool _isVideoReady = false;
  List<PlayerDetection> _players = [];
  Map<String, dynamic> _stats = {};
  String _connectionStatus = '🔄 Подключение...';
  bool _isTestMode = false;
  String _videoUrl = '';
  StreamSubscription<String>? _statusSub;
  StreamSubscription<AnalysisResult>? _analysisSub;
  bool _wsListenersReady = false;

  final List<AnalysisResult> _analysisBuffer = <AnalysisResult>[];
  Timer? _overlaySyncTimer;
  double _currentVideoTimeMs = 0;
  double _lastAppliedVideoTimeMs = -1;
  bool _isVideoPaused = true;
  bool _videoStateReady = false;
  bool _isSeeking = false;
  double _currentPlaybackRate = 1.0;
  double _lastAppliedSyncPlaybackRate = 1.0;
  DateTime _lastPlaybackRateChangeAt = DateTime.fromMillisecondsSinceEpoch(0);

  static const int _maxBufferedFrames = 3000;

  // Максимальная дистанция между текущим временем видео и ближайшим AI-кадром.
  // Если сделать слишком маленькой — рамки будут пропадать при небольшой задержке сервера.
  static const double _maxFrameDistanceMs = 7000;

  // Fix 9: рамки не должны отставать от игроков.
  // Если AI немного позади видео, сначала предсказываем bbox по двум последним AI-кадрам,
  // а затем мягко замедляем видео, но больше не ставим его постоянно на паузу.
  static const bool _adaptivePlaybackRateSync = true;
  static const double _predictAheadMs = 1600;
  static const double _criticalLagMs = -900;
  static const double _lowBufferAheadMs = 700;
  static const double _mediumBufferAheadMs = 1700;
  static const double _restoreSpeedAheadMs = 3600;

  // Fix 8: автоматическую паузу отключаем.
  // Сервер может анализировать медленнее реального видео, но плеер не должен постоянно останавливаться.
  // Overlay просто держит последние/ближайшие рамки и обновляется, когда приходят новые AI-кадры.
  static const bool _autoPauseForAiBuffer = false;

  static const double _pauseWhenBufferAheadLessThanMs = 700;
  static const double _resumeWhenBufferAheadMoreThanMs = 2600;

  bool _userWantsPlayback = false;
  bool _pausedByAnalysisBuffer = false;
  bool _pauseRequestedByBuffer = false;
  bool _resumeRequestedByBuffer = false;
  
  @override
  void initState() {
    super.initState();
    _videoUrl = widget.params['videoUrl'] ?? '';
    print('📹 Video URL: $_videoUrl');
    _initWebView();
    _startOverlaySyncTimer();
    _connectWebSocket();
    
  }
  
  void _initWebView() {
    // ВСЕ HTML И JAVASCRIPT КОД ВНУТРИ ТРОЙНЫХ КАВЫЧЕК
    final String html = r'''
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI Video Analysis</title>
  <style>
    * { margin: 0; padding: 0; }
    body { 
      background: #000; 
      display: flex; 
      justify-content: center; 
      align-items: center; 
      height: 100vh; 
      overflow: hidden;
    }
    #video-container { 
      width: 100%; 
      height: 100%; 
      display: flex; 
      justify-content: center; 
      align-items: center; 
      position: relative;
    }
    video { 
      width: 100%; 
      height: 100%; 
      object-fit: contain;
      background: #000;
    }
    .controls {
      position: absolute;
      bottom: 20px;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      align-items: center;
      gap: 12px;
      background: rgba(0,0,0,0.6);
      padding: 10px 16px;
      border-radius: 12px;
      backdrop-filter: blur(10px);
      pointer-events: auto;
    }
    .controls button {
      background: transparent;
      border: none;
      color: white;
      font-size: 20px;
      cursor: pointer;
      padding: 4px 8px;
      border-radius: 6px;
      transition: all 0.2s;
    }
    .controls button:hover {
      background: rgba(255,255,255,0.15);
    }
    .controls input[type="range"] {
      width: 100px;
      height: 4px;
      -webkit-appearance: none;
      background: rgba(255,255,255,0.3);
      border-radius: 2px;
      outline: none;
    }
    .controls input[type="range"]::-webkit-slider-thumb {
      -webkit-appearance: none;
      width: 12px;
      height: 12px;
      border-radius: 50%;
      background: #00A750;
      cursor: pointer;
    }
    .time-display {
      color: white;
      font-size: 13px;
      font-family: Arial, sans-serif;
      min-width: 80px;
      text-align: center;
    }
    .speed-btn {
      color: #00A750 !important;
      font-size: 13px !important;
      font-weight: bold;
      min-width: 36px;
    }
    .volume-btn {
      font-size: 18px !important;
    }
    .error-message {
      color: #ff6b6b;
      font-family: Arial, sans-serif;
      text-align: center;
      padding: 20px;
    }
  </style>
</head>
<body>
  <div id="video-container">
    <video id="video-player" playsinline preload="auto">
      <source src="''' + _videoUrl + '''" type="video/mp4">
      <p class="error-message">❌ Видео не может быть загружено</p>
    </video>
    
    <div class="controls" id="controls">
      <button id="playBtn" title="Play/Pause">▶️</button>
      <button id="rewindBtn" title="Назад 10с">⏪</button>
      <button id="forwardBtn" title="Вперед 10с">⏩</button>
      <input type="range" id="seekBar" min="0" max="100" value="0">
      <span class="time-display" id="timeDisplay">00:00 / 00:00</span>
      <button id="speedBtn" class="speed-btn">1x</button>
      <button id="volumeBtn" class="volume-btn">🔊</button>
      <button id="fullscreenBtn" title="Fullscreen">⛶</button>
    </div>
  </div>
  
  <script>
    const video = document.getElementById('video-player');
    const playBtn = document.getElementById('playBtn');
    const rewindBtn = document.getElementById('rewindBtn');
    const forwardBtn = document.getElementById('forwardBtn');
    const seekBar = document.getElementById('seekBar');
    const timeDisplay = document.getElementById('timeDisplay');
    const speedBtn = document.getElementById('speedBtn');
    const volumeBtn = document.getElementById('volumeBtn');
    const fullscreenBtn = document.getElementById('fullscreenBtn');
    
    let isDragging = false;
    let currentSpeed = 1;
    let isMuted = false;
    let lastStateEmit = 0;

    function emitVideoState(reason) {
      const now = performance.now();
      if (reason === 'tick' && now - lastStateEmit < 90) return;
      lastStateEmit = now;

      const payload = {
        type: 'video_state',
        reason: reason,
        time_ms: (video.currentTime || 0) * 1000,
        duration_ms: (video.duration || 0) * 1000,
        paused: video.paused,
        ended: video.ended,
        seeking: video.seeking,
        playback_rate: video.playbackRate || 1
      };

      try {
        if (window.SportotekaVideoBridge) {
          SportotekaVideoBridge.postMessage(JSON.stringify(payload));
        }
      } catch (e) {}
    }
    
    function formatTime(seconds) {
      const mins = Math.floor(seconds / 60);
      const secs = Math.floor(seconds % 60);
      return String(mins).padStart(2, '0') + ':' + String(secs).padStart(2, '0');
    }
    
    function updateTime() {
      if (!isDragging && video.duration) {
        const progress = (video.currentTime / video.duration) * 100;
        seekBar.value = progress;
        timeDisplay.textContent = formatTime(video.currentTime) + ' / ' + formatTime(video.duration);
      }
    }
    
    playBtn.addEventListener('click', function() {
      if (video.paused) {
        video.play();
        playBtn.textContent = '⏸️';
      } else {
        video.pause();
        playBtn.textContent = '▶️';
      }
    });
    
    rewindBtn.addEventListener('click', function() {
      video.currentTime = Math.max(0, video.currentTime - 10);
    });
    
    forwardBtn.addEventListener('click', function() {
      video.currentTime = Math.min(video.duration, video.currentTime + 10);
    });
    
    seekBar.addEventListener('input', function(e) {
      isDragging = true;
      if (video.duration) {
        const percent = e.target.value / 100;
        video.currentTime = percent * video.duration;
        timeDisplay.textContent = formatTime(video.currentTime) + ' / ' + formatTime(video.duration);
      }
    });
    
    seekBar.addEventListener('change', function() {
      isDragging = false;
    });
    
    speedBtn.addEventListener('click', function() {
      const speeds = [0.5, 1, 1.25, 1.5, 2];
      let index = speeds.indexOf(currentSpeed);
      index = (index + 1) % speeds.length;
      currentSpeed = speeds[index];
      video.playbackRate = currentSpeed;
      speedBtn.textContent = currentSpeed + 'x';
      speedBtn.style.color = currentSpeed === 1 ? '#00A750' : '#FFA500';
    });
    
    volumeBtn.addEventListener('click', function() {
      isMuted = !isMuted;
      video.muted = isMuted;
      volumeBtn.textContent = isMuted ? '🔇' : '🔊';
    });
    
    fullscreenBtn.addEventListener('click', function() {
      if (document.fullscreenElement) {
        document.exitFullscreen();
      } else {
        document.documentElement.requestFullscreen();
      }
    });
    
    video.addEventListener('play', function() {
      playBtn.textContent = '⏸️';
      emitVideoState('play');
    });
    
    video.addEventListener('pause', function() {
      playBtn.textContent = '▶️';
      emitVideoState('pause');
    });

    video.addEventListener('seeking', function() {
      emitVideoState('seeking');
    });

    video.addEventListener('seeked', function() {
      emitVideoState('seeked');
    });
    
    video.addEventListener('loadedmetadata', function() {
      timeDisplay.textContent = '00:00 / ' + formatTime(video.duration);
      emitVideoState('loadedmetadata');
    });
    
    video.addEventListener('timeupdate', function() {
      updateTime();
      emitVideoState('timeupdate');
    });
    
    function loop() {
      updateTime();
      emitVideoState('tick');
      requestAnimationFrame(loop);
    }
    loop();
    
    document.addEventListener('keydown', function(e) {
      if (e.target.tagName === 'INPUT') return;
      
      if (e.code === 'Space') {
        e.preventDefault();
        playBtn.click();
      }
      if (e.code === 'ArrowLeft') {
        e.preventDefault();
        rewindBtn.click();
      }
      if (e.code === 'ArrowRight') {
        e.preventDefault();
        forwardBtn.click();
      }
      if (e.code === 'KeyF') {
        e.preventDefault();
        fullscreenBtn.click();
      }
    });
    
    // Важно: не стартуем видео автоматически.
    // Сначала сервер должен набрать небольшой буфер анализа, иначе видео убегает вперёд
    // и квадраты после нескольких секунд начинают пропадать/зависать.
    emitVideoState('ready_no_autoplay');
    console.log('🎬 Video player initialized without autoplay');
  </script>
</body>
</html>
''';

    _webController = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel(
        'SportotekaVideoBridge',
        onMessageReceived: _handleVideoBridgeMessage,
      )
      ..loadHtmlString(html);
  }
  
  void _connectWebSocket({bool forceRestart = false}) {
    if (_videoUrl.trim().isEmpty) {
      setState(() {
        _isLoading = false;
        _connectionStatus = '❌ Нет ссылки на видео';
      });
      return;
    }

    if (!_wsListenersReady) {
      _wsListenersReady = true;

      _statusSub = _wsService.statusStream.listen((status) {
        if (!mounted) return;
        setState(() {
          _connectionStatus = status;
          if (status.contains('❌') || status.contains('⚠️') || status.contains('кадры ещё не пришли')) {
            _isLoading = false;
          }
        });
      });

      _analysisSub = _wsService.analysisStream.listen(
        (result) {
          if (!mounted) return;
          _addAnalysisFrame(result);
          if (_autoPauseForAiBuffer) {
            _maybeResumeVideoAfterAnalysisBuffer();
          }

          // Важно: не двигаем квадраты просто потому, что сервер прислал новый кадр.
          // Сервер может анализировать быстрее/медленнее видео, а overlay должен жить по времени плеера.
          if (!_isVideoPaused) {
            _applyOverlayForVideoTime();
          } else if (!_videoStateReady && _players.isEmpty) {
            // Fallback только до первого сообщения от video-плеера.
            setState(() {
              _players = result.players;
              _stats = result.stats;
              _isTestMode = false;
              _isLoading = false;
              _connectionStatus = '✅ Анализ: ${result.players.length} игроков';
            });
          } else {
            // На паузе не меняем уже видимые рамки.
            // Исключение: если рамок ещё нет, можно один раз показать ближайший кадр текущего времени.
            if (_players.isEmpty) {
              _applyOverlayForVideoTime(force: true);
            }
            setState(() {
              _stats = result.stats;
              _isTestMode = false;
              _isLoading = false;
              _connectionStatus = '⏸ Пауза: квадраты зафиксированы';
            });
          }
        },
        onError: (error) {
          if (!mounted) return;
          setState(() {
            _isLoading = false;
            _connectionStatus = '❌ Ошибка анализа: $error';
          });
        },
      );
    }

    Future<void> run() async {
      if (forceRestart) {
        await _wsService.disconnect(silent: true);
      }
      await _wsService.connect(_videoUrl);
      if (mounted) {
        setState(() => _isLoading = false);
      }
    }

    // Важно: не оставляем Future без catchError, иначе SocketException попадает
    // в dart_vm_initializer как Unhandled Exception.
    unawaited(
      run().catchError((Object error, StackTrace stackTrace) {
        debugPrint('❌ WebSocket start error: $error');
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _connectionStatus = '❌ Ошибка WebSocket: $error';
        });
      }),
    );
  }
  
  void _startOverlaySyncTimer() {
    _overlaySyncTimer?.cancel();
    _overlaySyncTimer = Timer.periodic(const Duration(milliseconds: 50), (_) {
      if (!mounted || _isVideoPaused || _isSeeking) return;
      if (_autoPauseForAiBuffer) {
        _maybePauseVideoForAnalysisBuffer();
      }
      _applyAdaptivePlaybackRate();
      _applyOverlayForVideoTime();
    });
  }

  void _handleVideoBridgeMessage(JavaScriptMessage message) {
    try {
      final decoded = jsonDecode(message.message);
      if (decoded is! Map) return;
      final map = Map<String, dynamic>.from(decoded);
      if (map['type'] != 'video_state') return;

      final reason = map['reason']?.toString() ?? '';
      final nextTimeMs = _asDouble(map['time_ms']);
      final nextPaused = map['paused'] == true;
      final nextSeeking = map['seeking'] == true || reason == 'seeking';
      final nextPlaybackRate = _asDouble(map['playback_rate']);

      _videoStateReady = true;
      _currentVideoTimeMs = nextTimeMs;
      _isVideoPaused = nextPaused;
      _isSeeking = nextSeeking;
      if (nextPlaybackRate > 0) {
        _currentPlaybackRate = nextPlaybackRate;
      }

      if (reason == 'play') {
        _userWantsPlayback = true;
        _pausedByAnalysisBuffer = false;
        _resumeRequestedByBuffer = false;
      } else if (reason == 'pause') {
        if (_pauseRequestedByBuffer) {
          // Это не ручная пауза пользователя, а наша короткая остановка,
          // чтобы видео не убежало дальше обработанных AI-кадров.
          _pauseRequestedByBuffer = false;
          _pausedByAnalysisBuffer = true;
          _userWantsPlayback = true;
        } else {
          _userWantsPlayback = false;
          _pausedByAnalysisBuffer = false;
        }
      } else if (reason == 'seeked') {
        _pausedByAnalysisBuffer = false;
        _pauseRequestedByBuffer = false;
        _resumeRequestedByBuffer = false;
      }

      // На паузе и после перемотки сразу ставим overlay на кадр текущего времени,
      // а потом больше не обновляем его входящими пакетами WebSocket.
      if (nextPaused || reason == 'pause' || reason == 'seeked' || reason == 'loadedmetadata') {
        _applyOverlayForVideoTime(force: true);
      }
    } catch (e) {
      debugPrint('⚠️ Video bridge parse error: $e');
    }
  }

  void _applyAdaptivePlaybackRate() {
    if (!_adaptivePlaybackRateSync) return;
    if (!mounted || _isVideoPaused || _isSeeking || !_videoStateReady) return;
    if (_analysisBuffer.length < 2) return;

    final aheadMs = _bufferAheadMs(_currentVideoTimeMs);
    double desiredRate = 1.0;

    // Если видео убежало вперёд от AI, не ставим на паузу, а мягко замедляем.
    // Так рамки успевают догнать игроков без постоянных остановок.
    if (aheadMs < _criticalLagMs) {
      desiredRate = 0.65;
    } else if (aheadMs < _lowBufferAheadMs) {
      desiredRate = 0.75;
    } else if (aheadMs < _mediumBufferAheadMs) {
      desiredRate = 0.85;
    } else if (aheadMs >= _restoreSpeedAheadMs) {
      desiredRate = 1.0;
    } else {
      // В серой зоне не дёргаем скорость туда-сюда.
      desiredRate = _lastAppliedSyncPlaybackRate < 1.0 ? _lastAppliedSyncPlaybackRate : 1.0;
    }

    desiredRate = double.parse(desiredRate.toStringAsFixed(2));
    if ((desiredRate - _lastAppliedSyncPlaybackRate).abs() < 0.01) return;

    final now = DateTime.now();
    if (now.difference(_lastPlaybackRateChangeAt).inMilliseconds < 650) return;
    _lastPlaybackRateChangeAt = now;
    _lastAppliedSyncPlaybackRate = desiredRate;

    debugPrint(
      '🎚 AI sync speed=${desiredRate}x video=${_currentVideoTimeMs.toStringAsFixed(0)}ms ahead=${aheadMs.toStringAsFixed(0)}ms bufferEnd=${_bufferEndMs.toStringAsFixed(0)}ms',
    );

    final js = '''
      (function(){
        const v = document.getElementById('video-player');
        const b = document.getElementById('speedBtn');
        if (!v) return;
        v.playbackRate = $desiredRate;
        if (b) {
          b.textContent = '${desiredRate}x';
          b.style.color = $desiredRate === 1 ? '#00A750' : '#FFA500';
          b.title = 'AI синхронизация: ${desiredRate}x';
        }
      })();
    ''';

    unawaited(
      _webController.runJavaScript(js).catchError((Object e) {
        debugPrint('⚠️ Cannot set AI sync playbackRate: $e');
      }),
    );
  }

  void _addAnalysisFrame(AnalysisResult result) {
    if (result.players.isEmpty) return;

    final timeMs = _resultTimeMs(result);
    final normalized = AnalysisResult(
      players: result.players,
      stats: result.stats,
      frame: result.frame,
      timestamp: timeMs,
    );

    final duplicateIndex = _analysisBuffer.indexWhere(
      (item) => (_resultTimeMs(item) - timeMs).abs() < 1,
    );
    if (duplicateIndex >= 0) {
      _analysisBuffer[duplicateIndex] = normalized;
    } else {
      _analysisBuffer.add(normalized);
      _analysisBuffer.sort((a, b) => _resultTimeMs(a).compareTo(_resultTimeMs(b)));
    }

    if (_analysisBuffer.length > _maxBufferedFrames) {
      _analysisBuffer.removeRange(0, _analysisBuffer.length - _maxBufferedFrames);
    }
  }

  void _maybePauseVideoForAnalysisBuffer() {
    if (!mounted || _isVideoPaused || _isSeeking || !_videoStateReady) return;
    if (_pausedByAnalysisBuffer || _pauseRequestedByBuffer) return;

    final aheadMs = _analysisBuffer.isEmpty ? -9999.0 : _bufferAheadMs(_currentVideoTimeMs);
    if (aheadMs >= _pauseWhenBufferAheadLessThanMs) return;

    _pauseRequestedByBuffer = true;
    _pausedByAnalysisBuffer = true;

    debugPrint('⏸ AI buffer pause: video=${_currentVideoTimeMs.toStringAsFixed(0)}ms ahead=${aheadMs.toStringAsFixed(0)}ms bufferEnd=${_bufferEndMs.toStringAsFixed(0)}ms');

    unawaited(
      _webController.runJavaScript('''
        (function(){
          const v = document.getElementById('video-player');
          if (v && !v.paused) v.pause();
        })();
      ''').catchError((Object e) {
        debugPrint('⚠️ Cannot pause video for AI buffer: $e');
      }),
    );

    setState(() {
      _connectionStatus = '⏳ Буферизация AI: видео ждёт кадры анализа';
      _isLoading = false;
    });
  }

  void _maybeResumeVideoAfterAnalysisBuffer() {
    if (!mounted || !_pausedByAnalysisBuffer || !_userWantsPlayback || !_videoStateReady) return;
    if (_analysisBuffer.isEmpty || _resumeRequestedByBuffer) return;

    final aheadMs = _bufferAheadMs(_currentVideoTimeMs);
    if (aheadMs < _resumeWhenBufferAheadMoreThanMs) {
      if (mounted) {
        setState(() {
          _connectionStatus = '⏳ Буферизация AI: ${aheadMs.clamp(0, 99999).toStringAsFixed(0)} мс';
          _isLoading = false;
        });
      }
      return;
    }

    _resumeRequestedByBuffer = true;
    _pausedByAnalysisBuffer = false;

    debugPrint('▶️ AI buffer resume: video=${_currentVideoTimeMs.toStringAsFixed(0)}ms ahead=${aheadMs.toStringAsFixed(0)}ms');

    unawaited(
      _webController.runJavaScript('''
        (function(){
          const v = document.getElementById('video-player');
          if (v && v.paused) v.play().catch(function(){});
        })();
      ''').catchError((Object e) {
        debugPrint('⚠️ Cannot resume video after AI buffer: $e');
      }),
    );
  }

  double get _bufferEndMs => _analysisBuffer.isEmpty ? 0.0 : _resultTimeMs(_analysisBuffer.last);

  double _bufferAheadMs(double timeMs) {
    if (_analysisBuffer.isEmpty) return 0.0;
    return _bufferEndMs - timeMs;
  }

  void _applyOverlayForVideoTime({bool force = false}) {
    if (_analysisBuffer.isEmpty || !mounted) return;

    final target = _playersForVideoTime(_currentVideoTimeMs);
    if (target.isEmpty) {
      if (!force && !_isVideoPaused && _autoPauseForAiBuffer) {
        _maybePauseVideoForAnalysisBuffer();
      }
      // Не очищаем старые рамки и не ставим видео на паузу:
      // если AI временно не успевает, кадр продолжает играть, а overlay обновится при следующем пакете.
      if (!_isVideoPaused && mounted) {
        setState(() {
          _connectionStatus = '⏳ AI догоняет видео';
          _isLoading = false;
        });
      }
      return;
    }

    final shouldSmooth = !force && !_isSeeking && _players.isNotEmpty;
    final visiblePlayers = shouldSmooth ? _smoothPlayers(target) : target;

    if (!force && (_currentVideoTimeMs - _lastAppliedVideoTimeMs).abs() < 40) {
      return;
    }

    setState(() {
      _players = visiblePlayers;
      _stats = _nearestStats(_currentVideoTimeMs);
      _isTestMode = false;
      _isLoading = false;
      _connectionStatus = _isVideoPaused
          ? '⏸ Пауза: квадраты зафиксированы'
          : '✅ Синхронный анализ: ${visiblePlayers.length} игроков';
    });

    _lastAppliedVideoTimeMs = _currentVideoTimeMs;
  }

  List<PlayerDetection> _playersForVideoTime(double timeMs) {
    if (_analysisBuffer.isEmpty) return const [];

    // Если видео чуть ушло дальше последнего AI-кадра — предсказываем движение
    // по двум последним кадрам. Это убирает визуальное отставание рамок.
    final last = _analysisBuffer.last;
    final lastTime = _resultTimeMs(last);
    if (timeMs > lastTime) {
      final ahead = timeMs - lastTime;
      if (_analysisBuffer.length >= 2 && ahead <= _predictAheadMs) {
        final prev = _analysisBuffer[_analysisBuffer.length - 2];
        final prevTime = _resultTimeMs(prev);
        final dt = lastTime - prevTime;
        if (dt > 25) {
          final factor = (ahead / dt).clamp(0.0, 1.35);
          return _extrapolatePlayers(prev.players, last.players, factor);
        }
      }

      if (ahead <= _maxFrameDistanceMs) return last.players;
      return const [];
    }

    AnalysisResult? prev;
    AnalysisResult? next;

    for (final item in _analysisBuffer) {
      final itemTime = _resultTimeMs(item);
      if (itemTime <= timeMs) prev = item;
      if (itemTime >= timeMs) {
        next = item;
        break;
      }
    }

    prev ??= _analysisBuffer.first;
    next ??= _analysisBuffer.last;

    final prevTime = _resultTimeMs(prev);
    final nextTime = _resultTimeMs(next);

    final nearestDistance = [
      (timeMs - prevTime).abs(),
      (timeMs - nextTime).abs(),
    ].reduce((a, b) => a < b ? a : b);

    if (nearestDistance > _maxFrameDistanceMs) return const [];

    if (prev == next || (nextTime - prevTime).abs() < 1) {
      return prev.players;
    }

    final t = ((timeMs - prevTime) / (nextTime - prevTime)).clamp(0.0, 1.0);
    return _interpolatePlayers(prev.players, next.players, t);
  }

  List<PlayerDetection> _extrapolatePlayers(
    List<PlayerDetection> previous,
    List<PlayerDetection> current,
    double factor,
  ) {
    String keyFor(PlayerDetection p) => p.trackId > 0 ? 'track_${p.trackId}' : p.id;

    final previousByKey = <String, PlayerDetection>{
      for (final p in previous) keyFor(p): p,
    };

    return current.map((p) {
      final old = previousByKey[keyFor(p)];
      if (old == null) return p;

      final move = p.bbox.center - old.bbox.center;
      final distance = move.distance;
      if (distance <= 0.2 || distance > 220) return p;

      final dx1 = (p.bbox.left - old.bbox.left) * factor;
      final dy1 = (p.bbox.top - old.bbox.top) * factor;
      final dx2 = (p.bbox.right - old.bbox.right) * factor;
      final dy2 = (p.bbox.bottom - old.bbox.bottom) * factor;

      final predicted = Rect.fromLTRB(
        p.bbox.left + dx1,
        p.bbox.top + dy1,
        p.bbox.right + dx2,
        p.bbox.bottom + dy2,
      );

      return p.copyWith(bbox: predicted);
    }).toList();
  }

  List<PlayerDetection> _interpolatePlayers(
    List<PlayerDetection> previous,
    List<PlayerDetection> next,
    double t,
  ) {
    String keyFor(PlayerDetection p) => p.trackId > 0 ? 'track_${p.trackId}' : p.id;

    final nextByKey = <String, PlayerDetection>{
      for (final p in next) keyFor(p): p,
    };
    final usedNextKeys = <String>{};
    final output = <PlayerDetection>[];

    for (final p in previous) {
      final key = keyFor(p);
      final q = nextByKey[key];
      if (q == null) {
        if (t < 0.65) output.add(p);
        continue;
      }
      usedNextKeys.add(key);
      output.add(
        q.copyWith(
          bbox: Rect.lerp(p.bbox, q.bbox, t) ?? q.bbox,
          confidence: p.confidence + (q.confidence - p.confidence) * t,
          trajectory: q.trajectory.isNotEmpty ? q.trajectory : p.trajectory,
        ),
      );
    }

    for (final q in next) {
      final key = keyFor(q);
      if (!usedNextKeys.contains(key) && t >= 0.35) output.add(q);
    }

    return output;
  }

  List<PlayerDetection> _smoothPlayers(List<PlayerDetection> target) {
    if (_players.isEmpty) return target;

    String keyFor(PlayerDetection p) => p.trackId > 0 ? 'track_${p.trackId}' : p.id;

    final previousByKey = <String, PlayerDetection>{
      for (final p in _players) keyFor(p): p,
    };

    const alpha = 0.84;
    return target.map((p) {
      final old = previousByKey[keyFor(p)];
      if (old == null) return p;

      final oldCenter = old.bbox.center;
      final newCenter = p.bbox.center;
      final jump = (newCenter - oldCenter).distance;

      // При большом скачке, перемотке или смене трека не тянем старую рамку за новой.
      if (jump > 260) return p;

      return p.copyWith(
        bbox: Rect.lerp(old.bbox, p.bbox, alpha) ?? p.bbox,
      );
    }).toList();
  }

  Map<String, dynamic> _nearestStats(double timeMs) {
    if (_analysisBuffer.isEmpty) return _stats;

    AnalysisResult best = _analysisBuffer.first;
    double bestDistance = (_resultTimeMs(best) - timeMs).abs();

    for (final item in _analysisBuffer) {
      final d = (_resultTimeMs(item) - timeMs).abs();
      if (d < bestDistance) {
        best = item;
        bestDistance = d;
      }
    }

    return best.stats;
  }

  double _resultTimeMs(AnalysisResult result) {
    final raw = result.timestamp;
    if (raw <= 0 && result.frame > 0) return result.frame * 20.0; // fallback для 50 fps

    // Если сервер когда-нибудь пришлёт секунды, а не миллисекунды.
    if (raw > 0 && raw < 1000 && result.frame > 1000) return raw * 1000;
    return raw;
  }

  double _asDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString().replaceAll(',', '.')) ?? 0.0;
  }

  void _addTestData() {
    setState(() {
      _players = [
        PlayerDetection(
          id: '1',
          number: 10,
          name: 'Тестовый 10',
          bbox: Rect.fromLTWH(200, 300, 60, 120),
          teamColor: 0xFF00A750,
          teamId: 'home',
          confidence: 0.95,
          position: 'forward',
          trackId: 1,
          trajectory: [],
          metrics: {},
        ),
        PlayerDetection(
          id: '2',
          number: 7,
          name: 'Тестовый 7',
          bbox: Rect.fromLTWH(450, 250, 60, 120),
          teamColor: 0xFFFF4444,
          teamId: 'away',
          confidence: 0.92,
          position: 'midfield',
          trackId: 2,
          trajectory: [],
          metrics: {},
        ),
        PlayerDetection(
          id: '3',
          number: 9,
          name: 'Тестовый 9',
          bbox: Rect.fromLTWH(700, 350, 60, 120),
          teamColor: 0xFF00A750,
          teamId: 'home',
          confidence: 0.88,
          position: 'defense',
          trackId: 3,
          trajectory: [],
          metrics: {},
        ),
      ];
      _stats = {
        'shots': 8,
        'shots_on_target': 4,
        'passes': 156,
        'possession': 58,
        'sprints': 23,
      };
    });
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        title: Row(
          children: [
            Text('AI-анализ ${widget.params['teamName'] ?? 'матча'}'),
            if (_isTestMode)
              Container(
                margin: const EdgeInsets.only(left: 10),
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.orange,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: const Text(
                  'ТЕСТ',
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
          ],
        ),
        actions: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                Container(
                  width: 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _connectionStatus.contains('✅') 
                        ? Colors.green 
                        : _connectionStatus.contains('❌') 
                            ? Colors.red 
                            : _isTestMode
                                ? Colors.orange
                                : Colors.orange,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  _connectionStatus.replaceAll('✅', '').replaceAll('❌', '').trim(),
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() {
                _connectionStatus = '🔄 Переподключение...';
                _players = [];
                _stats = {};
                _analysisBuffer.clear();
                _lastAppliedVideoTimeMs = -1;
                _userWantsPlayback = false;
                _pausedByAnalysisBuffer = false;
                _pauseRequestedByBuffer = false;
                _resumeRequestedByBuffer = false;
                _lastAppliedSyncPlaybackRate = 1.0;
                _isLoading = true;
              });
              _initWebView();
              _connectWebSocket(forceRestart: true);
            },
            tooltip: 'Переподключиться',
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: _showSettings,
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _webController),
          
          if (_players.isNotEmpty)
            Positioned.fill(
              child: AnalysisOverlayWidget(
                players: _players,
                stats: _stats,
                videoSize: MediaQuery.of(context).size,
              ),
            ),

          if (!_isLoading && _players.isEmpty)
            Positioned(
              left: 16,
              top: 16,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.55),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.white.withOpacity(0.12)),
                ),
                child: Text(
                  _connectionStatus.contains('Подключено')
                      ? 'Ожидаю реальные detections от сервера…'
                      : _connectionStatus,
                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          
          if (_isLoading && _players.isEmpty)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const CircularProgressIndicator(color: Colors.green),
                  const SizedBox(height: 16),
                  Text(
                    _connectionStatus,
                    style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 14,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Видео: $_videoUrl',
                    style: TextStyle(
                      color: Colors.white38,
                      fontSize: 11,
                    ),
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      setState(() {
                        _connectionStatus = '🔄 Переподключение...';
                        _players = [];
                        _stats = {};
                        _analysisBuffer.clear();
                        _lastAppliedVideoTimeMs = -1;
                        _isLoading = true;
                      });
                      _initWebView();
                      _connectWebSocket(forceRestart: true);
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green,
                    ),
                    child: const Text('Попробовать снова'),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
  
  void _showSettings() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Настройки анализа'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SwitchListTile(
              value: true,
              onChanged: null,
              title: Text('Показывать номера'),
            ),
            const SwitchListTile(
              value: true,
              onChanged: null,
              title: Text('Показывать траектории'),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  setState(() {
                    _isTestMode = true;
                    _connectionStatus = '⚠️ ТЕСТОВЫЙ РЕЖИМ';
                  });
                  _addTestData();
                },
                icon: const Icon(Icons.bug_report_outlined),
                label: const Text('Показать тестовые квадраты'),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Закрыть'),
          ),
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    _overlaySyncTimer?.cancel();
    _statusSub?.cancel();
    _analysisSub?.cancel();
    _wsService.dispose();
    super.dispose();
  }
}