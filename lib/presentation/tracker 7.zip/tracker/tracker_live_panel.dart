import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'models/action_tracker_protocol.dart';
import 'models/tracker_live_models.dart';
import 'models/tracker_pro_models.dart';
import 'services/action_tracker_ble_service.dart';
import 'services/tracker_live_api.dart';

class TrackerLivePanel extends StatefulWidget {
  const TrackerLivePanel({
    super.key,
    required this.clubId,
    required this.teamId,
    required this.teamName,
    required this.players,
    required this.selectedPlayer,
    required this.selectedField,
    required this.ble,
    this.savedDevices = const [],
    this.batteryPercent,
    this.onManageTrackers,
    this.onLiveRunningChanged,
  });

  final int clubId;
  final int teamId;
  final String teamName;
  final List<TrackerPlayerOption> players;
  final TrackerPlayerOption? selectedPlayer;
  final TrackerFieldModel? selectedField;
  final ActionTrackerBleService ble;
  final List<TrackerDeviceModel> savedDevices;
  final int? batteryPercent;
  final VoidCallback? onManageTrackers;
  final ValueChanged<bool>? onLiveRunningChanged;

  @override
  State<TrackerLivePanel> createState() => _TrackerLivePanelState();
}

class _TrackerLivePanelState extends State<TrackerLivePanel> with AutomaticKeepAliveClientMixin {
  final TrackerLiveApi _api = TrackerLiveApi();
  final Map<String, _RuntimeTrack> _tracks = <String, _RuntimeTrack>{};
  final List<String> _logs = <String>[];

  List<TrackerLiveSessionModel> _sessions = <TrackerLiveSessionModel>[];
  StreamSubscription<ActionTrackerParseResult>? _bleSub;
  StreamSubscription<String>? _logSub;
  Timer? _pollTimer;
  Timer? _gpsTimer;
  Timer? _clockTimer;
  Timer? _heartbeatTimer;

  bool _running = false;
  bool _starting = false;
  bool _savingPoint = false;
  bool _showTrace = true;
  bool _showHeat = true;
  bool _showLabels = true;
  bool _showVectors = true;
  int? _liveSessionId;
  int _commandIndex = 0;

  DateTime? _startedAt;
  DateTime? _lastGpsAt;
  DateTime? _lastSaveAt;
  String _lastRx = 'нет пакетов';
  String _lastTx = 'нет команд';
  String _lastGps = 'GPS нет';
  String _lastSave = 'нет сохранения';
  String _statusLine = 'OpenField готов: подключите трекер, выберите игрока и нажмите Start.';

  @override
  bool get wantKeepAlive => true;

  @override
  void initState() {
    super.initState();
    _bindBle();
    _startPolling();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && _running) setState(() {});
    });
  }

  @override
  void didUpdateWidget(covariant TrackerLivePanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.teamId != widget.teamId || oldWidget.clubId != widget.clubId) {
      _stopLocalTimersOnly();
      setState(() {
        _running = false;
        _startedAt = null;
        _liveSessionId = null;
        _sessions = <TrackerLiveSessionModel>[];
        _tracks.clear();
        _statusLine = 'Команда изменена: ${widget.teamName}';
      });
      widget.onLiveRunningChanged?.call(false);
      _loadLiveState();
    }
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _gpsTimer?.cancel();
    _clockTimer?.cancel();
    _heartbeatTimer?.cancel();
    _bleSub?.cancel();
    _logSub?.cancel();
    if (_running) widget.onLiveRunningChanged?.call(false);
    super.dispose();
  }

  void _bindBle() {
    _bleSub = widget.ble.dataStream.listen((event) async {
      if (!mounted) return;
      _lastRx = '${event.rawHex} · 0x${event.packetType.toRadixString(16).toUpperCase()}';
      final chunk = event.gpsChunk;
      if (chunk == null || chunk.points.isEmpty) {
        setState(() {});
        return;
      }
      final valid = chunk.points.where(_usableGps).toList(growable: false);
      if (valid.isEmpty) {
        setState(() => _lastGps = 'GPS пакет без координат');
        return;
      }
      _lastGpsAt = DateTime.now();
      _lastGps = '${valid.last.latitude.toStringAsFixed(6)}, ${valid.last.longitude.toStringAsFixed(6)}';
      if (_running) {
        for (final p in valid) {
          await _handleGpsPoint(p);
        }
      } else {
        setState(() {});
      }
    });

    _logSub = widget.ble.logStream.listen((line) {
      if (!mounted) return;
      _log(line);
    });
  }

  void _startPolling() {
    _loadLiveState();
    _pollTimer?.cancel();
    _pollTimer = Timer.periodic(const Duration(seconds: 3), (_) => _loadLiveState());
  }

  Future<void> _loadLiveState() async {
    try {
      final items = await _api.loadTeamLiveState(teamId: widget.teamId, fieldId: widget.selectedField?.id);
      if (!mounted) return;
      setState(() {
        _sessions = items;
        for (final s in items) {
          final key = _trackKey(session: s);
          final track = _tracks.putIfAbsent(
            key,
            () => _RuntimeTrack(
              key: key,
              playerId: s.playerId,
              playerName: s.playerName ?? _playerName(s.playerId) ?? 'Игрок',
              avatarUrl: s.avatarUrl,
              deviceName: s.deviceName,
            ),
          );
          if (s.latitude != null && s.longitude != null) {
            track.add(
              _RuntimePoint(
                lat: s.latitude!,
                lon: s.longitude!,
                speedKmh: s.speedKmh,
                time: DateTime.tryParse((s.lastSeenAt ?? '').replaceFirst(' ', 'T')) ?? DateTime.now(),
                fieldX: s.fieldXM,
                fieldY: s.fieldYM,
              ),
            );
          }
          track.totalDistanceM = math.max(track.totalDistanceM, s.totalDistanceM);
          track.maxSpeedKmh = math.max(track.maxSpeedKmh, s.maxSpeedKmh);
          track.sprintCount = math.max(track.sprintCount, s.sprintCount);
          track.loadScore = math.max(track.loadScore, s.loadScore);
        }
      });
    } catch (e) {
      _log('Live state error: $e');
    }
  }

  Future<void> _startLive() async {
    if (_starting || _running) return;
    final connected = widget.ble.connectedInfo;
    final player = widget.selectedPlayer;
    if (connected == null) {
      _showTrackerConnectDialog();
      return;
    }
    if (player == null) {
      setState(() => _statusLine = 'Выберите игрока перед стартом Live.');
      return;
    }

    setState(() {
      _starting = true;
      _statusLine = 'Создаём Live-сессию...';
    });

    try {
      final id = await _api.startLiveSession(
        clubId: widget.clubId,
        teamId: widget.teamId,
        playerId: player.id,
        fieldId: widget.selectedField?.id,
        deviceUuid: connected.id,
        deviceName: connected.name,
        batteryPercent: widget.batteryPercent,
      );
      if (!mounted) return;
      _liveSessionId = id;
      _setLiveRunning(true);
      _statusLine = 'Live запущен. Ожидание GPS-пакетов трекера.';
      _startGpsLoop();
      _startHeartbeat();
      _showTrackerConnectDialog(autoClose: true);
    } catch (e) {
      if (mounted) setState(() => _statusLine = 'Ошибка старта Live: $e');
    } finally {
      if (mounted) setState(() => _starting = false);
    }
  }

  Future<void> _stopLive() async {
    final id = _liveSessionId;
    _stopLocalTimersOnly();
    _setLiveRunning(false);
    setState(() => _statusLine = 'Останавливаем Live...');
    try {
      if (id != null) await _api.stopLiveSession(liveSessionId: id, createFinalSession: true);
      if (!mounted) return;
      setState(() {
        _liveSessionId = null;
        _statusLine = 'Live остановлен. Сессия сохранена для отчёта.';
      });
      await _loadLiveState();
    } catch (e) {
      if (mounted) setState(() => _statusLine = 'Live остановлен локально. Сервер: $e');
    }
  }

  void _setLiveRunning(bool value) {
    if (_running == value) return;
    setState(() {
      _running = value;
      _startedAt = value ? (_startedAt ?? DateTime.now()) : null;
    });
    widget.onLiveRunningChanged?.call(value);
  }

  void _stopLocalTimersOnly() {
    _gpsTimer?.cancel();
    _heartbeatTimer?.cancel();
  }

  void _startGpsLoop() {
    _gpsTimer?.cancel();
    _gpsTimer = Timer.periodic(const Duration(seconds: 1), (_) async {
      final connected = widget.ble.connectedInfo;
      if (!_running || connected == null) return;
      final commands = ActionTrackerBleProfile.commandCurrentGpsCandidates;
      if (commands.isEmpty) return;
      final command = commands[_commandIndex % commands.length];
      _commandIndex++;
      try {
        await widget.ble.sendRawCommand(command);
        _lastTx = command.map((e) => e.toRadixString(16).padLeft(2, '0').toUpperCase()).join(' ');
      } catch (e) {
        _log('TX error: $e');
      }
      if (mounted) setState(() {});
    });
  }

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 12), (_) async {
      final id = _liveSessionId;
      if (!_running || id == null) return;
      try {
        await _api.heartbeatLiveSession(liveSessionId: id, statusText: _lastGpsAt == null ? 'waiting_gps' : 'live');
      } catch (_) {}
    });
  }

  Future<void> _handleGpsPoint(ActionTrackerGpsPoint p) async {
    final connected = widget.ble.connectedInfo;
    final sessionId = _liveSessionId;
    if (connected == null || sessionId == null || _savingPoint) return;
    final projection = _projectGpsToField(p.latitude, p.longitude);
    _savingPoint = true;
    try {
      final res = await _api.saveLivePoint(
        TrackerLivePointPayload(
          liveSessionId: sessionId,
          clubId: widget.clubId,
          teamId: widget.teamId,
          playerId: widget.selectedPlayer?.id,
          deviceUuid: connected.id,
          latitude: p.latitude,
          longitude: p.longitude,
          timeMs: p.timeMs,
          batteryPercent: widget.batteryPercent,
          fieldXM: projection?.dx,
          fieldYM: projection?.dy,
        ),
      );
      final speed = _num(res['speed_kmh'] ?? res['last_speed_kmh']);
      final distance = _num(res['distance_delta_m']);
      final key = widget.selectedPlayer == null ? connected.id : 'p_${widget.selectedPlayer!.id}';
      final track = _tracks.putIfAbsent(
        key,
        () => _RuntimeTrack(
          key: key,
          playerId: widget.selectedPlayer?.id,
          playerName: widget.selectedPlayer?.name ?? 'Игрок',
          avatarUrl: widget.selectedPlayer?.avatar,
          deviceName: connected.name,
        ),
      );
      track.add(
        _RuntimePoint(
          lat: p.latitude,
          lon: p.longitude,
          speedKmh: speed > 0 ? speed : track.estimateSpeed(p.latitude, p.longitude),
          time: DateTime.now(),
          fieldX: projection?.dx,
          fieldY: projection?.dy,
        ),
        distanceDeltaM: distance,
      );
      _lastSaveAt = DateTime.now();
      _lastSave = 'точка сохранена';
    } catch (e) {
      _lastSave = 'ошибка сохранения';
      _log('SAVE error: $e');
    } finally {
      _savingPoint = false;
      if (mounted) setState(() {});
    }
  }

  Offset? _projectGpsToField(double lat, double lon) {
    final f = widget.selectedField;
    if (f?.hasCalibration != true) return null;
    final minLat = [f!.cornerALat!, f.cornerBLat!, f.cornerCLat!, f.cornerDLat!].reduce(math.min);
    final maxLat = [f.cornerALat!, f.cornerBLat!, f.cornerCLat!, f.cornerDLat!].reduce(math.max);
    final minLon = [f.cornerALng!, f.cornerBLng!, f.cornerCLng!, f.cornerDLng!].reduce(math.min);
    final maxLon = [f.cornerALng!, f.cornerBLng!, f.cornerCLng!, f.cornerDLng!].reduce(math.max);
    final denomLon = (maxLon - minLon).abs().clamp(0.0000001, 999).toDouble();
    final denomLat = (maxLat - minLat).abs().clamp(0.0000001, 999).toDouble();
    final nx = ((lon - minLon) / denomLon).clamp(0.0, 1.0).toDouble();
    final ny = (1 - ((lat - minLat) / denomLat)).clamp(0.0, 1.0).toDouble();
    return Offset(nx * (f.lengthM <= 0 ? 105 : f.lengthM), ny * (f.widthM <= 0 ? 68 : f.widthM));
  }

  bool _usableGps(ActionTrackerGpsPoint p) {
    if (p.latitude.abs() < 0.000001 && p.longitude.abs() < 0.000001) return false;
    return p.latitude.abs() <= 90 && p.longitude.abs() <= 180;
  }

  String? _playerName(int? id) {
    if (id == null) return null;
    final matches = widget.players.where((p) => p.id == id).toList();
    return matches.isEmpty ? null : matches.first.name;
  }

  String _trackKey({TrackerLiveSessionModel? session}) {
    if (session?.playerId != null) return 'p_${session!.playerId}';
    if ((session?.deviceUuid ?? '').isNotEmpty) return session!.deviceUuid;
    return 'unknown';
  }

  void _log(String line) {
    _logs.insert(0, line);
    if (_logs.length > 80) _logs.removeRange(80, _logs.length);
  }

  double _num(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? 0;
  }

  String _duration() {
    final started = _startedAt;
    if (started == null) return '00:00:00';
    final d = DateTime.now().difference(started);
    final h = d.inHours.toString().padLeft(2, '0');
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);
    return LayoutBuilder(
      builder: (context, c) {
        final w = c.maxWidth;
        if (w >= 1180) return _desktopOperator();
        if (w >= 760) return _tabletOperator();
        return _phoneOperator();
      },
    );
  }

  Widget _desktopOperator() {
    return _OperatorShell(
      top: _topOperatorBar(compact: false),
      timeline: _sessionTimeline(),
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(width: 272, child: _activePlayersPanel()),
          const SizedBox(width: 8),
          Expanded(flex: 9, child: _centralWorkspace()),
          const SizedBox(width: 8),
          SizedBox(width: 292, child: _rightOperatorPanel()),
        ],
      ),
      bottom: _bottomLiveStrip(),
    );
  }

  Widget _tabletOperator() {
    return _OperatorShell(
      top: _topOperatorBar(compact: true),
      timeline: _sessionTimeline(compact: true),
      body: Column(
        children: [
          Expanded(
            flex: 7,
            child: Row(
              children: [
                Expanded(flex: 7, child: _fieldPanel()),
                const SizedBox(width: 8),
                Expanded(flex: 5, child: _teamTablePanel()),
              ],
            ),
          ),
          const SizedBox(height: 8),
          Expanded(
            flex: 5,
            child: Row(
              children: [
                Expanded(child: _activePlayersPanel()),
                const SizedBox(width: 8),
                Expanded(child: _rightOperatorPanel()),
              ],
            ),
          ),
        ],
      ),
      bottom: _bottomLiveStrip(compact: true),
    );
  }

  Widget _phoneOperator() {
    return _OperatorShell(
      top: _topOperatorBar(compact: true),
      timeline: _sessionTimeline(compact: true),
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          SizedBox(height: 320, child: _fieldPanel()),
          const SizedBox(height: 8),
          SizedBox(height: 260, child: _activePlayersPanel()),
          const SizedBox(height: 8),
          SizedBox(height: 340, child: _teamTablePanel()),
          const SizedBox(height: 8),
          SizedBox(height: 300, child: _rightOperatorPanel()),
        ],
      ),
      bottom: _bottomLiveStrip(compact: true),
    );
  }

  Widget _topOperatorBar({required bool compact}) {
    final connected = widget.ble.connectedInfo;
    return Container(
      height: compact ? 52 : 58,
      decoration: const BoxDecoration(color: _OF.black),
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 14),
      child: Row(
        children: [
          const _OFLogo(),
          const SizedBox(width: 16),
          _NavPill(label: 'Timeline', active: true),
          if (!compact) ...[
            _NavPill(label: 'Download'),
            _NavPill(label: 'Settings'),
            _NavPill(label: 'Updates'),
          ],
          const Spacer(),
          Text(
            _running ? 'OpenField is live' : 'OpenField is ready',
            style: const TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.w800),
          ),
          const SizedBox(width: 14),
          _MiniAudioBars(active: _running),
          const SizedBox(width: 12),
          _StatusDot(label: connected == null ? 'Offline' : 'Online', active: connected != null),
          IconButton(
            tooltip: 'Подключить трекер',
            onPressed: _showTrackerConnectDialog,
            icon: const Icon(Icons.sensors_rounded, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _sessionTimeline({bool compact = false}) {
    return Container(
      height: compact ? 116 : 142,
      color: Colors.white,
      padding: EdgeInsets.fromLTRB(compact ? 10 : 26, 12, compact ? 10 : 26, 10),
      child: Column(
        children: [
          Row(
            children: [
              Text(
                '${DateTime.now().day.toString().padLeft(2, '0')}-${DateTime.now().month.toString().padLeft(2, '0')}-${DateTime.now().year}  ${widget.teamName}  ·  Activity time: ${_duration()}',
                style: const TextStyle(color: _OF.text, fontSize: 13, fontWeight: FontWeight.w900),
              ),
              const Spacer(),
              _SmallToolButton(icon: _running ? Icons.pause_rounded : Icons.play_arrow_rounded, label: _running ? 'Pause' : 'Start', onTap: _running ? _stopLive : _startLive, primary: true),
              const SizedBox(width: 8),
              _SmallToolButton(icon: Icons.add_rounded, label: 'Period', onTap: () {}),
            ],
          ),
          const SizedBox(height: 14),
          Expanded(
            child: CustomPaint(
              painter: _TimelinePainter(running: _running),
              child: const SizedBox.expand(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _centralWorkspace() {
    return Column(
      children: [
        Expanded(flex: 5, child: _fieldPanel()),
        const SizedBox(height: 8),
        Expanded(flex: 4, child: _teamTablePanel()),
      ],
    );
  }

  Widget _activePlayersPanel() {
    final connectedIds = widget.savedDevices.where((d) => d.playerId != null).map((d) => d.playerId!).toSet();
    final onlineIds = _tracks.values.where((t) => t.isFresh).map((t) => t.playerId).whereType<int>().toSet();
    final players = widget.players;
    return _OFPanel(
      title: 'Active Players',
      subtitle: '${onlineIds.length}/${players.length} live',
      headerTrailing: IconButton(
        tooltip: 'Датчики',
        onPressed: widget.onManageTrackers,
        icon: const Icon(Icons.sensors_rounded, size: 18, color: _OF.dark),
      ),
      child: players.isEmpty
          ? const Center(child: Text('Нет игроков', style: TextStyle(color: _OF.muted, fontWeight: FontWeight.w800)))
          : ListView.builder(
              itemCount: players.length,
              itemBuilder: (_, i) {
                final p = players[i];
                final online = onlineIds.contains(p.id);
                final connected = connectedIds.contains(p.id) || p.id == widget.selectedPlayer?.id;
                final track = _trackForPlayer(p.id);
                return _PlayerRow(
                  player: p,
                  online: online,
                  connected: connected,
                  speed: track?.lastSpeedKmh ?? 0,
                  load: track?.loadScore ?? 0,
                );
              },
            ),
    );
  }

  Widget _fieldPanel() {
    final tracks = _tracks.values.toList(growable: false);
    return _OFPanel(
      title: 'Tactical Table - Outdoor',
      subtitle: widget.selectedField?.title ?? 'Поле не выбрано',
      headerTrailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _LayerToggle(label: 'Trace', active: _showTrace, onTap: () => setState(() => _showTrace = !_showTrace)),
          _LayerToggle(label: 'Heat', active: _showHeat, onTap: () => setState(() => _showHeat = !_showHeat)),
          _LayerToggle(label: 'Tag', active: _showLabels, onTap: () => setState(() => _showLabels = !_showLabels)),
        ],
      ),
      child: CustomPaint(
        painter: _OpenFieldPitchPainter(
          tracks: tracks,
          field: widget.selectedField,
          showTrace: _showTrace,
          showHeat: _showHeat,
          showLabels: _showLabels,
          showVectors: _showVectors,
        ),
        child: const SizedBox.expand(),
      ),
    );
  }

  Widget _teamTablePanel() {
    final rows = widget.players.map((p) {
      final t = _trackForPlayer(p.id);
      return _TeamRowData(
        name: p.name,
        jersey: p.number ?? '${p.id}',
        distance: t?.totalDistanceM ?? 0,
        speed: t?.lastSpeedKmh ?? 0,
        maxSpeed: t?.maxSpeedKmh ?? 0,
        load: t?.loadScore ?? 0,
        hir: t?.hirDistanceM ?? 0,
        vhir: t?.vhirDistanceM ?? 0,
        sprint: t?.sprintDistanceM ?? 0,
      );
    }).toList(growable: false);

    return _OFPanel(
      title: 'Whole Team Table - Outdoor',
      subtitle: _running ? '-Live-' : '-Ready-',
      headerTrailing: Row(mainAxisSize: MainAxisSize.min, children: const [Icon(Icons.settings, color: _OF.muted, size: 18), SizedBox(width: 8), Icon(Icons.open_in_full, color: _OF.muted, size: 18)]),
      child: _TeamDataTable(rows: rows),
    );
  }

  Widget _rightOperatorPanel() {
    final selected = widget.selectedPlayer;
    return Column(
      children: [
        SizedBox(height: 136, child: _pipPanel()),
        const SizedBox(height: 8),
        SizedBox(height: 96, child: _selectedPanel(selected)),
        const SizedBox(height: 8),
        Expanded(child: _velocityPanel()),
        const SizedBox(height: 8),
        SizedBox(height: 158, child: _trackerPanel()),
      ],
    );
  }

  Widget _pipPanel() {
    final players = widget.players.take(12).toList();
    return _OFPanel(
      title: 'PIP - 1 Activity',
      subtitle: 'Group (${players.length})',
      child: Wrap(
        spacing: 6,
        runSpacing: 6,
        children: players.map((p) {
          final online = _trackForPlayer(p.id)?.isFresh == true;
          return Container(
            width: 45,
            height: 32,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: online ? _OF.lime : const Color(0xFFD9F99D),
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: const Color(0xFF9BCB31)),
            ),
            child: Text(p.number ?? '${p.id}', style: const TextStyle(color: _OF.dark, fontWeight: FontWeight.w900, fontSize: 12)),
          );
        }).toList(),
      ),
    );
  }

  Widget _selectedPanel(TrackerPlayerOption? selected) {
    return _OFPanel(
      title: 'Selected',
      subtitle: selected?.name ?? '- No Athlete -',
      child: selected == null
          ? const Center(child: Text('- No Athlete -', style: TextStyle(color: _OF.muted, fontWeight: FontWeight.w800)))
          : Row(
              children: [
                _Avatar(url: selected.avatar, name: selected.name, size: 44),
                const SizedBox(width: 10),
                Expanded(child: Text(selected.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900))),
              ],
            ),
    );
  }

  Widget _velocityPanel() {
    final zones = _zoneTotals();
    return _OFPanel(
      title: 'Velocity Bands Overview',
      subtitle: 'HIR / VHIR / Sprint',
      child: Column(
        children: [
          _BandRow(label: 'Jog', value: zones['jog'] ?? 0, color: const Color(0xFFB8E986)),
          _BandRow(label: 'Run', value: zones['run'] ?? 0, color: const Color(0xFF7ED321)),
          _BandRow(label: 'HIR', value: zones['hir'] ?? 0, color: const Color(0xFFF5A623)),
          _BandRow(label: 'VHIR', value: zones['vhir'] ?? 0, color: const Color(0xFFF97316)),
          _BandRow(label: 'Sprint', value: zones['sprint'] ?? 0, color: const Color(0xFFE11D48)),
        ],
      ),
    );
  }

  Widget _trackerPanel() {
    final connected = widget.ble.connectedInfo;
    return _OFPanel(
      title: 'Tracker',
      subtitle: connected == null ? 'Not connected' : connected.name,
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.asset(
              'assets/images/sportoteka_tracker_kit.png',
              width: 72,
              height: 86,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                width: 72,
                height: 86,
                color: _OF.black,
                alignment: Alignment.center,
                child: const Text('GPS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(connected == null ? 'SPORTOTEKA AT02 PRO' : connected.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                _StatusDot(label: connected == null ? 'Offline' : 'Online', active: connected != null, dark: true),
                const SizedBox(height: 8),
                _SmallToolButton(icon: Icons.sensors_rounded, label: connected == null ? 'Connect' : 'Change', onTap: widget.onManageTrackers ?? _showTrackerConnectDialog, primary: connected == null),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _bottomLiveStrip({bool compact = false}) {
    final online = _tracks.values.where((t) => t.isFresh).length;
    final total = widget.players.length;
    final distance = _tracks.values.fold<double>(0, (s, t) => s + t.totalDistanceM);
    final maxSpeed = _tracks.values.fold<double>(0, (s, t) => math.max(s, t.maxSpeedKmh));
    final gpsAge = _lastGpsAt == null ? 'нет' : '${DateTime.now().difference(_lastGpsAt!).inSeconds}с';
    return Container(
      height: compact ? 42 : 48,
      padding: EdgeInsets.symmetric(horizontal: compact ? 8 : 16),
      decoration: const BoxDecoration(color: _OF.black, border: Border(top: BorderSide(color: _OF.orange, width: 2))),
      child: Row(
        children: [
          _StatusDot(label: _running ? 'LIVE' : 'READY', active: _running),
          const SizedBox(width: 16),
          _FooterMetric(label: 'Time', value: _duration()),
          _FooterMetric(label: 'Athletes', value: '$online/$total'),
          _FooterMetric(label: 'Distance', value: '${(distance / 1000).toStringAsFixed(2)} км'),
          _FooterMetric(label: 'Max vel', value: '${maxSpeed.toStringAsFixed(1)}'),
          _FooterMetric(label: 'GPS', value: gpsAge),
          const Spacer(),
          if (!compact) Expanded(child: Text(_statusLine, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(color: Colors.white60, fontWeight: FontWeight.w700, fontSize: 11))),
        ],
      ),
    );
  }

  Map<String, double> _zoneTotals() {
    final res = <String, double>{'jog': 0, 'run': 0, 'hir': 0, 'vhir': 0, 'sprint': 0};
    for (final t in _tracks.values) {
      res['hir'] = (res['hir'] ?? 0) + t.hirDistanceM;
      res['vhir'] = (res['vhir'] ?? 0) + t.vhirDistanceM;
      res['sprint'] = (res['sprint'] ?? 0) + t.sprintDistanceM;
      final easy = math.max(0, t.totalDistanceM - t.hirDistanceM - t.vhirDistanceM - t.sprintDistanceM);
      res[t.lastSpeedKmh >= 10 ? 'run' : 'jog'] = (res[t.lastSpeedKmh >= 10 ? 'run' : 'jog'] ?? 0) + easy;
    }
    return res;
  }

  _RuntimeTrack? _trackForPlayer(int id) {
    final k = 'p_$id';
    if (_tracks.containsKey(k)) return _tracks[k];
    final matches = _tracks.values.where((t) => t.playerId == id).toList();
    return matches.isEmpty ? null : matches.first;
  }

  void _showTrackerConnectDialog({bool autoClose = false}) {
    if (!mounted) return;
    showDialog<void>(
      context: context,
      barrierDismissible: true,
      builder: (context) {
        if (autoClose) {
          Future<void>.delayed(const Duration(milliseconds: 950), () {
            if (Navigator.of(context).canPop()) Navigator.of(context).pop();
          });
        }
        final connected = widget.ble.connectedInfo;
        return Dialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          child: Container(
            width: 520,
            padding: const EdgeInsets.all(18),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.asset(
                    'assets/images/sportoteka_tracker_kit.png',
                    width: 172,
                    height: 142,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(width: 172, height: 142, color: _OF.black, alignment: Alignment.center, child: const Text('SPORTOTEKA\nGPS', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900))),
                  ),
                ),
                const SizedBox(width: 18),
                Expanded(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('SPORTOTEKA GPS Tracker', style: TextStyle(color: _OF.text, fontWeight: FontWeight.w900, fontSize: 20)),
                      const SizedBox(height: 8),
                      Text(connected == null ? 'Трекер не подключён' : 'Подключён: ${connected.name}', style: TextStyle(color: connected == null ? _OF.red : _OF.green, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 12),
                      Text('Игрок: ${widget.selectedPlayer?.name ?? 'не выбран'}', style: const TextStyle(color: _OF.muted, fontWeight: FontWeight.w700)),
                      Text('Поле: ${widget.selectedField?.title ?? 'не выбрано'}', style: const TextStyle(color: _OF.muted, fontWeight: FontWeight.w700)),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(child: _SmallToolButton(icon: Icons.sensors_rounded, label: 'Открыть датчики', onTap: () { Navigator.of(context).pop(); widget.onManageTrackers?.call(); }, primary: true)),
                          const SizedBox(width: 8),
                          _SmallToolButton(icon: Icons.close_rounded, label: 'Закрыть', onTap: () => Navigator.of(context).pop()),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _RuntimePoint {
  const _RuntimePoint({required this.lat, required this.lon, required this.speedKmh, required this.time, this.fieldX, this.fieldY});
  final double lat;
  final double lon;
  final double speedKmh;
  final DateTime time;
  final double? fieldX;
  final double? fieldY;
}

class _RuntimeTrack {
  _RuntimeTrack({required this.key, required this.playerId, required this.playerName, required this.avatarUrl, required this.deviceName});
  final String key;
  final int? playerId;
  final String playerName;
  final String? avatarUrl;
  final String deviceName;
  final List<_RuntimePoint> points = <_RuntimePoint>[];
  double totalDistanceM = 0;
  double maxSpeedKmh = 0;
  double loadScore = 0;
  double hirDistanceM = 0;
  double vhirDistanceM = 0;
  double sprintDistanceM = 0;
  int sprintCount = 0;
  double lastSpeedKmh = 0;

  bool get isFresh => points.isNotEmpty && DateTime.now().difference(points.last.time).inSeconds < 45;

  void add(_RuntimePoint p, {double distanceDeltaM = 0}) {
    if (points.isNotEmpty && points.last.lat == p.lat && points.last.lon == p.lon && DateTime.now().difference(points.last.time).inMilliseconds < 900) return;
    final dist = distanceDeltaM > 0 ? distanceDeltaM : (points.isEmpty ? 0 : _distance(points.last, p));
    totalDistanceM += dist;
    lastSpeedKmh = p.speedKmh;
    maxSpeedKmh = math.max(maxSpeedKmh, p.speedKmh);
    loadScore = totalDistanceM / 100 + sprintCount * 1.8;
    if (p.speedKmh >= 25.0) {
      sprintDistanceM += dist;
      sprintCount++;
    } else if (p.speedKmh >= 20.0) {
      vhirDistanceM += dist;
    } else if (p.speedKmh >= 14.4) {
      hirDistanceM += dist;
    }
    points.add(p);
    if (points.length > 800) points.removeRange(0, points.length - 800);
  }

  double estimateSpeed(double lat, double lon) {
    if (points.isEmpty) return 0;
    final prev = points.last;
    final dist = _haversine(prev.lat, prev.lon, lat, lon);
    final sec = math.max(1, DateTime.now().difference(prev.time).inSeconds);
    return (dist / sec) * 3.6;
  }

  static double _distance(_RuntimePoint a, _RuntimePoint b) => _haversine(a.lat, a.lon, b.lat, b.lon);
  static double _haversine(double lat1, double lon1, double lat2, double lon2) {
    const r = 6371000.0;
    final dLat = (lat2 - lat1) * math.pi / 180;
    final dLon = (lon2 - lon1) * math.pi / 180;
    final a = math.sin(dLat / 2) * math.sin(dLat / 2) + math.cos(lat1 * math.pi / 180) * math.cos(lat2 * math.pi / 180) * math.sin(dLon / 2) * math.sin(dLon / 2);
    return 2 * r * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }
}

class _TeamRowData {
  const _TeamRowData({required this.name, required this.jersey, required this.distance, required this.speed, required this.maxSpeed, required this.load, required this.hir, required this.vhir, required this.sprint});
  final String name;
  final String jersey;
  final double distance;
  final double speed;
  final double maxSpeed;
  final double load;
  final double hir;
  final double vhir;
  final double sprint;
}

class _OF {
  static const black = Color(0xFF050505);
  static const orange = Color(0xFFFF7A00);
  static const lime = Color(0xFF8EEA37);
  static const blue = Color(0xFF42C7D9);
  static const bg = Color(0xFFF1F2F3);
  static const card = Color(0xFFFFFFFF);
  static const line = Color(0xFFD9DEE4);
  static const text = Color(0xFF1E293B);
  static const dark = Color(0xFF111827);
  static const muted = Color(0xFF667085);
  static const green = Color(0xFF16A34A);
  static const red = Color(0xFFE11D48);
}

class _OperatorShell extends StatelessWidget {
  const _OperatorShell({required this.top, required this.timeline, required this.body, required this.bottom});
  final Widget top;
  final Widget timeline;
  final Widget body;
  final Widget bottom;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: _OF.bg,
      child: Column(
        children: [
          top,
          timeline,
          Expanded(child: Padding(padding: const EdgeInsets.all(8), child: body)),
          bottom,
        ],
      ),
    );
  }
}

class _OFLogo extends StatelessWidget {
  const _OFLogo();
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(width: 24, height: 24, decoration: BoxDecoration(border: Border.all(color: Colors.white, width: 4), shape: BoxShape.circle)),
        const SizedBox(width: 4),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
          Container(width: 19, height: 4, color: Colors.white),
          const SizedBox(height: 5),
          Container(width: 12, height: 4, color: Colors.white),
        ]),
      ],
    );
  }
}

class _NavPill extends StatelessWidget {
  const _NavPill({required this.label, this.active = false});
  final String label;
  final bool active;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 58,
      padding: const EdgeInsets.symmetric(horizontal: 18),
      decoration: BoxDecoration(border: Border(bottom: BorderSide(color: active ? _OF.orange : Colors.transparent, width: 3))),
      alignment: Alignment.center,
      child: Text(label, style: TextStyle(color: active ? Colors.white : Colors.white70, fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }
}

class _OFPanel extends StatelessWidget {
  const _OFPanel({required this.title, required this.subtitle, required this.child, this.headerTrailing});
  final String title;
  final String subtitle;
  final Widget child;
  final Widget? headerTrailing;
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(color: _OF.card, border: Border.all(color: _OF.line), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.035), blurRadius: 10, offset: const Offset(0, 3))]),
      child: Column(
        children: [
          Container(
            height: 42,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: const BoxDecoration(color: Colors.white, border: Border(bottom: BorderSide(color: _OF.line))),
            child: Row(children: [
              Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900, fontSize: 14))),
              if (subtitle.isNotEmpty) Flexible(child: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.right, style: const TextStyle(color: _OF.muted, fontWeight: FontWeight.w700, fontSize: 11))),
              if (headerTrailing != null) ...[const SizedBox(width: 8), headerTrailing!],
            ]),
          ),
          Expanded(child: Padding(padding: const EdgeInsets.all(10), child: child)),
        ],
      ),
    );
  }
}

class _PlayerRow extends StatelessWidget {
  const _PlayerRow({required this.player, required this.online, required this.connected, required this.speed, required this.load});
  final TrackerPlayerOption player;
  final bool online;
  final bool connected;
  final double speed;
  final double load;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 46,
      margin: const EdgeInsets.only(bottom: 5),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(color: online ? const Color(0xFFE8F8D8) : const Color(0xFFF8FAFC), border: Border(left: BorderSide(color: online ? _OF.lime : connected ? _OF.blue : _OF.line, width: 5))),
      child: Row(children: [
        _Avatar(url: player.avatar, name: player.name, size: 30),
        const SizedBox(width: 8),
        Expanded(child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(player.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900, fontSize: 12)),
          Text('${speed.toStringAsFixed(1)} км/ч · нагрузка ${load.toStringAsFixed(0)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _OF.muted, fontSize: 10, fontWeight: FontWeight.w700)),
        ])),
        Text(player.number ?? '', style: const TextStyle(color: _OF.dark, fontWeight: FontWeight.w900)),
      ]),
    );
  }
}

class _TeamDataTable extends StatelessWidget {
  const _TeamDataTable({required this.rows});
  final List<_TeamRowData> rows;
  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const Center(child: Text('Нет игроков', style: TextStyle(color: _OF.muted, fontWeight: FontWeight.w800)));
    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: SizedBox(
        width: 920,
        child: Column(
          children: [
            _tableHeader(),
            Expanded(
              child: ListView.builder(
                itemCount: rows.length,
                itemBuilder: (_, i) {
                  final r = rows[i];
                  final highlight = i % 5 == 3;
                  return Container(
                    height: 34,
                    color: highlight ? const Color(0xFFFFE1CC) : i.isEven ? const Color(0xFFF8FAFC) : Colors.white,
                    child: Row(children: [
                      _cell(r.jersey, 70, bold: true),
                      _cell(r.name, 180, bold: true, alignLeft: true),
                      _cell(r.distance.toStringAsFixed(0), 96),
                      _cell((r.distance / math.max(1, r.load + 1)).toStringAsFixed(1), 96),
                      _cell(r.load.toStringAsFixed(0), 96),
                      _cell(r.maxSpeed.toStringAsFixed(1), 90),
                      _cell(r.hir.toStringAsFixed(0), 86),
                      _cell(r.vhir.toStringAsFixed(0), 86),
                      _cell(r.sprint.toStringAsFixed(0), 86),
                    ]),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _tableHeader() {
    const cols = [
      ['JERSEY', 70.0],
      ['ATHLETE', 180.0],
      ['TOT DIST', 96.0],
      ['DIST/MIN', 96.0],
      ['PLAYER LOAD', 96.0],
      ['MAX VEL', 90.0],
      ['V4 DIST', 86.0],
      ['V5 DIST', 86.0],
      ['SPRINT', 86.0],
    ];
    return Container(
      height: 38,
      color: Colors.white,
      child: Row(children: cols.map((c) => _cell(c[0] as String, c[1] as double, bold: true)).toList()),
    );
  }

  Widget _cell(String value, double width, {bool bold = false, bool alignLeft = false}) {
    return Container(
      width: width,
      alignment: alignLeft ? Alignment.centerLeft : Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: const BoxDecoration(border: Border(right: BorderSide(color: Color(0xFFE5E7EB)))) ,
      child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: _OF.text, fontSize: 11, fontWeight: bold ? FontWeight.w900 : FontWeight.w700)),
    );
  }
}

class _OpenFieldPitchPainter extends CustomPainter {
  const _OpenFieldPitchPainter({required this.tracks, required this.field, required this.showTrace, required this.showHeat, required this.showLabels, required this.showVectors});
  final List<_RuntimeTrack> tracks;
  final TrackerFieldModel? field;
  final bool showTrace;
  final bool showHeat;
  final bool showLabels;
  final bool showVectors;
  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(rect, Paint()..color = const Color(0xFFEEF2F1));
    final pitch = _fit(rect.deflate(16));
    _drawPitch(canvas, pitch);
    final points = tracks.expand((t) => t.points).toList(growable: false);
    final bounds = _bounds(points);
    if (showHeat) _drawHeat(canvas, pitch, points, bounds);
    for (final t in tracks) {
      if (showTrace) _drawTrace(canvas, pitch, t, bounds);
      if (t.points.isNotEmpty) _drawPlayer(canvas, pitch, t, bounds);
    }
    if (points.isEmpty) _centerText(canvas, size, field?.hasCalibration == true ? 'Ожидание GPS-точек' : 'Откалибруйте поле по 4 углам');
  }

  Rect _fit(Rect area) {
    const aspect = 105 / 68;
    var w = area.width;
    var h = w / aspect;
    if (h > area.height) {
      h = area.height;
      w = h * aspect;
    }
    return Rect.fromCenter(center: area.center, width: w, height: h);
  }

  void _drawPitch(Canvas canvas, Rect p) {
    canvas.drawRRect(RRect.fromRectAndRadius(p, const Radius.circular(7)), Paint()..color = const Color(0xFF5E8469));
    for (var i = 0; i < 12; i++) {
      canvas.drawRect(Rect.fromLTWH(p.left + p.width * i / 12, p.top, p.width / 12, p.height), Paint()..color = (i.isEven ? Colors.white.withOpacity(.055) : Colors.black.withOpacity(.035)));
    }
    final inner = p.deflate(12);
    final line = Paint()..color = Colors.white.withOpacity(.86)..strokeWidth = 1.8..style = PaintingStyle.stroke;
    canvas.drawRect(inner, line);
    canvas.drawLine(Offset(inner.center.dx, inner.top), Offset(inner.center.dx, inner.bottom), line);
    canvas.drawCircle(inner.center, inner.width * .085, line);
    canvas.drawRect(Rect.fromLTWH(inner.left, inner.center.dy - inner.height * .22, inner.width * .16, inner.height * .44), line);
    canvas.drawRect(Rect.fromLTWH(inner.right - inner.width * .16, inner.center.dy - inner.height * .22, inner.width * .16, inner.height * .44), line);
    final small = Paint()..color = Colors.white.withOpacity(.68)..strokeWidth = 1.4..style = PaintingStyle.stroke;
    canvas.drawRect(Rect.fromLTWH(inner.left, inner.center.dy - inner.height * .10, inner.width * .055, inner.height * .20), small);
    canvas.drawRect(Rect.fromLTWH(inner.right - inner.width * .055, inner.center.dy - inner.height * .10, inner.width * .055, inner.height * .20), small);
  }

  _Bounds _bounds(List<_RuntimePoint> points) {
    if (points.any((p) => p.fieldX != null && p.fieldY != null)) return const _Bounds(0, 105, 0, 68, fieldMode: true);
    if (points.isEmpty) return const _Bounds(0, 1, 0, 1);
    final lats = points.map((p) => p.lat).toList();
    final lons = points.map((p) => p.lon).toList();
    var minLat = lats.reduce(math.min), maxLat = lats.reduce(math.max);
    var minLon = lons.reduce(math.min), maxLon = lons.reduce(math.max);
    if ((maxLat - minLat).abs() < .00001) { minLat -= .00005; maxLat += .00005; }
    if ((maxLon - minLon).abs() < .00001) { minLon -= .00005; maxLon += .00005; }
    return _Bounds(minLon, maxLon, minLat, maxLat);
  }

  Offset _pos(_RuntimePoint p, Rect pitch, _Bounds b) {
    if (p.fieldX != null && p.fieldY != null) {
      final fx = p.fieldX!.clamp(0, 105).toDouble();
      final fy = p.fieldY!.clamp(0, 68).toDouble();
      return Offset(pitch.left + (fx / 105) * pitch.width, pitch.top + (fy / 68) * pitch.height);
    }
    final x = ((p.lon - b.minX) / (b.maxX - b.minX)).clamp(0.0, 1.0).toDouble();
    final y = (1 - ((p.lat - b.minY) / (b.maxY - b.minY))).clamp(0.0, 1.0).toDouble();
    return Offset(pitch.left + x * pitch.width, pitch.top + y * pitch.height);
  }

  void _drawHeat(Canvas c, Rect pitch, List<_RuntimePoint> points, _Bounds b) {
    for (final p in points.take(220)) {
      final o = _pos(p, pitch, b);
      final speed = p.speedKmh.clamp(2, 30).toDouble() / 30;
      final color = p.speedKmh >= 25 ? _OF.red : p.speedKmh >= 18 ? _OF.orange : _OF.lime;
      final radius = 12 + 18 * speed;
      c.drawCircle(o, radius, Paint()..shader = RadialGradient(colors: [color.withOpacity(.20), color.withOpacity(.04), Colors.transparent]).createShader(Rect.fromCircle(center: o, radius: radius)));
    }
  }

  void _drawTrace(Canvas c, Rect pitch, _RuntimeTrack t, _Bounds b) {
    if (t.points.length < 2) return;
    final path = Path();
    for (var i = 0; i < t.points.length; i++) {
      final o = _pos(t.points[i], pitch, b);
      if (i == 0) path.moveTo(o.dx, o.dy); else path.lineTo(o.dx, o.dy);
    }
    c.drawPath(path, Paint()..color = _OF.orange.withOpacity(.72)..strokeWidth = 2.2..style = PaintingStyle.stroke..strokeCap = StrokeCap.round..strokeJoin = StrokeJoin.round);
  }

  void _drawPlayer(Canvas c, Rect pitch, _RuntimeTrack t, _Bounds b) {
    final last = t.points.last;
    final o = _pos(last, pitch, b);
    c.drawCircle(o, 9, Paint()..color = _OF.blue.withOpacity(.35));
    c.drawCircle(o, 5, Paint()..color = _OF.blue);
    if (showLabels) {
      final name = t.playerName.split(' ').take(2).join(' ');
      final tp = TextPainter(text: TextSpan(text: '$name · ${last.speedKmh.toStringAsFixed(1)}', style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout();
      final bg = Rect.fromLTWH(o.dx + 8, o.dy - 15, tp.width + 12, 22);
      c.drawRRect(RRect.fromRectAndRadius(bg, const Radius.circular(5)), Paint()..color = Colors.black.withOpacity(.62));
      tp.paint(c, Offset(bg.left + 6, bg.top + 4));
    }
  }

  void _centerText(Canvas c, Size s, String text) {
    final tp = TextPainter(text: TextSpan(text: text, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout(maxWidth: s.width - 40);
    tp.paint(c, Offset((s.width - tp.width) / 2, (s.height - tp.height) / 2));
  }

  @override
  bool shouldRepaint(covariant _OpenFieldPitchPainter oldDelegate) => true;
}

class _Bounds {
  const _Bounds(this.minX, this.maxX, this.minY, this.maxY, {this.fieldMode = false});
  final double minX, maxX, minY, maxY;
  final bool fieldMode;
}

class _TimelinePainter extends CustomPainter {
  const _TimelinePainter({required this.running});
  final bool running;
  @override
  void paint(Canvas canvas, Size size) {
    final topY = size.height * .34;
    final bottomY = size.height * .62;
    final line = Paint()..color = const Color(0xFFE5E7EB)..strokeWidth = 1;
    for (var i = 0; i <= 10; i++) {
      final x = 8 + (size.width - 16) * i / 10;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), line);
      final tp = TextPainter(text: TextSpan(text: '${16 + i ~/ 2}:${(30 + i * 2).toString().padLeft(2, '0')}', style: const TextStyle(color: _OF.muted, fontSize: 10, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset(x - tp.width / 2, 2));
    }
    _bar(canvas, Rect.fromLTWH(22, topY, size.width - 44, 9), _OF.orange, '20-02-2022 TRAINING AM');
    _bar(canvas, Rect.fromLTWH(22, bottomY, size.width * .27, 16), _OF.blue, 'WARM UP');
    _bar(canvas, Rect.fromLTWH(size.width * .33, bottomY, size.width * .22, 16), _OF.blue, 'SMG');
    _bar(canvas, Rect.fromLTWH(size.width * .58, bottomY, size.width * .24, 16), _OF.blue, 'SHOOTING PRACTICE');
    if (running) {
      final x = size.width * .42;
      final p = Paint()..color = _OF.orange;
      canvas.drawLine(Offset(x, 16), Offset(x, size.height - 4), p..strokeWidth = 2.2);
      final path = Path()..moveTo(x, 18)..lineTo(x - 10, 4)..lineTo(x + 10, 4)..close();
      canvas.drawPath(path, p);
    }
  }
  void _bar(Canvas c, Rect r, Color color, String text) {
    c.drawRRect(RRect.fromRectAndRadius(r, Radius.circular(r.height / 2)), Paint()..color = color.withOpacity(.92));
    final tp = TextPainter(text: TextSpan(text: text, style: const TextStyle(color: _OF.dark, fontSize: 10, fontWeight: FontWeight.w900)), textDirection: TextDirection.ltr)..layout(maxWidth: r.width);
    tp.paint(c, Offset(r.left + (r.width - tp.width) / 2, r.top + (r.height - tp.height) / 2));
  }
  @override
  bool shouldRepaint(covariant _TimelinePainter oldDelegate) => true;
}

class _SmallToolButton extends StatelessWidget {
  const _SmallToolButton({required this.icon, required this.label, required this.onTap, this.primary = false});
  final IconData icon;
  final String label;
  final VoidCallback? onTap;
  final bool primary;
  @override
  Widget build(BuildContext context) {
    return Material(
      color: primary ? _OF.orange : Colors.white,
      borderRadius: BorderRadius.circular(5),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(5),
        child: Container(
          height: 32,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(5), border: Border.all(color: primary ? _OF.orange : _OF.line)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 15, color: primary ? Colors.white : _OF.dark), const SizedBox(width: 5), Text(label, style: TextStyle(color: primary ? Colors.white : _OF.dark, fontSize: 11, fontWeight: FontWeight.w900))]),
        ),
      ),
    );
  }
}

class _LayerToggle extends StatelessWidget {
  const _LayerToggle({required this.label, required this.active, required this.onTap});
  final String label;
  final bool active;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      height: 24,
      margin: const EdgeInsets.only(left: 5),
      padding: const EdgeInsets.symmetric(horizontal: 8),
      alignment: Alignment.center,
      decoration: BoxDecoration(color: active ? _OF.black : Colors.white, border: Border.all(color: _OF.line), borderRadius: BorderRadius.circular(4)),
      child: Text(label, style: TextStyle(color: active ? Colors.white : _OF.muted, fontSize: 10, fontWeight: FontWeight.w900)),
    ),
  );
}

class _BandRow extends StatelessWidget {
  const _BandRow({required this.label, required this.value, required this.color});
  final String label;
  final double value;
  final Color color;
  @override
  Widget build(BuildContext context) {
    final widthFactor = (value / 500).clamp(.05, 1.0).toDouble();
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(children: [
        SizedBox(width: 54, child: Text(label, style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900, fontSize: 11))),
        Expanded(child: Stack(children: [
          Container(height: 18, color: const Color(0xFFE5E7EB)),
          FractionallySizedBox(widthFactor: widthFactor, child: Container(height: 18, color: color)),
        ])),
        SizedBox(width: 62, child: Text('${value.toStringAsFixed(0)} м', textAlign: TextAlign.right, style: const TextStyle(color: _OF.muted, fontWeight: FontWeight.w800, fontSize: 11))),
      ]),
    );
  }
}

class _StatusDot extends StatelessWidget {
  const _StatusDot({required this.label, required this.active, this.dark = false});
  final String label;
  final bool active;
  final bool dark;
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
    Container(width: 10, height: 10, decoration: BoxDecoration(color: active ? _OF.lime : _OF.red, shape: BoxShape.circle, border: Border.all(color: Colors.white.withOpacity(.5)))),
    const SizedBox(width: 6),
    Text(label, style: TextStyle(color: dark ? _OF.text : Colors.white70, fontWeight: FontWeight.w800, fontSize: 11)),
  ]);
}

class _MiniAudioBars extends StatelessWidget {
  const _MiniAudioBars({required this.active});
  final bool active;
  @override
  Widget build(BuildContext context) => SizedBox(
    width: 64,
    height: 22,
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: List.generate(12, (i) => Container(width: 3, height: active ? (6 + (i % 5) * 3).toDouble() : 3, margin: const EdgeInsets.only(right: 2), color: active ? _OF.orange : Colors.white24)),
    ),
  );
}

class _FooterMetric extends StatelessWidget {
  const _FooterMetric({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(right: 18),
    child: Row(mainAxisSize: MainAxisSize.min, children: [Text('$label ', style: const TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.w700)), Text(value, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w900))]),
  );
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.url, required this.name, required this.size});
  final String? url;
  final String name;
  final double size;
  @override
  Widget build(BuildContext context) {
    final image = _normalizeUrl(url);
    return ClipOval(
      child: image == null
          ? Container(width: size, height: size, color: const Color(0xFFE5E7EB), alignment: Alignment.center, child: Text(_initials(name), style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900)))
          : Image.network(image, width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(width: size, height: size, color: const Color(0xFFE5E7EB), alignment: Alignment.center, child: Text(_initials(name), style: const TextStyle(color: _OF.text, fontWeight: FontWeight.w900)))),
    );
  }
  String? _normalizeUrl(String? raw) {
    final v = (raw ?? '').trim();
    if (v.isEmpty || v == 'null') return null;
    if (v.startsWith('http')) return v;
    return 'https://sportotekaapp.ru/${v.startsWith('/') ? v.substring(1) : v}';
  }
  String _initials(String name) {
    final parts = name.trim().split(RegExp(r'\s+')).where((e) => e.isNotEmpty).toList();
    if (parts.isEmpty) return 'И';
    if (parts.length == 1) return parts.first.substring(0, math.min(2, parts.first.length)).toUpperCase();
    return '${parts.first[0]}${parts[1][0]}'.toUpperCase();
  }
}
