import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/parent_access/parent_family_screen.dart';

class WorkspaceParentAccessCard extends StatefulWidget {
  const WorkspaceParentAccessCard({
    super.key,
    required this.compact,
  });

  final bool compact;

  @override
  State<WorkspaceParentAccessCard> createState() =>
      _WorkspaceParentAccessCardState();
}

class _WorkspaceParentAccessCardState extends State<WorkspaceParentAccessCard> {
  static const _apiBase = 'https://sportotekaapp.ru/api';
  static const _green = Color(0xFF00A750);
  static const _greenDark = Color(0xFF067A46);
  static const _greenSoft = Color(0xFFF3FAF6);
  static const _greenBorder = Color(0xFFD7F0E2);
  static const _text = Color(0xFF0B0F14);
  static const _muted = Color(0xFF5F6670);
  static const _line = Color(0xFFE9ECEA);
  static const _soft = Color(0xFFF7F8F7);

  final _keyC = TextEditingController();
  bool _loading = true;
  bool _redeeming = false;
  String? _error;
  int _userId = 0;
  List<Map<String, dynamic>> _children = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _keyC.dispose();
    super.dispose();
  }

  dynamic _decode(String body) {
    try {
      final raw = body.trim();
      final brace = raw.indexOf('{');
      final bracket = raw.indexOf('[');
      int start = 0;
      if (brace >= 0 && bracket >= 0) {
        start = brace < bracket ? brace : bracket;
      } else if (brace >= 0) {
        start = brace;
      } else if (bracket >= 0) {
        start = bracket;
      }
      return jsonDecode(raw.substring(start));
    } catch (_) {
      return null;
    }
  }

  List<Map<String, dynamic>> _extractChildren(dynamic data) {
    dynamic raw = data;
    if (data is Map) {
      raw = data['children'] ??
          data['players'] ??
          data['items'] ??
          data['data'] ??
          const [];
      if (raw is Map) {
        raw = raw['children'] ?? raw['items'] ?? const [];
      }
    }
    if (raw is! List) return const [];
    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList(growable: false);
  }

  String _message(dynamic data, String fallback) {
    if (data is Map) {
      final v = '${data['message'] ?? data['error'] ?? ''}'.trim();
      if (v.isNotEmpty && v.toLowerCase() != 'null') return v;
    }
    return fallback;
  }

  Future<Map<String, dynamic>?> _postJson(
    String endpoint,
    Map<String, dynamic> body,
  ) async {
    final response = await http
        .post(
          Uri.parse('$_apiBase/$endpoint'),
          headers: const {
            'Content-Type': 'application/json; charset=utf-8',
            'Accept': 'application/json',
          },
          body: jsonEncode(body),
        )
        .timeout(const Duration(seconds: 15));
    final decoded = _decode(utf8.decode(response.bodyBytes));
    if (decoded is Map) return Map<String, dynamic>.from(decoded);
    if (decoded is List)
      return {'success': response.statusCode == 200, 'children': decoded};
    return null;
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      _userId = await PrefUtils.getUserId() ?? 0;
      if (_userId <= 0) throw Exception('Не найден user_id');
      final data = await _postJson(
        'get_parent_children.php',
        {'parent_user_id': _userId},
      );
      if (data == null) throw Exception('Сервер вернул некорректный ответ');
      final success = data['success'] == true ||
          '${data['status'] ?? ''}'.toLowerCase() == 'success' ||
          data.containsKey('children') ||
          data.containsKey('players');
      if (!success)
        throw Exception(_message(data, 'Не удалось проверить доступ'));
      if (!mounted) return;
      setState(() {
        _children = _extractChildren(data);
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = e.toString().replaceFirst('Exception: ', '');
      });
    }
  }

  Future<void> _redeem() async {
    if (_redeeming) return;
    final code = _keyC.text.trim();
    if (code.isEmpty) {
      _snack('Введите Parent Key');
      return;
    }
    if (_userId <= 0) _userId = await PrefUtils.getUserId() ?? 0;
    if (_userId <= 0) {
      _snack('Не найден пользователь');
      return;
    }

    setState(() => _redeeming = true);
    try {
      final data = await _postJson(
        'redeem_parent_invite.php',
        {
          'parent_user_id': _userId,
          'invite_code': code,
        },
      );
      if (data == null || data['success'] != true) {
        throw Exception(_message(data, 'Parent Key не принят'));
      }
      _keyC.clear();
      await _load();
      _snack('Доступ к ребёнку добавлен');
    } catch (e) {
      _snack(e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _redeeming = false);
    }
  }

  Future<void> _openFamily() async {
    await Navigator.of(context).push<void>(
      MaterialPageRoute(builder: (_) => const ParentFamilyScreen()),
    );
    if (mounted) await _load();
  }

  void _snack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String _childrenLabel() {
    final n = _children.length;
    if (n == 0) return 'Нет активных привязок';
    if (n == 1) return '1 ребёнок подключён';
    if (n >= 2 && n <= 4) return '$n ребёнка подключено';
    return '$n детей подключено';
  }

  @override
  Widget build(BuildContext context) {
    final compact = widget.compact;
    final hasChildren = _children.isNotEmpty;

    return Container(
      padding: EdgeInsets.all(compact ? 14 : 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _line, width: .8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: compact ? 40 : 44,
                height: compact ? 40 : 44,
                decoration: BoxDecoration(
                  color: _greenSoft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(Icons.family_restroom_rounded,
                    color: _greenDark, size: 21),
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Родительский кабинет',
                      style: AppTypography.custom(
                        size: compact ? 14.2 : 15,
                        weight: FontWeight.w600,
                        color: _text,
                        height: 1.15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _loading
                          ? 'Проверяем доступ…'
                          : hasChildren
                              ? _childrenLabel()
                              : 'Введите Parent Key, выданный клубом',
                      style: AppTypography.custom(
                        size: compact ? 10.8 : 11.2,
                        weight: FontWeight.w400,
                        color: _muted,
                        height: 1.25,
                      ),
                    ),
                  ],
                ),
              ),
              if (_loading)
                const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: _green,
                  ),
                )
              else if (hasChildren)
                TextButton(
                  onPressed: _openFamily,
                  style: TextButton.styleFrom(foregroundColor: _greenDark),
                  child: const Text('Открыть'),
                ),
            ],
          ),
          if (_error != null) ...[
            const SizedBox(height: 10),
            Text(
              _error!,
              style: AppTypography.custom(
                size: 10.4,
                weight: FontWeight.w400,
                color: const Color(0xFFD92D20),
                height: 1.3,
              ),
            ),
          ],
          const SizedBox(height: 12),
          Container(height: 1, color: _line),
          const SizedBox(height: 12),
          Text(
            hasChildren ? 'Добавить ребёнка по Parent Key' : 'Parent Key',
            style: AppTypography.custom(
              size: 10.7,
              weight: FontWeight.w500,
              color: _muted,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 7),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _keyC,
                  enabled: !_redeeming,
                  textCapitalization: TextCapitalization.characters,
                  onSubmitted: (_) => _redeem(),
                  style: AppTypography.custom(
                    size: 12.2,
                    weight: FontWeight.w600,
                    color: _text,
                    height: 1.1,
                  ),
                  decoration: InputDecoration(
                    hintText: 'PARENT-…',
                    isDense: true,
                    filled: true,
                    fillColor: _soft,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 12,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide.none,
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: const BorderSide(color: _greenBorder),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: _redeeming ? null : _redeem,
                style: FilledButton.styleFrom(
                  elevation: 0,
                  backgroundColor: _green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: _redeeming
                    ? const SizedBox(
                        width: 15,
                        height: 15,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: Colors.white,
                        ),
                      )
                    : const Text('Подключить'),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
