import 'package:flutter/material.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_player_section_document.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_player_section_browser.dart';

class SportotekaPlayerProjectScreen extends StatelessWidget {
  const SportotekaPlayerProjectScreen({
    super.key,
    required this.player,
    required this.clubId,
    this.teamId,
    this.teamName = '',
    this.onRefresh,
    this.onOpenLegacyProfile,
  });

  final Map<String, dynamic> player;
  final int clubId;
  final int? teamId;
  final String teamName;
  final Future<void> Function()? onRefresh;
  final VoidCallback? onOpenLegacyProfile;

  static const _green = Color(0xFF0B8F55);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);
  static const _line = Color(0xFFE7EAE7);

  String get _playerName {
    final last = '${player['last_name'] ?? player['lastname'] ?? ''}'.trim();
    final first = '${player['first_name'] ?? player['firstname'] ?? ''}'.trim();
    final full = '${player['full_name'] ?? player['fullName'] ?? player['name'] ?? ''}'.trim();
    final joined = <String>[last, first].where((e) => e.isNotEmpty).join(' ').trim();
    return joined.isNotEmpty ? joined : (full.isNotEmpty ? full : 'Игрок');
  }

  String get _position => '${player['position'] ?? player['role_on_field'] ?? player['amplua'] ?? ''}'.trim();
  String get _number => '${player['number'] ?? player['shirt_number'] ?? player['player_number'] ?? ''}'.trim();

  List<_PlayerProjectFile> get _files => const <_PlayerProjectFile>[
        _PlayerProjectFile(
          section: WorkspacePlayerSection.card,
          title: 'Карточка игрока',
          subtitle: 'личные данные, амплуа и контакты',
          glyph: _ProjectGlyph.card,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.diary,
          title: 'Дневник',
          subtitle: 'оценки, самооценка и заметки',
          glyph: _ProjectGlyph.diary,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.readiness,
          title: 'Готовность',
          subtitle: 'состояние, readiness и нагрузка',
          glyph: _ProjectGlyph.readiness,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.activity,
          title: 'Активность',
          subtitle: 'тренировки и показатели',
          glyph: _ProjectGlyph.activity,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.matches,
          title: 'Матчи',
          subtitle: 'игры и статистика',
          glyph: _ProjectGlyph.matches,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.testing,
          title: 'Тестирование',
          subtitle: 'тесты и динамика',
          glyph: _ProjectGlyph.testing,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.health,
          title: 'Здоровье',
          subtitle: 'медкарта, допуски и файлы',
          glyph: _ProjectGlyph.health,
          folderLike: true,
        ),
        _PlayerProjectFile(
          section: WorkspacePlayerSection.documents,
          title: 'Документы',
          subtitle: 'файлы и документы игрока',
          glyph: _ProjectGlyph.documents,
          folderLike: true,
        ),
      ];

  Future<void> _openSection(BuildContext context, _PlayerProjectFile file) async {
    final width = MediaQuery.sizeOf(context).width;

    // Карточка игрока — единственный одиночный системный документ.
    // Остальные разделы сначала открываются как папка со списком реальных
    // записей по датам, и только конкретная запись — как Word-подобный файл.
    final Widget child = file.section == WorkspacePlayerSection.card
        ? WorkspacePlayerSectionDocument(
            player: player,
            clubId: clubId,
            teamId: teamId,
            teamName: teamName,
            section: file.section,
            onRefresh: onRefresh,
          )
        : WorkspacePlayerSectionBrowser(
            player: player,
            clubId: clubId,
            teamId: teamId,
            teamName: teamName,
            section: file.section,
            onRefresh: onRefresh,
          );

    if (width < 760) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            backgroundColor: Colors.white,
            body: SafeArea(child: child),
          ),
        ),
      );
      return;
    }

    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(.16),
      builder: (dialogContext) {
        final size = MediaQuery.sizeOf(dialogContext);
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.symmetric(
            horizontal: size.width >= 1180 ? 54 : 26,
            vertical: size.height >= 820 ? 34 : 18,
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1180, maxHeight: 860),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Material(color: Colors.white, child: child),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 620;
        final tablet = constraints.maxWidth >= 620 && constraints.maxWidth < 980;
        final columns = mobile ? 2 : (tablet ? 3 : 4);
        final tileExtent = mobile ? 104.0 : (tablet ? 108.0 : 112.0);

        return ColoredBox(
          color: Colors.white,
          child: Column(
            children: [
              _ProjectHeader(
                playerName: _playerName,
                teamName: teamName,
                position: _position,
                number: _number,
                player: player,
                onBack: () => Navigator.of(context).maybePop(),
                onOpenLegacyProfile: onOpenLegacyProfile,
                compact: mobile,
              ),
              const Divider(height: 1, color: _line),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(
                    mobile ? 12 : 22,
                    mobile ? 16 : 22,
                    mobile ? 12 : 22,
                    28,
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          Text('Разделы игрока', style: AppTypography.sectionTitle(color: _text)),
                          const SizedBox(width: 8),
                          _BrandDots(compact: mobile),
                          const Spacer(),
                          Text('${_files.length} папок', style: AppTypography.caption(color: _muted)),
                        ],
                      ),
                      const SizedBox(height: 12),
                      GridView.builder(
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemCount: _files.length,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: columns,
                          crossAxisSpacing: mobile ? 8 : 12,
                          mainAxisSpacing: mobile ? 8 : 12,
                          mainAxisExtent: tileExtent,
                        ),
                        itemBuilder: (_, index) {
                          final file = _files[index];
                          return _PlayerFileTile(
                            file: file,
                            compact: mobile,
                            onTap: () => _openSection(context, file),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                height: 30,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: const BoxDecoration(
                  color: Color(0xFFF7F8F7),
                  border: Border(top: BorderSide(color: _line)),
                ),
                child: Row(
                  children: [
                    Text('8 папок', style: AppTypography.caption(color: _muted)),
                    const Spacer(),
                    Text('SPORTOTEKA PLAYER PROJECT', style: AppTypography.menuGroup(color: _muted)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _ProjectHeader extends StatelessWidget {
  const _ProjectHeader({
    required this.playerName,
    required this.teamName,
    required this.position,
    required this.number,
    required this.player,
    required this.onBack,
    required this.compact,
    this.onOpenLegacyProfile,
  });

  final String playerName;
  final String teamName;
  final String position;
  final String number;
  final Map<String, dynamic> player;
  final VoidCallback onBack;
  final bool compact;
  final VoidCallback? onOpenLegacyProfile;

  @override
  Widget build(BuildContext context) {
    final photo = '${player['photo'] ?? player['photo_url'] ?? player['avatar'] ?? ''}'.trim();
    final subtitle = <String>[
      if (teamName.trim().isNotEmpty) teamName.trim(),
      if (position.isNotEmpty) position,
      if (number.isNotEmpty) '№$number',
    ].join(' · ');

    return Container(
      height: compact ? 62 : 72,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 14),
      color: Colors.white,
      child: Row(
        children: [
          IconButton(
            tooltip: 'Назад',
            onPressed: onBack,
            icon: const Icon(Icons.arrow_back_rounded, size: 20, color: SportotekaPlayerProjectScreen._text),
          ),
          const SizedBox(width: 3),
          _PlayerAvatar(photo: photo, name: playerName, size: compact ? 38 : 42),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  playerName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.screenTitle(color: SportotekaPlayerProjectScreen._text),
                ),
                if (subtitle.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.secondary(color: SportotekaPlayerProjectScreen._muted),
                  ),
                ],
              ],
            ),
          ),
          if (!compact && onOpenLegacyProfile != null)
            TextButton(
              onPressed: onOpenLegacyProfile,
              child: Text('Классический профиль', style: AppTypography.action(color: SportotekaPlayerProjectScreen._muted)),
            ),
        ],
      ),
    );
  }
}

class _PlayerFileTile extends StatelessWidget {
  const _PlayerFileTile({
    required this.file,
    required this.compact,
    required this.onTap,
  });

  final _PlayerProjectFile file;
  final bool compact;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Ink(
          padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 14, vertical: compact ? 10 : 12),
          decoration: BoxDecoration(
            color: const Color(0xFFF9FBFA),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: SportotekaPlayerProjectScreen._line),
          ),
          child: Row(
            children: [
              _ProjectFolderIcon(size: compact ? 40 : 44, accent: file.folderLike),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            file.title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: AppTypography.itemTitle(color: SportotekaPlayerProjectScreen._text),
                          ),
                        ),
                        const SizedBox(width: 6),
                        const _BrandDots(),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      file.subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.caption(color: SportotekaPlayerProjectScreen._muted),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ProjectFolderIcon extends StatelessWidget {
  const _ProjectFolderIcon({required this.size, this.accent = false});
  final double size;
  final bool accent;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(painter: _ProjectFolderIconPainter(accent: accent)),
    );
  }
}

class _ProjectFolderIconPainter extends CustomPainter {
  const _ProjectFolderIconPainter({required this.accent});
  final bool accent;

  @override
  void paint(Canvas canvas, Size size) {
    final stroke = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.65
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round
      ..color = SportotekaPlayerProjectScreen._green;
    final fill = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFFEAF5EF);

    // Классическая форма папки: широкий tab слева и цельный корпус.
    final back = Path()
      ..moveTo(size.width * .12, size.height * .31)
      ..lineTo(size.width * .12, size.height * .27)
      ..quadraticBezierTo(size.width * .12, size.height * .21, size.width * .19, size.height * .21)
      ..lineTo(size.width * .39, size.height * .21)
      ..quadraticBezierTo(size.width * .43, size.height * .21, size.width * .46, size.height * .25)
      ..lineTo(size.width * .51, size.height * .31)
      ..lineTo(size.width * .84, size.height * .31)
      ..quadraticBezierTo(size.width * .90, size.height * .31, size.width * .90, size.height * .37)
      ..lineTo(size.width * .90, size.height * .70)
      ..quadraticBezierTo(size.width * .90, size.height * .78, size.width * .82, size.height * .78)
      ..lineTo(size.width * .18, size.height * .78)
      ..quadraticBezierTo(size.width * .10, size.height * .78, size.width * .10, size.height * .70)
      ..lineTo(size.width * .10, size.height * .37)
      ..quadraticBezierTo(size.width * .10, size.height * .31, size.width * .12, size.height * .31)
      ..close();
    canvas.drawPath(back, fill);
    canvas.drawPath(back, stroke);

    // Передний лист папки даёт привычный силуэт Finder, но без лишних линий.
    final frontFill = Paint()
      ..style = PaintingStyle.fill
      ..color = const Color(0xFFEAF5EF).withOpacity(.78);
    final front = RRect.fromRectAndRadius(
      Rect.fromLTWH(size.width * .10, size.height * .38, size.width * .80, size.height * .40),
      Radius.circular(size.width * .11),
    );
    canvas.drawRRect(front, frontFill);
    canvas.drawRRect(front, stroke);

    // Три фирменные точки Sportoteka — маленький акцент, а не отдельная пиктограмма.
    final dots = Paint()
      ..style = PaintingStyle.fill
      ..color = accent ? const Color(0xFF17A36A) : const Color(0xFF9ACDB0);
    final dotY = size.height * .61;
    for (final dx in [size.width * .66, size.width * .73, size.width * .80]) {
      canvas.drawCircle(Offset(dx, dotY), size.width * .022, dots);
    }
  }
  @override
  bool shouldRepaint(covariant _ProjectFolderIconPainter oldDelegate) => oldDelegate.accent != accent;
}

class _BrandDots extends StatelessWidget {
  const _BrandDots({this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final size = compact ? 5.0 : 6.0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        3,
        (index) => Padding(
          padding: EdgeInsets.only(left: index == 0 ? 0 : 4),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: index == 1 ? const Color(0xFF17A36A) : const Color(0xFFB8D9C6),
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class _PlayerAvatar extends StatelessWidget {
  const _PlayerAvatar({required this.photo, required this.name, required this.size});
  final String photo;
  final String name;
  final double size;

  @override
  Widget build(BuildContext context) {
    final uri = _absolutePhoto(photo);
    if (uri.isNotEmpty) {
      return ClipOval(
        child: Image.network(
          uri,
          width: size,
          height: size,
          fit: BoxFit.cover,
          errorBuilder: (_, __, ___) => _fallback(),
        ),
      );
    }
    return _fallback();
  }

  Widget _fallback() {
    final initials = name
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .take(2)
        .map((e) => e.substring(0, 1).toUpperCase())
        .join();
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: const BoxDecoration(color: Color(0xFFEAF5EF), shape: BoxShape.circle),
      child: Text(initials.isEmpty ? 'И' : initials, style: AppTypography.menuTitle(color: SportotekaPlayerProjectScreen._green)),
    );
  }

  String _absolutePhoto(String raw) {
    final value = raw.trim();
    if (value.isEmpty) return '';
    if (value.startsWith('http://') || value.startsWith('https://')) return value;
    if (value.startsWith('/')) return 'https://sportotekaapp.ru$value';
    if (value.startsWith('uploads/')) return 'https://sportotekaapp.ru/$value';
    return 'https://sportotekaapp.ru/uploads/$value';
  }
}

enum _ProjectGlyph { card, diary, readiness, activity, matches, testing, health, documents }

class _ProjectGlyphIcon extends StatelessWidget {
  const _ProjectGlyphIcon({required this.glyph, required this.folderLike, required this.size});
  final _ProjectGlyph glyph;
  final bool folderLike;
  final double size;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _ProjectGlyphPainter(glyph: glyph, folderLike: folderLike),
      ),
    );
  }
}

class _ProjectGlyphPainter extends CustomPainter {
  const _ProjectGlyphPainter({required this.glyph, required this.folderLike});
  final _ProjectGlyph glyph;
  final bool folderLike;

  @override
  void paint(Canvas canvas, Size size) {
    final green = Paint()
      ..color = SportotekaPlayerProjectScreen._green
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final graphite = Paint()
      ..color = const Color(0xFF253029)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.8
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;
    final soft = Paint()
      ..color = const Color(0xFFF0F7F3)
      ..style = PaintingStyle.fill;

    final rect = Rect.fromLTWH(size.width * .08, size.height * .13, size.width * .84, size.height * .72);
    final rr = RRect.fromRectAndRadius(rect, Radius.circular(size.width * .12));
    canvas.drawRRect(rr, soft);

    if (folderLike) {
      final path = Path()
        ..moveTo(size.width * .16, size.height * .35)
        ..lineTo(size.width * .16, size.height * .25)
        ..lineTo(size.width * .43, size.height * .25)
        ..lineTo(size.width * .51, size.height * .34)
        ..lineTo(size.width * .84, size.height * .34)
        ..lineTo(size.width * .84, size.height * .73)
        ..lineTo(size.width * .16, size.height * .73)
        ..close();
      canvas.drawPath(path, graphite);
    } else {
      final doc = RRect.fromRectAndRadius(
        Rect.fromLTWH(size.width * .23, size.height * .19, size.width * .54, size.height * .62),
        Radius.circular(size.width * .06),
      );
      canvas.drawRRect(doc, graphite);
      canvas.drawLine(Offset(size.width * .34, size.height * .34), Offset(size.width * .66, size.height * .34), green);
    }

    switch (glyph) {
      case _ProjectGlyph.card:
        canvas.drawCircle(Offset(size.width * .5, size.height * .49), size.width * .08, green);
        canvas.drawArc(Rect.fromCenter(center: Offset(size.width * .5, size.height * .66), width: size.width * .3, height: size.height * .2), 3.35, 2.72, false, green);
        break;
      case _ProjectGlyph.diary:
        canvas.drawLine(Offset(size.width * .35, size.height * .5), Offset(size.width * .65, size.height * .5), green);
        canvas.drawLine(Offset(size.width * .35, size.height * .61), Offset(size.width * .59, size.height * .61), green);
        break;
      case _ProjectGlyph.readiness:
        final p = Path()
          ..moveTo(size.width * .31, size.height * .57)
          ..lineTo(size.width * .42, size.height * .57)
          ..lineTo(size.width * .48, size.height * .43)
          ..lineTo(size.width * .55, size.height * .65)
          ..lineTo(size.width * .62, size.height * .53)
          ..lineTo(size.width * .69, size.height * .53);
        canvas.drawPath(p, green);
        break;
      case _ProjectGlyph.activity:
        canvas.drawArc(Rect.fromCenter(center: Offset(size.width * .5, size.height * .56), width: size.width * .32, height: size.height * .32), 0.4, 5.1, false, green);
        break;
      case _ProjectGlyph.matches:
        canvas.drawCircle(Offset(size.width * .5, size.height * .57), size.width * .13, green);
        canvas.drawLine(Offset(size.width * .42, size.height * .48), Offset(size.width * .58, size.height * .66), green);
        canvas.drawLine(Offset(size.width * .58, size.height * .48), Offset(size.width * .42, size.height * .66), green);
        break;
      case _ProjectGlyph.testing:
        canvas.drawLine(Offset(size.width * .34, size.height * .65), Offset(size.width * .34, size.height * .53), green);
        canvas.drawLine(Offset(size.width * .49, size.height * .65), Offset(size.width * .49, size.height * .43), green);
        canvas.drawLine(Offset(size.width * .64, size.height * .65), Offset(size.width * .64, size.height * .36), green);
        break;
      case _ProjectGlyph.health:
        canvas.drawLine(Offset(size.width * .5, size.height * .43), Offset(size.width * .5, size.height * .64), green);
        canvas.drawLine(Offset(size.width * .39, size.height * .535), Offset(size.width * .61, size.height * .535), green);
        break;
      case _ProjectGlyph.documents:
        canvas.drawLine(Offset(size.width * .35, size.height * .48), Offset(size.width * .67, size.height * .48), green);
        canvas.drawLine(Offset(size.width * .35, size.height * .58), Offset(size.width * .62, size.height * .58), green);
        break;
      }
  }

  @override
  bool shouldRepaint(covariant _ProjectGlyphPainter oldDelegate) => oldDelegate.glyph != glyph || oldDelegate.folderLike != folderLike;
}

class _PlayerProjectFile {
  const _PlayerProjectFile({
    required this.section,
    required this.title,
    required this.subtitle,
    required this.glyph,
    this.folderLike = false,
  });
  final WorkspacePlayerSection section;
  final String title;
  final String subtitle;
  final _ProjectGlyph glyph;
  final bool folderLike;
}
