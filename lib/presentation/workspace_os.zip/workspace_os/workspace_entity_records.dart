import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/sportoteka_workspace_icons.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_document_editor.dart';
import 'package:url_launcher/url_launcher.dart';

class WorkspaceEntityProperty {
  const WorkspaceEntityProperty(this.label, this.value);
  final String label;
  final String value;
}

class WorkspaceEntityRecordBrowser extends StatefulWidget {
  const WorkspaceEntityRecordBrowser({
    super.key,
    required this.ownerTitle,
    required this.sectionTitle,
    required this.iconKind,
    required this.loadRecords,
    required this.titleFor,
    required this.subtitleFor,
    required this.dateFor,
    required this.propertiesFor,
    required this.openRecord,
    this.emptyText = 'Записей пока нет',
  });

  final String ownerTitle;
  final String sectionTitle;
  final SportotekaWorkspaceIconKind iconKind;
  final Future<List<Map<String, dynamic>>> Function() loadRecords;
  final String Function(Map<String, dynamic>) titleFor;
  final String Function(Map<String, dynamic>) subtitleFor;
  final String Function(Map<String, dynamic>) dateFor;
  final List<WorkspaceEntityProperty> Function(Map<String, dynamic>) propertiesFor;
  final Future<void> Function(BuildContext context, Map<String, dynamic> record) openRecord;
  final String emptyText;

  @override
  State<WorkspaceEntityRecordBrowser> createState() => _WorkspaceEntityRecordBrowserState();
}

class _WorkspaceEntityRecordBrowserState extends State<WorkspaceEntityRecordBrowser> {
  static const _green = Color(0xFF0B8F55);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);
  static const _line = Color(0xFFE7EAE7);
  static const _soft = Color(0xFFF7F8F7);

  final _search = TextEditingController();
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _records = <Map<String, dynamic>>[];
  Map<String, dynamic>? _selected;
  bool _newestFirst = true;

  @override
  void initState() {
    super.initState();
    _search.addListener(_changed);
    _load();
  }

  @override
  void dispose() {
    _search
      ..removeListener(_changed)
      ..dispose();
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  DateTime _date(Map<String, dynamic> row) {
    final raw = widget.dateFor(row).trim();
    if (raw.isEmpty) return DateTime.fromMillisecondsSinceEpoch(0);
    return DateTime.tryParse(raw.replaceFirst(' ', 'T')) ?? DateTime.fromMillisecondsSinceEpoch(0);
  }

  List<Map<String, dynamic>> get _visible {
    final q = _search.text.trim().toLowerCase();
    final rows = _records.where((r) {
      if (q.isEmpty) return true;
      final props = widget.propertiesFor(r).map((p) => '${p.label} ${p.value}').join(' ');
      return '${widget.titleFor(r)} ${widget.subtitleFor(r)} ${widget.dateFor(r)} $props'.toLowerCase().contains(q);
    }).map((e) => Map<String, dynamic>.from(e)).toList();
    rows.sort((a, b) => _newestFirst ? _date(b).compareTo(_date(a)) : _date(a).compareTo(_date(b)));
    return rows;
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows = await widget.loadRecords();
      if (!mounted) return;
      setState(() {
        _records = rows;
        _selected = rows.isEmpty ? null : rows.first;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = '$e';
      });
    }
  }

  Future<void> _properties(Map<String, dynamic> row) async {
    final mobile = MediaQuery.sizeOf(context).width < 920;
    if (!mobile) {
      setState(() => _selected = row);
      return;
    }
    await showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (sheetContext) => SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 16, 18, 24),
          child: _EntityProperties(
            title: widget.titleFor(row),
            iconKind: widget.iconKind,
            properties: widget.propertiesFor(row),
            onOpen: () async {
              Navigator.of(sheetContext).pop();
              await widget.openRecord(context, row);
            },
          ),
        ),
      ),
    );
  }

  Future<void> _menu(Map<String, dynamic> row, Offset position) async {
    final action = await showMenu<String>(
      context: context,
      color: Colors.white,
      surfaceTintColor: Colors.white,
      position: RelativeRect.fromLTRB(position.dx, position.dy, position.dx, position.dy),
      items: <PopupMenuEntry<String>>[
        PopupMenuItem<String>(value: 'open', child: Text('Открыть', style: AppTypography.menuTitle(color: _text))),
        PopupMenuItem<String>(value: 'properties', child: Text('Свойства', style: AppTypography.menuTitle(color: _text))),
      ],
    );
    if (!mounted) return;
    if (action == 'open') await widget.openRecord(context, row);
    if (action == 'properties') await _properties(row);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final mobile = constraints.maxWidth < 700;
        final inspector = constraints.maxWidth >= 920;
        return ColoredBox(
          color: Colors.white,
          child: Column(
            children: [
              Container(
                height: mobile ? 58 : 64,
                padding: EdgeInsets.symmetric(horizontal: mobile ? 8 : 12),
                child: Row(
                  children: [
                    IconButton(
                      tooltip: 'Назад',
                      onPressed: () => Navigator.of(context).maybePop(),
                      icon: const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.back, size: 20),
                    ),
                    const SizedBox(width: 3),
                    SportotekaWorkspaceIcon(kind: widget.iconKind, size: mobile ? 31 : 34),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.sectionTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.screenTitle(color: _text)),
                          Text(widget.ownerTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.secondary(color: _muted)),
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: 'Обновить',
                      onPressed: _load,
                      icon: const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.refresh, size: 19),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: _line),
              Container(
                padding: EdgeInsets.fromLTRB(mobile ? 10 : 14, 9, mobile ? 10 : 14, 9),
                color: Colors.white,
                child: Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 36,
                        child: TextField(
                          controller: _search,
                          style: AppTypography.formText(color: _text),
                          decoration: InputDecoration(
                            hintText: 'Поиск по папке',
                            hintStyle: AppTypography.formHint(color: _muted),
                            prefixIcon: const Padding(
                              padding: EdgeInsets.all(9),
                              child: SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.search, size: 17),
                            ),
                            filled: true,
                            fillColor: _soft,
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    TextButton(
                      onPressed: () => setState(() => _newestFirst = !_newestFirst),
                      child: Text(_newestFirst ? 'Сначала новые' : 'Сначала старые', style: AppTypography.action(color: _muted)),
                    ),
                  ],
                ),
              ),
              const Divider(height: 1, color: _line),
              if (_error != null)
                Container(
                  width: double.infinity,
                  color: const Color(0xFFFFF3F1),
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                  child: Text(_error!, style: AppTypography.caption(color: const Color(0xFFB42318))),
                ),
              Expanded(
                child: Row(
                  children: [
                    Expanded(
                      child: _loading
                          ? const Center(child: CircularProgressIndicator(color: _green))
                          : _visible.isEmpty
                              ? Center(
                                  child: Padding(
                                    padding: const EdgeInsets.all(24),
                                    child: Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        SportotekaWorkspaceIcon(kind: widget.iconKind, size: 48, color: const Color(0xFF6E7A73)),
                                        const SizedBox(height: 12),
                                        Text(widget.emptyText, textAlign: TextAlign.center, style: AppTypography.secondary(color: _muted)),
                                      ],
                                    ),
                                  ),
                                )
                              : ListView.separated(
                                  padding: const EdgeInsets.fromLTRB(10, 4, 10, 20),
                                  itemCount: _visible.length,
                                  separatorBuilder: (_, __) => const Divider(height: 1, indent: 58, color: _line),
                                  itemBuilder: (_, index) {
                                    final row = _visible[index];
                                    final selected = identical(_selected, row) || (_selected != null && _sameRecord(_selected!, row));
                                    final title = widget.titleFor(row);
                                    final subtitle = widget.subtitleFor(row);
                                    final date = _friendlyDate(widget.dateFor(row));
                                    final tile = Material(
                                      color: selected ? const Color(0xFFF1F7F4) : Colors.white,
                                      borderRadius: BorderRadius.circular(10),
                                      child: InkWell(
                                        borderRadius: BorderRadius.circular(10),
                                        onTap: () {
                                          if (mobile) {
                                            widget.openRecord(context, row);
                                          } else {
                                            setState(() => _selected = row);
                                          }
                                        },
                                        onDoubleTap: mobile ? null : () => widget.openRecord(context, row),
                                        onLongPress: () => _properties(row),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
                                          child: Row(
                                            children: [
                                              Container(
                                                width: 40,
                                                height: 40,
                                                decoration: BoxDecoration(color: const Color(0xFFF1F7F4), borderRadius: BorderRadius.circular(11)),
                                                alignment: Alignment.center,
                                                child: SportotekaWorkspaceIcon(kind: widget.iconKind, size: 25),
                                              ),
                                              const SizedBox(width: 10),
                                              Expanded(
                                                child: Column(
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: [
                                                    Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.itemTitle(color: _text)),
                                                    if (subtitle.isNotEmpty) ...[
                                                      const SizedBox(height: 2),
                                                      Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.secondary(color: _muted)),
                                                    ],
                                                  ],
                                                ),
                                              ),
                                              if (date.isNotEmpty)
                                                SizedBox(width: mobile ? 76 : 104, child: Text(date, textAlign: TextAlign.right, style: AppTypography.captionMedium(color: _text))),
                                              const SizedBox(width: 4),
                                              const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.chevronRight, size: 16, color: _muted),
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                    return GestureDetector(
                                      behavior: HitTestBehavior.opaque,
                                      onSecondaryTapDown: (d) => _menu(row, d.globalPosition),
                                      child: tile,
                                    );
                                  },
                                ),
                    ),
                    if (inspector) ...[
                      const VerticalDivider(width: 1, color: _line),
                      SizedBox(
                        width: 280,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: _selected == null
                              ? Center(child: Text('Выберите запись', style: AppTypography.secondary(color: _muted)))
                              : _EntityProperties(
                                  title: widget.titleFor(_selected!),
                                  iconKind: widget.iconKind,
                                  properties: widget.propertiesFor(_selected!),
                                  onOpen: () => widget.openRecord(context, _selected!),
                                ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  bool _sameRecord(Map<String, dynamic> a, Map<String, dynamic> b) {
    for (final key in const <String>['id', 'match_id', 'event_id', 'session_id', 'plan_id', 'record_id', 'date', 'created_at']) {
      final av = '${a[key] ?? ''}';
      final bv = '${b[key] ?? ''}';
      if (av.isNotEmpty && bv.isNotEmpty && av == bv) return true;
    }
    return identical(a, b);
  }

  String _friendlyDate(String raw) {
    final d = DateTime.tryParse(raw.replaceFirst(' ', 'T'));
    if (d == null) return raw;
    String two(int n) => n.toString().padLeft(2, '0');
    return '${two(d.day)}.${two(d.month)}.${d.year}';
  }
}

class _EntityProperties extends StatelessWidget {
  const _EntityProperties({required this.title, required this.iconKind, required this.properties, required this.onOpen});
  final String title;
  final SportotekaWorkspaceIconKind iconKind;
  final List<WorkspaceEntityProperty> properties;
  final VoidCallback onOpen;

  @override
  Widget build(BuildContext context) {
    const text = Color(0xFF101814);
    const muted = Color(0xFF758079);
    const green = Color(0xFF0B8F55);
    final visible = properties.where((p) => p.value.trim().isNotEmpty && p.value.trim() != '—').toList();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisSize: MainAxisSize.min,
      children: [
        Row(
          children: [
            SportotekaWorkspaceIcon(kind: iconKind, size: 34),
            const SizedBox(width: 10),
            Expanded(child: Text('Свойства', style: AppTypography.sectionTitle(color: text))),
          ],
        ),
        const SizedBox(height: 14),
        Text(title, style: AppTypography.itemTitle(color: text)),
        const SizedBox(height: 14),
        for (final prop in visible)
          Padding(
            padding: const EdgeInsets.only(bottom: 11),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(prop.label, style: AppTypography.caption(color: muted)),
                const SizedBox(height: 2),
                Text(prop.value, maxLines: 4, overflow: TextOverflow.ellipsis, style: AppTypography.secondaryMedium(color: text)),
              ],
            ),
          ),
        const SizedBox(height: 6),
        FilledButton(
          onPressed: onOpen,
          style: FilledButton.styleFrom(backgroundColor: green, elevation: 0),
          child: Text('Открыть', style: AppTypography.actionStrong(color: Colors.white)),
        ),
      ],
    );
  }
}

class WorkspaceEntityRecordDocument extends StatefulWidget {
  const WorkspaceEntityRecordDocument({
    super.key,
    required this.ownerTitle,
    required this.sectionTitle,
    required this.title,
    required this.iconKind,
    required this.record,
    required this.properties,
    required this.noteKey,
    this.onEdit,
    this.onRefresh,
    this.fileUrl = '',
  });

  final String ownerTitle;
  final String sectionTitle;
  final String title;
  final SportotekaWorkspaceIconKind iconKind;
  final Map<String, dynamic> record;
  final List<WorkspaceEntityProperty> properties;
  final String noteKey;
  final Future<void> Function()? onEdit;
  final Future<void> Function()? onRefresh;
  final String fileUrl;

  @override
  State<WorkspaceEntityRecordDocument> createState() => _WorkspaceEntityRecordDocumentState();
}

class _WorkspaceEntityRecordDocumentState extends State<WorkspaceEntityRecordDocument> {
  static const _green = Color(0xFF0B8F55);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);
  static const _line = Color(0xFFE7EAE7);
  String _note = '';
  bool _busy = false;
  bool _detailsOpen = false;

  @override
  void initState() {
    super.initState();
    _loadNote();
  }

  Future<void> _loadNote() async {
    final prefs = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() => _note = prefs.getString(widget.noteKey) ?? '');
  }

  Future<void> _saveNote(String _, String body) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(widget.noteKey, body);
    if (mounted) setState(() => _note = body);
  }

  Future<void> _edit() async {
    if (widget.onEdit == null || _busy) return;
    setState(() => _busy = true);
    try {
      await widget.onEdit!.call();
      await widget.onRefresh?.call();
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _openAttachment() async {
    final uri = Uri.tryParse(widget.fileUrl);
    if (uri == null) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) {
    final visible = widget.properties.where((p) => p.value.trim().isNotEmpty && p.value.trim() != '—').toList();
    final headline = visible.take(4).toList();
    final rest = visible.skip(4).toList();
    return ColoredBox(
      color: Colors.white,
      child: Column(
        children: [
          Container(
            height: 62,
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              children: [
                IconButton(
                  onPressed: () => Navigator.of(context).maybePop(),
                  icon: const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.back, size: 20),
                ),
                const SizedBox(width: 3),
                SportotekaWorkspaceIcon(kind: widget.iconKind, size: 31),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${widget.ownerTitle} — ${widget.title}', maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.screenTitle(color: _text)),
                      Text(widget.sectionTitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.caption(color: _muted)),
                    ],
                  ),
                ),
                if (widget.onEdit != null)
                  TextButton(onPressed: _busy ? null : _edit, child: Text(_busy ? 'Сохранение…' : 'Редактировать', style: AppTypography.actionStrong(color: _green))),
                if (widget.fileUrl.isNotEmpty)
                  TextButton(onPressed: _openAttachment, child: Text('Вложение', style: AppTypography.actionStrong(color: _green))),
              ],
            ),
          ),
          const Divider(height: 1, color: _line),
          if (headline.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 9),
              color: const Color(0xFFFAFBFA),
              child: Wrap(
                spacing: 18,
                runSpacing: 6,
                children: [
                  for (final p in headline)
                    _RibbonProperty(label: p.label, value: p.value),
                  if (rest.isNotEmpty)
                    InkWell(
                      onTap: () => setState(() => _detailsOpen = !_detailsOpen),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Text(_detailsOpen ? 'Скрыть данные' : 'Все данные', style: AppTypography.action(color: _green)),
                      ),
                    ),
                ],
              ),
            ),
          if (_detailsOpen && rest.isNotEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
              decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _line))),
              child: Wrap(
                spacing: 22,
                runSpacing: 10,
                children: [
                  for (final p in rest)
                    SizedBox(width: 230, child: _RibbonProperty(label: p.label, value: p.value, multiline: true)),
                ],
              ),
            )
          else
            const Divider(height: 1, color: _line),
          Expanded(
            child: WorkspaceDocumentEditor(
              key: ValueKey('${widget.noteKey}:$_note'),
              initialTitle: '${widget.title} — ${widget.ownerTitle}',
              initialBody: _note,
              onSave: _saveNote,
            ),
          ),
        ],
      ),
    );
  }
}

class _RibbonProperty extends StatelessWidget {
  const _RibbonProperty({required this.label, required this.value, this.multiline = false});
  final String label;
  final String value;
  final bool multiline;
  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: multiline ? 230 : 190),
      child: RichText(
        maxLines: multiline ? 4 : 1,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          style: AppTypography.secondary(color: const Color(0xFF101814)),
          children: [
            TextSpan(text: '$label  ', style: AppTypography.caption(color: const Color(0xFF758079))),
            TextSpan(text: value, style: AppTypography.secondaryMedium(color: const Color(0xFF101814))),
          ],
        ),
      ),
    );
  }
}
