import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/sportoteka_workspace_icons.dart';

class WorkspaceDocumentEditor extends StatefulWidget {
  const WorkspaceDocumentEditor({
    super.key,
    required this.initialTitle,
    this.initialBody = '',
    this.readOnly = false,
    this.onSave,
  });

  final String initialTitle;
  final String initialBody;
  final bool readOnly;
  final Future<void> Function(String title, String body)? onSave;

  @override
  State<WorkspaceDocumentEditor> createState() => _WorkspaceDocumentEditorState();
}

class _WorkspaceDocumentEditorState extends State<WorkspaceDocumentEditor> {
  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;
  bool _saving = false;
  bool _dirty = false;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.initialTitle);
    _bodyController = TextEditingController(text: widget.initialBody);
    _titleController.addListener(_markDirty);
    _bodyController.addListener(_markDirty);
  }

  void _markDirty() {
    if (!_dirty && mounted) setState(() => _dirty = true);
  }

  @override
  void dispose() {
    _titleController.dispose();
    _bodyController.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (widget.readOnly || widget.onSave == null || _saving) return;
    setState(() => _saving = true);
    try {
      await widget.onSave!(_titleController.text.trim(), _bodyController.text);
      if (mounted) setState(() => _dirty = false);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _wrapSelection(String left, String right) {
    if (widget.readOnly) return;
    final value = _bodyController.value;
    final selection = value.selection;
    if (!selection.isValid) return;
    final start = selection.start;
    final end = selection.end;
    final selected = value.text.substring(start, end);
    final replacement = '$left$selected$right';
    final text = value.text.replaceRange(start, end, replacement);
    _bodyController.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: start + replacement.length),
    );
  }

  void _prefixLine(String prefix) {
    if (widget.readOnly) return;
    final value = _bodyController.value;
    final cursor = value.selection.baseOffset.clamp(0, value.text.length).toInt();
    final lineStart = value.text.lastIndexOf('\n', cursor == 0 ? 0 : cursor - 1) + 1;
    final text = value.text.replaceRange(lineStart, lineStart, prefix);
    _bodyController.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: cursor + prefix.length),
    );
  }

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.sizeOf(context).width;
    final mobile = width < 700;
    final padding = mobile ? 14.0 : 22.0;

    return Shortcuts(
      shortcuts: const <ShortcutActivator, Intent>{
        SingleActivator(LogicalKeyboardKey.keyS, meta: true): _SaveIntent(),
        SingleActivator(LogicalKeyboardKey.keyS, control: true): _SaveIntent(),
      },
      child: Actions(
        actions: <Type, Action<Intent>>{
          _SaveIntent: CallbackAction<_SaveIntent>(onInvoke: (_) {
            _save();
            return null;
          }),
        },
        child: Focus(
          autofocus: true,
          child: Column(
            children: [
              _EditorToolbar(
                mobile: mobile,
                dirty: _dirty,
                saving: _saving,
                readOnly: widget.readOnly,
                onBold: () => _wrapSelection('**', '**'),
                onItalic: () => _wrapSelection('_', '_'),
                onHeading: () => _prefixLine('## '),
                onBullet: () => _prefixLine('• '),
                onNumbered: () => _prefixLine('1. '),
                onQuote: () => _prefixLine('> '),
                onSave: _save,
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.fromLTRB(padding, 18, padding, 48),
                  child: Center(
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 840),
                      child: DecoratedBox(
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(mobile ? 12 : 16),
                          boxShadow: const [
                            BoxShadow(
                              color: Color(0x12000000),
                              blurRadius: 24,
                              offset: Offset(0, 8),
                            ),
                          ],
                        ),
                        child: Padding(
                          padding: EdgeInsets.fromLTRB(
                            mobile ? 18 : 44,
                            mobile ? 22 : 42,
                            mobile ? 18 : 44,
                            mobile ? 32 : 58,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              TextField(
                                controller: _titleController,
                                readOnly: widget.readOnly,
                                maxLines: 2,
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Название документа',
                                  isDense: true,
                                ),
                                style: AppTypography.screenTitle().copyWith(
                                  fontSize: mobile ? 18 : 20,
                                  height: 1.18,
                                ),
                              ),
                              const SizedBox(height: 18),
                              const Divider(height: 1, color: Color(0xFFE7E9E7)),
                              const SizedBox(height: 20),
                              TextField(
                                controller: _bodyController,
                                readOnly: widget.readOnly,
                                minLines: mobile ? 18 : 24,
                                maxLines: null,
                                keyboardType: TextInputType.multiline,
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Начните писать…',
                                  alignLabelWithHint: true,
                                ),
                                style: AppTypography.body().copyWith(
                                  fontSize: mobile ? 13.2 : 13.5,
                                  height: 1.55,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EditorToolbar extends StatelessWidget {
  const _EditorToolbar({
    required this.mobile,
    required this.dirty,
    required this.saving,
    required this.readOnly,
    required this.onBold,
    required this.onItalic,
    required this.onHeading,
    required this.onBullet,
    required this.onNumbered,
    required this.onQuote,
    required this.onSave,
  });

  final bool mobile;
  final bool dirty;
  final bool saving;
  final bool readOnly;
  final VoidCallback onBold;
  final VoidCallback onItalic;
  final VoidCallback onHeading;
  final VoidCallback onBullet;
  final VoidCallback onNumbered;
  final VoidCallback onQuote;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    final actions = <Widget>[
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.bold, tooltip: 'Жирный', onTap: onBold),
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.italic, tooltip: 'Курсив', onTap: onItalic),
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.heading, tooltip: 'Заголовок', onTap: onHeading),
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.bullets, tooltip: 'Список', onTap: onBullet),
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.numbered, tooltip: 'Нумерация', onTap: onNumbered),
      _ToolbarButton(icon: SportotekaWorkspaceIconKind.quote, tooltip: 'Цитата', onTap: onQuote),
    ];

    return Container(
      height: mobile ? 54 : 58,
      padding: EdgeInsets.symmetric(horizontal: mobile ? 8 : 14),
      decoration: const BoxDecoration(
        color: Color(0xFFF8F9F8),
        border: Border(bottom: BorderSide(color: Color(0xFFE5E7E5))),
      ),
      child: Row(
        children: [
          if (!mobile)
            Text('Документ', style: AppTypography.menuTitle()),
          if (!mobile) const SizedBox(width: 14),
          Expanded(
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: actions,
            ),
          ),
          if (!readOnly)
            FilledButton.icon(
              onPressed: saving ? null : onSave,
              icon: saving
                  ? const SizedBox.square(
                      dimension: 14,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.save, size: 17, color: Colors.white, accentColor: Colors.white),
              label: Text(
                dirty ? 'Сохранить' : 'Сохранено',
                style: AppTypography.actionStrong(color: Colors.white),
              ),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFF0B8F55),
                elevation: 0,
                padding: EdgeInsets.symmetric(horizontal: mobile ? 10 : 14),
              ),
            ),
        ],
      ),
    );
  }
}

class _ToolbarButton extends StatelessWidget {
  const _ToolbarButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final SportotekaWorkspaceIconKind icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return IconButton(
      onPressed: onTap,
      icon: SportotekaWorkspaceIcon(kind: icon, size: 19),
      tooltip: tooltip,
      visualDensity: VisualDensity.compact,
    );
  }
}

class _SaveIntent extends Intent {
  const _SaveIntent();
}
