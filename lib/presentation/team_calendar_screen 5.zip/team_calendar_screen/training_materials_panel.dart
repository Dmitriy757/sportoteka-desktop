import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_server_storage.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import 'training_lifecycle_api.dart';

class TrainingMaterialsPanel extends StatefulWidget {
  final String apiBase;
  final int clubId;
  final int teamId;
  final int eventId;
  final int currentUserId;

  const TrainingMaterialsPanel({
    super.key,
    required this.apiBase,
    required this.clubId,
    required this.teamId,
    required this.eventId,
    this.currentUserId = 0,
  });

  @override
  State<TrainingMaterialsPanel> createState() => _TrainingMaterialsPanelState();
}

class _TrainingMaterialsPanelState extends State<TrainingMaterialsPanel> {
  static const _green = Color(0xFF14915D);
  static const _greenDark = Color(0xFF0F7B50);
  static const _greenSoft = Color(0xFFF7FBF8);
  static const _soft = Color(0xFFF8FAF9);
  static const _line = Color(0xFFE5ECE8);
  static const _text = Color(0xFF0B0F14);
  static const _muted = Color(0xFF667085);

  bool loading = true;
  bool uploading = false;
  bool linking = false;
  String? error;
  int linkedPlanId = 0;
  List<Map<String, dynamic>> plans = [];
  List<Map<String, dynamic>> attachments = [];
  List<Map<String, dynamic>> linkedDocuments = [];
  Map<String, dynamic>? openedDocument;
  bool openedDocumentLinked = false;

  WorkspaceServerStorage get _storage => WorkspaceServerStorage(
        clubId: widget.clubId,
        userId: widget.currentUserId,
      );

  @override
  void initState() {
    super.initState();
    _load();
  }

  dynamic _decode(String body) {
    try {
      return jsonDecode(body);
    } catch (_) {
      final i = body.indexOf('{');
      if (i >= 0) {
        try {
          return jsonDecode(body.substring(i));
        } catch (_) {}
      }
      return <String, dynamic>{};
    }
  }

  List<Map<String, dynamic>> _list(dynamic data, List<String> keys) {
    dynamic raw = data;
    if (data is Map) {
      for (final key in keys) {
        if (data[key] is List) {
          raw = data[key];
          break;
        }
      }
    }
    if (raw is! List) return <Map<String, dynamic>>[];
    return raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
  }

  int _id(dynamic value) => int.tryParse('${value ?? 0}') ?? 0;

  String _planTitle(Map<String, dynamic> p) {
    final value = '${p['theme'] ?? p['title'] ?? p['name'] ?? p['plan_title'] ?? ''}'.trim();
    return value.isEmpty ? 'План тренировки' : value;
  }

  String _fileTitle(Map<String, dynamic> row) {
    final value = '${row['title'] ?? row['original_name'] ?? row['file_name'] ?? row['name'] ?? 'Документ'}'.trim();
    return value.isEmpty ? 'Документ' : value;
  }

  String _fileUrl(Map<String, dynamic> row) {
    for (final key in const ['url', 'file_url', 'download_url', 'path']) {
      final value = '${row[key] ?? ''}'.trim();
      if (value.startsWith('http://') || value.startsWith('https://')) return value;
      if (value.startsWith('/')) return 'https://sportotekaapp.ru$value';
    }
    return '';
  }

  Future<void> _load() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final results = await Future.wait<dynamic>([
        _loadPlans(),
        _loadLinkedPlan(),
        _storage.listAttachments(
          entityType: 'training',
          entityId: widget.eventId,
          sectionKey: 'documents',
        ),
        _storage.listEntityDocuments(
          entityType: 'training',
          entityId: '${widget.eventId}',
        ),
      ]);

      if (!mounted) return;
      setState(() {
        plans = results[0] as List<Map<String, dynamic>>;
        linkedPlanId = results[1] as int;
        attachments = results[2] as List<Map<String, dynamic>>;
        linkedDocuments = results[3] as List<Map<String, dynamic>>;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = '$e';
      });
    }
  }

  Future<List<Map<String, dynamic>>> _loadPlans() async {
    try {
      final uri = Uri.parse('${widget.apiBase}/get_latest_training_plans.php').replace(
        queryParameters: <String, String>{
          'team_id': '${widget.teamId}',
          'club_id': '${widget.clubId}',
          'limit': '30',
        },
      );
      final r = await http.get(uri).timeout(const Duration(seconds: 10));
      return _list(_decode(r.body), const ['plans', 'items', 'data', 'result']);
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  Future<int> _loadLinkedPlan() async {
    try {
      final uri = Uri.parse('${widget.apiBase}/training_plan_link.php').replace(
        queryParameters: <String, String>{'event_id': '${widget.eventId}'},
      );
      final r = await http.get(uri).timeout(const Duration(seconds: 8));
      if (r.statusCode < 200 || r.statusCode >= 300) return 0;
      final data = _decode(r.body);
      if (data is! Map || data['success'] == false) return 0;
      return _id(data['plan_id'] ?? (data['link'] is Map ? data['link']['plan_id'] : 0));
    } catch (_) {
      return 0;
    }
  }

  Future<void> _linkPlan(int planId) async {
    if (linking || planId <= 0) return;
    setState(() => linking = true);
    try {
      final r = await http.post(
        Uri.parse('${widget.apiBase}/training_plan_link.php'),
        body: <String, String>{
          'event_id': '${widget.eventId}',
          'team_id': '${widget.teamId}',
          'club_id': '${widget.clubId}',
          'plan_id': '$planId',
          if (widget.currentUserId > 0) 'linked_by': '${widget.currentUserId}',
        },
      ).timeout(const Duration(seconds: 10));
      final data = _decode(r.body);
      if (r.statusCode < 200 || r.statusCode >= 300 || data is! Map || data['success'] == false) {
        throw Exception(data is Map ? '${data['message'] ?? 'Не удалось привязать план'}' : 'Не удалось привязать план');
      }
      if (widget.currentUserId > 0) {
        final match = plans.where((p) => _id(p['id'] ?? p['plan_id']) == planId).toList();
        try {
          await TrainingLifecycleApi(
            apiBase: widget.apiBase,
            clubId: widget.clubId,
            teamId: widget.teamId,
            eventId: widget.eventId,
          ).recordPlanLinked(
            userId: widget.currentUserId,
            planId: planId,
            planTitle: match.isEmpty ? '' : _planTitle(match.first),
          );
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() => linkedPlanId = planId);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('План привязан к тренировке')),
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$e'.replaceFirst('Exception: ', ''))),
        );
      }
    } finally {
      if (mounted) setState(() => linking = false);
    }
  }

  Future<void> _upload() async {
    if (uploading) return;
    final result = await FilePicker.pickFiles(allowMultiple: true);
    if (result == null) return;
    final paths = result.files.map((f) => f.path).whereType<String>().where((p) => p.trim().isNotEmpty).toList();
    if (paths.isEmpty) return;

    setState(() => uploading = true);
    try {
      for (final path in paths) {
        final name = path.split(RegExp(r'[\\/]')).last;
        await _storage.uploadAttachment(
          filePath: path,
          entityType: 'training',
          entityId: widget.eventId,
          sectionKey: 'documents',
          title: name.replaceFirst(RegExp(r'\.[^.]+$'), ''),
        );
        if (widget.currentUserId > 0) {
          try {
            await TrainingLifecycleApi(
              apiBase: widget.apiBase,
              clubId: widget.clubId,
              teamId: widget.teamId,
              eventId: widget.eventId,
            ).recordDocumentAdded(
              userId: widget.currentUserId,
              fileName: name,
            );
          } catch (_) {}
        }
      }
      await _load();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Документы добавлены в тренировку и Sportoteka OS')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Ошибка загрузки: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => uploading = false);
    }
  }

  void _openFile(Map<String, dynamic> row, {required bool linked}) {
    final raw = _fileUrl(row);
    if (raw.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('У документа нет ссылки для просмотра')),
      );
      return;
    }
    setState(() {
      openedDocument = Map<String, dynamic>.from(row);
      openedDocumentLinked = linked;
    });
  }

  void _closePreview() {
    if (!mounted) return;
    setState(() {
      openedDocument = null;
      openedDocumentLinked = false;
    });
  }

  String _fileExtension(String value) {
    final clean = value.trim().split('?').first.split('#').first;
    final match = RegExp(r'\.([A-Za-z0-9]{2,6})$').firstMatch(clean);
    return match == null ? '' : (match.group(1) ?? '').toUpperCase();
  }

  String _extensionFromRow(Map<String, dynamic> row) {
    for (final value in <String>[
      '${row['original_name'] ?? ''}',
      '${row['file_name'] ?? ''}',
      '${row['name'] ?? ''}',
      '${row['title'] ?? ''}',
      _fileUrl(row),
    ]) {
      final ext = _fileExtension(value);
      if (ext.isNotEmpty) return ext;
    }
    return '';
  }

  String _documentSource(Map<String, dynamic> row, {required bool linked}) {
    if (linked) return 'Sportoteka OS';
    final type = '${row['entity_type'] ?? ''}'.trim();
    if (type.isNotEmpty) return type == 'training' ? 'Документ тренировки' : type;
    return 'Документ тренировки';
  }

  String _formatBytes(dynamic value) {
    final bytes = int.tryParse('${value ?? 0}') ?? 0;
    if (bytes <= 0) return '';
    const units = ['Б', 'КБ', 'МБ', 'ГБ'];
    double size = bytes.toDouble();
    var idx = 0;
    while (size >= 1024 && idx < units.length - 1) {
      size /= 1024;
      idx++;
    }
    final digits = size >= 10 || idx == 0 ? 0 : 1;
    return '${size.toStringAsFixed(digits)} ${units[idx]}';
  }

  String _fileSubtitle(Map<String, dynamic> row, {required bool linked}) {
    final parts = <String>[];
    final source = _documentSource(row, linked: linked);
    if (source.isNotEmpty) parts.add(source);
    final ext = _extensionFromRow(row);
    if (ext.isNotEmpty) parts.add(ext);
    final size = _formatBytes(row['size'] ?? row['file_size'] ?? row['bytes']);
    if (size.isNotEmpty) parts.add(size);
    return parts.join(' · ');
  }

  Future<String> _loadTextPreview(String url) async {
    try {
      final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 12));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        return 'Не удалось загрузить документ (${response.statusCode}).';
      }
      if (response.body.length > 150000) {
        return '${response.body.substring(0, 150000)}\n\n… предпросмотр сокращён';
      }
      return response.body;
    } catch (e) {
      return 'Не удалось загрузить документ: $e';
    }
  }

  Widget _buildDocumentPreview(Map<String, dynamic> row, {required bool linked}) {
    final url = _fileUrl(row);
    final title = _fileTitle(row);
    final ext = _extensionFromRow(row);
    final lower = ext.toLowerCase();
    final isPdf = lower == 'pdf';
    final isImage = const {'jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp'}.contains(lower);
    final isText = const {'txt', 'md', 'json', 'csv', 'log', 'xml'}.contains(lower);

    Widget content;
    if (isPdf) {
      content = ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: SfPdfViewer.network(
          url,
          canShowScrollHead: true,
          canShowScrollStatus: true,
          enableDoubleTapZooming: true,
        ),
      );
    } else if (isImage) {
      content = InteractiveViewer(
        minScale: .7,
        maxScale: 5,
        child: Center(
          child: Image.network(
            url,
            fit: BoxFit.contain,
            loadingBuilder: (context, child, progress) {
              if (progress == null) return child;
              return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: _green));
            },
            errorBuilder: (_, __, ___) => _previewUnsupported(title, ext),
          ),
        ),
      );
    } else if (isText) {
      content = FutureBuilder<String>(
        future: _loadTextPreview(url),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(strokeWidth: 2, color: _green));
          }
          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: SelectableText(
              snapshot.data ?? 'Документ пуст.',
              style: AppTypography.body(color: _text),
            ),
          );
        },
      );
    } else {
      content = _previewUnsupported(title, ext);
    }

    return Column(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
          ),
          child: Row(
            children: [
              Material(
                color: _soft,
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: _closePreview,
                  borderRadius: BorderRadius.circular(10),
                  child: const SizedBox(
                    width: 36,
                    height: 36,
                    child: Icon(Icons.arrow_back_rounded, size: 18, color: _muted),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              const _TrainingBrandDots(),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.itemTitle(color: _text)),
                    const SizedBox(height: 2),
                    Text(
                      _fileSubtitle(row, linked: linked).isEmpty ? 'Просмотр документа' : _fileSubtitle(row, linked: linked),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.caption(color: _muted),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Material(
                color: _soft,
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: _closePreview,
                  borderRadius: BorderRadius.circular(10),
                  child: const SizedBox(
                    width: 36,
                    height: 36,
                    child: Icon(Icons.close_rounded, size: 18, color: _muted),
                  ),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: SizedBox.expand(
            child: ColoredBox(
              color: const Color(0xFFFBFCFB),
              child: content,
            ),
          ),
        ),
      ],
    );
  }

  Widget _previewUnsupported(String title, String ext) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 380),
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const _TrainingBrandDots(),
              const SizedBox(height: 14),
              Container(
                width: 54,
                height: 54,
                decoration: BoxDecoration(
                  color: const Color(0xFFF5F7F6),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.description_outlined, color: _greenDark, size: 24),
              ),
              const SizedBox(height: 14),
              Text(title, textAlign: TextAlign.center, style: AppTypography.subsectionTitle(color: _text)),
              const SizedBox(height: 6),
              Text(
                ext.isEmpty
                    ? 'Формат файла не удалось определить. Просмотр остаётся внутри карточки тренировки.'
                    : 'Формат $ext пока не поддерживает встроенный предпросмотр. PDF, изображения и текстовые файлы открываются прямо здесь.',
                textAlign: TextAlign.center,
                style: AppTypography.secondary(color: _muted),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const Center(child: CircularProgressIndicator(color: _green, strokeWidth: 2));
    }

    final preview = openedDocument;
    if (preview != null) {
      // Предпросмотр занимает всю доступную высоту правой панели до самого низа.
      // Слева остаётся «назад», справа — крестик закрытия документа.
      return SizedBox.expand(
        child: _buildDocumentPreview(
          preview,
          linked: openedDocumentLinked,
        ),
      );
    }

    final linked = plans.where((p) => _id(p['id'] ?? p['plan_id']) == linkedPlanId).toList();
    final linkedPlan = linked.isEmpty ? null : linked.first;

    return RefreshIndicator(
      color: _green,
      onRefresh: _load,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(0, 0, 0, 14),
        children: [
          _section(
            icon: Icons.assignment_turned_in_outlined,
            title: 'План на тренировку',
            child: linkedPlan == null
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(14),
                                                  ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('План пока не привязан.', style: AppTypography.itemTitle(color: _text)),
                            const SizedBox(height: 4),
                            Text('Выбери один из доступных планов команды и привяжи его к тренировке.', style: AppTypography.secondary(color: _muted)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      if (plans.isEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(14),
                                                      ),
                          child: Text('Доступных планов команды не найдено.', style: AppTypography.caption(color: _muted)),
                        )
                      else
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: plans.take(8).map((p) {
                            final id = _id(p['id'] ?? p['plan_id']);
                            return OutlinedButton(
                              onPressed: linking ? null : () => _linkPlan(id),
                              style: OutlinedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                                side: BorderSide.none,
                                foregroundColor: _text,
                                backgroundColor: Colors.white,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text(_planTitle(p), maxLines: 1, overflow: TextOverflow.ellipsis),
                            );
                          }).toList(),
                        ),
                    ],
                  )
                : Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                                          ),
                    child: Row(
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _greenSoft,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.assignment_turned_in_rounded, color: _greenDark, size: 18),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(_planTitle(linkedPlan), style: AppTypography.itemTitle(color: _text)),
                              const SizedBox(height: 3),
                              Text('План привязан к этой тренировке', style: AppTypography.caption(color: _muted)),
                            ],
                          ),
                        ),
                        PopupMenuButton<int>(
                          tooltip: 'Сменить план',
                          onSelected: _linkPlan,
                          itemBuilder: (_) => plans
                              .where((p) => _id(p['id'] ?? p['plan_id']) > 0)
                              .map((p) => PopupMenuItem<int>(
                                    value: _id(p['id'] ?? p['plan_id']),
                                    child: Text(_planTitle(p)),
                                  ))
                              .toList(),
                          child: Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: _soft,
                              borderRadius: BorderRadius.circular(10),
                                                          ),
                            child: const Icon(Icons.more_horiz_rounded, color: _muted, size: 18),
                          ),
                        ),
                      ],
                    ),
                  ),
          ),
          const SizedBox(height: 12),
          _section(
            icon: Icons.folder_copy_outlined,
            title: 'Документы тренировки',
            subtitle: '${attachments.length + linkedDocuments.length} ${_filesWord(attachments.length + linkedDocuments.length)}',
            trailing: TextButton.icon(
              onPressed: uploading ? null : _upload,
              style: TextButton.styleFrom(foregroundColor: _greenDark),
              icon: uploading
                  ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 1.8, color: _green))
                  : const Icon(Icons.add_rounded, size: 17),
              label: Text(uploading ? 'Загрузка...' : 'Добавить'),
            ),
            child: attachments.isEmpty && linkedDocuments.isEmpty
                ? Container(
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                                          ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: _greenSoft,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.folder_open_rounded, color: _greenDark, size: 18),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(
                            'Документов пока нет. Добавленные здесь файлы автоматически будут доступны в Sportoteka OS у этой тренировки.',
                            style: AppTypography.secondary(color: _muted),
                          ),
                        ),
                      ],
                    ),
                  )
                : Column(
                    children: [
                      for (final row in attachments) _fileRow(row, Icons.attach_file_rounded, linked: false),
                      for (final row in linkedDocuments) _fileRow(row, Icons.description_outlined, linked: true),
                    ],
                  ),
          ),
          if (error != null) ...[
            const SizedBox(height: 10),
            Text(error!, style: AppTypography.caption(color: Colors.red.shade700)),
          ],
        ],
      ),
    );
  }

  String _filesWord(int count) {
    final mod10 = count % 10;
    final mod100 = count % 100;
    if (mod10 == 1 && mod100 != 11) return 'файл';
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return 'файла';
    return 'файлов';
  }

  Widget _section({
    required IconData icon,
    required String title,
    required Widget child,
    String? subtitle,
    Widget? trailing,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _soft,
        borderRadius: BorderRadius.circular(16),
              ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const _TrainingBrandDots(),
              const SizedBox(width: 9),
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                                  ),
                child: Icon(icon, size: 16, color: _greenDark),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: AppTypography.subsectionTitle(color: _text)),
                    if (subtitle != null && subtitle!.trim().isNotEmpty) ...[
                      const SizedBox(height: 2),
                      Text(subtitle!, style: AppTypography.caption(color: _muted)),
                    ],
                  ],
                ),
              ),
              if (trailing != null) trailing,
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  Widget _fileRow(Map<String, dynamic> row, IconData icon, {required bool linked}) {
    final url = _fileUrl(row);
    final subtitle = _fileSubtitle(row, linked: linked);
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: url.isEmpty ? null : () => _openFile(row, linked: linked),
        borderRadius: BorderRadius.circular(14),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
                      ),
          child: Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: linked ? _greenSoft : _soft,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(icon, size: 18, color: _greenDark),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      _fileTitle(row),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.itemTitle(color: _text),
                    ),
                    if (subtitle.isNotEmpty) ...[
                      const SizedBox(height: 3),
                      Text(
                        subtitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.caption(color: _muted),
                      ),
                    ],
                  ],
                ),
              ),
              if (url.isNotEmpty) ...[
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: _soft,
                    borderRadius: BorderRadius.circular(10),
                                      ),
                  child: const Icon(Icons.visibility_outlined, size: 15, color: _muted),
                ),
                const SizedBox(width: 6),
              ],
              PopupMenuButton<String>(
                tooltip: 'Действия',
                onSelected: (value) {
                  if (value == 'open' && url.isNotEmpty) _openFile(row, linked: linked);
                  if (value == 'refresh') _load();
                },
                itemBuilder: (_) => <PopupMenuEntry<String>>[
                  if (url.isNotEmpty)
                    const PopupMenuItem<String>(
                      value: 'open',
                      child: Text('Открыть в панели'),
                    ),
                  const PopupMenuItem<String>(
                    value: 'refresh',
                    child: Text('Обновить список'),
                  ),
                ],
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: _soft,
                    borderRadius: BorderRadius.circular(10),
                                      ),
                  child: const Icon(Icons.more_horiz_rounded, size: 17, color: _muted),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TrainingBrandDot extends StatelessWidget {
  final double size;
  final double opacity;
  final Color color;

  const _TrainingBrandDot({required this.size, required this.opacity, required this.color});

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
    );
  }
}

class _TrainingBrandDots extends StatelessWidget {
  const _TrainingBrandDots();

  @override
  Widget build(BuildContext context) {
    const color = Color(0xFF14915D);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: const [
        _TrainingBrandDot(size: 3.5, opacity: .28, color: color),
        SizedBox(width: 3),
        _TrainingBrandDot(size: 4.5, opacity: .48, color: color),
        SizedBox(width: 3),
        _TrainingBrandDot(size: 5.5, opacity: .72, color: color),
        SizedBox(width: 3),
        _TrainingBrandDot(size: 6.5, opacity: 1, color: color),
      ],
    );
  }
}
