import 'package:flutter/material.dart';


class AiPassNetworkEdge {
  final String fromTrackId;
  final String toTrackId;
  final String? team;
  final int count;
  final int successful;
  final double avgStartX;
  final double avgStartY;
  final double avgEndX;
  final double avgEndY;

  const AiPassNetworkEdge({
    required this.fromTrackId,
    required this.toTrackId,
    required this.team,
    required this.count,
    required this.successful,
    required this.avgStartX,
    required this.avgStartY,
    required this.avgEndX,
    required this.avgEndY,
  });

  factory AiPassNetworkEdge.fromJson(Map<String, dynamic> json) {
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    int asInt(dynamic v) =>
        v is num ? v.toInt() : int.tryParse('$v') ?? 0;

    return AiPassNetworkEdge(
      fromTrackId: '${json['from_track_id'] ?? ''}',
      toTrackId: '${json['to_track_id'] ?? ''}',
      team: json['team']?.toString(),
      count: asInt(json['count']),
      successful: asInt(json['successful']),
      avgStartX: asDouble(json['avg_start_x']),
      avgStartY: asDouble(json['avg_start_y']),
      avgEndX: asDouble(json['avg_end_x']),
      avgEndY: asDouble(json['avg_end_y']),
    );
  }
}

class AiAveragePosition {
  final String trackId;
  final String? team;
  final String playerName;
  final double avgX;
  final double avgY;
  final int samples;

  const AiAveragePosition({
    required this.trackId,
    required this.team,
    required this.playerName,
    required this.avgX,
    required this.avgY,
    required this.samples,
  });

  factory AiAveragePosition.fromJson(Map<String, dynamic> json) {
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    int asInt(dynamic v) =>
        v is num ? v.toInt() : int.tryParse('$v') ?? 0;

    return AiAveragePosition(
      trackId: '${json['track_id'] ?? ''}',
      team: json['team']?.toString(),
      playerName: '${json['player_name'] ?? 'Игрок'}',
      avgX: asDouble(json['avg_x']),
      avgY: asDouble(json['avg_y']),
      samples: asInt(json['samples']),
    );
  }
}

class AiDangerMoment {
  final int timeMs;
  final String? team;
  final String type;
  final String title;
  final double dangerScore;

  const AiDangerMoment({
    required this.timeMs,
    required this.team,
    required this.type,
    required this.title,
    required this.dangerScore,
  });

  factory AiDangerMoment.fromJson(Map<String, dynamic> json) {
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    int asInt(dynamic v) =>
        v is num ? v.toInt() : int.tryParse('$v') ?? 0;

    return AiDangerMoment(
      timeMs: asInt(json['time_ms']),
      team: json['team']?.toString(),
      type: '${json['type'] ?? 'danger'}',
      title: '${json['title'] ?? 'Опасный момент'}',
      dangerScore: asDouble(json['danger_score']),
    );
  }
}

class AiPlayerStat {
  final String trackId;
  final String? team;
  final String playerName;
  final int touches;
  final int passes;
  final int successfulPasses;
  final int shots;
  final int interceptions;
  final double distanceM;
  final double maxSpeedKmh;
  final double rating;

  const AiPlayerStat({
    required this.trackId,
    required this.team,
    required this.playerName,
    required this.touches,
    required this.passes,
    required this.successfulPasses,
    required this.shots,
    required this.interceptions,
    required this.distanceM,
    required this.maxSpeedKmh,
    required this.rating,
  });

  factory AiPlayerStat.fromJson(Map<String, dynamic> json) {
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    int asInt(dynamic v) =>
        v is num ? v.toInt() : int.tryParse('$v') ?? 0;

    return AiPlayerStat(
      trackId: '${json['track_id'] ?? ''}',
      team: json['team']?.toString(),
      playerName: '${json['player_name'] ?? 'Игрок'}',
      touches: asInt(json['touches']),
      passes: asInt(json['passes']),
      successfulPasses: asInt(json['successful_passes']),
      shots: asInt(json['shots']),
      interceptions: asInt(json['interceptions']),
      distanceM: asDouble(json['distance_m']),
      maxSpeedKmh: asDouble(json['max_speed_kmh']),
      rating: asDouble(json['rating']),
    );
  }
}


class AiDetectedEvent {
  final String type;
  final String title;
  final String subtitle;
  final int timeMs;
  final double confidence;
  final IconData icon;
  final Color color;
  final Map<String, dynamic>? meta;

  const AiDetectedEvent({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.timeMs,
    required this.confidence,
    required this.icon,
    required this.color,
    this.meta,
  });

  factory AiDetectedEvent.fromBackendJson(Map<String, dynamic> json) {
    int asInt(dynamic v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    bool asBool(dynamic v) => v == true || v == 1 || v == '1' || v == 'true';

    final type = (json['type'] ?? json['event_type'] ?? json['code'] ?? '')
        .toString()
        .trim();
    final title = (json['title'] ?? json['event_title'] ?? 'Событие')
        .toString()
        .trim();
    final team = (json['team'] ?? json['side'] ?? '').toString().trim();
    final startRaw = json['start_ms'] ?? json['time_ms'] ?? json['timeMs'] ?? 0;
    final startMs = asInt(startRaw);
    final endMs = asInt(json['end_ms'] ?? json['end_time_ms'] ?? startMs);
    final confidence = asDouble(json['confidence']);
    final success = json.containsKey('success')
        ? asBool(json['success'])
        : asBool(json['is_positive']);

    final participants = ((json['participants'] as List?) ?? const [])
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();

    final meta = json['meta'] is Map<String, dynamic>
        ? Map<String, dynamic>.from(json['meta'] as Map<String, dynamic>)
        : json['meta'] is Map
            ? Map<String, dynamic>.from(json['meta'] as Map)
            : <String, dynamic>{};

    final subtitle = _buildSubtitle(
      type: type,
      team: team,
      participants: participants,
      meta: meta,
    );

    return AiDetectedEvent(
      type: type.isEmpty ? 'unknown' : type,
      title: title.isEmpty ? 'Событие' : title,
      subtitle: subtitle,
      timeMs: startMs,
      confidence: confidence,
      icon: _iconForType(type),
      color: _colorForType(type),
      meta: {
        ...meta,
        'team': team,
        'start_ms': startMs,
        'time_ms': startMs,
        'end_ms': endMs,
        'success': success,
        'event_title': json['event_title'],
        'event_type': json['event_type'],
        'is_positive': json['is_positive'],
        'participants': participants,
        'player_id': json['player_id'],
        'target_player_id': json['target_player_id'],
        'track_id': json['track_id'],
        'target_track_id': json['target_track_id'],
        'description': json['description'] ?? json['note'],
        'id': json['id'],
      },
    );
  }

  static String _buildSubtitle({
    required String type,
    required String team,
    required List<Map<String, dynamic>> participants,
    required Map<String, dynamic> meta,
  }) {
    final names = participants
        .map((p) => (p['name'] ?? '').toString().trim())
        .where((e) => e.isNotEmpty)
        .toList();

    if (type == 'pass' && names.length >= 2) {
      return '${names[0]} → ${names[1]}';
    }

    if (names.isNotEmpty) {
      return team.isEmpty ? names.join(', ') : '$team • ${names.join(', ')}';
    }

    if (type == 'pass') {
      final direction = (meta['direction'] ?? '').toString();
      final lengthType = (meta['length_type'] ?? '').toString();
      final parts = [direction, lengthType].where((e) => e.isNotEmpty).toList();
      if (parts.isNotEmpty) {
        return team.isEmpty ? parts.join(' ') : '$team • ${parts.join(' ')}';
      }
    }

    if (meta['from_team'] != null && meta['to_team'] != null) {
      return '${meta['from_team']} → ${meta['to_team']}';
    }

    return team.isEmpty ? 'AI событие' : team;
  }

  static IconData _iconForType(String type) {
    switch (type) {
      case 'pass':
      case 'pass_forward_short':
      case 'pass_forward_medium':
      case 'pass_forward_long':
      case 'pass_back_short':
      case 'pass_back_medium':
      case 'pass_back_long':
      case 'pass_side_short':
      case 'pass_side_medium':
      case 'pass_side_long':
        return Icons.compare_arrows_rounded;
      case 'goal':
        return Icons.sports_score_rounded;
      case 'assist':
        return Icons.assistant_direction_rounded;
      case 'yellow_card':
      case 'card_yellow':
        return Icons.style_rounded;
      case 'red_card':
      case 'card_red':
        return Icons.style_rounded;
      case 'interception':
        return Icons.shield_outlined;
      case 'recovery':
        return Icons.autorenew_rounded;
      case 'sprint':
        return Icons.flash_on_rounded;
      case 'acceleration':
        return Icons.trending_up_rounded;
      case 'direction_change':
        return Icons.turn_right_rounded;
      case 'shot':
        return Icons.sports_soccer_rounded;
      default:
        return Icons.analytics_outlined;
    }
  }

  static Color _colorForType(String type) {
    switch (type) {
      case 'pass':
      case 'pass_forward_short':
      case 'pass_forward_medium':
      case 'pass_forward_long':
      case 'pass_back_short':
      case 'pass_back_medium':
      case 'pass_back_long':
      case 'pass_side_short':
      case 'pass_side_medium':
      case 'pass_side_long':
        return const Color(0xFF2563EB);
      case 'goal':
        return const Color(0xFF00A750);
      case 'assist':
        return const Color(0xFF0F766E);
      case 'yellow_card':
      case 'card_yellow':
        return const Color(0xFFF59E0B);
      case 'red_card':
      case 'card_red':
        return const Color(0xFFDC2626);
      case 'interception':
        return const Color(0xFFDC2626);
      case 'recovery':
        return const Color(0xFF16A34A);
      case 'sprint':
        return const Color(0xFFF59E0B);
      case 'acceleration':
        return const Color(0xFF0F766E);
      case 'direction_change':
        return const Color(0xFF7C3AED);
      case 'shot':
        return const Color(0xFFEA580C);
      default:
        return const Color(0xFF334155);
    }
  }
}

class AiTtdSuggestion {
  final String code;
  final String title;
  final String section;
  final int timeMs;
  final double confidence;
  final bool success;
  final Map<String, dynamic>? meta;

  const AiTtdSuggestion({
    required this.code,
    required this.title,
    required this.section,
    required this.timeMs,
    required this.confidence,
    required this.success,
    this.meta,
  });

  factory AiTtdSuggestion.fromBackendJson(Map<String, dynamic> json) {
    int asInt(dynamic v) => v is num ? v.toInt() : int.tryParse('$v') ?? 0;
    double asDouble(dynamic v) =>
        v is num ? v.toDouble() : double.tryParse('$v') ?? 0.0;
    bool asBool(dynamic v) => v == true || v == 1 || v == '1' || v == 'true';

    final type = (json['type'] ?? json['code'] ?? json['event_type'] ?? '')
        .toString()
        .trim();
    final title = (json['title'] ?? json['event_title'] ?? 'AI ТТД')
        .toString()
        .trim();
    final timeMs = asInt(json['start_ms'] ?? json['time_ms'] ?? json['timeMs'] ?? 0);
    final confidence = asDouble(json['confidence']);
    final success = json.containsKey('success')
        ? asBool(json['success'])
        : !json.containsKey('is_positive') || asBool(json['is_positive']);

    final meta = json['meta'] is Map<String, dynamic>
        ? Map<String, dynamic>.from(json['meta'] as Map<String, dynamic>)
        : json['meta'] is Map
            ? Map<String, dynamic>.from(json['meta'] as Map)
            : <String, dynamic>{};

    return AiTtdSuggestion(
      code: type.isEmpty ? 'unknown' : type,
      title: title.isEmpty ? 'AI ТТД' : title,
      section: _sectionForType(type),
      timeMs: timeMs,
      confidence: confidence,
      success: success,
      meta: {
        ...meta,
        'team': json['team'],
        'participants': json['participants'],
        'track_id': json['track_id'],
        'target_track_id': json['target_track_id'],
        'description': json['description'] ?? json['note'],
        'time_ms': timeMs,
        'event_title': json['event_title'],
        'is_positive': json['is_positive'],
        'id': json['id'],
      },
    );
  }

  static String _sectionForType(String type) {
    switch (type) {
      case 'pass':
      case 'forward_short':
      case 'forward_medium':
      case 'forward_long':
      case 'back_short':
      case 'back_medium':
      case 'back_long':
      case 'lateral_short':
      case 'lateral_medium':
      case 'lateral_long':
      case 'pass_forward_short':
      case 'pass_forward_medium':
      case 'pass_forward_long':
      case 'pass_back_short':
      case 'pass_back_medium':
      case 'pass_back_long':
      case 'pass_side_short':
      case 'pass_side_medium':
      case 'pass_side_long':
        return 'Передачи';

      case 'save':
      case 'gk_save':
      case 'gk_saves':
      case 'goalkeeper_save':
      case 'goalkeeper_exit':
      case 'gk_exit':
      case 'gk_close_combat':
      case 'gk_pass_short':
      case 'gk_pass_medium':
      case 'gk_pass_long':
        return 'Вратарские действия';

      default:
        return 'Основные действия';
    }
  }
}