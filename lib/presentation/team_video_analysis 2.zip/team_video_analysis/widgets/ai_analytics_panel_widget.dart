import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_analytics_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_tracking_controller.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/utils/formatters.dart';
import 'package:sportoteka/presentation/team_video_analysis/widgets/standard_pitch_painter.dart';

class AiAnalyticsPanelWidget extends StatefulWidget {
  final AiTrackingController aiTracking;
  final bool showHeatmap;
  final String statusText;

  final bool isAiLoading;
  final double? aiProgress;

  final String myTeamName;
  final String opponentTeamName;
  final String myTeamTag;
  final Color myTeamColor;
  final Color opponentTeamColor;

  final VoidCallback onToggleAi;
  final ValueChanged<bool> onToggleHeatmap;
  final VoidCallback onBindTrack;
  final ValueChanged<int> onJumpToTime;
  final VoidCallback onExport;
  final ValueChanged<AiTtdSuggestion> onConfirmSuggestion;
  final VoidCallback? onConfirmTopAi;
  final VoidCallback? onOpenTeamSetup;
  final VoidCallback? onCoachPauseNote;
  final VoidCallback? onToggleCoachBoard;
  final bool coachBoardActive;

  const AiAnalyticsPanelWidget({
    super.key,
    required this.aiTracking,
    required this.showHeatmap,
    required this.statusText,
    this.isAiLoading = false,
    this.aiProgress,
    this.myTeamName = 'Моя команда',
    this.opponentTeamName = 'Соперник',
    this.myTeamTag = 'home',
    this.myTeamColor = const Color(0xFF00A750),
    this.opponentTeamColor = const Color(0xFF2563EB),
    required this.onToggleAi,
    required this.onToggleHeatmap,
    required this.onBindTrack,
    required this.onJumpToTime,
    required this.onExport,
    required this.onConfirmSuggestion,
    this.onConfirmTopAi,
    this.onOpenTeamSetup,
    this.onCoachPauseNote,
    this.onToggleCoachBoard,
    this.coachBoardActive = false,
  });

  @override
  State<AiAnalyticsPanelWidget> createState() => _AiAnalyticsPanelWidgetState();
}

class _AiPanelColors {
  static const background = Color(0xFFF5F7F6);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceSoft = Color(0xFFF8FAFC);
  static const line = Color(0xFFE5E7EB);
  static const text = Color(0xFF101828);
  static const textMuted = Color(0xFF667085);
  static const textSoft = Color(0xFF98A2B3);
  static const black = Color(0xFF121212);
  static const green = Color(0xFF00A750);
  static const greenDark = Color(0xFF08713E);
  static const red = Color(0xFFDC2626);
  static const blue = Color(0xFF2563EB);
  static const violet = Color(0xFF7C3AED);
  static const amber = Color(0xFFF59E0B);
  static const teal = Color(0xFF0F766E);
}

class _AiAnalyticsPanelWidgetState extends State<AiAnalyticsPanelWidget>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  bool _showTrails = true;
  bool _showPassNetwork = true;
  bool _showAveragePositions = true;
  bool _showOnlyMyTeam = false;

  bool get _isMyTeamHome => widget.myTeamTag == 'home';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 7, vsync: this);
    widget.aiTracking.addListener(_refresh);
  }

  @override
  void dispose() {
    widget.aiTracking.removeListener(_refresh);
    _tabController.dispose();
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final track = widget.aiTracking.lockedTrack ?? widget.aiTracking.selectedTrack;
    final live = _buildLiveStats(track);
    final summary = _buildMatchSummary(track, live);

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 920;
        final hasHeight = constraints.hasBoundedHeight && constraints.maxHeight.isFinite;

        final content = Container(
          color: _AiPanelColors.background,
          padding: const EdgeInsets.fromLTRB(10, 10, 10, 12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHero(summary, live, track),
              const SizedBox(height: 10),
              _buildActionDock(),
              if (widget.isAiLoading) ...[
                const SizedBox(height: 10),
                _buildAiLoadingBar(),
              ],
              const SizedBox(height: 10),
              _buildTabSelector(),
              const SizedBox(height: 10),
              Expanded(
                child: isWide
                    ? _buildWideBody(summary, live, track)
                    : _buildTabsBody(summary, live, track),
              ),
            ],
          ),
        );

        if (hasHeight) return content;

        return SizedBox(
          height: isWide ? 820 : 760,
          child: content,
        );
      },
    );
  }

  Widget _buildWideBody(_AiMatchSummary summary, _AiLiveStats live, PlayerTrack? track) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 11,
          child: _buildTabsBody(summary, live, track),
        ),
        const SizedBox(width: 10),
        SizedBox(
          width: 390,
          child: Column(
            children: [
              Expanded(child: _buildMapTab(track, live)),
              const SizedBox(height: 10),
              _buildAiNotesCompact(summary),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTabsBody(_AiMatchSummary summary, _AiLiveStats live, PlayerTrack? track) {
    return TabBarView(
      controller: _tabController,
      children: [
        _buildOverviewTab(summary, live, track),
        _buildEventsTab(summary),
        _buildTtdTab(summary),
        _buildMapTab(track, live),
        _buildPlayersTab(),
        _buildAiNotesTab(summary),
        _buildExportTab(summary),
      ],
    );
  }

  Widget _buildHero(_AiMatchSummary summary, _AiLiveStats live, PlayerTrack? track) {
    final selectedName = track?.boundPlayerName.trim().isNotEmpty == true
        ? track!.boundPlayerName.trim()
        : 'Все игроки';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: _AiPanelColors.surface,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 42,
                height: 42,
                decoration: BoxDecoration(
                  color: _AiPanelColors.black,
                  borderRadius: BorderRadius.circular(16),
                ),
                child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 22),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'AI Match Center',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w900,
                        color: _AiPanelColors.text,
                        height: 1.05,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      widget.statusText.isEmpty ? 'Авто-ТТД, трекинг, карта поля и тренерские заметки' : widget.statusText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        color: _AiPanelColors.textMuted,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              _statusDot(widget.aiTracking.isRunning || widget.isAiLoading),
            ],
          ),
          const SizedBox(height: 12),
          _responsiveWrap(
            minItemWidth: 118,
            spacing: 8,
            items: [
              _heroMetric('События', '${summary.eventsCount}', Icons.timeline_rounded, _AiPanelColors.blue),
              _heroMetric('AI ТТД', '${summary.suggestionsCount}', Icons.fact_check_outlined, _AiPanelColors.green),
              _heroMetric('Голы', '${summary.goals}', Icons.sports_soccer_rounded, _AiPanelColors.red),
              _heroMetric('Передачи', '${summary.passesTotal}', Icons.compare_arrows_rounded, _AiPanelColors.violet),
              _heroMetric('Heatmap', widget.showHeatmap ? 'ON' : 'OFF', Icons.local_fire_department_rounded, _AiPanelColors.amber),
              _heroMetric('Трек', selectedName, Icons.person_pin_circle_rounded, _AiPanelColors.teal),
            ],
          ),
          const SizedBox(height: 10),
          _teamIdentityStrip(summary),
        ],
      ),
    );
  }

  Widget _teamIdentityStrip(_AiMatchSummary summary) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _AiPanelColors.surfaceSoft,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Expanded(
            child: _teamMini(
              widget.myTeamName,
              widget.myTeamColor,
              '${summary.myPossessionPct.toStringAsFixed(0)}% владение',
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Text(
              '${summary.homeGoals}:${summary.awayGoals}',
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: _AiPanelColors.text,
              ),
            ),
          ),
          Expanded(
            child: _teamMini(
              widget.opponentTeamName,
              widget.opponentTeamColor,
              '${summary.opponentPossessionPct.toStringAsFixed(0)}% владение',
              alignRight: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _teamMini(String title, Color color, String sub, {bool alignRight = false}) {
    return Row(
      mainAxisAlignment: alignRight ? MainAxisAlignment.end : MainAxisAlignment.start,
      children: [
        if (!alignRight) _teamDot(color),
        if (!alignRight) const SizedBox(width: 8),
        Flexible(
          child: Column(
            crossAxisAlignment: alignRight ? CrossAxisAlignment.end : CrossAxisAlignment.start,
            children: [
              Text(
                title.isEmpty ? 'Команда' : title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: _AiPanelColors.text),
              ),
              const SizedBox(height: 2),
              Text(
                sub,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w700, color: _AiPanelColors.textMuted),
              ),
            ],
          ),
        ),
        if (alignRight) const SizedBox(width: 8),
        if (alignRight) _teamDot(color),
      ],
    );
  }

  Widget _teamDot(Color color) {
    return Container(
      width: 16,
      height: 16,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
        boxShadow: [BoxShadow(color: color.withOpacity(0.30), blurRadius: 8)],
      ),
    );
  }

  Widget _statusDot(bool active) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: active ? _AiPanelColors.green.withOpacity(0.10) : _AiPanelColors.amber.withOpacity(0.12),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: active ? _AiPanelColors.green : _AiPanelColors.amber,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 6),
          Text(
            active ? 'AI LIVE' : 'READY',
            style: TextStyle(
              fontSize: 10.5,
              fontWeight: FontWeight.w900,
              color: active ? _AiPanelColors.greenDark : _AiPanelColors.amber,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActionDock() {
    final controls = <Widget>[
      _actionPill(
        icon: widget.isAiLoading ? Icons.hourglass_top_rounded : Icons.auto_awesome_rounded,
        label: widget.isAiLoading
            ? (widget.aiProgress != null ? 'AI ${(widget.aiProgress! * 100).round()}%' : 'AI...')
            : 'Запустить AI',
        color: _AiPanelColors.black,
        onTap: widget.isAiLoading ? null : widget.onToggleAi,
        filled: true,
      ),
      if (widget.onOpenTeamSetup != null)
        _actionPill(
          icon: Icons.palette_outlined,
          label: 'Цвета команд',
          color: _AiPanelColors.teal,
          onTap: widget.onOpenTeamSetup!,
        ),
      _actionPill(
        icon: widget.showHeatmap ? Icons.local_fire_department_rounded : Icons.heat_pump_rounded,
        label: widget.showHeatmap ? 'Heatmap ON' : 'Heatmap OFF',
        color: _AiPanelColors.red,
        onTap: () => widget.onToggleHeatmap(!widget.showHeatmap),
      ),
      _actionPill(
        icon: Icons.link_rounded,
        label: 'Привязать игрока',
        color: _AiPanelColors.blue,
        onTap: widget.onBindTrack,
      ),
      if (widget.onCoachPauseNote != null)
        _actionPill(
          icon: Icons.pause_circle_outline_rounded,
          label: 'Пауза + заметка',
          color: _AiPanelColors.amber,
          onTap: widget.onCoachPauseNote!,
        ),
      if (widget.onToggleCoachBoard != null)
        _actionPill(
          icon: widget.coachBoardActive ? Icons.draw_rounded : Icons.edit_note_rounded,
          label: widget.coachBoardActive ? 'Чертёж ON' : 'Чертёж поля',
          color: _AiPanelColors.green,
          onTap: widget.onToggleCoachBoard!,
        ),
      if (widget.onConfirmTopAi != null)
        _actionPill(
          icon: Icons.done_all_rounded,
          label: 'Принять >75%',
          color: _AiPanelColors.green,
          onTap: widget.onConfirmTopAi!,
        ),
      _actionPill(
        icon: Icons.ios_share_rounded,
        label: 'Экспорт',
        color: _AiPanelColors.violet,
        onTap: widget.onExport,
      ),
    ];

    return SizedBox(
      height: 42,
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            for (int i = 0; i < controls.length; i++) ...[
              controls[i],
              if (i != controls.length - 1) const SizedBox(width: 8),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildAiLoadingBar() {
    final progress = widget.aiProgress;
    final percent = progress == null ? null : (progress.clamp(0.0, 1.0) * 100).round();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: _AiPanelColors.surface,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const SizedBox(
                width: 16,
                height: 16,
                child: CircularProgressIndicator(strokeWidth: 2.2, color: _AiPanelColors.green),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  widget.statusText.isEmpty ? 'AI анализ запускается...' : widget.statusText,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: _AiPanelColors.text),
                ),
              ),
              if (percent != null)
                Text('$percent%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: _AiPanelColors.green)),
            ],
          ),
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              minHeight: 7,
              value: progress,
              backgroundColor: _AiPanelColors.surfaceSoft,
              valueColor: const AlwaysStoppedAnimation<Color>(_AiPanelColors.green),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTabSelector() {
    return Container(
      height: 42,
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: _AiPanelColors.surface,
        borderRadius: BorderRadius.circular(16),
      ),
      child: TabBar(
        controller: _tabController,
        isScrollable: true,
        dividerColor: Colors.transparent,
        indicatorSize: TabBarIndicatorSize.tab,
        labelColor: Colors.white,
        unselectedLabelColor: _AiPanelColors.textMuted,
        labelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900),
        unselectedLabelStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
        indicator: BoxDecoration(color: _AiPanelColors.black, borderRadius: BorderRadius.circular(13)),
        tabs: const [
          Tab(text: 'Обзор'),
          Tab(text: 'События'),
          Tab(text: 'ТТД'),
          Tab(text: 'Карта'),
          Tab(text: 'Игроки'),
          Tab(text: 'AI заметки'),
          Tab(text: 'Экспорт'),
        ],
      ),
    );
  }

  Widget _buildOverviewTab(_AiMatchSummary summary, _AiLiveStats live, PlayerTrack? track) {
    final myPasses = _isMyTeamHome ? summary.homePasses : summary.awayPasses;
    final oppPasses = _isMyTeamHome ? summary.awayPasses : summary.homePasses;
    final myShots = _isMyTeamHome ? summary.homeShots : summary.awayShots;
    final oppShots = _isMyTeamHome ? summary.awayShots : summary.homeShots;
    final myInterceptions = _isMyTeamHome ? summary.homeInterceptions : summary.awayInterceptions;
    final oppInterceptions = _isMyTeamHome ? summary.awayInterceptions : summary.homeInterceptions;

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          _responsiveWrap(
            minItemWidth: 156,
            spacing: 8,
            items: [
              _metricCard('Голы', '${summary.goals}', 'AI events', Icons.sports_soccer_rounded, _AiPanelColors.red),
              _metricCard('Голевые', '${summary.assists}', 'Передачи', Icons.assistant_direction_rounded, _AiPanelColors.violet),
              _metricCard('Карточки', '${summary.cards}', 'Жёлтые/красные', Icons.style_rounded, _AiPanelColors.amber),
              _metricCard('Уверенность', '${summary.avgSuggestionConfidence.toStringAsFixed(0)}%', 'Средняя', Icons.psychology_alt_outlined, _AiPanelColors.green),
            ],
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Сводка матча',
            icon: Icons.analytics_outlined,
            color: _AiPanelColors.green,
            child: Column(
              children: [
                _vsBar('Владение', summary.myPossessionPct, summary.opponentPossessionPct),
                const SizedBox(height: 10),
                _infoRow('Передачи ${widget.myTeamName}', '$myPasses'),
                _infoRow('Передачи ${widget.opponentTeamName}', '$oppPasses'),
                _infoRow('Удары ${widget.myTeamName}', '$myShots'),
                _infoRow('Удары ${widget.opponentTeamName}', '$oppShots'),
                _infoRow('Перехваты ${widget.myTeamName}', '$myInterceptions'),
                _infoRow('Перехваты ${widget.opponentTeamName}', '$oppInterceptions'),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Трекинг выбранного игрока',
            icon: Icons.directions_run_rounded,
            color: _AiPanelColors.blue,
            child: Column(
              children: [
                _infoRow('Текущая скорость', '${live.currentSpeed.toStringAsFixed(1)} км/ч'),
                _infoRow('Средняя скорость', '${live.avgSpeed.toStringAsFixed(1)} км/ч'),
                _infoRow('Макс. скорость', '${live.maxSpeed.toStringAsFixed(1)} км/ч'),
                _infoRow('Дистанция', '${live.totalDistance.toStringAsFixed(1)} м'),
                _infoRow('Рывки', '${live.sprints}'),
                _infoRow('Точек трека', '${track?.points.length ?? widget.aiTracking.tracks.fold<int>(0, (s, t) => s + t.points.length)}'),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Что уже автоматизировано',
            icon: Icons.bolt_rounded,
            color: _AiPanelColors.amber,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _hintLine('1. Сначала задаём цвет формы моей команды и соперника.'),
                _hintLine('2. AI выделяет игроков, мяч, треки и события, затем формирует ТТД.'),
                _hintLine('3. Heatmap и точки строятся на стандартном поле, а не только поверх видео.'),
                _hintLine('4. Тренер может поставить паузу, оставить заметку и нарисовать схему.'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventsTab(_AiMatchSummary summary) {
    final events = widget.aiTracking.autoEvents;

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          _surfaceBlock(
            title: 'AI события матча',
            icon: Icons.timeline_rounded,
            color: _AiPanelColors.blue,
            child: events.isEmpty
                ? _emptyText('Пока нет событий. Запусти AI после выбора цветов команд.')
                : Column(children: events.map(_eventTile).toList()),
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Быстрые фильтры',
            icon: Icons.filter_alt_outlined,
            color: _AiPanelColors.violet,
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                _presetChip('Голы: ${summary.goals}', _AiPanelColors.red),
                _presetChip('Передачи: ${summary.passesTotal}', _AiPanelColors.blue),
                _presetChip('Удары: ${summary.shotsTotal}', _AiPanelColors.amber),
                _presetChip('Перехваты: ${summary.homeInterceptions + summary.awayInterceptions}', _AiPanelColors.green),
                _presetChip('Карточки: ${summary.cards}', _AiPanelColors.violet),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTtdTab(_AiMatchSummary summary) {
    final suggestions = widget.aiTracking.ttdSuggestions;
    final main = suggestions.where((e) => e.section == 'Основные действия').toList();
    final passes = suggestions.where((e) => e.section == 'Передачи').toList();
    final gk = suggestions.where((e) => e.section == 'Вратарские действия').toList();

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          _responsiveWrap(
            minItemWidth: 156,
            spacing: 8,
            items: [
              _metricCard('Всего ТТД', '${summary.suggestionsCount}', 'AI подсказки', Icons.fact_check_outlined, _AiPanelColors.green),
              _metricCard('Успешные', '${summary.positiveSuggestions}', 'Плюс', Icons.check_circle_outline_rounded, _AiPanelColors.green),
              _metricCard('Неуспешные', '${summary.negativeSuggestions}', 'Минус', Icons.cancel_outlined, _AiPanelColors.red),
              _metricCard('Качество', '${summary.avgSuggestionConfidence.toStringAsFixed(0)}%', 'Confidence', Icons.verified_rounded, _AiPanelColors.violet),
            ],
          ),
          const SizedBox(height: 8),
          _ttdSection(
            title: 'Основные действия',
            color: _AiPanelColors.blue,
            items: main,
            presets: const ['Гол', 'Удар', 'Финт/дриблинг', 'Отбор', 'Перехват', 'Подбор', 'Игра головой', 'Карточка'],
          ),
          const SizedBox(height: 8),
          _ttdSection(
            title: 'Передачи',
            color: _AiPanelColors.violet,
            items: passes,
            presets: const ['Голевая', 'Вперёд К', 'Вперёд С', 'Вперёд Д', 'Поперёк К', 'Назад К', 'Ключевая'],
          ),
          const SizedBox(height: 8),
          _ttdSection(
            title: 'Вратарские действия',
            color: _AiPanelColors.red,
            items: gk,
            presets: const ['Сейв', 'Выход', 'Ввод рукой', 'Ближний бой', 'Перехват', 'Пас короткий', 'Пас длинный'],
          ),
        ],
      ),
    );
  }

  Widget _buildMapTab(PlayerTrack? track, _AiLiveStats live) {
    final tracks = _visibleTracks();
    final heatmapPoints = track?.points ?? tracks.expand((t) => t.points).toList();

    return Column(
      children: [
        Expanded(
          child: Container(
            width: double.infinity,
            decoration: BoxDecoration(
              color: _AiPanelColors.surface,
              borderRadius: BorderRadius.circular(22),
            ),
            padding: const EdgeInsets.all(10),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(18),
              child: CustomPaint(
                painter: StandardPitchPainter(
                  tracks: tracks,
                  heatmapPoints: heatmapPoints,
                  averagePositions: widget.aiTracking.aiAveragePositions.where((e) => !_showOnlyMyTeam || e.team == widget.myTeamTag).toList(),
                  passNetwork: widget.aiTracking.aiPassNetwork.where((e) => !_showOnlyMyTeam || e.team == widget.myTeamTag).toList(),
                  selectedTrackId: track?.id ?? widget.aiTracking.selectedTrackId,
                  myTeamTag: widget.myTeamTag,
                  showHeatmap: widget.showHeatmap,
                  showTrails: _showTrails,
                  showAveragePositions: _showAveragePositions,
                  showPassNetwork: _showPassNetwork,
                  myTeamColor: widget.myTeamColor,
                  opponentTeamColor: widget.opponentTeamColor,
                ),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        ),
        const SizedBox(height: 8),
        _surfaceBlock(
          title: 'Слои карты',
          icon: Icons.layers_rounded,
          color: _AiPanelColors.green,
          child: Column(
            children: [
              _switchRow('Heatmap', widget.showHeatmap, widget.onToggleHeatmap),
              _switchRow('Точки и треки', _showTrails, (v) => setState(() => _showTrails = v)),
              _switchRow('Сеть передач', _showPassNetwork, (v) => setState(() => _showPassNetwork = v)),
              _switchRow('Средние позиции', _showAveragePositions, (v) => setState(() => _showAveragePositions = v)),
              _switchRow('Только моя команда', _showOnlyMyTeam, (v) => setState(() => _showOnlyMyTeam = v)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPlayersTab() {
    final stats = widget.aiTracking.aiPlayerStats
        .where((e) => !_showOnlyMyTeam || e.team == widget.myTeamTag)
        .toList()
      ..sort((a, b) => b.rating.compareTo(a.rating));

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: _surfaceBlock(
        title: 'Игроки и рейтинг',
        icon: Icons.person_search_rounded,
        color: _AiPanelColors.violet,
        child: stats.isEmpty
            ? _emptyText('Пока нет статистики игроков. После AI здесь будут касания, передачи, удары, перехваты, дистанция и скорость.')
            : Column(children: stats.map(_playerStatTile).toList()),
      ),
    );
  }

  Widget _buildAiNotesTab(_AiMatchSummary summary) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          _buildAiNotesCompact(summary),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'DeepSeek / LLM блок — подключим следующим шагом',
            icon: Icons.smart_toy_outlined,
            color: _AiPanelColors.violet,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _hintLine('AI будет получать JSON матча: события, ТТД, владение, карту, игроки и тренерские заметки.'),
                _hintLine('На выходе: слабые зоны, ключевые эпизоды, рекомендации по тренировкам и персональные выводы.'),
                _hintLine('Можно добавить шаблоны: «для тренера», «для игрока», «для руководителя клуба», «кратко в Telegram».')
              ],
            ),
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Идеи для ТОП версии',
            icon: Icons.workspace_premium_rounded,
            color: _AiPanelColors.amber,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _hintLine('Авто‑нарезка плейлистов: голы, удары, потери, прессинг, выход из обороны.'),
                _hintLine('Сравнение двух таймов: темп, владение, зона атак, просадки игрока.'),
                _hintLine('Индекс риска: игрок часто выпадает из кадра, потеря трека, перегрузка зоны.'),
                _hintLine('Экспорт: PDF/HTML/CSV + таблица ТТД по игрокам и эпизодам.'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAiNotesCompact(_AiMatchSummary summary) {
    final quality = summary.avgSuggestionConfidence;
    final qualityText = quality >= 75
        ? 'AI уверенно распознал события. Можно подтверждать ТТД пачкой.'
        : quality > 0
            ? 'Есть события со средней уверенностью — лучше проверить ключевые моменты.'
            : 'Запусти AI после настройки цветов команд.';

    return _surfaceBlock(
      title: 'Заметки от AI',
      icon: Icons.lightbulb_outline_rounded,
      color: _AiPanelColors.green,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _hintLine(qualityText),
          _hintLine('Найдено: ${summary.eventsCount} событий, ${summary.suggestionsCount} ТТД, ${summary.goals} голов, ${summary.cards} карточек.'),
          _hintLine('Карта: ${widget.showHeatmap ? 'тепловая карта включена' : 'тепловая карта выключена'}, треков: ${widget.aiTracking.tracks.length}.'),
          _hintLine('Перед экспортом желательно подтвердить спорные AI‑подсказки вручную.'),
        ],
      ),
    );
  }

  Widget _buildExportTab(_AiMatchSummary summary) {
    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 12),
      child: Column(
        children: [
          _surfaceBlock(
            title: 'Красивый экспорт',
            icon: Icons.ios_share_rounded,
            color: _AiPanelColors.violet,
            child: Column(
              children: [
                _exportItem('HTML отчёт матча', 'Красивый отчёт с таблицами, событиями и AI‑заметками', Icons.article_outlined, widget.onExport),
                _exportItem('CSV таблица ТТД', 'Для Excel: игрок, команда, действие, время, успех, confidence', Icons.table_chart_outlined, widget.onExport),
                _exportItem('JSON AI анализа', 'Полный технический пакет для DeepSeek/аналитики', Icons.data_object_rounded, widget.onExport),
              ],
            ),
          ),
          const SizedBox(height: 8),
          _surfaceBlock(
            title: 'Выгружается в отчёт',
            icon: Icons.inventory_2_outlined,
            color: _AiPanelColors.blue,
            child: Column(
              children: [
                _infoRow('AI-события', '${summary.eventsCount}'),
                _infoRow('AI ТТД', '${summary.suggestionsCount}'),
                _infoRow('Голы', '${summary.goals}'),
                _infoRow('Голевые передачи', '${summary.assists}'),
                _infoRow('Карточки', '${summary.cards}'),
                _infoRow('Передачи всего', '${summary.passesTotal}'),
                _infoRow('Удары всего', '${summary.shotsTotal}'),
                _infoRow('Треки игроков', '${widget.aiTracking.tracks.length}'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ttdSection({
    required String title,
    required Color color,
    required List<AiTtdSuggestion> items,
    required List<String> presets,
  }) {
    return _surfaceBlock(
      title: title,
      icon: Icons.sports_soccer_rounded,
      color: color,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (items.isEmpty)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: _emptyText('AI пока не предложил действий в этом разделе.'),
            ),
          ...items.map((e) => _ttdSuggestionTile(e, color)),
          const SizedBox(height: 8),
          Wrap(spacing: 8, runSpacing: 8, children: presets.map((e) => _presetChip(e, color)).toList()),
        ],
      ),
    );
  }

  Widget _ttdSuggestionTile(AiTtdSuggestion item, Color accent) {
    final timeText = Formatters.formatDuration(Duration(milliseconds: item.timeMs));
    final teamName = _teamLabel(item.meta?['team']?.toString());
    final player = _extractPlayerName(item.meta);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: _AiPanelColors.surfaceSoft, borderRadius: BorderRadius.circular(14)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(item.title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: _AiPanelColors.text)),
              ),
              _pill(timeText, _AiPanelColors.black),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _pill(item.success ? 'Успешно' : 'Неуспешно', item.success ? _AiPanelColors.green : _AiPanelColors.red),
              _pill('Уверенность ${(item.confidence * 100).round()}%', accent),
              if (teamName.isNotEmpty) _pill(teamName, teamName == widget.myTeamName ? widget.myTeamColor : widget.opponentTeamColor),
              if (player.isNotEmpty) _pill(player, _AiPanelColors.teal),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(child: _miniButton('Перейти', Icons.play_arrow_rounded, _AiPanelColors.black, () => widget.onJumpToTime(item.timeMs))),
              const SizedBox(width: 8),
              Expanded(child: _miniButton('Подтвердить', Icons.check_circle_outline_rounded, _AiPanelColors.green, () => widget.onConfirmSuggestion(item))),
            ],
          ),
        ],
      ),
    );
  }

  Widget _eventTile(AiDetectedEvent item) {
    final timeText = Formatters.formatDuration(Duration(milliseconds: item.timeMs));
    final teamName = _teamLabel(item.meta?['team']?.toString());

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: _AiPanelColors.surfaceSoft, borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: item.color.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
            child: Icon(item.icon, color: item.color, size: 20),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: _AiPanelColors.text)),
                const SizedBox(height: 2),
                Text(
                  [item.subtitle, teamName].where((e) => e.trim().isNotEmpty).join(' · '),
                  style: const TextStyle(fontSize: 12, color: _AiPanelColors.textMuted, fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text('Уверенность ${(item.confidence * 100).round()}%', style: TextStyle(fontSize: 11, color: item.color, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
          Column(
            children: [
              Text(timeText, style: const TextStyle(fontSize: 11, color: _AiPanelColors.textMuted, fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              IconButton(
                onPressed: () => widget.onJumpToTime(item.timeMs),
                icon: const Icon(Icons.play_circle_outline_rounded),
                color: _AiPanelColors.black,
                tooltip: 'Перейти к моменту',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _playerStatTile(AiPlayerStat e) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: _AiPanelColors.surfaceSoft, borderRadius: BorderRadius.circular(14)),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(color: e.team == widget.myTeamTag ? widget.myTeamColor : widget.opponentTeamColor, shape: BoxShape.circle),
              ),
              const SizedBox(width: 8),
              Expanded(child: Text(e.playerName, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: _AiPanelColors.text))),
              _pill('Рейтинг ${e.rating.toStringAsFixed(1)}', _AiPanelColors.green),
            ],
          ),
          const SizedBox(height: 8),
          _responsiveWrap(
            minItemWidth: 102,
            spacing: 8,
            items: [
              _miniStat('Касания', '${e.touches}'),
              _miniStat('Передачи', '${e.passes}'),
              _miniStat('Усп.', '${e.successfulPasses}'),
              _miniStat('Удары', '${e.shots}'),
              _miniStat('Перехваты', '${e.interceptions}'),
              _miniStat('Дист.', '${e.distanceM.toStringAsFixed(1)}'),
              _miniStat('Макс км/ч', e.maxSpeedKmh.toStringAsFixed(1)),
            ],
          ),
        ],
      ),
    );
  }

  Widget _surfaceBlock({required String title, required IconData icon, required Color color, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      decoration: BoxDecoration(
        color: _AiPanelColors.surface,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 18),
              const SizedBox(width: 8),
              Expanded(child: Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: _AiPanelColors.text))),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }

  Widget _metricCard(String title, String value, String subtitle, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: _AiPanelColors.surface, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(height: 8),
          Text(title, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: color)),
          const SizedBox(height: 4),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: _AiPanelColors.text)),
          const SizedBox(height: 2),
          Text(subtitle, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _AiPanelColors.textMuted)),
        ],
      ),
    );
  }

  Widget _heroMetric(String title, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(14)),
      child: Row(
        children: [
          Icon(icon, color: color, size: 17),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800, color: color)),
                const SizedBox(height: 2),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, fontWeight: FontWeight.w900, color: _AiPanelColors.text)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String title, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(color: _AiPanelColors.surface, borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Text(title, style: const TextStyle(fontSize: 10, color: _AiPanelColors.textMuted, fontWeight: FontWeight.w800), textAlign: TextAlign.center),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 12, color: _AiPanelColors.text, fontWeight: FontWeight.w900), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _actionPill({required IconData icon, required String label, required Color color, required VoidCallback? onTap, bool filled = false}) {
    final disabled = onTap == null;
    return Opacity(
      opacity: disabled ? 0.55 : 1,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            color: filled ? _AiPanelColors.black : color.withOpacity(0.09),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: filled ? Colors.white : color),
              const SizedBox(width: 6),
              Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: filled ? Colors.white : color)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniButton(String label, IconData icon, Color color, VoidCallback onTap) {
    final isBlack = color == _AiPanelColors.black;
    return SizedBox(
      height: 38,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 15),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: isBlack ? _AiPanelColors.black : color.withOpacity(0.10),
          foregroundColor: isBlack ? Colors.white : color,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900),
        ),
      ),
    );
  }

  Widget _presetChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(999)),
      child: Text(label, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: color)),
    );
  }

  Widget _pill(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(color: color.withOpacity(0.10), borderRadius: BorderRadius.circular(999)),
      child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontSize: 10, fontWeight: FontWeight.w900, color: color)),
    );
  }

  Widget _switchRow(String title, bool value, ValueChanged<bool> onChanged) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(color: _AiPanelColors.surfaceSoft, borderRadius: BorderRadius.circular(12)),
      child: Row(
        children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: _AiPanelColors.text))),
          Switch.adaptive(value: value, activeColor: _AiPanelColors.green, onChanged: onChanged),
        ],
      ),
    );
  }

  Widget _exportItem(String title, String subtitle, IconData icon, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
        tileColor: _AiPanelColors.surfaceSoft,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        leading: Container(
          width: 36,
          height: 36,
          decoration: BoxDecoration(color: _AiPanelColors.green, borderRadius: BorderRadius.circular(11)),
          child: Icon(icon, color: Colors.white, size: 19),
        ),
        title: Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900, color: _AiPanelColors.text)),
        subtitle: Text(subtitle, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _AiPanelColors.textMuted)),
        trailing: const Icon(Icons.chevron_right_rounded, color: _AiPanelColors.textMuted),
      ),
    );
  }

  Widget _emptyText(String text) {
    return Text(text, style: const TextStyle(color: _AiPanelColors.textMuted, fontWeight: FontWeight.w700, fontSize: 12));
  }

  Widget _hintLine(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 5),
            width: 6,
            height: 6,
            decoration: const BoxDecoration(color: _AiPanelColors.green, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(text, style: const TextStyle(fontSize: 12, height: 1.35, color: _AiPanelColors.textMuted, fontWeight: FontWeight.w700))),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(child: Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: _AiPanelColors.textMuted))),
          const SizedBox(width: 8),
          Flexible(child: Text(value, textAlign: TextAlign.end, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: _AiPanelColors.text))),
        ],
      ),
    );
  }

  Widget _vsBar(String title, double leftPct, double rightPct) {
    final total = math.max(leftPct + rightPct, 1.0);
    final left = (leftPct / total).clamp(0.0, 1.0);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text('${leftPct.toStringAsFixed(0)}%', style: TextStyle(color: widget.myTeamColor, fontWeight: FontWeight.w900))),
            Text(title, style: const TextStyle(color: _AiPanelColors.textMuted, fontWeight: FontWeight.w800, fontSize: 12)),
            Expanded(child: Text('${rightPct.toStringAsFixed(0)}%', textAlign: TextAlign.end, style: TextStyle(color: widget.opponentTeamColor, fontWeight: FontWeight.w900))),
          ],
        ),
        const SizedBox(height: 6),
        ClipRRect(
          borderRadius: BorderRadius.circular(999),
          child: SizedBox(
            height: 9,
            child: Row(
              children: [
                Expanded(flex: (left * 1000).round().clamp(1, 999).toInt(), child: Container(color: widget.myTeamColor)),
                Expanded(flex: ((1 - left) * 1000).round().clamp(1, 999).toInt(), child: Container(color: widget.opponentTeamColor)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _responsiveWrap({required double minItemWidth, required double spacing, required List<Widget> items}) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth.isFinite ? constraints.maxWidth : 360.0;
        final count = math.max(1, (width / minItemWidth).floor());
        final itemWidth = (width - spacing * (count - 1)) / count;
        return Wrap(
          spacing: spacing,
          runSpacing: spacing,
          children: items.map((child) => SizedBox(width: itemWidth, child: child)).toList(),
        );
      },
    );
  }

  List<PlayerTrack> _visibleTracks() {
    if (!_showOnlyMyTeam) return widget.aiTracking.tracks;
    return widget.aiTracking.tracks.where((t) => t.teamTag == widget.myTeamTag).toList();
  }

  _AiLiveStats _buildLiveStats(PlayerTrack? track) {
    if (track == null || track.points.isEmpty) return const _AiLiveStats.empty();
    final points = track.points;
    double maxSpeed = 0;
    double sumSpeed = 0;
    double totalDistance = 0;
    int sprints = 0;
    bool sprintOpen = false;

    for (int i = 0; i < points.length; i++) {
      final p = points[i];
      maxSpeed = math.max(maxSpeed, p.speed);
      sumSpeed += p.speed;
      if (p.speed >= 24.0 && !sprintOpen) {
        sprintOpen = true;
        sprints++;
      } else if (p.speed < 20.0) {
        sprintOpen = false;
      }
      if (i > 0) {
        final prev = points[i - 1].position;
        final dx = p.position.dx - prev.dx;
        final dy = p.position.dy - prev.dy;
        totalDistance += math.sqrt(dx * dx + dy * dy) * 0.12;
      }
    }

    final avgSpeed = points.isEmpty ? 0.0 : sumSpeed / points.length;
    final last = points.last;
    return _AiLiveStats(
      currentSpeed: last.speed,
      avgSpeed: avgSpeed,
      maxSpeed: maxSpeed,
      totalDistance: totalDistance,
      sprints: sprints,
      currentAcceleration: math.sqrt(last.ax * last.ax + last.ay * last.ay),
    );
  }

  _AiMatchSummary _buildMatchSummary(PlayerTrack? track, _AiLiveStats live) {
    final events = widget.aiTracking.autoEvents;
    final suggestions = widget.aiTracking.ttdSuggestions;

    final rawStats = widget.aiTracking.aiMatchStats ??
        (widget.aiTracking.aiSummary?['match_stats'] is Map
            ? Map<String, dynamic>.from(widget.aiTracking.aiSummary!['match_stats'] as Map)
            : const <String, dynamic>{});

    final stats = rawStats['match_stats'] is Map ? Map<String, dynamic>.from(rawStats['match_stats'] as Map) : rawStats;
    final overview = stats['overview'] is Map ? Map<String, dynamic>.from(stats['overview'] as Map) : const <String, dynamic>{};
    final home = stats['home'] is Map ? Map<String, dynamic>.from(stats['home'] as Map) : const <String, dynamic>{};
    final away = stats['away'] is Map ? Map<String, dynamic>.from(stats['away'] as Map) : const <String, dynamic>{};

    int asInt(dynamic value) {
      if (value is int) return value;
      if (value is num) return value.toInt();
      return int.tryParse(value?.toString() ?? '') ?? 0;
    }

    double asDouble(dynamic value) {
      if (value is double) return value;
      if (value is num) return value.toDouble();
      return double.tryParse(value?.toString() ?? '') ?? 0.0;
    }

    bool matchesType(String raw, List<String> keys) {
      final value = raw.toLowerCase();
      return keys.any((k) => value.contains(k));
    }

    final positive = suggestions.where((e) => e.success).length;
    final negative = suggestions.where((e) => !e.success).length;
    final avgConfidence = suggestions.isEmpty
        ? 0.0
        : suggestions.map((e) => e.confidence).reduce((a, b) => a + b) / suggestions.length * 100;

    final goalEvents = events.where((e) => matchesType('${e.type} ${e.title}', ['goal', 'гол'])).length +
        suggestions.where((e) => matchesType('${e.code} ${e.title}', ['goal', 'гол'])).length;
    final assistEvents = suggestions.where((e) => matchesType('${e.code} ${e.title}', ['assist', 'голев'])).length;
    final cardEvents = events.where((e) => matchesType('${e.type} ${e.title}', ['card', 'карточ'])).length +
        suggestions.where((e) => matchesType('${e.code} ${e.title}', ['card', 'карточ'])).length;

    final possessionHome = asDouble(overview['possession_home_pct'] ?? home['possession_percent']);
    final possessionAway = asDouble(overview['possession_away_pct'] ?? away['possession_percent']);

    final homeGoals = asInt(home['goals']);
    final awayGoals = asInt(away['goals']);
    final computedHomeGoals = _eventsByTeam(events, widget.myTeamTag == 'home' ? 'home' : 'away', ['goal', 'гол']);
    final computedAwayGoals = _eventsByTeam(events, widget.myTeamTag == 'home' ? 'away' : 'home', ['goal', 'гол']);

    return _AiMatchSummary(
      eventsCount: events.length,
      suggestionsCount: suggestions.length,
      positiveSuggestions: positive,
      negativeSuggestions: negative,
      avgSuggestionConfidence: avgConfidence,
      currentSpeed: live.currentSpeed,
      distance: live.totalDistance,
      sprints: live.sprints,
      pointsCount: track?.points.length ?? widget.aiTracking.tracks.fold<int>(0, (s, t) => s + t.points.length),
      possessionHomePct: possessionHome,
      possessionAwayPct: possessionAway,
      myPossessionPct: _isMyTeamHome ? possessionHome : possessionAway,
      opponentPossessionPct: _isMyTeamHome ? possessionAway : possessionHome,
      passesTotal: asInt(overview['passes_total']) + suggestions.where((e) => e.section == 'Передачи').length,
      shotsTotal: asInt(overview['shots_total']) + suggestions.where((e) => matchesType('${e.code} ${e.title}', ['shot', 'удар'])).length,
      dribblesTotal: asInt(overview['dribbles_total']),
      homePasses: asInt(home['passes'] ?? home['passes_total']),
      awayPasses: asInt(away['passes'] ?? away['passes_total']),
      homeShots: asInt(home['shots']),
      awayShots: asInt(away['shots']),
      homeInterceptions: asInt(home['interceptions']),
      awayInterceptions: asInt(away['interceptions']),
      homeTurnoversWon: asInt(home['turnovers_won'] ?? home['possession_won']),
      awayTurnoversWon: asInt(away['turnovers_won'] ?? away['possession_won']),
      homeTurnoversLost: asInt(home['turnovers_lost']),
      awayTurnoversLost: asInt(away['turnovers_lost']),
      goals: goalEvents + math.max(homeGoals + awayGoals, 0),
      assists: assistEvents,
      cards: cardEvents,
      homeGoals: homeGoals > 0 ? homeGoals : computedHomeGoals,
      awayGoals: awayGoals > 0 ? awayGoals : computedAwayGoals,
    );
  }

  int _eventsByTeam(List<AiDetectedEvent> events, String team, List<String> keys) {
    return events.where((e) {
      final rawTeam = (e.meta?['team'] ?? '').toString();
      final rawType = '${e.type} ${e.title}'.toLowerCase();
      return rawTeam == team && keys.any((k) => rawType.contains(k));
    }).length;
  }

  String _teamLabel(String? raw) {
    if (raw == null || raw.isEmpty) return '';
    if (raw == widget.myTeamTag) return widget.myTeamName;
    return widget.opponentTeamName;
  }

  String _extractPlayerName(Map<String, dynamic>? meta) {
    final participants = meta?['participants'];
    if (participants is List && participants.isNotEmpty) {
      final first = participants.first;
      if (first is Map && (first['name'] ?? '').toString().trim().isNotEmpty) {
        return first['name'].toString();
      }
    }
    return '';
  }
}

class _AiLiveStats {
  final double currentSpeed;
  final double avgSpeed;
  final double maxSpeed;
  final double totalDistance;
  final int sprints;
  final double currentAcceleration;

  const _AiLiveStats({
    required this.currentSpeed,
    required this.avgSpeed,
    required this.maxSpeed,
    required this.totalDistance,
    required this.sprints,
    required this.currentAcceleration,
  });

  const _AiLiveStats.empty()
      : currentSpeed = 0,
        avgSpeed = 0,
        maxSpeed = 0,
        totalDistance = 0,
        sprints = 0,
        currentAcceleration = 0;
}

class _AiMatchSummary {
  final int eventsCount;
  final int suggestionsCount;
  final int positiveSuggestions;
  final int negativeSuggestions;
  final double avgSuggestionConfidence;
  final double currentSpeed;
  final double distance;
  final int sprints;
  final int pointsCount;

  final double possessionHomePct;
  final double possessionAwayPct;
  final double myPossessionPct;
  final double opponentPossessionPct;

  final int passesTotal;
  final int shotsTotal;
  final int dribblesTotal;
  final int homePasses;
  final int awayPasses;
  final int homeShots;
  final int awayShots;
  final int homeInterceptions;
  final int awayInterceptions;
  final int homeTurnoversWon;
  final int awayTurnoversWon;
  final int homeTurnoversLost;
  final int awayTurnoversLost;

  final int goals;
  final int assists;
  final int cards;
  final int homeGoals;
  final int awayGoals;

  const _AiMatchSummary({
    required this.eventsCount,
    required this.suggestionsCount,
    required this.positiveSuggestions,
    required this.negativeSuggestions,
    required this.avgSuggestionConfidence,
    required this.currentSpeed,
    required this.distance,
    required this.sprints,
    required this.pointsCount,
    required this.possessionHomePct,
    required this.possessionAwayPct,
    required this.myPossessionPct,
    required this.opponentPossessionPct,
    required this.passesTotal,
    required this.shotsTotal,
    required this.dribblesTotal,
    required this.homePasses,
    required this.awayPasses,
    required this.homeShots,
    required this.awayShots,
    required this.homeInterceptions,
    required this.awayInterceptions,
    required this.homeTurnoversWon,
    required this.awayTurnoversWon,
    required this.homeTurnoversLost,
    required this.awayTurnoversLost,
    required this.goals,
    required this.assists,
    required this.cards,
    required this.homeGoals,
    required this.awayGoals,
  });
}
