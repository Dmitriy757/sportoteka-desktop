import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_analytics_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class StandardPitchPainter extends CustomPainter {
  final List<PlayerTrack> tracks;
  final List<TrackPoint> heatmapPoints;
  final List<AiAveragePosition> averagePositions;
  final List<AiPassNetworkEdge> passNetwork;
  final String? selectedTrackId;
  final String myTeamTag;
  final bool showHeatmap;
  final bool showTrails;
  final bool showAveragePositions;
  final bool showPassNetwork;
  final Color myTeamColor;
  final Color opponentTeamColor;

  const StandardPitchPainter({
    required this.tracks,
    required this.heatmapPoints,
    required this.averagePositions,
    required this.passNetwork,
    required this.myTeamTag,
    this.selectedTrackId,
    this.showHeatmap = true,
    this.showTrails = true,
    this.showAveragePositions = true,
    this.showPassNetwork = true,
    this.myTeamColor = const Color(0xFF00A750),
    this.opponentTeamColor = const Color(0xFF2563EB),
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final pitch = _pitchRect(size);
    _drawBackground(canvas, rect, pitch);
    _drawFieldLines(canvas, pitch);

    final bounds = _sourceBounds();

    if (showHeatmap) {
      _drawHeatmap(canvas, pitch, bounds);
    }

    if (showPassNetwork) {
      _drawPassNetwork(canvas, pitch);
    }

    if (showTrails) {
      _drawTrails(canvas, pitch, bounds);
    }

    if (showAveragePositions) {
      _drawAveragePositions(canvas, pitch);
    }

    _drawCurrentDots(canvas, pitch, bounds);
    _drawLegend(canvas, pitch);
  }

  Rect _pitchRect(Size size) {
    final padding = math.max(10.0, math.min(size.width, size.height) * 0.04);
    return Rect.fromLTWH(
      padding,
      padding,
      math.max(0, size.width - padding * 2),
      math.max(0, size.height - padding * 2),
    );
  }

  void _drawBackground(Canvas canvas, Rect rect, Rect pitch) {
    final shadow = Paint()
      ..color = Colors.black.withOpacity(0.10)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16);
    canvas.drawRRect(
      RRect.fromRectAndRadius(pitch.translate(0, 3), const Radius.circular(24)),
      shadow,
    );

    final bg = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF0B4F33), Color(0xFF08713E)],
      ).createShader(pitch);

    canvas.drawRRect(
      RRect.fromRectAndRadius(pitch, const Radius.circular(22)),
      bg,
    );

    final stripe = Paint()..color = Colors.white.withOpacity(0.035);
    final stripeWidth = pitch.width / 8;
    for (int i = 0; i < 8; i++) {
      if (i.isEven) {
        canvas.drawRect(
          Rect.fromLTWH(pitch.left + i * stripeWidth, pitch.top, stripeWidth, pitch.height),
          stripe,
        );
      }
    }
  }

  void _drawFieldLines(Canvas canvas, Rect p) {
    final line = Paint()
      ..color = Colors.white.withOpacity(0.82)
      ..strokeWidth = 1.4
      ..style = PaintingStyle.stroke;

    final thin = Paint()
      ..color = Colors.white.withOpacity(0.55)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    canvas.drawRRect(RRect.fromRectAndRadius(p, const Radius.circular(22)), line);
    canvas.drawLine(Offset(p.center.dx, p.top), Offset(p.center.dx, p.bottom), line);
    canvas.drawCircle(p.center, math.min(p.width, p.height) * 0.105, line);
    canvas.drawCircle(p.center, 2.5, Paint()..color = Colors.white.withOpacity(0.8));

    final boxW = p.width * 0.16;
    final boxH = p.height * 0.47;
    final goalBoxW = p.width * 0.055;
    final goalBoxH = p.height * 0.22;

    final leftPenalty = Rect.fromLTWH(p.left, p.center.dy - boxH / 2, boxW, boxH);
    final rightPenalty = Rect.fromLTWH(p.right - boxW, p.center.dy - boxH / 2, boxW, boxH);
    final leftGoal = Rect.fromLTWH(p.left, p.center.dy - goalBoxH / 2, goalBoxW, goalBoxH);
    final rightGoal = Rect.fromLTWH(p.right - goalBoxW, p.center.dy - goalBoxH / 2, goalBoxW, goalBoxH);

    canvas.drawRect(leftPenalty, line);
    canvas.drawRect(rightPenalty, line);
    canvas.drawRect(leftGoal, thin);
    canvas.drawRect(rightGoal, thin);

    final arcR = p.height * 0.13;
    canvas.drawArc(
      Rect.fromCircle(center: Offset(p.left + boxW, p.center.dy), radius: arcR),
      -math.pi / 3,
      2 * math.pi / 3,
      false,
      thin,
    );
    canvas.drawArc(
      Rect.fromCircle(center: Offset(p.right - boxW, p.center.dy), radius: arcR),
      2 * math.pi / 3,
      2 * math.pi / 3,
      false,
      thin,
    );

    canvas.drawRect(Rect.fromLTWH(p.left - 5, p.center.dy - 22, 5, 44), line);
    canvas.drawRect(Rect.fromLTWH(p.right, p.center.dy - 22, 5, 44), line);
  }

  void _drawHeatmap(Canvas canvas, Rect pitch, Rect bounds) {
    final pts = heatmapPoints.isNotEmpty
        ? heatmapPoints
        : tracks.expand((t) => t.points).toList();

    if (pts.isEmpty) return;

    for (final point in pts) {
      final pos = _mapPoint(point.position, pitch, bounds);
      final radius = 18.0 + (point.speed.clamp(0.0, 32.0) / 32.0) * 18.0;
      final heat = Paint()
        ..shader = RadialGradient(
          colors: [
            Colors.redAccent.withOpacity(0.26),
            Colors.orangeAccent.withOpacity(0.14),
            Colors.transparent,
          ],
        ).createShader(Rect.fromCircle(center: pos, radius: radius));
      canvas.drawCircle(pos, radius, heat);
    }
  }

  void _drawPassNetwork(Canvas canvas, Rect pitch) {
    if (passNetwork.isEmpty) return;

    final maxCount = passNetwork.fold<int>(1, (m, e) => math.max(m, e.count));

    for (final edge in passNetwork.take(30)) {
      final color = _teamColor(edge.team);
      final start = _mapPercent(Offset(edge.avgStartX, edge.avgStartY), pitch);
      final end = _mapPercent(Offset(edge.avgEndX, edge.avgEndY), pitch);
      final width = 1.0 + (edge.count / maxCount) * 4.0;

      final paint = Paint()
        ..color = color.withOpacity(0.38)
        ..strokeWidth = width
        ..strokeCap = StrokeCap.round;

      canvas.drawLine(start, end, paint);
      _drawTinyArrow(canvas, start, end, color.withOpacity(0.55));
    }
  }

  void _drawTrails(Canvas canvas, Rect pitch, Rect bounds) {
    for (final track in tracks) {
      if (track.points.length < 2) continue;
      final isSelected = track.id == selectedTrackId;
      final color = _trackColor(track);
      final maxPoints = isSelected ? 220 : 80;
      final pts = track.points.length > maxPoints
          ? track.points.sublist(track.points.length - maxPoints)
          : track.points;

      for (int i = 1; i < pts.length; i++) {
        final a = _mapPoint(pts[i - 1].position, pitch, bounds);
        final b = _mapPoint(pts[i].position, pitch, bounds);
        final t = i / pts.length;
        final paint = Paint()
          ..color = color.withOpacity(isSelected ? (0.18 + 0.55 * t) : 0.18)
          ..strokeWidth = isSelected ? 2.4 : 1.4
          ..strokeCap = StrokeCap.round;
        canvas.drawLine(a, b, paint);
      }
    }
  }

  void _drawAveragePositions(Canvas canvas, Rect pitch) {
    for (final pos in averagePositions.take(26)) {
      final color = _teamColor(pos.team);
      final center = _mapPercent(Offset(pos.avgX, pos.avgY), pitch);
      final radius = pos.team == myTeamTag ? 8.0 : 7.0;

      canvas.drawCircle(
        center,
        radius + 5,
        Paint()..color = color.withOpacity(0.13),
      );
      canvas.drawCircle(center, radius, Paint()..color = color.withOpacity(0.90));
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = Colors.white.withOpacity(0.88)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.2,
      );

      _drawLabel(canvas, pos.playerName, center.translate(0, -25), color);
    }
  }

  void _drawCurrentDots(Canvas canvas, Rect pitch, Rect bounds) {
    for (final track in tracks) {
      final last = track.lastPoint;
      if (last == null) continue;

      final isSelected = track.id == selectedTrackId;
      final color = _trackColor(track);
      final center = _mapPoint(last.position, pitch, bounds);
      final radius = isSelected ? 7.5 : 5.5;

      canvas.drawCircle(center, radius + 8, Paint()..color = color.withOpacity(0.16));
      canvas.drawCircle(center, radius, Paint()..color = color);
      canvas.drawCircle(
        center,
        radius,
        Paint()
          ..color = Colors.white.withOpacity(0.9)
          ..style = PaintingStyle.stroke
          ..strokeWidth = isSelected ? 2 : 1.2,
      );

      if (isSelected || track.boundPlayerName.isNotEmpty) {
        _drawLabel(
          canvas,
          track.boundPlayerName.isNotEmpty ? track.boundPlayerName : track.id,
          center.translate(0, 14),
          color,
        );
      }
    }
  }

  void _drawLegend(Canvas canvas, Rect pitch) {
    final left = pitch.left + 12;
    final top = pitch.top + 10;
    _legendItem(canvas, Offset(left, top), myTeamColor, 'Моя команда');
    _legendItem(canvas, Offset(left, top + 20), opponentTeamColor, 'Соперник');
  }

  void _legendItem(Canvas canvas, Offset pos, Color color, String text) {
    canvas.drawCircle(pos.translate(6, 7), 5, Paint()..color = color);
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 10,
          fontWeight: FontWeight.w800,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, pos.translate(18, 1));
  }

  void _drawLabel(Canvas canvas, String raw, Offset pos, Color color) {
    final label = raw.trim();
    if (label.isEmpty) return;

    final tp = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 9.5,
          fontWeight: FontWeight.w900,
        ),
      ),
      textDirection: TextDirection.ltr,
      maxLines: 1,
      ellipsis: '…',
    )..layout(maxWidth: 86);

    final r = RRect.fromRectAndRadius(
      Rect.fromLTWH(pos.dx - tp.width / 2 - 5, pos.dy - 8, tp.width + 10, 17),
      const Radius.circular(999),
    );
    canvas.drawRRect(r, Paint()..color = color.withOpacity(0.72));
    tp.paint(canvas, Offset(r.left + 5, r.top + 2));
  }

  void _drawTinyArrow(Canvas canvas, Offset start, Offset end, Color color) {
    final dx = end.dx - start.dx;
    final dy = end.dy - start.dy;
    final dist = math.sqrt(dx * dx + dy * dy);
    if (dist < 12) return;
    final angle = math.atan2(dy, dx);
    final p1 = Offset(end.dx - 8 * math.cos(angle - math.pi / 6), end.dy - 8 * math.sin(angle - math.pi / 6));
    final p2 = Offset(end.dx - 8 * math.cos(angle + math.pi / 6), end.dy - 8 * math.sin(angle + math.pi / 6));
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(end, p1, paint);
    canvas.drawLine(end, p2, paint);
  }

  Offset _mapPoint(Offset raw, Rect pitch, Rect bounds) {
    if (raw.dx >= 0 && raw.dx <= 100 && raw.dy >= 0 && raw.dy <= 100) {
      return _mapPercent(raw, pitch);
    }

    if (bounds.width <= 0 || bounds.height <= 0) {
      return _mapPercent(Offset(raw.dx.clamp(0, 100).toDouble(), raw.dy.clamp(0, 100).toDouble()), pitch);
    }

    final nx = ((raw.dx - bounds.left) / bounds.width).clamp(0.0, 1.0);
    final ny = ((raw.dy - bounds.top) / bounds.height).clamp(0.0, 1.0);
    return Offset(pitch.left + pitch.width * nx, pitch.top + pitch.height * ny);
  }

  Offset _mapPercent(Offset raw, Rect pitch) {
    final x = (raw.dx / 100.0).clamp(0.0, 1.0);
    final y = (raw.dy / 100.0).clamp(0.0, 1.0);
    return Offset(pitch.left + pitch.width * x, pitch.top + pitch.height * y);
  }

  Rect _sourceBounds() {
    final points = tracks.expand((t) => t.points).map((p) => p.position).toList();
    if (points.isEmpty) return const Rect.fromLTWH(0, 0, 100, 100);

    final percentLike = points.every((p) => p.dx >= 0 && p.dx <= 100 && p.dy >= 0 && p.dy <= 100);
    if (percentLike) return const Rect.fromLTWH(0, 0, 100, 100);

    double minX = points.first.dx;
    double maxX = points.first.dx;
    double minY = points.first.dy;
    double maxY = points.first.dy;

    for (final p in points) {
      minX = math.min(minX, p.dx);
      maxX = math.max(maxX, p.dx);
      minY = math.min(minY, p.dy);
      maxY = math.max(maxY, p.dy);
    }

    if ((maxX - minX).abs() < 1) maxX = minX + 100;
    if ((maxY - minY).abs() < 1) maxY = minY + 100;

    return Rect.fromLTRB(minX, minY, maxX, maxY);
  }

  Color _trackColor(PlayerTrack track) {
    if (track.teamTag == myTeamTag) return myTeamColor;
    if (track.teamTag != null && track.teamTag!.isNotEmpty) return opponentTeamColor;
    return track.color;
  }

  Color _teamColor(String? team) {
    if (team == myTeamTag) return myTeamColor;
    if (team != null && team.isNotEmpty) return opponentTeamColor;
    return Colors.white;
  }

  @override
  bool shouldRepaint(covariant StandardPitchPainter oldDelegate) {
    return oldDelegate.tracks != tracks ||
        oldDelegate.heatmapPoints != heatmapPoints ||
        oldDelegate.averagePositions != averagePositions ||
        oldDelegate.passNetwork != passNetwork ||
        oldDelegate.selectedTrackId != selectedTrackId ||
        oldDelegate.showHeatmap != showHeatmap ||
        oldDelegate.showTrails != showTrails ||
        oldDelegate.showAveragePositions != showAveragePositions ||
        oldDelegate.showPassNetwork != showPassNetwork ||
        oldDelegate.myTeamTag != myTeamTag ||
        oldDelegate.myTeamColor != myTeamColor ||
        oldDelegate.opponentTeamColor != opponentTeamColor;
  }
}
