// lib/presentation/team_calendar_screen/cmr_calendar_panel.dart
// Windows 11 / Fluent unified window refresh for CMR Calendar.
import 'dart:math' as math;
import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/team_calendar_screen/calendar_week_view.dart';
import 'package:sportoteka/presentation/team_calendar_screen/event_editor_sheet.dart';
import 'package:sportoteka/presentation/team_calendar_screen/team_calendar_api.dart';
import 'package:sportoteka/presentation/team_calendar_screen/team_calendar_models.dart';
import 'package:sportoteka/presentation/team_calendar_screen/training_rating_sheet.dart';
import 'package:sportoteka/presentation/team_calendar_screen/training_attendance_panel.dart';

enum CmrCalendarMode { month, week }

enum _CalendarWorkPanel { calendar, details, editor, ratings }

class CmrCalendarPanel extends StatefulWidget {
  final int teamId;
  final String teamName;
  final int clubId;
  final String clubName;
  final bool allowOpenFull;

  const CmrCalendarPanel({
    super.key,
    required this.teamId,
    required this.teamName,
    required this.clubId,
    required this.clubName,
    this.allowOpenFull = true,
  });

  @override
  State<CmrCalendarPanel> createState() => _CmrCalendarPanelState();
}

class _CmrCalendarPanelState extends State<CmrCalendarPanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';

  late final TeamCalendarApi api;

  bool loading = true;
  bool refreshing = false;
  String? error;

  CmrCalendarMode mode = CmrCalendarMode.month;
  DateTime cursor = DateTime.now();
  DateTime selectedDay = DateTime.now();

  List<TeamEvent> events = [];
  Map<DateTime, List<TeamEvent>> eventsByDay = {};

  String _role = '';
  _CalendarWorkPanel _workPanel = _CalendarWorkPanel.calendar;
  TeamEvent? _selectedEventForPanel;
  TeamEvent? _editingEventForPanel;
  DateTime? _createDateForPanel;
  int _editorCreatedBy = 0;

  bool get canEdit {
    final r = _role.toLowerCase().trim();
    if (r == 'player') return false;
    return true;
  }

  @override
  void initState() {
    super.initState();
    api = TeamCalendarApi(apiBase: apiBase);
    _init();
  }

  Future<void> _init() async {
    _role = await _loadRoleSafe();
    await _fetch(initial: true);
  }

  Future<String> _loadRoleSafe() async {
    try {
      return '';
    } catch (_) {
      return '';
    }
  }

  Future<void> _fetch({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      if (initial) {
        loading = true;
      } else {
        refreshing = true;
      }
      error = null;
    });

    final DateTime from;
    final DateTime to;
    if (mode == CmrCalendarMode.month) {
      from = firstDayOfMonth(cursor);
      to = lastDayOfMonth(cursor);
    } else {
      from = startOfWeekMonday(cursor);
      to = from.add(const Duration(days: 6));
    }

    try {
      final list = await api.fetch(teamId: widget.teamId, from: from, to: to);
      final grouped = <DateTime, List<TeamEvent>>{};
      for (final e in list) {
        final key = dateOnly(e.startAt);
        (grouped[key] ??= <TeamEvent>[]).add(e);
      }
      for (final entry in grouped.entries) {
        entry.value.sort((a, b) => a.startAt.compareTo(b.startAt));
      }
      if (!mounted) return;
      setState(() {
        events = list;
        eventsByDay = grouped;
        loading = false;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        refreshing = false;
        error = '$e';
      });
    }
  }

  String _monthTitle(DateTime d) {
    const months = [
      'Январь',
      'Февраль',
      'Март',
      'Апрель',
      'Май',
      'Июнь',
      'Июль',
      'Август',
      'Сентябрь',
      'Октябрь',
      'Ноябрь',
      'Декабрь',
    ];
    return '${months[d.month - 1]} ${d.year}';
  }

  String _weekTitle(DateTime d) {
    final ws = startOfWeekMonday(d);
    final we = ws.add(const Duration(days: 6));
    String f(DateTime x) =>
        '${x.day.toString().padLeft(2, '0')}.${x.month.toString().padLeft(2, '0')}';
    return '${f(ws)}–${f(we)}';
  }

  String _dateTitle(DateTime d) {
    return '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';
  }

  String _pluralEvent(int count) {
    final mod10 = count % 10;
    final mod100 = count % 100;
    if (mod10 == 1 && mod100 != 11) return 'событие';
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) {
      return 'события';
    }
    return 'событий';
  }

  void _previousPeriod() {
    setState(() {
      if (mode == CmrCalendarMode.month) {
        cursor = DateTime(cursor.year, cursor.month - 1, 1);
        selectedDay = DateTime(cursor.year, cursor.month, 1);
      } else {
        cursor = cursor.subtract(const Duration(days: 7));
        selectedDay = cursor;
      }
      _workPanel = _CalendarWorkPanel.calendar;
      _selectedEventForPanel = null;
    });
    _fetch();
  }

  void _nextPeriod() {
    setState(() {
      if (mode == CmrCalendarMode.month) {
        cursor = DateTime(cursor.year, cursor.month + 1, 1);
        selectedDay = DateTime(cursor.year, cursor.month, 1);
      } else {
        cursor = cursor.add(const Duration(days: 7));
        selectedDay = cursor;
      }
      _workPanel = _CalendarWorkPanel.calendar;
      _selectedEventForPanel = null;
    });
    _fetch();
  }

  void _today() {
    final now = DateTime.now();
    setState(() {
      cursor = now;
      selectedDay = now;
      _workPanel = _CalendarWorkPanel.calendar;
      _selectedEventForPanel = null;
    });
    _fetch();
  }

  Future<void> _pickMonth() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDay,
      firstDate: DateTime(now.year - 5, 1, 1),
      lastDate: DateTime(now.year + 5, 12, 31),
      helpText: 'Выберите дату календаря',
      cancelText: 'Отмена',
      confirmText: 'Выбрать',
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: Theme.of(context).colorScheme.copyWith(
                  primary: _C.green,
                  secondary: _C.greenDark,
                ),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
    );
    if (picked == null) return;
    setState(() {
      cursor = mode == CmrCalendarMode.month
          ? DateTime(picked.year, picked.month, 1)
          : startOfWeekMonday(picked);
      selectedDay = DateTime(picked.year, picked.month, picked.day);
      _workPanel = _CalendarWorkPanel.calendar;
      _selectedEventForPanel = null;
    });
    _fetch();
  }

  void _openFullCalendar() {
    Get.to(
      () => Scaffold(
        backgroundColor: _C.bg,
        body: SafeArea(
          child: CmrCalendarPanel(
            teamId: widget.teamId,
            teamName: widget.teamName,
            clubId: widget.clubId,
            clubName: widget.clubName,
            allowOpenFull: false,
          ),
        ),
      ),
      transition: Transition.fadeIn,
      duration: const Duration(milliseconds: 180),
    );
  }

  void _selectCalendarDay(DateTime day) {
    final nextCursor = mode == CmrCalendarMode.month
        ? DateTime(day.year, day.month, 1)
        : startOfWeekMonday(day);
    final needReload = mode == CmrCalendarMode.month
        ? nextCursor.year != cursor.year || nextCursor.month != cursor.month
        : dateOnly(nextCursor) != dateOnly(startOfWeekMonday(cursor));

    setState(() {
      selectedDay = day;
      if (needReload) cursor = nextCursor;
    });

    if (needReload) _fetch();
  }

  void _selectCalendarDayAndSyncPane(DateTime day) {
    _selectCalendarDay(day);
    setState(() {
      _editingEventForPanel = null;
      _createDateForPanel = null;
      _selectedEventForPanel = null;
      _workPanel = _CalendarWorkPanel.calendar;
    });
  }

  Future<void> _openCreate(DateTime day) async {
    if (!canEdit) return;
    final createdBy = await PrefUtils.getUserId() ?? 0;
    if (!mounted) return;

    setState(() {
      selectedDay = day;
      _editorCreatedBy = createdBy;
      _createDateForPanel = day;
      _editingEventForPanel = null;
      _selectedEventForPanel = null;
      _workPanel = _CalendarWorkPanel.editor;
    });
  }

  Future<void> _openEdit(TeamEvent event) async {
    if (!canEdit) return;
    final createdBy = await PrefUtils.getUserId() ?? 0;
    if (!mounted) return;

    setState(() {
      selectedDay = event.startAt;
      _editorCreatedBy = createdBy;
      _createDateForPanel = event.startAt;
      _editingEventForPanel = event;
      _selectedEventForPanel = event;
      _workPanel = _CalendarWorkPanel.editor;
    });
  }

  void _openDetails(TeamEvent event) {
    setState(() {
      selectedDay = event.startAt;
      _selectedEventForPanel = event;
      _editingEventForPanel = null;
      _createDateForPanel = null;
      _workPanel = _CalendarWorkPanel.details;
    });
  }

  bool _canRateEvent(TeamEvent event) {
    return event.type == TeamEventType.training || event.type == TeamEventType.gym;
  }

  Future<void> _openTrainingRatings(TeamEvent event) async {
    if (!canEdit) return;

    if (!_canRateEvent(event)) {
      Get.snackbar(
        'Оценка',
        'Оценка доступна только для тренировок и ОФП.',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    final coachId = await PrefUtils.getUserId() ?? 0;
    if (coachId <= 0) {
      Get.snackbar(
        'Оценка',
        'Не найден userId тренера.',
        snackPosition: SnackPosition.BOTTOM,
      );
      return;
    }

    if (!mounted) return;
    setState(() {
      selectedDay = event.startAt;
      _selectedEventForPanel = event;
      _editingEventForPanel = null;
      _createDateForPanel = null;
      _workPanel = _CalendarWorkPanel.ratings;
    });
  }

  void _closeWorkPanel() {
    setState(() {
      _workPanel = _CalendarWorkPanel.calendar;
      _selectedEventForPanel = null;
      _editingEventForPanel = null;
      _createDateForPanel = null;
    });
  }

  Future<void> _handleEditorSubmit(TeamEvent event) async {
    if (!canEdit) return;
    try {
      if (_editingEventForPanel == null) {
        await api.add(event: event, createdBy: _editorCreatedBy);
        Get.snackbar('Готово', 'Событие добавлено', snackPosition: SnackPosition.BOTTOM);
      } else {
        await api.update(event: event);
        Get.snackbar('Готово', 'Событие обновлено', snackPosition: SnackPosition.BOTTOM);
      }
      await _fetch();
      if (!mounted) return;
      setState(() {
        selectedDay = event.startAt;
        _workPanel = _CalendarWorkPanel.calendar;
        _selectedEventForPanel = null;
        _editingEventForPanel = null;
        _createDateForPanel = null;
      });
    } catch (e) {
      Get.snackbar('Ошибка', e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _handleAddMoreFromEditor(TeamEvent event) async {
    if (!canEdit) return;
    try {
      await api.add(event: event, createdBy: _editorCreatedBy);
      await _fetch();
      if (!mounted) return;
      setState(() {
        selectedDay = event.startAt;
        _createDateForPanel = event.startAt;
      });
      Get.snackbar('Готово', 'Событие добавлено', snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      Get.snackbar('Ошибка', e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _delete(TeamEvent event) async {
    if (!canEdit) return;
    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Удалить событие?'),
        content: Text('«${event.title}» будет удалено из календаря.'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('Отмена')),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(foregroundColor: _C.red),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      await api.remove(eventId: event.id, teamId: widget.teamId);
      await _fetch();
      if (mounted && _selectedEventForPanel?.id == event.id) {
        _closeWorkPanel();
      }
      Get.snackbar('Готово', 'Событие удалено', snackPosition: SnackPosition.BOTTOM);
    } catch (e) {
      Get.snackbar('Ошибка', e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  TeamEvent? _eventForRightPane(List<TeamEvent> selectedList) {
    if (_workPanel == _CalendarWorkPanel.details ||
        _workPanel == _CalendarWorkPanel.ratings) {
      final current = _selectedEventForPanel;
      if (current != null && events.any((e) => e.id == current.id)) return current;
    }
    if (selectedList.isNotEmpty) return selectedList.first;
    return null;
  }

  TeamEvent? _nextUpcomingEvent() {
    final now = DateTime.now();
    final future = events.where((e) => e.startAt.isAfter(now)).toList()
      ..sort((a, b) => a.startAt.compareTo(b.startAt));
    if (future.isNotEmpty) return future.first;
    final sorted = events.toList()..sort((a, b) => a.startAt.compareTo(b.startAt));
    return sorted.isEmpty ? null : sorted.first;
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return Container(
        width: double.infinity,
        decoration: const BoxDecoration(color: Colors.white),
        child: const Center(child: CircularProgressIndicator(color: _C.green)),
      );
    }

    if (error != null) {
      return _CmrEmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить календарь',
        text: error ?? 'Неизвестная ошибка',
        actionText: 'Повторить',
        onAction: () => _fetch(initial: true),
      );
    }

    final selectedList = (eventsByDay[dateOnly(selectedDay)] ?? const <TeamEvent>[]).toList()
      ..sort((a, b) => a.startAt.compareTo(b.startAt));
    final weekStart = startOfWeekMonday(cursor);

    return DefaultTextStyle.merge(
      style: AppTypography.custom(
        size: 13,
        weight: FontWeight.w400,
        color: _C.text,
        height: 1.18,
        letterSpacing: 0,
      ),
      child: LayoutBuilder(
        builder: (context, c) {
          final isPhone = c.maxWidth < 640;
          if (isPhone) {
            return _buildMobileLayout(selectedList, weekStart, c);
          }

          final selectedForDetails = _eventForRightPane(selectedList);

          // Как в CMR-матчах: календарь остаётся слева, а список/детали/редактор
          // всегда живут в правой колонке. Без нижнего дублирующего блока.
          return _buildTabletKpiWorkspace(
            selectedList: selectedList,
            weekStart: weekStart,
            selectedForDetails: selectedForDetails,
            constraints: c,
          );
        },
      ),
    );
  }

  double _calendarColumnWidth(BoxConstraints constraints) {
    // Геометрия как в CMR Team Matches: слева стабильная календарная колонка,
    // на узких десктопных окнах не сжимается ниже комфортного размера.
    final width = constraints.maxWidth.isFinite ? constraints.maxWidth : 1180.0;
    return math.min(480.0, math.max(320.0, width * .42));
  }

  Widget _buildTabletKpiWorkspace({
    required List<TeamEvent> selectedList,
    required DateTime weekStart,
    required TeamEvent? selectedForDetails,
    required BoxConstraints constraints,
  }) {
    final height = constraints.maxHeight.isFinite ? constraints.maxHeight : 780.0;
    final showWorkPane = _workPanel == _CalendarWorkPanel.editor ||
        ((_workPanel == _CalendarWorkPanel.details ||
                _workPanel == _CalendarWorkPanel.ratings) &&
            selectedForDetails != null);
    final calendarWidth = _calendarColumnWidth(constraints);

    return SizedBox(
      width: double.infinity,
      height: height,
      child: Container(
        color: const Color(0xFFF6F7F6),
        padding: EdgeInsets.all(constraints.maxWidth < 980 ? 8 : 10),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(constraints.maxWidth < 980 ? 14 : 16),
          child: Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(constraints.maxWidth < 980 ? 14 : 16),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.025),
                  blurRadius: 22,
                  spreadRadius: -16,
                  offset: const Offset(0, 12),
                ),
              ],
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  width: calendarWidth,
                  child: _buildStrictCalendarWindow(weekStart, selectedList),
                ),
                Container(width: 1, color: _C.line),
                Expanded(
                  child: AnimatedSwitcher(
                    duration: const Duration(milliseconds: 180),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    child: KeyedSubtree(
                      key: ValueKey<String>('calendar-pane-${_workPanel.name}-${selectedForDetails?.id ?? 0}'),
                      child: showWorkPane
                          ? _buildCalendarDetailsPane(selectedForDetails, selectedList, compact: true)
                          : _buildCalendarRightOverviewPanel(selectedList),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCalendarMatchHeader(List<TeamEvent> selectedList) {
    final next = _nextUpcomingEvent();
    final period = mode == CmrCalendarMode.month ? _monthTitle(cursor) : _weekTitle(cursor);
    final selectedText = _dateTitle(selectedDay);
    final selectedCountText = '${selectedList.length} ${_pluralEvent(selectedList.length)}';

    return Container(
      height: 58,
      decoration: _C.panelDecoration(radius: 22),
      padding: const EdgeInsets.fromLTRB(10, 7, 8, 7),
      child: Row(
        children: [
          const _CalendarBrandDots(),
          const SizedBox(width: 9),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: _C.surface,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.transparent),
            ),
            child: const Center(
              child: Icon(Icons.calendar_month_rounded, color: _C.text, size: 17),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 34,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.teamName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: _C.text, fontSize: 13.65, fontWeight: FontWeight.w600, height: 1),
                ),
                const SizedBox(height: 4),
                Text(
                  widget.clubName.trim().isEmpty ? 'Команда' : widget.clubName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.captionMedium(color: _C.muted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            flex: 28,
            child: _CalendarTopLine(
              label: mode == CmrCalendarMode.month ? 'Месяц' : 'Неделя',
              value: period,
              subvalue: '$selectedText · $selectedCountText',
              icon: Icons.date_range_rounded,
              color: _C.green,
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            flex: 26,
            child: _CalendarTopLine(
              label: 'Ближайшее',
              value: next == null ? 'Нет событий' : next.title,
              subvalue: next == null ? 'Добавьте событие на день' : '${_dateTitle(next.startAt)} · ${hhmm(next.startAt)}',
              icon: next == null ? Icons.event_busy_rounded : Icons.event_available_rounded,
              color: next == null ? const Color(0xFF64748B) : eventTypeColor(next.type),
            ),
          ),
          const SizedBox(width: 8),
          _ProfileRoundButton(icon: Icons.today_rounded, onTap: _today),
          const SizedBox(width: 5),
          _ProfileRoundButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
          if (canEdit) ...[
            const SizedBox(width: 5),
            _ProfileRoundButton(icon: Icons.add_rounded, onTap: () => _openCreate(selectedDay)),
          ],
        ],
      ),
    );
  }

  Widget _buildTabletDefaultGrid({
    required List<TeamEvent> selectedList,
    required DateTime weekStart,
    required TeamEvent? selectedForDetails,
    required double gap,
  }) {
    return LayoutBuilder(
      builder: (context, c) {
        final calendarWidth = _calendarColumnWidth(c);
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(width: calendarWidth, child: _buildStrictCalendarWindow(weekStart, selectedList)),
            SizedBox(width: gap),
            Expanded(
              child: _buildCalendarRightOverviewPanel(selectedList),
            ),
          ],
        );
      },
    );
  }

  Widget _buildTabletWorkModeGrid({
    required List<TeamEvent> selectedList,
    required DateTime weekStart,
    required TeamEvent? selectedForDetails,
    required double gap,
  }) {
    return LayoutBuilder(
      builder: (context, c) {
        final calendarWidth = _calendarColumnWidth(c);
        return Row(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SizedBox(width: calendarWidth, child: _buildStrictCalendarWindow(weekStart, selectedList)),
            SizedBox(width: gap),
            Expanded(
              child: _buildCalendarDetailsPane(selectedForDetails, selectedList),
            ),
          ],
        );
      },
    );
  }

  Widget _buildCalendarRightOverviewPanel(List<TeamEvent> selectedList) {
    final matchCount = events
        .where((e) => e.type == TeamEventType.leagueMatch || e.type == TeamEventType.friendlyMatch)
        .length;
    final trainingCount = events.where((e) => e.type == TeamEventType.training || e.type == TeamEventType.gym).length;
    final theoryCount = events.where((e) => e.type == TeamEventType.theory).length;
    final dayOffCount = events.where((e) => e.type == TeamEventType.dayOff).length;
    final next = _nextUpcomingEvent();
    final selectedTitle = _dateTitle(selectedDay);

    return _StrictWorkspaceCard(
      icon: Icons.view_agenda_rounded,
      title: 'События дня',
      whiteSurface: true,
      subtitle: '$selectedTitle · ${selectedList.length} ${_pluralEvent(selectedList.length)}',
      trailing: _ProfileRoundButton(
        icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded,
        onTap: () => _fetch(),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _CalendarSideKpi(
                  icon: Icons.today_rounded,
                  label: 'День',
                  value: '${selectedList.length}',
                  hint: 'на дату',
                  color: _C.green,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CalendarSideKpi(
                  icon: Icons.fitness_center_rounded,
                  label: 'Тренировки',
                  value: '$trainingCount',
                  hint: 'в периоде',
                  color: _C.green,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CalendarSideKpi(
                  icon: Icons.sports_soccer_rounded,
                  label: 'Матчи',
                  value: '$matchCount',
                  hint: 'в периоде',
                  color: _C.green,
                ),
              ),
            ],
          ),
          if (next != null) ...[
            const SizedBox(height: 8),
            _CalendarNextEventStrip(event: next, title: next.title.trim().isEmpty ? 'Ближайшее событие' : next.title),
          ],
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _CalendarSideKpi(
                  icon: Icons.psychology_alt_outlined,
                  label: 'Теория',
                  value: '$theoryCount',
                  hint: 'разборы',
                  color: _C.green,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _CalendarSideKpi(
                  icon: Icons.beach_access_rounded,
                  label: 'Выходные',
                  value: '$dayOffCount',
                  hint: 'в периоде',
                  color: _C.green,
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(0, 12, 0, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Список событий',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: _C.section(),
                  ),
                ),
                Text(
                  selectedTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.captionMedium(color: _C.muted),
                ),
              ],
            ),
          ),
          Expanded(
            child: selectedList.isEmpty
                ? const _MiniEmpty(text: 'На выбранный день событий нет')
                : ListView.separated(
                    padding: EdgeInsets.zero,
                    itemCount: selectedList.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 7),
                    itemBuilder: (_, index) {
                      final event = selectedList[index];
                      return _CmrEventTile(
                        event: event,
                        canEdit: canEdit,
                        onDetails: () => _openDetails(event),
                        onEdit: () => _openEdit(event),
                        onDelete: () => _delete(event),
                        onRating: () => _openTrainingRatings(event),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodStructureCompact() {
    final rows = [
      _CalendarTypeData(TeamEventType.training, 'Тренировки'),
      _CalendarTypeData(TeamEventType.leagueMatch, 'Матчи'),
      _CalendarTypeData(TeamEventType.friendlyMatch, 'Товарищ.'),
      _CalendarTypeData(TeamEventType.theory, 'Теория'),
      _CalendarTypeData(TeamEventType.gym, 'Зал'),
      _CalendarTypeData(TeamEventType.dayOff, 'Выходные'),
    ];

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.transparent),
      ),
      child: LayoutBuilder(
        builder: (context, c) {
          const gap = 6.0;
          final columns = c.maxWidth >= 420 ? 3 : 2;
          final width = (c.maxWidth - gap * (columns - 1)) / columns;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.query_stats_rounded, color: _C.greenDark, size: 15),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      'Структура периода',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _C.title.copyWith(fontSize: 12.55, fontWeight: FontWeight.w600),
                    ),
                  ),
                  Text(
                    mode == CmrCalendarMode.month ? _monthTitle(cursor) : _weekTitle(cursor),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.captionMedium(color: _C.muted),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final row in rows)
                    SizedBox(
                      width: width,
                      child: _CalendarTypeTile(
                        label: row.label,
                        value: '${events.where((e) => e.type == row.type).length}',
                        color: eventTypeColor(row.type),
                      ),
                    ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildCalendarInfoRows(List<TeamEvent> selectedList) {
    final matchCount = events.where((e) => e.type == TeamEventType.leagueMatch || e.type == TeamEventType.friendlyMatch).length;
    final trainingCount = events.where((e) => e.type == TeamEventType.training || e.type == TeamEventType.gym).length;
    final theoryCount = events.where((e) => e.type == TeamEventType.theory).length;
    final dayOffCount = events.where((e) => e.type == TeamEventType.dayOff).length;
    final next = _nextUpcomingEvent();

    final items = [
      _CalendarKpiData(label: 'Период', value: '${events.length}', icon: Icons.dashboard_customize_rounded, color: _C.green, hint: mode == CmrCalendarMode.month ? _monthTitle(cursor) : _weekTitle(cursor)),
      _CalendarKpiData(label: 'День', value: '${selectedList.length}', icon: Icons.today_rounded, color: _C.green, hint: _dateTitle(selectedDay)),
      _CalendarKpiData(label: 'Тренировки', value: '$trainingCount', icon: Icons.fitness_center_rounded, color: _C.green, hint: 'поле + зал'),
      _CalendarKpiData(label: 'Матчи', value: '$matchCount', icon: Icons.sports_soccer_rounded, color: _C.green, hint: 'игры'),
      _CalendarKpiData(label: 'Теория', value: '$theoryCount', icon: Icons.psychology_alt_outlined, color: _C.green, hint: dayOffCount > 0 ? 'выходных: $dayOffCount' : 'разбор'),
      _CalendarKpiData(label: 'Следующее', value: next == null ? '—' : hhmm(next.startAt), icon: Icons.play_arrow_rounded, color: next == null ? _C.slate : eventTypeColor(next.type), hint: next == null ? 'нет' : next.title),
    ];

    return SizedBox(
      height: 42,
      child: LayoutBuilder(
        builder: (context, c) {
          const gap = 5.0;
          final wide = c.maxWidth >= 1040;
          if (wide) {
            return Row(
              children: [
                for (var i = 0; i < items.length; i++) ...[
                  Expanded(child: _CalendarInfoCell(item: items[i])),
                  if (i != items.length - 1) const SizedBox(width: gap),
                ],
              ],
            );
          }

          return ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemBuilder: (_, index) => SizedBox(width: 156, child: _CalendarInfoCell(item: items[index])),
            separatorBuilder: (_, __) => const SizedBox(width: gap),
            itemCount: items.length,
          );
        },
      ),
    );
  }

  Widget _buildStrictCalendarWindow(DateTime weekStart, List<TeamEvent> selectedList) {
    final title = mode == CmrCalendarMode.month ? _monthTitle(cursor) : 'Неделя • ${_weekTitle(cursor)}';

    return _StrictWorkspaceCard(
      icon: Icons.calendar_month_rounded,
      title: title,
      subtitle: '${widget.teamName} · ${_dateTitle(selectedDay)} · ${events.length} ${_pluralEvent(events.length)}',
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ProfileRoundButton(icon: Icons.chevron_left_rounded, onTap: _previousPeriod),
          const SizedBox(width: 6),
          _ProfileRoundButton(icon: Icons.chevron_right_rounded, onTap: _nextPeriod),
          const SizedBox(width: 6),
          _ProfileRoundButton(icon: Icons.today_rounded, onTap: _today),
          const SizedBox(width: 6),
          _ProfileRoundButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
          if (canEdit) ...[
            const SizedBox(width: 6),
            _ProfileRoundButton(icon: Icons.add_rounded, onTap: () => _openCreate(selectedDay)),
          ],
        ],
      ),
      child: Column(
        children: [
          _buildCalendarInfoRows(selectedList),
          const SizedBox(height: 8),
          Row(
            children: [
              SizedBox(width: 250, child: _buildModeSelector()),
              const SizedBox(width: 8),
              Expanded(child: SingleChildScrollView(scrollDirection: Axis.horizontal, child: _legend())),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(.70),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.transparent, width: 0),
                ),
                padding: const EdgeInsets.all(8),
                child: LayoutBuilder(
                  builder: (context, calendarBox) {
                    return mode == CmrCalendarMode.month
                        ? _buildInlineMonthCalendar(maxHeight: calendarBox.maxHeight)
                        : CalendarWeekView(
                            weekStartMonday: weekStart,
                            eventsByDay: eventsByDay,
                            selectedDay: selectedDay,
                            onDayTap: _selectCalendarDayAndSyncPane,
                            onDayLongPress: (d) {
                              if (!canEdit) return;
                              _selectCalendarDayAndSyncPane(d);
                              _openCreate(d);
                            },
                            onEventTap: _openDetails,
                            onEventLongPress: (e) {
                              if (!canEdit) return;
                              _openEdit(e);
                            },
                          );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSelectedDayEventsWindow(List<TeamEvent> selectedList) {
    final eventCards = <Widget>[];
    for (var i = 0; i < selectedList.length; i++) {
      if (i > 0) eventCards.add(const SizedBox(height: 6));
      final event = selectedList[i];
      eventCards.add(
        _CmrEventTile(
          event: event,
          canEdit: canEdit,
          onDetails: () => _openDetails(event),
          onEdit: () => _openEdit(event),
          onDelete: () => _delete(event),
          onRating: () => _openTrainingRatings(event),
        ),
      );
    }

    return _StrictWorkspaceCard(
      icon: Icons.view_agenda_rounded,
      title: 'События дня',
      whiteSurface: true,
      subtitle: _dateTitle(selectedDay),
      dense: true,
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _ProfileRoundButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
          if (canEdit) ...[
            const SizedBox(width: 6),
            _ProfileRoundButton(icon: Icons.add_rounded, onTap: () => _openCreate(selectedDay)),
          ],
        ],
      ),
      child: selectedList.isEmpty
          ? const _MiniEmpty(text: 'На выбранный день событий нет')
          : Column(
              mainAxisSize: MainAxisSize.min,
              children: eventCards,
            ),
    );
  }

  Widget _buildPeriodTypeWindow() {
    final rows = [
      _CalendarTypeData(TeamEventType.training, 'Тренировки'),
      _CalendarTypeData(TeamEventType.leagueMatch, 'Матчи'),
      _CalendarTypeData(TeamEventType.friendlyMatch, 'Товарищ.'),
      _CalendarTypeData(TeamEventType.theory, 'Теория'),
      _CalendarTypeData(TeamEventType.gym, 'Зал'),
      _CalendarTypeData(TeamEventType.dayOff, 'Выходные'),
    ];

    return _StrictWorkspaceCard(
      icon: Icons.query_stats_rounded,
      title: 'Структура периода',
      subtitle: mode == CmrCalendarMode.month ? _monthTitle(cursor) : _weekTitle(cursor),
      dense: true,
      child: LayoutBuilder(
        builder: (context, c) {
          const gap = 6.0;
          final columns = c.maxWidth >= 430 ? 3 : 2;
          final width = (c.maxWidth - gap * (columns - 1)) / columns;
          return Wrap(
            spacing: gap,
            runSpacing: gap,
            children: [
              for (final row in rows)
                SizedBox(
                  width: width,
                  child: _CalendarTypeTile(
                    label: row.label,
                    value: '${events.where((e) => e.type == row.type).length}',
                    color: eventTypeColor(row.type),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildProfileCalendarCenter({
    required List<TeamEvent> selectedList,
    required DateTime weekStart,
    required double maxWidth,
  }) {
    return RefreshIndicator(
      color: _C.green,
      onRefresh: () => _fetch(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(0, 0, 0, 18),
        physics: const AlwaysScrollableScrollPhysics(),
        children: [
          _buildSlimCalendarBlock(weekStart),
          const SizedBox(height: 8),
          _buildModeSelector(),
          const SizedBox(height: 8),
          _legend(),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: Text(
                  'События за ${_dateTitle(selectedDay)}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.screenTitle(color: _C.text).copyWith(fontWeight: FontWeight.w600),
                ),
              ),
              if (canEdit) _ProfileActionButton(icon: Icons.add_rounded, text: 'Событие', onTap: () => _openCreate(selectedDay)),
              const SizedBox(width: 6),
              _ProfileRoundButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
            ],
          ),
          const SizedBox(height: 8),
          if (selectedList.isEmpty)
            const _MiniEmpty(text: 'На выбранный день событий нет')
          else
            _buildProfileEventCardsList(selectedList),
        ],
      ),
    );
  }

  Widget _buildSlimCalendarBlock(DateTime weekStart) {
    final title = mode == CmrCalendarMode.month ? _monthTitle(cursor) : 'Неделя • ${_weekTitle(cursor)}';

    return Container(
      padding: const EdgeInsets.fromLTRB(6, 6, 6, 8),
      decoration: const BoxDecoration(color: Colors.white),
      child: Column(
        children: [
          Row(
            children: [
              _ProfileCalendarArrow(icon: Icons.chevron_left_rounded, onTap: _previousPeriod),
              Expanded(
                child: Center(
                  child: InkWell(
                    borderRadius: BorderRadius.circular(6),
                    onTap: _pickMonth,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
                      child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 15.05, fontWeight: FontWeight.w600)),
                    ),
                  ),
                ),
              ),
              _ProfileCalendarArrow(icon: Icons.chevron_right_rounded, onTap: _nextPeriod),
              const SizedBox(width: 6),
              _ProfileRoundButton(icon: Icons.today_rounded, onTap: _today),
              const SizedBox(width: 6),
              if (widget.allowOpenFull)
                _ProfileRoundButton(icon: Icons.open_in_full_rounded, onTap: _openFullCalendar),
            ],
          ),
          const SizedBox(height: 8),
          if (mode == CmrCalendarMode.month)
            _buildInlineMonthCalendar()
          else
            SizedBox(
              height: 380,
              child: CalendarWeekView(
                weekStartMonday: weekStart,
                eventsByDay: eventsByDay,
                selectedDay: selectedDay,
                onDayTap: _selectCalendarDayAndSyncPane,
                onDayLongPress: (d) {
                  if (!canEdit) return;
                  _selectCalendarDayAndSyncPane(d);
                  _openCreate(d);
                },
                onEventTap: _openDetails,
                onEventLongPress: (e) {
                  if (!canEdit) return;
                  _openEdit(e);
                },
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildInlineMonthCalendar({double? maxHeight}) {
    const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    final first = DateTime(cursor.year, cursor.month, 1);
    final daysInMonth = DateTime(cursor.year, cursor.month + 1, 0).day;
    final prevMonthDays = DateTime(cursor.year, cursor.month, 0).day;
    final leading = first.weekday - 1;
    final total = ((leading + daysInMonth + 6) ~/ 7) * 7;
    final rowsCount = total ~/ 7;

    return Column(
      children: [
        Row(
          children: weekdays
              .map(
                (d) => Expanded(
                  child: Center(
                    child: Text(
                      d,
                      style: AppTypography.captionMedium(color: _C.muted),
                    ),
                  ),
                ),
              )
              .toList(),
        ),
        const SizedBox(height: 5),
        LayoutBuilder(
          builder: (context, gridBox) {
            const gap = 5.0;
            final availableWidth = gridBox.maxWidth.isFinite ? gridBox.maxWidth : MediaQuery.sizeOf(context).width;
            final safeMaxHeight = maxHeight;
            final maxGridHeight = safeMaxHeight != null && safeMaxHeight.isFinite ? math.max(180.0, safeMaxHeight - 20.0) : null;
            final cellWidth = (availableWidth - gap * 6) / 7;
            final naturalCellHeight = cellWidth / 1.22;
            final fittedCellHeight = maxGridHeight == null
                ? naturalCellHeight
                : (maxGridHeight - gap * (rowsCount - 1)) / rowsCount;
            final cellHeight = maxGridHeight == null
                ? naturalCellHeight
                : math.max(36.0, math.min(naturalCellHeight, fittedCellHeight));
            final ratio = math.max(.82, math.min(2.75, cellWidth / cellHeight));

            return GridView.builder(
              key: ValueKey('cmr-calendar-${cursor.year}-${cursor.month}-${selectedDay.toIso8601String()}'),
              itemCount: total,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 7,
                mainAxisSpacing: gap,
                crossAxisSpacing: gap,
                childAspectRatio: ratio,
              ),
              itemBuilder: (_, index) {
                final dayNumber = index - leading + 1;
                late DateTime day;
                var inMonth = true;
                if (dayNumber < 1) {
                  day = DateTime(cursor.year, cursor.month - 1, prevMonthDays + dayNumber);
                  inMonth = false;
                } else if (dayNumber > daysInMonth) {
                  day = DateTime(cursor.year, cursor.month + 1, dayNumber - daysInMonth);
                  inMonth = false;
                } else {
                  day = DateTime(cursor.year, cursor.month, dayNumber);
                }

                final list = eventsByDay[dateOnly(day)] ?? const <TeamEvent>[];
                final has = list.isNotEmpty;
                final eventAccent = has ? eventTypeColor(list.first.type) : _C.slate;
                final now = DateTime.now();
                final today = dateOnly(day) == dateOnly(now);
                final selected = dateOnly(day) == dateOnly(selectedDay);

                return Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(10),
                    onTap: () => _selectCalendarDayAndSyncPane(day),
                    onLongPress: () {
                      if (!canEdit) return;
                      _selectCalendarDayAndSyncPane(day);
                      _openCreate(day);
                    },
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 160),
                      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: null,
                        color: selected
                            ? _C.greenSoft
                            : has
                                ? _C.panel
                                : _C.soft,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: null,
                        border: selected
                            ? Border.all(color: _C.green.withOpacity(.22), width: 1)
                            : today
                                ? Border.all(color: _C.greenBorder)
                                : null,
                      ),
                      child: Stack(
                        children: [
                          Center(
                            child: Text(
                              '${day.day}',
                              style: TextStyle(
                                color: selected
                                    ? _C.greenDark
                                    : inMonth
                                        ? (today ? _C.greenDark : _C.text)
                                        : _C.muted.withOpacity(.64),
                                fontSize: maxHeight == null ? 13 : 12.5,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          if (has)
                            Positioned(
                              top: 2,
                              right: 3,
                              child: _SegmentedEventBadge(events: list, selected: selected, size: maxHeight == null ? 16 : 15),
                            ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            );
          },
        ),
      ],
    );
  }

  Widget _buildProfileEventCardsList(List<TeamEvent> rows) {
    return Column(
      children: rows
          .map(
            (event) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _CmrEventTile(
                event: event,
                canEdit: canEdit,
                onDetails: () => _openDetails(event),
                onEdit: () => _openEdit(event),
                onDelete: () => _delete(event),
                onRating: () => _openTrainingRatings(event),
              ),
            ),
          )
          .toList(),
    );
  }

  Widget _buildCalendarDetailsPane(TeamEvent? event, List<TeamEvent> selectedList, {bool compact = false}) {
    if (_workPanel == _CalendarWorkPanel.editor) {
      final editing = _editingEventForPanel;
      final day = _createDateForPanel ?? selectedDay;
      final base = editing?.startAt ?? DateTime(day.year, day.month, day.day, 18, 0);
      return _InlineEventEditorPanel(
        title: editing == null ? 'Добавить событие' : 'Редактировать событие',
        subtitle: editing == null ? 'Выбранная дата: ${_dateTitle(day)}' : 'Измените данные события и сохраните обновления',
        icon: editing == null ? Icons.add_rounded : Icons.edit_calendar_rounded,
        accent: editing == null ? _C.green : eventTypeColor(editing.type),
        onClose: _closeWorkPanel,
        child: EventEditorSheet(
          primary: _C.green,
          teamId: widget.teamId,
          clubId: editing?.clubId ?? widget.clubId,
          createdBy: _editorCreatedBy,
          initialDateTime: base,
          initial: editing,
          onEventAdded: editing == null ? _handleAddMoreFromEditor : null,
          onSubmit: _handleEditorSubmit,
          onCancel: _closeWorkPanel,
          embedded: true,
        ),
      );
    }

    if ((_workPanel == _CalendarWorkPanel.details ||
            _workPanel == _CalendarWorkPanel.ratings) &&
        event != null) {
      return _InlineEventDetailsPanel(
        key: ValueKey<String>('calendar-event-${event.id}-${_workPanel.name}'),
        event: event,
        teamName: widget.teamName,
        canEdit: canEdit,
        initialTab: _workPanel == _CalendarWorkPanel.ratings ? 2 : 0,
        onClose: _closeWorkPanel,
        onBackToCalendar: _closeWorkPanel,
        onEdit: () => _openEdit(event),
        onDelete: () => _delete(event),
        onOpenRating: () => _openTrainingRatings(event),
        onRatingsSaved: () => _fetch(),
      );
    }

    return _CalendarDetailsPlaceholder(
      teamName: widget.teamName,
      selectedDate: _dateTitle(selectedDay),
      eventsCount: selectedList.length,
      canEdit: canEdit,
      onAdd: () => _openCreate(selectedDay),
      onRefresh: () => _fetch(),
    );
  }

  Widget _buildMobileLayout(List<TeamEvent> selectedList, DateTime weekStart, BoxConstraints constraints) {
    final height = constraints.maxHeight.isFinite ? constraints.maxHeight : MediaQuery.sizeOf(context).height * .84;
    return SizedBox(
      width: double.infinity,
      height: height,
      child: Container(
        decoration: const BoxDecoration(color: _C.bg),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        child: RefreshIndicator(
          color: _C.green,
          onRefresh: () => _fetch(),
          child: ListView(
            padding: EdgeInsets.fromLTRB(0, 0, 0, MediaQuery.paddingOf(context).bottom + 116),
            physics: const AlwaysScrollableScrollPhysics(),
            children: [
              _buildMobileHeader(selectedList),
              const SizedBox(height: 8),
              _buildModeSelector(),
              const SizedBox(height: 8),
              _buildSlimCalendarBlock(weekStart),
              const SizedBox(height: 8),
              _buildSelectedDayEventsWindow(selectedList),
              if (_workPanel == _CalendarWorkPanel.editor ||
                  _workPanel == _CalendarWorkPanel.details ||
                  _workPanel == _CalendarWorkPanel.ratings) ...[
                const SizedBox(height: 8),
                SizedBox(
                  height: _workPanel == _CalendarWorkPanel.editor
                      ? 560
                      : _workPanel == _CalendarWorkPanel.ratings
                          ? 520
                          : 360,
                  child: _buildCalendarDetailsPane(_eventForRightPane(selectedList), selectedList, compact: true),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildMobileHeader(List<TeamEvent> selectedList) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: _C.cardDecoration,
      child: Row(
        children: [
          const _CalendarBrandDots(),
          const SizedBox(width: 9),
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.calendar_month_rounded, color: _C.text, size: 19),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(_monthTitle(cursor), maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 15.25, fontWeight: FontWeight.w600)),
                const SizedBox(height: 3),
                Text('${_dateTitle(selectedDay)} · ${selectedList.length} ${_pluralEvent(selectedList.length)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontSize: 11.05, fontWeight: FontWeight.w600)),
              ],
            ),
          ),
          if (canEdit) _ProfileRoundButton(icon: Icons.add_rounded, onTap: () => _openCreate(selectedDay)),
        ],
      ),
    );
  }

  Widget _buildModeSelector() {
    return Container(
      height: 34,
      child: Row(
        children: [
          Expanded(
            child: _ModeButton(
              text: 'Месяц',
              active: mode == CmrCalendarMode.month,
              onTap: () {
                if (mode == CmrCalendarMode.month) return;
                setState(() {
                  mode = CmrCalendarMode.month;
                  cursor = DateTime(selectedDay.year, selectedDay.month, 1);
                  _workPanel = _CalendarWorkPanel.calendar;
                  _selectedEventForPanel = null;
                });
                _fetch();
              },
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: _ModeButton(
              text: 'Неделя',
              active: mode == CmrCalendarMode.week,
              onTap: () {
                if (mode == CmrCalendarMode.week) return;
                setState(() {
                  mode = CmrCalendarMode.week;
                  cursor = startOfWeekMonday(selectedDay);
                  _workPanel = _CalendarWorkPanel.calendar;
                  _selectedEventForPanel = null;
                });
                _fetch();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _legend() {
    Widget item(TeamEventType t) {
      final c = eventTypeColor(t);
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(width: 7, height: 7, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 6),
            Text(eventTypeLabel(t), style: AppTypography.chip(color: _C.text, active: true)),
          ],
        ),
      );
    }

    return Wrap(
      spacing: 6,
      runSpacing: 6,
      children: [
        item(TeamEventType.training),
        item(TeamEventType.leagueMatch),
        item(TeamEventType.friendlyMatch),
        item(TeamEventType.theory),
        item(TeamEventType.gym),
        item(TeamEventType.dayOff),
      ],
    );
  }
}

class _C {
  // Windows 11 / Fluent Premium для календаря:
  // белая база, мягкий glass, графитовый текст и спокойные спортивные акценты.
  static const Color ink = Color(0xFF0B0F14);
  static const Color ink2 = Color(0xFF111827);
  static const Color inkSoft = Color(0xFF1F2937);

  static const Color bg = Colors.white;
  static const Color workspace = Color(0xFFFFFFFF);
  static const Color panel = Colors.white;
  static const Color card = Colors.white;
  static const Color surface = Color(0xFFF7F8F7);
  static const Color soft = Color(0xFFF7F8F7);
  static const Color soft2 = Color(0xFFF2F4F2);
  static const Color glass = Colors.white;
  static const Color border = Color(0xFFE9ECEA);
  static const Color line = Color(0xFFE9ECEA);
  static const Color borderStrong = Color(0xFFE1E6E3);

  static const Color text = Color(0xFF0B0F14);
  static const Color text2 = Color(0xFF111827);
  static const Color muted = Color(0xFF5F6670);
  static const Color muted2 = Color(0xFF8A9099);

  static const Color green = Color(0xFF00A750);
  static const Color greenDark = Color(0xFF067A46);
  static const Color darkGreen = Color(0xFF067A46);
  static const Color accentSoft = Color(0xFFF3FAF6);
  static const Color greenSoft = Color(0xFFF3FAF6);
  static const Color greenSoft2 = Color(0xFFF8FEFA);
  static const Color accentBorder = Color(0xFFD7F0E2);
  static const Color greenBorder = Color(0xFFD7F0E2);

  static const Color blue = Color(0xFF2563EB);
  static const Color blueSoft = Color(0xFFF5F8FF);
  static const Color cyan = Color(0xFF0891B2);
  static const Color cyanSoft = Color(0xFFF0FDFF);
  static const Color slate = Color(0xFF475569);
  static const Color slateSoft = Color(0xFFF3F5F7);
  static const Color amber = Color(0xFFD97706);
  static const Color amberSoft = Color(0xFFFFFBEB);
  static const Color red = Color(0xFFD92D20);
  static const Color redSoft = Color(0xFFFEF2F2);
  static const Color winBlue = Color(0xFF2563EB);
  static const Color winCyan = Color(0xFF0891B2);
  static const Color winMint = Color(0xFF0F766E);
  static const Color winPurple = Color(0xFF475569);

  static Color softTint(Color color, {double opacity = .085}) => Color.alphaBlend(color.withOpacity(opacity), Colors.white);

  static Color accentByIndex(int index) {
    const colors = <Color>[green, blue, cyan, slate, amber];
    return colors[index.abs() % colors.length];
  }

  static Color accentSoftByIndex(int index) {
    const colors = <Color>[greenSoft, blueSoft, cyanSoft, slateSoft, amberSoft];
    return colors[index.abs() % colors.length];
  }

  static TextStyle _base({
    required double size,
    required FontWeight weight,
    required Color color,
    double height = 1.18,
    double letterSpacing = 0,
    List<FontFeature>? features,
  }) {
    return AppTypography.custom(
      size: size,
      weight: weight,
      color: color,
      height: height,
      letterSpacing: letterSpacing,
      features: features,
    );
  }

  static List<BoxShadow> get softShadow => const <BoxShadow>[];

  static List<BoxShadow> get microShadow => const <BoxShadow>[];

  static List<BoxShadow> get panelShadow => const <BoxShadow>[];

  static BoxDecoration get workspaceDecoration => const BoxDecoration(
        color: panel,
      );

  static BoxDecoration get cardDecoration => const BoxDecoration(
        color: panel,
      );

  static BoxDecoration panelDecoration({double radius = 0}) => const BoxDecoration(
        color: panel,
      );

  static BoxDecoration seamlessPaneDecoration({double radius = 12}) => BoxDecoration(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
      );

  static BoxDecoration fluentSurface({
    double radius = 8,
    bool active = false,
    Color? accent,
    bool elevated = false,
  }) =>
      BoxDecoration(
        color: active
            ? Color.alphaBlend((accent ?? green).withOpacity(.045), Colors.white)
            : Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
      );

  static BoxDecoration softCard({double radius = 8, Color? tint}) => BoxDecoration(
        color: tint ?? Colors.transparent,
        borderRadius: BorderRadius.circular(radius),
      );

  static BoxDecoration accentCard({required Color color, double radius = 12}) => BoxDecoration(
        color: Color.alphaBlend(color.withOpacity(.045), Colors.white),
        borderRadius: BorderRadius.circular(radius),
      );

  static TextStyle get title => AppTypography.sectionTitle(
        color: text,
      ).copyWith(
        fontWeight: FontWeight.w600,
        letterSpacing: -0.18,
      );

  static TextStyle section() => AppTypography.subsectionTitle(
        color: text,
      );

  static TextStyle value(double size) => _base(
        size: size,
        weight: FontWeight.w600,
        color: text,
        height: 1.08,
        letterSpacing: -0.25,
        features: const [FontFeature.tabularFigures()],
      );

  static TextStyle mutedStyle(double size, {FontWeight weight = FontWeight.w500}) => _base(
        size: size,
        weight: weight,
        color: muted,
        height: 1.34,
        letterSpacing: -0.05,
      );

  static TextStyle caption() => AppTypography.captionMedium(
        color: muted2,
      );

  static TextStyle tab({bool active = false}) => AppTypography.tab(
        active: active,
        color: active ? greenDark : text,
      );

  static TextStyle tabSelected() => tab(active: true);

  static TextStyle action() => AppTypography.action(
        color: text,
      );

  static TextStyle danger() => AppTypography.action(
        color: red,
      );
}

String? _calendarRatingText(dynamic value) {
  if (value == null) return null;
  if (value is num) {
    if (!value.isFinite || value <= 0) return null;
    return value % 1 == 0 ? value.toInt().toString() : value.toStringAsFixed(1);
  }

  final text = '$value'.trim();
  if (text.isEmpty) return null;
  final lower = text.toLowerCase();
  if (lower == 'null' || lower == '—' || lower == '-' || lower == '0') return null;
  return text;
}

String? _readCalendarRating(List<dynamic Function()> readers) {
  for (final read in readers) {
    try {
      final value = _calendarRatingText(read());
      if (value != null) return value;
    } catch (_) {
      // Поле может отсутствовать в TeamEvent после разных версий модели.
    }
  }
  return null;
}

String? _eventCoachRatingText(TeamEvent event) {
  final dynamic e = event;
  return _readCalendarRating([
    () => e.coachRating,
    () => e.trainerRating,
    () => e.coachScore,
    () => e.trainerScore,
    () => e.coachMark,
    () => e.trainerMark,
    () => e.coachEvaluation,
    () => e.trainerEvaluation,
    () => e.coachAssessment,
    () => e.trainerAssessment,
    () => e.coach_rating,
    () => e.trainer_rating,
    () => e.coach_score,
    () => e.trainer_score,
  ]);
}


class _CalendarBrandDot extends StatelessWidget {
  final double size;
  final double opacity;
  final Color color;
  final bool glow;

  const _CalendarBrandDot({
    this.size = 6,
    this.opacity = 1,
    this.color = _C.green,
    this.glow = true,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          boxShadow: glow
              ? <BoxShadow>[
                  BoxShadow(
                    color: color.withOpacity(.18),
                    blurRadius: size * 1.9,
                    spreadRadius: .25,
                  ),
                  BoxShadow(
                    color: color.withOpacity(.08),
                    blurRadius: size * 3.2,
                    spreadRadius: .6,
                  ),
                ]
              : null,
        ),
      ),
    );
  }
}

class _CalendarBrandDots extends StatelessWidget {
  final Color color;
  const _CalendarBrandDots({this.color = _C.green});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        _CalendarBrandDot(size: 3.5, opacity: .22, color: color, glow: false),
        const SizedBox(width: 3),
        _CalendarBrandDot(size: 4.5, opacity: .42, color: color, glow: false),
        const SizedBox(width: 3),
        _CalendarBrandDot(size: 5.5, opacity: .68, color: color, glow: false),
        const SizedBox(width: 3),
        _CalendarBrandDot(size: 6.5, color: color),
      ],
    );
  }
}

class _CalendarKpiData {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final String hint;

  const _CalendarKpiData({required this.label, required this.value, required this.icon, required this.color, required this.hint});
}

class _CalendarHeaderSide extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final String metric;
  final String metricLabel;
  final Color accent;
  final bool alignEnd;

  const _CalendarHeaderSide({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.metric,
    required this.metricLabel,
    required this.accent,
    this.alignEnd = false,
  });

  @override
  Widget build(BuildContext context) {
    final content = Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: alignEnd ? CrossAxisAlignment.end : CrossAxisAlignment.start,
      children: [
        Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: alignEnd ? TextAlign.right : TextAlign.left, style: const TextStyle(color: _C.text, fontSize: 14.05, fontWeight: FontWeight.w600, height: 1.0)),
        const SizedBox(height: 5),
        Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: alignEnd ? TextAlign.right : TextAlign.left, style: AppTypography.captionMedium(color: _C.muted)),
        const SizedBox(height: 6),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
          decoration: BoxDecoration(color: Color.alphaBlend(accent.withOpacity(.08), Colors.white), borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.transparent)),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(metric, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: accent, fontSize: 11.15, fontWeight: FontWeight.w600, height: 1)),
              const SizedBox(width: 6),
              Text(metricLabel, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontSize: 9.25, fontWeight: FontWeight.w600, height: 1)),
            ],
          ),
        ),
      ],
    );

    final badge = Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Colors.transparent)),
      child: Icon(icon, color: accent == _C.green ? _C.greenDark : accent, size: 18),
    );

    return Row(
      mainAxisAlignment: alignEnd ? MainAxisAlignment.end : MainAxisAlignment.start,
      children: alignEnd ? [Expanded(child: content), const SizedBox(width: 6), badge] : [badge, const SizedBox(width: 6), Expanded(child: content)],
    );
  }
}

class _CalendarHeaderCenter extends StatelessWidget {
  final String title;
  final String subtitle;
  final String status;
  final String count;

  const _CalendarHeaderCenter({required this.title, required this.subtitle, required this.status, required this.count});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: _C.text, fontSize: 15.95, fontWeight: FontWeight.w600, height: 1.05)),
          const SizedBox(height: 5),
          Text(status, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.greenDark, fontSize: 9.65, fontWeight: FontWeight.w600, letterSpacing: .25, height: 1)),
          const SizedBox(height: 5),
          Text('$subtitle · $count', maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontSize: 9.65, fontWeight: FontWeight.w600, height: 1.1)),
        ],
      ),
    );
  }
}

class _CalendarTopLine extends StatelessWidget {
  final String label;
  final String value;
  final String subvalue;
  final IconData icon;
  final Color color;

  const _CalendarTopLine({required this.label, required this.value, required this.subvalue, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10), boxShadow: _C.microShadow),
      child: Row(
        children: [
          Container(width: 27, height: 27, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(8)), child: Icon(icon, color: _C.green, size: 13)),
          const SizedBox(width: 7),
          Expanded(
            child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.caption().copyWith(fontSize: 9.05)),
              const SizedBox(height: 3),
              Row(children: [
                Flexible(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.action().copyWith(fontSize: 10.75))),
                const SizedBox(width: 5),
                Flexible(child: Text(subvalue, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.caption().copyWith(fontSize: 9.05))),
              ]),
            ]),
          ),
        ],
      ),
    );
  }
}

class _CalendarRightHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;

  const _CalendarRightHeader({
    required this.title,
    required this.subtitle,
    required this.icon,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 60),
      padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
      color: Colors.white,
      child: Row(
        children: [
          const _CalendarBrandDots(),
          const SizedBox(width: 9),
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: _C.greenSoft,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, color: _C.greenDark, size: 15),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 14.95)),
                const SizedBox(height: 3),
                Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.mutedStyle(11.4)),
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            trailing ?? const SizedBox.shrink(),
          ],
        ],
      ),
    );
  }
}

class _CalendarSideKpi extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final String hint;
  final Color color;

  const _CalendarSideKpi({
    required this.icon,
    required this.label,
    required this.value,
    required this.hint,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 62,
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 8),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _C.value(15),
          ),
          const Spacer(),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _C.caption().copyWith(
              color: _C.text,
              fontSize: 9.25,
            ),
          ),
          const SizedBox(height: 1),
          Text(
            hint,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _C.caption().copyWith(fontSize: 8.35),
          ),
        ],
      ),
    );
  }
}

class _CalendarNextEventStrip extends StatelessWidget {
  final TeamEvent event;
  final String title;

  const _CalendarNextEventStrip({required this.event, required this.title});

  @override
  Widget build(BuildContext context) {
    final color = eventTypeColor(event.type);
    final date = '${event.startAt.day.toString().padLeft(2, '0')}.${event.startAt.month.toString().padLeft(2, '0')}.${event.startAt.year}';
    final endAt = event.endAt;
    final time = endAt == null ? hhmm(event.startAt) : '${hhmm(event.startAt)}–${hhmm(endAt)}';

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)), child: const Icon(Icons.event_available_rounded, color: _C.green, size: 16)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 13.8)),
              const SizedBox(height: 3),
              Text('$date · $time', maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.mutedStyle(10.8)),
            ]),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: _C.fluentSurface(radius: 999, active: true, accent: color, elevated: false),
            child: Text(eventTypeLabel(event.type), maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.action().copyWith(color: color, fontSize: 10.5)),
          ),
        ],
      ),
    );
  }
}

class _CalendarInfoCell extends StatelessWidget {
  final _CalendarKpiData item;

  const _CalendarInfoCell({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 44,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Text(
            item.value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: _C.value(14.0),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _C.caption().copyWith(
                    color: _C.text,
                    fontSize: 9.35,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.hint,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _C.caption().copyWith(fontSize: 8.8),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _CalendarKpiTile extends StatelessWidget {
  final _CalendarKpiData item;

  const _CalendarKpiTile({required this.item});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(
            width: 28,
            height: 28,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.88),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Icon(item.icon, color: item.color, size: 15),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.label, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium(color: _C.muted)),
                const SizedBox(height: 2),
                Row(
                  children: [
                    Text(item.value, maxLines: 1, style: const TextStyle(color: _C.text, fontSize: 14.55, fontWeight: FontWeight.w600, height: 1)),
                    const SizedBox(width: 6),
                    Expanded(child: Text(item.hint, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.badge(color: _C.muted))),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StrictWorkspaceCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Widget child;
  final Widget? trailing;
  final bool dense;
  final bool whiteSurface;

  const _StrictWorkspaceCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.child,
    this.trailing,
    this.dense = false,
    this.whiteSurface = false,
  });

  @override
  Widget build(BuildContext context) {
    final pad = dense ? 8.0 : 10.0;

    return Container(
      color: _C.panel,
      padding: EdgeInsets.fromLTRB(pad, pad, pad, dense ? 8 : 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const _CalendarBrandDots(),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _C.title.copyWith(
                        fontSize: dense ? 14.2 : 16.2,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _C.mutedStyle(dense ? 10.4 : 11.2),
                    ),
                  ],
                ),
              ),
              if (trailing != null) ...[
                const SizedBox(width: 8),
                trailing!,
              ],
            ],
          ),
          SizedBox(height: dense ? 8 : 10),
          if (dense) child else Expanded(child: child),
        ],
      ),
    );
  }
}

class _CalendarTypeData {
  final TeamEventType type;
  final String label;

  const _CalendarTypeData(this.type, this.label);
}

class _CalendarTypeTile extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _CalendarTypeTile({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 34,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        children: [
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: _C.softTint(color, opacity: .12),
              borderRadius: BorderRadius.circular(9),
            ),
            alignment: Alignment.center,
            child: Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: color,
                fontSize: 11.2,
                fontWeight: FontWeight.w600,
                height: 1,
              ),
            ),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTypography.captionMedium(
                color: _C.text,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProfileCalendarArrow extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _ProfileCalendarArrow({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(12),
      onTap: onTap,
      child: Container(
        width: 34,
        height: 34,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: _C.microShadow,
        ),
        child: Icon(icon, color: _C.inkSoft, size: 18),
      ),
    );
  }
}

class _ProfileRoundButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _ProfileRoundButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final emphasized = icon == Icons.add_rounded;
    final radius = BorderRadius.circular(13);
    final accent = emphasized ? _C.green : _C.slate;
    return Material(
      color: Colors.transparent,
      borderRadius: radius,
      child: InkWell(
        borderRadius: radius,
        onTap: onTap,
        child: Container(
          width: 38,
          height: 38,
          decoration: _C.fluentSurface(radius: 13, accent: emphasized ? _C.green : _C.blue, active: emphasized, elevated: false),
          child: Icon(icon, color: accent, size: 18),
        ),
      ),
    );
  }
}

class _ProfileActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _ProfileActionButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 34,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: _C.greenSoft,
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(
          text,
          style: _C.action().copyWith(
            color: _C.greenDark,
            fontSize: 11.2,
          ),
        ),
      ),
    );
  }
}

class _ModeButton extends StatelessWidget {
  final String text;
  final bool active;
  final VoidCallback onTap;

  const _ModeButton({
    required this.text,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        height: 32,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? _C.greenSoft : Colors.transparent,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(
          text,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: _C.action().copyWith(
            color: active ? _C.text : _C.muted2,
            fontSize: 11.2,
            fontWeight: active ? FontWeight.w600 : FontWeight.w500,
          ),
        ),
      ),
    );
  }
}

class _SegmentedEventBadge extends StatelessWidget {
  final List<TeamEvent> events;
  final bool selected;
  final double size;

  const _SegmentedEventBadge({required this.events, required this.selected, this.size = 18});

  @override
  Widget build(BuildContext context) {
    final colors = events.map((event) => eventTypeColor(event.type)).take(3).toList(growable: false);
    return SizedBox(
      width: size,
      height: size,
      child: CustomPaint(
        painter: _SegmentedEventBadgePainter(colors: colors, borderColor: Colors.white),
        child: events.length > 1
            ? Center(
                child: Text(events.length > 9 ? '9+' : '${events.length}', style: const TextStyle(color: Colors.white, fontSize: 8.4, fontWeight: FontWeight.w600, height: 1, shadows: [Shadow(color: Color(0x66000000), blurRadius: 4)])),
              )
            : const SizedBox.shrink(),
      ),
    );
  }
}

class _SegmentedEventBadgePainter extends CustomPainter {
  final List<Color> colors;
  final Color borderColor;

  const _SegmentedEventBadgePainter({required this.colors, required this.borderColor});

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final rect = Offset.zero & size;
    final safeColors = colors.isEmpty ? const [Color(0xFF008F62)] : colors;
    final fill = Paint()..style = PaintingStyle.fill;
    if (safeColors.length == 1) {
      fill.color = safeColors.first;
      canvas.drawOval(rect, fill);
    } else {
      final sweep = (math.pi * 2) / safeColors.length;
      var start = -math.pi / 2;
      for (final color in safeColors) {
        fill.color = color;
        canvas.drawArc(rect, start, sweep, true, fill);
        start += sweep;
      }
    }
    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5
      ..color = borderColor;
    canvas.drawOval(rect.deflate(.75), border);
  }

  @override
  bool shouldRepaint(covariant _SegmentedEventBadgePainter oldDelegate) {
    if (oldDelegate.borderColor != borderColor) return true;
    if (oldDelegate.colors.length != colors.length) return true;
    for (var i = 0; i < colors.length; i++) {
      if (oldDelegate.colors[i] != colors[i]) return true;
    }
    return false;
  }
}

class _CmrEventTile extends StatelessWidget {
  final TeamEvent event;
  final bool canEdit;
  final VoidCallback onDetails;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback? onRating;

  const _CmrEventTile({
    required this.event,
    required this.canEdit,
    required this.onDetails,
    required this.onEdit,
    required this.onDelete,
    this.onRating,
  });

  String get _timeText {
    final endAt = event.endAt;
    if (endAt == null) return hhmm(event.startAt);
    return '${hhmm(event.startAt)}–${hhmm(endAt)}';
  }

  @override
  Widget build(BuildContext context) {
    final accent = eventTypeColor(event.type);
    final location = event.location.trim();
    final coachRating = _eventCoachRatingText(event);
    final trainingLike =
        event.type == TeamEventType.training || event.type == TeamEventType.gym;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        onTap: onDetails,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          constraints: const BoxConstraints(minHeight: 66),
          padding: const EdgeInsets.fromLTRB(10, 9, 8, 9),
          decoration: BoxDecoration(
            color: _C.soft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 42,
                decoration: BoxDecoration(
                  color: accent,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      event.title.trim().isEmpty
                          ? 'Событие календаря'
                          : event.title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _C.title.copyWith(
                        fontSize: 13.4,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      location.isEmpty
                          ? '$_timeText  ·  ${eventTypeLabel(event.type)}'
                          : '$_timeText  ·  ${eventTypeLabel(event.type)}  ·  $location',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: _C.mutedStyle(10.6),
                    ),
                    if (coachRating != null) ...[
                      const SizedBox(height: 4),
                      Text(
                        'Оценка тренера: $coachRating',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTypography.badge(
                          color: _C.greenDark,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (canEdit) ...[
                if (trainingLike && onRating != null)
                  _MiniIconButton(
                    icon: Icons.star_rate_rounded,
                    onTap: onRating!,
                  ),
                const SizedBox(width: 4),
                _MiniIconButton(
                  icon: Icons.edit_outlined,
                  onTap: onEdit,
                ),
              ] else
                const Icon(
                  Icons.chevron_right_rounded,
                  size: 18,
                  color: _C.muted2,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CalendarRatingChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;

  const _CalendarRatingChip({required this.icon, required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: Color.alphaBlend(color.withOpacity(.08), Colors.white),
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: Colors.transparent),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: color, size: 12),
          const SizedBox(width: 4),
          Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.badge(color: _C.muted)),
          const SizedBox(width: 4),
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium(color: color)),
        ],
      ),
    );
  }
}

class _MiniIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  final bool danger;

  const _MiniIconButton({required this.icon, required this.onTap, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final c = danger ? _C.red : _C.text;
    return InkWell(
      borderRadius: BorderRadius.circular(5),
      onTap: onTap,
      child: Container(
        width: 26,
        height: 26,
        decoration: BoxDecoration(color: Color.alphaBlend(c.withOpacity(.08), Colors.white), borderRadius: BorderRadius.circular(5), border: Border.all(color: Colors.transparent)),
        child: Icon(icon, color: c, size: 13),
      ),
    );
  }
}

class _CalendarDetailsPlaceholder extends StatelessWidget {
  final String teamName;
  final String selectedDate;
  final int eventsCount;
  final bool canEdit;
  final VoidCallback onAdd;
  final VoidCallback onRefresh;

  const _CalendarDetailsPlaceholder({required this.teamName, required this.selectedDate, required this.eventsCount, required this.canEdit, required this.onAdd, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return _StrictWorkspaceCard(
      icon: Icons.fact_check_outlined,
      title: 'Детали дня',
      subtitle: teamName,
      trailing: _ProfileRoundButton(icon: Icons.refresh_rounded, onTap: onRefresh),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _InfoBox(icon: Icons.calendar_today_rounded, title: selectedDate, text: eventsCount == 0 ? 'На выбранный день событий пока нет. Можно добавить тренировку, матч, теорию или другой пункт расписания.' : 'Выберите событие в ленте дня, чтобы открыть подробности справа.'),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(child: _HeroStat(value: '$eventsCount', title: 'на день')),
                const SizedBox(width: 6),
                Expanded(child: _HeroStat(value: canEdit ? 'Да' : 'Нет', title: 'редакт.')),
              ],
            ),
            const SizedBox(height: 12),
            if (canEdit)
              _SheetActionButton(icon: Icons.add_rounded, text: 'Добавить событие', onTap: onAdd)
            else
              const _MutedHint('Для роли игрока редактирование календаря отключено.'),
          ],
        ),
      ),
    );
  }
}

class _InlineEventDetailsPanel extends StatefulWidget {
  final TeamEvent event;
  final String teamName;
  final bool canEdit;
  final VoidCallback onClose;
  final VoidCallback onBackToCalendar;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback onOpenRating;
  final VoidCallback onRatingsSaved;
  final int initialTab;

  const _InlineEventDetailsPanel({
    super.key,
    required this.event,
    required this.teamName,
    required this.canEdit,
    required this.onClose,
    required this.onBackToCalendar,
    required this.onEdit,
    required this.onDelete,
    required this.onOpenRating,
    required this.onRatingsSaved,
    this.initialTab = 0,
  });
  @override State<_InlineEventDetailsPanel> createState() => _InlineEventDetailsPanelState();
}

class _InlineEventDetailsPanelState extends State<_InlineEventDetailsPanel> {
  late int tab;
  int coachId = 0;
  @override void initState(){super.initState(); tab = widget.initialTab.clamp(0, 2); _loadCoach();}
  Future<void> _loadCoach() async {final id=await PrefUtils.getUserId()??0; if(mounted)setState(()=>coachId=id);}
  String get _dateText => '${widget.event.startAt.day.toString().padLeft(2, '0')}.${widget.event.startAt.month.toString().padLeft(2, '0')}.${widget.event.startAt.year}';
  String get _timeText {final e=widget.event.endAt; return e==null?hhmm(widget.event.startAt):'${hhmm(widget.event.startAt)}–${hhmm(e)}';}

  @override Widget build(BuildContext context) {
    final event=widget.event;
    final c=eventTypeColor(event.type);
    final isTrainingLike=event.type==TeamEventType.training||event.type==TeamEventType.gym;
    return _StrictWorkspaceCard(
      icon: Icons.event_note_rounded,
      title: event.title.trim().isEmpty?'Событие календаря':event.title,
      subtitle: '${eventTypeLabel(event.type)} · $_dateText · $_timeText',
      trailing: _ProfileRoundButton(icon:Icons.close_rounded,onTap:widget.onClose),
      child: Column(children:[
        if(isTrainingLike) Container(height:42,padding:const EdgeInsets.all(4),decoration:BoxDecoration(color:_C.surface,borderRadius:BorderRadius.circular(12)),child:Row(children:[
          Expanded(child:_InlineTabButton(text:'Описание',icon:Icons.info_outline_rounded,active:tab==0,onTap:()=>setState(()=>tab=0))),
          const SizedBox(width:4),
          Expanded(child:_InlineTabButton(text:'Посещаемость',icon:Icons.fact_check_rounded,active:tab==1,onTap:()=>setState(()=>tab=1))),
          const SizedBox(width:4),
          Expanded(child:_InlineTabButton(text:'Оценки',icon:Icons.star_rate_rounded,active:tab==2,onTap:()=>setState(()=>tab=2))),
        ])),
        if(isTrainingLike) const SizedBox(height:8),
        Expanded(child: !isTrainingLike||tab==0
            ? _eventInfo(c)
            : tab==1
                ? TrainingAttendancePanel(key:ValueKey('attendance-${event.id}'),apiBase:_CmrCalendarPanelState.apiBase,teamId:event.teamId,eventId:event.id)
                : (coachId<=0
                    ? const Center(child:CircularProgressIndicator(strokeWidth:2))
                    : TrainingRatingSheet(key:ValueKey('rating-${event.id}'),apiBase:_CmrCalendarPanelState.apiBase,teamId:event.teamId,eventId:event.id,coachId:coachId,title:event.title,embedded:true,onSaved:widget.onRatingsSaved))),
      ]),
    );
  }

  Widget _eventInfo(Color c){
    final event=widget.event; final notes=event.notes.trim(); final location=event.location.trim(); final coachRating=_eventCoachRatingText(event);
    return SingleChildScrollView(child:Column(children:[
      Row(children:[Expanded(child:_DetailMetric(icon:Icons.schedule_rounded,title:'Время',value:_timeText,accent:c)),const SizedBox(width:6),Expanded(child:_DetailMetric(icon:Icons.category_rounded,title:'Тип',value:eventTypeLabel(event.type),accent:c))]),
      const SizedBox(height:8),
      Row(children:[Expanded(child:_DetailMetric(icon:Icons.calendar_month_rounded,title:'Дата',value:_dateText,accent:c)),const SizedBox(width:6),Expanded(child:_DetailMetric(icon:Icons.location_on_outlined,title:'Место',value:location.isEmpty?'Не указано':location,accent:c))]),
      if(coachRating!=null)...[const SizedBox(height:8),_DetailMetric(icon:Icons.workspace_premium_rounded,title:'Оценка тренера',value:coachRating,accent:_C.greenDark)],
      const SizedBox(height:8),_InfoBox(icon:Icons.notes_rounded,title:'Заметки',text:notes.isEmpty?'Заметки не добавлены.':notes),const SizedBox(height:8),
      if(widget.canEdit) Row(children:[Expanded(child:_SheetActionButton(icon:Icons.edit_rounded,text:'Редактировать',onTap:widget.onEdit)),const SizedBox(width:6),Expanded(child:_SheetActionButton(icon:Icons.delete_outline_rounded,text:'Удалить',onTap:widget.onDelete,danger:true))]),
    ]));
  }
}

class _InlineTabButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final bool active;
  final VoidCallback onTap;

  const _InlineTabButton({
    required this.text,
    required this.icon,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? _C.greenSoft : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 14,
                color: active ? _C.greenDark : _C.muted2,
              ),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  text,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.tab(
                    active: active,
                    color: active ? _C.text : _C.muted2,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InlineEventEditorPanel extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final Widget child;
  final VoidCallback onClose;

  const _InlineEventEditorPanel({required this.title, required this.subtitle, required this.icon, required this.accent, required this.child, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.panelDecoration(),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            constraints: const BoxConstraints(minHeight: 62),
            padding: const EdgeInsets.fromLTRB(14, 10, 10, 10),
            decoration: const BoxDecoration(color: Colors.white),
            child: Row(
              children: [
                _CalendarBrandDots(color: accent),
                const SizedBox(width: 9),
                Container(
                  width: 32,
                  height: 32,
                  decoration: BoxDecoration(
                    color: Color.alphaBlend(accent.withOpacity(.07), Colors.white),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(icon, color: accent, size: 15),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 13.45, fontWeight: FontWeight.w600, height: 1.05)),
                      const SizedBox(height: 3),
                      Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium(color: _C.muted)),
                    ],
                  ),
                ),
                _ProfileRoundButton(icon: Icons.close_rounded, onTap: onClose),
              ],
            ),
          ),
          Expanded(
            child: Container(
              color: Colors.white,
              padding: const EdgeInsets.fromLTRB(8, 4, 8, 8),
              child: child,
            ),
          ),
        ],
      ),
    );
  }
}

class _DetailMetric extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final Color accent;

  const _DetailMetric({required this.icon, required this.title, required this.value, required this.accent});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Container(width: 30, height: 30, decoration: BoxDecoration(color: Color.alphaBlend(accent.withOpacity(.10), Colors.white), borderRadius: BorderRadius.circular(6)), child: Icon(icon, color: accent, size: 15)),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium(color: _C.muted)),
                const SizedBox(height: 3),
                Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.secondaryMedium(color: _C.text)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoBox extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;

  const _InfoBox({required this.icon, required this.title, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: _C.greenDark, size: 15),
              const SizedBox(width: 7),
              Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 11.85, fontWeight: FontWeight.w600))),
            ],
          ),
          const SizedBox(height: 5),
          Text(text, style: const TextStyle(color: _C.muted, fontSize: 11.55, fontWeight: FontWeight.w600, height: 1.35)),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;
  final Color accent;

  const _HeroStat({
    required this.value,
    required this.title,
    this.accent = _C.blue,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        children: [
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.text, fontSize: 16.75, fontWeight: FontWeight.w600)),
          const SizedBox(height: 2),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium(color: _C.muted)),
        ],
      ),
    );
  }
}

class _SheetActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool danger;

  const _SheetActionButton({required this.icon, required this.text, required this.onTap, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final color = danger ? _C.red : _C.greenDark;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 11),
          decoration: BoxDecoration(
            color: danger ? _C.redSoft : _C.soft,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 14),
              const SizedBox(width: 7),
              Flexible(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: color, fontSize: 11.5, fontWeight: FontWeight.w600))),
            ],
          ),
        ),
      ),
    );
  }
}

class _MutedHint extends StatelessWidget {
  final String text;

  const _MutedHint(this.text);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(color: _C.soft, borderRadius: BorderRadius.circular(10)),
      child: Text(text, style: const TextStyle(color: _C.muted, fontSize: 11.55, fontWeight: FontWeight.w600)),
    );
  }
}

class _MiniEmpty extends StatelessWidget {
  final String text;

  const _MiniEmpty({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w600, height: 1.4)),
      ),
    );
  }
}

class _CmrEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String? actionText;
  final VoidCallback? onAction;

  const _CmrEmptyState({required this.icon, required this.title, required this.text, this.actionText, this.onAction});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: _C.greenDark, size: 48),
              const SizedBox(height: 14),
              Text(title, textAlign: TextAlign.center, style: AppTypography.emptyTitle(color: _C.text)),
              const SizedBox(height: 8),
              Text(text, textAlign: TextAlign.center, style: AppTypography.emptyText(color: _C.muted).copyWith(fontWeight: FontWeight.w500)),
              if (actionText != null && onAction != null) ...[
                const SizedBox(height: 18),
                ElevatedButton.icon(
                  onPressed: onAction,
                  icon: const Icon(Icons.refresh_rounded),
                  label: Text(actionText ?? 'Действие'),
                  style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: _C.greenDark, elevation: 0, side: BorderSide(color: _C.green.withOpacity(.18)), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
