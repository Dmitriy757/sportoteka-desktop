import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/tracker_pro_models.dart';

class TrackerHeatmapPainter extends CustomPainter {
  TrackerHeatmapPainter({required this.points});

  final List<TrackerHeatPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRRect(
      RRect.fromRectAndRadius(rect, const Radius.circular(24)),
      Paint()..color = const Color(0xFF0E1216),
    );

    final pitch = _fitPitch(rect.deflate(18));
    final pitchRRect = RRect.fromRectAndRadius(pitch, const Radius.circular(22));
    _drawUnifiedPitch(canvas, pitch, pitchRRect);

    if (points.isEmpty) {
      _drawCenterText(canvas, rect, 'Нет данных теплокарты');
      return;
    }

    final maxValue = points.fold<double>(1, (m, p) => math.max(m, p.value));
    for (final p in points) {
      final nx = _normalX(p);
      final ny = _normalY(p);
      final pos = Offset(pitch.left + nx * pitch.width, pitch.top + ny * pitch.height);
      final ratio = (p.value / maxValue).clamp(.06, 1.0).toDouble();
      final radius = (14 + 44 * ratio).clamp(14.0, 58.0).toDouble();
      final color = _heatColor(ratio);

      canvas.drawCircle(
        pos,
        radius,
        Paint()
          ..shader = RadialGradient(
            colors: [
              color.withOpacity(.24),
              color.withOpacity(.10),
              Colors.transparent,
            ],
            stops: const [0, .48, 1],
          ).createShader(Rect.fromCircle(center: pos, radius: radius)),
      );
    }

    _drawPitchLines(canvas, pitch, pitchRRect);
  }

  Rect _fitPitch(Rect area) {
    const aspect = 105 / 68;
    var w = area.width;
    var h = w / aspect;
    if (h > area.height) {
      h = area.height;
      w = h * aspect;
    }
    return Rect.fromCenter(center: area.center, width: w, height: h);
  }

  void _drawUnifiedPitch(Canvas canvas, Rect pitch, RRect pitchRRect) {
    final grass = Paint()
      ..shader = const LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [Color(0xFF113D2A), Color(0xFF0D5B33), Color(0xFF0C6A3A)],
      ).createShader(pitch);
    canvas.drawRRect(pitchRRect, grass);

    final stripeW = pitch.width / 10;
    for (var i = 0; i < 10; i++) {
      canvas.drawRect(
        Rect.fromLTWH(pitch.left + stripeW * i, pitch.top, stripeW, pitch.height),
        Paint()..color = i.isEven ? Colors.white.withOpacity(.034) : Colors.black.withOpacity(.030),
      );
    }

    final lane = Paint()
      ..color = Colors.white.withOpacity(.055)
      ..strokeWidth = 1;
    for (var i = 1; i <= 3; i++) {
      final y = pitch.top + pitch.height / 4 * i;
      canvas.drawLine(Offset(pitch.left, y), Offset(pitch.right, y), lane);
    }
    for (var i = 1; i <= 5; i++) {
      final x = pitch.left + pitch.width / 6 * i;
      canvas.drawLine(Offset(x, pitch.top), Offset(x, pitch.bottom), lane);
    }
  }

  void _drawPitchLines(Canvas canvas, Rect pitch, RRect pitchRRect) {
    final line = Paint()
      ..color = Colors.white.withOpacity(.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    final thin = Paint()
      ..color = Colors.white.withOpacity(.40)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    canvas.drawRRect(pitchRRect, line);
    canvas.drawLine(Offset(pitch.center.dx, pitch.top), Offset(pitch.center.dx, pitch.bottom), line);
    canvas.drawCircle(pitch.center, math.min(pitch.width, pitch.height) * .11, line);
    canvas.drawCircle(pitch.center, 3, Paint()..color = Colors.white.withOpacity(.92));

    final penaltyW = pitch.width * .165;
    final penaltyH = pitch.height * .52;
    final goalW = pitch.width * .060;
    final goalH = pitch.height * .24;
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), line);
    canvas.drawRect(Rect.fromLTWH(pitch.right - penaltyW, pitch.center.dy - penaltyH / 2, penaltyW, penaltyH), line);
    canvas.drawRect(Rect.fromLTWH(pitch.left, pitch.center.dy - goalH / 2, goalW, goalH), thin);
    canvas.drawRect(Rect.fromLTWH(pitch.right - goalW, pitch.center.dy - goalH / 2, goalW, goalH), thin);
  }

  double _normalX(TrackerHeatPoint p) {
    if (p.x >= 0 && p.x <= 1 && p.y >= 0 && p.y <= 1) return p.x.clamp(0.0, 1.0).toDouble();
    return (p.x / 105.0).clamp(0.0, 1.0).toDouble();
  }

  double _normalY(TrackerHeatPoint p) {
    if (p.x >= 0 && p.x <= 1 && p.y >= 0 && p.y <= 1) return p.y.clamp(0.0, 1.0).toDouble();
    return (p.y / 68.0).clamp(0.0, 1.0).toDouble();
  }

  Color _heatColor(double ratio) {
    if (ratio > .80) return const Color(0xFFE11D48);
    if (ratio > .55) return const Color(0xFFF97316);
    if (ratio > .30) return const Color(0xFFFACC15);
    return const Color(0xFF22C55E);
  }

  void _drawCenterText(Canvas canvas, Rect rect, String text) {
    final tp = TextPainter(
      text: TextSpan(
        text: text,
        style: TextStyle(color: Colors.white.withOpacity(.78), fontSize: 16, fontWeight: FontWeight.w900),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: rect.width - 40);
    tp.paint(canvas, rect.center - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant TrackerHeatmapPainter oldDelegate) => oldDelegate.points != points;
}
