class TrackerPlayerOption {
  final int id;
  final String name;
  final String? avatar;
  final String? number;
  final String? position;

  const TrackerPlayerOption({
    required this.id,
    required this.name,
    this.avatar,
    this.number,
    this.position,
  });

  factory TrackerPlayerOption.fromJson(Map<String, dynamic> json) {
    final firstName = '${json['first_name'] ?? json['firstName'] ?? ''}'.trim();
    final lastName = '${json['last_name'] ?? json['lastName'] ?? ''}'.trim();
    final full = '${json['name'] ?? json['full_name'] ?? json['fullName'] ?? '$firstName $lastName'}'.trim();

    return TrackerPlayerOption(
      id: int.tryParse('${json['id'] ?? json['player_id'] ?? json['playerId'] ?? 0}') ?? 0,
      name: full.isEmpty ? 'Игрок' : full,
      avatar: '${json['avatar_url'] ?? json['avatar'] ?? json['photo_url'] ?? json['user_photo'] ?? json['photo'] ?? json['image'] ?? ''}'.trim().isEmpty
          ? null
          : '${json['avatar_url'] ?? json['avatar'] ?? json['photo_url'] ?? json['user_photo'] ?? json['photo'] ?? json['image']}',
      number: '${json['jersey_number'] ?? json['jersey_number'] ?? json['number'] ?? json['shirt_number'] ?? ''}'.trim().isEmpty ? null : '${json['jersey_number'] ?? json['number'] ?? json['shirt_number']}',
      position: '${json['position'] ?? ''}'.trim().isEmpty ? null : '${json['position']}',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'avatar': avatar,
        'number': number,
        'position': position,
      };
}

class TrackerDeviceModel {
  final int? id;
  final int? clubId;
  final int? teamId;
  final int? playerId;
  final String deviceUuid;
  final String deviceName;
  final int? batteryPercent;
  final bool isNearby;
  final String? playerName;

  const TrackerDeviceModel({
    this.id,
    this.clubId,
    this.teamId,
    this.playerId,
    required this.deviceUuid,
    required this.deviceName,
    this.batteryPercent,
    this.isNearby = false,
    this.playerName,
  });

  factory TrackerDeviceModel.fromJson(Map<String, dynamic> json) {
    return TrackerDeviceModel(
      id: int.tryParse('${json['id'] ?? ''}'),
      clubId: int.tryParse('${json['club_id'] ?? json['clubId'] ?? ''}'),
      teamId: int.tryParse('${json['team_id'] ?? json['teamId'] ?? ''}'),
      playerId: int.tryParse('${json['player_id'] ?? json['playerId'] ?? ''}'),
      deviceUuid: '${json['device_uuid'] ?? json['device_id'] ?? json['uuid'] ?? ''}',
      deviceName: '${json['device_name'] ?? json['name'] ?? 'Трекер'}',
      batteryPercent: int.tryParse('${json['battery_percent'] ?? ''}'),
      isNearby: '${json['is_nearby'] ?? json['nearby'] ?? 0}' == '1' || json['is_nearby'] == true,
      playerName: '${json['player_name'] ?? ''}'.trim().isEmpty ? null : '${json['player_name']}',
    );
  }
}

class TrackerSpeedSettings {
  final String preset;
  final double jogRuleMps;
  final double mediumRuleMps;
  final double highRuleMps;
  final double sprintRuleMps;
  final double sprintTimeSec;
  final double accelerationRuleMps2;
  final bool isSprintTraceMode;

  const TrackerSpeedSettings({
    this.preset = 'youth',
    this.jogRuleMps = 1.2,
    this.mediumRuleMps = 3.0,
    this.highRuleMps = 5.0,
    this.sprintRuleMps = 5.5,
    this.sprintTimeSec = 2.0,
    this.accelerationRuleMps2 = 0.3,
    this.isSprintTraceMode = true,
  });

  factory TrackerSpeedSettings.fromJson(Map<String, dynamic> json) {
    return TrackerSpeedSettings(
      preset: '${json['preset'] ?? 'youth'}',
      jogRuleMps: _d(json['jog_rule_mps'], 1.2),
      mediumRuleMps: _d(json['medium_rule_mps'], 3.0),
      highRuleMps: _d(json['high_rule_mps'], 5.0),
      sprintRuleMps: _d(json['sprint_rule_mps'], 5.5),
      sprintTimeSec: _d(json['sprint_time_sec'], 2.0),
      accelerationRuleMps2: _d(json['acceleration_rule_mps2'], 0.3),
      isSprintTraceMode: '${json['is_sprint_trace_mode'] ?? 1}' == '1' || json['is_sprint_trace_mode'] == true,
    );
  }

  Map<String, dynamic> toJson() => {
        'preset': preset,
        'jog_rule_mps': jogRuleMps,
        'medium_rule_mps': mediumRuleMps,
        'high_rule_mps': highRuleMps,
        'sprint_rule_mps': sprintRuleMps,
        'sprint_time_sec': sprintTimeSec,
        'acceleration_rule_mps2': accelerationRuleMps2,
        'is_sprint_trace_mode': isSprintTraceMode ? 1 : 0,
      };

  TrackerSpeedSettings copyWith({
    String? preset,
    double? jogRuleMps,
    double? mediumRuleMps,
    double? highRuleMps,
    double? sprintRuleMps,
    double? sprintTimeSec,
    double? accelerationRuleMps2,
    bool? isSprintTraceMode,
  }) {
    return TrackerSpeedSettings(
      preset: preset ?? this.preset,
      jogRuleMps: jogRuleMps ?? this.jogRuleMps,
      mediumRuleMps: mediumRuleMps ?? this.mediumRuleMps,
      highRuleMps: highRuleMps ?? this.highRuleMps,
      sprintRuleMps: sprintRuleMps ?? this.sprintRuleMps,
      sprintTimeSec: sprintTimeSec ?? this.sprintTimeSec,
      accelerationRuleMps2: accelerationRuleMps2 ?? this.accelerationRuleMps2,
      isSprintTraceMode: isSprintTraceMode ?? this.isSprintTraceMode,
    );
  }

  static double _d(dynamic value, double fallback) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? fallback;
  }
}

class TrackerPlayerLoadRow {
  final int? playerId;
  final String playerName;
  final String? avatar;
  final int sessionsCount;
  final double distanceM;
  final double avgSpeedKmh;
  final double maxSpeedKmh;
  final double highSpeedDistanceM;
  final double sprintDistanceM;
  final int sprintCount;
  final int accelerationCount;
  final int decelerationCount;
  final double loadScore;

  const TrackerPlayerLoadRow({
    required this.playerId,
    required this.playerName,
    this.avatar,
    required this.sessionsCount,
    required this.distanceM,
    required this.avgSpeedKmh,
    required this.maxSpeedKmh,
    required this.highSpeedDistanceM,
    required this.sprintDistanceM,
    required this.sprintCount,
    required this.accelerationCount,
    required this.decelerationCount,
    required this.loadScore,
  });

  factory TrackerPlayerLoadRow.fromJson(Map<String, dynamic> json) {
    return TrackerPlayerLoadRow(
      playerId: int.tryParse('${json['player_id'] ?? ''}'),
      playerName: '${json['player_name'] ?? json['name'] ?? json['full_name'] ?? 'Игрок'}',
      avatar: _photo(json),
      sessionsCount: int.tryParse('${json['sessions_count'] ?? 0}') ?? 0,
      distanceM: _d(json['distance_m']),
      avgSpeedKmh: _d(json['avg_speed_kmh']),
      maxSpeedKmh: _d(json['max_speed_kmh']),
      highSpeedDistanceM: _d(json['high_speed_distance_m']),
      sprintDistanceM: _d(json['sprint_distance_m']),
      sprintCount: int.tryParse('${json['sprint_count'] ?? 0}') ?? 0,
      accelerationCount: int.tryParse('${json['acceleration_count'] ?? 0}') ?? 0,
      decelerationCount: int.tryParse('${json['deceleration_count'] ?? 0}') ?? 0,
      loadScore: _d(json['load_score']),
    );
  }

  static String? _photo(Map<String, dynamic> json) {
    final raw = '${json['photo'] ?? json['avatar'] ?? json['image'] ?? json['photo_url'] ?? json['avatar_url'] ?? json['user_photo'] ?? ''}'.trim();
    if (raw.isEmpty || raw == 'null') return null;
    return raw;
  }

  static double _d(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? 0;
  }
}

class TrackerDashboardModel {
  final Map<String, dynamic> summary;
  final List<TrackerPlayerLoadRow> players;
  final List<Map<String, dynamic>> alerts;

  const TrackerDashboardModel({
    required this.summary,
    required this.players,
    required this.alerts,
  });

  factory TrackerDashboardModel.fromJson(Map<String, dynamic> json) {
    return TrackerDashboardModel(
      summary: Map<String, dynamic>.from(json['summary'] as Map? ?? const {}),
      players: (json['players'] as List? ?? const [])
          .map((e) => TrackerPlayerLoadRow.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      alerts: (json['alerts'] as List? ?? const [])
          .map((e) => Map<String, dynamic>.from(e as Map))
          .toList(),
    );
  }
}

class TrackerSessionModel {
  final int id;
  final int? playerId;
  final String? playerName;
  final String deviceName;
  final String title;
  final String createdAt;
  final String processingStatus;
  final double distanceM;
  final double maxSpeedKmh;
  final int sprintCount;
  final double loadScore;

  const TrackerSessionModel({
    required this.id,
    this.playerId,
    this.playerName,
    required this.deviceName,
    required this.title,
    required this.createdAt,
    required this.processingStatus,
    required this.distanceM,
    required this.maxSpeedKmh,
    required this.sprintCount,
    required this.loadScore,
  });

  factory TrackerSessionModel.fromJson(Map<String, dynamic> json) {
    return TrackerSessionModel(
      id: int.tryParse('${json['id'] ?? 0}') ?? 0,
      playerId: int.tryParse('${json['player_id'] ?? ''}'),
      playerName: '${json['player_name'] ?? ''}'.trim().isEmpty ? null : '${json['player_name']}',
      deviceName: '${json['device_name'] ?? 'Трекер'}',
      title: '${json['title'] ?? 'Сессия'}',
      createdAt: '${json['created_at'] ?? ''}',
      processingStatus: '${json['processing_status'] ?? 'new'}',
      distanceM: _d(json['distance_m']),
      maxSpeedKmh: _d(json['max_speed_kmh']),
      sprintCount: int.tryParse('${json['sprint_count'] ?? 0}') ?? 0,
      loadScore: _d(json['load_score']),
    );
  }

  static double _d(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? 0;
  }
}

class TrackerHeatPoint {
  final double x;
  final double y;
  final double value;

  const TrackerHeatPoint({required this.x, required this.y, required this.value});

  factory TrackerHeatPoint.fromJson(Map<String, dynamic> json) {
    return TrackerHeatPoint(
      x: _d(json['x']),
      y: _d(json['y']),
      value: _d(json['value'], 1),
    );
  }

  static double _d(dynamic value, [double fallback = 0]) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? fallback;
  }
}


class TrackerFieldModel {
  final int? id;
  final int? clubId;
  final int? teamId;
  final String title;
  final double lengthM;
  final double widthM;
  final double? cornerALat;
  final double? cornerALng;
  final double? cornerBLat;
  final double? cornerBLng;
  final double? cornerCLat;
  final double? cornerCLng;
  final double? cornerDLat;
  final double? cornerDLng;
  final bool isDefault;

  const TrackerFieldModel({
    this.id,
    this.clubId,
    this.teamId,
    required this.title,
    this.lengthM = 105,
    this.widthM = 68,
    this.cornerALat,
    this.cornerALng,
    this.cornerBLat,
    this.cornerBLng,
    this.cornerCLat,
    this.cornerCLng,
    this.cornerDLat,
    this.cornerDLng,
    this.isDefault = false,
  });

  bool get hasCalibration =>
      cornerALat != null &&
      cornerALng != null &&
      cornerBLat != null &&
      cornerBLng != null &&
      cornerCLat != null &&
      cornerCLng != null &&
      cornerDLat != null &&
      cornerDLng != null;

  factory TrackerFieldModel.fromJson(Map<String, dynamic> json) {
    return TrackerFieldModel(
      id: int.tryParse('${json['id'] ?? ''}'),
      clubId: int.tryParse('${json['club_id'] ?? json['clubId'] ?? ''}'),
      teamId: int.tryParse('${json['team_id'] ?? json['teamId'] ?? ''}'),
      title: '${json['title'] ?? json['name'] ?? 'Поле'}',
      lengthM: _d(json['length_m'], 105),
      widthM: _d(json['width_m'], 68),
      cornerALat: _dn(json['corner_a_lat']),
      cornerALng: _dn(json['corner_a_lng']),
      cornerBLat: _dn(json['corner_b_lat']),
      cornerBLng: _dn(json['corner_b_lng']),
      cornerCLat: _dn(json['corner_c_lat']),
      cornerCLng: _dn(json['corner_c_lng']),
      cornerDLat: _dn(json['corner_d_lat']),
      cornerDLng: _dn(json['corner_d_lng']),
      isDefault: '${json['is_default'] ?? 0}' == '1' || json['is_default'] == true,
    );
  }

  Map<String, dynamic> toJson({int? overrideClubId, int? overrideTeamId}) => {
        'id': id,
        'club_id': overrideClubId ?? clubId,
        'team_id': overrideTeamId ?? teamId,
        'title': title,
        'length_m': lengthM,
        'width_m': widthM,
        'corner_a_lat': cornerALat,
        'corner_a_lng': cornerALng,
        'corner_b_lat': cornerBLat,
        'corner_b_lng': cornerBLng,
        'corner_c_lat': cornerCLat,
        'corner_c_lng': cornerCLng,
        'corner_d_lat': cornerDLat,
        'corner_d_lng': cornerDLng,
        'is_default': isDefault ? 1 : 0,
      };

  static double _d(dynamic value, double fallback) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? fallback;
  }

  static double? _dn(dynamic value) {
    if (value == null) return null;
    final s = '$value'.trim();
    if (s.isEmpty) return null;
    if (value is num) return value.toDouble();
    return double.tryParse(s);
  }
}

class TrackerSessionPointModel {
  final int id;
  final int sessionId;
  final int? playerId;
  final String? deviceUuid;
  final DateTime? pointTime;
  final double elapsedSec;
  final double? latitude;
  final double? longitude;
  final double? fieldXM;
  final double? fieldYM;
  final double speedKmh;
  final double accelerationMps2;
  final double distanceDeltaM;
  final double cumulativeDistanceM;
  final String intensityZone;

  const TrackerSessionPointModel({
    required this.id,
    required this.sessionId,
    this.playerId,
    this.deviceUuid,
    this.pointTime,
    required this.elapsedSec,
    this.latitude,
    this.longitude,
    this.fieldXM,
    this.fieldYM,
    required this.speedKmh,
    required this.accelerationMps2,
    required this.distanceDeltaM,
    required this.cumulativeDistanceM,
    required this.intensityZone,
  });

  factory TrackerSessionPointModel.fromJson(Map<String, dynamic> json) {
    final dt = _dt(json['point_time'] ?? json['created_at'] ?? json['timestamp']);
    return TrackerSessionPointModel(
      id: _i(json['id']),
      sessionId: _i(json['session_id']),
      playerId: _in(json['player_id']),
      deviceUuid: _sn(json['device_uuid']),
      pointTime: dt,
      elapsedSec: _d(json['elapsed_sec'] ?? json['time_sec'] ?? json['second']),
      latitude: _dn(json['latitude']),
      longitude: _dn(json['longitude']),
      fieldXM: _dn(json['field_x_m']),
      fieldYM: _dn(json['field_y_m']),
      speedKmh: _d(json['speed_kmh']),
      accelerationMps2: _d(json['acceleration_mps2']),
      distanceDeltaM: _d(json['distance_delta_m']),
      cumulativeDistanceM: _d(json['cumulative_distance_m']),
      intensityZone: '${json['intensity_zone'] ?? json['zone'] ?? 'walk'}',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'session_id': sessionId,
        'player_id': playerId,
        'device_uuid': deviceUuid,
        'point_time': pointTime?.toIso8601String(),
        'elapsed_sec': elapsedSec,
        'latitude': latitude,
        'longitude': longitude,
        'field_x_m': fieldXM,
        'field_y_m': fieldYM,
        'speed_kmh': speedKmh,
        'acceleration_mps2': accelerationMps2,
        'distance_delta_m': distanceDeltaM,
        'cumulative_distance_m': cumulativeDistanceM,
        'intensity_zone': intensityZone,
      };

  static int _i(dynamic v) => int.tryParse('$v') ?? (v is num ? v.toInt() : 0);
  static int? _in(dynamic v) {
    if (v == null) return null;
    final s = '$v'.trim();
    if (s.isEmpty || s == 'null') return null;
    return int.tryParse(s) ?? (v is num ? v.toInt() : null);
  }

  static double _d(dynamic v) => double.tryParse('$v') ?? (v is num ? v.toDouble() : 0);
  static double? _dn(dynamic v) {
    if (v == null) return null;
    final s = '$v'.trim();
    if (s.isEmpty || s == 'null') return null;
    return double.tryParse(s) ?? (v is num ? v.toDouble() : null);
  }

  static String? _sn(dynamic v) {
    final s = '${v ?? ''}'.trim();
    return s.isEmpty || s == 'null' ? null : s;
  }

  static DateTime? _dt(dynamic v) {
    final s = '${v ?? ''}'.trim();
    if (s.isEmpty || s == 'null') return null;
    return DateTime.tryParse(s.replaceFirst(' ', 'T'));
  }
}

class TrackerSessionSummaryModel {
  final int? sessionId;
  final int? playerId;
  final double distanceM;
  final double sprintDistanceM;
  final double hirDistanceM;
  final double vhirDistanceM;
  final double avgSpeedKmh;
  final double maxSpeedKmh;
  final int sprintCount;
  final int accelerationCount;
  final int decelerationCount;
  final double loadScore;
  final int durationSec;

  const TrackerSessionSummaryModel({
    this.sessionId,
    this.playerId,
    this.distanceM = 0,
    this.sprintDistanceM = 0,
    this.hirDistanceM = 0,
    this.vhirDistanceM = 0,
    this.avgSpeedKmh = 0,
    this.maxSpeedKmh = 0,
    this.sprintCount = 0,
    this.accelerationCount = 0,
    this.decelerationCount = 0,
    this.loadScore = 0,
    this.durationSec = 0,
  });

  factory TrackerSessionSummaryModel.fromJson(Map<String, dynamic> json) {
    final summary = Map<String, dynamic>.from(json['summary'] as Map? ?? json);
    return TrackerSessionSummaryModel(
      sessionId: _in(summary['session_id']),
      playerId: _in(summary['player_id']),
      distanceM: _d(summary['distance_m']),
      sprintDistanceM: _d(summary['sprint_distance_m']),
      hirDistanceM: _d(summary['hir_distance_m'] ?? summary['high_speed_distance_m']),
      vhirDistanceM: _d(summary['vhir_distance_m']),
      avgSpeedKmh: _d(summary['avg_speed_kmh']),
      maxSpeedKmh: _d(summary['max_speed_kmh']),
      sprintCount: _i(summary['sprint_count']),
      accelerationCount: _i(summary['acceleration_count'] ?? summary['accel_count']),
      decelerationCount: _i(summary['deceleration_count'] ?? summary['decel_count']),
      loadScore: _d(summary['load_score']),
      durationSec: _i(summary['duration_sec']),
    );
  }

  bool get hasData => distanceM > 0 || maxSpeedKmh > 0 || sprintCount > 0 || loadScore > 0;

  static int _i(dynamic v) => int.tryParse('$v') ?? (v is num ? v.toInt() : 0);
  static int? _in(dynamic v) {
    if (v == null) return null;
    final s = '$v'.trim();
    if (s.isEmpty || s == 'null') return null;
    return int.tryParse(s) ?? (v is num ? v.toInt() : null);
  }

  static double _d(dynamic v) => double.tryParse('$v') ?? (v is num ? v.toDouble() : 0);
}

class TrackerSessionReportModel {
  final Map<String, dynamic> session;
  final TrackerSessionSummaryModel summary;
  final List<TrackerSessionPointModel> points;
  final List<TrackerHeatPoint> heatmap;

  const TrackerSessionReportModel({
    required this.session,
    required this.summary,
    required this.points,
    required this.heatmap,
  });

  factory TrackerSessionReportModel.fromJson(Map<String, dynamic> json) {
    return TrackerSessionReportModel(
      session: Map<String, dynamic>.from(json['session'] as Map? ?? const {}),
      summary: TrackerSessionSummaryModel.fromJson(Map<String, dynamic>.from(json['summary'] as Map? ?? const {})),
      points: (json['points'] as List? ?? const [])
          .map((e) => TrackerSessionPointModel.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
      heatmap: (json['heatmap'] as List? ?? const [])
          .map((e) => TrackerHeatPoint.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(),
    );
  }
}
