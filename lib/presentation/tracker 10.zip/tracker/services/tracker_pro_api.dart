import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/action_tracker_protocol.dart';
import '../models/tracker_pro_models.dart';

class TrackerProApi {
  TrackerProApi({this.apiBaseUrl = 'https://sportotekaapp.ru/api/tracker'});

  final String apiBaseUrl;

  Future<List<TrackerPlayerOption>> loadPlayers({required int teamId}) async {
    final json = await _get('$apiBaseUrl/get_tracker_players.php?team_id=$teamId');
    final list = (json['players'] as List? ?? json['data'] as List? ?? const []);
    return list.map((e) => TrackerPlayerOption.fromJson(Map<String, dynamic>.from(e as Map))).where((p) => p.id > 0).toList();
  }

  Future<List<TrackerDeviceModel>> loadDevices({required int teamId}) async {
    final json = await _get('$apiBaseUrl/get_tracker_devices.php?team_id=$teamId');
    final list = (json['devices'] as List? ?? const []);
    return list.map((e) => TrackerDeviceModel.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> registerOrBindDevice({
    required int clubId,
    required int teamId,
    required String deviceUuid,
    required String deviceName,
    int? playerId,
    int? batteryPercent,
  }) async {
    await _post('$apiBaseUrl/save_tracker_device.php', {
      'club_id': clubId,
      'team_id': teamId,
      'player_id': playerId,
      'device_uuid': deviceUuid,
      'device_name': deviceName,
      'battery_percent': batteryPercent,
    });
  }

  Future<Map<String, dynamic>> saveGpsSession({
    required int clubId,
    required int teamId,
    int? userId,
    int? playerId,
    required String deviceUuid,
    required String deviceName,
    required ActionTrackerRecord record,
    required List<ActionTrackerGpsPoint> points,
    int? fieldId,
  }) async {
    return _post('$apiBaseUrl/save_tracker_session.php', {
      'club_id': clubId,
      'team_id': teamId,
      'user_id': userId,
      'player_id': playerId,
      'device_uuid': deviceUuid,
      'device_name': deviceName,
      'record': record.toJson(),
      'points': points.map((p) => p.toJson()).toList(),
      'field_id': fieldId,
    });
  }


  Future<Map<String, dynamic>> processSession({required int sessionId}) async {
    return _get('$apiBaseUrl/process_tracker_session.php?session_id=$sessionId');
  }

  Future<TrackerDashboardModel> loadDashboard({required int teamId}) async {
    final json = await _get('$apiBaseUrl/get_tracker_dashboard.php?team_id=$teamId');
    return TrackerDashboardModel.fromJson(json);
  }

  Future<List<TrackerSessionModel>> loadSessions({required int teamId, int? playerId}) async {
    final url = '$apiBaseUrl/get_tracker_sessions.php?team_id=$teamId${playerId == null ? '' : '&player_id=$playerId'}';
    try {
      final json = await _get(url);
      final list = (json['sessions'] as List? ?? json['data'] as List? ?? const []);
      return list.map((e) => TrackerSessionModel.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (e) {
      debugPrint('[TrackerProApi] loadSessions failed, показываю пустой список: $e');
      return const <TrackerSessionModel>[];
    }
  }

  Future<List<TrackerHeatPoint>> loadHeatmap({required int teamId, int? playerId, int? sessionId, int? fieldId}) async {
    final url = '$apiBaseUrl/get_tracker_heatmap.php?team_id=$teamId'
        '${playerId == null ? '' : '&player_id=$playerId'}'
        '${sessionId == null ? '' : '&session_id=$sessionId'}'
        '${fieldId == null ? '' : '&field_id=$fieldId'}';
    try {
      final json = await _get(url);
      final list = (json['points'] as List? ?? json['data'] as List? ?? const []);
      return list.map((e) => TrackerHeatPoint.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (e) {
      debugPrint('[TrackerProApi] loadHeatmap failed, показываю пустую теплокарту: $e');
      return const <TrackerHeatPoint>[];
    }
  }



  Future<List<TrackerFieldModel>> loadFields({required int teamId}) async {
    final json = await _get('$apiBaseUrl/get_tracker_fields.php?team_id=$teamId');
    final list = (json['fields'] as List? ?? const []);
    return list.map((e) => TrackerFieldModel.fromJson(Map<String, dynamic>.from(e as Map))).toList();
  }

  Future<void> saveField({
    required int clubId,
    required int teamId,
    required TrackerFieldModel field,
  }) async {
    await _post('$apiBaseUrl/save_tracker_field.php', field.toJson(
      overrideClubId: clubId,
      overrideTeamId: teamId,
    ));
  }

  Future<TrackerSpeedSettings> loadSettings({required int teamId}) async {
    final json = await _get('$apiBaseUrl/get_tracker_settings.php?team_id=$teamId');
    return TrackerSpeedSettings.fromJson(Map<String, dynamic>.from(json['settings'] as Map? ?? const {}));
  }

  Future<void> saveSettings({required int teamId, required TrackerSpeedSettings settings}) async {
    await _post('$apiBaseUrl/save_tracker_settings.php', {
      'team_id': teamId,
      ...settings.toJson(),
    });
  }



  Future<List<TrackerSessionPointModel>> loadSessionPoints({
    required int sessionId,
    int? playerId,
  }) async {
    final url = '$apiBaseUrl/get_tracker_session_points.php?session_id=$sessionId'
        '${playerId == null ? '' : '&player_id=$playerId'}';
    try {
      final json = await _get(url);
      final list = (json['points'] as List? ?? json['data'] as List? ?? const []);
      return list.map((e) => TrackerSessionPointModel.fromJson(Map<String, dynamic>.from(e as Map))).toList();
    } catch (e) {
      debugPrint('[TrackerProApi] loadSessionPoints failed, показываю пустой график: $e');
      return const <TrackerSessionPointModel>[];
    }
  }

  Future<TrackerSessionSummaryModel> loadSessionSummary({
    required int sessionId,
    int? playerId,
  }) async {
    final url = '$apiBaseUrl/get_tracker_session_summary.php?session_id=$sessionId'
        '${playerId == null ? '' : '&player_id=$playerId'}';
    try {
      final json = await _get(url);
      return TrackerSessionSummaryModel.fromJson(json);
    } catch (e) {
      debugPrint('[TrackerProApi] loadSessionSummary failed, показываю нулевые KPI: $e');
      return TrackerSessionSummaryModel(sessionId: sessionId, playerId: playerId);
    }
  }

  Future<TrackerSessionReportModel> loadSessionReport({
    required int sessionId,
    int? playerId,
  }) async {
    final url = '$apiBaseUrl/get_tracker_session_report.php?session_id=$sessionId'
        '${playerId == null ? '' : '&player_id=$playerId'}';
    try {
      final json = await _get(url);
      return TrackerSessionReportModel.fromJson(json);
    } catch (e) {
      debugPrint('[TrackerProApi] loadSessionReport failed, показываю пустой отчёт: $e');
      return TrackerSessionReportModel(
        session: <String, dynamic>{'id': sessionId},
        summary: TrackerSessionSummaryModel(sessionId: sessionId, playerId: playerId),
        points: const <TrackerSessionPointModel>[],
        heatmap: const <TrackerHeatPoint>[],
      );
    }
  }

  Future<int> createTrackerSession({
    required int clubId,
    required int teamId,
    int? fieldId,
    required String title,
    String type = 'training',
    String source = 'live',
  }) async {
    final json = await _post('$apiBaseUrl/create_tracker_session.php', {
      'club_id': clubId,
      'team_id': teamId,
      'field_id': fieldId,
      'title': title,
      'type': type,
      'source': source,
    });
    return int.tryParse('${json['session_id'] ?? json['id'] ?? 0}') ?? 0;
  }

  Future<void> finishTrackerSession({required int sessionId}) async {
    await _post('$apiBaseUrl/finish_tracker_session.php', {'session_id': sessionId});
  }

  Future<void> saveTrackerSessionPoint({required TrackerSessionPointModel point}) async {
    await _post('$apiBaseUrl/save_tracker_session_point.php', point.toJson());
  }

  Future<Map<String, dynamic>> _get(String url) async {
    final response = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 25));
    debugPrint('[TrackerProApi] GET ${response.statusCode} $url');
    if (response.statusCode >= 400 || kDebugMode) {
      debugPrint('[TrackerProApi] BODY ${_shortBody(response.body)}');
    }
    return _decode(response.body, url: url, statusCode: response.statusCode);
  }

  Future<Map<String, dynamic>> _post(String url, Map<String, dynamic> body) async {
    final response = await http
        .post(Uri.parse(url), headers: {'Content-Type': 'application/json; charset=utf-8'}, body: jsonEncode(body))
        .timeout(const Duration(seconds: 35));
    debugPrint('[TrackerProApi] POST ${response.statusCode} $url');
    if (response.statusCode >= 400 || kDebugMode) {
      debugPrint('[TrackerProApi] BODY ${_shortBody(response.body)}');
    }
    return _decode(response.body, url: url, statusCode: response.statusCode);
  }

  Map<String, dynamic> _decode(String body, {required String url, required int statusCode}) {
    final trimmed = body.trim();

    if (trimmed.isEmpty) {
      throw Exception('Пустой ответ API ($statusCode): $url. Проверьте, что PHP-файл загружен и db.php подключается.');
    }

    final start = trimmed.indexOf('{');
    final end = trimmed.lastIndexOf('}');
    if (start < 0 || end < start) {
      throw Exception('API вернул не JSON ($statusCode): $url\nОтвет: ${_shortBody(trimmed)}');
    }

    dynamic decoded;
    try {
      decoded = jsonDecode(trimmed.substring(start, end + 1));
    } on FormatException catch (e) {
      throw Exception('Ошибка JSON от API ($statusCode): $url\n$e\nОтвет: ${_shortBody(trimmed)}');
    }

    if (decoded is! Map) {
      throw Exception('Некорректный JSON API ($statusCode): $url\nОтвет: ${_shortBody(trimmed)}');
    }

    final map = Map<String, dynamic>.from(decoded);
    if (statusCode >= 400) {
      final message = '${map['message'] ?? map['error'] ?? 'HTTP $statusCode'}';
      throw Exception('Ошибка API ($statusCode): $message\n$url');
    }
    if (map['success'] == false || map['status'] == 'error') {
      final message = '${map['message'] ?? 'Ошибка API'}';
      final error = '${map['error'] ?? ''}'.trim();
      throw Exception(error.isEmpty ? '$message\n$url' : '$message: $error\n$url');
    }
    return map;
  }

  String _shortBody(String body) {
    final compact = body.replaceAll(RegExp(r'\s+'), ' ').trim();
    return compact.substring(0, math.min(compact.length, 900));
  }
}
