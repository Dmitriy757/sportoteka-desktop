import 'dart:async';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/club_workspace/cmr_context_ai_layer.dart';
import 'package:sportoteka/presentation/workspace_os/sportoteka_workspace_icons.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_live_blocks.dart';

/// Самописный редактор заметок Sportoteka OS.
///
/// Редактор не зависит от стороннего rich-text пакета: форматирование хранится
/// в простом переносимом тексте, а контекст игрока, тренера или команды
/// отображается отдельно и не смешивается с содержимым документа.
class WorkspaceDocumentEditor extends StatefulWidget {
  const WorkspaceDocumentEditor({
    super.key,
    required this.initialTitle,
    this.initialBody = '',
    this.readOnly = false,
    this.titleReadOnly = false,
    this.onSave,
    this.contextLabel = 'Рабочая заметка',
    this.contextName = '',
    this.documentType = 'Заметка',
    this.autoSave = true,
    this.showTemplates = true,
    this.onClose,
    this.liveBlocksKey,
    this.aiClubId,
    this.aiUserId,
    this.aiTeamId,
    this.aiClubName = '',
    this.aiTeamName = '',
    this.aiDocumentKey,
    this.aiExtraPayload = const <String, dynamic>{},
    this.onUploadImage,
    this.compactWorkspaceChrome = false,
  });

  final String initialTitle;
  final String initialBody;
  final bool readOnly;
  final bool titleReadOnly;
  final Future<void> Function(String title, String body)? onSave;
  final String contextLabel;
  final String contextName;
  final String documentType;
  final bool autoSave;
  final bool showTemplates;
  final VoidCallback? onClose;
  final String? liveBlocksKey;
  final int? aiClubId;
  final int? aiUserId;
  final int? aiTeamId;
  final String aiClubName;
  final String aiTeamName;
  final String? aiDocumentKey;
  final Map<String, dynamic> aiExtraPayload;
  final Future<String?> Function(String filePath)? onUploadImage;

  /// Для документов, уже открытых внутри плавающего окна SPORTOTEKA OS.
  /// В этом режиме внешняя шапка окна/сущности уже показывает название,
  /// поэтому внутренний ряд SPORTOTEKA OS + Save скрывается, как в Word.
  final bool compactWorkspaceChrome;

  @override
  State<WorkspaceDocumentEditor> createState() =>
      _WorkspaceDocumentEditorState();
}

class _WorkspaceDocumentEditorState extends State<WorkspaceDocumentEditor> {
  static const _green = Color(0xFF0B8F55);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);
  static const _line = Color(0xFFE6EAE7);
  static const _surface = Colors.white;

  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;
  final FocusNode _bodyFocus = FocusNode();

  Timer? _autoSaveTimer;
  bool _saving = false;
  bool _saveQueued = false;
  bool _saveError = false;
  int _revision = 0;
  int _savedRevision = 0;

  List<WorkspaceLiveBlock> _liveBlocks = <WorkspaceLiveBlock>[];
  bool _liveBlocksLoading = false;
  bool _slashLiveBlockPending = false;

  // На широком экране вставка живого блока открывается прямо внутри
  // текущего окна редактора — отдельной правой панелью, а не modal/bottom sheet.
  WorkspaceLiveBlockType? _sidePickerType;
  bool _aiExpanded = false;
  bool _showImportedTextBlock = true;

  // Word-подобный режим: текст хранится в переносимом markdown-подобном
  // формате, но на странице отображается как визуальный документ.
  bool _visualMode = true;
  int? _activeVisualBlockStart;
  int? _activeVisualBlockEnd;
  _WorkspaceRichTextController? _visualBlockController;
  FocusNode? _visualBlockFocus;
  int? _selectedImageStart;
  int? _selectedTableStart;
  double _imageResizeDrag = 0;

  final List<String> _bodyHistory = <String>[];
  int _bodyHistoryIndex = -1;
  bool _historyRestoring = false;
  String _lastHistoryBody = '';

  bool get _canUndo => _bodyHistoryIndex > 0;
  bool get _canRedo =>
      _bodyHistoryIndex >= 0 && _bodyHistoryIndex < _bodyHistory.length - 1;

  bool get _dirty => _revision != _savedRevision;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.initialTitle);
    _bodyController = TextEditingController(text: widget.initialBody);
    _titleController.addListener(_handleEdit);
    _bodyController.addListener(_handleEdit);
    _lastHistoryBody = _bodyController.text;
    _bodyHistory.add(_bodyController.text);
    _bodyHistoryIndex = 0;
    _loadLiveBlocks();
  }

  @override
  void didUpdateWidget(covariant WorkspaceDocumentEditor oldWidget) {
    super.didUpdateWidget(oldWidget);
    final blocksKeyChanged =
        _liveBlocksKeyFor(oldWidget) != _effectiveLiveBlocksKey;
    if (blocksKeyChanged) _loadLiveBlocks();
    if (_dirty || _saving) return;
    final titleChanged = oldWidget.initialTitle != widget.initialTitle;
    final bodyChanged = oldWidget.initialBody != widget.initialBody;
    if (!titleChanged && !bodyChanged) return;

    _titleController.removeListener(_handleEdit);
    _bodyController.removeListener(_handleEdit);
    if (titleChanged) _titleController.text = widget.initialTitle;
    if (bodyChanged) _bodyController.text = widget.initialBody;
    _titleController.addListener(_handleEdit);
    _bodyController.addListener(_handleEdit);
    _revision = 0;
    _savedRevision = 0;
    if (bodyChanged) {
      _lastHistoryBody = _bodyController.text;
      _bodyHistory
        ..clear()
        ..add(_bodyController.text);
      _bodyHistoryIndex = 0;
      _finishVisualBlockEditing(rebuild: false);
    }
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _titleController.removeListener(_handleEdit);
    _bodyController.removeListener(_handleEdit);
    _titleController.dispose();
    _bodyController.dispose();
    _bodyFocus.dispose();
    _visualBlockController?.dispose();
    _visualBlockFocus?.dispose();
    super.dispose();
  }

  String _liveBlocksKeyFor(WorkspaceDocumentEditor source) {
    final explicit = source.liveBlocksKey?.trim() ?? '';
    if (explicit.isNotEmpty) return explicit;
    final seed =
        '${source.contextLabel}|${source.contextName}|${source.documentType}|${source.initialTitle}';
    var hash = 0x811C9DC5;
    for (final code in seed.codeUnits) {
      hash ^= code;
      hash = (hash * 0x01000193) & 0xFFFFFFFF;
    }
    return 'workspace_doc_${hash.toRadixString(16).padLeft(8, '0')}';
  }

  String get _effectiveLiveBlocksKey => _liveBlocksKeyFor(widget);

  Future<void> _loadLiveBlocks() async {
    if (mounted) setState(() => _liveBlocksLoading = true);
    try {
      final blocks = await WorkspaceLiveBlocksRepository(
              documentKey: _effectiveLiveBlocksKey)
          .load();
      if (!mounted) return;
      setState(() {
        _liveBlocks = blocks;
        _liveBlocksLoading = false;
      });
    } catch (_) {
      if (mounted) setState(() => _liveBlocksLoading = false);
    }
  }

  Future<void> _persistLiveBlocks() async {
    try {
      await WorkspaceLiveBlocksRepository(documentKey: _effectiveLiveBlocksKey)
          .save(_liveBlocks);
    } catch (_) {
      if (!mounted) return;
      setState(() => _saveError = true);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text(
                'Изменение сохранено локально, но пока не синхронизировано с сервером')),
      );
    }
  }

  void _checkSlashLiveBlockCommand() {
    if (widget.readOnly || _slashLiveBlockPending) return;
    final lower = _bodyController.text.toLowerCase();
    for (final reportCommand in const <String>['/отчет', '/отчёт', '/report']) {
      if (lower.endsWith(reportCommand)) {
        _slashLiveBlockPending = true;
        WidgetsBinding.instance.addPostFrameCallback((_) async {
          if (!mounted) return;
          final current = _bodyController.text;
          if (current.toLowerCase().endsWith(reportCommand)) {
            final next =
                current.substring(0, current.length - reportCommand.length);
            _bodyController.value = TextEditingValue(
                text: next,
                selection: TextSelection.collapsed(offset: next.length));
          }
          await _buildSmartReport();
          if (mounted) _slashLiveBlockPending = false;
        });
        return;
      }
    }
    const commands = <String, WorkspaceLiveBlockType>{
      '/план': WorkspaceLiveBlockType.plan,
      '/plan': WorkspaceLiveBlockType.plan,
      '/матч': WorkspaceLiveBlockType.match,
      '/match': WorkspaceLiveBlockType.match,
      '/тренировка': WorkspaceLiveBlockType.training,
      '/training': WorkspaceLiveBlockType.training,
      '/игрок': WorkspaceLiveBlockType.player,
      '/player': WorkspaceLiveBlockType.player,
      '/tracker': WorkspaceLiveBlockType.tracker,
      '/трекер': WorkspaceLiveBlockType.tracker,
      '/тест': WorkspaceLiveBlockType.testing,
      '/testing': WorkspaceLiveBlockType.testing,
      '/видео': WorkspaceLiveBlockType.video,
      '/video': WorkspaceLiveBlockType.video,
      '/документ': WorkspaceLiveBlockType.document,
      '/document': WorkspaceLiveBlockType.document,
    };
    String command = '';
    WorkspaceLiveBlockType? type;
    for (final entry in commands.entries) {
      if (lower.endsWith(entry.key)) {
        command = entry.key;
        type = entry.value;
        break;
      }
    }
    if (command.isEmpty || type == null) return;
    _slashLiveBlockPending = true;
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final current = _bodyController.text;
      if (current.toLowerCase().endsWith(command)) {
        final next = current.substring(0, current.length - command.length);
        _bodyController.value = TextEditingValue(
            text: next,
            selection: TextSelection.collapsed(offset: next.length));
      }
      await _insertLiveBlock(type!);
      if (mounted) _slashLiveBlockPending = false;
    });
  }

  Future<void> _insertLiveBlock(WorkspaceLiveBlockType type) async {
    if (widget.readOnly) return;

    final media = MediaQuery.maybeOf(context);
    final width = media?.size.width ?? 0;
    final shortestSide = media == null
        ? 0.0
        : (media.size.width < media.size.height
            ? media.size.width
            : media.size.height);

    // На desktop/tablet всегда открываем picker внутри текущего окна редактора.
    // Это не зависит от фактической ширины самого OS-окна.
    if (width >= 600 || shortestSide >= 600) {
      if (!mounted) return;
      setState(() => _sidePickerType = type);
      return;
    }

    final block = await showWorkspaceLiveBlockPicker(context, type);
    if (block == null || !mounted) return;
    await _acceptLiveBlock(block);
  }

  Future<void> _acceptLiveBlock(WorkspaceLiveBlock block) async {
    final duplicate = _liveBlocks.any((item) =>
        item.type == block.type &&
        ((item.entityId > 0 &&
                block.entityId > 0 &&
                item.entityId == block.entityId) ||
            (item.entityKey.isNotEmpty && item.entityKey == block.entityKey)));
    if (duplicate) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Этот объект уже вставлен в документ')),
        );
      }
      return;
    }

    if (!mounted) return;
    setState(() {
      _liveBlocks = <WorkspaceLiveBlock>[..._liveBlocks, block];
      _sidePickerType = null;
    });
    await _persistLiveBlocks();
  }

  Future<void> _insertPlanBlock() =>
      _insertLiveBlock(WorkspaceLiveBlockType.plan);

  Future<void> _buildSmartReport() async {
    if (widget.readOnly) return;
    if (_liveBlocks.isEmpty) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text(
                  'Сначала вставьте Матч, План, Игрока, Tracker или другой живой блок')),
        );
      }
      return;
    }

    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    final date = '${two(now.day)}.${two(now.month)}.${now.year}';
    final lines = <String>[
      '# ОТЧЁТ SPORTOTEKA',
      '',
      'Дата: $date',
      if (widget.contextName.trim().isNotEmpty)
        'Контекст: ${widget.contextName.trim()}',
      '',
      '## Использованные материалы',
      '',
    ];

    for (final block in _liveBlocks) {
      lines.addAll(_reportLinesForBlock(block));
    }

    lines.addAll(<String>[
      '## Ключевые наблюдения',
      '',
      '• ',
      '• ',
      '• ',
      '',
      '## Выводы и следующие действия',
      '',
      '1. ',
      '2. ',
      '3. ',
    ]);

    final generated = lines.join('\n');
    final current = _bodyController.text.trimRight();
    final next = current.isEmpty ? generated : '$current\n\n---\n\n$generated';
    _bodyController.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: next.length),
    );
    _bodyFocus.requestFocus();
  }

  List<String> _reportLinesForBlock(WorkspaceLiveBlock block) {
    final label = _editorTitleForType(block.type);
    final details = <String>[
      if (block.date.trim().isNotEmpty) block.date.trim(),
      if (block.subtitle.trim().isNotEmpty) block.subtitle.trim(),
    ].join(' · ');
    final lines = <String>[
      '### $label — ${block.title}',
      if (details.isNotEmpty) details,
    ];

    final meta = block.meta;
    void add(String title, List<String> keys) {
      for (final key in keys) {
        final value = '${meta[key] ?? ''}'.trim();
        if (value.isNotEmpty && value.toLowerCase() != 'null') {
          lines.add('• $title: $value');
          return;
        }
      }
    }

    switch (block.type) {
      case WorkspaceLiveBlockType.match:
        add('Соперник', const <String>['opponent', 'opponent_name', 'rival']);
        add('Счёт', const <String>['score', 'result', 'final_score']);
        add('Турнир',
            const <String>['competition_name', 'competition', 'event_type']);
        break;
      case WorkspaceLiveBlockType.training:
        add('Место', const <String>['location', 'venue', 'place']);
        add('Команда', const <String>['team_name']);
        break;
      case WorkspaceLiveBlockType.plan:
        add('Длительность',
            const <String>['duration', 'duration_min', 'minutes']);
        add('Игроков', const <String>['players_count', 'player_count']);
        break;
      case WorkspaceLiveBlockType.player:
        add('Команда', const <String>['team_name']);
        add('Амплуа', const <String>['position', 'amplua']);
        add('Номер', const <String>['number', 'shirt_number']);
        break;
      case WorkspaceLiveBlockType.tracker:
        add('Дистанция', const <String>['distance_m', 'total_distance_m']);
        add('Max скорость', const <String>['max_speed_kmh', 'max_speed']);
        add('Max ЧСС', const <String>['max_hr', 'max_bpm', 'heart_rate_max']);
        add('Спринты', const <String>['sprints', 'sprint_count']);
        break;
      case WorkspaceLiveBlockType.testing:
        add('Категория', const <String>['category', 'stage', 'type']);
        break;
      case WorkspaceLiveBlockType.video:
        add('Материал', const <String>['video_title', 'name', 'type']);
        break;
      case WorkspaceLiveBlockType.document:
        add('Тип', const <String>['document_type', 'type', 'mime_type']);
        break;
    }
    lines.add('');
    return lines;
  }

  Future<void> _replaceLiveBlock(int index, WorkspaceLiveBlock block) async {
    if (index < 0 || index >= _liveBlocks.length) return;
    final next = <WorkspaceLiveBlock>[..._liveBlocks];
    next[index] = block;
    setState(() => _liveBlocks = next);
    await _persistLiveBlocks();
  }

  Future<void> _removeLiveBlock(int index) async {
    if (index < 0 || index >= _liveBlocks.length) return;
    final next = <WorkspaceLiveBlock>[..._liveBlocks]..removeAt(index);
    setState(() => _liveBlocks = next);
    await _persistLiveBlocks();
  }

  void _handleEdit() {
    _revision += 1;
    _saveError = false;

    final body = _bodyController.text;
    if (!_historyRestoring && body != _lastHistoryBody) {
      if (_bodyHistoryIndex < _bodyHistory.length - 1) {
        _bodyHistory.removeRange(_bodyHistoryIndex + 1, _bodyHistory.length);
      }
      _bodyHistory.add(body);
      if (_bodyHistory.length > 80) {
        _bodyHistory.removeAt(0);
      }
      _bodyHistoryIndex = _bodyHistory.length - 1;
      _lastHistoryBody = body;
    }

    _checkSlashLiveBlockCommand();
    if (mounted) setState(() {});
    if (!widget.readOnly && widget.autoSave && widget.onSave != null) {
      _autoSaveTimer?.cancel();
      _autoSaveTimer = Timer(const Duration(milliseconds: 1100), _save);
    }
  }

  void _restoreHistoryAt(int index) {
    if (index < 0 || index >= _bodyHistory.length) return;
    _finishVisualBlockEditing(rebuild: false);
    _historyRestoring = true;
    final text = _bodyHistory[index];
    _bodyController.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: text.length),
    );
    _historyRestoring = false;
    _bodyHistoryIndex = index;
    _lastHistoryBody = text;
    if (mounted) setState(() {});
  }

  void _undo() {
    if (widget.readOnly || !_canUndo) return;
    _restoreHistoryAt(_bodyHistoryIndex - 1);
  }

  void _redo() {
    if (widget.readOnly || !_canRedo) return;
    _restoreHistoryAt(_bodyHistoryIndex + 1);
  }

  Future<void> _save() async {
    if (widget.readOnly || widget.onSave == null || !_dirty) return;
    if (_saving) {
      _saveQueued = true;
      return;
    }

    _autoSaveTimer?.cancel();
    final revision = _revision;
    setState(() {
      _saving = true;
      _saveError = false;
    });

    try {
      await widget.onSave!(
        _titleController.text.trim(),
        _bodyController.text,
      );
      if (!mounted) return;
      setState(() {
        _savedRevision = revision;
        _saving = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _saveError = true;
      });
    }

    if (!mounted) return;
    final shouldSaveAgain = _saveQueued || _dirty;
    _saveQueued = false;
    if (shouldSaveAgain && !_saveError) {
      _autoSaveTimer = Timer(const Duration(milliseconds: 260), _save);
    }
  }

  Future<void> _requestClose() async {
    if (_saving) {
      _saveQueued = true;
      while (_saving && mounted) {
        await Future<void>.delayed(const Duration(milliseconds: 40));
      }
    }
    if (_dirty && widget.onSave != null) await _save();
    if (!mounted || _saveError) return;
    widget.onClose?.call();
  }

  TextEditingController get _editingController =>
      _visualMode && _visualBlockController != null
          ? _visualBlockController!
          : _bodyController;

  FocusNode get _editingFocus =>
      _visualMode && _visualBlockFocus != null ? _visualBlockFocus! : _bodyFocus;

  void _focusEditing() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _editingFocus.requestFocus();
    });
  }

  void _syncVisualBlock() {
    final controller = _visualBlockController;
    final start = _activeVisualBlockStart;
    final end = _activeVisualBlockEnd;
    if (controller == null || start == null || end == null) return;
    final body = _bodyController.text;
    if (start < 0 || start > body.length || end < start || end > body.length) {
      return;
    }
    final replacement = controller.text;
    final next = body.replaceRange(start, end, replacement);
    final local = controller.selection.isValid
        ? controller.selection.extentOffset.clamp(0, replacement.length).toInt()
        : replacement.length;
    _activeVisualBlockEnd = start + replacement.length;
    _bodyController.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: start + local),
    );
  }

  void _syncVisualBlockIfNeeded() {
    if (_visualMode && _visualBlockController != null) _syncVisualBlock();
  }

  void _finishVisualBlockEditing({bool rebuild = true}) {
    final controller = _visualBlockController;
    if (controller != null) {
      controller.removeListener(_syncVisualBlock);
      controller.dispose();
    }
    _visualBlockFocus?.dispose();
    _visualBlockController = null;
    _visualBlockFocus = null;
    _activeVisualBlockStart = null;
    _activeVisualBlockEnd = null;
    if (rebuild && mounted) setState(() {});
  }

  void _startVisualBlockEditing(_WorkspaceDocBlock block) {
    if (widget.readOnly || block.kind == _WorkspaceDocBlockKind.image ||
        block.kind == _WorkspaceDocBlockKind.rule ||
        block.kind == _WorkspaceDocBlockKind.table) {
      return;
    }
    _finishVisualBlockEditing(rebuild: false);
    final controller = _WorkspaceRichTextController(text: block.raw);
    final focus = FocusNode();
    _visualBlockController = controller;
    _visualBlockFocus = focus;
    _activeVisualBlockStart = block.start;
    _activeVisualBlockEnd = block.end;
    _selectedImageStart = null;
    controller.addListener(_syncVisualBlock);
    setState(() {});
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      focus.requestFocus();
      controller.selection = TextSelection.collapsed(offset: controller.text.length);
    });
  }

  void _setVisualMode(bool value) {
    if (_visualMode == value) return;
    _finishVisualBlockEditing(rebuild: false);
    _selectedImageStart = null;
    setState(() => _visualMode = value);
    if (!value) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _bodyFocus.requestFocus();
      });
    }
  }

  bool _ensureVisualFormattingTarget() {
    if (!_visualMode || _visualBlockController != null) return true;
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Сначала нажмите на абзац, который хотите отформатировать'),
          duration: Duration(milliseconds: 1400),
        ),
      );
    }
    return false;
  }

  void _wrapSelection(String left, String right) {
    if (widget.readOnly || !_ensureVisualFormattingTarget()) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final end = selection.isValid
        ? selection.end.clamp(start, value.text.length).toInt()
        : start;
    final selected = value.text.substring(start, end);
    final replacement = '$left$selected$right';
    final text = value.text.replaceRange(start, end, replacement);
    final cursor =
        selected.isEmpty ? start + left.length : start + replacement.length;
    controller.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: cursor),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  void _prefixSelection(String prefix) {
    if (widget.readOnly || !_ensureVisualFormattingTarget()) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    final rawStart = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final rawEnd = selection.isValid
        ? selection.end.clamp(rawStart, value.text.length).toInt()
        : rawStart;
    final lineStart =
        value.text.lastIndexOf('\n', rawStart == 0 ? 0 : rawStart - 1) + 1;
    final nextBreak = value.text.indexOf('\n', rawEnd);
    final lineEnd = nextBreak < 0 ? value.text.length : nextBreak;
    final block = value.text.substring(lineStart, lineEnd);
    final replacement =
        block.split('\n').map((line) => '$prefix$line').join('\n');
    controller.value = TextEditingValue(
      text: value.text.replaceRange(lineStart, lineEnd, replacement),
      selection: TextSelection(
        baseOffset: lineStart,
        extentOffset: lineStart + replacement.length,
      ),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  void _replaceBodySelection(String replacement, {bool selectReplacement = false}) {
    if (widget.readOnly) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    final start = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final end = selection.isValid
        ? selection.end.clamp(start, value.text.length).toInt()
        : start;
    final next = value.text.replaceRange(start, end, replacement);
    final newSelection = selectReplacement
        ? TextSelection(baseOffset: start, extentOffset: start + replacement.length)
        : TextSelection.collapsed(offset: start + replacement.length);
    controller.value = TextEditingValue(text: next, selection: newSelection);
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  Future<void> _copySelection() async {
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    if (!selection.isValid || selection.isCollapsed) {
      await _copyDocument();
      return;
    }
    final start = selection.start.clamp(0, value.text.length).toInt();
    final end = selection.end.clamp(start, value.text.length).toInt();
    await Clipboard.setData(ClipboardData(text: value.text.substring(start, end)));
  }

  Future<void> _cutSelection() async {
    if (widget.readOnly) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    if (!selection.isValid || selection.isCollapsed) return;
    final start = selection.start.clamp(0, value.text.length).toInt();
    final end = selection.end.clamp(start, value.text.length).toInt();
    await Clipboard.setData(ClipboardData(text: value.text.substring(start, end)));
    controller.value = TextEditingValue(
      text: value.text.replaceRange(start, end, ''),
      selection: TextSelection.collapsed(offset: start),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  Future<void> _pasteClipboard() async {
    if (widget.readOnly) return;
    final data = await Clipboard.getData('text/plain');
    final text = data?.text ?? '';
    if (text.isEmpty) return;
    _replaceBodySelection(text);
  }

  void _selectAllBody() {
    if (_editingController.text.isEmpty) return;
    _editingController.selection = TextSelection(
      baseOffset: 0,
      extentOffset: _editingController.text.length,
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  void _duplicateSelection() {
    if (widget.readOnly) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    if (!selection.isValid || selection.isCollapsed) return;
    final start = selection.start.clamp(0, value.text.length).toInt();
    final end = selection.end.clamp(start, value.text.length).toInt();
    final selected = value.text.substring(start, end);
    controller.value = TextEditingValue(
      text: value.text.replaceRange(end, end, selected),
      selection: TextSelection(baseOffset: end, extentOffset: end + selected.length),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  void _insertHorizontalRule() {
    _replaceBodySelection('\n---\n');
    if (_visualMode) _finishVisualBlockEditing();
  }

  void _insertDateTime() {
    final now = DateTime.now();
    String two(int v) => v.toString().padLeft(2, '0');
    _replaceBodySelection(
      '${two(now.day)}.${two(now.month)}.${now.year} ${two(now.hour)}:${two(now.minute)}',
    );
  }

  void _insertTable() {
    _replaceBodySelection(
      '\n| Столбец 1 | Столбец 2 | Столбец 3 |\n'
      '| --- | --- | --- |\n'
      '|  |  |  |\n'
      '|  |  |  |\n',
    );
    if (_visualMode) _finishVisualBlockEditing();
  }

  Future<String?> _askText({required String title, required String hint}) async {
    final controller = TextEditingController();
    final result = await showDialog<String>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(title, style: AppTypography.sectionTitle(color: _text)),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(hintText: hint),
          onSubmitted: (value) => Navigator.of(dialogContext).pop(value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Отмена'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(controller.text.trim()),
            child: const Text('Вставить'),
          ),
        ],
      ),
    );
    controller.dispose();
    return result?.trim();
  }

  Future<void> _insertLink() async {
    if (widget.readOnly) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    final selected = selection.isValid && !selection.isCollapsed
        ? value.text.substring(selection.start, selection.end)
        : '';
    final url = await _askText(title: 'Вставить ссылку', hint: 'https://…');
    if (url == null || url.isEmpty) return;
    final label = selected.trim().isEmpty ? 'Ссылка' : selected.trim();
    _replaceBodySelection('[$label]($url)');
  }

  Future<void> _insertImage() async {
    if (widget.readOnly) return;
    String? url;

    if (widget.onUploadImage != null) {
      final result = await FilePicker.pickFiles(
        type: FileType.image,
        allowMultiple: false,
      );
      final path = result?.files.single.path;
      if (path != null && path.trim().isNotEmpty) {
        try {
          url = await widget.onUploadImage!(path);
        } catch (e) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Не удалось загрузить изображение: $e')),
            );
          }
          return;
        }
      }
    }

    url ??= await _askText(
      title: 'Вставить изображение',
      hint: 'Ссылка на изображение https://…',
    );
    if (url == null || url.trim().isEmpty) return;
    final caption = await _askText(
      title: 'Подпись к изображению',
      hint: 'Необязательно',
    );
    final safeCaption = (caption ?? '').replaceAll(']', '').trim();
    _replaceBodySelection(
      '\n![${safeCaption.isEmpty ? 'Изображение' : safeCaption}](${url.trim()}){width=100%}\n',
    );
  }

  void _resizeNearestImage(int deltaPercent) {
    if (widget.readOnly) return;
    if (_visualMode && _selectedImageStart != null) {
      for (final block in _parseDocumentBlocks()) {
        if (block.start == _selectedImageStart && block.image != null) {
          _resizeVisualImage(block, deltaPercent);
          return;
        }
      }
    }
    final controller = _editingController;
    final value = controller.value;
    final cursor = value.selection.isValid ? value.selection.extentOffset : value.text.length;
    final regex = RegExp(
      r'!\[[^\]]*\]\([^\)]+\)\{width=(\d+)%(?:;align=(?:left|center|right))?\}',
    );
    RegExpMatch? best;
    for (final match in regex.allMatches(value.text)) {
      if (match.start <= cursor) best = match;
      if (match.start > cursor && best == null) {
        best = match;
        break;
      }
    }
    if (best == null) return;
    final current = int.tryParse(best.group(1) ?? '') ?? 100;
    final nextWidth = (current + deltaPercent).clamp(20, 100);
    final matched = best.group(0)!;
    final replaced = matched.replaceFirst('width=$current%', 'width=$nextWidth%');
    controller.value = TextEditingValue(
      text: value.text.replaceRange(best.start, best.end, replaced),
      selection: TextSelection.collapsed(offset: best.start + replaced.length),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  void _applyFontSize(int size) {
    _wrapSelection('<fs:$size>', '</fs>');
  }

  void _applyTextColor(String hex) {
    _wrapSelection('<c:$hex>', '</c>');
  }

  void _applyHighlight(String hex) {
    _wrapSelection('<bg:$hex>', '</bg>');
  }

  void _applyAlignment(String alignment) {
    if (widget.readOnly || !_ensureVisualFormattingTarget()) return;
    final controller = _editingController;
    final value = controller.value;
    final selection = value.selection;
    final rawStart = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final rawEnd = selection.isValid
        ? selection.end.clamp(rawStart, value.text.length).toInt()
        : rawStart;
    final lineStart =
        value.text.lastIndexOf('\n', rawStart == 0 ? 0 : rawStart - 1) + 1;
    final nextBreak = value.text.indexOf('\n', rawEnd);
    final lineEnd = nextBreak < 0 ? value.text.length : nextBreak;
    final raw = value.text.substring(lineStart, lineEnd);
    final cleaned = raw
        .split('\n')
        .map((line) => line.replaceFirst(
            RegExp(r'^<align:(left|center|right|justify)>'), ''))
        .toList();
    final replacement = cleaned
        .map((line) => alignment == 'left' ? line : '<align:$alignment>$line')
        .join('\n');
    controller.value = TextEditingValue(
      text: value.text.replaceRange(lineStart, lineEnd, replacement),
      selection: TextSelection(
        baseOffset: lineStart,
        extentOffset: lineStart + replacement.length,
      ),
    );
    _syncVisualBlockIfNeeded();
    _focusEditing();
  }

  List<_WorkspaceDocBlock> _parseDocumentBlocks() {
    final text = _bodyController.text;
    if (text.isEmpty) return <_WorkspaceDocBlock>[];
    final blocks = <_WorkspaceDocBlock>[];
    final lines = <_WorkspaceDocLine>[];
    var offset = 0;
    final rawLines = text.split('\n');
    for (var i = 0; i < rawLines.length; i++) {
      final line = rawLines[i];
      lines.add(_WorkspaceDocLine(
        text: line,
        start: offset,
        end: offset + line.length,
      ));
      offset += line.length;
      if (i < rawLines.length - 1) offset += 1;
    }

    var i = 0;
    while (i < lines.length) {
      final line = lines[i];
      final trimmed = line.text.trim();
      if (trimmed.startsWith('|') && trimmed.endsWith('|')) {
        var j = i + 1;
        while (j < lines.length) {
          final candidate = lines[j].text.trim();
          if (!(candidate.startsWith('|') && candidate.endsWith('|'))) break;
          j++;
        }
        if (j - i >= 2) {
          final end = lines[j - 1].end;
          blocks.add(_WorkspaceDocBlock(
            kind: _WorkspaceDocBlockKind.table,
            start: line.start,
            end: end,
            raw: text.substring(line.start, end),
          ));
          i = j;
          continue;
        }
      }

      final image = _WorkspaceVisualImageData.tryParse(line.text);
      if (image != null) {
        blocks.add(_WorkspaceDocBlock(
          kind: _WorkspaceDocBlockKind.image,
          start: line.start,
          end: line.end,
          raw: line.text,
          image: image,
        ));
      } else if (trimmed == '---') {
        blocks.add(_WorkspaceDocBlock(
          kind: _WorkspaceDocBlockKind.rule,
          start: line.start,
          end: line.end,
          raw: line.text,
        ));
      } else if (trimmed.isEmpty) {
        blocks.add(_WorkspaceDocBlock(
          kind: _WorkspaceDocBlockKind.spacer,
          start: line.start,
          end: line.end,
          raw: line.text,
        ));
      } else {
        blocks.add(_WorkspaceDocBlock(
          kind: _WorkspaceDocBlockKind.text,
          start: line.start,
          end: line.end,
          raw: line.text,
        ));
      }
      i++;
    }
    return blocks;
  }

  void _editRawBlock(_WorkspaceDocBlock block) {
    _setVisualMode(false);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final len = _bodyController.text.length;
      _bodyController.selection = TextSelection(
        baseOffset: block.start.clamp(0, len).toInt(),
        extentOffset: block.end.clamp(0, len).toInt(),
      );
      _bodyFocus.requestFocus();
    });
  }

  void _replaceCanonicalRange(int start, int end, String replacement) {
    if (widget.readOnly) return;
    final value = _bodyController.value;
    if (start < 0 || start > value.text.length || end < start || end > value.text.length) {
      return;
    }
    _finishVisualBlockEditing(rebuild: false);
    final next = value.text.replaceRange(start, end, replacement);
    _bodyController.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: start + replacement.length),
    );
  }

  void _updateVisualImage(
    _WorkspaceDocBlock block, {
    int? width,
    String? alignment,
    String? caption,
  }) {
    final image = block.image;
    if (image == null) return;
    final next = image.copyWith(
      widthPercent: width ?? image.widthPercent,
      alignment: alignment ?? image.alignment,
      caption: caption ?? image.caption,
    );
    _selectedImageStart = block.start;
    _replaceCanonicalRange(block.start, block.end, next.toMarkup());
    if (mounted) setState(() {});
  }

  void _resizeVisualImage(_WorkspaceDocBlock block, int deltaPercent) {
    final image = block.image;
    if (image == null) return;
    final width = (image.widthPercent + deltaPercent).clamp(20, 100).toInt();
    _updateVisualImage(block, width: width);
  }

  void _deleteVisualBlock(_WorkspaceDocBlock block) {
    var start = block.start;
    var end = block.end;
    final body = _bodyController.text;
    if (end < body.length && body.substring(end, end + 1) == '\n') {
      end += 1;
    } else if (start > 0 && body.substring(start - 1, start) == '\n') {
      start -= 1;
    }
    _selectedImageStart = null;
    _selectedTableStart = null;
    _replaceCanonicalRange(start, end, '');
  }

  Future<void> _copyVisualBlock(_WorkspaceDocBlock block) async {
    await Clipboard.setData(ClipboardData(text: block.raw));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Объект скопирован')),
    );
  }

  Future<void> _cutVisualBlock(_WorkspaceDocBlock block) async {
    if (widget.readOnly) return;
    await Clipboard.setData(ClipboardData(text: block.raw));
    _deleteVisualBlock(block);
  }

  void _duplicateVisualBlock(_WorkspaceDocBlock block) {
    if (widget.readOnly) return;
    final body = _bodyController.text;
    var insertAt = block.end.clamp(0, body.length).toInt();
    final needsLeadingBreak = insertAt > 0 &&
        body.substring(insertAt - 1, insertAt) != '\n';
    final needsTrailingBreak = insertAt < body.length &&
        body.substring(insertAt, insertAt + 1) != '\n';
    final insertion =
        '${needsLeadingBreak ? '\n' : ''}${block.raw}${needsTrailingBreak ? '\n' : ''}';
    _replaceCanonicalRange(insertAt, insertAt, insertion);
  }

  int _lineIndexForOffset(String text, int offset) {
    final safe = offset.clamp(0, text.length).toInt();
    if (safe == 0) return 0;
    return '\n'.allMatches(text.substring(0, safe)).length;
  }

  void _moveImageBlock(int sourceStart, int? targetStart) {
    if (widget.readOnly) return;
    final body = _bodyController.text;
    final blocks = _parseDocumentBlocks();
    _WorkspaceDocBlock? source;
    for (final block in blocks) {
      if (block.start == sourceStart &&
          block.kind == _WorkspaceDocBlockKind.image) {
        source = block;
        break;
      }
    }
    if (source == null) return;

    final sourceLine = _lineIndexForOffset(body, source.start);
    var targetLine = targetStart == null
        ? body.split('\n').length
        : _lineIndexForOffset(body, targetStart);
    if (targetLine == sourceLine || targetLine == sourceLine + 1) return;

    final lines = body.split('\n');
    if (sourceLine < 0 || sourceLine >= lines.length) return;
    final movedLine = lines.removeAt(sourceLine);
    if (sourceLine < targetLine) targetLine -= 1;
    targetLine = targetLine.clamp(0, lines.length).toInt();
    lines.insert(targetLine, movedLine);

    _finishVisualBlockEditing(rebuild: false);
    _selectedImageStart = null;
    _bodyController.value = TextEditingValue(
      text: lines.join('\n'),
      selection: TextSelection.collapsed(
        offset: lines.take(targetLine + 1).join('\n').length,
      ),
    );
  }

  Widget _buildBlockDropTarget(int? targetStart) {
    if (widget.readOnly) return const SizedBox(height: 3);
    return DragTarget<int>(
      onWillAccept: (sourceStart) => sourceStart != null && sourceStart != targetStart,
      onAccept: (sourceStart) => _moveImageBlock(sourceStart, targetStart),
      builder: (context, candidateData, rejectedData) {
        final active = candidateData.isNotEmpty;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          height: active ? 16 : 4,
          margin: const EdgeInsets.symmetric(vertical: 1),
          decoration: BoxDecoration(
            color: active ? const Color(0xFFE5F4EC) : Colors.transparent,
            borderRadius: BorderRadius.circular(99),
            border: active
                ? Border.all(color: _green.withOpacity(.45), width: 1)
                : null,
          ),
        );
      },
    );
  }

  List<List<String>> _visualTableRows(_WorkspaceDocBlock block) {
    final parsed = block.raw
        .split('\n')
        .where((line) => line.trim().isNotEmpty)
        .map((line) => line
            .trim()
            .replaceFirst(RegExp(r'^\|'), '')
            .replaceFirst(RegExp(r'\|$'), '')
            .split('|')
            .map((cell) => cell.trim())
            .toList())
        .toList();
    if (parsed.length >= 2 &&
        parsed[1].every((cell) => RegExp(r'^:?-{2,}:?$').hasMatch(cell))) {
      return <List<String>>[parsed.first, ...parsed.skip(2)];
    }
    return parsed;
  }

  String _tableMarkup(List<List<String>> rows) {
    if (rows.isEmpty) rows = <List<String>>[<String>['']];
    var columns = 1;
    for (final row in rows) {
      if (row.length > columns) columns = row.length;
    }
    final normalized = rows
        .map((row) => List<String>.generate(
              columns,
              (index) => index < row.length
                  ? row[index].replaceAll('|', '¦').replaceAll('\n', ' ')
                  : '',
            ))
        .toList();
    final out = <String>[];
    out.add('| ${normalized.first.join(' | ')} |');
    out.add('| ${List<String>.filled(columns, '---').join(' | ')} |');
    for (final row in normalized.skip(1)) {
      out.add('| ${row.join(' | ')} |');
    }
    return out.join('\n');
  }

  void _replaceVisualTable(_WorkspaceDocBlock block, List<List<String>> rows) {
    if (widget.readOnly) return;
    _selectedTableStart = block.start;
    _replaceCanonicalRange(block.start, block.end, _tableMarkup(rows));
    if (mounted) setState(() {});
  }

  void _addVisualTableRow(_WorkspaceDocBlock block) {
    final rows = _visualTableRows(block);
    var columns = 1;
    for (final row in rows) {
      if (row.length > columns) columns = row.length;
    }
    rows.add(List<String>.filled(columns, ''));
    _replaceVisualTable(block, rows);
  }

  void _removeVisualTableRow(_WorkspaceDocBlock block) {
    final rows = _visualTableRows(block);
    if (rows.length <= 1) return;
    rows.removeLast();
    _replaceVisualTable(block, rows);
  }

  void _addVisualTableColumn(_WorkspaceDocBlock block) {
    final rows = _visualTableRows(block);
    if (rows.isEmpty) rows.add(<String>['']);
    for (final row in rows) {
      row.add('');
    }
    _replaceVisualTable(block, rows);
  }

  void _removeVisualTableColumn(_WorkspaceDocBlock block) {
    final rows = _visualTableRows(block);
    var columns = 0;
    for (final row in rows) {
      if (row.length > columns) columns = row.length;
    }
    if (columns <= 1) return;
    for (final row in rows) {
      if (row.isNotEmpty) row.removeLast();
    }
    _replaceVisualTable(block, rows);
  }

  void _updateVisualTableCell(
    _WorkspaceDocBlock block,
    int rowIndex,
    int columnIndex,
    String value,
  ) {
    final rows = _visualTableRows(block);
    if (rowIndex < 0 || rowIndex >= rows.length) return;
    while (rows[rowIndex].length <= columnIndex) {
      rows[rowIndex].add('');
    }
    rows[rowIndex][columnIndex] = value;
    _replaceVisualTable(block, rows);
  }

  RelativeRect _menuPosition(Offset globalPosition) {
    final overlay = Overlay.of(context).context.findRenderObject() as RenderBox;
    return RelativeRect.fromRect(
      Rect.fromLTWH(globalPosition.dx, globalPosition.dy, 1, 1),
      Offset.zero & overlay.size,
    );
  }

  Future<void> _showBlockContextMenu(
    _WorkspaceDocBlock block,
    Offset globalPosition,
  ) async {
    final items = <PopupMenuEntry<String>>[
      const PopupMenuItem(value: 'copy', child: Text('Копировать')),
      if (!widget.readOnly)
        const PopupMenuItem(value: 'cut', child: Text('Вырезать')),
      if (!widget.readOnly)
        const PopupMenuItem(value: 'duplicate', child: Text('Дублировать')),
    ];

    if (!widget.readOnly && block.kind == _WorkspaceDocBlockKind.image) {
      items.add(const PopupMenuDivider());
      items.addAll(const <PopupMenuEntry<String>>[
        PopupMenuItem(value: 'image_caption', child: Text('Подпись к изображению')),
        PopupMenuItem(value: 'image_left', child: Text('Изображение слева')),
        PopupMenuItem(value: 'image_center', child: Text('Изображение по центру')),
        PopupMenuItem(value: 'image_right', child: Text('Изображение справа')),
      ]);
    }
    if (!widget.readOnly && block.kind == _WorkspaceDocBlockKind.table) {
      items.add(const PopupMenuDivider());
      items.addAll(const <PopupMenuEntry<String>>[
        PopupMenuItem(value: 'table_add_row', child: Text('Добавить строку')),
        PopupMenuItem(value: 'table_remove_row', child: Text('Удалить последнюю строку')),
        PopupMenuItem(value: 'table_add_column', child: Text('Добавить столбец')),
        PopupMenuItem(value: 'table_remove_column', child: Text('Удалить последний столбец')),
      ]);
    }
    if (!widget.readOnly && block.kind == _WorkspaceDocBlockKind.text) {
      items.add(const PopupMenuDivider());
      items.add(const PopupMenuItem(value: 'edit', child: Text('Редактировать абзац')));
    }
    if (!widget.readOnly) {
      items.add(const PopupMenuDivider());
      items.add(const PopupMenuItem(
        value: 'delete',
        child: Text('Удалить', style: TextStyle(color: Color(0xFFB42318))),
      ));
    }

    final action = await showMenu<String>(
      context: context,
      position: _menuPosition(globalPosition),
      color: Colors.white,
      surfaceTintColor: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      items: items,
    );
    if (!mounted || action == null) return;

    switch (action) {
      case 'copy':
        await _copyVisualBlock(block);
        break;
      case 'cut':
        await _cutVisualBlock(block);
        break;
      case 'duplicate':
        _duplicateVisualBlock(block);
        break;
      case 'delete':
        _deleteVisualBlock(block);
        break;
      case 'edit':
        _startVisualBlockEditing(block);
        break;
      case 'image_caption':
        setState(() => _selectedImageStart = block.start);
        break;
      case 'image_left':
        _updateVisualImage(block, alignment: 'left');
        break;
      case 'image_center':
        _updateVisualImage(block, alignment: 'center');
        break;
      case 'image_right':
        _updateVisualImage(block, alignment: 'right');
        break;
      case 'table_add_row':
        _addVisualTableRow(block);
        break;
      case 'table_remove_row':
        _removeVisualTableRow(block);
        break;
      case 'table_add_column':
        _addVisualTableColumn(block);
        break;
      case 'table_remove_column':
        _removeVisualTableColumn(block);
        break;
    }
  }

  Widget _buildVisualDocument({required bool compact}) {
    final blocks = _parseDocumentBlocks();
    if (blocks.isEmpty) {
      return InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: widget.readOnly
            ? null
            : () {
                _setVisualMode(false);
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (mounted) _bodyFocus.requestFocus();
                });
              },
        child: Container(
          width: double.infinity,
          constraints: BoxConstraints(minHeight: compact ? 320 : 430),
          alignment: Alignment.topLeft,
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            widget.readOnly
                ? 'Документ пуст'
                : 'Нажмите здесь и начните писать…',
            style: AppTypography.body(color: const Color(0xFFA2ABA5)).copyWith(
              fontSize: compact ? 14 : 15,
              height: 1.62,
            ),
          ),
        ),
      );
    }

    final widgets = <Widget>[];
    for (final block in blocks) {
      widgets.add(_buildBlockDropTarget(block.start));
      final activeStart = _activeVisualBlockStart;
      final activeEnd = _activeVisualBlockEnd;
      if (activeStart != null && activeEnd != null) {
        if (block.start > activeStart && block.start < activeEnd) continue;
        if (block.start == activeStart && _visualBlockController != null) {
          widgets.add(_buildActiveVisualTextBlock(compact: compact));
          continue;
        }
      }
      switch (block.kind) {
        case _WorkspaceDocBlockKind.spacer:
          widgets.add(const SizedBox(height: 11));
          break;
        case _WorkspaceDocBlockKind.rule:
          widgets.add(const Padding(
            padding: EdgeInsets.symmetric(vertical: 10),
            child: Divider(height: 1, color: _line),
          ));
          break;
        case _WorkspaceDocBlockKind.image:
          widgets.add(_buildVisualImage(block, compact: compact));
          break;
        case _WorkspaceDocBlockKind.table:
          widgets.add(_buildVisualTable(block, compact: compact));
          break;
        case _WorkspaceDocBlockKind.text:
          widgets.add(_buildVisualTextBlock(block, compact: compact));
          break;
      }
    }
    widgets.add(_buildBlockDropTarget(null));
    widgets.add(
      GestureDetector(
        behavior: HitTestBehavior.translucent,
        onSecondaryTapDown: (details) =>
            _showDocumentContextMenu(details.globalPosition),
        onTap: widget.readOnly
            ? null
            : () {
                _setVisualMode(false);
                WidgetsBinding.instance.addPostFrameCallback((_) {
                  if (!mounted) return;
                  _bodyController.selection = TextSelection.collapsed(
                    offset: _bodyController.text.length,
                  );
                  _bodyFocus.requestFocus();
                });
              },
        child: SizedBox(height: compact ? 120 : 180),
      ),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: widgets,
    );
  }

  Widget _buildActiveVisualTextBlock({required bool compact}) {
    final controller = _visualBlockController!;
    final focus = _visualBlockFocus!;
    final styleInfo = _WorkspaceTextBlockStyle.parse(controller.text);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: TextField(
        controller: controller,
        focusNode: focus,
        readOnly: widget.readOnly,
        minLines: 1,
        maxLines: null,
        keyboardType: TextInputType.multiline,
        textCapitalization: TextCapitalization.sentences,
        textAlign: styleInfo.textAlign,
        decoration: const InputDecoration(
          isDense: true,
          border: InputBorder.none,
          enabledBorder: InputBorder.none,
          focusedBorder: InputBorder.none,
          contentPadding: EdgeInsets.symmetric(vertical: 3),
        ),
        style: styleInfo.baseStyle(
          compact: compact,
          color: _text,
        ),
        onTapOutside: (_) => _finishVisualBlockEditing(),
      ),
    );
  }

  Widget _buildVisualTextBlock(
    _WorkspaceDocBlock block, {
    required bool compact,
  }) {
    final info = _WorkspaceTextBlockStyle.parse(block.raw);
    final text = info.content;
    final span = _workspaceRichSpan(
      text,
      info.baseStyle(compact: compact, color: _text),
    );
    Widget child = RichText(
      textAlign: info.textAlign,
      text: span,
    );
    if (info.quote) {
      child = Container(
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
        decoration: BoxDecoration(
          color: const Color(0xFFF5F8F6),
          borderRadius: BorderRadius.circular(9),
          border: const Border(left: BorderSide(color: _green, width: 3)),
        ),
        child: child,
      );
    }
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onSecondaryTapDown: (details) =>
          _showBlockContextMenu(block, details.globalPosition),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: widget.readOnly ? null : () => _startVisualBlockEditing(block),
        child: Padding(
          padding: EdgeInsets.symmetric(vertical: info.headingLevel > 0 ? 6 : 3),
          child: child,
        ),
      ),
    );
  }

  Widget _buildVisualImage(
    _WorkspaceDocBlock block, {
    required bool compact,
  }) {
    final image = block.image!;
    final selected = _selectedImageStart == block.start;
    return LayoutBuilder(
      builder: (context, constraints) {
        final maxWidth = constraints.maxWidth;
        final desiredWidth = maxWidth * image.widthPercent / 100;
        final alignment = image.alignment == 'left'
            ? Alignment.centerLeft
            : image.alignment == 'right'
                ? Alignment.centerRight
                : Alignment.center;
        final imageWidget = GestureDetector(
          onTap: () => setState(() {
            _finishVisualBlockEditing(rebuild: false);
            _selectedImageStart = selected ? null : block.start;
          }),
          child: Container(
            width: desiredWidth,
            constraints: BoxConstraints(
              minHeight: compact ? 100 : 120,
              maxHeight: compact ? 380 : 520,
            ),
            decoration: BoxDecoration(
              color: const Color(0xFFF7F8F7),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: selected ? _green : _line,
                width: selected ? 1.4 : .8,
              ),
            ),
            clipBehavior: Clip.antiAlias,
            child: Stack(
              children: [
                Positioned.fill(
                  child: Image.network(
                    image.url,
                    fit: BoxFit.contain,
                    errorBuilder: (_, __, ___) => Center(
                      child: Padding(
                        padding: const EdgeInsets.all(18),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.broken_image_outlined,
                                size: 28, color: _muted),
                            const SizedBox(height: 8),
                            Text(
                              'Не удалось показать изображение',
                              textAlign: TextAlign.center,
                              style: AppTypography.caption(color: _muted),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (selected && !widget.readOnly)
                  Positioned(
                    right: 0,
                    bottom: 0,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onHorizontalDragStart: (_) => _imageResizeDrag = 0,
                      onHorizontalDragUpdate: (details) {
                        _imageResizeDrag += details.delta.dx;
                      },
                      onHorizontalDragEnd: (_) {
                        final steps = (_imageResizeDrag / 18).round();
                        if (steps != 0) {
                          _resizeVisualImage(block, steps * 5);
                        }
                        _imageResizeDrag = 0;
                      },
                      child: Container(
                        width: 32,
                        height: 32,
                        alignment: Alignment.center,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(9),
                          ),
                        ),
                        child: const Icon(
                          Icons.open_in_full_rounded,
                          size: 16,
                          color: _green,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        );

        return GestureDetector(
          behavior: HitTestBehavior.translucent,
          onSecondaryTapDown: (details) =>
              _showBlockContextMenu(block, details.globalPosition),
          child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Align(alignment: alignment, child: imageWidget),
              if (selected && !widget.readOnly) ...[
                const SizedBox(height: 7),
                Align(
                  alignment: alignment,
                  child: SizedBox(
                    width: desiredWidth,
                    child: _InlineImageCaptionEditor(
                      key: ValueKey<String>(
                        'image-caption-${block.start}-${image.caption}',
                      ),
                      initialValue: image.caption,
                      onSave: (value) =>
                          _updateVisualImage(block, caption: value),
                    ),
                  ),
                ),
              ] else if (image.caption.trim().isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  image.caption,
                  textAlign: image.alignment == 'left'
                      ? TextAlign.left
                      : image.alignment == 'right'
                          ? TextAlign.right
                          : TextAlign.center,
                  style: AppTypography.caption(color: _muted),
                ),
              ],
              if (selected && !widget.readOnly) ...[
                const SizedBox(height: 7),
                Align(
                  alignment: alignment,
                  child: Wrap(
                    spacing: 4,
                    runSpacing: 4,
                    children: [
                      Draggable<int>(
                        data: block.start,
                        feedback: Material(
                          color: Colors.transparent,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 10,
                              vertical: 7,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(9),
                              border: Border.all(color: _green.withOpacity(.35)),
                              boxShadow: const <BoxShadow>[
                                BoxShadow(
                                  color: Color(0x16101814),
                                  blurRadius: 16,
                                  offset: Offset(0, 7),
                                ),
                              ],
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.drag_indicator_rounded,
                                    size: 16, color: _green),
                                const SizedBox(width: 6),
                                Text(
                                  'Переместить фото',
                                  style: AppTypography.captionMedium(
                                    color: _text,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        childWhenDragging: Opacity(
                          opacity: .35,
                          child: _WordObjectButton(
                            icon: Icons.drag_indicator_rounded,
                            tooltip: 'Перетащить между абзацами',
                            onTap: () {},
                          ),
                        ),
                        child: _WordObjectButton(
                          icon: Icons.drag_indicator_rounded,
                          tooltip: 'Перетащить между абзацами',
                          onTap: () {},
                        ),
                      ),
                      _WordObjectButton(
                        icon: Icons.remove_rounded,
                        tooltip: 'Уменьшить',
                        onTap: () => _resizeVisualImage(block, -10),
                      ),
                      _WordObjectLabel(text: '${image.widthPercent}%'),
                      _WordObjectButton(
                        icon: Icons.add_rounded,
                        tooltip: 'Увеличить',
                        onTap: () => _resizeVisualImage(block, 10),
                      ),
                      _WordObjectButton(
                        icon: Icons.format_align_left_rounded,
                        tooltip: 'По левому краю',
                        active: image.alignment == 'left',
                        onTap: () => _updateVisualImage(block, alignment: 'left'),
                      ),
                      _WordObjectButton(
                        icon: Icons.format_align_center_rounded,
                        tooltip: 'По центру',
                        active: image.alignment == 'center',
                        onTap: () => _updateVisualImage(block, alignment: 'center'),
                      ),
                      _WordObjectButton(
                        icon: Icons.format_align_right_rounded,
                        tooltip: 'По правому краю',
                        active: image.alignment == 'right',
                        onTap: () => _updateVisualImage(block, alignment: 'right'),
                      ),
                      _WordObjectButton(
                        icon: Icons.content_copy_rounded,
                        tooltip: 'Копировать изображение',
                        onTap: () => _copyVisualBlock(block),
                      ),
                      _WordObjectButton(
                        icon: Icons.delete_outline_rounded,
                        tooltip: 'Удалить изображение',
                        danger: true,
                        onTap: () => _deleteVisualBlock(block),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
          ),
        );
      },
    );
  }

  Widget _buildVisualTable(
    _WorkspaceDocBlock block, {
    required bool compact,
  }) {
    final dataRows = _visualTableRows(block);
    final selected = _selectedTableStart == block.start;
    var columns = 0;
    for (final row in dataRows) {
      if (row.length > columns) columns = row.length;
    }
    if (columns == 0) return const SizedBox.shrink();

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onSecondaryTapDown: (details) =>
          _showBlockContextMenu(block, details.globalPosition),
      onTap: widget.readOnly
          ? null
          : () => setState(() {
                _finishVisualBlockEditing(rebuild: false);
                _selectedImageStart = null;
                _selectedTableStart = selected ? null : block.start;
              }),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 130),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(9),
                border: Border.all(
                  color: selected ? _green : _line,
                  width: selected ? 1.3 : .8,
                ),
              ),
              clipBehavior: Clip.antiAlias,
              child: Table(
                border: TableBorder.all(color: _line, width: .8),
                defaultVerticalAlignment: TableCellVerticalAlignment.middle,
                children: [
                  for (var r = 0; r < dataRows.length; r++)
                    TableRow(
                      decoration: BoxDecoration(
                        color: r == 0
                            ? const Color(0xFFF5F8F6)
                            : Colors.white,
                      ),
                      children: [
                        for (var c = 0; c < columns; c++)
                          _InlineTableCellEditor(
                            key: ValueKey<String>(
                              'table-${block.start}-$r-$c-${c < dataRows[r].length ? dataRows[r][c] : ''}',
                            ),
                            initialValue:
                                c < dataRows[r].length ? dataRows[r][c] : '',
                            readOnly: widget.readOnly,
                            header: r == 0,
                            compact: compact,
                            onSave: (value) =>
                                _updateVisualTableCell(block, r, c, value),
                          ),
                      ],
                    ),
                ],
              ),
            ),
            if (selected && !widget.readOnly) ...[
              const SizedBox(height: 7),
              Wrap(
                spacing: 4,
                runSpacing: 4,
                alignment: WrapAlignment.end,
                children: [
                  _WordObjectButton(
                    icon: Icons.add_rounded,
                    tooltip: 'Добавить строку',
                    onTap: () => _addVisualTableRow(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.remove_rounded,
                    tooltip: 'Удалить последнюю строку',
                    onTap: () => _removeVisualTableRow(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.view_column_outlined,
                    tooltip: 'Добавить столбец',
                    onTap: () => _addVisualTableColumn(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.vertical_split_outlined,
                    tooltip: 'Удалить последний столбец',
                    onTap: () => _removeVisualTableColumn(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.content_copy_rounded,
                    tooltip: 'Копировать таблицу',
                    onTap: () => _copyVisualBlock(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.edit_note_rounded,
                    tooltip: 'Исходный текст таблицы',
                    onTap: () => _editRawBlock(block),
                  ),
                  _WordObjectButton(
                    icon: Icons.delete_outline_rounded,
                    tooltip: 'Удалить таблицу',
                    danger: true,
                    onTap: () => _deleteVisualBlock(block),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Future<void> _showDocumentContextMenu(Offset globalPosition) async {
    if (widget.readOnly) return;
    final action = await showMenu<String>(
      context: context,
      position: _menuPosition(globalPosition),
      color: Colors.white,
      surfaceTintColor: Colors.white,
      elevation: 6,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      items: const <PopupMenuEntry<String>>[
        PopupMenuItem(value: 'paste', child: Text('Вставить')),
        PopupMenuItem(value: 'image', child: Text('Вставить изображение')),
        PopupMenuItem(value: 'table', child: Text('Вставить таблицу')),
        PopupMenuDivider(),
        PopupMenuItem(value: 'text_mode', child: Text('Редактировать как текст')),
      ],
    );
    if (!mounted || action == null) return;
    switch (action) {
      case 'paste':
        await _pasteClipboard();
        break;
      case 'image':
        await _insertImage();
        break;
      case 'table':
        _insertTable();
        break;
      case 'text_mode':
        _setVisualMode(false);
        break;
    }
  }

  void _insertTemplate(_EditorTemplate template) {
    if (widget.readOnly) return;
    final current = _bodyController.text.trimRight();
    final separator = current.isEmpty ? '' : '\n\n';
    final next = '$current$separator${template.body}';
    _bodyController.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: next.length),
    );
    _bodyFocus.requestFocus();
  }

  int get _wordCount {
    final value = _bodyController.text.trim();
    if (value.isEmpty) return 0;
    return value.split(RegExp(r'\s+')).where((part) => part.isNotEmpty).length;
  }

  Future<void> _copyDocument() async {
    final title = _titleController.text.trim();
    final body = _bodyController.text;
    final value = <String>[title, body]
        .where((part) => part.trim().isNotEmpty)
        .join('\n\n');
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Текст заметки скопирован')),
    );
  }

  List<_EditorTemplate> get _templates {
    final context = widget.contextLabel.toLowerCase();
    if (context.contains('игрок')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Наблюдение',
            'Наблюдение за игроком\n\nСильные стороны\n• \n\nЗона развития\n• \n\nСледующий шаг\n☐ '),
        _EditorTemplate('Личная цель',
            'Цель игрока\n\nЧто развиваем\n\nКритерий результата\n\nСрок\n\n☐ Контрольная точка'),
        _EditorTemplate('Обратная связь',
            'Обратная связь\n\nЧто получилось\n\nЧто улучшить\n\nДоговорённость с игроком'),
        _EditorTemplate('Итоги периода',
            'Итоги периода\n\nПрогресс\n\nНагрузка и готовность\n\nПриоритет следующего периода'),
      ];
    }
    if (context.contains('тренер')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Рабочая запись',
            'Рабочая запись тренера\n\nЗадача\n\nРешение\n\n☐ Следующее действие'),
        _EditorTemplate('Методика',
            'Методическая заметка\n\nЦель\n\nОрганизация\n\nКлючевые подсказки\n\nВарианты усложнения'),
        _EditorTemplate('Разбор',
            'Разбор работы\n\nЧто сработало\n\nЧто изменить\n\nРешение на следующую тренировку'),
        _EditorTemplate('Договорённость',
            'Договорённость\n\nУчастники\n\nРешение\n\nСрок\n\n☐ Проверить выполнение'),
      ];
    }
    if (context.contains('команд')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Командная цель',
            'Командная цель\n\nФокус\n\nКритерий результата\n\n☐ Следующий шаг'),
        _EditorTemplate('Разбор матча',
            'Разбор матча\n\nСильные эпизоды\n\nЧто исправить\n\nФокус микроцикла'),
        _EditorTemplate('План недели',
            'План недели\n\nГлавная задача\n\nНагрузка\n\nКонтрольные точки'),
        _EditorTemplate('Собрание',
            'Итоги собрания\n\nРешения\n\nОтветственные\n\n☐ Следующая встреча'),
      ];
    }
    return const <_EditorTemplate>[
      _EditorTemplate(
          'Быстрая заметка', 'Кратко\n\nГлавная мысль\n\n☐ Следующее действие'),
      _EditorTemplate(
          'Итоги', 'Итоги\n\nЧто сделано\n\nЧто осталось\n\nСледующий шаг'),
      _EditorTemplate('План', 'Цель\n\nШаги\n☐ \n☐ \n☐ \n\nСрок'),
      _EditorTemplate('Встреча',
          'Встреча\n\nУчастники\n\nОбсудили\n\nРешили\n\n☐ Контроль'),
    ];
  }

  bool get _methodDocumentMode => widget.aiExtraPayload['document_ai'] == true;

  String get _sourceDocumentName {
    final value = '${widget.aiExtraPayload['document_filename'] ?? ''}'.trim();
    return value.isEmpty ? widget.initialTitle : value;
  }

  String get _sourceDocumentUrl =>
      '${widget.aiExtraPayload['document_file_url'] ?? ''}'.trim();

  String get _sourceDocumentExtension {
    final value = '${widget.aiExtraPayload['document_extension'] ?? ''}'.trim();
    return value.replaceFirst('.', '').toUpperCase();
  }

  int get _sourceDocumentSize {
    final raw = widget.aiExtraPayload['document_file_size'];
    if (raw is int) return raw;
    return int.tryParse('$raw') ?? 0;
  }

  String _sourceSizeLabel() {
    final bytes = _sourceDocumentSize;
    if (bytes <= 0) return '';
    if (bytes < 1024 * 1024) {
      return '${(bytes / 1024).toStringAsFixed(0)} КБ';
    }
    return '${(bytes / 1024 / 1024).toStringAsFixed(1)} МБ';
  }

  String _absoluteSourceUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty) return '';
    if (value.startsWith('https://') || value.startsWith('http://')) {
      return value;
    }
    if (value.startsWith('/')) {
      return 'https://sportotekaapp.ru$value';
    }
    return 'https://sportotekaapp.ru/$value';
  }

  Future<void> _openOriginalSourceDocument() async {
    final raw = _sourceDocumentUrl;
    final absolute = _absoluteSourceUrl(raw);
    final uri = Uri.tryParse(absolute);
    if (uri == null || absolute.isEmpty) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Ссылка на оригинальный документ недоступна'),
        ),
      );
      return;
    }
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openAiAnalysis() {
    if (!_aiEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ИИ-контекст для этого документа пока недоступен'),
        ),
      );
      return;
    }
    setState(() => _aiExpanded = true);
  }

  bool get _aiEnabled =>
      (widget.aiClubId ?? 0) > 0 && (widget.aiUserId ?? 0) > 0;

  String get _aiDocumentKey {
    final explicit = (widget.aiDocumentKey ?? '').trim();
    if (explicit.isNotEmpty) return explicit;
    final live = _effectiveLiveBlocksKey.trim();
    if (live.isNotEmpty) return live;
    return '${widget.contextLabel}:${widget.contextName}:${widget.initialTitle}';
  }

  String _selectedTextForAi() {
    final selection = _bodyController.selection;
    final body = _bodyController.text;
    if (!selection.isValid || selection.isCollapsed) return '';
    final start = selection.start.clamp(0, body.length).toInt();
    final end = selection.end.clamp(0, body.length).toInt();
    if (end <= start) return '';
    return body.substring(start, end);
  }

  Map<String, dynamic> _aiPayload() {
    return <String, dynamic>{
      ...widget.aiExtraPayload,
      'scope': 'workspace_document',
      'workspace_section': widget.contextLabel,
      'workspace_document': <String, dynamic>{
        'document_key': _aiDocumentKey,
        'title': _titleController.text.trim().isEmpty
            ? widget.initialTitle
            : _titleController.text.trim(),
        'body': _bodyController.text,
        'selected_text': _selectedTextForAi(),
        'context_label': widget.contextLabel,
        'context_name': widget.contextName,
        'document_type': widget.documentType,
      },
    };
  }

  String _aiInitialPrompt() {
    final label = widget.contextLabel.trim();
    final title = _titleController.text.trim().isEmpty
        ? widget.initialTitle
        : _titleController.text.trim();
    final normalized = label.toLowerCase();

    if (normalized.contains('трениров')) {
      return 'Проанализируй текущий документ тренировки «$title». '
          'Сначала разберись в тексте документа, затем, если это уместно, '
          'сопоставь его только с проверенными данными этой тренировки и команды. '
          'Дай коротко: что важно, что требует внимания и что делать тренеру.';
    }
    if (normalized.contains('матч')) {
      return 'Проанализируй текущий документ матча «$title». '
          'Выдели ключевые решения, тактические моменты и следующие действия. '
          'Если нужны данные матча или игроков, используй только проверенные данные SPORTOTEKA.';
    }
    if (normalized.contains('игрок')) {
      return 'Проанализируй текущий документ игрока «$title». '
          'Сопоставляй текст с данными игрока только когда они действительно нужны '
          'и используй только проверенные показатели SPORTOTEKA.';
    }
    if (normalized.contains('тренер')) {
      return 'Проанализируй текущий рабочий документ тренера «$title». '
          'Помоги улучшить формулировки, структуру, план и практические действия.';
    }
    if (normalized.contains('календар')) {
      return 'Проанализируй текущий документ календаря «$title». '
          'Выдели задачи, сроки, риски и следующие действия.';
    }
    if (widget.documentType.toLowerCase().contains('метод')) {
      return 'Разбери методический документ «$title». '
          'Выдели ключевые принципы, упражнения, ограничения и практическое применение. '
          'Не придумывай того, чего нет в документе.';
    }
    return 'Проанализируй текущий документ «$title» в разделе «$label». '
        'Сделай краткий разбор, выдели главное и предложи следующие действия. '
        'Используй текст документа и только проверенные данные SPORTOTEKA.';
  }

  String get _aiContextTitle => 'ИИ анализ · ${widget.contextLabel}';

  String get _aiContextSubtitle {
    final title = _titleController.text.trim();
    if (title.isNotEmpty) return title;
    if (widget.contextName.trim().isNotEmpty) return widget.contextName.trim();
    return widget.documentType;
  }

  @override
  Widget build(BuildContext context) {
    return Shortcuts(
      shortcuts: const <ShortcutActivator, Intent>{
        SingleActivator(LogicalKeyboardKey.keyS, meta: true): _SaveIntent(),
        SingleActivator(LogicalKeyboardKey.keyS, control: true): _SaveIntent(),
        SingleActivator(LogicalKeyboardKey.keyZ, meta: true): _UndoIntent(),
        SingleActivator(LogicalKeyboardKey.keyZ, control: true): _UndoIntent(),
        SingleActivator(LogicalKeyboardKey.keyZ, meta: true, shift: true): _RedoIntent(),
        SingleActivator(LogicalKeyboardKey.keyY, control: true): _RedoIntent(),
      },
      child: Actions(
        actions: <Type, Action<Intent>>{
          _SaveIntent: CallbackAction<_SaveIntent>(onInvoke: (_) {
            _save();
            return null;
          }),
          _UndoIntent: CallbackAction<_UndoIntent>(onInvoke: (_) {
            _undo();
            return null;
          }),
          _RedoIntent: CallbackAction<_RedoIntent>(onInvoke: (_) {
            _redo();
            return null;
          }),
        },
        child: Focus(
          autofocus: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 760;
              final sidePickerOpen = _sidePickerType != null;
              // Важно: окно Sportoteka OS может быть уже 700 px, хотя весь экран
              // desktop широкий. Поэтому picker не должен зависеть от ширины окна.
              // На широком окне он занимает правую колонку, на узком — выезжает
              // поверх правой части ЭТОГО ЖЕ окна, без route/dialog/bottom sheet.
              final showAside = widget.showTemplates &&
                  constraints.maxWidth >= 1120 &&
                  !sidePickerOpen;
              final splitPicker = sidePickerOpen && constraints.maxWidth >= 860;
              final sideWidth = splitPicker
                  ? (constraints.maxWidth * .36).clamp(330.0, 430.0).toDouble()
                  : (constraints.maxWidth * .88).clamp(280.0, 430.0).toDouble();

              final editorBody = Row(
                children: [
                  if (showAside) _buildAside(),
                  Expanded(child: _buildEditor(compact: compact)),
                  if (splitPicker)
                    SizedBox(
                      width: sideWidth,
                      child: WorkspaceLiveBlockPickerPane(
                        type: _sidePickerType!,
                        onClose: () => setState(() => _sidePickerType = null),
                        onSelected: (block) async => _acceptLiveBlock(block),
                      ),
                    ),
                ],
              );

              final editor = Material(
                color: _surface,
                child: Column(
                  children: [
                    if (!widget.compactWorkspaceChrome)
                      _buildHeader(compact: compact),
                    Expanded(
                      child: sidePickerOpen && !splitPicker
                          ? Stack(
                              children: [
                                Positioned.fill(child: editorBody),
                                Positioned.fill(
                                  child: IgnorePointer(
                                    ignoring: false,
                                    child: GestureDetector(
                                      behavior: HitTestBehavior.translucent,
                                      onTap: () => setState(
                                          () => _sidePickerType = null),
                                      child: Container(
                                        color: Colors.black.withOpacity(.045),
                                      ),
                                    ),
                                  ),
                                ),
                                Positioned(
                                  top: 0,
                                  right: 0,
                                  bottom: 0,
                                  width: sideWidth,
                                  child: Material(
                                    color: Colors.white,
                                    elevation: 10,
                                    shadowColor: Colors.black.withOpacity(.10),
                                    child: WorkspaceLiveBlockPickerPane(
                                      type: _sidePickerType!,
                                      onClose: () => setState(
                                          () => _sidePickerType = null),
                                      onSelected: (block) async =>
                                          _acceptLiveBlock(block),
                                    ),
                                  ),
                                ),
                              ],
                            )
                          : editorBody,
                    ),
                  ],
                ),
              );

              if (!_aiEnabled) return editor;

              return CmrContextAiLayer(
                child: editor,
                expanded: _aiExpanded,
                onToggle: () => setState(() => _aiExpanded = !_aiExpanded),
                clubId: widget.aiClubId!,
                userId: widget.aiUserId!,
                teamId: widget.aiTeamId,
                clubName: widget.aiClubName,
                teamName: widget.aiTeamName,
                contextTitle: _aiContextTitle,
                contextSubtitle: _aiContextSubtitle,
                initialPrompt: _aiInitialPrompt(),
                initialPayload: _aiPayload(),
                panelKey: ValueKey<String>('workspace-ai:$_aiDocumentKey'),
                bottomInset: 12,
                showCollapsedLauncher: false,
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader({required bool compact}) {
    return Container(
      height: compact ? 62 : 68,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 18),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: _line)),
      ),
      child: Row(
        children: [
          if (widget.onClose != null) ...[
            _EditorHeaderButton(
              icon: SportotekaWorkspaceIconKind.close,
              tooltip: 'Закрыть редактор',
              onTap: _requestClose,
            ),
            const SizedBox(width: 8),
          ],
          const _EditorMosaicMark(size: 26),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  _methodDocumentMode
                      ? (_titleController.text.trim().isEmpty
                          ? widget.initialTitle
                          : _titleController.text.trim())
                      : 'SPORTOTEKA OS',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: _methodDocumentMode
                      ? AppTypography.sectionTitle(color: _text)
                          .copyWith(fontSize: compact ? 14.5 : 15.5)
                      : AppTypography.menuGroup(color: _green),
                ),
                if (!compact)
                  Text(
                    _methodDocumentMode
                        ? (widget.contextName.trim().isEmpty
                            ? 'Методические материалы · SPORTOTEKA OS'
                            : 'Методические материалы · ${widget.contextName}')
                        : (widget.contextName.trim().isEmpty
                            ? widget.contextLabel
                            : '${widget.contextLabel} · ${widget.contextName}'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.caption(color: _muted),
                  ),
              ],
            ),
          ),
          _EditorSaveState(
            compact: compact,
            saving: _saving,
            dirty: _dirty,
            failed: _saveError,
            readOnly: widget.readOnly,
          ),
          const SizedBox(width: 6),
          IconButton(
            tooltip: 'Копировать весь текст',
            onPressed: _copyDocument,
            icon: const Icon(Icons.copy_all_rounded, size: 18, color: _muted),
          ),
          if (!widget.readOnly && widget.onSave != null) ...[
            const SizedBox(width: 8),
            FilledButton(
              onPressed: _saving || !_dirty ? null : _save,
              style: FilledButton.styleFrom(
                elevation: 0,
                backgroundColor: _green,
                disabledBackgroundColor: const Color(0xFFDCE5E0),
                padding: EdgeInsets.symmetric(
                    horizontal: compact ? 12 : 16, vertical: 12),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SportotekaWorkspaceIcon(
                    kind: SportotekaWorkspaceIconKind.save,
                    size: 16,
                    color: Colors.white,
                    accentColor: Colors.white,
                  ),
                  if (!compact) ...[
                    const SizedBox(width: 7),
                    Text('Сохранить',
                        style: AppTypography.actionStrong(color: Colors.white)),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAside() {
    return Container(
      width: 246,
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(right: BorderSide(color: _line)),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
        children: [
          Text('КОНТЕКСТ', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.72),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                        width: 8,
                        height: 8,
                        decoration: const BoxDecoration(
                            color: _green, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(widget.contextLabel,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: AppTypography.menuTitle(color: _text)),
                    ),
                  ],
                ),
                if (widget.contextName.trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(widget.contextName,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: AppTypography.itemTitle(color: _text)),
                ],
                const SizedBox(height: 9),
                Text(widget.documentType,
                    style: AppTypography.caption(color: _muted)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (!widget.readOnly) ...[
            Text('УМНЫЙ ДОКУМЕНТ',
                style: AppTypography.menuGroup(color: _muted)),
            const SizedBox(height: 9),
            _EditorTemplateButton(
                title: 'Собрать отчёт из блоков', onTap: _buildSmartReport),
            const SizedBox(height: 22),
          ],
          Text('БЫСТРЫЙ СТАРТ', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 9),
          for (final template in _templates)
            _EditorTemplateButton(
                title: template.title, onTap: () => _insertTemplate(template)),
          const SizedBox(height: 22),
          if (!widget.readOnly) ...[
            Text('ЖИВЫЕ БЛОКИ', style: AppTypography.menuGroup(color: _muted)),
            const SizedBox(height: 9),
            _EditorLiveBlockButton(
              title: 'План-конспект',
              subtitle: 'Живой план + PDF snapshot',
              onTap: _insertPlanBlock,
            ),
            const SizedBox(height: 7),
            _EditorLiveBlockButton(
              title: 'Матч',
              subtitle: 'Счёт, соперник и дата',
              iconKind: SportotekaWorkspaceIconKind.matches,
              onTap: () => _insertLiveBlock(WorkspaceLiveBlockType.match),
            ),
            const SizedBox(height: 7),
            _EditorLiveBlockButton(
              title: 'Игрок / Tracker',
              subtitle: 'Игроки и физические данные',
              iconKind: SportotekaWorkspaceIconKind.players,
              onTap: () => _insertLiveBlock(WorkspaceLiveBlockType.player),
            ),
            const SizedBox(height: 22),
          ],
          Text('ПОДСКАЗКА', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 8),
          Text(
            'Выделите текст и примените формат. ⌘S или Ctrl+S сохраняет документ сразу.',
            style: AppTypography.caption(color: _muted).copyWith(height: 1.45),
          ),
        ],
      ),
    );
  }

  Widget _buildEditor({required bool compact}) {
    return Column(
      children: [
        _EditorToolbar(
          compact: compact,
          wordCompact: widget.compactWorkspaceChrome,
          readOnly: widget.readOnly,
          visualMode: _visualMode,
          saving: _saving,
          dirty: _dirty,
          failed: _saveError,
          canSave: !widget.readOnly && widget.onSave != null,
          onSave: _save,
          canUndo: _canUndo,
          canRedo: _canRedo,
          onUndo: _undo,
          onRedo: _redo,
          onVisualModeChanged: _setVisualMode,
          onFontSize: _applyFontSize,
          onTextColor: _applyTextColor,
          onHighlight: _applyHighlight,
          onAlignment: _applyAlignment,
          onBold: () => _wrapSelection('**', '**'),
          onItalic: () => _wrapSelection('_', '_'),
          onUnderline: () => _wrapSelection('__', '__'),
          onStrike: () => _wrapSelection('~~', '~~'),
          onHeading: () => _prefixSelection('## '),
          onBullet: () => _prefixSelection('• '),
          onNumbered: () => _prefixSelection('1. '),
          onChecklist: () => _prefixSelection('☐ '),
          onQuote: () => _prefixSelection('> '),
          onCopy: _copySelection,
          onCut: _cutSelection,
          onPaste: _pasteClipboard,
          onSelectAll: _selectAllBody,
          onDuplicate: _duplicateSelection,
          onLink: _insertLink,
          onImage: _insertImage,
          onImageSmaller: () => _resizeNearestImage(-10),
          onImageLarger: () => _resizeNearestImage(10),
          onTable: _insertTable,
          onRule: _insertHorizontalRule,
          onDateTime: _insertDateTime,
          onInsert: _insertLiveBlock,
          onAiAnalysis:
              (_aiEnabled || _methodDocumentMode) ? _openAiAnalysis : null,
          aiActive: _aiExpanded,
        ),
        if (compact && widget.showTemplates && !widget.readOnly)
          SizedBox(
            height: 48,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              itemCount: _templates.length + 2,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (_, index) {
                if (index == 0) {
                  return ActionChip(
                    onPressed: _buildSmartReport,
                    backgroundColor: const Color(0xFFEAF5EF),
                    side: BorderSide.none,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(999)),
                    label: Text('Собрать отчёт',
                        style: AppTypography.captionMedium(color: _green)),
                  );
                }
                if (index == 1) {
                  return ActionChip(
                    onPressed: _insertPlanBlock,
                    backgroundColor: Colors.white,
                    side: BorderSide.none,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(999)),
                    label: Text('+ План-конспект',
                        style: AppTypography.captionMedium(color: _green)),
                  );
                }
                final template = _templates[index - 2];
                return ActionChip(
                  onPressed: () => _insertTemplate(template),
                  backgroundColor: Colors.white,
                  side: BorderSide.none,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(999)),
                  label: Text(template.title,
                      style: AppTypography.captionMedium(color: _text)),
                );
              },
            ),
          ),
        if (_visualMode && !compact) const _WordRuler(),
        Expanded(
          child: ColoredBox(
            color: const Color(0xFFF1F3F2),
            child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              compact ? 10 : 26,
              compact ? 12 : 22,
              compact ? 10 : 26,
              compact ? 28 : 44,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: compact ? 900 : 794,
                  minHeight: compact ? 520 : 1120,
                ),
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                    compact ? 18 : 38,
                    compact ? 20 : 30,
                    compact ? 18 : 38,
                    compact ? 30 : 44,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(compact ? 12 : 14),
                    boxShadow: const <BoxShadow>[
                      BoxShadow(
                          color: Color(0x0E142219),
                          blurRadius: 30,
                          spreadRadius: -8,
                          offset: Offset(0, 12)),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          const _EditorMosaicStrip(),
                          const SizedBox(width: 10),
                          Expanded(
                              child: Text(widget.documentType.toUpperCase(),
                                  style:
                                      AppTypography.menuGroup(color: _muted))),
                          Text(_todayLabel(),
                              style: AppTypography.caption(color: _muted)),
                        ],
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _titleController,
                        readOnly: widget.readOnly || widget.titleReadOnly,
                        maxLines: null,
                        decoration: InputDecoration.collapsed(
                          hintText: 'Название заметки',
                          hintStyle: AppTypography.screenTitle(
                                  color: const Color(0xFFAAB2AD))
                              .copyWith(fontSize: compact ? 20 : 24),
                        ),
                        style: AppTypography.screenTitle(color: _text).copyWith(
                            fontSize: compact ? 20 : 24, height: 1.16),
                      ),
                      const SizedBox(height: 13),
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: [
                          _EditorMetaChip(text: widget.contextLabel),
                          if (widget.contextName.trim().isNotEmpty)
                            _EditorMetaChip(text: widget.contextName),
                          _EditorMetaChip(text: '$_wordCount слов'),
                        ],
                      ),
                      const SizedBox(height: 22),
                      const Divider(height: 1, color: _line),
                      const SizedBox(height: 18),
                      if (_liveBlocksLoading)
                        const Padding(
                          padding: EdgeInsets.only(bottom: 14),
                          child: LinearProgressIndicator(
                              minHeight: 2,
                              color: _green,
                              backgroundColor: Color(0xFFEAF1ED)),
                        ),
                      if (_liveBlocks.isNotEmpty) ...[
                        Row(
                          children: [
                            Text('СВЯЗАННЫЕ МАТЕРИАЛЫ',
                                style: AppTypography.menuGroup(color: _muted)),
                            const SizedBox(width: 8),
                            const _EditorMosaicStrip(),
                          ],
                        ),
                        const SizedBox(height: 10),
                        for (int index = 0;
                            index < _liveBlocks.length;
                            index++) ...[
                          WorkspaceLiveBlockCard(
                            key: ValueKey(
                                '${_liveBlocks[index].type.name}:${_liveBlocks[index].entityId}'),
                            block: _liveBlocks[index],
                            readOnly: widget.readOnly,
                            onChanged: (value) =>
                                _replaceLiveBlock(index, value),
                            onRemove: () => _removeLiveBlock(index),
                          ),
                          const SizedBox(height: 9),
                        ],
                        const SizedBox(height: 8),
                        const Divider(height: 1, color: _line),
                        const SizedBox(height: 18),
                      ] else
                        const SizedBox(height: 4),
                      if (_methodDocumentMode) ...[
                        _ImportedSourceDocumentBlock(
                          filename: _sourceDocumentName,
                          extension: _sourceDocumentExtension,
                          sizeLabel: _sourceSizeLabel(),
                          onOpen: _sourceDocumentUrl.isEmpty
                              ? null
                              : _openOriginalSourceDocument,
                        ),
                        const SizedBox(height: 18),
                        Row(
                          children: [
                            const Icon(
                              Icons.text_snippet_outlined,
                              size: 18,
                              color: _green,
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: Text(
                                'РАСПОЗНАННЫЙ ТЕКСТ',
                                style: AppTypography.menuGroup(
                                  color: _muted,
                                ),
                              ),
                            ),
                            if (_showImportedTextBlock)
                              TextButton.icon(
                                onPressed: () => setState(
                                  () => _showImportedTextBlock = false,
                                ),
                                icon: const Icon(
                                  Icons.close_rounded,
                                  size: 16,
                                ),
                                label: const Text('Убрать блок'),
                                style: TextButton.styleFrom(
                                  foregroundColor: _muted,
                                ),
                              )
                            else
                              TextButton.icon(
                                onPressed: () => setState(
                                  () => _showImportedTextBlock = true,
                                ),
                                icon: const Icon(
                                  Icons.add_rounded,
                                  size: 16,
                                ),
                                label: const Text('Вернуть текст'),
                                style: TextButton.styleFrom(
                                  foregroundColor: _green,
                                ),
                              ),
                          ],
                        ),
                        const SizedBox(height: 8),
                        if (_showImportedTextBlock)
                          Container(
                            padding: EdgeInsets.all(compact ? 12 : 16),
                            decoration: BoxDecoration(
                              color: const Color(0xFFFBFCFB),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _line),
                            ),
                            child: TextField(
                              controller: _bodyController,
                              focusNode: _bodyFocus,
                              readOnly: widget.readOnly,
                              minLines: compact ? 18 : 24,
                              maxLines: null,
                              keyboardType: TextInputType.multiline,
                              textCapitalization: TextCapitalization.sentences,
                              decoration: InputDecoration.collapsed(
                                hintText: 'Распознанный текст документа…',
                                hintStyle: AppTypography.body(
                                  color: const Color(0xFFA2ABA5),
                                ).copyWith(
                                  fontSize: compact ? 14 : 15,
                                  height: 1.62,
                                ),
                              ),
                              style: AppTypography.body(color: _text).copyWith(
                                fontSize: compact ? 14 : 15,
                                height: 1.62,
                              ),
                            ),
                          )
                        else
                          Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 12,
                            ),
                            decoration: BoxDecoration(
                              color: const Color(0xFFF5F8F6),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: _line),
                            ),
                            child: Text(
                              'Распознанный текст скрыт. Оригинальный файл '
                              'сохранён выше и текст можно вернуть в любой момент.',
                              style: AppTypography.caption(color: _muted),
                            ),
                          ),
                      ] else if (_visualMode)
                        _buildVisualDocument(compact: compact)
                      else
                        TextField(
                          controller: _bodyController,
                          focusNode: _bodyFocus,
                          readOnly: widget.readOnly,
                          minLines: compact ? 20 : 26,
                          maxLines: null,
                          keyboardType: TextInputType.multiline,
                          textCapitalization: TextCapitalization.sentences,
                          decoration: InputDecoration.collapsed(
                            hintText:
                                'Начните писать или выберите шаблон заметки…',
                            hintStyle: AppTypography.body(
                              color: const Color(0xFFA2ABA5),
                            ).copyWith(
                              fontSize: compact ? 14 : 15,
                              height: 1.62,
                            ),
                          ),
                          style: AppTypography.body(color: _text).copyWith(
                            fontSize: compact ? 14 : 15,
                            height: 1.62,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
            ),
          ),
        ),
        Container(
          height: widget.compactWorkspaceChrome ? 24 : 31,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(top: BorderSide(color: _line)),
          ),
          child: Row(
            children: [
              Text('$_wordCount слов · ${_bodyController.text.length} знаков',
                  style: AppTypography.caption(color: _muted)),
              const Spacer(),
              if (!compact && !widget.compactWorkspaceChrome)
                Text(
                  widget.autoSave && widget.onSave != null
                      ? 'Автосохранение включено'
                      : 'Сохранение вручную',
                  style: AppTypography.caption(color: _muted),
                ),
            ],
          ),
        ),
      ],
    );
  }

  String _todayLabel() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(now.day)}.${two(now.month)}.${now.year}';
  }
}



class _WordRuler extends StatelessWidget {
  const _WordRuler();

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 26,
      color: const Color(0xFFF7F8F7),
      child: Row(
        children: [
          const SizedBox(width: 18),
          Expanded(
            child: CustomPaint(
              painter: _WordRulerPainter(),
            ),
          ),
          const SizedBox(width: 18),
        ],
      ),
    );
  }
}

class _WordRulerPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final minor = Paint()
      ..color = const Color(0xFFCFD6D2)
      ..strokeWidth = 1;
    final major = Paint()
      ..color = const Color(0xFFAAB4AE)
      ..strokeWidth = 1;
    final baseline = Paint()
      ..color = const Color(0xFFE2E6E3)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, size.height - 1), Offset(size.width, size.height - 1), baseline);
    const step = 18.0;
    var x = 0.0;
    var index = 0;
    while (x <= size.width) {
      final isMajor = index % 5 == 0;
      final height = isMajor ? 9.0 : (index % 2 == 0 ? 6.0 : 4.0);
      canvas.drawLine(
        Offset(x, size.height - 1),
        Offset(x, size.height - 1 - height),
        isMajor ? major : minor,
      );
      x += step;
      index++;
    }
  }

  @override
  bool shouldRepaint(covariant _WordRulerPainter oldDelegate) => false;
}

enum _WorkspaceDocBlockKind { text, image, table, rule, spacer }

class _WorkspaceDocLine {
  const _WorkspaceDocLine({
    required this.text,
    required this.start,
    required this.end,
  });

  final String text;
  final int start;
  final int end;
}

class _InlineImageCaptionEditor extends StatefulWidget {
  const _InlineImageCaptionEditor({
    super.key,
    required this.initialValue,
    required this.onSave,
  });

  final String initialValue;
  final ValueChanged<String> onSave;

  @override
  State<_InlineImageCaptionEditor> createState() =>
      _InlineImageCaptionEditorState();
}

class _InlineImageCaptionEditorState
    extends State<_InlineImageCaptionEditor> {
  late final TextEditingController _controller;
  late final FocusNode _focus;
  String _lastSaved = '';

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
    _lastSaved = widget.initialValue;
    _focus = FocusNode()..addListener(_handleFocus);
  }

  void _handleFocus() {
    if (!_focus.hasFocus) _save();
  }

  void _save() {
    final value = _controller.text.trim();
    if (value == _lastSaved) return;
    _lastSaved = value;
    widget.onSave(value);
  }

  @override
  void dispose() {
    _save();
    _focus
      ..removeListener(_handleFocus)
      ..dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _controller,
      focusNode: _focus,
      maxLines: 2,
      minLines: 1,
      textAlign: TextAlign.center,
      textInputAction: TextInputAction.done,
      onSubmitted: (_) => _save(),
      decoration: InputDecoration(
        hintText: 'Подпись к изображению',
        isDense: true,
        filled: true,
        fillColor: const Color(0xFFF7F8F7),
        contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide.none,
        ),
        suffixIcon: IconButton(
          tooltip: 'Сохранить подпись',
          onPressed: _save,
          icon: const Icon(Icons.check_rounded, size: 16, color: Color(0xFF177B57)),
        ),
      ),
      style: AppTypography.caption(color: const Color(0xFF758079)),
    );
  }
}

class _InlineTableCellEditor extends StatefulWidget {
  const _InlineTableCellEditor({
    super.key,
    required this.initialValue,
    required this.readOnly,
    required this.header,
    required this.compact,
    required this.onSave,
  });

  final String initialValue;
  final bool readOnly;
  final bool header;
  final bool compact;
  final ValueChanged<String> onSave;

  @override
  State<_InlineTableCellEditor> createState() => _InlineTableCellEditorState();
}

class _InlineTableCellEditorState extends State<_InlineTableCellEditor> {
  late final TextEditingController _controller;
  late final FocusNode _focus;
  String _lastSaved = '';

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
    _lastSaved = widget.initialValue;
    _focus = FocusNode()..addListener(_handleFocus);
  }

  void _handleFocus() {
    if (!_focus.hasFocus) _save();
  }

  void _save() {
    if (widget.readOnly) return;
    final value = _controller.text.trim();
    if (value == _lastSaved) return;
    _lastSaved = value;
    widget.onSave(value);
  }

  @override
  void dispose() {
    _save();
    _focus
      ..removeListener(_handleFocus)
      ..dispose();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: _controller,
      focusNode: _focus,
      readOnly: widget.readOnly,
      minLines: 1,
      maxLines: 4,
      keyboardType: TextInputType.multiline,
      textInputAction: TextInputAction.newline,
      decoration: InputDecoration(
        isDense: true,
        border: InputBorder.none,
        enabledBorder: InputBorder.none,
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Color(0xFF177B57), width: .8),
        ),
        contentPadding: EdgeInsets.symmetric(
          horizontal: widget.compact ? 7 : 9,
          vertical: widget.compact ? 7 : 9,
        ),
      ),
      onSubmitted: (_) => _save(),
      style: (widget.header
              ? AppTypography.captionMedium(color: const Color(0xFF101814))
              : AppTypography.caption(color: const Color(0xFF101814)))
          .copyWith(fontSize: widget.compact ? 11.5 : 12.5),
    );
  }
}

class _WorkspaceDocBlock {
  const _WorkspaceDocBlock({
    required this.kind,
    required this.start,
    required this.end,
    required this.raw,
    this.image,
  });

  final _WorkspaceDocBlockKind kind;
  final int start;
  final int end;
  final String raw;
  final _WorkspaceVisualImageData? image;
}

class _WorkspaceVisualImageData {
  const _WorkspaceVisualImageData({
    required this.caption,
    required this.url,
    required this.widthPercent,
    required this.alignment,
  });

  final String caption;
  final String url;
  final int widthPercent;
  final String alignment;

  static _WorkspaceVisualImageData? tryParse(String raw) {
    final match = RegExp(
      r'^!\[([^\]]*)\]\(([^\)]+)\)\{width=(\d+)%(?:;align=(left|center|right))?\}\s*$',
    ).firstMatch(raw.trim());
    if (match == null) return null;
    return _WorkspaceVisualImageData(
      caption: match.group(1) ?? '',
      url: match.group(2) ?? '',
      widthPercent: (int.tryParse(match.group(3) ?? '') ?? 100).clamp(20, 100).toInt(),
      alignment: match.group(4) ?? 'center',
    );
  }

  _WorkspaceVisualImageData copyWith({
    String? caption,
    String? url,
    int? widthPercent,
    String? alignment,
  }) {
    return _WorkspaceVisualImageData(
      caption: caption ?? this.caption,
      url: url ?? this.url,
      widthPercent: widthPercent ?? this.widthPercent,
      alignment: alignment ?? this.alignment,
    );
  }

  String toMarkup() =>
      '![$caption]($url){width=${widthPercent.clamp(20, 100)}%;align=$alignment}';
}

class _WorkspaceTextBlockStyle {
  const _WorkspaceTextBlockStyle({
    required this.content,
    required this.headingLevel,
    required this.quote,
    required this.textAlign,
  });

  final String content;
  final int headingLevel;
  final bool quote;
  final TextAlign textAlign;

  static _WorkspaceTextBlockStyle parse(String raw) {
    var value = raw;
    var align = TextAlign.left;
    final alignMatch = RegExp(r'^<align:(left|center|right|justify)>').firstMatch(value);
    if (alignMatch != null) {
      switch (alignMatch.group(1)) {
        case 'center':
          align = TextAlign.center;
          break;
        case 'right':
          align = TextAlign.right;
          break;
        case 'justify':
          align = TextAlign.justify;
          break;
        default:
          align = TextAlign.left;
      }
      value = value.substring(alignMatch.end);
    }

    var heading = 0;
    if (value.startsWith('### ')) {
      heading = 3;
      value = value.substring(4);
    } else if (value.startsWith('## ')) {
      heading = 2;
      value = value.substring(3);
    } else if (value.startsWith('# ')) {
      heading = 1;
      value = value.substring(2);
    }

    var quote = false;
    if (value.startsWith('> ')) {
      quote = true;
      value = value.substring(2);
    }

    return _WorkspaceTextBlockStyle(
      content: value,
      headingLevel: heading,
      quote: quote,
      textAlign: align,
    );
  }

  TextStyle baseStyle({required bool compact, required Color color}) {
    if (headingLevel == 1) {
      return AppTypography.screenTitle(color: color).copyWith(
        fontSize: compact ? 22 : 26,
        height: 1.25,
      );
    }
    if (headingLevel == 2) {
      return AppTypography.sectionTitle(color: color).copyWith(
        fontSize: compact ? 18 : 21,
        height: 1.3,
      );
    }
    if (headingLevel == 3) {
      return AppTypography.subsectionTitle(color: color).copyWith(
        fontSize: compact ? 15.5 : 17,
        height: 1.4,
      );
    }
    return AppTypography.body(color: color).copyWith(
      fontSize: compact ? 14 : 15,
      height: 1.62,
      fontStyle: quote ? FontStyle.italic : FontStyle.normal,
    );
  }
}

Color _workspaceHexColor(String raw, Color fallback) {
  var value = raw.trim().replaceAll('#', '');
  if (value.length == 6) value = 'FF$value';
  if (value.length != 8) return fallback;
  final parsed = int.tryParse(value, radix: 16);
  return parsed == null ? fallback : Color(parsed);
}

TextSpan _workspaceRichSpan(String raw, TextStyle baseStyle) {
  final children = <InlineSpan>[];
  final token = RegExp(
    r'(\*\*(.+?)\*\*|__(.+?)__|~~(.+?)~~|_(.+?)_|<fs:(\d{1,2})>(.+?)</fs>|<c:([0-9A-Fa-f]{6,8})>(.+?)</c>|<bg:([0-9A-Fa-f]{6,8})>(.+?)</bg>|\[([^\]]+)\]\(([^\)]+)\))',
  );
  var cursor = 0;
  for (final match in token.allMatches(raw)) {
    if (match.start > cursor) {
      children.add(TextSpan(text: raw.substring(cursor, match.start), style: baseStyle));
    }
    final whole = match.group(0) ?? '';
    TextStyle style = baseStyle;
    String text = whole;
    if (whole.startsWith('**')) {
      text = match.group(2) ?? '';
      style = style.copyWith(fontWeight: FontWeight.w700);
    } else if (whole.startsWith('__')) {
      text = match.group(3) ?? '';
      style = style.copyWith(decoration: TextDecoration.underline);
    } else if (whole.startsWith('~~')) {
      text = match.group(4) ?? '';
      style = style.copyWith(decoration: TextDecoration.lineThrough);
    } else if (whole.startsWith('_')) {
      text = match.group(5) ?? '';
      style = style.copyWith(fontStyle: FontStyle.italic);
    } else if (whole.startsWith('<fs:')) {
      text = match.group(7) ?? '';
      final size = double.tryParse(match.group(6) ?? '');
      if (size != null) style = style.copyWith(fontSize: size.clamp(8, 48).toDouble());
    } else if (whole.startsWith('<c:')) {
      text = match.group(9) ?? '';
      style = style.copyWith(
        color: _workspaceHexColor(match.group(8) ?? '', baseStyle.color ?? Colors.black),
      );
    } else if (whole.startsWith('<bg:')) {
      text = match.group(11) ?? '';
      style = style.copyWith(
        backgroundColor: _workspaceHexColor(match.group(10) ?? '', Colors.transparent),
      );
    } else if (whole.startsWith('[')) {
      text = match.group(12) ?? '';
      style = style.copyWith(
        color: const Color(0xFF0B8F55),
        decoration: TextDecoration.underline,
      );
    }
    children.add(TextSpan(text: text, style: style));
    cursor = match.end;
  }
  if (cursor < raw.length) {
    children.add(TextSpan(text: raw.substring(cursor), style: baseStyle));
  }
  if (children.isEmpty) return TextSpan(text: raw, style: baseStyle);
  return TextSpan(style: baseStyle, children: children);
}

class _WorkspaceRichTextController extends TextEditingController {
  _WorkspaceRichTextController({String? text}) : super(text: text);

  @override
  TextSpan buildTextSpan({
    required BuildContext context,
    TextStyle? style,
    required bool withComposing,
  }) {
    final base = style ?? const TextStyle();
    // Во время редактирования маркеры остаются видимыми, чтобы курсор и
    // выделение всегда совпадали с реальным текстом. Само форматирование
    // показывается сразу цветом/начертанием там, где это возможно.
    return TextSpan(text: text, style: base);
  }
}

class _WordObjectButton extends StatelessWidget {
  const _WordObjectButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
    this.active = false,
    this.danger = false,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback onTap;
  final bool active;
  final bool danger;

  @override
  Widget build(BuildContext context) {
    final color = danger
        ? const Color(0xFFB42318)
        : active
            ? const Color(0xFF0B8F55)
            : const Color(0xFF667085);
    return Tooltip(
      message: tooltip,
      child: Material(
        color: active ? const Color(0xFFEAF5EF) : const Color(0xFFF7F8F7),
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(8),
          child: SizedBox(
            width: 32,
            height: 30,
            child: Icon(icon, size: 16, color: color),
          ),
        ),
      ),
    );
  }
}

class _WordObjectLabel extends StatelessWidget {
  const _WordObjectLabel({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 30,
      alignment: Alignment.center,
      padding: const EdgeInsets.symmetric(horizontal: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F8F7),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: AppTypography.captionMedium(color: const Color(0xFF667085)),
      ),
    );
  }
}

class _EditorToolbar extends StatelessWidget {
  const _EditorToolbar({
    required this.compact,
    required this.wordCompact,
    required this.readOnly,
    required this.visualMode,
    required this.saving,
    required this.dirty,
    required this.failed,
    required this.canSave,
    required this.onSave,
    required this.canUndo,
    required this.canRedo,
    required this.onUndo,
    required this.onRedo,
    required this.onVisualModeChanged,
    required this.onFontSize,
    required this.onTextColor,
    required this.onHighlight,
    required this.onAlignment,
    required this.onBold,
    required this.onItalic,
    required this.onUnderline,
    required this.onStrike,
    required this.onHeading,
    required this.onBullet,
    required this.onNumbered,
    required this.onChecklist,
    required this.onQuote,
    required this.onCopy,
    required this.onCut,
    required this.onPaste,
    required this.onSelectAll,
    required this.onDuplicate,
    required this.onLink,
    required this.onImage,
    required this.onImageSmaller,
    required this.onImageLarger,
    required this.onTable,
    required this.onRule,
    required this.onDateTime,
    required this.onInsert,
    this.onAiAnalysis,
    this.aiActive = false,
  });

  final bool compact;
  final bool wordCompact;
  final bool readOnly;
  final bool visualMode;
  final bool saving;
  final bool dirty;
  final bool failed;
  final bool canSave;
  final VoidCallback onSave;
  final bool canUndo;
  final bool canRedo;
  final VoidCallback onUndo;
  final VoidCallback onRedo;
  final ValueChanged<bool> onVisualModeChanged;
  final ValueChanged<int> onFontSize;
  final ValueChanged<String> onTextColor;
  final ValueChanged<String> onHighlight;
  final ValueChanged<String> onAlignment;
  final VoidCallback onBold;
  final VoidCallback onItalic;
  final VoidCallback onUnderline;
  final VoidCallback onStrike;
  final VoidCallback onHeading;
  final VoidCallback onBullet;
  final VoidCallback onNumbered;
  final VoidCallback onChecklist;
  final VoidCallback onQuote;
  final VoidCallback onCopy;
  final VoidCallback onCut;
  final VoidCallback onPaste;
  final VoidCallback onSelectAll;
  final VoidCallback onDuplicate;
  final VoidCallback onLink;
  final VoidCallback onImage;
  final VoidCallback onImageSmaller;
  final VoidCallback onImageLarger;
  final VoidCallback onTable;
  final VoidCallback onRule;
  final VoidCallback onDateTime;
  final ValueChanged<WorkspaceLiveBlockType> onInsert;
  final VoidCallback? onAiAnalysis;
  final bool aiActive;

  @override
  Widget build(BuildContext context) {
    final primaryActions = <Widget>[
      _EditorMaterialToolButton(
        icon: Icons.undo_rounded,
        tooltip: 'Отменить',
        onTap: canUndo ? onUndo : null,
      ),
      _EditorMaterialToolButton(
        icon: Icons.redo_rounded,
        tooltip: 'Повторить',
        onTap: canRedo ? onRedo : null,
      ),
      const _EditorToolDivider(),
      _EditorFontSizeButton(onSelected: onFontSize),
      _EditorPaletteButton(
        icon: Icons.format_color_text_rounded,
        tooltip: 'Цвет текста',
        onSelected: onTextColor,
        colors: const <String>[
          '101814', '0B8F55', '315447', '2563EB', '7C3AED', 'B42318', 'B54708',
        ],
      ),
      _EditorPaletteButton(
        icon: Icons.format_color_fill_rounded,
        tooltip: 'Выделение цветом',
        onSelected: onHighlight,
        colors: const <String>[
          'EAF5EF', 'FFF1B8', 'FDE2E2', 'E5EDFF', 'EFE7FF', 'F2F4F7',
        ],
      ),
      _EditorAlignmentButton(onSelected: onAlignment),
      const _EditorToolDivider(),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.heading,
          tooltip: 'Заголовок',
          onTap: onHeading),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.bold,
          tooltip: 'Жирный',
          onTap: onBold),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.italic,
          tooltip: 'Курсив',
          onTap: onItalic),
      _EditorTextToolButton(
          label: 'U', tooltip: 'Подчёркнутый', onTap: onUnderline),
      _EditorTextToolButton(
          label: 'S̶', tooltip: 'Зачёркнутый', onTap: onStrike),
      const _EditorToolDivider(),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.bullets,
          tooltip: 'Список',
          onTap: onBullet),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.numbered,
          tooltip: 'Нумерованный список',
          onTap: onNumbered),
      _EditorTextToolButton(label: '☐', tooltip: 'Задача', onTap: onChecklist),
      _EditorToolButton(
          icon: SportotekaWorkspaceIconKind.quote,
          tooltip: 'Цитата',
          onTap: onQuote),
      const _EditorToolDivider(),
      _EditorMaterialToolButton(
          icon: Icons.link_rounded, tooltip: 'Ссылка', onTap: onLink),
      _EditorMaterialToolButton(
          icon: Icons.image_outlined, tooltip: 'Вставить фото', onTap: onImage),
      _EditorMaterialToolButton(
          icon: Icons.table_chart_outlined, tooltip: 'Таблица', onTap: onTable),
      _EditorInsertButton(onInsert: onInsert),
      if (onAiAnalysis != null) ...[
        const SizedBox(width: 3),
        _EditorAiButton(onTap: onAiAnalysis!, active: aiActive),
      ],
    ];

    final fullActions = <Widget>[
      ...primaryActions.take(2),
      const _EditorToolDivider(),
      _EditorFontSizeButton(onSelected: onFontSize),
      _EditorPaletteButton(
        icon: Icons.format_color_text_rounded,
        tooltip: 'Цвет текста',
        onSelected: onTextColor,
        colors: const <String>[
          '101814', '0B8F55', '315447', '2563EB', '7C3AED', 'B42318', 'B54708',
        ],
      ),
      _EditorPaletteButton(
        icon: Icons.format_color_fill_rounded,
        tooltip: 'Выделение цветом',
        onSelected: onHighlight,
        colors: const <String>[
          'EAF5EF', 'FFF1B8', 'FDE2E2', 'E5EDFF', 'EFE7FF', 'F2F4F7',
        ],
      ),
      _EditorAlignmentButton(onSelected: onAlignment),
      const _EditorToolDivider(),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.heading, tooltip: 'Заголовок', onTap: onHeading),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.bold, tooltip: 'Жирный', onTap: onBold),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.italic, tooltip: 'Курсив', onTap: onItalic),
      _EditorTextToolButton(label: 'U', tooltip: 'Подчёркнутый', onTap: onUnderline),
      _EditorTextToolButton(label: 'S̶', tooltip: 'Зачёркнутый', onTap: onStrike),
      const _EditorToolDivider(),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.bullets, tooltip: 'Список', onTap: onBullet),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.numbered, tooltip: 'Нумерованный список', onTap: onNumbered),
      _EditorTextToolButton(label: '☐', tooltip: 'Задача', onTap: onChecklist),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.quote, tooltip: 'Цитата', onTap: onQuote),
      const _EditorToolDivider(),
      _EditorMaterialToolButton(icon: Icons.content_copy_rounded, tooltip: 'Копировать', onTap: onCopy),
      _EditorMaterialToolButton(icon: Icons.content_cut_rounded, tooltip: 'Вырезать', onTap: onCut),
      _EditorMaterialToolButton(icon: Icons.content_paste_rounded, tooltip: 'Вставить', onTap: onPaste),
      _EditorMaterialToolButton(icon: Icons.select_all_rounded, tooltip: 'Выделить всё', onTap: onSelectAll),
      _EditorMaterialToolButton(icon: Icons.control_point_duplicate_rounded, tooltip: 'Дублировать выделение', onTap: onDuplicate),
      const _EditorToolDivider(),
      _EditorMaterialToolButton(icon: Icons.link_rounded, tooltip: 'Ссылка', onTap: onLink),
      _EditorMaterialToolButton(icon: Icons.image_outlined, tooltip: 'Вставить фото', onTap: onImage),
      _EditorMaterialToolButton(icon: Icons.photo_size_select_small_rounded, tooltip: 'Уменьшить ближайшее фото', onTap: onImageSmaller),
      _EditorMaterialToolButton(icon: Icons.photo_size_select_large_rounded, tooltip: 'Увеличить ближайшее фото', onTap: onImageLarger),
      _EditorMaterialToolButton(icon: Icons.table_chart_outlined, tooltip: 'Таблица', onTap: onTable),
      _EditorMaterialToolButton(icon: Icons.horizontal_rule_rounded, tooltip: 'Разделитель', onTap: onRule),
      _EditorMaterialToolButton(icon: Icons.event_outlined, tooltip: 'Дата и время', onTap: onDateTime),
      const _EditorToolDivider(),
      _EditorInsertButton(onInsert: onInsert),
      if (onAiAnalysis != null) ...[
        const SizedBox(width: 4),
        _EditorAiButton(onTap: onAiAnalysis!, active: aiActive),
      ],
    ];

    final actions = wordCompact ? primaryActions : fullActions;

    return IgnorePointer(
      ignoring: readOnly,
      child: Opacity(
        opacity: readOnly ? .48 : 1,
        child: Container(
          height: wordCompact ? 44 : (compact ? 49 : 54),
          decoration: const BoxDecoration(
            color: Colors.white,
            border: Border(
                bottom: BorderSide(color: _WorkspaceDocumentEditorState._line)),
          ),
          child: Row(
            children: [
              if (!compact && !wordCompact) ...[
                const SizedBox(width: 16),
                Text('ФОРМАТ',
                    style: AppTypography.menuGroup(
                        color: _WorkspaceDocumentEditorState._muted)),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(
                      horizontal: compact || wordCompact ? 6 : 0,
                      vertical: wordCompact ? 2 : 5),
                  children: actions,
                ),
              ),
              if (wordCompact) ...[
                const SizedBox(width: 2),
                _EditorCompactMoreButton(
                  onCopy: onCopy,
                  onCut: onCut,
                  onPaste: onPaste,
                  onSelectAll: onSelectAll,
                  onDuplicate: onDuplicate,
                  onImageSmaller: onImageSmaller,
                  onImageLarger: onImageLarger,
                  onRule: onRule,
                  onDateTime: onDateTime,
                ),
                const SizedBox(width: 3),
                _EditorCompactSaveButton(
                  saving: saving,
                  dirty: dirty,
                  failed: failed,
                  enabled: canSave,
                  onSave: onSave,
                ),
              ],
              const SizedBox(width: 4),
              _EditorViewToggle(
                visualMode: visualMode,
                compact: compact || wordCompact,
                onChanged: onVisualModeChanged,
              ),
              const SizedBox(width: 6),
            ],
          ),
        ),
      ),
    );
  }
}



class _EditorCompactSaveButton extends StatelessWidget {
  const _EditorCompactSaveButton({
    required this.saving,
    required this.dirty,
    required this.failed,
    required this.enabled,
    required this.onSave,
  });

  final bool saving;
  final bool dirty;
  final bool failed;
  final bool enabled;
  final VoidCallback onSave;

  @override
  Widget build(BuildContext context) {
    final IconData icon;
    final Color color;
    final String tooltip;
    if (saving) {
      icon = Icons.sync_rounded;
      color = const Color(0xFF0B8F55);
      tooltip = 'Сохраняется…';
    } else if (failed) {
      icon = Icons.cloud_off_rounded;
      color = const Color(0xFFB42318);
      tooltip = 'Не синхронизировано — нажмите, чтобы повторить';
    } else if (dirty) {
      icon = Icons.cloud_upload_outlined;
      color = const Color(0xFFB54708);
      tooltip = 'Есть изменения — сохранить (⌘S / Ctrl+S)';
    } else {
      icon = Icons.cloud_done_outlined;
      color = const Color(0xFF0B8F55);
      tooltip = 'Сохранено';
    }

    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: enabled && !saving && (dirty || failed) ? onSave : null,
        child: SizedBox.square(
          dimension: 34,
          child: Center(
            child: saving
                ? const SizedBox(
                    width: 15,
                    height: 15,
                    child: CircularProgressIndicator(
                      strokeWidth: 1.8,
                      color: Color(0xFF0B8F55),
                    ),
                  )
                : Icon(icon, size: 18, color: color),
          ),
        ),
      ),
    );
  }
}

class _EditorCompactMoreButton extends StatelessWidget {
  const _EditorCompactMoreButton({
    required this.onCopy,
    required this.onCut,
    required this.onPaste,
    required this.onSelectAll,
    required this.onDuplicate,
    required this.onImageSmaller,
    required this.onImageLarger,
    required this.onRule,
    required this.onDateTime,
  });

  final VoidCallback onCopy;
  final VoidCallback onCut;
  final VoidCallback onPaste;
  final VoidCallback onSelectAll;
  final VoidCallback onDuplicate;
  final VoidCallback onImageSmaller;
  final VoidCallback onImageLarger;
  final VoidCallback onRule;
  final VoidCallback onDateTime;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: 'Ещё инструменты',
      color: Colors.white,
      elevation: 10,
      onSelected: (value) {
        switch (value) {
          case 'copy': onCopy(); break;
          case 'cut': onCut(); break;
          case 'paste': onPaste(); break;
          case 'all': onSelectAll(); break;
          case 'duplicate': onDuplicate(); break;
          case 'img-': onImageSmaller(); break;
          case 'img+': onImageLarger(); break;
          case 'rule': onRule(); break;
          case 'datetime': onDateTime(); break;
        }
      },
      itemBuilder: (_) => const <PopupMenuEntry<String>>[
        PopupMenuItem(value: 'copy', child: ListTile(dense: true, leading: Icon(Icons.content_copy_rounded, size: 18), title: Text('Копировать'))),
        PopupMenuItem(value: 'cut', child: ListTile(dense: true, leading: Icon(Icons.content_cut_rounded, size: 18), title: Text('Вырезать'))),
        PopupMenuItem(value: 'paste', child: ListTile(dense: true, leading: Icon(Icons.content_paste_rounded, size: 18), title: Text('Вставить'))),
        PopupMenuDivider(),
        PopupMenuItem(value: 'all', child: ListTile(dense: true, leading: Icon(Icons.select_all_rounded, size: 18), title: Text('Выделить всё'))),
        PopupMenuItem(value: 'duplicate', child: ListTile(dense: true, leading: Icon(Icons.control_point_duplicate_rounded, size: 18), title: Text('Дублировать'))),
        PopupMenuDivider(),
        PopupMenuItem(value: 'img-', child: ListTile(dense: true, leading: Icon(Icons.photo_size_select_small_rounded, size: 18), title: Text('Уменьшить фото'))),
        PopupMenuItem(value: 'img+', child: ListTile(dense: true, leading: Icon(Icons.photo_size_select_large_rounded, size: 18), title: Text('Увеличить фото'))),
        PopupMenuItem(value: 'rule', child: ListTile(dense: true, leading: Icon(Icons.horizontal_rule_rounded, size: 18), title: Text('Разделитель'))),
        PopupMenuItem(value: 'datetime', child: ListTile(dense: true, leading: Icon(Icons.event_outlined, size: 18), title: Text('Дата и время'))),
      ],
      child: const Tooltip(
        message: 'Ещё инструменты',
        child: SizedBox.square(
          dimension: 34,
          child: Center(child: Icon(Icons.more_horiz_rounded, size: 20, color: Color(0xFF29332D))),
        ),
      ),
    );
  }
}

class _EditorFontSizeButton extends StatelessWidget {
  const _EditorFontSizeButton({required this.onSelected});
  final ValueChanged<int> onSelected;

  @override
  Widget build(BuildContext context) {
    const sizes = <int>[10, 12, 14, 16, 18, 20, 24, 28, 32, 40];
    return PopupMenuButton<int>(
      tooltip: 'Размер шрифта',
      color: Colors.white,
      elevation: 8,
      onSelected: onSelected,
      itemBuilder: (_) => [
        for (final size in sizes)
          PopupMenuItem<int>(
            value: size,
            child: Text(
              '$size pt',
              style: AppTypography.body(color: const Color(0xFF101814))
                  .copyWith(fontSize: size.clamp(11, 20).toDouble()),
            ),
          ),
      ],
      child: Tooltip(
        message: 'Размер шрифта',
        child: Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 9),
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '15',
                style: AppTypography.actionStrong(
                  color: const Color(0xFF29332D),
                ),
              ),
              const SizedBox(width: 3),
              const Icon(
                Icons.keyboard_arrow_down_rounded,
                size: 15,
                color: Color(0xFF667085),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EditorPaletteButton extends StatelessWidget {
  const _EditorPaletteButton({
    required this.icon,
    required this.tooltip,
    required this.onSelected,
    required this.colors,
  });

  final IconData icon;
  final String tooltip;
  final ValueChanged<String> onSelected;
  final List<String> colors;

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: tooltip,
      color: Colors.white,
      elevation: 8,
      onSelected: onSelected,
      itemBuilder: (_) => [
        for (final hex in colors)
          PopupMenuItem<String>(
            value: hex,
            child: Row(
              children: [
                Container(
                  width: 20,
                  height: 20,
                  decoration: BoxDecoration(
                    color: _workspaceHexColor(hex, Colors.transparent),
                    shape: BoxShape.circle,
                    border: Border.all(color: const Color(0xFFD7DDD9)),
                  ),
                ),
                const SizedBox(width: 9),
                Text(
                  '#$hex',
                  style: AppTypography.captionMedium(
                    color: const Color(0xFF667085),
                  ),
                ),
              ],
            ),
          ),
      ],
      child: Tooltip(
        message: tooltip,
        child: SizedBox.square(
          dimension: 40,
          child: Center(
            child: Icon(icon, size: 19, color: const Color(0xFF29332D)),
          ),
        ),
      ),
    );
  }
}

class _EditorAlignmentButton extends StatelessWidget {
  const _EditorAlignmentButton({required this.onSelected});
  final ValueChanged<String> onSelected;

  PopupMenuItem<String> _item(
    String value,
    IconData icon,
    String label,
  ) {
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon, size: 18, color: const Color(0xFF29332D)),
          const SizedBox(width: 9),
          Text(
            label,
            style: AppTypography.action(color: const Color(0xFF29332D)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      tooltip: 'Выравнивание',
      color: Colors.white,
      elevation: 8,
      onSelected: onSelected,
      itemBuilder: (_) => <PopupMenuEntry<String>>[
        _item('left', Icons.format_align_left_rounded, 'По левому краю'),
        _item('center', Icons.format_align_center_rounded, 'По центру'),
        _item('right', Icons.format_align_right_rounded, 'По правому краю'),
        _item('justify', Icons.format_align_justify_rounded, 'По ширине'),
      ],
      child: const Tooltip(
        message: 'Выравнивание',
        child: SizedBox.square(
          dimension: 40,
          child: Center(
            child: Icon(
              Icons.format_align_left_rounded,
              size: 19,
              color: Color(0xFF29332D),
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorViewToggle extends StatelessWidget {
  const _EditorViewToggle({
    required this.visualMode,
    required this.compact,
    required this.onChanged,
  });

  final bool visualMode;
  final bool compact;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 36,
      decoration: BoxDecoration(
        color: const Color(0xFFF3F5F4),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _EditorViewOption(
            icon: Icons.article_outlined,
            label: compact ? '' : 'Страница',
            active: visualMode,
            onTap: () => onChanged(true),
          ),
          _EditorViewOption(
            icon: Icons.code_rounded,
            label: compact ? '' : 'Текст',
            active: !visualMode,
            onTap: () => onChanged(false),
          ),
        ],
      ),
    );
  }
}

class _EditorViewOption extends StatelessWidget {
  const _EditorViewOption({
    required this.icon,
    required this.label,
    required this.active,
    required this.onTap,
  });
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(9),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        height: 32,
        padding: EdgeInsets.symmetric(horizontal: label.isEmpty ? 8 : 9),
        decoration: BoxDecoration(
          color: active ? Colors.white : Colors.transparent,
          borderRadius: BorderRadius.circular(9),
          boxShadow: active
              ? const [
                  BoxShadow(
                    color: Color(0x0D000000),
                    blurRadius: 8,
                    offset: Offset(0, 2),
                  ),
                ]
              : null,
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 16,
              color: active ? const Color(0xFF0B8F55) : const Color(0xFF758079),
            ),
            if (label.isNotEmpty) ...[
              const SizedBox(width: 5),
              Text(
                label,
                style: AppTypography.captionMedium(
                  color: active ? const Color(0xFF0B8F55) : const Color(0xFF758079),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _ImportedSourceDocumentBlock extends StatelessWidget {
  const _ImportedSourceDocumentBlock({
    required this.filename,
    required this.extension,
    required this.sizeLabel,
    required this.onOpen,
  });

  final String filename;
  final String extension;
  final String sizeLabel;
  final VoidCallback? onOpen;

  @override
  Widget build(BuildContext context) {
    final meta = <String>[
      if (extension.trim().isNotEmpty) extension.trim(),
      if (sizeLabel.trim().isNotEmpty) sizeLabel.trim(),
      'оригинал',
    ].join(' · ');

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(14, 13, 12, 13),
      decoration: BoxDecoration(
        color: const Color(0xFFF4FAF6),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFD6EBDD)),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFDDE8E1)),
            ),
            child: const Icon(
              Icons.picture_as_pdf_outlined,
              color: Color(0xFF0B8F55),
              size: 21,
            ),
          ),
          const SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  filename,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: AppTypography.itemTitle(
                    color: const Color(0xFF101814),
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  meta,
                  style: AppTypography.caption(
                    color: const Color(0xFF758079),
                  ),
                ),
              ],
            ),
          ),
          if (onOpen != null)
            TextButton.icon(
              onPressed: onOpen,
              icon: const Icon(
                Icons.open_in_new_rounded,
                size: 17,
              ),
              label: const Text('Открыть оригинал'),
              style: TextButton.styleFrom(
                foregroundColor: const Color(0xFF0B8F55),
              ),
            ),
        ],
      ),
    );
  }
}

class _EditorAiButton extends StatelessWidget {
  const _EditorAiButton({
    required this.onTap,
    required this.active,
  });

  final VoidCallback onTap;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: 'Открыть ИИ-анализ текущего документа',
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Container(
          height: 40,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          decoration: BoxDecoration(
            color: active ? const Color(0xFFE7F7ED) : Colors.transparent,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(
              color: active ? const Color(0xFFBCE8CD) : Colors.transparent,
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(
                Icons.auto_awesome_rounded,
                size: 18,
                color: Color(0xFF0B8F55),
              ),
              const SizedBox(width: 6),
              Text(
                'AI анализ',
                style: AppTypography.actionStrong(
                  color: const Color(0xFF0B8F55),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EditorInsertButton extends StatelessWidget {
  const _EditorInsertButton({required this.onInsert});
  final ValueChanged<WorkspaceLiveBlockType> onInsert;

  @override
  Widget build(BuildContext context) {
    const entries = <WorkspaceLiveBlockType>[
      WorkspaceLiveBlockType.plan,
      WorkspaceLiveBlockType.match,
      WorkspaceLiveBlockType.training,
      WorkspaceLiveBlockType.player,
      WorkspaceLiveBlockType.tracker,
      WorkspaceLiveBlockType.testing,
      WorkspaceLiveBlockType.video,
      WorkspaceLiveBlockType.document,
    ];
    return PopupMenuButton<WorkspaceLiveBlockType>(
      tooltip: 'Вставить',
      color: Colors.white,
      onSelected: onInsert,
      itemBuilder: (_) => <PopupMenuEntry<WorkspaceLiveBlockType>>[
        for (final type in entries)
          PopupMenuItem<WorkspaceLiveBlockType>(
            value: type,
            child: Row(
              children: [
                SportotekaWorkspaceIcon(
                    kind: _editorIconForType(type),
                    size: 19,
                    color: const Color(0xFF0B8F55)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_editorTitleForType(type),
                          style: AppTypography.menuTitle(
                              color: const Color(0xFF101814))),
                      Text(_editorSubtitleForType(type),
                          style: AppTypography.caption(
                              color: const Color(0xFF758079))),
                    ],
                  ),
                ),
              ],
            ),
          ),
      ],
      child: Tooltip(
        message: 'Вставить',
        child: SizedBox(
          height: 40,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 9),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.add_rounded,
                    size: 18, color: Color(0xFF0B8F55)),
                const SizedBox(width: 5),
                Text('Вставить',
                    style: AppTypography.actionStrong(
                        color: const Color(0xFF0B8F55))),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

SportotekaWorkspaceIconKind _editorIconForType(WorkspaceLiveBlockType type) {
  switch (type) {
    case WorkspaceLiveBlockType.plan:
      return SportotekaWorkspaceIconKind.plans;
    case WorkspaceLiveBlockType.match:
      return SportotekaWorkspaceIconKind.matches;
    case WorkspaceLiveBlockType.training:
      return SportotekaWorkspaceIconKind.trainings;
    case WorkspaceLiveBlockType.player:
      return SportotekaWorkspaceIconKind.players;
    case WorkspaceLiveBlockType.tracker:
      return SportotekaWorkspaceIconKind.tracker;
    case WorkspaceLiveBlockType.testing:
      return SportotekaWorkspaceIconKind.testing;
    case WorkspaceLiveBlockType.video:
      return SportotekaWorkspaceIconKind.video;
    case WorkspaceLiveBlockType.document:
      return SportotekaWorkspaceIconKind.documents;
  }
}

String _editorTitleForType(WorkspaceLiveBlockType type) {
  switch (type) {
    case WorkspaceLiveBlockType.plan:
      return 'План-конспект';
    case WorkspaceLiveBlockType.match:
      return 'Матч';
    case WorkspaceLiveBlockType.training:
      return 'Тренировка';
    case WorkspaceLiveBlockType.player:
      return 'Игрок';
    case WorkspaceLiveBlockType.tracker:
      return 'Tracker';
    case WorkspaceLiveBlockType.testing:
      return 'Тестирование';
    case WorkspaceLiveBlockType.video:
      return 'Видео';
    case WorkspaceLiveBlockType.document:
      return 'Документ';
  }
}

String _editorSubtitleForType(WorkspaceLiveBlockType type) {
  switch (type) {
    case WorkspaceLiveBlockType.plan:
      return 'Живой план + PDF snapshot';
    case WorkspaceLiveBlockType.match:
      return 'Соперник, счёт и дата';
    case WorkspaceLiveBlockType.training:
      return 'Событие, место и команда';
    case WorkspaceLiveBlockType.player:
      return 'Карточка игрока';
    case WorkspaceLiveBlockType.tracker:
      return 'GPS, скорость и ЧСС';
    case WorkspaceLiveBlockType.testing:
      return 'Реальная тестовая сессия';
    case WorkspaceLiveBlockType.video:
      return 'Видеораздел / материал';
    case WorkspaceLiveBlockType.document:
      return 'Документ из архива';
  }
}

class _EditorLiveBlockButton extends StatelessWidget {
  const _EditorLiveBlockButton(
      {required this.title,
      required this.subtitle,
      required this.onTap,
      this.iconKind = SportotekaWorkspaceIconKind.plans});
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final SportotekaWorkspaceIconKind iconKind;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(.72),
      borderRadius: BorderRadius.circular(11),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(11),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
          child: Row(
            children: [
              SportotekaWorkspaceIcon(
                  kind: iconKind, size: 22, color: const Color(0xFF0B8F55)),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: AppTypography.menuTitle(
                            color: const Color(0xFF101814))),
                    const SizedBox(height: 2),
                    Text(subtitle,
                        style: AppTypography.caption(
                            color: const Color(0xFF758079))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EditorToolButton extends StatelessWidget {
  const _EditorToolButton(
      {required this.icon, required this.tooltip, required this.onTap});

  final SportotekaWorkspaceIconKind icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(child: SportotekaWorkspaceIcon(kind: icon, size: 19)),
        ),
      ),
    );
  }
}

class _EditorMaterialToolButton extends StatelessWidget {
  const _EditorMaterialToolButton({
    required this.icon,
    required this.tooltip,
    required this.onTap,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final enabled = onTap != null;
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(
            child: Icon(
              icon,
              size: 19,
              color: enabled
                  ? const Color(0xFF29332D)
                  : const Color(0xFFB4BBB7),
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorTextToolButton extends StatelessWidget {
  const _EditorTextToolButton(
      {required this.label, required this.tooltip, required this.onTap});

  final String label;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(
              child: Text(label,
                  style:
                      AppTypography.itemTitle(color: const Color(0xFF29332D)))),
        ),
      ),
    );
  }
}

class _EditorToolDivider extends StatelessWidget {
  const _EditorToolDivider();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 5, vertical: 8),
      child: VerticalDivider(width: 1, thickness: 1, color: Color(0xFFE0E5E1)),
    );
  }
}

class _EditorHeaderButton extends StatelessWidget {
  const _EditorHeaderButton(
      {required this.icon, required this.tooltip, required this.onTap});

  final SportotekaWorkspaceIconKind icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(child: SportotekaWorkspaceIcon(kind: icon, size: 19)),
        ),
      ),
    );
  }
}

class _EditorSaveState extends StatelessWidget {
  const _EditorSaveState(
      {required this.compact,
      required this.saving,
      required this.dirty,
      required this.failed,
      required this.readOnly});

  final bool compact;
  final bool saving;
  final bool dirty;
  final bool failed;
  final bool readOnly;

  @override
  Widget build(BuildContext context) {
    final color = failed
        ? const Color(0xFFB04444)
        : dirty || saving
            ? const Color(0xFF9B7420)
            : const Color(0xFF0B8F55);
    final text = readOnly
        ? 'Только чтение'
        : failed
            ? 'Не синхронизировано'
            : saving
                ? 'Сохраняется'
                : dirty
                    ? 'Есть изменения'
                    : 'Сохранено';

    if (compact) {
      return Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle));
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
          color: color.withOpacity(.09),
          borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
              width: 6,
              height: 6,
              decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(text, style: AppTypography.captionMedium(color: color)),
        ],
      ),
    );
  }
}

class _EditorTemplateButton extends StatelessWidget {
  const _EditorTemplateButton({required this.title, required this.onTap});

  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Material(
        color: Colors.white.withOpacity(.68),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
            child: Row(
              children: [
                const _EditorMosaicStrip(compact: true),
                const SizedBox(width: 9),
                Expanded(
                    child: Text(title,
                        style: AppTypography.menuTitle(
                            color: const Color(0xFF263129)))),
                const SportotekaWorkspaceIcon(
                    kind: SportotekaWorkspaceIconKind.chevronRight,
                    size: 15,
                    color: Color(0xFF78837C)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorMetaChip extends StatelessWidget {
  const _EditorMetaChip({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 250),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(
          color: const Color(0xFFF0F4F1),
          borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: AppTypography.caption(color: const Color(0xFF637068)),
      ),
    );
  }
}

class _EditorMosaicMark extends StatelessWidget {
  const _EditorMosaicMark({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    final dot = size * .18;
    return SizedBox.square(
      dimension: size,
      child: Wrap(
        alignment: WrapAlignment.center,
        runAlignment: WrapAlignment.center,
        spacing: size * .10,
        runSpacing: size * .10,
        children: List<Widget>.generate(9, (index) {
          const colors = <Color>[
            Color(0xFFC4DED0),
            Color(0xFF8FC2A6),
            Color(0xFFDCECE3),
            Color(0xFF75B492),
            Color(0xFF0B8F55),
            Color(0xFFAED3BF),
            Color(0xFFD5E8DD),
            Color(0xFF66AA86),
            Color(0xFFBADBC9),
          ];
          return Container(
            width: dot,
            height: dot,
            decoration:
                BoxDecoration(color: colors[index], shape: BoxShape.circle),
          );
        }),
      ),
    );
  }
}

class _EditorMosaicStrip extends StatelessWidget {
  const _EditorMosaicStrip({this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final size = compact ? 4.0 : 5.0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List<Widget>.generate(
        3,
        (index) => Padding(
          padding: EdgeInsets.only(left: index == 0 ? 0 : 4),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: index == 1
                  ? const Color(0xFF0B8F55)
                  : const Color(0xFFAED3BF),
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorTemplate {
  const _EditorTemplate(this.title, this.body);

  final String title;
  final String body;
}

class _SaveIntent extends Intent {
  const _SaveIntent();
}

class _UndoIntent extends Intent {
  const _UndoIntent();
}

class _RedoIntent extends Intent {
  const _RedoIntent();
}
