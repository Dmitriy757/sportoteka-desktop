import 'package:flutter/material.dart';

class TtdPanelWidget extends StatefulWidget {
  final Map<String, dynamic>? selectedPlayer;
  final Map<String, dynamic>? selectedEpisode;
  final bool quickSaving;
  final bool saving;
  final TextEditingController noteCtrl;
  final String? message;
  final bool isMessageError;
  final String ttdSection;
  final Function(String) onSectionChanged;
  final VoidCallback onSaveEvent;
  final Function(String, String, bool) onSaveQuickTtd;
  final Function(String, String, int) onSaveSingleTtd;
  final Map<String, int> successCounters;
  final Map<String, int> failCounters;
  final Map<String, int> singleCounters;
  final int currentRating;

  const TtdPanelWidget({
    super.key,
    this.selectedPlayer,
    this.selectedEpisode,
    required this.successCounters,
    required this.failCounters,
    required this.singleCounters,
    required this.currentRating,
    required this.quickSaving,
    required this.saving,
    required this.noteCtrl,
    this.message,
    required this.isMessageError,
    required this.ttdSection,
    required this.onSectionChanged,
    required this.onSaveEvent,
    required this.onSaveQuickTtd,
    required this.onSaveSingleTtd,
  });

  @override
  State<TtdPanelWidget> createState() => _TtdPanelWidgetState();
}

class _TtdMetric {
  final String label;
  final String code;
  final bool single;

  const _TtdMetric(this.label, this.code, {this.single = false});
}

class _TtdPanelWidgetState extends State<TtdPanelWidget> {
  static const Color _bg = Colors.white;
  static const Color _panel = Colors.white;
  static const Color _soft = Color(0xFFF8F9FA);
  static const Color _line = Color(0xFFF0F2F4);
  static const Color _text = Color(0xFF0B0F14);
  static const Color _muted = Color(0xFF374151);
  static const Color _subtle = Color(0xFF6B7280);
  static const Color _green = Color(0xFF00A750);
  static const Color _greenSoft = Color(0xFFF3FBF7);
  static const Color _red = Color(0xFFDC2626);
  static const Color _redSoft = Color(0xFFFEF2F2);

  static const String _family = 'Segoe UI';
  static const List<String> _fallback = <String>['SF Pro Display', 'SF Pro Text', 'Inter', 'Roboto', 'Arial'];

  int _selectedRating = 5;
  late String _currentSection;

  final Map<String, int> _localCounters = {};
  final Map<String, int> _localSuccessCounters = {};
  final Map<String, int> _localFailCounters = {};

  static final Map<String, Map<String, int>> _episodeCountersCache = {};
  static final Map<String, Map<String, int>> _episodeSuccessCountersCache = {};
  static final Map<String, Map<String, int>> _episodeFailCountersCache = {};
  static final Map<String, int> _episodeRatingsCache = {};

  static const Map<String, List<_TtdMetric>> _sections = {
    'main': [
      _TtdMetric('Финт / дриблинг', 'feint_dribble'),
      _TtdMetric('Удар', 'shot_on_goal'),
      _TtdMetric('Отбор', 'tackle_duel'),
      _TtdMetric('Перехват', 'interception_ball'),
      _TtdMetric('Подбор', 'recovery_ball'),
      _TtdMetric('Игра головой', 'header_play'),
      _TtdMetric('Аут', 'throw_ins'),
      _TtdMetric('Пас АВП', 'pass_avp'),
    ],
    'pass': [
      _TtdMetric('Вперёд К', 'pass_forward_short'),
      _TtdMetric('Вперёд С', 'pass_forward_medium'),
      _TtdMetric('Вперёд Д', 'pass_forward_long'),
      _TtdMetric('Поперёк К', 'pass_side_short'),
      _TtdMetric('Поперёк С', 'pass_side_medium'),
      _TtdMetric('Поперёк Д', 'pass_side_long'),
      _TtdMetric('Назад К', 'pass_back_short'),
      _TtdMetric('Назад С', 'pass_back_medium'),
      _TtdMetric('Назад Д', 'pass_back_long'),
    ],
    'defense': [
      _TtdMetric('Отбор', 'tackle_duel'),
      _TtdMetric('Перехват', 'interception_ball'),
      _TtdMetric('Подбор', 'recovery_ball'),
      _TtdMetric('Игра головой', 'header_play'),
      _TtdMetric('Аут', 'throw_ins'),
    ],
    'goalkeeper': [
      _TtdMetric('Ввод рукой', 'gk_hand_distribution'),
      _TtdMetric('Выход', 'gk_coming_out'),
      _TtdMetric('Ближний бой', 'gk_close_combat'),
      _TtdMetric('Перехваты', 'gk_interceptions'),
      _TtdMetric('За штрафной', 'gk_outside_box'),
      _TtdMetric('Пас К', 'gk_pass_short'),
      _TtdMetric('Пас С', 'gk_pass_medium'),
      _TtdMetric('Пас Д', 'gk_pass_long'),
      _TtdMetric('Сэйв', 'gk_saves', single: true),
      _TtdMetric('Пропущено', 'gk_conceded', single: true),
    ],
  };

  String _storageKey() {
    final playerId = widget.selectedPlayer?['id']?.toString() ?? 'no_player';
    final episodeId = widget.selectedEpisode?['id']?.toString() ?? 'no_episode';
    return '${playerId}_$episodeId';
  }

  String _normalizeEventType(String type) {
    final normalized = type.trim();
    switch (normalized) {
      case 'interception_ball':
        return 'interception';
      case 'recovery_ball':
        return 'recovery';
      case 'pass_forward_short':
        return 'forward_short';
      case 'pass_forward_medium':
        return 'forward_medium';
      case 'pass_forward_long':
        return 'forward_long';
      case 'pass_side_short':
        return 'side_short';
      case 'pass_side_medium':
        return 'side_medium';
      case 'pass_side_long':
        return 'side_long';
      case 'pass_back_short':
        return 'back_short';
      case 'pass_back_medium':
        return 'back_medium';
      case 'pass_back_long':
        return 'back_long';
      case 'gk_saves':
        return 'saves';
      case 'gk_conceded':
        return 'conceded';
      case 'gk_hand_distribution':
        return 'hand_distribution';
      case 'gk_coming_out':
        return 'coming_out';
      case 'gk_close_combat':
        return 'close_combat';
      case 'gk_interceptions':
        return 'interceptions';
      case 'gk_outside_box':
        return 'outside_box';
      case 'gk_pass_short':
        return 'pass_short';
      case 'gk_pass_medium':
        return 'pass_medium';
      case 'gk_pass_long':
        return 'pass_long';
      default:
        return normalized;
    }
  }

  TextStyle _title(double size) => TextStyle(
        fontFamily: _family,
        fontFamilyFallback: _fallback,
        color: _text,
        fontSize: size,
        fontWeight: FontWeight.w700,
        height: 1.08,
        letterSpacing: -0.18,
      );

  TextStyle _body(double size, {Color? color, FontWeight? weight}) => TextStyle(
        fontFamily: _family,
        fontFamilyFallback: _fallback,
        color: color ?? _muted,
        fontSize: size,
        fontWeight: weight ?? FontWeight.w500,
        height: 1.16,
        letterSpacing: -0.04,
      );

  @override
  void initState() {
    super.initState();
    _currentSection = widget.ttdSection;
    _restoreStateForCurrentSelection();
  }

  @override
  void didUpdateWidget(covariant TtdPanelWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.ttdSection != widget.ttdSection) {
      _currentSection = widget.ttdSection;
    }
    final oldPlayerId = oldWidget.selectedPlayer?['id']?.toString();
    final newPlayerId = widget.selectedPlayer?['id']?.toString();
    final oldEpisodeId = oldWidget.selectedEpisode?['id']?.toString();
    final newEpisodeId = widget.selectedEpisode?['id']?.toString();
    if (oldPlayerId != newPlayerId || oldEpisodeId != newEpisodeId) {
      _saveStateForCurrentSelection();
      setState(_restoreStateForCurrentSelection);
    }
  }

  @override
  void dispose() {
    _saveStateForCurrentSelection();
    super.dispose();
  }

  void _restoreStateForCurrentSelection() {
    _localCounters.clear();
    _localSuccessCounters.clear();
    _localFailCounters.clear();
    _selectedRating = widget.currentRating > 0 ? widget.currentRating : 5;

    final playerId = widget.selectedPlayer?['id'];
    final episode = widget.selectedEpisode;
    if (playerId == null || episode == null) return;

    final childrenRaw = episode['children'];
    if (childrenRaw is! List) {
      final key = _storageKey();
      _localCounters.addAll(_episodeCountersCache[key] ?? widget.singleCounters);
      _localSuccessCounters.addAll(_episodeSuccessCountersCache[key] ?? widget.successCounters);
      _localFailCounters.addAll(_episodeFailCountersCache[key] ?? widget.failCounters);
      _selectedRating = _episodeRatingsCache[key] ?? _selectedRating;
      return;
    }

    for (final item in childrenRaw) {
      if (item is! Map) continue;
      final child = Map<String, dynamic>.from(item);
      final childPlayerId = child['player_id'];
      if (childPlayerId == null || childPlayerId.toString() != playerId.toString()) continue;

      final rawType = (child['event_type'] ?? '').toString().trim();
      final eventType = _normalizeEventType(rawType);
      final isPositive = int.tryParse((child['is_positive'] ?? '0').toString()) ?? 0;
      final rating = int.tryParse((child['rating'] ?? '0').toString()) ?? 0;
      if (eventType.isEmpty || eventType == 'episode') continue;

      if (eventType == 'rating') {
        _selectedRating = rating > 0 ? rating : 5;
        continue;
      }

      if (eventType == 'saves' || eventType == 'conceded') {
        final delta = rating == 0 ? 1 : rating;
        _localCounters[eventType] = (_localCounters[eventType] ?? 0) + delta;
        continue;
      }

      if (isPositive > 0) {
        _localSuccessCounters[eventType] = (_localSuccessCounters[eventType] ?? 0) + 1;
      } else {
        _localFailCounters[eventType] = (_localFailCounters[eventType] ?? 0) + 1;
      }
    }
    _saveStateForCurrentSelection();
  }

  void _saveStateForCurrentSelection() {
    final key = _storageKey();
    _episodeCountersCache[key] = Map<String, int>.from(_localCounters);
    _episodeSuccessCountersCache[key] = Map<String, int>.from(_localSuccessCounters);
    _episodeFailCountersCache[key] = Map<String, int>.from(_localFailCounters);
    _episodeRatingsCache[key] = _selectedRating;
  }

  int _successTotal() => _localSuccessCounters.values.fold<int>(0, (a, b) => a + b);
  int _failTotal() => _localFailCounters.values.fold<int>(0, (a, b) => a + b);
  int _singleCountersTotal() => _localCounters.values.fold<int>(0, (a, b) => a + b);
  int _allActionsTotal() => _successTotal() + _failTotal() + _singleCountersTotal();
  int _filledMetricsCount() => {..._localCounters.keys, ..._localSuccessCounters.keys, ..._localFailCounters.keys}.where((key) => (_localCounters[key] ?? 0) > 0 || (_localSuccessCounters[key] ?? 0) > 0 || (_localFailCounters[key] ?? 0) > 0).length;
  String _successPercent(int success, int fail) {
    final total = success + fail;
    if (total <= 0) return '0%';
    return '${((success / total) * 100).round()}%';
  }

  String _playerName() {
    final firstName = widget.selectedPlayer?['first_name']?.toString() ?? '';
    final lastName = widget.selectedPlayer?['last_name']?.toString() ?? '';
    final fallback = widget.selectedPlayer?['name']?.toString() ?? '';
    final full = '$firstName $lastName'.trim();
    return full.isEmpty ? (fallback.isEmpty ? 'Игрок не выбран' : fallback) : full;
  }

  String _episodeTitle() {
    final episode = widget.selectedEpisode;
    if (episode == null) return 'Эпизод не выбран';
    final title = (episode['title'] ?? '').toString().trim();
    final time = (episode['timecode'] ?? episode['timecode_text'] ?? '').toString().trim();
    if (title.isNotEmpty && time.isNotEmpty) return '$title • $time';
    return title.isNotEmpty ? title : (time.isNotEmpty ? time : 'Эпизод выбран');
  }

  @override
  Widget build(BuildContext context) {
    final hasSelection = widget.selectedPlayer != null && widget.selectedEpisode != null;

    return Container(
      color: _bg,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildHeader(hasSelection),
          Container(height: 1, color: _line),
          Expanded(
            child: hasSelection
                ? SingleChildScrollView(
                    padding: const EdgeInsets.fromLTRB(12, 12, 12, 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        _buildSummaryLine(),
                        const SizedBox(height: 10),
                        _buildSectionTabs(),
                        const SizedBox(height: 10),
                        if (widget.message != null) ...[
                          _buildMessageBanner(),
                          const SizedBox(height: 10),
                        ],
                        _buildMetricsTable(),
                        const SizedBox(height: 10),
                        _buildRatingAndNote(),
                      ],
                    ),
                  )
                : _buildNoSelection(),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(bool hasSelection) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Row(
        children: [
          Container(width: 4, height: 32, color: hasSelection ? _green : _line),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('ТТД матча', style: _title(13.4)),
                const SizedBox(height: 3),
                Text('${_playerName()}  ·  ${_episodeTitle()}', maxLines: 1, overflow: TextOverflow.ellipsis, style: _body(11, color: _subtle, weight: FontWeight.w600)),
              ],
            ),
          ),
          _smallStat('Всего', '${_allActionsTotal()}'),
          const SizedBox(width: 6),
          _smallStat('КПД', _successPercent(_successTotal(), _failTotal())),
        ],
      ),
    );
  }

  Widget _smallStat(String label, String value) {
    return Container(
      width: 58,
      padding: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(border: Border.all(color: _line), color: _soft, borderRadius: BorderRadius.circular(8)),
      child: Column(
        children: [
          Text(value, style: _title(12.2)),
          const SizedBox(height: 1),
          Text(label, style: _body(9.6, color: _subtle)),
        ],
      ),
    );
  }

  Widget _buildNoSelection() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.ads_click_rounded, size: 28, color: _green),
            const SizedBox(height: 10),
            Text('Выбери игрока и эпизод', style: _title(14)),
            const SizedBox(height: 6),
            Text('После выбора здесь откроется профессиональная таблица ТТД по эпизоду.', textAlign: TextAlign.center, style: _body(11.4, color: _subtle)),
          ],
        ),
      ),
    );
  }

  Widget _buildSummaryLine() {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: _soft, border: Border.all(color: _line), borderRadius: BorderRadius.circular(10)),
      child: Row(
        children: [
          Expanded(child: _summaryItem('Удачно', '${_successTotal()}', _green)),
          Container(width: 1, height: 28, color: _line),
          Expanded(child: _summaryItem('Неудачно', '${_failTotal()}', _red)),
          Container(width: 1, height: 28, color: _line),
          Expanded(child: _summaryItem('Метрик', '${_filledMetricsCount()}', _muted)),
          Container(width: 1, height: 28, color: _line),
          Expanded(child: _summaryItem('Оценка', '$_selectedRating/10', _green)),
        ],
      ),
    );
  }

  Widget _summaryItem(String label, String value, Color color) {
    return Column(
      children: [
        Text(value, style: _title(13.2).copyWith(color: color)),
        const SizedBox(height: 2),
        Text(label, style: _body(10.3, color: _subtle)),
      ],
    );
  }

  Widget _buildSectionTabs() {
    const tabs = [
      ('main', 'Основные'),
      ('pass', 'Пасы'),
      ('defense', 'Оборона'),
      ('goalkeeper', 'Вратарь'),
    ];

    return Container(
      decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: _line))),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: tabs.map((tab) {
            final active = _currentSection == tab.$1;
            return InkWell(
              onTap: () {
                setState(() => _currentSection = tab.$1);
                widget.onSectionChanged(tab.$1);
              },
              child: Container(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 9),
                decoration: BoxDecoration(border: Border(bottom: BorderSide(color: active ? _green : Colors.transparent, width: 2))),
                child: Text(tab.$2, style: _body(11.4, color: active ? _green : _muted, weight: active ? FontWeight.w700 : FontWeight.w600)),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }

  Widget _buildMessageBanner() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: widget.isMessageError ? _redSoft : _greenSoft,
        border: Border.all(color: widget.isMessageError ? const Color(0xFFFECACA) : const Color(0xFFD7F0E2)),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(widget.message ?? '', style: _body(11.2, color: widget.isMessageError ? _red : _green, weight: FontWeight.w600)),
    );
  }

  Widget _buildMetricsTable() {
    final metrics = _sections[_currentSection] ?? _sections['main']!;

    return Container(
      decoration: BoxDecoration(color: _panel, border: Border.all(color: _line), borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: const BoxDecoration(color: _soft, border: Border(bottom: BorderSide(color: _line))),
            child: Row(
              children: [
                Expanded(flex: 4, child: Text('Действие', style: _body(10.8, color: _subtle, weight: FontWeight.w700))),
                SizedBox(width: 52, child: Text('+', textAlign: TextAlign.center, style: _body(10.8, color: _green, weight: FontWeight.w700))),
                SizedBox(width: 52, child: Text('−', textAlign: TextAlign.center, style: _body(10.8, color: _red, weight: FontWeight.w700))),
                SizedBox(width: 54, child: Text('КПД', textAlign: TextAlign.center, style: _body(10.8, color: _subtle, weight: FontWeight.w700))),
              ],
            ),
          ),
          for (int i = 0; i < metrics.length; i++) _metricRow(metrics[i], last: i == metrics.length - 1),
        ],
      ),
    );
  }

  Widget _metricRow(_TtdMetric metric, {required bool last}) {
    final code = metric.code;
    final normalized = _normalizeEventType(code);
    final success = _localSuccessCounters[code] ?? _localSuccessCounters[normalized] ?? 0;
    final fail = _localFailCounters[code] ?? _localFailCounters[normalized] ?? 0;
    final single = _localCounters[code] ?? _localCounters[normalized] ?? 0;
    final pct = metric.single ? '$single' : _successPercent(success, fail);

    return Container(
      decoration: BoxDecoration(border: last ? null : const Border(bottom: BorderSide(color: _line))),
      child: Row(
        children: [
          Expanded(
            flex: 4,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              child: Text(metric.label, style: _body(11.5, color: _text, weight: FontWeight.w600)),
            ),
          ),
          if (metric.single) ...[
            SizedBox(width: 104, child: _counterStepper(metric)),
          ] else ...[
            SizedBox(width: 52, child: _plusMinusButton('+', _green, () => _incQuick(metric, true), success.toString())),
            SizedBox(width: 52, child: _plusMinusButton('−', _red, () => _incQuick(metric, false), fail.toString())),
          ],
          SizedBox(width: 54, child: Text(pct, textAlign: TextAlign.center, style: _body(11.2, color: _muted, weight: FontWeight.w700))),
        ],
      ),
    );
  }

  Widget _plusMinusButton(String sign, Color color, VoidCallback onTap, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 5),
      child: InkWell(
        onTap: widget.quickSaving ? null : onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          height: 30,
          alignment: Alignment.center,
          decoration: BoxDecoration(color: color.withOpacity(.08), border: Border.all(color: color.withOpacity(.24)), borderRadius: BorderRadius.circular(8)),
          child: Text('$sign $value', style: _body(11.4, color: color, weight: FontWeight.w700)),
        ),
      ),
    );
  }

  Widget _counterStepper(_TtdMetric metric) {
    final code = metric.code;
    final value = _localCounters[code] ?? _localCounters[_normalizeEventType(code)] ?? 0;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _miniIcon(Icons.remove_rounded, value > 0 ? () => _incSingle(metric, -1) : null),
        SizedBox(width: 28, child: Text('$value', textAlign: TextAlign.center, style: _title(12.2))),
        _miniIcon(Icons.add_rounded, () => _incSingle(metric, 1)),
      ],
    );
  }

  Widget _miniIcon(IconData icon, VoidCallback? onTap) {
    return InkWell(
      onTap: widget.quickSaving ? null : onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        width: 28,
        height: 28,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: _soft, border: Border.all(color: _line), borderRadius: BorderRadius.circular(7)),
        child: Icon(icon, size: 15, color: onTap == null ? _subtle : _muted),
      ),
    );
  }

  void _incQuick(_TtdMetric metric, bool success) {
    setState(() {
      final map = success ? _localSuccessCounters : _localFailCounters;
      map[metric.code] = (map[metric.code] ?? 0) + 1;
    });
    _saveStateForCurrentSelection();
    widget.onSaveQuickTtd(metric.label, metric.code, success);
  }

  void _incSingle(_TtdMetric metric, int delta) {
    setState(() {
      final next = ((_localCounters[metric.code] ?? 0) + delta).clamp(0, 999).toInt();
      _localCounters[metric.code] = next;
    });
    _saveStateForCurrentSelection();
    widget.onSaveSingleTtd(metric.label, metric.code, delta);
  }

  Widget _buildRatingAndNote() {
    return Container(
      decoration: BoxDecoration(color: _panel, border: Border.all(color: _line), borderRadius: BorderRadius.circular(12)),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 10, 10, 8),
            child: Row(
              children: [
                Expanded(child: Text('Оценка эпизода', style: _title(12.4))),
                Text('$_selectedRating/10', style: _body(11.4, color: _green, weight: FontWeight.w700)),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: SliderTheme(
              data: SliderTheme.of(context).copyWith(trackHeight: 3, thumbShape: const RoundSliderThumbShape(enabledThumbRadius: 7)),
              child: Slider(
                min: 1,
                max: 10,
                divisions: 9,
                value: _selectedRating.toDouble(),
                activeColor: _green,
                inactiveColor: _line,
                onChanged: (v) {
                  setState(() => _selectedRating = v.round());
                  _saveStateForCurrentSelection();
                },
              ),
            ),
          ),
          Container(height: 1, color: _line),
          Padding(
            padding: const EdgeInsets.all(10),
            child: TextField(
              controller: widget.noteCtrl,
              minLines: 3,
              maxLines: 5,
              style: _body(11.6, color: _text, weight: FontWeight.w500),
              decoration: InputDecoration(
                hintText: 'Заметка тренера по эпизоду...',
                hintStyle: _body(11.4, color: _subtle),
                filled: true,
                fillColor: _soft,
                isDense: true,
                contentPadding: const EdgeInsets.all(10),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _line)),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _line)),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: _green)),
              ),
            ),
          ),
          Container(height: 1, color: _line),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(
              children: [
                Expanded(child: Text('Сохраняет выбранные ТТД, оценку и комментарий в отчёт.', style: _body(10.8, color: _subtle))),
                const SizedBox(width: 10),
                ElevatedButton.icon(
                  onPressed: widget.saving ? null : widget.onSaveEvent,
                  icon: widget.saving ? const SizedBox(width: 14, height: 14, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.save_rounded, size: 15),
                  label: Text(widget.saving ? 'Сохранение' : 'Сохранить'),
                  style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: _green,
                    foregroundColor: Colors.white,
                    textStyle: _body(11.6, color: Colors.white, weight: FontWeight.w700),
                    minimumSize: const Size(122, 36),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
