import 'dart:math' as math;

import 'package:flutter/material.dart';

class CmrAiWindowColors {
  static const Color bg = Color(0xFFFFFFFF);
  static const Color panel = Color(0xFFFFFFFF);
  static const Color soft = Color(0xFFF8F9FA);
  static const Color soft2 = Color(0xFFF3F4F6);
  static const Color line = Color(0xFFF0F2F4);
  static const Color text = Color(0xFF0B0F14);
  static const Color muted = Color(0xFF374151);
  static const Color subtle = Color(0xFF6B7280);
  static const Color green = Color(0xFF00A750);
  static const Color greenSoft = Color(0xFFF3FBF7);
  static const Color graphite = Color(0xFF111827);
  static const Color red = Color(0xFFDC2626);
}

class CmrAiText {
  static const String family = 'Segoe UI';
  static const List<String> fallback = <String>[
    'SF Pro Display',
    'SF Pro Text',
    'Inter',
    'Roboto',
    'Arial',
  ];

  static TextStyle title(double size) => TextStyle(
        fontFamily: family,
        fontFamilyFallback: fallback,
        fontSize: size,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.28,
        height: 1.08,
        color: CmrAiWindowColors.text,
      );

  static TextStyle body(double size, {Color? color, FontWeight? weight}) => TextStyle(
        fontFamily: family,
        fontFamilyFallback: fallback,
        fontSize: size,
        fontWeight: weight ?? FontWeight.w500,
        letterSpacing: -0.05,
        height: 1.18,
        color: color ?? CmrAiWindowColors.muted,
      );

  static TextStyle label(double size, {Color? color}) => TextStyle(
        fontFamily: family,
        fontFamilyFallback: fallback,
        fontSize: size,
        fontWeight: FontWeight.w700,
        letterSpacing: -0.06,
        height: 1.12,
        color: color ?? CmrAiWindowColors.text,
      );
}

Future<T?> showCmrAiWindow<T>({
  required BuildContext context,
  required String title,
  String? subtitle,
  required Widget child,
  double maxWidth = 900,
  double maxHeightFactor = 0.86,
  bool barrierDismissible = true,
}) {
  return showGeneralDialog<T>(
    context: context,
    useRootNavigator: true,
    barrierDismissible: barrierDismissible,
    barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    barrierColor: Colors.black.withOpacity(0.28),
    transitionDuration: const Duration(milliseconds: 160),
    pageBuilder: (dialogContext, animation, secondaryAnimation) {
      final media = MediaQuery.of(dialogContext);
      final width = math.min(maxWidth, media.size.width - 24);
      final maxHeight = media.size.height * maxHeightFactor;

      return SafeArea(
        child: Center(
          child: Material(
            color: Colors.transparent,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                maxWidth: width,
                maxHeight: maxHeight,
              ),
              child: CmrAiWindowFrame(
                title: title,
                subtitle: subtitle,
                onClose: () => Navigator.of(dialogContext, rootNavigator: true).maybePop(),
                child: child,
              ),
            ),
          ),
        ),
      );
    },
    transitionBuilder: (context, animation, secondaryAnimation, child) {
      final curved = CurvedAnimation(parent: animation, curve: Curves.easeOutCubic);
      return FadeTransition(
        opacity: curved,
        child: ScaleTransition(
          scale: Tween<double>(begin: 0.985, end: 1).animate(curved),
          child: child,
        ),
      );
    },
  );
}

class CmrAiWindowFrame extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  final VoidCallback? onClose;
  final VoidCallback? onMinimize;
  final VoidCallback? onMaximize;

  const CmrAiWindowFrame({
    super.key,
    required this.title,
    this.subtitle,
    required this.child,
    this.onClose,
    this.onMinimize,
    this.onMaximize,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(18),
      child: Container(
        decoration: BoxDecoration(
          color: CmrAiWindowColors.panel,
          border: Border.all(color: CmrAiWindowColors.line),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.16),
              blurRadius: 36,
              offset: const Offset(0, 18),
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              height: 46,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(bottom: BorderSide(color: CmrAiWindowColors.line)),
              ),
              child: Row(
                children: [
                  _WindowControlButton(
                    icon: Icons.close_rounded,
                    tooltip: 'Закрыть',
                    onTap: onClose,
                  ),
                  const SizedBox(width: 6),
                  _WindowControlButton(
                    icon: Icons.remove_rounded,
                    tooltip: 'Свернуть',
                    onTap: onMinimize ?? onClose,
                  ),
                  const SizedBox(width: 6),
                  _WindowControlButton(
                    icon: Icons.crop_square_rounded,
                    tooltip: 'Развернуть',
                    onTap: onMaximize,
                  ),
                  const SizedBox(width: 14),
                  Container(width: 1, height: 20, color: CmrAiWindowColors.line),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: CmrAiText.title(13.2),
                        ),
                        if (subtitle != null && subtitle!.trim().isNotEmpty) ...[
                          const SizedBox(height: 2),
                          Text(
                            subtitle!,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: CmrAiText.body(10.8, color: CmrAiWindowColors.subtle),
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Flexible(child: child),
          ],
        ),
      ),
    );
  }
}

class _WindowControlButton extends StatelessWidget {
  final IconData icon;
  final String tooltip;
  final VoidCallback? onTap;

  const _WindowControlButton({
    required this.icon,
    required this.tooltip,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          width: 26,
          height: 26,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: CmrAiWindowColors.soft,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: CmrAiWindowColors.line),
          ),
          child: Icon(icon, size: 14, color: CmrAiWindowColors.muted),
        ),
      ),
    );
  }
}
