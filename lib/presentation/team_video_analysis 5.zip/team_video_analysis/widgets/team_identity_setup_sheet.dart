import 'package:flutter/material.dart';

import '../models/team_visual_config.dart';
import 'cmr_ai_window.dart';

class TeamIdentitySetupSheet extends StatefulWidget {
  final TeamVisualConfig myTeamConfig;
  final TeamVisualConfig opponentTeamConfig;
  final void Function(
    TeamVisualConfig myConfig,
    TeamVisualConfig opponentConfig,
  ) onApply;

  const TeamIdentitySetupSheet({
    super.key,
    required this.myTeamConfig,
    required this.opponentTeamConfig,
    required this.onApply,
  });

  @override
  State<TeamIdentitySetupSheet> createState() => _TeamIdentitySetupSheetState();
}

class _TeamIdentitySetupSheetState extends State<TeamIdentitySetupSheet> {
  late TeamVisualConfig _myConfig;
  late TeamVisualConfig _opponentConfig;

  final _myNameCtrl = TextEditingController();
  final _oppNameCtrl = TextEditingController();

  static const List<Color> _palette = [
    Color(0xFF00A750),
    Color(0xFF2563EB),
    Color(0xFFDC2626),
    Color(0xFFF59E0B),
    Color(0xFF7C3AED),
    Color(0xFF111827),
    Color(0xFFFFFFFF),
    Color(0xFF14B8A6),
  ];

  @override
  void initState() {
    super.initState();
    _myConfig = widget.myTeamConfig;
    _opponentConfig = widget.opponentTeamConfig;
    _myNameCtrl.text = _myConfig.displayName;
    _oppNameCtrl.text = _opponentConfig.displayName;
  }

  @override
  void dispose() {
    _myNameCtrl.dispose();
    _oppNameCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _infoLine(),
            const SizedBox(height: 12),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: _buildTeamCard(
                    title: 'Моя команда',
                    subtitle: 'Цвет используется для поиска игроков, точек, треков и heatmap',
                    controller: _myNameCtrl,
                    config: _myConfig,
                    onPrimaryChanged: (c) => setState(() => _myConfig = _myConfig.copyWith(primaryColor: c)),
                    onSecondaryChanged: (c) => setState(() => _myConfig = _myConfig.copyWith(secondaryColor: c)),
                    onTextChanged: (c) => setState(() => _myConfig = _myConfig.copyWith(textColor: c)),
                    onSideChanged: (tag) => setState(() => _myConfig = _myConfig.copyWith(sideTag: tag)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildTeamCard(
                    title: 'Соперник',
                    subtitle: 'Нужен контрастный цвет, чтобы AI не смешивал команды',
                    controller: _oppNameCtrl,
                    config: _opponentConfig,
                    onPrimaryChanged: (c) => setState(() => _opponentConfig = _opponentConfig.copyWith(primaryColor: c)),
                    onSecondaryChanged: (c) => setState(() => _opponentConfig = _opponentConfig.copyWith(secondaryColor: c)),
                    onTextChanged: (c) => setState(() => _opponentConfig = _opponentConfig.copyWith(textColor: c)),
                    onSideChanged: (tag) => setState(() => _opponentConfig = _opponentConfig.copyWith(sideTag: tag)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(height: 1, color: CmrAiWindowColors.line),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    'После сохранения AI будет использовать эти цвета в классификации команд и в визуализации отчёта.',
                    style: CmrAiText.body(11.6, color: CmrAiWindowColors.subtle),
                  ),
                ),
                const SizedBox(width: 12),
                TextButton(
                  onPressed: () => Navigator.of(context, rootNavigator: true).maybePop(),
                  child: Text('Отмена', style: CmrAiText.label(12, color: CmrAiWindowColors.muted)),
                ),
                const SizedBox(width: 8),
                ElevatedButton.icon(
                  onPressed: () {
                    final myName = _myNameCtrl.text.trim();
                    final oppName = _oppNameCtrl.text.trim();
                    widget.onApply(
                      _myConfig.copyWith(displayName: myName.isEmpty ? 'Моя команда' : myName),
                      _opponentConfig.copyWith(displayName: oppName.isEmpty ? 'Соперник' : oppName),
                    );
                    Navigator.of(context, rootNavigator: true).maybePop();
                  },
                  icon: const Icon(Icons.check_rounded, size: 16),
                  label: const Text('Применить'),
                  style: ElevatedButton.styleFrom(
                    elevation: 0,
                    backgroundColor: CmrAiWindowColors.green,
                    foregroundColor: Colors.white,
                    minimumSize: const Size(132, 38),
                    textStyle: CmrAiText.label(12, color: Colors.white),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoLine() {
    return Container(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: CmrAiWindowColors.greenSoft,
        border: Border.all(color: const Color(0xFFD7F0E2)),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const Icon(Icons.tune_rounded, size: 17, color: CmrAiWindowColors.green),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Задай основной цвет формы. Чем точнее цвет, тем стабильнее AI разделит игроков на команды.',
              style: CmrAiText.body(11.8, color: CmrAiWindowColors.muted, weight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamCard({
    required String title,
    required String subtitle,
    required TextEditingController controller,
    required TeamVisualConfig config,
    required ValueChanged<Color> onPrimaryChanged,
    required ValueChanged<Color> onSecondaryChanged,
    required ValueChanged<Color> onTextChanged,
    required ValueChanged<AnalysisSideTag> onSideChanged,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: CmrAiWindowColors.line),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
            child: Row(
              children: [
                Container(width: 4, height: 28, color: config.primaryColor),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: CmrAiText.title(13.2)),
                      const SizedBox(height: 3),
                      Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: CmrAiText.body(10.8, color: CmrAiWindowColors.subtle)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Container(height: 1, color: CmrAiWindowColors.line),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextField(
                  controller: controller,
                  style: CmrAiText.body(12.4, color: CmrAiWindowColors.text, weight: FontWeight.w600),
                  decoration: InputDecoration(
                    labelText: 'Название',
                    labelStyle: CmrAiText.body(11.4, color: CmrAiWindowColors.subtle),
                    filled: true,
                    fillColor: CmrAiWindowColors.soft,
                    isDense: true,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: CmrAiWindowColors.line)),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: CmrAiWindowColors.line)),
                    focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: CmrAiWindowColors.green)),
                  ),
                ),
                const SizedBox(height: 10),
                _sideSelector(config.sideTag, onSideChanged),
                const SizedBox(height: 12),
                _colorGroup('Основной цвет формы', config.primaryColor, onPrimaryChanged),
                const SizedBox(height: 10),
                _colorGroup('Доп. цвет', config.secondaryColor, onSecondaryChanged),
                const SizedBox(height: 10),
                _colorGroup('Цвет номера/текста', config.textColor, onTextChanged),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _sideSelector(AnalysisSideTag selected, ValueChanged<AnalysisSideTag> onChanged) {
    return Row(
      children: [
        Expanded(child: _sideButton('Дом', AnalysisSideTag.home, selected, onChanged)),
        const SizedBox(width: 8),
        Expanded(child: _sideButton('Гости', AnalysisSideTag.away, selected, onChanged)),
      ],
    );
  }

  Widget _sideButton(String label, AnalysisSideTag tag, AnalysisSideTag selected, ValueChanged<AnalysisSideTag> onChanged) {
    final active = tag == selected;
    return InkWell(
      onTap: () => onChanged(tag),
      borderRadius: BorderRadius.circular(10),
      child: Container(
        height: 34,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: active ? CmrAiWindowColors.greenSoft : CmrAiWindowColors.soft,
          border: Border.all(color: active ? CmrAiWindowColors.green : CmrAiWindowColors.line),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Text(label, style: CmrAiText.label(11.6, color: active ? CmrAiWindowColors.green : CmrAiWindowColors.muted)),
      ),
    );
  }

  Widget _colorGroup(String title, Color selected, ValueChanged<Color> onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(child: Text(title, style: CmrAiText.label(11.2, color: CmrAiWindowColors.muted))),
            Text(_hex(selected), style: CmrAiText.body(10.6, color: CmrAiWindowColors.subtle)),
          ],
        ),
        const SizedBox(height: 7),
        Wrap(
          spacing: 7,
          runSpacing: 7,
          children: _palette.map((color) {
            final active = color.value == selected.value;
            return InkWell(
              onTap: () => onChanged(color),
              borderRadius: BorderRadius.circular(8),
              child: Container(
                width: 30,
                height: 24,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(
                    color: active ? CmrAiWindowColors.green : CmrAiWindowColors.line,
                    width: active ? 2 : 1,
                  ),
                ),
                child: active ? Icon(Icons.check_rounded, size: 14, color: color.computeLuminance() > 0.55 ? Colors.black : Colors.white) : null,
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  String _hex(Color color) {
    final value = color.value.toRadixString(16).padLeft(8, '0').toUpperCase();
    return '#${value.substring(2)}';
  }
}
