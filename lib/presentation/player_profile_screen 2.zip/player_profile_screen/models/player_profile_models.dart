import 'package:flutter/material.dart';

enum PlayerProfileSection { overview, diary, activity, matches, analytics, testing, health, card }

class PlayerProfilePoint {
  final double x;
  final double y;
  final double? value;
  const PlayerProfilePoint(this.x, this.y, {this.value});
}

class PlayerProfileSession {
  final int id;
  final DateTime? date;
  final String title;
  final double distanceM;
  final double maxSpeedKmh;
  final double avgSpeedKmh;
  final int durationSec;
  final int sprintCount;
  final double avgHr;
  final double maxHr;
  final double minHr;
  final List<PlayerProfilePoint> route;
  final List<PlayerProfilePoint> heatmap;
  final List<double> speedTimeline;
  final List<double> heartRateTimeline;
  final List<double> heartRateTimelineSec;
  final Map<String, dynamic> trackerReportJson;

  const PlayerProfileSession({
    required this.id,
    required this.date,
    required this.title,
    required this.distanceM,
    required this.maxSpeedKmh,
    required this.avgSpeedKmh,
    required this.durationSec,
    required this.sprintCount,
    required this.avgHr,
    required this.maxHr,
    this.minHr = 0,
    this.route = const [],
    this.heatmap = const [],
    this.speedTimeline = const [],
    this.heartRateTimeline = const [],
    this.heartRateTimelineSec = const [],
    this.trackerReportJson = const <String, dynamic>{},
  });

  PlayerProfileSession copyWith({
    List<PlayerProfilePoint>? route,
    List<PlayerProfilePoint>? heatmap,
    List<double>? speedTimeline,
    List<double>? heartRateTimeline,
    List<double>? heartRateTimelineSec,
    double? avgHr,
    double? maxHr,
    double? minHr,
    Map<String, dynamic>? trackerReportJson,
  }) => PlayerProfileSession(
        id: id,
        date: date,
        title: title,
        distanceM: distanceM,
        maxSpeedKmh: maxSpeedKmh,
        avgSpeedKmh: avgSpeedKmh,
        durationSec: durationSec,
        sprintCount: sprintCount,
        avgHr: avgHr ?? this.avgHr,
        maxHr: maxHr ?? this.maxHr,
        minHr: minHr ?? this.minHr,
        route: route ?? this.route,
        heatmap: heatmap ?? this.heatmap,
        speedTimeline: speedTimeline ?? this.speedTimeline,
        heartRateTimeline: heartRateTimeline ?? this.heartRateTimeline,
        heartRateTimelineSec: heartRateTimelineSec ?? this.heartRateTimelineSec,
        trackerReportJson: trackerReportJson ?? this.trackerReportJson,
      );
}

class PlayerTimelineItem {
  final DateTime? date;
  final String type;
  final String title;
  final String subtitle;
  final IconData icon;
  const PlayerTimelineItem({required this.date, required this.type, required this.title, required this.subtitle, required this.icon});
}

class PlayerProfileSnapshot {
  final Map<String, dynamic> player;
  final List<Map<String, dynamic>> trainings;
  final List<Map<String, dynamic>> attendance;
  final List<Map<String, dynamic>> matches;
  final List<Map<String, dynamic>> tests;
  final List<Map<String, dynamic>> coachRatings;
  final List<Map<String, dynamic>> selfAssessments;
  final List<Map<String, dynamic>> diaryEntries;
  final List<Map<String, dynamic>> weeklyGoals;
  final List<Map<String, dynamic>> medical;
  final List<PlayerProfileSession> sessions;
  final List<PlayerTimelineItem> timeline;

  const PlayerProfileSnapshot({
    required this.player,
    this.trainings = const [],
    this.attendance = const [],
    this.matches = const [],
    this.tests = const [],
    this.coachRatings = const [],
    this.selfAssessments = const [],
    this.diaryEntries = const [],
    this.weeklyGoals = const [],
    this.medical = const [],
    this.sessions = const [],
    this.timeline = const [],
  });


  PlayerProfileSession? get trackerMaxHrSession {
    final rows = sessions.where((e) => e.maxHr > 0).toList();
    if (rows.isEmpty) return null;
    rows.sort((a, b) => b.maxHr.compareTo(a.maxHr));
    return rows.first;
  }

  PlayerProfileSession? get trackerRestHrSession {
    final rows = sessions.where((e) => e.minHr >= 30 && e.minHr <= 120).toList();
    if (rows.isEmpty) return null;
    rows.sort((a, b) => a.minHr.compareTo(b.minHr));
    return rows.first;
  }

  int get attendancePercent {
    if (attendance.isEmpty) return 0;
    final present = attendance.where((e) {
      final value = '${e['status'] ?? e['mark'] ?? ''}'.toLowerCase();
      return value == 'present' || value.contains('прис');
    }).length;
    return ((present / attendance.length) * 100).round();
  }

  double get coachRatingAverage {
    final rows = <Map<String, dynamic>>[
      ...coachRatings,
      ...diaryEntries.where((e) {
        final role = '${e['author_role'] ?? ''}'.trim().toLowerCase();
        return (role == 'coach' || role == 'manager') && _toDouble(e['rating']) > 0;
      }),
    ];
    return _averageRating(rows);
  }

  double get selfRatingAverage {
    final rows = <Map<String, dynamic>>[
      ...selfAssessments,
      ...diaryEntries.where((e) {
        final role = '${e['author_role'] ?? ''}'.trim().toLowerCase();
        return role == 'player' && _toDouble(e['rating']) > 0;
      }),
    ];
    return _averageRating(rows);
  }

  int get testingScorePercent {
    final values = <double>[];
    for (final test in tests) {
      final rating = '${test['rating'] ?? test['rating_code'] ?? ''}'.trim().toLowerCase();
      if (rating.isNotEmpty) {
        switch (rating) {
          case 'excellent':
            values.add(100);
            continue;
          case 'good':
            values.add(80);
            continue;
          case 'satisfactory':
            values.add(60);
            continue;
          case 'poor':
            values.add(40);
            continue;
        }
      }
      final points = _toDouble(test['points']);
      if (points > 0) values.add((points / 4 * 100).clamp(0, 100).toDouble());
    }
    if (values.isEmpty) return 0;
    return (values.reduce((a, b) => a + b) / values.length).round();
  }

  int get compositeRating {
    final parts = <({double value, double weight})>[];
    if (coachRatingAverage > 0) {
      parts.add((value: coachRatingAverage * 20, weight: .35));
    }
    if (selfRatingAverage > 0) {
      parts.add((value: selfRatingAverage * 20, weight: .20));
    }
    if (attendance.isNotEmpty) {
      parts.add((value: attendancePercent.toDouble(), weight: .20));
    }
    if (testingScorePercent > 0) {
      parts.add((value: testingScorePercent.toDouble(), weight: .25));
    }
    if (parts.isEmpty) return 0;
    final totalWeight = parts.fold<double>(0, (sum, e) => sum + e.weight);
    final score = parts.fold<double>(0, (sum, e) => sum + e.value * e.weight) / totalWeight;
    return score.round().clamp(0, 100).toInt();
  }

  static double _averageRating(List<Map<String, dynamic>> rows) {
    final values = rows.map((e) => _toDouble(e['rating'])).where((e) => e > 0).toList();
    if (values.isEmpty) return 0;
    return values.reduce((a, b) => a + b) / values.length;
  }

  static double _toDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse('${value ?? ''}'.replaceAll(',', '.')) ?? 0;
  }

  PlayerProfileSnapshot copyWith({List<PlayerProfileSession>? sessions, List<PlayerTimelineItem>? timeline}) => PlayerProfileSnapshot(
        player: player,
        trainings: trainings,
        attendance: attendance,
        matches: matches,
        tests: tests,
        coachRatings: coachRatings,
        selfAssessments: selfAssessments,
        diaryEntries: diaryEntries,
        weeklyGoals: weeklyGoals,
        medical: medical,
        sessions: sessions ?? this.sessions,
        timeline: timeline ?? this.timeline,
      );
}
