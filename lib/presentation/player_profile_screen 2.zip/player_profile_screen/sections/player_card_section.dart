import 'package:flutter/material.dart';

import '../export/player_card_preview.dart';
import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerCardSection extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? session;

  const PlayerCardSection({
    super.key,
    required this.data,
    this.session,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          Row(
            children: [
              const PpDot.green(size: 7),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Карточка игрока', style: PpText.title(18)),
                    const SizedBox(height: 3),
                    Text(
                      'Профиль · форма · посещаемость · трекер',
                      style: PpText.body(10.2),
                    ),
                  ],
                ),
              ),
              const PpDotCluster(),
            ],
          ),
          const PpThinDivider(
            margin: EdgeInsets.only(top: 12, bottom: 12),
          ),
          PlayerCardPreview(
            data: data,
            session: session,
          ),
        ],
      ),
    );
  }
}
