import 'package:flutter/material.dart';

import '../models/player_profile_models.dart';
import 'player_profile_ui.dart';

class PlayerSectionTabs extends StatelessWidget {
  final PlayerProfileSection value;
  final ValueChanged<PlayerProfileSection> onChanged;
  final Set<PlayerProfileSection>? allowedSections;

  const PlayerSectionTabs({
    super.key,
    required this.value,
    required this.onChanged,
    this.allowedSections,
  });

  static const order = <PlayerProfileSection>[
    PlayerProfileSection.card,
    PlayerProfileSection.diary,
    PlayerProfileSection.activity,
    PlayerProfileSection.matches,
    PlayerProfileSection.testing,
    PlayerProfileSection.health,
  ];

  static const labels = <PlayerProfileSection, String>{
    PlayerProfileSection.card: 'Карточка игрока',
    PlayerProfileSection.diary: 'Дневник',
    PlayerProfileSection.activity: 'Активность',
    PlayerProfileSection.matches: 'Матчи',
    PlayerProfileSection.testing: 'Тестирование',
    PlayerProfileSection.health: 'Здоровье',
  };

  Color _dotColor(PlayerProfileSection section) {
    switch (section) {
      case PlayerProfileSection.card:
        return PpColors.green;
      case PlayerProfileSection.diary:
        return PpColors.greenDark;
      case PlayerProfileSection.activity:
        return PpColors.amber;
      case PlayerProfileSection.matches:
        return PpColors.green;
      case PlayerProfileSection.analytics:
        return PpColors.greenDark;
      case PlayerProfileSection.testing:
        return PpColors.amber;
      case PlayerProfileSection.health:
        return PpColors.red;
      case PlayerProfileSection.overview:
        return PpColors.green;
    }
  }

  @override
  Widget build(BuildContext context) {
    final visible = order.where((section) {
      if (allowedSections == null) return true;
      if (allowedSections!.contains(section)) return true;

      // Старые конфигурации могли разрешать отдельную Analytics.
      // Теперь она является подробным режимом Activity.
      if (section == PlayerProfileSection.activity &&
          allowedSections!.contains(
            PlayerProfileSection.analytics,
          )) {
        return true;
      }

      // Compatibility with old configurations that allowed Overview
      // but did not explicitly allow Card.
      return section == PlayerProfileSection.card &&
          allowedSections!.contains(
            PlayerProfileSection.overview,
          );
    }).toList(growable: false);

    final selected = value == PlayerProfileSection.overview
        ? PlayerProfileSection.card
        : value == PlayerProfileSection.analytics
            ? PlayerProfileSection.activity
            : value;

    return Container(
      height: 52,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(
          bottom: BorderSide(
            color: PpColors.line,
            width: .65,
          ),
        ),
      ),
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: visible.length,
        separatorBuilder: (_, __) => const SizedBox(width: 4),
        itemBuilder: (_, index) {
          final item = visible[index];
          final active = item == selected;
          final color = _dotColor(item);

          return Material(
            color: active ? PpColors.greenSoft : Colors.transparent,
            borderRadius: BorderRadius.circular(9),
            child: InkWell(
              onTap: () => onChanged(item),
              borderRadius: BorderRadius.circular(9),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 11),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    PpDot(
                      color: color,
                      size: active ? 6 : 4.5,
                      opacity: active ? 1 : .7,
                    ),
                    const SizedBox(width: 6),
                    Text(
                      labels[item]!,
                      style: PpText.body(
                        10.6,
                        color: active
                            ? PpColors.greenDark
                            : PpColors.text,
                        weight: active
                            ? FontWeight.w600
                            : FontWeight.w500,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
