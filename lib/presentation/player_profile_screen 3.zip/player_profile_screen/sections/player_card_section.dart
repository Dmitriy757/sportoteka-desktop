import 'package:flutter/material.dart';

import '../export/player_card_preview.dart';
import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerCardSection extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? session;
  final VoidCallback? onOpenReadiness;

  const PlayerCardSection({
    super.key,
    required this.data,
    this.session,
    this.onOpenReadiness,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          Row(
            children: [
              const PpDot.green(size: 7),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Карточка игрока', style: PpText.title(18)),
                    const SizedBox(height: 3),
                    Text(
                      'Профиль · форма · посещаемость · трекер',
                      style: PpText.body(10.2),
                    ),
                  ],
                ),
              ),
              const PpDotCluster(),
            ],
          ),
          const PpThinDivider(
            margin: EdgeInsets.only(top: 12, bottom: 12),
          ),
          if (data.readiness != null) ...[
            _PlayerReadinessCard(
              readiness: data.readiness!,
              onDetails: onOpenReadiness,
            ),
            const PpThinDivider(
              margin: EdgeInsets.symmetric(vertical: 12),
            ),
          ],
          PlayerCardPreview(
            data: data,
            session: session,
          ),
        ],
      ),
    );
  }
}

class _PlayerReadinessCard extends StatelessWidget {
  final PlayerReadinessSummary readiness;
  final VoidCallback? onDetails;

  const _PlayerReadinessCard({
    required this.readiness,
    this.onDetails,
  });

  Color get _accent {
    if (readiness.score >= 80) return PpColors.green;
    if (readiness.score >= 60) return PpColors.amber;
    return PpColors.red;
  }

  Color get _background {
    if (readiness.score >= 80) return PpColors.greenSoft2;
    if (readiness.score >= 60) return PpColors.amberGlass;
    return PpColors.redGlass;
  }

  @override
  Widget build(BuildContext context) {
    final accent = _accent;
    return PpSurface(
      color: _background,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PpSectionTitle(
            title: 'Готовность',
            subtitle: 'Состояние и нагрузка на сегодня',
            dotColor: accent,
            trailing: PpTextAction(
              label: 'Подробнее',
              onTap: onDetails,
              dotColor: accent,
              emphasized: true,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                width: 64,
                height: 64,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: accent.withOpacity(.22)),
                ),
                child: Text(
                  '${readiness.score.round()}',
                  style: PpText.value(17).copyWith(
                    color: accent,
                    fontSize: 21,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      readiness.label,
                      style: PpText.title(14),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      readiness.recommendations.first,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: PpText.body(10.2),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          LayoutBuilder(
            builder: (context, constraints) {
              final columns = constraints.maxWidth >= 680
                  ? 5
                  : constraints.maxWidth >= 430
                      ? 3
                      : 2;
              final width =
                  (constraints.maxWidth - (columns - 1) * 8) / columns;
              return Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _metric(
                    width,
                    '7 дней',
                    readiness.acute7.toStringAsFixed(0),
                    '${readiness.sessions7} сесс.',
                    accent,
                  ),
                  _metric(
                    width,
                    '7 / 28',
                    readiness.ratio?.toStringAsFixed(2) ?? '—',
                    'отношение',
                    (readiness.ratio ?? 0) > 1.3 ? PpColors.red : accent,
                  ),
                  _metric(
                    width,
                    'Сон',
                    readiness.hasCheckin
                        ? '${readiness.sleepHours.toStringAsFixed(1)} ч'
                        : '—',
                    'сегодня',
                    accent,
                  ),
                  _metric(
                    width,
                    'Боль',
                    readiness.hasCheckin ? '${readiness.pain}/10' : '—',
                    'самооценка',
                    readiness.pain >= 5 ? PpColors.red : accent,
                  ),
                  _metric(
                    width,
                    'RPE',
                    readiness.hasCheckin && readiness.rpe > 0
                        ? '${readiness.rpe}/10'
                        : '—',
                    'нагрузка',
                    accent,
                  ),
                ],
              );
            },
          ),
          if (!readiness.hasCheckin) ...[
            const SizedBox(height: 10),
            Text(
              'Анкета не заполнена · расчёт выполнен по данным GPS',
              style: PpText.caption(color: PpColors.muted),
            ),
          ],
        ],
      ),
    );
  }

  Widget _metric(
    double width,
    String label,
    String value,
    String note,
    Color color,
  ) {
    return SizedBox(
      width: width,
      child: PpMetric(
        label: label,
        value: value,
        note: note,
        dotColor: color,
      ),
    );
  }
}
