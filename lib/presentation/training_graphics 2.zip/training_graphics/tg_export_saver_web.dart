import 'dart:html' as html;
import 'dart:typed_data';

Future<String> saveTgExportFile(
  String fileName,
  Uint8List bytes, {
  String mimeType = 'application/octet-stream',
  String? folderName,
}) async {
  final blob = html.Blob(<dynamic>[bytes], mimeType);
  final url = html.Url.createObjectUrlFromBlob(blob);
  final anchor = html.AnchorElement(href: url)
    ..download = fileName
    ..style.display = 'none';
  html.document.body?.children.add(anchor);
  anchor.click();
  anchor.remove();
  html.Url.revokeObjectUrl(url);
  return fileName;
}
