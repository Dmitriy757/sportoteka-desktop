import 'dart:math' as math;

import 'package:flutter/material.dart';

import 'tg_models.dart';
import 'training_graphics_state.dart';

/// SPORTOTEKA 3D PRO implemented entirely with Flutter Canvas.
///
/// The scene uses a small perspective camera and projects the same tactical
/// document that is edited in [TgState]. No Unity/WebView/native 3D runtime is
/// required, so the screen behaves the same on macOS, iOS, Android and Windows.
class SportotekaFlutter3DProScreen extends StatefulWidget {
  const SportotekaFlutter3DProScreen({
    super.key,
    required this.state,
    this.teamName = '',
  });

  final TgState state;
  final String teamName;

  @override
  State<SportotekaFlutter3DProScreen> createState() =>
      _SportotekaFlutter3DProScreenState();
}

class _SportotekaFlutter3DProScreenState
    extends State<SportotekaFlutter3DProScreen> {
  double _yaw = 0.0;
  double _elevation = 0.63;
  double _distance = 4.25;
  double _fov = 48.0;
  bool _showRoutes = true;
  bool _showLabels = true;
  bool _showZones = true;
  Offset? _gestureStart;
  double _startYaw = 0;
  double _startElevation = 0;
  double _startDistance = 0;

  @override
  void initState() {
    super.initState();
    widget.state.addListener(_onStateChanged);
  }

  @override
  void dispose() {
    widget.state.removeListener(_onStateChanged);
    super.dispose();
  }

  void _onStateChanged() {
    if (mounted) setState(() {});
  }

  void _resetCamera() {
    setState(() {
      _yaw = 0;
      _elevation = 0.63;
      _distance = 4.25;
      _fov = 48;
    });
  }

  void _onScaleStart(ScaleStartDetails d) {
    _gestureStart = d.focalPoint;
    _startYaw = _yaw;
    _startElevation = _elevation;
    _startDistance = _distance;
  }

  void _onScaleUpdate(ScaleUpdateDetails d) {
    final start = _gestureStart;
    if (start == null) return;
    final delta = d.focalPoint - start;
    setState(() {
      _yaw = _startYaw + delta.dx * 0.006;
      _elevation = (_startElevation - delta.dy * 0.004)
          .clamp(0.30, 1.23)
          .toDouble();
      if ((d.scale - 1.0).abs() > 0.01) {
        _distance = (_startDistance / d.scale).clamp(2.65, 7.5).toDouble();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final team = widget.teamName.trim().isEmpty
        ? widget.state.teamName
        : widget.teamName.trim();
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F8),
      body: SafeArea(
        child: Column(
          children: [
            _header(context, team),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 8, 10, 10),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(18),
                  child: DecoratedBox(
                    decoration: const BoxDecoration(color: Color(0xFFE8ECEA)),
                    child: Stack(
                      children: [
                        Positioned.fill(
                          child: GestureDetector(
                            behavior: HitTestBehavior.opaque,
                            onScaleStart: _onScaleStart,
                            onScaleUpdate: _onScaleUpdate,
                            child: CustomPaint(
                              painter: _Sportoteka3DScenePainter(
                                state: widget.state,
                                yaw: _yaw,
                                elevation: _elevation,
                                distance: _distance,
                                fov: _fov,
                                showRoutes: _showRoutes,
                                showLabels: _showLabels,
                                showZones: _showZones,
                              ),
                              child: const SizedBox.expand(),
                            ),
                          ),
                        ),
                        Positioned(
                          left: 12,
                          bottom: 12,
                          child: _cameraHint(),
                        ),
                        Positioned(
                          right: 12,
                          bottom: 12,
                          child: _cameraPad(),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _header(BuildContext context, String team) {
    return Container(
      height: 56,
      padding: const EdgeInsets.symmetric(horizontal: 10),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFE8EBEE))),
      ),
      child: Row(
        children: [
          _roundAction(
            icon: Icons.arrow_back_rounded,
            tooltip: 'Назад в редактор',
            onTap: () => Navigator.of(context).pop(),
          ),
          const SizedBox(width: 9),
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: const Color(0xFFEAF8F0),
              borderRadius: BorderRadius.circular(10),
            ),
            child: const Icon(Icons.view_in_ar_rounded,
                size: 18, color: Color(0xFF00A750)),
          ),
          const SizedBox(width: 9),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Sportoteka 3D Pro',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF101418),
                  ),
                ),
                Text(
                  team.isEmpty
                      ? 'Текущая схема · 3D PRO'
                      : '$team · текущая схема',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontFamily: 'Inter',
                    fontSize: 10.5,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF667085),
                  ),
                ),
              ],
            ),
          ),
          _headerToggle(
            icon: Icons.route_rounded,
            tooltip: 'Маршруты',
            value: _showRoutes,
            onTap: () => setState(() => _showRoutes = !_showRoutes),
          ),
          const SizedBox(width: 5),
          _headerToggle(
            icon: Icons.sell_outlined,
            tooltip: 'Подписи',
            value: _showLabels,
            onTap: () => setState(() => _showLabels = !_showLabels),
          ),
          const SizedBox(width: 5),
          _headerToggle(
            icon: Icons.crop_square_rounded,
            tooltip: 'Зоны',
            value: _showZones,
            onTap: () => setState(() => _showZones = !_showZones),
          ),
          const SizedBox(width: 5),
          _roundAction(
            icon: Icons.center_focus_strong_rounded,
            tooltip: 'Сбросить камеру',
            onTap: _resetCamera,
          ),
        ],
      ),
    );
  }

  Widget _headerToggle({
    required IconData icon,
    required String tooltip,
    required bool value,
    required VoidCallback onTap,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: value ? const Color(0xFFEAF8F0) : Colors.white,
        borderRadius: BorderRadius.circular(9),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(9),
          child: Container(
            width: 34,
            height: 34,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              border: Border.all(
                color: value
                    ? const Color(0xFFBFE9D1)
                    : const Color(0xFFE4E7EC),
              ),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon,
                size: 17,
                color: value
                    ? const Color(0xFF00A750)
                    : const Color(0xFF667085)),
          ),
        ),
      ),
    );
  }

  Widget _roundAction({
    required IconData icon,
    required String tooltip,
    required VoidCallback onTap,
  }) {
    return Tooltip(
      message: tooltip,
      child: Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(9),
          child: Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              border: Border.all(color: const Color(0xFFE4E7EC)),
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(icon, size: 17, color: const Color(0xFF344054)),
          ),
        ),
      ),
    );
  }

  Widget _cameraHint() {
    return IgnorePointer(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.92),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: const Color(0xFFE5E7EB)),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.open_with_rounded, size: 14, color: Color(0xFF00A750)),
            SizedBox(width: 6),
            Text(
              'Перетаскивание — камера · щипок — масштаб',
              style: TextStyle(
                fontFamily: 'Inter',
                fontSize: 10,
                fontWeight: FontWeight.w600,
                color: Color(0xFF475467),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cameraPad() {
    return Container(
      padding: const EdgeInsets.all(5),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.94),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE4E7EC)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          _smallCameraButton(Icons.rotate_left_rounded,
              () => setState(() => _yaw -= 0.16)),
          _smallCameraButton(Icons.rotate_right_rounded,
              () => setState(() => _yaw += 0.16)),
          _smallCameraButton(Icons.add_rounded,
              () => setState(() => _distance = (_distance - .35).clamp(2.65, 7.5).toDouble())),
          _smallCameraButton(Icons.remove_rounded,
              () => setState(() => _distance = (_distance + .35).clamp(2.65, 7.5).toDouble())),
        ],
      ),
    );
  }

  Widget _smallCameraButton(IconData icon, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: SizedBox(
        width: 32,
        height: 32,
        child: Icon(icon, size: 16, color: const Color(0xFF344054)),
      ),
    );
  }
}

class _Sportoteka3DScenePainter extends CustomPainter {
  const _Sportoteka3DScenePainter({
    required this.state,
    required this.yaw,
    required this.elevation,
    required this.distance,
    required this.fov,
    required this.showRoutes,
    required this.showLabels,
    required this.showZones,
  });

  final TgState state;
  final double yaw;
  final double elevation;
  final double distance;
  final double fov;
  final bool showRoutes;
  final bool showLabels;
  final bool showZones;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(
      Offset.zero & size,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFFF4F7F5), Color(0xFFDCE4DF)],
        ).createShader(Offset.zero & size),
    );

    final camera = _Camera3D(
      size: size,
      yaw: yaw,
      elevation: elevation,
      distance: distance,
      fovDegrees: fov,
      fieldSize: state.fieldLogicalSize,
    );

    _drawPitchShadow(canvas, camera);
    _drawPitch(canvas, camera);

    final ground = <_DepthPaint>[];
    final elevated = <_DepthPaint>[];

    for (final e in state.elements) {
      if (e.hidden) continue;
      if (e is TgStamp) {
        final override = state.animationPositionFor(e.id);
        final stamp = override == null ? e : e.copyWith(pos: override);
        final depth = camera.depthForScene(stamp.pos);
        elevated.add(_DepthPaint(depth, () => _drawStamp(canvas, camera, stamp)));
        continue;
      }
      if (e is TgLine && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawLine(canvas, camera, e)));
      } else if (e is TgPolyline && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawPolyline(canvas, camera, e)));
      } else if (e is TgCurve && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawCurve(canvas, camera, e)));
      } else if (e is TgWavy && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawWavy(canvas, camera, e)));
      } else if (e is TgSpring && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawSpring(canvas, camera, e)));
      } else if (e is TgSpiral && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawSpiral(canvas, camera, e)));
      } else if (e is TgZigzag && showRoutes) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawZigzag(canvas, camera, e)));
      } else if (e is TgZone && showZones) {
        ground.add(_DepthPaint(camera.depthForScene(e.bounds().center),
            () => _drawZone(canvas, camera, e)));
      } else if (e is TgRect && showZones) {
        ground.add(_DepthPaint(camera.depthForScene(e.position),
            () => _drawRect(canvas, camera, e)));
      } else if (e is TgCircle && showZones) {
        ground.add(_DepthPaint(camera.depthForScene(e.position),
            () => _drawCircle(canvas, camera, e)));
      } else if (e is TgText && showLabels) {
        elevated.add(_DepthPaint(camera.depthForScene(e.position),
            () => _drawText(canvas, camera, e)));
      }
    }

    ground.sort((a, b) => b.depth.compareTo(a.depth));
    elevated.sort((a, b) => b.depth.compareTo(a.depth));
    for (final item in ground) item.paint();
    for (final item in elevated) item.paint();
  }

  void _drawPitchShadow(Canvas canvas, _Camera3D camera) {
    final pts = camera.pitchCorners(vertical: -0.035);
    if (pts.any((p) => p == null)) return;
    final path = Path()..moveTo(pts[0]!.dx, pts[0]!.dy);
    for (int i = 1; i < pts.length; i++) {
      path.lineTo(pts[i]!.dx, pts[i]!.dy);
    }
    path.close();
    canvas.drawPath(
      path.shift(const Offset(0, 10)),
      Paint()
        ..color = Colors.black.withOpacity(.17)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 16),
    );
  }

  void _drawPitch(Canvas canvas, _Camera3D camera) {
    final corners = camera.pitchCorners();
    if (corners.any((p) => p == null)) return;
    final pitch = Path()..moveTo(corners[0]!.dx, corners[0]!.dy);
    for (int i = 1; i < corners.length; i++) pitch.lineTo(corners[i]!.dx, corners[i]!.dy);
    pitch.close();
    canvas.drawPath(pitch, Paint()..color = const Color(0xFF2E9558));

    // restrained mowing stripes
    for (int i = 0; i < 10; i++) {
      if (i.isEven) continue;
      final y0 = state.fieldLogicalSize.height * i / 10;
      final y1 = state.fieldLogicalSize.height * (i + 1) / 10;
      final p0 = camera.projectScene(Offset(0, y0));
      final p1 = camera.projectScene(Offset(state.fieldLogicalSize.width, y0));
      final p2 = camera.projectScene(Offset(state.fieldLogicalSize.width, y1));
      final p3 = camera.projectScene(Offset(0, y1));
      if ([p0, p1, p2, p3].any((p) => p == null)) continue;
      final stripe = Path()
        ..moveTo(p0!.dx, p0.dy)
        ..lineTo(p1!.dx, p1.dy)
        ..lineTo(p2!.dx, p2.dy)
        ..lineTo(p3!.dx, p3.dy)
        ..close();
      canvas.drawPath(stripe, Paint()..color = Colors.white.withOpacity(.035));
    }

    final linePaint = Paint()
      ..color = Colors.white.withOpacity(.88)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.45
      ..strokeCap = StrokeCap.round;

    _groundPolyline(canvas, camera, <Offset>[
      Offset.zero,
      Offset(state.fieldLogicalSize.width, 0),
      Offset(state.fieldLogicalSize.width, state.fieldLogicalSize.height),
      Offset(0, state.fieldLogicalSize.height),
      Offset.zero,
    ], linePaint);

    final w = state.fieldLogicalSize.width;
    final h = state.fieldLogicalSize.height;
    _groundPolyline(canvas, camera,
        [Offset(w / 2, 0), Offset(w / 2, h)], linePaint);
    _groundCircle(canvas, camera, Offset(w / 2, h / 2), h * .135, linePaint);
    _groundCircle(canvas, camera, Offset(w / 2, h / 2), 3.8,
        Paint()..color = Colors.white.withOpacity(.9));

    final boxDepth = w * .155;
    final boxWidth = h * .58;
    final boxTop = (h - boxWidth) / 2;
    _groundPolyline(canvas, camera, [
      Offset(0, boxTop),
      Offset(boxDepth, boxTop),
      Offset(boxDepth, boxTop + boxWidth),
      Offset(0, boxTop + boxWidth),
    ], linePaint);
    _groundPolyline(canvas, camera, [
      Offset(w, boxTop),
      Offset(w - boxDepth, boxTop),
      Offset(w - boxDepth, boxTop + boxWidth),
      Offset(w, boxTop + boxWidth),
    ], linePaint);
  }

  void _drawLine(Canvas canvas, _Camera3D camera, TgLine e) {
    final a = camera.projectScene(e.a, vertical: .012);
    final b = camera.projectScene(e.b, vertical: .012);
    if (a == null || b == null) return;
    final p = Paint()
      ..color = e.color.withOpacity((e.opacity * .95).clamp(0.0, 1.0).toDouble())
      ..strokeWidth = (e.width * .72).clamp(1.4, 7.0).toDouble()
      ..strokeCap = StrokeCap.round
      ..style = PaintingStyle.stroke;
    canvas.drawLine(a, b, p);
    if (e.end == LineEnd.arrow) _arrowHead(canvas, a, b, p.color, e.arrowSize * .7);
  }

  void _drawPolyline(Canvas canvas, _Camera3D camera, TgPolyline e) {
    final pts = e.points
        .map((p) => camera.projectScene(p, vertical: .012))
        .whereType<Offset>()
        .toList();
    final paint = Paint()
      ..color = e.color.withOpacity((e.opacity * .95).clamp(0.0, 1.0).toDouble())
      ..strokeWidth = (e.width * .72).clamp(1.4, 7.0).toDouble()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    _screenPolyline(canvas, pts, paint);
    if (e.end == LineEnd.arrow && pts.length > 1) {
      _arrowHead(canvas, pts[pts.length - 2], pts.last, e.color, e.arrowSize * .7);
    }
  }

  void _drawCurve(Canvas canvas, _Camera3D camera, TgCurve e) {
    final pts = <Offset>[];
    for (int i = 0; i <= 32; i++) {
      final p = camera.projectScene(e.pointAt(i / 32), vertical: .012);
      if (p != null) pts.add(p);
    }
    _screenPolyline(
      canvas,
      pts,
      Paint()
        ..color = e.color.withOpacity((e.opacity * .95).clamp(0.0, 1.0).toDouble())
        ..strokeWidth = (e.width * .72).clamp(1.4, 7.0).toDouble()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round,
    );
    if (e.end == LineEnd.arrow && pts.length > 1) {
      _arrowHead(canvas, pts[pts.length - 2], pts.last, e.color, e.arrowSize * .7);
    }
  }

  void _drawWavy(Canvas canvas, _Camera3D camera, TgWavy e) {
    final base = <Offset>[e.start, ...e.controlPoints, e.endPoint];
    if (base.length < 2) return;
    final sampled = <Offset>[];
    for (int i = 0; i < base.length - 1; i++) {
      final a = base[i];
      final b = base[i + 1];
      final d = b - a;
      final len = math.max(1.0, d.distance);
      final n = Offset(-d.dy / len, d.dx / len);
      for (int j = 0; j < 12; j++) {
        final t = j / 12;
        final pos = Offset.lerp(a, b, t)!;
        final wave = math.sin((i + t) * math.pi * 2.7 + e.phase) * e.amplitude * .45;
        sampled.add(pos + n * wave);
      }
    }
    sampled.add(base.last);
    final pts = sampled
        .map((p) => camera.projectScene(p, vertical: .012))
        .whereType<Offset>()
        .toList();
    _screenPolyline(
      canvas,
      pts,
      Paint()
        ..color = e.color.withOpacity((e.opacity * .95).clamp(0.0, 1.0).toDouble())
        ..strokeWidth = (e.width * .72).clamp(1.4, 7.0).toDouble()
        ..style = PaintingStyle.stroke
        ..strokeCap = StrokeCap.round,
    );
  }

  void _drawSpring(Canvas canvas, _Camera3D camera, TgSpring e) {
    final dir = e.endPoint - e.start;
    final len = math.max(1.0, dir.distance).toDouble();
    final perp = Offset(-dir.dy / len, dir.dx / len);
    final sampled = <Offset>[];
    for (int i = 0; i <= 96; i++) {
      final t = i / 96;
      final base = e.start + dir * t;
      final angle = t * e.frequency * 2 * math.pi + e.phase;
      final r = e.amplitude * (1 - .5 * t);
      sampled.add(base + perp * (math.sin(angle) * r));
    }
    _drawGeneratedRoute(canvas, camera, sampled, e.color, e.width, e.opacity,
        e.lineEnd, e.arrowSize);
  }

  void _drawSpiral(Canvas canvas, _Camera3D camera, TgSpiral e) {
    final dir = e.endPoint - e.start;
    final len = math.max(1.0, dir.distance).toDouble();
    final perp = Offset(-dir.dy / len, dir.dx / len);
    final fadeEdge = e.fadeEdge.clamp(0.0, .49).toDouble();
    final sampled = <Offset>[];
    for (int i = 0; i <= 128; i++) {
      final t = i / 128;
      final base = e.start + dir * t;
      final angle = t * e.turns * 2 * math.pi + e.phase;
      var fade = 1.0;
      if (fadeEdge > 0) {
        final a = t < fadeEdge ? t / fadeEdge : 1.0;
        final b = t > 1 - fadeEdge ? (1 - t) / fadeEdge : 1.0;
        fade = math.min(a, b).clamp(0.0, 1.0).toDouble();
      }
      final r = e.amplitude * (1 + e.grow * t);
      sampled.add(base + perp * (math.sin(angle) * r * fade));
    }
    _drawGeneratedRoute(canvas, camera, sampled, e.color, e.width, e.opacity,
        e.lineEnd, e.arrowSize);
  }

  void _drawZigzag(Canvas canvas, _Camera3D camera, TgZigzag e) {
    final dir = e.endPoint - e.start;
    final len = math.max(1.0, dir.distance).toDouble();
    final perp = Offset(-dir.dy / len, dir.dx / len);
    final sampled = <Offset>[];
    for (int i = 0; i <= 96; i++) {
      final t = i / 96;
      final base = e.start + dir * t;
      final wave = math.sin(t * e.frequency * 2 * math.pi + e.phase);
      sampled.add(base + perp * ((wave >= 0 ? 1.0 : -1.0) * e.amplitude));
    }
    _drawGeneratedRoute(canvas, camera, sampled, e.color, e.width, e.opacity,
        e.lineEnd, e.arrowSize);
  }

  void _drawGeneratedRoute(
    Canvas canvas,
    _Camera3D camera,
    List<Offset> source,
    Color color,
    double width,
    double opacity,
    LineEnd end,
    double arrowSize,
  ) {
    final pts = source
        .map((p) => camera.projectScene(p, vertical: .012))
        .whereType<Offset>()
        .toList();
    final paint = Paint()
      ..color = color.withOpacity((opacity * .95).clamp(0.0, 1.0).toDouble())
      ..strokeWidth = (width * .72).clamp(1.4, 7.0).toDouble()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    _screenPolyline(canvas, pts, paint);
    if (end == LineEnd.arrow && pts.length > 1) {
      _arrowHead(canvas, pts[pts.length - 2], pts.last, color, arrowSize * .7);
    }
  }

  void _drawZone(Canvas canvas, _Camera3D camera, TgZone e) {
    final pts = e.points.map((p) => camera.projectScene(p, vertical: .008)).toList();
    if (pts.length < 3 || pts.any((p) => p == null)) return;
    final path = Path()..moveTo(pts.first!.dx, pts.first!.dy);
    for (int i = 1; i < pts.length; i++) path.lineTo(pts[i]!.dx, pts[i]!.dy);
    path.close();
    canvas.drawPath(
      path,
      Paint()..color = e.fill.withOpacity((e.opacity * .58).clamp(0.0, 1.0).toDouble()),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.0, e.borderWidth * .65).toDouble()
        ..color = e.border.withOpacity(.9),
    );
  }

  void _drawRect(Canvas canvas, _Camera3D camera, TgRect e) {
    final hw = e.width / 2;
    final hh = e.height / 2;
    final c = math.cos(e.rotation);
    final s = math.sin(e.rotation);
    Offset rot(double x, double y) =>
        e.position + Offset(x * c - y * s, x * s + y * c);
    final src = [rot(-hw, -hh), rot(hw, -hh), rot(hw, hh), rot(-hw, hh)];
    final pts = src.map((p) => camera.projectScene(p, vertical: .008)).toList();
    if (pts.any((p) => p == null)) return;
    final path = Path()..moveTo(pts.first!.dx, pts.first!.dy);
    for (int i = 1; i < pts.length; i++) path.lineTo(pts[i]!.dx, pts[i]!.dy);
    path.close();
    canvas.drawPath(path, Paint()..color = e.fill.withOpacity((e.opacity * .55).clamp(0.0, 1.0).toDouble()));
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.0, e.borderWidth * .65).toDouble()
        ..color = e.border.withOpacity(.9),
    );
  }

  void _drawCircle(Canvas canvas, _Camera3D camera, TgCircle e) {
    final pts = <Offset>[];
    for (int i = 0; i <= 40; i++) {
      final a = i / 40 * math.pi * 2;
      final p = e.position + Offset(math.cos(a), math.sin(a)) * e.radius;
      final sp = camera.projectScene(p, vertical: .008);
      if (sp != null) pts.add(sp);
    }
    if (pts.length < 3) return;
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final p in pts.skip(1)) path.lineTo(p.dx, p.dy);
    path.close();
    canvas.drawPath(path, Paint()..color = e.fill.withOpacity((e.opacity * .45).clamp(0.0, 1.0).toDouble()));
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = math.max(1.0, e.borderWidth * .65).toDouble()
        ..color = e.border.withOpacity(.9),
    );
  }

  void _drawText(Canvas canvas, _Camera3D camera, TgText e) {
    final p = camera.projectScene(e.position, vertical: .14);
    if (p == null) return;
    final tp = TextPainter(
      text: TextSpan(
        text: e.text,
        style: TextStyle(
          fontFamily: 'Inter',
          color: e.color.withOpacity(e.opacity),
          fontWeight: FontWeight.w700,
          fontSize: (e.size * .55).clamp(9.0, 28.0).toDouble(),
          shadows: const [Shadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))],
        ),
      ),
      textDirection: TextDirection.ltr,
      textAlign: TextAlign.center,
    )..layout(maxWidth: 180);
    tp.paint(canvas, p - Offset(tp.width / 2, tp.height / 2));
  }

  void _drawStamp(Canvas canvas, _Camera3D camera, TgStamp e) {
    final ground = camera.projectScene(e.pos, vertical: .008);
    if (ground == null) return;
    final asset = e.asset.toLowerCase();
    final isBall = asset.startsWith('sportoteka://ball') || asset.contains('/ball');
    final isCone = asset.contains('cone') || asset.endsWith('://cone');
    final isDummy = asset.contains('dummy') || asset.endsWith('://dummy');
    final isGoal = asset.contains('/vorota1/') || asset.contains('goal');

    if (isBall) {
      final p = camera.projectScene(e.pos, vertical: .06) ?? ground;
      final r = (10.0 * camera.scaleAtScene(e.pos)).clamp(5.5, 12.0).toDouble();
      canvas.drawOval(
        Rect.fromCenter(center: ground + const Offset(0, 4), width: r * 2.3, height: r * .7),
        Paint()..color = Colors.black.withOpacity(.18),
      );
      canvas.drawCircle(p, r, Paint()..color = Colors.white);
      canvas.drawCircle(p, r, Paint()..style = PaintingStyle.stroke..strokeWidth = 1.5..color = const Color(0xFF1F2937));
      canvas.drawCircle(p, r * .28, Paint()..color = const Color(0xFF1F2937));
      return;
    }

    if (isCone) {
      final top = camera.projectScene(e.pos, vertical: .17) ?? ground;
      final sc = camera.scaleAtScene(e.pos);
      final half = (9 * sc).clamp(5.0, 11.0).toDouble();
      final path = Path()
        ..moveTo(top.dx, top.dy)
        ..lineTo(ground.dx - half, ground.dy)
        ..lineTo(ground.dx + half, ground.dy)
        ..close();
      canvas.drawPath(path, Paint()..color = e.color ?? const Color(0xFFF59E0B));
      return;
    }

    if (isDummy) {
      final top = camera.projectScene(e.pos, vertical: .42) ?? ground;
      final sc = camera.scaleAtScene(e.pos);
      canvas.drawLine(top + Offset(0, 8 * sc), ground, Paint()..color = const Color(0xFFB45309)..strokeWidth = (7 * sc).clamp(3.0, 8.0).toDouble());
      canvas.drawCircle(top, (8 * sc).clamp(4.0, 9.0).toDouble(), Paint()..color = const Color(0xFFD97706));
      return;
    }

    if (isGoal) {
      final left = camera.projectScene(e.pos + const Offset(0, -45), vertical: 0);
      final right = camera.projectScene(e.pos + const Offset(0, 45), vertical: 0);
      final leftTop = camera.projectScene(e.pos + const Offset(0, -45), vertical: .32);
      final rightTop = camera.projectScene(e.pos + const Offset(0, 45), vertical: .32);
      if ([left, right, leftTop, rightTop].any((p) => p == null)) return;
      final paint = Paint()..color = Colors.white.withOpacity(.95)..strokeWidth = 3..style = PaintingStyle.stroke;
      canvas.drawLine(left!, leftTop!, paint);
      canvas.drawLine(right!, rightTop!, paint);
      canvas.drawLine(leftTop, rightTop, paint);
      return;
    }

    _drawPlayer(canvas, camera, e, ground);
  }

  void _drawPlayer(Canvas canvas, _Camera3D camera, TgStamp e, Offset ground) {
    final sc = camera.scaleAtScene(e.pos);
    final top = camera.projectScene(e.pos, vertical: .34) ?? ground;
    final torsoTop = camera.projectScene(e.pos, vertical: .27) ?? top;
    final torsoBottom = camera.projectScene(e.pos, vertical: .10) ?? ground;
    final jersey = _playerColor(e);
    final shadowW = (25 * sc).clamp(12.0, 30.0).toDouble();
    canvas.drawOval(
      Rect.fromCenter(center: ground + const Offset(0, 3), width: shadowW, height: shadowW * .28),
      Paint()..color = Colors.black.withOpacity(.20),
    );
    final bodyPaint = Paint()
      ..color = jersey
      ..strokeWidth = (10 * sc).clamp(5.0, 12.0).toDouble()
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(torsoTop, torsoBottom, bodyPaint);
    canvas.drawCircle(top, (7.2 * sc).clamp(4.2, 8.6).toDouble(), Paint()..color = const Color(0xFFF1C7A5));

    if (!showLabels) return;
    final label = _stampLabel(e);
    if (label.isEmpty) return;
    final p = camera.projectScene(e.pos, vertical: .43) ?? top;
    final tp = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          fontFamily: 'Inter',
          color: Color(0xFF111827),
          fontSize: 9.5,
          fontWeight: FontWeight.w800,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout(maxWidth: 110);
    final bg = RRect.fromRectAndRadius(
      Rect.fromCenter(center: p, width: tp.width + 12, height: tp.height + 6),
      const Radius.circular(7),
    );
    canvas.drawRRect(bg, Paint()..color = Colors.white.withOpacity(.90));
    tp.paint(canvas, p - Offset(tp.width / 2, tp.height / 2));
  }

  Color _playerColor(TgStamp e) {
    if (e.playerColors != null) return e.playerColors!.jersey;
    if (e.color != null) return e.color!;
    final uri = Uri.tryParse(e.asset);
    final ring = uri?.queryParameters['ring'];
    if (ring != null) {
      final raw = ring.replaceAll('0x', '').replaceAll('#', '');
      final value = int.tryParse(raw, radix: 16);
      if (value != null) return Color(raw.length <= 6 ? 0xFF000000 | value : value);
    }
    return const Color(0xFF00A750);
  }

  String _stampLabel(TgStamp e) {
    final uri = Uri.tryParse(e.asset);
    if (uri != null && uri.scheme == 'sportoteka' && uri.host == 'player-avatar') {
      final name = (uri.queryParameters['name'] ?? e.name ?? '').trim();
      final number = (uri.queryParameters['number'] ?? '').trim();
      if (number.isNotEmpty && name.isNotEmpty) return '$number · $name';
      return number.isNotEmpty ? number : name;
    }
    return (e.name ?? '').trim();
  }

  void _groundPolyline(Canvas canvas, _Camera3D camera, List<Offset> scene, Paint paint) {
    final pts = scene.map((p) => camera.projectScene(p, vertical: .006)).whereType<Offset>().toList();
    _screenPolyline(canvas, pts, paint);
  }

  void _groundCircle(Canvas canvas, _Camera3D camera, Offset center, double radius, Paint paint) {
    final pts = <Offset>[];
    for (int i = 0; i <= 48; i++) {
      final a = i / 48 * math.pi * 2;
      final sp = camera.projectScene(center + Offset(math.cos(a), math.sin(a)) * radius, vertical: .006);
      if (sp != null) pts.add(sp);
    }
    _screenPolyline(canvas, pts, paint);
  }

  void _screenPolyline(Canvas canvas, List<Offset> pts, Paint paint) {
    if (pts.length < 2) return;
    final path = Path()..moveTo(pts.first.dx, pts.first.dy);
    for (final p in pts.skip(1)) path.lineTo(p.dx, p.dy);
    canvas.drawPath(path, paint);
  }

  void _arrowHead(Canvas canvas, Offset a, Offset b, Color color, double size) {
    final d = b - a;
    final len = d.distance;
    if (len < .5) return;
    final u = d / len;
    final n = Offset(-u.dy, u.dx);
    final s = size.clamp(7.0, 22.0).toDouble();
    final p1 = b - u * s + n * (s * .48);
    final p2 = b - u * s - n * (s * .48);
    final path = Path()..moveTo(b.dx, b.dy)..lineTo(p1.dx, p1.dy)..lineTo(p2.dx, p2.dy)..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(covariant _Sportoteka3DScenePainter oldDelegate) => true;
}

class _DepthPaint {
  const _DepthPaint(this.depth, this.paint);
  final double depth;
  final VoidCallback paint;
}

class _Camera3D {
  _Camera3D({
    required this.size,
    required this.yaw,
    required this.elevation,
    required this.distance,
    required this.fovDegrees,
    required this.fieldSize,
  }) {
    final horizontal = distance * math.cos(elevation);
    position = _V3(
      math.sin(yaw) * horizontal,
      distance * math.sin(elevation),
      math.cos(yaw) * horizontal,
    );
    forward = (const _V3.zero() - position).normalized;
    right = forward.cross(const _V3(0, 1, 0)).normalized;
    up = right.cross(forward).normalized;
    focal = math.min(size.width, size.height) * .5 /
        math.tan((fovDegrees * math.pi / 180) / 2);
  }

  final Size size;
  final double yaw;
  final double elevation;
  final double distance;
  final double fovDegrees;
  final Size fieldSize;
  late final _V3 position;
  late final _V3 forward;
  late final _V3 right;
  late final _V3 up;
  late final double focal;

  _V3 worldForScene(Offset p, {double vertical = 0}) {
    final fx = fieldSize.width <= 0 ? 1050.0 : fieldSize.width;
    final fy = fieldSize.height <= 0 ? 680.0 : fieldSize.height;
    return _V3((p.dx / fx - .5) * 3.4, vertical, (p.dy / fy - .5) * 2.2);
  }

  Offset? projectScene(Offset p, {double vertical = 0}) => project(worldForScene(p, vertical: vertical));

  Offset? project(_V3 point) {
    final rel = point - position;
    final z = rel.dot(forward);
    if (z <= .08) return null;
    final x = rel.dot(right);
    final y = rel.dot(up);
    return Offset(size.width / 2 + focal * x / z, size.height * .50 - focal * y / z);
  }

  double depthForScene(Offset p) {
    final rel = worldForScene(p) - position;
    return rel.dot(forward);
  }

  double scaleAtScene(Offset p) {
    final depth = math.max(.25, depthForScene(p));
    return (focal / depth / 430).clamp(.55, 1.45).toDouble();
  }

  List<Offset?> pitchCorners({double vertical = 0}) {
    return <Offset?>[
      projectScene(Offset.zero, vertical: vertical),
      projectScene(Offset(fieldSize.width, 0), vertical: vertical),
      projectScene(Offset(fieldSize.width, fieldSize.height), vertical: vertical),
      projectScene(Offset(0, fieldSize.height), vertical: vertical),
    ];
  }
}

class _V3 {
  const _V3(this.x, this.y, this.z);
  const _V3.zero() : x = 0, y = 0, z = 0;
  final double x;
  final double y;
  final double z;

  _V3 operator -(_V3 other) => _V3(x - other.x, y - other.y, z - other.z);
  double dot(_V3 other) => x * other.x + y * other.y + z * other.z;
  _V3 cross(_V3 o) => _V3(y * o.z - z * o.y, z * o.x - x * o.z, x * o.y - y * o.x);
  double get length => math.sqrt(x * x + y * y + z * z);
  _V3 get normalized {
    final l = length;
    return l < 1e-8 ? const _V3.zero() : _V3(x / l, y / l, z / l);
  }
}
