import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/sportoteka_workspace_icons.dart';

/// Самописный редактор заметок Sportoteka OS.
///
/// Редактор не зависит от стороннего rich-text пакета: форматирование хранится
/// в простом переносимом тексте, а контекст игрока, тренера или команды
/// отображается отдельно и не смешивается с содержимым документа.
class WorkspaceDocumentEditor extends StatefulWidget {
  const WorkspaceDocumentEditor({
    super.key,
    required this.initialTitle,
    this.initialBody = '',
    this.readOnly = false,
    this.titleReadOnly = false,
    this.onSave,
    this.contextLabel = 'Рабочая заметка',
    this.contextName = '',
    this.documentType = 'Заметка',
    this.autoSave = true,
    this.showTemplates = true,
    this.onClose,
  });

  final String initialTitle;
  final String initialBody;
  final bool readOnly;
  final bool titleReadOnly;
  final Future<void> Function(String title, String body)? onSave;
  final String contextLabel;
  final String contextName;
  final String documentType;
  final bool autoSave;
  final bool showTemplates;
  final VoidCallback? onClose;

  @override
  State<WorkspaceDocumentEditor> createState() =>
      _WorkspaceDocumentEditorState();
}

class _WorkspaceDocumentEditorState extends State<WorkspaceDocumentEditor> {
  static const _green = Color(0xFF0B8F55);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);
  static const _line = Color(0xFFE6EAE7);
  static const _surface = Color(0xFFF3F5F3);

  late final TextEditingController _titleController;
  late final TextEditingController _bodyController;
  final FocusNode _bodyFocus = FocusNode();

  Timer? _autoSaveTimer;
  bool _saving = false;
  bool _saveQueued = false;
  bool _saveError = false;
  int _revision = 0;
  int _savedRevision = 0;

  bool get _dirty => _revision != _savedRevision;

  @override
  void initState() {
    super.initState();
    _titleController = TextEditingController(text: widget.initialTitle);
    _bodyController = TextEditingController(text: widget.initialBody);
    _titleController.addListener(_handleEdit);
    _bodyController.addListener(_handleEdit);
  }

  @override
  void didUpdateWidget(covariant WorkspaceDocumentEditor oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (_dirty || _saving) return;
    final titleChanged = oldWidget.initialTitle != widget.initialTitle;
    final bodyChanged = oldWidget.initialBody != widget.initialBody;
    if (!titleChanged && !bodyChanged) return;

    _titleController.removeListener(_handleEdit);
    _bodyController.removeListener(_handleEdit);
    if (titleChanged) _titleController.text = widget.initialTitle;
    if (bodyChanged) _bodyController.text = widget.initialBody;
    _titleController.addListener(_handleEdit);
    _bodyController.addListener(_handleEdit);
    _revision = 0;
    _savedRevision = 0;
  }

  @override
  void dispose() {
    _autoSaveTimer?.cancel();
    _titleController.removeListener(_handleEdit);
    _bodyController.removeListener(_handleEdit);
    _titleController.dispose();
    _bodyController.dispose();
    _bodyFocus.dispose();
    super.dispose();
  }

  void _handleEdit() {
    _revision += 1;
    _saveError = false;
    if (mounted) setState(() {});
    if (!widget.readOnly && widget.autoSave && widget.onSave != null) {
      _autoSaveTimer?.cancel();
      _autoSaveTimer = Timer(const Duration(milliseconds: 1100), _save);
    }
  }

  Future<void> _save() async {
    if (widget.readOnly || widget.onSave == null || !_dirty) return;
    if (_saving) {
      _saveQueued = true;
      return;
    }

    _autoSaveTimer?.cancel();
    final revision = _revision;
    setState(() {
      _saving = true;
      _saveError = false;
    });

    try {
      await widget.onSave!(
        _titleController.text.trim(),
        _bodyController.text,
      );
      if (!mounted) return;
      setState(() {
        _savedRevision = revision;
        _saving = false;
      });
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _saving = false;
        _saveError = true;
      });
    }

    if (!mounted) return;
    final shouldSaveAgain = _saveQueued || _dirty;
    _saveQueued = false;
    if (shouldSaveAgain && !_saveError) {
      _autoSaveTimer = Timer(const Duration(milliseconds: 260), _save);
    }
  }

  Future<void> _requestClose() async {
    if (_saving) {
      _saveQueued = true;
      while (_saving && mounted) {
        await Future<void>.delayed(const Duration(milliseconds: 40));
      }
    }
    if (_dirty && widget.onSave != null) await _save();
    if (!mounted || _saveError) return;
    widget.onClose?.call();
  }

  void _wrapSelection(String left, String right) {
    if (widget.readOnly) return;
    final value = _bodyController.value;
    final selection = value.selection;
    final start = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final end = selection.isValid
        ? selection.end.clamp(start, value.text.length).toInt()
        : start;
    final selected = value.text.substring(start, end);
    final replacement = '$left$selected$right';
    final text = value.text.replaceRange(start, end, replacement);
    final cursor = selected.isEmpty ? start + left.length : start + replacement.length;
    _bodyController.value = TextEditingValue(
      text: text,
      selection: TextSelection.collapsed(offset: cursor),
    );
    _bodyFocus.requestFocus();
  }

  void _prefixSelection(String prefix) {
    if (widget.readOnly) return;
    final value = _bodyController.value;
    final selection = value.selection;
    final rawStart = selection.isValid
        ? selection.start.clamp(0, value.text.length).toInt()
        : value.text.length;
    final rawEnd = selection.isValid
        ? selection.end.clamp(rawStart, value.text.length).toInt()
        : rawStart;
    final lineStart =
        value.text.lastIndexOf('\n', rawStart == 0 ? 0 : rawStart - 1) + 1;
    final nextBreak = value.text.indexOf('\n', rawEnd);
    final lineEnd = nextBreak < 0 ? value.text.length : nextBreak;
    final block = value.text.substring(lineStart, lineEnd);
    final replacement =
        block.split('\n').map((line) => '$prefix$line').join('\n');
    _bodyController.value = TextEditingValue(
      text: value.text.replaceRange(lineStart, lineEnd, replacement),
      selection: TextSelection(
        baseOffset: lineStart,
        extentOffset: lineStart + replacement.length,
      ),
    );
    _bodyFocus.requestFocus();
  }

  void _insertTemplate(_EditorTemplate template) {
    if (widget.readOnly) return;
    final current = _bodyController.text.trimRight();
    final separator = current.isEmpty ? '' : '\n\n';
    final next = '$current$separator${template.body}';
    _bodyController.value = TextEditingValue(
      text: next,
      selection: TextSelection.collapsed(offset: next.length),
    );
    _bodyFocus.requestFocus();
  }

  int get _wordCount {
    final value = _bodyController.text.trim();
    if (value.isEmpty) return 0;
    return value.split(RegExp(r'\s+')).where((part) => part.isNotEmpty).length;
  }

  Future<void> _copyDocument() async {
    final title = _titleController.text.trim();
    final body = _bodyController.text;
    final value = <String>[title, body].where((part) => part.trim().isNotEmpty).join('\n\n');
    await Clipboard.setData(ClipboardData(text: value));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Текст заметки скопирован')),
    );
  }

  List<_EditorTemplate> get _templates {
    final context = widget.contextLabel.toLowerCase();
    if (context.contains('игрок')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Наблюдение', 'Наблюдение за игроком\n\nСильные стороны\n• \n\nЗона развития\n• \n\nСледующий шаг\n☐ '),
        _EditorTemplate('Личная цель', 'Цель игрока\n\nЧто развиваем\n\nКритерий результата\n\nСрок\n\n☐ Контрольная точка'),
        _EditorTemplate('Обратная связь', 'Обратная связь\n\nЧто получилось\n\nЧто улучшить\n\nДоговорённость с игроком'),
        _EditorTemplate('Итоги периода', 'Итоги периода\n\nПрогресс\n\nНагрузка и готовность\n\nПриоритет следующего периода'),
      ];
    }
    if (context.contains('тренер')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Рабочая запись', 'Рабочая запись тренера\n\nЗадача\n\nРешение\n\n☐ Следующее действие'),
        _EditorTemplate('Методика', 'Методическая заметка\n\nЦель\n\nОрганизация\n\nКлючевые подсказки\n\nВарианты усложнения'),
        _EditorTemplate('Разбор', 'Разбор работы\n\nЧто сработало\n\nЧто изменить\n\nРешение на следующую тренировку'),
        _EditorTemplate('Договорённость', 'Договорённость\n\nУчастники\n\nРешение\n\nСрок\n\n☐ Проверить выполнение'),
      ];
    }
    if (context.contains('команд')) {
      return const <_EditorTemplate>[
        _EditorTemplate('Командная цель', 'Командная цель\n\nФокус\n\nКритерий результата\n\n☐ Следующий шаг'),
        _EditorTemplate('Разбор матча', 'Разбор матча\n\nСильные эпизоды\n\nЧто исправить\n\nФокус микроцикла'),
        _EditorTemplate('План недели', 'План недели\n\nГлавная задача\n\nНагрузка\n\nКонтрольные точки'),
        _EditorTemplate('Собрание', 'Итоги собрания\n\nРешения\n\nОтветственные\n\n☐ Следующая встреча'),
      ];
    }
    return const <_EditorTemplate>[
      _EditorTemplate('Быстрая заметка', 'Кратко\n\nГлавная мысль\n\n☐ Следующее действие'),
      _EditorTemplate('Итоги', 'Итоги\n\nЧто сделано\n\nЧто осталось\n\nСледующий шаг'),
      _EditorTemplate('План', 'Цель\n\nШаги\n☐ \n☐ \n☐ \n\nСрок'),
      _EditorTemplate('Встреча', 'Встреча\n\nУчастники\n\nОбсудили\n\nРешили\n\n☐ Контроль'),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Shortcuts(
      shortcuts: const <ShortcutActivator, Intent>{
        SingleActivator(LogicalKeyboardKey.keyS, meta: true): _SaveIntent(),
        SingleActivator(LogicalKeyboardKey.keyS, control: true): _SaveIntent(),
      },
      child: Actions(
        actions: <Type, Action<Intent>>{
          _SaveIntent: CallbackAction<_SaveIntent>(onInvoke: (_) {
            _save();
            return null;
          }),
        },
        child: Focus(
          autofocus: true,
          child: LayoutBuilder(
            builder: (context, constraints) {
              final compact = constraints.maxWidth < 760;
              final showAside = widget.showTemplates && constraints.maxWidth >= 1040;
              return ColoredBox(
                color: _surface,
                child: Column(
                  children: [
                    _buildHeader(compact: compact),
                    Expanded(
                      child: Row(
                        children: [
                          if (showAside) _buildAside(),
                          Expanded(child: _buildEditor(compact: compact)),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  Widget _buildHeader({required bool compact}) {
    return Container(
      height: compact ? 62 : 68,
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 18),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: _line)),
      ),
      child: Row(
        children: [
          if (widget.onClose != null) ...[
            _EditorHeaderButton(
              icon: SportotekaWorkspaceIconKind.close,
              tooltip: 'Закрыть редактор',
              onTap: _requestClose,
            ),
            const SizedBox(width: 8),
          ],
          const _EditorMosaicMark(size: 26),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('SPORTOTEKA OS', maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.menuGroup(color: _green)),
                if (!compact)
                  Text(
                    widget.contextName.trim().isEmpty ? widget.contextLabel : '${widget.contextLabel} · ${widget.contextName}',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.caption(color: _muted),
                  ),
              ],
            ),
          ),
          _EditorSaveState(
            compact: compact,
            saving: _saving,
            dirty: _dirty,
            failed: _saveError,
            readOnly: widget.readOnly,
          ),
          const SizedBox(width: 6),
          IconButton(
            tooltip: 'Копировать весь текст',
            onPressed: _copyDocument,
            icon: const Icon(Icons.copy_all_rounded, size: 18, color: _muted),
          ),
          if (!widget.readOnly && widget.onSave != null) ...[
            const SizedBox(width: 8),
            FilledButton(
              onPressed: _saving || !_dirty ? null : _save,
              style: FilledButton.styleFrom(
                elevation: 0,
                backgroundColor: _green,
                disabledBackgroundColor: const Color(0xFFDCE5E0),
                padding: EdgeInsets.symmetric(horizontal: compact ? 12 : 16, vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SportotekaWorkspaceIcon(
                    kind: SportotekaWorkspaceIconKind.save,
                    size: 16,
                    color: Colors.white,
                    accentColor: Colors.white,
                  ),
                  if (!compact) ...[
                    const SizedBox(width: 7),
                    Text('Сохранить', style: AppTypography.actionStrong(color: Colors.white)),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAside() {
    return Container(
      width: 246,
      decoration: const BoxDecoration(
        color: Color(0xFFEDF1EE),
        border: Border(right: BorderSide(color: _line)),
      ),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 22, 18, 28),
        children: [
          Text('КОНТЕКСТ', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.72),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(width: 8, height: 8, decoration: const BoxDecoration(color: _green, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(widget.contextLabel, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.menuTitle(color: _text)),
                    ),
                  ],
                ),
                if (widget.contextName.trim().isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(widget.contextName, maxLines: 3, overflow: TextOverflow.ellipsis, style: AppTypography.itemTitle(color: _text)),
                ],
                const SizedBox(height: 9),
                Text(widget.documentType, style: AppTypography.caption(color: _muted)),
              ],
            ),
          ),
          const SizedBox(height: 24),
          Text('БЫСТРЫЙ СТАРТ', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 9),
          for (final template in _templates)
            _EditorTemplateButton(title: template.title, onTap: () => _insertTemplate(template)),
          const SizedBox(height: 22),
          Text('ПОДСКАЗКА', style: AppTypography.menuGroup(color: _muted)),
          const SizedBox(height: 8),
          Text(
            'Выделите текст и примените формат. ⌘S или Ctrl+S сохраняет документ сразу.',
            style: AppTypography.caption(color: _muted).copyWith(height: 1.45),
          ),
        ],
      ),
    );
  }

  Widget _buildEditor({required bool compact}) {
    return Column(
      children: [
        _EditorToolbar(
          compact: compact,
          readOnly: widget.readOnly,
          onBold: () => _wrapSelection('**', '**'),
          onItalic: () => _wrapSelection('_', '_'),
          onHeading: () => _prefixSelection('## '),
          onBullet: () => _prefixSelection('• '),
          onNumbered: () => _prefixSelection('1. '),
          onChecklist: () => _prefixSelection('☐ '),
          onQuote: () => _prefixSelection('> '),
        ),
        if (compact && widget.showTemplates && !widget.readOnly)
          SizedBox(
            height: 48,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
              itemCount: _templates.length,
              separatorBuilder: (_, __) => const SizedBox(width: 7),
              itemBuilder: (_, index) {
                final template = _templates[index];
                return ActionChip(
                  onPressed: () => _insertTemplate(template),
                  backgroundColor: Colors.white,
                  side: BorderSide.none,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
                  label: Text(template.title, style: AppTypography.captionMedium(color: _text)),
                );
              },
            ),
          ),
        Expanded(
          child: SingleChildScrollView(
            padding: EdgeInsets.fromLTRB(
              compact ? 10 : 26,
              compact ? 12 : 22,
              compact ? 10 : 26,
              compact ? 28 : 44,
            ),
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 900),
                child: Container(
                  padding: EdgeInsets.fromLTRB(
                    compact ? 18 : 50,
                    compact ? 22 : 42,
                    compact ? 18 : 50,
                    compact ? 34 : 58,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(compact ? 14 : 18),
                    boxShadow: const <BoxShadow>[
                      BoxShadow(color: Color(0x0E142219), blurRadius: 30, spreadRadius: -8, offset: Offset(0, 12)),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          const _EditorMosaicStrip(),
                          const SizedBox(width: 10),
                          Expanded(child: Text(widget.documentType.toUpperCase(), style: AppTypography.menuGroup(color: _muted))),
                          Text(_todayLabel(), style: AppTypography.caption(color: _muted)),
                        ],
                      ),
                      const SizedBox(height: 20),
                      TextField(
                        controller: _titleController,
                        readOnly: widget.readOnly || widget.titleReadOnly,
                        maxLines: null,
                        decoration: InputDecoration.collapsed(
                          hintText: 'Название заметки',
                          hintStyle: AppTypography.screenTitle(color: const Color(0xFFAAB2AD)).copyWith(fontSize: compact ? 21 : 28),
                        ),
                        style: AppTypography.screenTitle(color: _text).copyWith(fontSize: compact ? 21 : 28, height: 1.16),
                      ),
                      const SizedBox(height: 13),
                      Wrap(
                        spacing: 7,
                        runSpacing: 7,
                        children: [
                          _EditorMetaChip(text: widget.contextLabel),
                          if (widget.contextName.trim().isNotEmpty) _EditorMetaChip(text: widget.contextName),
                          _EditorMetaChip(text: '$_wordCount слов'),
                        ],
                      ),
                      const SizedBox(height: 22),
                      const Divider(height: 1, color: _line),
                      const SizedBox(height: 22),
                      TextField(
                        controller: _bodyController,
                        focusNode: _bodyFocus,
                        readOnly: widget.readOnly,
                        minLines: compact ? 20 : 26,
                        maxLines: null,
                        keyboardType: TextInputType.multiline,
                        textCapitalization: TextCapitalization.sentences,
                        decoration: InputDecoration.collapsed(
                          hintText: 'Начните писать или выберите шаблон заметки…',
                          hintStyle: AppTypography.body(color: const Color(0xFFA2ABA5)).copyWith(fontSize: compact ? 14 : 15, height: 1.62),
                        ),
                        style: AppTypography.body(color: _text).copyWith(fontSize: compact ? 14 : 15, height: 1.62),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        Container(
          height: 31,
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: const BoxDecoration(
            color: Color(0xFFF8F9F8),
            border: Border(top: BorderSide(color: _line)),
          ),
          child: Row(
            children: [
              Text('$_wordCount слов · ${_bodyController.text.length} знаков', style: AppTypography.caption(color: _muted)),
              const Spacer(),
              if (!compact)
                Text(
                  widget.autoSave && widget.onSave != null ? 'Автосохранение включено' : 'Сохранение вручную',
                  style: AppTypography.caption(color: _muted),
                ),
            ],
          ),
        ),
      ],
    );
  }

  String _todayLabel() {
    final now = DateTime.now();
    String two(int value) => value.toString().padLeft(2, '0');
    return '${two(now.day)}.${two(now.month)}.${now.year}';
  }
}

class _EditorToolbar extends StatelessWidget {
  const _EditorToolbar({
    required this.compact,
    required this.readOnly,
    required this.onBold,
    required this.onItalic,
    required this.onHeading,
    required this.onBullet,
    required this.onNumbered,
    required this.onChecklist,
    required this.onQuote,
  });

  final bool compact;
  final bool readOnly;
  final VoidCallback onBold;
  final VoidCallback onItalic;
  final VoidCallback onHeading;
  final VoidCallback onBullet;
  final VoidCallback onNumbered;
  final VoidCallback onChecklist;
  final VoidCallback onQuote;

  @override
  Widget build(BuildContext context) {
    final actions = <Widget>[
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.heading, tooltip: 'Заголовок', onTap: onHeading),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.bold, tooltip: 'Жирный', onTap: onBold),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.italic, tooltip: 'Курсив', onTap: onItalic),
      const _EditorToolDivider(),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.bullets, tooltip: 'Список', onTap: onBullet),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.numbered, tooltip: 'Нумерованный список', onTap: onNumbered),
      _EditorTextToolButton(label: '☐', tooltip: 'Задача', onTap: onChecklist),
      _EditorToolButton(icon: SportotekaWorkspaceIconKind.quote, tooltip: 'Цитата', onTap: onQuote),
    ];

    return IgnorePointer(
      ignoring: readOnly,
      child: Opacity(
        opacity: readOnly ? .48 : 1,
        child: Container(
          height: compact ? 49 : 54,
          decoration: const BoxDecoration(
            color: Color(0xFFF8F9F8),
            border: Border(bottom: BorderSide(color: _WorkspaceDocumentEditorState._line)),
          ),
          child: Row(
            children: [
              if (!compact) ...[
                const SizedBox(width: 16),
                Text('ФОРМАТ', style: AppTypography.menuGroup(color: _WorkspaceDocumentEditorState._muted)),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: EdgeInsets.symmetric(horizontal: compact ? 7 : 0, vertical: 5),
                  children: actions,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _EditorToolButton extends StatelessWidget {
  const _EditorToolButton({required this.icon, required this.tooltip, required this.onTap});

  final SportotekaWorkspaceIconKind icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(child: SportotekaWorkspaceIcon(kind: icon, size: 19)),
        ),
      ),
    );
  }
}

class _EditorTextToolButton extends StatelessWidget {
  const _EditorTextToolButton({required this.label, required this.tooltip, required this.onTap});

  final String label;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(child: Text(label, style: AppTypography.itemTitle(color: const Color(0xFF29332D)))),
        ),
      ),
    );
  }
}

class _EditorToolDivider extends StatelessWidget {
  const _EditorToolDivider();

  @override
  Widget build(BuildContext context) {
    return const Padding(
      padding: EdgeInsets.symmetric(horizontal: 5, vertical: 8),
      child: VerticalDivider(width: 1, thickness: 1, color: Color(0xFFE0E5E1)),
    );
  }
}

class _EditorHeaderButton extends StatelessWidget {
  const _EditorHeaderButton({required this.icon, required this.tooltip, required this.onTap});

  final SportotekaWorkspaceIconKind icon;
  final String tooltip;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: SizedBox.square(
          dimension: 40,
          child: Center(child: SportotekaWorkspaceIcon(kind: icon, size: 19)),
        ),
      ),
    );
  }
}

class _EditorSaveState extends StatelessWidget {
  const _EditorSaveState({required this.compact, required this.saving, required this.dirty, required this.failed, required this.readOnly});

  final bool compact;
  final bool saving;
  final bool dirty;
  final bool failed;
  final bool readOnly;

  @override
  Widget build(BuildContext context) {
    final color = failed
        ? const Color(0xFFB04444)
        : dirty || saving
            ? const Color(0xFF9B7420)
            : const Color(0xFF0B8F55);
    final text = readOnly
        ? 'Только чтение'
        : failed
            ? 'Ошибка сохранения'
            : saving
                ? 'Сохраняется'
                : dirty
                    ? 'Есть изменения'
                    : 'Сохранено';

    if (compact) {
      return Container(width: 8, height: 8, decoration: BoxDecoration(color: color, shape: BoxShape.circle));
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(color: color.withOpacity(.09), borderRadius: BorderRadius.circular(999)),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(width: 6, height: 6, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          Text(text, style: AppTypography.captionMedium(color: color)),
        ],
      ),
    );
  }
}

class _EditorTemplateButton extends StatelessWidget {
  const _EditorTemplateButton({required this.title, required this.onTap});

  final String title;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Material(
        color: Colors.white.withOpacity(.68),
        borderRadius: BorderRadius.circular(10),
        child: InkWell(
          borderRadius: BorderRadius.circular(10),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 10),
            child: Row(
              children: [
                const _EditorMosaicStrip(compact: true),
                const SizedBox(width: 9),
                Expanded(child: Text(title, style: AppTypography.menuTitle(color: const Color(0xFF263129)))),
                const SportotekaWorkspaceIcon(kind: SportotekaWorkspaceIconKind.chevronRight, size: 15, color: Color(0xFF78837C)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorMetaChip extends StatelessWidget {
  const _EditorMetaChip({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(maxWidth: 250),
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
      decoration: BoxDecoration(color: const Color(0xFFF0F4F1), borderRadius: BorderRadius.circular(999)),
      child: Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: AppTypography.caption(color: const Color(0xFF637068)),
      ),
    );
  }
}

class _EditorMosaicMark extends StatelessWidget {
  const _EditorMosaicMark({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    final dot = size * .18;
    return SizedBox.square(
      dimension: size,
      child: Wrap(
        alignment: WrapAlignment.center,
        runAlignment: WrapAlignment.center,
        spacing: size * .10,
        runSpacing: size * .10,
        children: List<Widget>.generate(9, (index) {
          const colors = <Color>[
            Color(0xFFC4DED0), Color(0xFF8FC2A6), Color(0xFFDCECE3),
            Color(0xFF75B492), Color(0xFF0B8F55), Color(0xFFAED3BF),
            Color(0xFFD5E8DD), Color(0xFF66AA86), Color(0xFFBADBC9),
          ];
          return Container(
            width: dot,
            height: dot,
            decoration: BoxDecoration(color: colors[index], shape: BoxShape.circle),
          );
        }),
      ),
    );
  }
}

class _EditorMosaicStrip extends StatelessWidget {
  const _EditorMosaicStrip({this.compact = false});

  final bool compact;

  @override
  Widget build(BuildContext context) {
    final size = compact ? 4.0 : 5.0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List<Widget>.generate(
        3,
        (index) => Padding(
          padding: EdgeInsets.only(left: index == 0 ? 0 : 4),
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: index == 1 ? const Color(0xFF0B8F55) : const Color(0xFFAED3BF),
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class _EditorTemplate {
  const _EditorTemplate(this.title, this.body);

  final String title;
  final String body;
}

class _SaveIntent extends Intent {
  const _SaveIntent();
}
