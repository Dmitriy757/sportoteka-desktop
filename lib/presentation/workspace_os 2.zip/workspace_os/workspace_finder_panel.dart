import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:sportoteka/core/theme/app_typography.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_document_editor.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_finder_models.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_player_project_screen.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_team_project_screen.dart';
import 'package:sportoteka/presentation/workspace_os/workspace_trainer_project_screen.dart';
import 'package:sportoteka/presentation/workspace_os/sportoteka_workspace_icons.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SportotekaWorkspaceFinderPanel extends StatefulWidget {
  const SportotekaWorkspaceFinderPanel({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teams,
    required this.players,
    required this.trainers,
    required this.onOpenModule,
    required this.onOpenPlayer,
    required this.onOpenTeam,
    required this.onOpenTrainer,
    this.selectedTeamId,
    this.selectedTeamName = '',
    this.onRefresh,
    this.onMoveEntity,
  });

  final int clubId;
  final String clubName;
  final List<Map<String, dynamic>> teams;
  final List<Map<String, dynamic>> players;
  final List<Map<String, dynamic>> trainers;
  final int? selectedTeamId;
  final String selectedTeamName;
  final ValueChanged<String> onOpenModule;
  final ValueChanged<Map<String, dynamic>> onOpenPlayer;
  final ValueChanged<Map<String, dynamic>> onOpenTeam;
  final ValueChanged<Map<String, dynamic>> onOpenTrainer;
  final Future<void> Function()? onRefresh;
  final Future<bool> Function(
    WorkspaceFinderNode source,
    WorkspaceFinderNode target,
  )? onMoveEntity;

  @override
  State<SportotekaWorkspaceFinderPanel> createState() =>
      _SportotekaWorkspaceFinderPanelState();
}

class _SportotekaWorkspaceFinderPanelState
    extends State<SportotekaWorkspaceFinderPanel> {
  static const _green = Color(0xFF0B8F55);
  static const _bg = Color(0xFFF7F8F7);
  static const _line = Color(0xFFE5E8E5);
  static const _text = Color(0xFF101814);
  static const _muted = Color(0xFF758079);

  WorkspaceFinderViewMode _viewMode = WorkspaceFinderViewMode.grid;
  String _folderKey = 'home';
  String _search = '';
  String? _selectedNodeId;
  WorkspaceFinderNode? _clipboardNode;
  bool _showSidebarOnCompact = false;

  final List<String> _recentIds = <String>[];
  final Set<String> _favoriteIds = <String>{};
  final Map<String, List<WorkspaceFinderNode>> _localChildren =
      <String, List<WorkspaceFinderNode>>{};
  final Map<String, String> _noteBodies = <String, String>{};

  String get _storageKey => 'sportoteka_finder_v1_${widget.clubId}';

  @override
  void initState() {
    super.initState();
    _loadLocalWorkspace();
  }

  Future<void> _loadLocalWorkspace() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.trim().isEmpty) return;
      final decoded = jsonDecode(raw);
      if (decoded is! Map) return;

      final foldersRaw = decoded['localChildren'];
      final loadedChildren = <String, List<WorkspaceFinderNode>>{};
      if (foldersRaw is Map) {
        for (final entry in foldersRaw.entries) {
          final value = entry.value;
          if (value is! List) continue;
          loadedChildren['${entry.key}'] = value
              .whereType<Map>()
              .map((item) => _nodeFromJson(Map<String, dynamic>.from(item)))
              .whereType<WorkspaceFinderNode>()
              .toList();
        }
      }

      final notesRaw = decoded['noteBodies'];
      final loadedNotes = <String, String>{};
      if (notesRaw is Map) {
        for (final entry in notesRaw.entries) {
          loadedNotes['${entry.key}'] = '${entry.value ?? ''}';
        }
      }

      final favoriteRaw = decoded['favorites'];
      final recentRaw = decoded['recent'];
      final viewRaw = '${decoded['viewMode'] ?? ''}';
      if (!mounted) return;
      setState(() {
        _localChildren
          ..clear()
          ..addAll(loadedChildren);
        _noteBodies
          ..clear()
          ..addAll(loadedNotes);
        _favoriteIds
          ..clear()
          ..addAll(favoriteRaw is List ? favoriteRaw.map((e) => '$e') : const <String>[]);
        _recentIds
          ..clear()
          ..addAll(recentRaw is List ? recentRaw.map((e) => '$e') : const <String>[]);
        _viewMode = WorkspaceFinderViewMode.grid;
      });
    } catch (_) {
      // Повреждённое локальное состояние не должно ломать Спортотека OS.
    }
  }

  Map<String, dynamic> _nodeToJson(WorkspaceFinderNode node) => <String, dynamic>{
        'id': node.id,
        'title': node.title,
        'subtitle': node.subtitle,
        'kind': node.kind.name,
        'moduleKey': node.moduleKey,
        'payload': node.payload,
        'parentId': node.parentId,
        'isSystem': node.isSystem,
        'isFavorite': node.isFavorite,
        'isShortcut': node.isShortcut,
        'createdAt': node.createdAt?.toIso8601String(),
        'updatedAt': node.updatedAt?.toIso8601String(),
      };

  WorkspaceFinderNode? _nodeFromJson(Map<String, dynamic> json) {
    final id = '${json['id'] ?? ''}'.trim();
    final title = '${json['title'] ?? ''}'.trim();
    if (id.isEmpty || title.isEmpty) return null;
    final kindName = '${json['kind'] ?? ''}';
    final kind = WorkspaceFinderNodeKind.values.firstWhere(
      (item) => item.name == kindName,
      orElse: () => WorkspaceFinderNodeKind.shortcut,
    );
    final payloadRaw = json['payload'];
    return WorkspaceFinderNode(
      id: id,
      title: title,
      subtitle: '${json['subtitle'] ?? ''}',
      kind: kind,
      moduleKey: json['moduleKey'] == null ? null : '${json['moduleKey']}',
      payload: payloadRaw is Map ? Map<String, dynamic>.from(payloadRaw) : null,
      parentId: json['parentId'] == null ? null : '${json['parentId']}',
      isSystem: json['isSystem'] == true,
      isFavorite: json['isFavorite'] == true,
      isShortcut: json['isShortcut'] == true,
      createdAt: DateTime.tryParse('${json['createdAt'] ?? ''}'),
      updatedAt: DateTime.tryParse('${json['updatedAt'] ?? ''}'),
    );
  }

  Future<void> _persistLocalWorkspace() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final data = <String, dynamic>{
        'localChildren': <String, dynamic>{
          for (final entry in _localChildren.entries)
            entry.key: entry.value.map(_nodeToJson).toList(),
        },
        'noteBodies': _noteBodies,
        'favorites': _favoriteIds.toList(),
        'recent': _recentIds,
        'viewMode': _viewMode.name,
      };
      await prefs.setString(_storageKey, jsonEncode(data));
    } catch (_) {
      // Локальное сохранение не должно блокировать основные данные клуба.
    }
  }

  String _nodeId(String prefix, Map<String, dynamic> payload, int index) {
    final raw = payload['id'] ??
        payload['player_id'] ??
        payload['trainer_id'] ??
        payload['team_id'] ??
        payload['user_id'] ??
        payload['email'] ??
        payload['name'] ??
        index;
    return '$prefix:$raw';
  }

  String _teamTitle(Map<String, dynamic> team) {
    return '${team['name'] ?? team['team_name'] ?? team['title'] ?? 'Команда'}'
        .trim();
  }

  String _playerTitle(Map<String, dynamic> player) {
    final last = '${player['last_name'] ?? player['lastname'] ?? ''}'.trim();
    final first = '${player['first_name'] ?? player['firstname'] ?? ''}'.trim();
    final full = '${player['full_name'] ?? player['fullName'] ?? player['name'] ?? ''}'
        .trim();
    final joined = [last, first].where((e) => e.isNotEmpty).join(' ').trim();
    return joined.isNotEmpty ? joined : (full.isNotEmpty ? full : 'Игрок');
  }

  String _trainerTitle(Map<String, dynamic> trainer) {
    final last = '${trainer['last_name'] ?? trainer['lastname'] ?? ''}'.trim();
    final first = '${trainer['first_name'] ?? trainer['firstname'] ?? ''}'.trim();
    final full = '${trainer['full_name'] ?? trainer['fullName'] ?? trainer['name'] ?? ''}'
        .trim();
    final joined = [last, first].where((e) => e.isNotEmpty).join(' ').trim();
    return joined.isNotEmpty ? joined : (full.isNotEmpty ? full : 'Тренер');
  }

  List<WorkspaceFinderNode> get _rootNodes {
    return kWorkspaceFinderModules
        .map(
          (module) => WorkspaceFinderNode(
            id: 'module:${module.key}',
            title: module.title,
            subtitle: module.subtitle,
            kind: WorkspaceFinderNodeKind.folder,
            moduleKey: module.key,
            isSystem: true,
          ),
        )
        .toList(growable: false);
  }

  List<WorkspaceFinderNode> _teamNodes() {
    return List<WorkspaceFinderNode>.generate(widget.teams.length, (index) {
      final team = widget.teams[index];
      final title = _teamTitle(team);
      final stage = '${team['age_group'] ?? team['stage'] ?? team['category'] ?? ''}'
          .trim();
      return WorkspaceFinderNode(
        id: _nodeId('team', team, index),
        title: title,
        subtitle: stage.isEmpty ? 'Команда клуба' : stage,
        kind: WorkspaceFinderNodeKind.team,
        moduleKey: 'teams',
        payload: Map<String, dynamic>.from(team),
        isSystem: true,
      );
    });
  }

  List<WorkspaceFinderNode> _playerNodes() {
    return List<WorkspaceFinderNode>.generate(widget.players.length, (index) {
      final player = widget.players[index];
      final number = '${player['number'] ?? player['shirt_number'] ?? ''}'.trim();
      final subtitleParts = <String>[
        if (widget.selectedTeamName.trim().isNotEmpty) widget.selectedTeamName.trim(),
        if (number.isNotEmpty) '№$number',
      ];
      return WorkspaceFinderNode(
        id: _nodeId('player', player, index),
        title: _playerTitle(player),
        subtitle: subtitleParts.isEmpty ? 'Игрок' : subtitleParts.join(' · '),
        kind: WorkspaceFinderNodeKind.player,
        moduleKey: 'players',
        payload: Map<String, dynamic>.from(player),
        isSystem: true,
      );
    });
  }

  List<WorkspaceFinderNode> _trainerNodes() {
    return List<WorkspaceFinderNode>.generate(widget.trainers.length, (index) {
      final trainer = widget.trainers[index];
      final role = '${trainer['role'] ?? trainer['position'] ?? trainer['specialization'] ?? ''}'
          .trim();
      return WorkspaceFinderNode(
        id: _nodeId('trainer', trainer, index),
        title: _trainerTitle(trainer),
        subtitle: role.isEmpty ? 'Тренер' : role,
        kind: WorkspaceFinderNodeKind.trainer,
        moduleKey: 'trainers',
        payload: Map<String, dynamic>.from(trainer),
        isSystem: true,
      );
    });
  }

  WorkspaceFinderModuleDefinition? _moduleFor(String key) {
    for (final module in kWorkspaceFinderModules) {
      if (module.key == key) return module;
    }
    return null;
  }

  List<WorkspaceFinderNode> _smartModuleNodes(String key) {
    WorkspaceFinderNode link(
      String id,
      String title,
      String subtitle,
      WorkspaceFinderNodeKind kind,
      String moduleKey,
    ) =>
        WorkspaceFinderNode(
          id: 'smart:$key:$id',
          title: title,
          subtitle: subtitle,
          kind: kind,
          moduleKey: moduleKey,
          isSystem: true,
        );

    switch (key) {
      case 'trainings':
        return <WorkspaceFinderNode>[
          link('calendar', 'Календарь тренировок', 'Расписание и события', WorkspaceFinderNodeKind.calendar, 'calendar'),
          link('plans', 'Планы-конспекты', 'Упражнения и методические материалы', WorkspaceFinderNodeKind.plan, 'plans'),
          link('attendance', 'Посещаемость', 'Журнал тренировок', WorkspaceFinderNodeKind.training, 'attendance'),
          link('tracker', 'Tracker Live', 'GPS и нагрузка на тренировке', WorkspaceFinderNodeKind.tracker, 'tracker'),
        ];
      case 'video':
        return <WorkspaceFinderNode>[
          link('analysis', 'Видеоанализ матчей', 'Разбор, эпизоды и AI', WorkspaceFinderNodeKind.video, 'videoAnalysis'),
          link('lessons', 'Видеоуроки', 'Методическая видеотека клуба', WorkspaceFinderNodeKind.video, 'videoLessons'),
        ];
      case 'reports':
        return <WorkspaceFinderNode>[
          link('tracker', 'Tracker отчёты', 'GPS, ЧСС, нагрузка и карты', WorkspaceFinderNodeKind.report, 'tracker'),
          link('testing', 'Отчёты тестирования', 'Динамика и результаты тестов', WorkspaceFinderNodeKind.testing, 'testing'),
          link('attendance', 'Посещаемость', 'Журнал и выгрузка', WorkspaceFinderNodeKind.report, 'attendance'),
        ];
      case 'documents':
        return <WorkspaceFinderNode>[
          link('players', 'Документы игроков', 'Карточки и личные документы', WorkspaceFinderNodeKind.document, 'players'),
          link('trainers', 'Документы тренеров', 'Профили и HR-документы', WorkspaceFinderNodeKind.document, 'trainers'),
          link('medical', 'Медицинские документы', 'Медкарта игроков', WorkspaceFinderNodeKind.medical, 'medical'),
        ];
      default:
        return const <WorkspaceFinderNode>[];
    }
  }

  List<WorkspaceFinderNode> _nodesForCurrentFolder() {
    List<WorkspaceFinderNode> nodes;
    switch (_folderKey) {
      case 'home':
        nodes = _rootNodes;
        break;
      case 'teams':
        nodes = _teamNodes();
        break;
      case 'players':
        nodes = _playerNodes();
        break;
      case 'trainers':
        nodes = _trainerNodes();
        break;
      case 'favorites':
        nodes = _allKnownNodes()
            .where((node) => _favoriteIds.contains(node.id))
            .toList();
        break;
      case 'recent':
        final all = <String, WorkspaceFinderNode>{
          for (final node in _allKnownNodes()) node.id: node,
        };
        nodes = _recentIds
            .map((id) => all[id])
            .whereType<WorkspaceFinderNode>()
            .toList();
        break;
      default:
        nodes = <WorkspaceFinderNode>[
          ..._smartModuleNodes(_folderKey),
          ...?_localChildren[_folderKey],
        ];
        break;
    }

    final local = _localChildren[_folderKey];
    if (local != null && _folderKey != 'home' && _folderKey != 'favorites' && _folderKey != 'recent') {
      final known = nodes.map((e) => e.id).toSet();
      nodes.addAll(local.where((node) => !known.contains(node.id)));
    }

    if (_folderKey != 'home' &&
        _folderKey != 'teams' &&
        _folderKey != 'players' &&
        _folderKey != 'trainers' &&
        _folderKey != 'favorites' &&
        _folderKey != 'recent' &&
        !_folderKey.startsWith('local-folder:')) {
      final module = _moduleFor(_folderKey);
      if (module != null && _smartModuleNodes(_folderKey).isEmpty) {
        nodes = <WorkspaceFinderNode>[
          WorkspaceFinderNode(
            id: 'open-module:${module.key}',
            title: 'Открыть ${module.title}',
            subtitle: module.subtitle,
            kind: module.kind,
            moduleKey: module.key,
            isSystem: true,
          ),
          ...nodes,
        ];
      }
    }

    final query = _search.trim().toLowerCase();
    if (query.isNotEmpty) {
      nodes = nodes
          .where((node) =>
              node.title.toLowerCase().contains(query) ||
              node.subtitle.toLowerCase().contains(query))
          .toList();
    }

    nodes.sort((a, b) {
      if (a.isFolder != b.isFolder) return a.isFolder ? -1 : 1;
      return a.title.toLowerCase().compareTo(b.title.toLowerCase());
    });
    return nodes;
  }

  List<WorkspaceFinderNode> _allKnownNodes() {
    return <WorkspaceFinderNode>[
      ..._rootNodes,
      ..._teamNodes(),
      ..._playerNodes(),
      ..._trainerNodes(),
      for (final list in _localChildren.values) ...list,
    ];
  }

  void _rememberRecent(WorkspaceFinderNode node) {
    _recentIds.remove(node.id);
    _recentIds.insert(0, node.id);
    if (_recentIds.length > 24) _recentIds.removeLast();
    _persistLocalWorkspace();
  }

  Future<void> _openNode(WorkspaceFinderNode node) async {
    setState(() {
      _selectedNodeId = node.id;
      _rememberRecent(node);
    });

    if (node.isFolder && node.moduleKey != null) {
      setState(() {
        _folderKey = node.moduleKey!;
        _search = '';
        _selectedNodeId = null;
      });
      return;
    }

    if (node.isFolder && node.id.startsWith('local-folder:')) {
      setState(() {
        _folderKey = node.id;
        _search = '';
        _selectedNodeId = null;
      });
      return;
    }

    switch (node.kind) {
      case WorkspaceFinderNodeKind.player:
        if (node.payload != null) await _openPlayerProject(node.payload!);
        return;
      case WorkspaceFinderNodeKind.team:
        if (node.payload != null) await _openTeamProject(node.payload!);
        return;
      case WorkspaceFinderNodeKind.trainer:
        if (node.payload != null) await _openTrainerProject(node.payload!);
        return;
      case WorkspaceFinderNodeKind.note:
        _openNote(node);
        return;
      default:
        if (node.moduleKey != null) widget.onOpenModule(node.moduleKey!);
    }
  }

  Future<void> _openPlayerProject(Map<String, dynamic> rawPlayer) async {
    final player = Map<String, dynamic>.from(rawPlayer);
    player['club_id'] ??= widget.clubId;
    player['clubId'] ??= widget.clubId;
    player['team_id'] ??= player['teamId'] ?? widget.selectedTeamId;
    player['teamId'] ??= player['team_id'] ?? widget.selectedTeamId;
    player['team_name'] ??= widget.selectedTeamName;
    player['teamName'] ??= widget.selectedTeamName;

    final project = SportotekaPlayerProjectScreen(
      player: player,
      clubId: widget.clubId,
      teamId: widget.selectedTeamId,
      teamName: widget.selectedTeamName,
      onRefresh: widget.onRefresh,
    );

    final width = MediaQuery.sizeOf(context).width;
    if (width < 760) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            backgroundColor: Colors.white,
            body: SafeArea(child: project),
          ),
        ),
      );
      return;
    }

    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(.16),
      builder: (dialogContext) {
        final size = MediaQuery.sizeOf(dialogContext);
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.symmetric(
            horizontal: size.width >= 1280 ? 54 : 24,
            vertical: size.height >= 850 ? 34 : 18,
          ),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1160, maxHeight: 850),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Material(color: Colors.white, child: project),
            ),
          ),
        );
      },
    );
  }


  Future<void> _openTeamProject(Map<String, dynamic> rawTeam) async {
    final project = SportotekaTeamProjectScreen(
      team: Map<String, dynamic>.from(rawTeam),
      clubId: widget.clubId,
      players: widget.players,
      onRefresh: widget.onRefresh,
      onOpenModule: widget.onOpenModule,
    );
    await _openProjectSurface(project, maxWidth: 1180, maxHeight: 860);
  }

  Future<void> _openTrainerProject(Map<String, dynamic> rawTrainer) async {
    final project = SportotekaTrainerProjectScreen(
      trainer: Map<String, dynamic>.from(rawTrainer),
      clubId: widget.clubId,
      teams: widget.teams,
      players: widget.players,
      onRefresh: widget.onRefresh,
    );
    await _openProjectSurface(project, maxWidth: 1180, maxHeight: 860);
  }

  Future<void> _openProjectSurface(
    Widget project, {
    required double maxWidth,
    required double maxHeight,
  }) async {
    final width = MediaQuery.sizeOf(context).width;
    if (width < 760) {
      await Navigator.of(context).push<void>(
        MaterialPageRoute<void>(
          builder: (_) => Scaffold(
            backgroundColor: Colors.white,
            body: SafeArea(child: project),
          ),
        ),
      );
      return;
    }

    await showDialog<void>(
      context: context,
      barrierColor: Colors.black.withOpacity(.16),
      builder: (dialogContext) {
        final size = MediaQuery.sizeOf(dialogContext);
        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: EdgeInsets.symmetric(
            horizontal: size.width >= 1280 ? 54 : 24,
            vertical: size.height >= 850 ? 34 : 18,
          ),
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxWidth, maxHeight: maxHeight),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Material(color: Colors.white, child: project),
            ),
          ),
        );
      },
    );
  }

  void _goHome() {
    setState(() {
      _folderKey = 'home';
      _search = '';
      _selectedNodeId = null;
    });
  }

  String get _currentTitle {
    if (_folderKey == 'home') return widget.clubName.trim().isEmpty ? 'SPORTOTEKA' : widget.clubName;
    if (_folderKey == 'favorites') return 'Избранное';
    if (_folderKey == 'recent') return 'Недавние';
    final module = _moduleFor(_folderKey);
    if (module != null) return module.title;
    for (final node in _allKnownNodes()) {
      if (node.id == _folderKey) return node.title;
    }
    return 'Папка';
  }

  List<String> get _breadcrumbs {
    if (_folderKey == 'home') return <String>['Клуб'];
    return <String>['Клуб', _currentTitle];
  }

  Future<void> _createFolder() async {
    final controller = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Новая папка', style: AppTypography.sectionTitle()),
        content: TextField(
          controller: controller,
          autofocus: true,
          decoration: InputDecoration(
            hintText: 'Название папки',
            hintStyle: AppTypography.formHint(),
          ),
          style: AppTypography.formText(),
          onSubmitted: (value) => Navigator.of(context).pop(value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Отмена', style: AppTypography.action()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(controller.text.trim()),
            child: Text('Создать', style: AppTypography.actionStrong(color: Colors.white)),
          ),
        ],
      ),
    );
    controller.dispose();
    if (name == null || name.isEmpty || !mounted) return;

    final id = 'local-folder:${DateTime.now().microsecondsSinceEpoch}';
    final node = WorkspaceFinderNode(
      id: id,
      title: name,
      subtitle: 'Папка Спортотека OS',
      kind: WorkspaceFinderNodeKind.folder,
      parentId: _folderKey,
      createdAt: DateTime.now(),
    );
    setState(() {
      (_localChildren[_folderKey] ??= <WorkspaceFinderNode>[]).add(node);
    });
    _persistLocalWorkspace();
  }

  Future<void> _createNote() async {
    final id = 'note:${DateTime.now().microsecondsSinceEpoch}';
    final node = WorkspaceFinderNode(
      id: id,
      title: 'Новый документ',
      subtitle: 'Заметка Спортотека OS',
      kind: WorkspaceFinderNodeKind.note,
      parentId: _folderKey,
      createdAt: DateTime.now(),
    );
    setState(() {
      (_localChildren[_folderKey] ??= <WorkspaceFinderNode>[]).add(node);
      _noteBodies[id] = '';
    });
    _persistLocalWorkspace();
    _openNote(node);
  }

  Future<void> _openNote(WorkspaceFinderNode node) async {
    final currentBody = _noteBodies[node.id] ?? '';
    final localNode = _findLocalNode(node.id);
    final initialTitle = localNode?.title ?? node.title;

    Future<void> save(String title, String body) async {
      setState(() {
        _noteBodies[node.id] = body;
        _replaceLocalNode(
          node.id,
          (old) => old.copyWith(
            title: title.isEmpty ? 'Без названия' : title,
            updatedAt: DateTime.now(),
          ),
        );
      });
      await _persistLocalWorkspace();
    }

    await Navigator.of(context).push<void>(
      PageRouteBuilder<void>(
        transitionDuration: const Duration(milliseconds: 300),
        reverseTransitionDuration: const Duration(milliseconds: 220),
        pageBuilder: (routeContext, animation, secondaryAnimation) {
          return Scaffold(
            backgroundColor: _bg,
            body: SafeArea(
              child: WorkspaceDocumentEditor(
                initialTitle: initialTitle,
                initialBody: currentBody,
                contextLabel: _editorContextLabel,
                contextName: _editorContextName,
                documentType: 'Заметка',
                onSave: save,
                onClose: () => Navigator.of(routeContext).pop(),
              ),
            ),
          );
        },
        transitionsBuilder: (context, animation, secondaryAnimation, child) {
          final curved = CurvedAnimation(
            parent: animation,
            curve: Curves.easeOutCubic,
            reverseCurve: Curves.easeInCubic,
          );
          return FadeTransition(
            opacity: curved,
            child: SlideTransition(
              position: Tween<Offset>(
                begin: const Offset(.055, .018),
                end: Offset.zero,
              ).animate(curved),
              child: child,
            ),
          );
        },
      ),
    );
  }

  String get _editorContextLabel {
    switch (_folderKey) {
      case 'players':
        return 'Игрок';
      case 'trainers':
        return 'Тренер';
      case 'teams':
        return 'Команда';
      case 'trainings':
        return 'Тренировка';
      case 'matches':
        return 'Матч';
      default:
        return 'Пространство клуба';
    }
  }

  String get _editorContextName {
    if (_folderKey == 'home') return widget.clubName;
    return _currentTitle;
  }

  WorkspaceFinderNode? _findLocalNode(String id) {
    for (final list in _localChildren.values) {
      for (final node in list) {
        if (node.id == id) return node;
      }
    }
    return null;
  }

  void _replaceLocalNode(
    String id,
    WorkspaceFinderNode Function(WorkspaceFinderNode old) transform,
  ) {
    for (final entry in _localChildren.entries) {
      final index = entry.value.indexWhere((node) => node.id == id);
      if (index >= 0) {
        entry.value[index] = transform(entry.value[index]);
        return;
      }
    }
  }

  void _deleteLocalNode(WorkspaceFinderNode node) {
    setState(() {
      for (final list in _localChildren.values) {
        list.removeWhere((item) => item.id == node.id);
      }
      _localChildren.remove(node.id);
      _noteBodies.remove(node.id);
      _favoriteIds.remove(node.id);
      _recentIds.remove(node.id);
      if (_selectedNodeId == node.id) _selectedNodeId = null;
    });
    _persistLocalWorkspace();
  }

  Future<void> _renameLocalNode(WorkspaceFinderNode node) async {
    if (node.isSystem) return;
    final controller = TextEditingController(text: node.title);
    final value = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Переименовать', style: AppTypography.sectionTitle()),
        content: TextField(
          controller: controller,
          autofocus: true,
          style: AppTypography.formText(),
          onSubmitted: (value) => Navigator.of(context).pop(value.trim()),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('Отмена', style: AppTypography.action()),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(controller.text.trim()),
            child: Text('Готово', style: AppTypography.actionStrong(color: Colors.white)),
          ),
        ],
      ),
    );
    controller.dispose();
    if (value == null || value.isEmpty || !mounted) return;
    setState(() => _replaceLocalNode(node.id, (old) => old.copyWith(title: value)));
    _persistLocalWorkspace();
  }

  void _copyNode(WorkspaceFinderNode node) {
    setState(() => _clipboardNode = node);
    Clipboard.setData(ClipboardData(text: node.title));
    _showSnack('«${node.title}» скопирован. В Спортотека OS он вставляется как ярлык.');
  }

  void _pasteShortcut() {
    final source = _clipboardNode;
    if (source == null) return;
    final now = DateTime.now();
    final shortcut = WorkspaceFinderNode(
      id: 'shortcut:${now.microsecondsSinceEpoch}',
      title: source.title,
      subtitle: source.subtitle.isEmpty ? 'Ярлык' : '${source.subtitle} · ярлык',
      kind: source.kind,
      moduleKey: source.moduleKey,
      payload: source.payload,
      parentId: _folderKey,
      isShortcut: true,
      createdAt: now,
    );
    setState(() {
      (_localChildren[_folderKey] ??= <WorkspaceFinderNode>[]).add(shortcut);
    });
    _persistLocalWorkspace();
  }

  Future<void> _dropNode(WorkspaceFinderNode source, WorkspaceFinderNode target) async {
    if (!(target.isFolder || target.kind == WorkspaceFinderNodeKind.team) || source.id == target.id) return;

    if (!target.isSystem && target.id.startsWith('local-folder:')) {
      final shortcut = WorkspaceFinderNode(
        id: 'shortcut:${DateTime.now().microsecondsSinceEpoch}',
        title: source.title,
        subtitle: source.subtitle.isEmpty ? 'Ярлык' : '${source.subtitle} · ярлык',
        kind: source.kind,
        moduleKey: source.moduleKey,
        payload: source.payload,
        parentId: target.id,
        isShortcut: true,
        createdAt: DateTime.now(),
      );
      setState(() {
        (_localChildren[target.id] ??= <WorkspaceFinderNode>[]).add(shortcut);
      });
      _persistLocalWorkspace();
      _showSnack('Создан ярлык в папке «${target.title}».');
      return;
    }

    if (widget.onMoveEntity != null) {
      final ok = await widget.onMoveEntity!(source, target);
      if (ok && mounted) {
        _showSnack('Изменение применено к данным клуба.');
        await widget.onRefresh?.call();
      }
      return;
    }

    _showSnack('Для системных папок перенос изменяет реальные данные. Подключение операции выполняется через API раздела.');
  }

  void _showSnack(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, style: AppTypography.body(color: Colors.white)),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  Future<void> _showNodeMenu(WorkspaceFinderNode node, Offset position) async {
    final action = await showMenu<String>(
      context: context,
      position: RelativeRect.fromLTRB(position.dx, position.dy, position.dx, position.dy),
      items: <PopupMenuEntry<String>>[
        PopupMenuItem(value: 'open', child: Text('Открыть', style: AppTypography.menuTitle())),
        PopupMenuItem(value: 'copy', child: Text('Копировать', style: AppTypography.menuTitle())),
        PopupMenuItem(
          value: 'favorite',
          child: Text(
            _favoriteIds.contains(node.id) ? 'Убрать из избранного' : 'В избранное',
            style: AppTypography.menuTitle(),
          ),
        ),
        if (!node.isSystem)
          PopupMenuItem(value: 'rename', child: Text('Переименовать', style: AppTypography.menuTitle())),
        if (!node.isSystem)
          PopupMenuItem(value: 'delete', child: Text('Удалить', style: AppTypography.menuTitle(color: const Color(0xFFB04444)))),
      ],
    );

    switch (action) {
      case 'open':
        await _openNode(node);
        break;
      case 'copy':
        _copyNode(node);
        break;
      case 'favorite':
        setState(() {
          if (!_favoriteIds.add(node.id)) _favoriteIds.remove(node.id);
        });
        _persistLocalWorkspace();
        break;
      case 'rename':
        await _renameLocalNode(node);
        break;
      case 'delete':
        _deleteLocalNode(node);
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final mobile = size.width < 700;
    final compact = size.width < 980;
    final showSidebar = !compact || _showSidebarOnCompact;

    return Shortcuts(
      shortcuts: const <ShortcutActivator, Intent>{
        SingleActivator(LogicalKeyboardKey.keyC, meta: true): _CopyIntent(),
        SingleActivator(LogicalKeyboardKey.keyC, control: true): _CopyIntent(),
        SingleActivator(LogicalKeyboardKey.keyV, meta: true): _PasteIntent(),
        SingleActivator(LogicalKeyboardKey.keyV, control: true): _PasteIntent(),
      },
      child: Actions(
        actions: <Type, Action<Intent>>{
          _CopyIntent: CallbackAction<_CopyIntent>(onInvoke: (_) {
            final node = _nodesForCurrentFolder().where((n) => n.id == _selectedNodeId).firstOrNull;
            if (node != null) _copyNode(node);
            return null;
          }),
          _PasteIntent: CallbackAction<_PasteIntent>(onInvoke: (_) {
            _pasteShortcut();
            return null;
          }),
        },
        child: Focus(
          autofocus: true,
          child: ColoredBox(
            color: _bg,
            child: Stack(
              children: [
                Row(
                  children: [
                    if (showSidebar)
                      SizedBox(
                        width: mobile ? math.min(280.0, size.width * .82) : 226.0,
                        child: _buildSidebar(compact: compact),
                      ),
                    Expanded(child: _buildMain(mobile: mobile, compact: compact)),
                  ],
                ),
                if (compact && showSidebar)
                  Positioned(
                    right: 12,
                    top: 12,
                    child: IconButton.filledTonal(
                      onPressed: () => setState(() => _showSidebarOnCompact = false),
                      icon: const Icon(Icons.close_rounded),
                      tooltip: 'Закрыть меню',
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSidebar({required bool compact}) {
    return Container(
      decoration: const BoxDecoration(
        color: Color(0xFFF1F3F1),
        border: Border(right: BorderSide(color: _line)),
      ),
      child: SafeArea(
        right: false,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(10, 14, 10, 24),
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(9, 4, 9, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('SPORTOTEKA OS', style: AppTypography.menuGroup(color: _green)),
                  const SizedBox(height: 4),
                  Text(
                    widget.clubName.trim().isEmpty ? 'Пространство клуба' : widget.clubName,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.itemTitle(color: _text),
                  ),
                ],
              ),
            ),
            _SideItem(
              icon: Icons.home_rounded,
              title: 'Главная',
              selected: _folderKey == 'home',
              onTap: () {
                _goHome();
                if (compact) setState(() => _showSidebarOnCompact = false);
              },
            ),
            _SideItem(
              icon: Icons.schedule_rounded,
              title: 'Недавние',
              selected: _folderKey == 'recent',
              onTap: () {
                setState(() => _folderKey = 'recent');
                if (compact) setState(() => _showSidebarOnCompact = false);
              },
            ),
            _SideItem(
              icon: Icons.star_rounded,
              title: 'Избранное',
              selected: _folderKey == 'favorites',
              onTap: () {
                setState(() => _folderKey = 'favorites');
                if (compact) setState(() => _showSidebarOnCompact = false);
              },
            ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 9),
              child: Text('КЛУБ', style: AppTypography.menuGroup(color: _muted)),
            ),
            const SizedBox(height: 5),
            for (final module in kWorkspaceFinderModules.take(9))
              _SideItem(
                icon: module.icon,
                title: module.title,
                selected: _folderKey == module.key,
                onTap: () {
                  setState(() {
                    _folderKey = module.key;
                    _search = '';
                  });
                  if (compact) setState(() => _showSidebarOnCompact = false);
                },
              ),
            const SizedBox(height: 14),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 9),
              child: Text('ЕЩЁ', style: AppTypography.menuGroup(color: _muted)),
            ),
            const SizedBox(height: 5),
            for (final module in kWorkspaceFinderModules.skip(9))
              _SideItem(
                icon: module.icon,
                title: module.title,
                selected: _folderKey == module.key,
                onTap: () {
                  setState(() {
                    _folderKey = module.key;
                    _search = '';
                  });
                  if (compact) setState(() => _showSidebarOnCompact = false);
                },
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildMain({required bool mobile, required bool compact}) {
    final nodes = _nodesForCurrentFolder();
    return Column(
      children: [
        _buildToolbar(mobile: mobile, compact: compact),
        _buildBreadcrumbs(mobile: mobile),
        Expanded(
          child: nodes.isEmpty
              ? _buildEmpty()
              : _viewMode == WorkspaceFinderViewMode.grid
                  ? _buildGrid(nodes, mobile: mobile)
                  : _buildList(nodes, mobile: mobile),
        ),
        _buildStatusBar(nodes.length),
      ],
    );
  }

  Widget _buildToolbar({required bool mobile, required bool compact}) {
    return Container(
      height: mobile ? 58 : 62,
      padding: EdgeInsets.symmetric(horizontal: mobile ? 10 : 14),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: _line)),
      ),
      child: Row(
        children: [
          if (compact)
            IconButton(
              onPressed: () => setState(() => _showSidebarOnCompact = true),
              icon: const Icon(Icons.menu_rounded),
              tooltip: 'Разделы',
            ),
          IconButton(
            onPressed: _folderKey == 'home' ? null : _goHome,
            icon: const Icon(Icons.arrow_back_rounded),
            tooltip: 'Назад',
          ),
          if (!mobile) ...[
            IconButton(
              onPressed: widget.onRefresh == null ? null : () => widget.onRefresh!(),
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Обновить',
            ),
            const SizedBox(width: 4),
          ],
          Expanded(
            child: Container(
              height: 36,
              constraints: const BoxConstraints(maxWidth: 420),
              decoration: BoxDecoration(
                color: const Color(0xFFF4F6F4),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                onChanged: (value) => setState(() => _search = value),
                style: AppTypography.formText(),
                decoration: InputDecoration(
                  border: InputBorder.none,
                  isDense: true,
                  prefixIcon: const Icon(Icons.search_rounded, size: 18),
                  hintText: mobile ? 'Поиск' : 'Поиск в «$_currentTitle»',
                  hintStyle: AppTypography.formHint(),
                  contentPadding: const EdgeInsets.symmetric(vertical: 9),
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          PopupMenuButton<String>(
            tooltip: 'Создать',
            onSelected: (value) {
              if (value == 'folder') _createFolder();
              if (value == 'note') _createNote();
              if (value == 'paste') _pasteShortcut();
            },
            itemBuilder: (_) => <PopupMenuEntry<String>>[
              PopupMenuItem(value: 'folder', child: Text('Новая папка', style: AppTypography.menuTitle())),
              PopupMenuItem(value: 'note', child: Text('Новый документ', style: AppTypography.menuTitle())),
              if (_clipboardNode != null)
                PopupMenuItem(value: 'paste', child: Text('Вставить ярлык', style: AppTypography.menuTitle())),
            ],
            child: Container(
              height: 36,
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: _green,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  const Icon(Icons.add_rounded, color: Colors.white, size: 18),
                  if (!mobile) ...[
                    const SizedBox(width: 5),
                    Text('Создать', style: AppTypography.actionStrong(color: Colors.white)),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(width: 6),
          IconButton(
            onPressed: () {
              setState(() {
                _viewMode = _viewMode == WorkspaceFinderViewMode.grid
                    ? WorkspaceFinderViewMode.list
                    : WorkspaceFinderViewMode.grid;
              });
              _persistLocalWorkspace();
            },
            icon: Icon(
              _viewMode == WorkspaceFinderViewMode.grid
                  ? Icons.view_list_rounded
                  : Icons.grid_view_rounded,
            ),
            tooltip: _viewMode == WorkspaceFinderViewMode.grid ? 'Список' : 'Иконки',
          ),
        ],
      ),
    );
  }

  Widget _buildBreadcrumbs({required bool mobile}) {
    return Container(
      height: mobile ? 42 : 46,
      padding: EdgeInsets.symmetric(horizontal: mobile ? 12 : 18),
      alignment: Alignment.centerLeft,
      child: Row(
        children: [
          for (int i = 0; i < _breadcrumbs.length; i++) ...[
            if (i > 0)
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 4),
                child: Icon(Icons.chevron_right_rounded, size: 16, color: _muted),
              ),
            InkWell(
              borderRadius: BorderRadius.circular(6),
              onTap: i == 0 ? _goHome : null,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 3),
                child: Text(
                  _breadcrumbs[i],
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: i == _breadcrumbs.length - 1
                      ? AppTypography.menuTitle(color: _text)
                      : AppTypography.menuTitle(color: _muted),
                ),
              ),
            ),
          ],
          const Spacer(),
          if (!mobile && widget.selectedTeamName.trim().isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF5EF),
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                widget.selectedTeamName,
                style: AppTypography.captionMedium(color: _green),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildGrid(List<WorkspaceFinderNode> nodes, {required bool mobile}) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final targetWidth = mobile ? 142.0 : 154.0;
        final count = math.max(2, (constraints.maxWidth / targetWidth).floor()).toInt();
        return GridView.builder(
          padding: EdgeInsets.fromLTRB(mobile ? 10 : 18, 4, mobile ? 10 : 18, 24),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: count,
            mainAxisExtent: mobile ? 142 : 150,
            crossAxisSpacing: mobile ? 6 : 10,
            mainAxisSpacing: mobile ? 6 : 10,
          ),
          itemCount: nodes.length,
          itemBuilder: (_, index) => _buildGridNode(nodes[index], mobile: mobile),
        );
      },
    );
  }

  Widget _buildGridNode(WorkspaceFinderNode node, {required bool mobile}) {
    final selected = _selectedNodeId == node.id;
    final favorite = _favoriteIds.contains(node.id);
    final tile = DragTarget<WorkspaceFinderNode>(
      onWillAccept: (data) => data != null && (node.isFolder || node.kind == WorkspaceFinderNodeKind.team) && data.id != node.id,
      onAccept: (data) => _dropNode(data, node),
      builder: (context, candidate, rejected) {
        final accepting = candidate.isNotEmpty;
        return AnimatedContainer(
          duration: const Duration(milliseconds: 120),
          padding: const EdgeInsets.fromLTRB(8, 10, 8, 8),
          decoration: BoxDecoration(
            color: accepting
                ? const Color(0xFFE6F4EC)
                : selected
                    ? const Color(0xFFEAF3EE)
                    : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Expanded(
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    _FinderFolderGlyph(
                      size: mobile ? 68 : 74,
                    ),
                    if (favorite)
                      const Positioned(
                        top: 1,
                        right: 12,
                        child: Icon(Icons.star_rounded, size: 15, color: Color(0xFFD39C18)),
                      ),
                    if (node.isShortcut)
                      const Positioned(
                        bottom: 5,
                        right: 14,
                        child: Icon(Icons.shortcut_rounded, size: 15, color: _muted),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Flexible(
                    child: Text(
                      node.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      textAlign: TextAlign.center,
                      style: AppTypography.menuTitle(color: _text),
                    ),
                  ),
                  const SizedBox(width: 5),
                  const _FinderBrandDots(),
                ],
              ),
              if (node.subtitle.isNotEmpty && !mobile) ...[
                const SizedBox(height: 2),
                Text(
                  node.subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: AppTypography.caption(color: _muted),
                ),
              ],
            ],
          ),
        );
      },
    );

    final interactive = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: () {
        setState(() => _selectedNodeId = node.id);
        if (mobile) _openNode(node);
      },
      onDoubleTap: mobile ? null : () => _openNode(node),
      onSecondaryTapDown: (details) => _showNodeMenu(node, details.globalPosition),
      child: tile,
    );

    return LongPressDraggable<WorkspaceFinderNode>(
      data: node,
      feedback: Material(
        color: Colors.transparent,
        child: SizedBox(
          width: 138,
          child: DecoratedBox(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: const [BoxShadow(color: Color(0x24000000), blurRadius: 18)],
            ),
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Row(
                children: [
                  const _FinderFolderGlyph(size: 24),
                  const SizedBox(width: 7),
                  Expanded(child: Text(node.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.captionMedium())),
                ],
              ),
            ),
          ),
        ),
      ),
      childWhenDragging: Opacity(opacity: .35, child: interactive),
      child: interactive,
    );
  }

  Widget _buildList(List<WorkspaceFinderNode> nodes, {required bool mobile}) {
    return ListView.separated(
      padding: EdgeInsets.fromLTRB(mobile ? 8 : 14, 2, mobile ? 8 : 14, 28),
      itemCount: nodes.length,
      separatorBuilder: (_, __) => const Divider(height: 1, indent: 52, color: _line),
      itemBuilder: (_, index) {
        final node = nodes[index];
        final selected = _selectedNodeId == node.id;
        return DragTarget<WorkspaceFinderNode>(
          onWillAccept: (data) => data != null && (node.isFolder || node.kind == WorkspaceFinderNodeKind.team) && data.id != node.id,
          onAccept: (data) => _dropNode(data, node),
          builder: (context, candidate, rejected) {
            final tile = Material(
              color: selected || candidate.isNotEmpty ? const Color(0xFFEAF3EE) : Colors.white,
              borderRadius: BorderRadius.circular(9),
              child: InkWell(
                borderRadius: BorderRadius.circular(9),
                onTap: () {
                  setState(() => _selectedNodeId = node.id);
                  _openNode(node);
                },
                onDoubleTap: mobile ? null : () => _openNode(node),
                onLongPress: () => _copyNode(node),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  child: Row(
                    children: [
                      const _FinderFolderGlyph(size: 34),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Expanded(child: Text(node.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.menuTitle(color: _text))),
                                const SizedBox(width: 6),
                                const _FinderBrandDots(compact: true),
                              ],
                            ),
                            if (node.subtitle.isNotEmpty)
                              Text(node.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.caption(color: _muted)),
                          ],
                        ),
                      ),
                      if (_favoriteIds.contains(node.id))
                        const Padding(
                          padding: EdgeInsets.only(right: 2),
                          child: Icon(Icons.star_rounded, size: 15, color: Color(0xFFD39C18)),
                        ),
                      IconButton(
                        icon: const Icon(Icons.more_horiz_rounded, size: 19),
                        onPressed: () {
                          final box = context.findRenderObject() as RenderBox?;
                          final pos = box?.localToGlobal(const Offset(20, 20)) ?? const Offset(120, 120);
                          _showNodeMenu(node, pos);
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
            return GestureDetector(
              behavior: HitTestBehavior.opaque,
              onDoubleTap: mobile ? null : () => _openNode(node),
              onSecondaryTapDown: (details) => _showNodeMenu(node, details.globalPosition),
              child: tile,
            );
          },
        );
      },
    );
  }

  SportotekaWorkspaceIconKind _sportIconForNode(WorkspaceFinderNode node) {
    if (node.moduleKey != null && node.moduleKey!.isNotEmpty) {
      return sportotekaWorkspaceIconForModuleKey(node.moduleKey!);
    }
    switch (node.kind) {
      case WorkspaceFinderNodeKind.team:
        return SportotekaWorkspaceIconKind.teams;
      case WorkspaceFinderNodeKind.player:
        return SportotekaWorkspaceIconKind.players;
      case WorkspaceFinderNodeKind.trainer:
        return SportotekaWorkspaceIconKind.trainers;
      case WorkspaceFinderNodeKind.match:
        return SportotekaWorkspaceIconKind.matches;
      case WorkspaceFinderNodeKind.training:
        return SportotekaWorkspaceIconKind.trainings;
      case WorkspaceFinderNodeKind.plan:
        return SportotekaWorkspaceIconKind.plans;
      case WorkspaceFinderNodeKind.tracker:
        return SportotekaWorkspaceIconKind.tracker;
      case WorkspaceFinderNodeKind.testing:
        return SportotekaWorkspaceIconKind.testing;
      case WorkspaceFinderNodeKind.calendar:
        return SportotekaWorkspaceIconKind.calendar;
      case WorkspaceFinderNodeKind.document:
        return SportotekaWorkspaceIconKind.document;
      case WorkspaceFinderNodeKind.video:
        return SportotekaWorkspaceIconKind.video;
      case WorkspaceFinderNodeKind.report:
        return SportotekaWorkspaceIconKind.reports;
      case WorkspaceFinderNodeKind.chat:
        return SportotekaWorkspaceIconKind.chat;
      case WorkspaceFinderNodeKind.medical:
        return SportotekaWorkspaceIconKind.medical;
      case WorkspaceFinderNodeKind.parent:
        return SportotekaWorkspaceIconKind.parents;
      case WorkspaceFinderNodeKind.shortcut:
        return SportotekaWorkspaceIconKind.shortcut;
      case WorkspaceFinderNodeKind.note:
        return SportotekaWorkspaceIconKind.note;
      case WorkspaceFinderNodeKind.folder:
        return SportotekaWorkspaceIconKind.folder;
    }
  }

  IconData _iconForNode(WorkspaceFinderNode node) {
    if (node.isFolder && node.moduleKey != null) {
      return _moduleFor(node.moduleKey!)?.icon ?? Icons.folder_rounded;
    }
    if (node.kind == WorkspaceFinderNodeKind.shortcut && node.moduleKey != null) {
      return _moduleFor(node.moduleKey!)?.icon ?? Icons.shortcut_rounded;
    }
    return workspaceFinderIconForKind(node.kind);
  }

  Widget _buildEmpty() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SportotekaWorkspaceFolderIcon(
              size: 58,
              color: Color(0xFFAAB8B1),
              fillColor: Colors.white,
              showBrandDots: false,
            ),
            const SizedBox(height: 12),
            Text('Здесь пока пусто', style: AppTypography.sectionTitle(color: _text)),
            const SizedBox(height: 5),
            Text(
              _search.trim().isNotEmpty
                  ? 'По запросу ничего не найдено.'
                  : 'Создайте папку или документ. Системные данные клуба появятся здесь автоматически.',
              textAlign: TextAlign.center,
              style: AppTypography.secondary(color: _muted),
            ),
            const SizedBox(height: 14),
            OutlinedButton.icon(
              onPressed: _createNote,
              icon: const Icon(Icons.note_add_rounded, size: 18),
              label: Text('Новый документ', style: AppTypography.action()),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBar(int count) {
    return Container(
      height: 30,
      padding: const EdgeInsets.symmetric(horizontal: 14),
      decoration: const BoxDecoration(
        color: Color(0xFFF5F6F5),
        border: Border(top: BorderSide(color: _line)),
      ),
      child: Row(
        children: [
          Text('$count объектов', style: AppTypography.caption(color: _muted)),
          const Spacer(),
          if (_clipboardNode != null)
            Text('Буфер: ${_clipboardNode!.title}', maxLines: 1, overflow: TextOverflow.ellipsis, style: AppTypography.caption(color: _muted)),
        ],
      ),
    );
  }
}


class _FinderBrandDots extends StatelessWidget {
  const _FinderBrandDots({this.compact = false});
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final dot = compact ? 5.0 : 6.0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(
        3,
        (index) => Padding(
          padding: EdgeInsets.only(left: index == 0 ? 0 : 4),
          child: Container(
            width: dot,
            height: dot,
            decoration: BoxDecoration(
              color: index == 1 ? const Color(0xFF17A36A) : const Color(0xFFB8D9C6),
              shape: BoxShape.circle,
            ),
          ),
        ),
      ),
    );
  }
}

class _FinderFolderGlyph extends StatelessWidget {
  const _FinderFolderGlyph({required this.size});
  final double size;

  @override
  Widget build(BuildContext context) => SportotekaWorkspaceFolderIcon(
        size: size,
        color: const Color(0xFF8D9490),
        fillColor: const Color(0xFFF2F3F2),
        showBrandDots: false,
      );
}

class _SideItem extends StatelessWidget {
  const _SideItem({
    required this.icon,
    required this.title,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 1),
      child: Material(
        color: selected ? const Color(0xFFDDE9E2) : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 7),
            child: Row(
              children: [
                Icon(icon, size: 18, color: selected ? const Color(0xFF0B8F55) : const Color(0xFF667169)),
                const SizedBox(width: 9),
                Expanded(
                  child: Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTypography.menuTitle(
                      color: selected ? const Color(0xFF101814) : const Color(0xFF4F5A53),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CopyIntent extends Intent {
  const _CopyIntent();
}

class _PasteIntent extends Intent {
  const _PasteIntent();
}

extension _IterableFirstOrNull<T> on Iterable<T> {
  T? get firstOrNull {
    final iterator = this.iterator;
    if (!iterator.moveNext()) return null;
    return iterator.current;
  }
}
