import 'dart:convert';
import 'package:http/http.dart' as http;

import 'tracker_training_report_models.dart';

class TrackerTrainingReportApi {
  TrackerTrainingReportApi({this.apiBaseUrl = 'https://sportotekaapp.ru/api/tracker'});

  final String apiBaseUrl;

  Future<TrackerTrainingReport> loadTrainingReport({
    required int sessionId,
    required int teamId,
  }) async {
    final uri = Uri.parse('$apiBaseUrl/get_training_report.php?session_id=$sessionId&team_id=$teamId&full=1&include_maps=1&include_heatmap=1&include_hr=1&include_players=1&include_charts=1&include_player_pages=1&per_player_charts=1&timeline=1&include_locomotor=1&include_mechanics=1&include_internal=1&include_microcycle=1&ai_stub=1');
    final response = await http.get(uri).timeout(const Duration(seconds: 18));
    final body = utf8.decode(response.bodyBytes);
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Ошибка API (${response.statusCode}): $body');
    }
    final json = jsonDecode(body);
    if (json is! Map) throw Exception('Некорректный JSON отчёта');
    if (json['success'] == false) throw Exception('${json['message'] ?? 'API вернул ошибку'}');
    return TrackerTrainingReport.fromJson(Map<String, dynamic>.from(json['report'] as Map? ?? json));
  }

  Uri pdfExportUri({
    required int sessionId,
    required int teamId,
    List<int>? playerIds,
    List<String>? playerNames,
    List<String>? sections,
    bool includeMaps = true,
    bool includeHeatmap = true,
    bool includeCharts = true,
    bool includePlayerPages = true,
    bool includeLogo = true,
    bool includePhotos = true,
  }) {
    final players = (playerIds ?? const <int>[]).where((id) => id > 0).join(',');
    final names = (playerNames ?? const <String>[]).where((name) => name.trim().isNotEmpty).map(Uri.encodeQueryComponent).join(',');
    final sectionList = (sections == null || sections.isEmpty)
        ? 'summary,locomotor,mechanics,internal,maps,heatmap,speed,hr,players,player_pages,microcycle,ai'
        : sections.map(Uri.encodeQueryComponent).join(',');
    final query = StringBuffer('$apiBaseUrl/export_training_report_pdf.php?session_id=$sessionId&team_id=$teamId&template=analytics_ru&inline=1&print=1&full=1&report=analytics_export');
    query.write('&include_maps=${includeMaps ? 1 : 0}&include_heatmap=${includeHeatmap ? 1 : 0}&include_hr=1&include_players=1&include_charts=${includeCharts ? 1 : 0}');
    query.write('&include_player_pages=${includePlayerPages ? 1 : 0}&per_player_charts=${includePlayerPages ? 1 : 0}&timeline=${includeCharts ? 1 : 0}');
    query.write('&include_locomotor=1&include_mechanics=1&include_internal=1&include_microcycle=1&sections=$sectionList&ai_stub=1');
    query.write('&include_logo=${includeLogo ? 1 : 0}&include_photos=${includePhotos ? 1 : 0}');
    if (players.isNotEmpty) query.write('&player_ids=$players&player_id=$players');
    if (names.isNotEmpty) query.write('&player_names=$names');
    query.write('&v=108');
    return Uri.parse(query.toString());
  }

  Uri csvExportUri({required int sessionId, required int teamId, List<int>? playerIds, List<String>? playerNames, List<String>? sections}) {
    final players = (playerIds ?? const <int>[]).where((id) => id > 0).join(',');
    final names = (playerNames ?? const <String>[]).where((name) => name.trim().isNotEmpty).map(Uri.encodeQueryComponent).join(',');
    final sectionList = (sections == null || sections.isEmpty) ? 'summary,players,locomotor,mechanics,hr,comparison,zones' : sections.map(Uri.encodeQueryComponent).join(',');
    final query = StringBuffer('$apiBaseUrl/export_training_report_csv.php?session_id=$sessionId&team_id=$teamId&full=1&include_hr=1&include_players=1&sections=$sectionList');
    if (players.isNotEmpty) query.write('&player_ids=$players&player_id=$players');
    if (names.isNotEmpty) query.write('&player_names=$names');
    query.write('&v=108');
    return Uri.parse(query.toString());
  }
}
