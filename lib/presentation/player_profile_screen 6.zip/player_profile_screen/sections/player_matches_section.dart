import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerMatchesSection extends StatelessWidget {
  final PlayerProfileSnapshot data;

  const PlayerMatchesSection({super.key, required this.data});

  DateTime? _d(dynamic v) => DateTime.tryParse('${v ?? ''}'.replaceAll(' ', 'T'));

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
      children: [
        const PpSurface(
          elevated: true,
          child: PpSectionTitle(
            title: 'Матчи',
            subtitle: 'Результаты, участие, оценки и ТТД',
            dotColor: PpColors.green,
          ),
        ),
        const SizedBox(height: 10),
        if (data.matches.isEmpty)
          const SizedBox(
            height: 300,
            child: PpSurface(
              child: PpEmpty(
                title: 'Матчей нет',
                text: 'История матчей игрока пока пуста',
              ),
            ),
          )
        else
          ...data.matches.toList().asMap().entries.expand((entry) {
            final index = entry.key;
            final m = entry.value;
            final title = '${m['opponent'] ?? m['title'] ?? 'Матч'}';
            final date = _d(m['match_date'] ?? m['date']);
            final result = '${m['score'] ?? m['result'] ?? '—'}';
            final dot = result.contains(':') || result.toLowerCase().contains('поб')
                ? PpColors.green
                : result.toLowerCase().contains('пор')
                    ? PpColors.red
                    : PpColors.amber;
            return [
              PpSurface(
                child: Row(
                  children: [
                    PpDot(color: dot, size: 8),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(title, style: PpText.body(12, color: PpColors.text, weight: FontWeight.w600)),
                          const SizedBox(height: 3),
                          Text(date == null ? 'Без даты' : DateFormat('dd.MM.yyyy').format(date), style: PpText.body(10.5)),
                        ],
                      ),
                    ),
                    const SizedBox(width: 8),
                    Text(result, style: PpText.value(15)),
                  ],
                ),
              ),
              if (index != data.matches.length - 1) const SizedBox(height: 8),
            ];
          }),
      ],
    );
  }
}
