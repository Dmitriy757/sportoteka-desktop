import 'package:flutter/material.dart';

import '../export/player_card_preview.dart';
import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerCardSection extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? session;
  final VoidCallback? onEditSchoolProfile;

  const PlayerCardSection({
    super.key,
    required this.data,
    this.session,
    this.onEditSchoolProfile,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 28),
        children: [
          Row(
            children: [
              const PpDot.green(size: 7),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Карточка игрока', style: PpText.title(18)),
                    const SizedBox(height: 3),
                    Text(
                      'Паспорт школы · форма · посещаемость · трекер',
                      style: PpText.body(10.2),
                    ),
                  ],
                ),
              ),
              const PpDotCluster(),
            ],
          ),
          const PpThinDivider(
            margin: EdgeInsets.only(top: 12, bottom: 12),
          ),
          PlayerCardPreview(data: data, session: session),
          const PpThinDivider(
            margin: EdgeInsets.symmetric(vertical: 12),
          ),
          _SchoolPassport(data: data, onEdit: onEditSchoolProfile),
        ],
      ),
    );
  }
}

class _SchoolPassport extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final VoidCallback? onEdit;

  const _SchoolPassport({required this.data, this.onEdit});

  String _s(dynamic value) => '${value ?? ''}'.trim();

  String _value(List<String> keys) {
    for (final key in keys) {
      final value = _s(data.player[key] ?? data.schoolProfile[key]);
      if (value.isNotEmpty && value != 'null') return value;
    }
    return '—';
  }

  int get _completion {
    const keys = <String>[
      'birth_date',
      'citizenship',
      'city',
      'position',
      'dominant_foot',
      'jersey_number',
      'enrollment_date',
      'player_status',
      'school_name',
      'school_class',
      'parent_name',
      'parent_phone',
      'parent_email',
      'contract_number',
      'medical_clearance_until',
      'equipment_size',
    ];
    final filled = keys.where((key) {
      final value = _s(data.player[key] ?? data.schoolProfile[key]);
      return value.isNotEmpty && value != 'null';
    }).length;
    return (filled / keys.length * 100).round();
  }

  @override
  Widget build(BuildContext context) {
    final sections = <_PassportGroup>[
      _PassportGroup(
        'Футбольная школа',
        PpColors.greenDark,
        <_PassportRow>[
          _PassportRow('Дата зачисления', _value(const ['enrollment_date'])),
          _PassportRow('Статус', _value(const ['player_status'])),
          _PassportRow('Основное амплуа', _value(const ['position', 'amplua'])),
          _PassportRow('Доп. амплуа', _value(const ['secondary_position'])),
          _PassportRow('Ведущая нога', _value(const ['dominant_foot'])),
          _PassportRow('ID федерации', _value(const ['federation_id'])),
        ],
      ),
      _PassportGroup(
        'Обучение',
        PpColors.amber,
        <_PassportRow>[
          _PassportRow('Школа', _value(const ['school_name'])),
          _PassportRow('Класс', _value(const ['school_class'])),
          _PassportRow('Смена', _value(const ['school_shift'])),
          _PassportRow('Расписание', _value(const ['education_note'])),
        ],
      ),
      _PassportGroup(
        'Родитель и связь',
        PpColors.green,
        <_PassportRow>[
          _PassportRow('Представитель', _value(const ['parent_name'])),
          _PassportRow('Кем приходится', _value(const ['parent_relation'])),
          _PassportRow('Телефон', _value(const ['parent_phone'])),
          _PassportRow('Email', _value(const ['parent_email'])),
          _PassportRow('Экстренный контакт', _value(const ['emergency_contact'])),
        ],
      ),
      _PassportGroup(
        'Учёт и экипировка',
        PpColors.amber,
        <_PassportRow>[
          _PassportRow('Договор', _value(const ['contract_number'])),
          _PassportRow('Приказ', _value(const ['admission_order'])),
          _PassportRow('Мед. допуск до', _value(const ['medical_clearance_until'])),
          _PassportRow('Размер формы', _value(const ['equipment_size'])),
          _PassportRow('Размер обуви', _value(const ['shoe_size'])),
        ],
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        PpSectionTitle(
          title: 'Паспорт футбольной школы',
          subtitle: 'Анкета заполнена на $_completion%',
          dotColor: PpColors.greenDark,
          trailing: onEdit == null
              ? null
              : PpTextAction(
                  label: 'Заполнить / изменить',
                  onTap: onEdit,
                  dotColor: PpColors.greenDark,
                  emphasized: true,
                ),
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            final twoColumns = constraints.maxWidth >= 820;
            final width = twoColumns
                ? (constraints.maxWidth - 10) / 2
                : constraints.maxWidth;
            return Wrap(
              spacing: 10,
              runSpacing: 10,
              children: sections
                  .map(
                    (section) => SizedBox(
                      width: width,
                      child: _PassportCard(group: section),
                    ),
                  )
                  .toList(growable: false),
            );
          },
        ),
      ],
    );
  }
}

class _PassportCard extends StatelessWidget {
  final _PassportGroup group;

  const _PassportCard({required this.group});

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      color: PpColors.soft,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          PpSectionTitle(title: group.title, dotColor: group.color),
          const SizedBox(height: 7),
          ...group.rows.asMap().entries.map((entry) {
            final row = entry.value;
            return Column(
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 7),
                  child: Row(
                    children: [
                      PpDot(color: group.color, size: 5),
                      const SizedBox(width: 8),
                      Expanded(child: Text(row.label, style: PpText.body(10.4))),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          row.value,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.right,
                          style: PpText.body(
                            10.4,
                            color: PpColors.text,
                            weight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                if (entry.key != group.rows.length - 1)
                  const PpThinDivider(margin: EdgeInsets.zero),
              ],
            );
          }),
        ],
      ),
    );
  }
}

class _PassportGroup {
  final String title;
  final Color color;
  final List<_PassportRow> rows;

  const _PassportGroup(this.title, this.color, this.rows);
}

class _PassportRow {
  final String label;
  final String value;

  const _PassportRow(this.label, this.value);
}
