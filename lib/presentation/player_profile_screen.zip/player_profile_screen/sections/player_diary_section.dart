import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

typedef PlayerDiarySave = Future<void> Function({
  required DateTime entryDate,
  required String authorRole,
  int eventId,
  int rating,
  int mood,
  int fatigue,
  int sleepQuality,
  int pain,
  int rpe,
  String note,
});

class PlayerDiarySection extends StatefulWidget {
  final PlayerProfileSnapshot data;
  final bool readOnly;
  final int viewerUserId;
  final String viewerRole;
  final bool viewerContextLoading;
  final PlayerDiarySave? onSave;

  const PlayerDiarySection({
    super.key,
    required this.data,
    this.readOnly = false,
    this.viewerUserId = 0,
    this.viewerRole = '',
    this.viewerContextLoading = false,
    this.onSave,
  });

  @override
  State<PlayerDiarySection> createState() => _PlayerDiarySectionState();
}

class _PlayerDiarySectionState extends State<PlayerDiarySection> {
  final TextEditingController _noteC = TextEditingController();

  int _rating = 0;
  int _mood = 0;
  int _fatigue = 0;
  int _sleep = 0;
  int _pain = 0;
  int _rpe = 0;

  bool _saving = false;
  bool _showEditor = true;

  String _s(dynamic value) => '${value ?? ''}'.trim();

  int _i(dynamic value) =>
      value is num ? value.toInt() : int.tryParse(_s(value)) ?? 0;

  String get _role {
    final raw = widget.viewerRole.trim().toLowerCase();
    if (raw == 'trainer' || raw == 'тренер') return 'coach';
    if (raw == 'club' ||
        raw == 'manager' ||
        raw == 'admin' ||
        raw == 'management' ||
        raw == 'руководитель') {
      return 'manager';
    }
    if (raw == 'футболист' || raw == 'игрок') return 'player';
    if (raw == 'родитель') return 'parent';
    return raw;
  }

  bool get _isPlayer => _role == 'player';

  bool get _isCoach => _role == 'coach' || _role == 'manager';

  bool get _canEdit =>
      !widget.readOnly &&
      widget.viewerUserId > 0 &&
      (_isPlayer || _isCoach);

  String _absoluteUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty || value == 'null') return '';
    if (value.startsWith('http://') || value.startsWith('https://')) {
      return value;
    }
    if (value.startsWith('//')) return 'https:$value';
    final cleaned = value.startsWith('/') ? value.substring(1) : value;
    return 'https://sportotekaapp.ru/$cleaned';
  }

  String _playerName() {
    final full = _s(
      widget.data.player['full_name'] ??
          widget.data.player['fullName'] ??
          widget.data.player['name'],
    );
    if (full.isNotEmpty) return full;

    final last = _s(
      widget.data.player['last_name'] ??
          widget.data.player['lastName'] ??
          widget.data.player['surname'],
    );
    final first = _s(
      widget.data.player['first_name'] ??
          widget.data.player['firstName'],
    );
    final value = '$last $first'.trim();
    return value.isEmpty ? 'Футболист' : value;
  }

  String _playerPhoto() => _absoluteUrl(
        _s(
          widget.data.player['photo'] ??
              widget.data.player['photo_url'] ??
              widget.data.player['avatar'] ??
              widget.data.player['avatar_url'],
        ),
      );

  String _clubLogo() => _absoluteUrl(
        _s(
          widget.data.player['club_logo'] ??
              widget.data.player['club_logo_url'] ??
              widget.data.player['school_logo'] ??
              widget.data.player['team_logo'] ??
              widget.data.player['logo'],
        ),
      );

  String _clubName() => _s(
        widget.data.player['club_name'] ??
            widget.data.player['school_name'] ??
            widget.data.player['team_name'],
      );

  String _position() => _s(
        widget.data.player['position'] ??
            widget.data.player['amplua'] ??
            widget.data.player['player_position'],
      );

  Map<int, Map<String, dynamic>> get _coachByEvent => {
        for (final row in widget.data.coachRatings)
          if (_i(row['event_id']) > 0) _i(row['event_id']): row,
      };

  Map<int, Map<String, dynamic>> get _selfByEvent => {
        for (final row in widget.data.selfAssessments)
          if (_i(row['event_id']) > 0) _i(row['event_id']): row,
      };

  Map<int, Map<String, dynamic>> get _attendanceByEvent => {
        for (final row in widget.data.attendance)
          if (_i(row['event_id']) > 0) _i(row['event_id']): row,
      };

  Future<void> _saveToday() async {
    if (!_canEdit || widget.onSave == null || _saving) return;

    if (!_isPlayer && _rating <= 0 && _noteC.text.trim().isEmpty) {
      _message('Добавьте оценку или заметку тренера');
      return;
    }

    if (_isPlayer &&
        _rating <= 0 &&
        _noteC.text.trim().isEmpty &&
        _mood <= 0 &&
        _fatigue <= 0 &&
        _sleep <= 0 &&
        _pain <= 0 &&
        _rpe <= 0) {
      _message('Добавьте самооценку или обратную связь');
      return;
    }

    setState(() => _saving = true);

    try {
      await widget.onSave!(
        entryDate: DateTime.now(),
        authorRole:
            _isPlayer ? 'player' : (_role == 'manager' ? 'manager' : 'coach'),
        rating: _rating,
        mood: _isPlayer ? _mood : 0,
        fatigue: _isPlayer ? _fatigue : 0,
        sleepQuality: _isPlayer ? _sleep : 0,
        pain: _isPlayer ? _pain : 0,
        rpe: _isPlayer ? _rpe : 0,
        note: _noteC.text.trim(),
      );

      if (!mounted) return;

      _noteC.clear();
      setState(() {
        _rating = 0;
        _mood = 0;
        _fatigue = 0;
        _sleep = 0;
        _pain = 0;
        _rpe = 0;
      });

      _message(
        _isPlayer ? 'Самооценка сохранена' : 'Заметка тренера сохранена',
      );
    } catch (e) {
      if (mounted) _message('Не удалось сохранить: $e');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  void _message(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  void dispose() {
    _noteC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final data = widget.data;

    return Container(
      color: PpColors.bg,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
        children: [
          _DiaryHeader(
            playerName: _playerName(),
            playerPhoto: _playerPhoto(),
            clubLogo: _clubLogo(),
            clubName: _clubName(),
            position: _position(),
            rating: data.compositeRating,
            tier: _ratingTier(data.compositeRating),
          ),
          const SizedBox(height: 10),
          _RatingStrip(data: data),
          if (widget.viewerContextLoading) ...[
            const SizedBox(height: 10),
            const LinearProgressIndicator(
              minHeight: 2,
              color: PpColors.green,
              backgroundColor: PpColors.greenSoft,
            ),
          ] else if (_canEdit) ...[
            const SizedBox(height: 10),
            _TodayEditor(
              isPlayer: _isPlayer,
              expanded: _showEditor,
              onToggle: () =>
                  setState(() => _showEditor = !_showEditor),
              rating: _rating,
              onRating: (value) => setState(() => _rating = value),
              mood: _mood,
              onMood: (value) => setState(() => _mood = value),
              fatigue: _fatigue,
              onFatigue: (value) => setState(() => _fatigue = value),
              sleep: _sleep,
              onSleep: (value) => setState(() => _sleep = value),
              pain: _pain,
              onPain: (value) => setState(() => _pain = value),
              rpe: _rpe,
              onRpe: (value) => setState(() => _rpe = value),
              noteController: _noteC,
              saving: _saving,
              onSave: _saveToday,
            ),
          ] else ...[
            const SizedBox(height: 10),
            const _ReadOnlyNotice(),
          ],
          const SizedBox(height: 10),
          _DailyJournal(
            data: data,
            coachByEvent: _coachByEvent,
            selfByEvent: _selfByEvent,
            attendanceByEvent: _attendanceByEvent,
          ),
          const SizedBox(height: 10),
          LayoutBuilder(
            builder: (context, constraints) {
              final testing = _TestingSummary(data: data);
              final season = _SeasonSummary(data: data);

              if (constraints.maxWidth >= 800) {
                return Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(child: testing),
                    const SizedBox(width: 10),
                    Expanded(child: season),
                  ],
                );
              }

              return Column(
                children: [
                  testing,
                  const SizedBox(height: 10),
                  season,
                ],
              );
            },
          ),
          const SizedBox(height: 10),
          PpSurface(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
            child: Text(
              'Рейтинг: тренер 35% · игрок 20% · посещаемость 20% · '
              'тестирование 25%. Если данных одного блока нет, вес '
              'перераспределяется между доступными показателями.',
              style: PpText.body(10.2, color: PpColors.text),
            ),
          ),
        ],
      ),
    );
  }

  String _ratingTier(int value) {
    if (value <= 0) return 'Недостаточно данных';
    if (value >= 86) return 'Лидер';
    if (value >= 75) return 'Стабильный уровень';
    if (value >= 64) return 'Хорошая база';
    if (value >= 52) return 'Нужен контроль';
    return 'Зона внимания';
  }
}

class _DiaryHeader extends StatelessWidget {
  final String playerName;
  final String playerPhoto;
  final String clubLogo;
  final String clubName;
  final String position;
  final int rating;
  final String tier;

  const _DiaryHeader({
    required this.playerName,
    required this.playerPhoto,
    required this.clubLogo,
    required this.clubName,
    required this.position,
    required this.rating,
    required this.tier,
  });

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      padding: const EdgeInsets.all(12),
      elevated: true,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 610;

          final identity = Row(
            children: [
              _SquareImage(
                url: playerPhoto,
                fallback: _initials(playerName),
                size: compact ? 58 : 68,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            playerName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: PpText.title(compact ? 16.5 : 18.5),
                          ),
                        ),
                        if (clubLogo.isNotEmpty) ...[
                          const SizedBox(width: 8),
                          _ClubLogo(url: clubLogo, size: 34),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      [
                        if (clubName.isNotEmpty) clubName,
                        if (position.isNotEmpty) position,
                      ].isEmpty
                          ? 'Дневник футболиста'
                          : [
                              if (clubName.isNotEmpty) clubName,
                              if (position.isNotEmpty) position,
                            ].join('  ·  '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PpText.body(10.8),
                    ),
                    const SizedBox(height: 7),
                    Row(
                      children: [
                        Container(
                          width: 5,
                          height: 5,
                          decoration: const BoxDecoration(
                            color: PpColors.green,
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Дневник футболиста',
                          style: PpText.caption(color: PpColors.greenDark),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );

          final score = Container(
            constraints: BoxConstraints(
              minWidth: compact ? 118 : 145,
            ),
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 10,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: PpColors.greenBorder,
                width: .8,
              ),
            ),
            child: Row(
              children: [
                Text(
                  rating > 0 ? '$rating' : '—',
                  style: PpText.value(compact ? 24 : 28),
                ),
                const SizedBox(width: 9),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Рейтинг / 100', style: PpText.caption()),
                      const SizedBox(height: 3),
                      Text(
                        tier,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: PpText.body(
                          10.2,
                          color: PpColors.greenDark,
                          weight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );

          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                identity,
                const SizedBox(height: 10),
                score,
              ],
            );
          }

          return Row(
            children: [
              Expanded(child: identity),
              const SizedBox(width: 12),
              SizedBox(width: 165, child: score),
            ],
          );
        },
      ),
    );
  }
}

class _RatingStrip extends StatelessWidget {
  final PlayerProfileSnapshot data;

  const _RatingStrip({required this.data});

  @override
  Widget build(BuildContext context) {
    final values = <({String label, String value, String note})>[
      (
        label: 'Тренер',
        value: data.coachRatingAverage > 0
            ? '${(data.coachRatingAverage * 20).round()}%'
            : '—',
        note: '35% рейтинга',
      ),
      (
        label: 'Игрок',
        value: data.selfRatingAverage > 0
            ? '${(data.selfRatingAverage * 20).round()}%'
            : '—',
        note: '20% рейтинга',
      ),
      (
        label: 'Посещаемость',
        value:
            data.attendance.isEmpty ? '—' : '${data.attendancePercent}%',
        note: '20% рейтинга',
      ),
      (
        label: 'Тесты',
        value: data.testingScorePercent > 0
            ? '${data.testingScorePercent}%'
            : '—',
        note: '25% рейтинга',
      ),
    ];

    return PpSurface(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 11),
      color: Colors.white,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 560;
          final width =
              compact ? constraints.maxWidth / 2 : constraints.maxWidth / 4;

          return Wrap(
            children: [
              for (var i = 0; i < values.length; i++)
                SizedBox(
                  width: width,
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      border: i == 0 || (compact && i.isEven)
                          ? null
                          : const Border(
                              left: BorderSide(
                                color: PpColors.line,
                                width: .7,
                              ),
                            ),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(values[i].label, style: PpText.caption()),
                        const SizedBox(height: 4),
                        Text(values[i].value, style: PpText.value(16)),
                        const SizedBox(height: 2),
                        Text(
                          values[i].note,
                          style: PpText.body(9.4),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _TodayEditor extends StatelessWidget {
  final bool isPlayer;
  final bool expanded;
  final VoidCallback onToggle;
  final int rating;
  final ValueChanged<int> onRating;
  final int mood;
  final ValueChanged<int> onMood;
  final int fatigue;
  final ValueChanged<int> onFatigue;
  final int sleep;
  final ValueChanged<int> onSleep;
  final int pain;
  final ValueChanged<int> onPain;
  final int rpe;
  final ValueChanged<int> onRpe;
  final TextEditingController noteController;
  final bool saving;
  final VoidCallback onSave;

  const _TodayEditor({
    required this.isPlayer,
    required this.expanded,
    required this.onToggle,
    required this.rating,
    required this.onRating,
    required this.mood,
    required this.onMood,
    required this.fatigue,
    required this.onFatigue,
    required this.sleep,
    required this.onSleep,
    required this.pain,
    required this.onPain,
    required this.rpe,
    required this.onRpe,
    required this.noteController,
    required this.saving,
    required this.onSave,
  });

  @override
  Widget build(BuildContext context) {
    final today = DateFormat('dd.MM.yyyy').format(DateTime.now());

    return PpSurface(
      bordered: false,
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: onToggle,
              borderRadius: BorderRadius.circular(11),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
                child: Row(
                  children: [
                    Container(
                      width: 3,
                      height: 31,
                      decoration: BoxDecoration(
                        color: PpColors.green,
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            isPlayer
                                ? 'Мой день · $today'
                                : 'Запись тренера · $today',
                            style: PpText.title(13.5),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            isPlayer
                                ? 'Самооценка и обратная связь'
                                : 'Оценка и заметка по футболисту',
                            style: PpText.body(10.4),
                          ),
                        ],
                      ),
                    ),
                    Text(
                      expanded ? 'Свернуть' : 'Заполнить',
                      style: PpText.body(
                        10.4,
                        color: PpColors.greenDark,
                        weight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          if (expanded) ...[
            const SizedBox(height: 2),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    isPlayer
                        ? 'Как оцениваешь сегодняшний день?'
                        : 'Оценка футболиста',
                    style: PpText.body(
                      11,
                      color: PpColors.text,
                      weight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 8),
                  _Scale(
                    value: rating,
                    max: 5,
                    onChanged: onRating,
                  ),
                  if (isPlayer) ...[
                    const SizedBox(height: 12),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final two = constraints.maxWidth >= 620;
                        final cards = <Widget>[
                          _MiniScaleCard(
                            title: 'Настроение',
                            value: mood,
                            max: 5,
                            onChanged: onMood,
                          ),
                          _MiniScaleCard(
                            title: 'Усталость',
                            value: fatigue,
                            max: 5,
                            onChanged: onFatigue,
                          ),
                          _MiniScaleCard(
                            title: 'Качество сна',
                            value: sleep,
                            max: 5,
                            onChanged: onSleep,
                          ),
                          _MiniScaleCard(
                            title: 'Боль / дискомфорт',
                            value: pain,
                            max: 5,
                            onChanged: onPain,
                          ),
                          _MiniScaleCard(
                            title: 'Нагрузка RPE',
                            value: rpe,
                            max: 10,
                            onChanged: onRpe,
                          ),
                        ];

                        if (!two) {
                          return Column(
                            children: cards
                                .map(
                                  (item) => Padding(
                                    padding:
                                        const EdgeInsets.only(bottom: 7),
                                    child: item,
                                  ),
                                )
                                .toList(),
                          );
                        }

                        return Wrap(
                          spacing: 7,
                          runSpacing: 7,
                          children: cards
                              .map(
                                (item) => SizedBox(
                                  width:
                                      (constraints.maxWidth - 7) / 2,
                                  child: item,
                                ),
                              )
                              .toList(),
                        );
                      },
                    ),
                  ],
                  const SizedBox(height: 11),
                  TextField(
                    controller: noteController,
                    minLines: 2,
                    maxLines: 5,
                    decoration: InputDecoration(
                      hintText: isPlayer
                          ? 'Что получилось? Что было сложно? Что хочешь улучшить?'
                          : 'Сильные стороны, задачи и рекомендации...',
                      hintStyle: PpText.body(10.4),
                      filled: true,
                      fillColor: PpColors.soft,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 11,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(9),
                        borderSide: BorderSide.none,
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(9),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(9),
                        borderSide: BorderSide.none,
                      ),
                    ),
                    style: PpText.body(
                      11,
                      color: PpColors.text,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Align(
                    alignment: Alignment.centerRight,
                    child: Material(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(9),
                      child: InkWell(
                        onTap: saving ? null : onSave,
                        borderRadius: BorderRadius.circular(9),
                        child: Container(
                          constraints:
                              const BoxConstraints(minHeight: 38),
                          padding: const EdgeInsets.symmetric(
                            horizontal: 14,
                          ),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(9),

                          ),
                          child: Text(
                            saving
                                ? 'Сохранение...'
                                : 'Сохранить запись',
                            style: PpText.body(
                              10.8,
                              color: PpColors.greenDark,
                              weight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _MiniScaleCard extends StatelessWidget {
  final String title;
  final int value;
  final int max;
  final ValueChanged<int> onChanged;

  const _MiniScaleCard({
    required this.title,
    required this.value,
    required this.max,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 9, 10, 9),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9),

      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: PpText.body(
                    10.3,
                    color: PpColors.text,
                    weight: FontWeight.w600,
                  ),
                ),
              ),
              Text(
                value <= 0 ? '—' : '$value/$max',
                style: PpText.caption(
                  color: value > 0
                      ? PpColors.greenDark
                      : PpColors.muted2,
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          _Scale(
            value: value,
            max: max,
            onChanged: onChanged,
            compact: true,
          ),
        ],
      ),
    );
  }
}

class _Scale extends StatelessWidget {
  final int value;
  final int max;
  final ValueChanged<int> onChanged;
  final bool compact;

  const _Scale({
    required this.value,
    required this.max,
    required this.onChanged,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 5,
      runSpacing: 5,
      children: List.generate(max, (index) {
        final current = index + 1;
        final active = current == value;

        return Material(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          child: InkWell(
            onTap: () => onChanged(current),
            borderRadius: BorderRadius.circular(8),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 130),
              width: max > 5
                  ? (compact ? 27 : 30)
                  : (compact ? 34 : 38),
              height: compact ? 28 : 31,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active
                    ? PpColors.greenSoft
                    : Colors.white,
                borderRadius: BorderRadius.circular(8),

              ),
              child: Text(
                '$current',
                style: PpText.body(
                  10.2,
                  color: active
                      ? PpColors.greenDark
                      : PpColors.muted,
                  weight:
                      active ? FontWeight.w600 : FontWeight.w400,
                ),
              ),
            ),
          ),
        );
      }),
    );
  }
}

class _ReadOnlyNotice extends StatelessWidget {
  const _ReadOnlyNotice();

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      color: Colors.white,
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      child: Row(
        children: [
          Container(
            width: 5,
            height: 5,
            decoration: const BoxDecoration(
              color: PpColors.green,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              'Дневник доступен только для просмотра.',
              style: PpText.body(10.6, color: PpColors.text),
            ),
          ),
        ],
      ),
    );
  }
}

class _DailyJournal extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final Map<int, Map<String, dynamic>> coachByEvent;
  final Map<int, Map<String, dynamic>> selfByEvent;
  final Map<int, Map<String, dynamic>> attendanceByEvent;

  const _DailyJournal({
    required this.data,
    required this.coachByEvent,
    required this.selfByEvent,
    required this.attendanceByEvent,
  });

  String _s(dynamic value) => '${value ?? ''}'.trim();

  DateTime? _date(dynamic value) =>
      DateTime.tryParse(_s(value).replaceAll(' ', 'T'));

  String _key(DateTime value) =>
      '${value.year}-${value.month.toString().padLeft(2, '0')}-'
      '${value.day.toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final days = <String, _DayData>{};

    void ensure(DateTime date) {
      final day = DateTime(date.year, date.month, date.day);
      days.putIfAbsent(_key(day), () => _DayData(date: day));
    }

    for (final event in data.trainings) {
      final date = _date(
        event['start_at'] ??
            event['event_date'] ??
            event['training_date'] ??
            event['date'],
      );
      if (date == null) continue;
      ensure(date);
      days[_key(date)]!.events.add(event);
    }

    for (final entry in data.diaryEntries) {
      final date = _date(
        entry['entry_date'] ??
            entry['date'] ??
            entry['created_at'],
      );
      if (date == null) continue;
      ensure(date);
      days[_key(date)]!.entries.add(entry);
    }

    for (final match in data.matches) {
      final date =
          _date(match['match_date'] ?? match['date'] ?? match['start_at']);
      if (date == null) continue;
      ensure(date);
      days[_key(date)]!.matches.add(match);
    }

    for (final test in data.tests) {
      final date = _date(test['test_date'] ?? test['date']);
      if (date == null) continue;
      ensure(date);
      days[_key(date)]!.tests.add(test);
    }

    final list = days.values.toList()
      ..sort((a, b) => b.date.compareTo(a.date));

    return PpSurface(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Журнал по дням',
            subtitle:
                'Тренировки, оценки, обратная связь, матчи и тестирование',
          ),
          const SizedBox(height: 10),
          if (list.isEmpty)
            const SizedBox(
              height: 165,
              child: PpEmpty(
                title: 'Записей пока нет',
                text:
                    'Журнал заполнится после тренировок, оценок и обратной связи.',
              ),
            )
          else
            ...list.take(45).map(
                  (day) => Padding(
                    padding: const EdgeInsets.only(bottom: 7),
                    child: _DayCard(
                      day: day,
                      coachByEvent: coachByEvent,
                      selfByEvent: selfByEvent,
                      attendanceByEvent: attendanceByEvent,
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

class _DayData {
  final DateTime date;
  final List<Map<String, dynamic>> events = [];
  final List<Map<String, dynamic>> entries = [];
  final List<Map<String, dynamic>> matches = [];
  final List<Map<String, dynamic>> tests = [];

  _DayData({required this.date});
}

class _DayCard extends StatelessWidget {
  final _DayData day;
  final Map<int, Map<String, dynamic>> coachByEvent;
  final Map<int, Map<String, dynamic>> selfByEvent;
  final Map<int, Map<String, dynamic>> attendanceByEvent;

  const _DayCard({
    required this.day,
    required this.coachByEvent,
    required this.selfByEvent,
    required this.attendanceByEvent,
  });

  String _s(dynamic value) => '${value ?? ''}'.trim();

  int _i(dynamic value) =>
      value is num ? value.toInt() : int.tryParse(_s(value)) ?? 0;

  String _weekday(int weekday) {
    const days = <String>['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];
    return weekday >= 1 && weekday <= 7 ? days[weekday - 1] : '';
  }

  String _attendance(Map<String, dynamic>? row) {
    final raw = _s(row?['status'] ?? row?['mark']).toLowerCase();

    if (raw == 'present' || raw.contains('прис')) return 'Присутствовал';
    if (raw == 'late') return 'Опоздал';
    if (raw == 'injured') return 'Травма';
    if (raw == 'individual') return 'Индивидуально';
    if (raw == 'dayoff') return 'Выходной';
    if (raw == 'absent') return 'Отсутствовал';

    return '';
  }

  @override
  Widget build(BuildContext context) {
    final coachDaily = day.entries
        .where(
          (row) => <String>['coach', 'manager'].contains(
            _s(row['author_role']).toLowerCase(),
          ),
        )
        .toList();

    final playerDaily = day.entries
        .where(
          (row) =>
              _s(row['author_role']).toLowerCase() == 'player',
        )
        .toList();

    final coachEntry = coachDaily.isEmpty ? null : coachDaily.first;
    final playerEntry = playerDaily.isEmpty ? null : playerDaily.first;

    var coachRating = _i(coachEntry?['rating']);
    var selfRating = _i(playerEntry?['rating']);
    var attendance = '';

    final eventTitles = <String>[];

    for (final event in day.events) {
      final id = _i(event['id'] ?? event['event_id']);
      final title = _s(event['title']);

      eventTitles.add(title.isEmpty ? 'Тренировка' : title);

      if (coachRating <= 0) {
        coachRating = _i(coachByEvent[id]?['rating']);
      }

      if (selfRating <= 0) {
        selfRating = _i(selfByEvent[id]?['rating']);
      }

      if (attendance.isEmpty) {
        attendance = _attendance(attendanceByEvent[id]);
      }
    }

    final coachNote = _s(coachEntry?['note']);
    final playerNote = _s(playerEntry?['note']);

    final meta = <String>[
      if (eventTitles.isNotEmpty) eventTitles.take(2).join(' · '),
      if (day.matches.isNotEmpty) '${day.matches.length} матч.',
      if (day.tests.isNotEmpty) '${day.tests.length} тест.',
    ];

    final hasWarning = attendance == 'Отсутствовал' ||
        attendance == 'Травма';

    return Container(
      padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: hasWarning
              ? PpColors.amber.withOpacity(.22)
              : PpColors.line.withOpacity(.82),
          width: .7,
        ),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 48,
            padding: const EdgeInsets.symmetric(vertical: 7),
            decoration: BoxDecoration(
              color: PpColors.soft,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Column(
              children: [
                Text(
                  DateFormat('dd').format(day.date),
                  style: PpText.value(16),
                ),
                const SizedBox(height: 2),
                Text(
                  DateFormat('MM').format(day.date),
                  style: PpText.caption(size: 9.8),
                ),
                const SizedBox(height: 3),
                Text(
                  _weekday(day.date.weekday),
                  style: PpText.caption(
                    size: 9.2,
                    color: PpColors.greenDark,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  meta.isEmpty ? 'Запись дневника' : meta.join('  ·  '),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: PpText.body(
                    11.2,
                    color: PpColors.text,
                    weight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 5,
                  runSpacing: 5,
                  children: [
                    if (coachRating > 0)
                      _MiniTag(
                        label: 'Тренер',
                        value: '$coachRating/5',
                      ),
                    if (selfRating > 0)
                      _MiniTag(
                        label: 'Игрок',
                        value: '$selfRating/5',
                      ),
                    if (attendance.isNotEmpty)
                      _MiniTag(
                        label: 'Статус',
                        value: attendance,
                        warning: hasWarning,
                      ),
                    if (playerEntry != null &&
                        _i(playerEntry['mood']) > 0)
                      _MiniTag(
                        label: 'Настроение',
                        value: '${_i(playerEntry['mood'])}/5',
                      ),
                    if (playerEntry != null &&
                        _i(playerEntry['rpe']) > 0)
                      _MiniTag(
                        label: 'RPE',
                        value: '${_i(playerEntry['rpe'])}/10',
                      ),
                  ],
                ),
                if (coachNote.isNotEmpty || playerNote.isNotEmpty) ...[
                  const SizedBox(height: 7),
                  if (coachNote.isNotEmpty)
                    _NoteLine(
                      label: 'Тренер',
                      text: coachNote,
                      accent: true,
                    ),
                  if (playerNote.isNotEmpty)
                    _NoteLine(
                      label: 'Игрок',
                      text: playerNote,
                    ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _NoteLine extends StatelessWidget {
  final String label;
  final String text;
  final bool accent;

  const _NoteLine({
    required this.label,
    required this.text,
    this.accent = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 3),
      child: RichText(
        text: TextSpan(
          style: PpText.body(10.2),
          children: [
            TextSpan(
              text: '$label: ',
              style: PpText.body(
                10.2,
                color: accent
                    ? PpColors.greenDark
                    : PpColors.text,
                weight: FontWeight.w600,
              ),
            ),
            TextSpan(text: text),
          ],
        ),
      ),
    );
  }
}

class _MiniTag extends StatelessWidget {
  final String label;
  final String value;
  final bool warning;

  const _MiniTag({
    required this.label,
    required this.value,
    this.warning = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = warning ? PpColors.amberSoft : Colors.white;
    final border = warning
        ? PpColors.amber.withOpacity(.22)
        : PpColors.line;
    final accent =
        warning ? PpColors.amber : PpColors.greenDark;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(8),

      ),
      child: RichText(
        text: TextSpan(
          children: [
            TextSpan(
              text: '$label ',
              style: PpText.caption(size: 9.2),
            ),
            TextSpan(
              text: value,
              style: PpText.body(
                9.5,
                color: accent,
                weight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _TestingSummary extends StatelessWidget {
  final PlayerProfileSnapshot data;

  const _TestingSummary({required this.data});

  String _s(dynamic value) => '${value ?? ''}'.trim();

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Тестирование',
            subtitle: 'Последние результаты',
          ),
          const SizedBox(height: 9),
          if (data.tests.isEmpty)
            const SizedBox(
              height: 125,
              child: PpEmpty(
                title: 'Нет тестов',
                text: 'Результаты появятся после тестирования.',
              ),
            )
          else
            ...data.tests.take(7).map(
                  (test) => Container(
                    constraints: const BoxConstraints(minHeight: 38),
                    decoration: const BoxDecoration(
                      border: Border(
                        bottom: BorderSide(
                          color: PpColors.line,
                          width: .55,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Expanded(
                          child: Text(
                            _s(test['test_name']).isEmpty
                                ? 'Тест'
                                : _s(test['test_name']),
                            style: PpText.body(
                              10.5,
                              color: PpColors.text,
                              weight: FontWeight.w500,
                            ),
                          ),
                        ),
                        Text(
                          '${_s(test['value'] ?? test['result'])}'
                          '${_s(test['unit']).isEmpty ? '' : ' ${_s(test['unit'])}'}',
                          style: PpText.body(
                            10.5,
                            color: PpColors.text,
                            weight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ],
      ),
    );
  }
}

class _SeasonSummary extends StatelessWidget {
  final PlayerProfileSnapshot data;

  const _SeasonSummary({required this.data});

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Сводка дневника',
            subtitle: 'Статистика текущего профиля',
          ),
          const SizedBox(height: 9),
          _line('Мероприятия', '${data.trainings.length}'),
          _line('Матчи', '${data.matches.length}'),
          _line('Оценки тренера', '${data.coachRatings.length}'),
          _line(
            'Самооценки',
            '${data.selfAssessments.length + data.diaryEntries.where((row) => '${row['author_role']}'.toLowerCase() == 'player' && '${row['rating'] ?? 0}' != '0').length}',
          ),
          _line('Дневные записи', '${data.diaryEntries.length}'),
          _line('Тесты', '${data.tests.length}'),
          _line(
            'Посещаемость',
            data.attendance.isEmpty
                ? '—'
                : '${data.attendancePercent}%',
          ),
        ],
      ),
    );
  }

  Widget _line(String label, String value) {
    return Container(
      constraints: const BoxConstraints(minHeight: 38),
      decoration: const BoxDecoration(),
      child: Row(
        children: [
          Expanded(child: Text(label, style: PpText.body(10.5))),
          Text(
            value,
            style: PpText.body(
              10.5,
              color: PpColors.text,
              weight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _SquareImage extends StatelessWidget {
  final String url;
  final String fallback;
  final double size;

  const _SquareImage({
    required this.url,
    required this.fallback,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),

      ),
      child: url.isEmpty
          ? Center(
              child: Text(
                fallback,
                style: PpText.title(size * .27),
              ),
            )
          : Image.network(
              url,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Center(
                child: Text(
                  fallback,
                  style: PpText.title(size * .27),
                ),
              ),
            ),
    );
  }
}

class _ClubLogo extends StatelessWidget {
  final String url;
  final double size;

  const _ClubLogo({
    required this.url,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(9),

      ),
      child: Image.network(
        url,
        fit: BoxFit.contain,
        errorBuilder: (_, __, ___) => Center(
          child: Text(
            'ST',
            style: PpText.caption(
              color: PpColors.greenDark,
            ),
          ),
        ),
      ),
    );
  }
}

String _initials(String name) {
  final parts = name
      .trim()
      .split(RegExp(r'\s+'))
      .where((item) => item.isNotEmpty)
      .toList();

  if (parts.isEmpty) return 'И';

  if (parts.length == 1) {
    return parts.first.substring(0, 1).toUpperCase();
  }

  return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
}
