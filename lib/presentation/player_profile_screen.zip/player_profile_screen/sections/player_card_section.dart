import 'package:flutter/material.dart';

import '../export/player_card_preview.dart';
import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerCardSection extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? session;

  const PlayerCardSection({
    super.key,
    required this.data,
    this.session,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 28),
        children: [
          PpSurface(
            bordered: false,
            elevated: true,
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Карточка игрока', style: PpText.title(18)),
                const SizedBox(height: 4),
                Text(
                  'Краткая спортивная визитка: профиль, форма, '
                  'посещаемость, матчи и данные трекера.',
                  style: PpText.body(10.8),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    const _BrandDot(size: 7),
                    const SizedBox(width: 7),
                    Expanded(
                      child: Text(
                        'Все основные данные собраны на одном экране — '
                        'без настройки состава отчёта.',
                        style: PpText.body(
                          10.3,
                          color: PpColors.greenDark,
                          weight: FontWeight.w500,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 10),
          PlayerCardPreview(
            data: data,
            session: session,
          ),
        ],
      ),
    );
  }
}

class _BrandDot extends StatelessWidget {
  final double size;

  const _BrandDot({this.size = 6});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        color: PpColors.green,
        shape: BoxShape.circle,
      ),
    );
  }
}
