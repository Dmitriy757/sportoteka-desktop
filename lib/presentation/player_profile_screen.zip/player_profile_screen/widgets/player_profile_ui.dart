import 'dart:ui' show FontFeature;

import 'package:flutter/material.dart';
import 'package:sportoteka/core/theme/app_typography.dart';

class PpColors {
  static const bg = Colors.white;
  static const panel = Colors.white;
  static const soft = Color(0xFFF7F8F7);
  static const soft2 = Color(0xFFF2F4F2);
  static const line = Color(0xFFE9ECEA);
  static const text = Color(0xFF0B0F14);
  static const muted = Color(0xFF5F6670);
  static const muted2 = Color(0xFF8A9099);

  static const green = Color(0xFF00A750);
  static const greenDark = Color(0xFF067A46);
  static const greenSoft = Color(0xFFF3FAF6);
  static const greenSoft2 = Color(0xFFF8FEFA);
  static const greenBorder = Color(0xFFD7F0E2);

  static const red = Color(0xFFD92D20);
  static const redSoft = Color(0xFFFFF1F1);
  static const amber = Color(0xFFF59E0B);
  static const amberSoft = Color(0xFFFFF7E8);
}

class PpText {
  static TextStyle title(double size) => AppTypography.custom(
        size: size,
        weight: FontWeight.w600,
        color: PpColors.text,
        height: 1.18,
        letterSpacing: 0,
        features: const <FontFeature>[FontFeature.tabularFigures()],
      );

  static TextStyle body(
    double size, {
    Color color = PpColors.muted,
    FontWeight weight = FontWeight.w400,
  }) =>
      AppTypography.custom(
        size: size,
        weight: weight,
        color: color,
        height: 1.32,
        letterSpacing: 0,
      );

  static TextStyle value(double size) => AppTypography.custom(
        size: size,
        weight: FontWeight.w600,
        color: PpColors.text,
        height: 1.12,
        letterSpacing: 0,
        features: const <FontFeature>[FontFeature.tabularFigures()],
      );

  static TextStyle caption({
    double size = 10.6,
    Color color = PpColors.muted2,
  }) =>
      AppTypography.custom(
        size: size,
        weight: FontWeight.w500,
        color: color,
        height: 1.18,
        letterSpacing: 0,
      );
}

class PpSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final Color color;
  final double radius;
  final bool bordered;
  final bool elevated;

  const PpSurface({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.color = PpColors.panel,
    this.radius = 12,
    this.bordered = false,
    this.elevated = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(radius),
        border: bordered
            ? Border.all(
                color: color == PpColors.greenSoft ||
                        color == PpColors.greenSoft2
                    ? PpColors.greenBorder
                    : PpColors.line.withOpacity(.78),
                width: .75,
              )
            : null,
        boxShadow: elevated
            ? <BoxShadow>[
                BoxShadow(
                  color: Colors.black.withOpacity(.02),
                  blurRadius: 18,
                  spreadRadius: -14,
                  offset: const Offset(0, 8),
                ),
              ]
            : null,
      ),
      child: child,
    );
  }
}

class PpSectionTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget? trailing;

  const PpSectionTitle({
    super.key,
    required this.title,
    this.subtitle,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Container(
            width: 7,
            height: 7,
            decoration: const BoxDecoration(
              color: PpColors.green,
              shape: BoxShape.circle,
            ),
          ),
        ),
        const SizedBox(width: 9),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: PpText.title(14.2)),
              if (subtitle != null) ...[
                const SizedBox(height: 3),
                Text(subtitle!, style: PpText.body(10.8)),
              ],
            ],
          ),
        ),
        if (trailing != null) ...[
          const SizedBox(width: 10),
          trailing!,
        ],
      ],
    );
  }
}

class PpMetric extends StatelessWidget {
  final String label;
  final String value;
  final String? note;

  const PpMetric({
    super.key,
    required this.label,
    required this.value,
    this.note,
  });

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      color: PpColors.soft,
      padding: const EdgeInsets.fromLTRB(12, 11, 12, 11),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Row(
            children: [
              Container(
                width: 5,
                height: 5,
                decoration: const BoxDecoration(
                  color: PpColors.green,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 7),
              Expanded(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: PpText.caption(),
                ),
              ),
            ],
          ),
          const SizedBox(height: 7),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: PpText.value(17),
          ),
          if (note != null) ...[
            const SizedBox(height: 3),
            Text(
              note!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: PpText.body(9.8),
            ),
          ],
        ],
      ),
    );
  }
}

class PpActionRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  final bool danger;

  const PpActionRow({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final active = onTap != null;
    final accent = danger ? PpColors.red : PpColors.green;

    return Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(10),
      child: InkWell(
        borderRadius: BorderRadius.circular(10),
        onTap: onTap,
        child: Opacity(
          opacity: active ? 1 : .48,
          child: Container(
            constraints: const BoxConstraints(minHeight: 52),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
            decoration: BoxDecoration(
              color: danger ? PpColors.redSoft : PpColors.soft,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: danger
                    ? PpColors.red.withOpacity(.12)
                    : PpColors.line.withOpacity(.78),
                width: .7,
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: accent,
                    shape: BoxShape.circle,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: PpText.body(
                          11.8,
                          color: danger ? PpColors.red : PpColors.text,
                          weight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(subtitle, style: PpText.body(10.2)),
                    ],
                  ),
                ),
                if (active)
                  Text(
                    'Открыть',
                    style: PpText.caption(
                      size: 9.8,
                      color: danger
                          ? PpColors.red
                          : PpColors.greenDark,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


class _PpBrandDot extends StatelessWidget {
  final double size;
  final double opacity;

  const _PpBrandDot({
    required this.size,
    this.opacity = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Opacity(
      opacity: opacity,
      child: Container(
        width: size,
        height: size,
        decoration: const BoxDecoration(
          color: PpColors.green,
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}

class PpEmpty extends StatelessWidget {
  final String title;
  final String text;
  final IconData? icon;

  const PpEmpty({
    super.key,
    required this.title,
    required this.text,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  _PpBrandDot(size: 5, opacity: .34),
                  SizedBox(width: 5),
                  _PpBrandDot(size: 6, opacity: .62),
                  SizedBox(width: 5),
                  _PpBrandDot(size: 7),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                title,
                style: PpText.title(13.5),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 5),
              Text(
                text,
                textAlign: TextAlign.center,
                style: PpText.body(10.8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
