import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/player_profile_models.dart';
import '../widgets/player_profile_ui.dart';

class PlayerCardPreview extends StatelessWidget {
  final PlayerProfileSnapshot data;
  final PlayerProfileSession? session;

  const PlayerCardPreview({
    super.key,
    required this.data,
    this.session,
  });

  String _s(dynamic value) => '${value ?? ''}'.trim();

  String _name() {
    final full = _s(
      data.player['full_name'] ??
          data.player['fullName'] ??
          data.player['name'],
    );
    if (full.isNotEmpty) return full;

    final last = _s(
      data.player['last_name'] ??
          data.player['lastName'] ??
          data.player['surname'],
    );
    final first = _s(
      data.player['first_name'] ??
          data.player['firstName'],
    );

    final value = '$last $first'.trim();
    return value.isEmpty ? 'Игрок' : value;
  }

  String _photo() {
    final value = _s(
      data.player['photo'] ??
          data.player['photo_url'] ??
          data.player['avatar'] ??
          data.player['avatar_url'],
    );

    if (value.isEmpty || value == 'null') return '';
    if (value.startsWith('http://') ||
        value.startsWith('https://')) {
      return value;
    }

    final clean =
        value.startsWith('/') ? value.substring(1) : value;
    return 'https://sportotekaapp.ru/$clean';
  }

  String _team() => _s(
        data.player['team_name'] ??
            data.player['teamName'],
      );

  String _position() => _s(
        data.player['position'] ??
            data.player['amplua'] ??
            data.player['player_position'],
      );

  String _number() => _s(
        data.player['number'] ??
            data.player['shirt_number'] ??
            data.player['jersey_number'],
      );

  String _height() {
    final value = _s(data.player['height']);
    return value.isEmpty ? '—' : '$value см';
  }

  String _weight() {
    final value = _s(data.player['weight']);
    return value.isEmpty ? '—' : '$value кг';
  }

  int _presentPercent() => data.attendancePercent;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _IdentityCard(
          name: _name(),
          photo: _photo(),
          team: _team(),
          position: _position(),
          number: _number(),
          rating: data.compositeRating,
        ),
        const SizedBox(height: 10),
        _MainStats(
          rating: data.compositeRating,
          attendance: _presentPercent(),
          matches: data.matches.length,
          tests: data.tests.length,
          sessions: data.sessions.length,
        ),
        const SizedBox(height: 10),
        LayoutBuilder(
          builder: (context, constraints) {
            final profile = _ProfileFacts(
              height: _height(),
              weight: _weight(),
              position: _position(),
              number: _number(),
              coachRating: data.coachRatingAverage,
              selfRating: data.selfRatingAverage,
            );

            final tracker = _TrackerSummary(
              session: session,
              maxHrSession: data.trackerMaxHrSession,
              restHrSession: data.trackerRestHrSession,
            );

            if (constraints.maxWidth >= 820) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(child: profile),
                  const SizedBox(width: 10),
                  Expanded(child: tracker),
                ],
              );
            }

            return Column(
              children: [
                profile,
                const SizedBox(height: 10),
                tracker,
              ],
            );
          },
        ),
        const SizedBox(height: 10),
        _RecentHighlights(data: data),
      ],
    );
  }
}

class _IdentityCard extends StatelessWidget {
  final String name;
  final String photo;
  final String team;
  final String position;
  final String number;
  final int rating;

  const _IdentityCard({
    required this.name,
    required this.photo,
    required this.team,
    required this.position,
    required this.number,
    required this.rating,
  });

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      bordered: false,
      elevated: true,
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 12),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final compact = constraints.maxWidth < 580;

          final identity = Row(
            children: [
              _PlayerPhoto(
                url: photo,
                name: name,
                size: compact ? 58 : 68,
              ),
              const SizedBox(width: 11),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PpText.title(
                        compact ? 16.5 : 18.5,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      [
                        if (team.isNotEmpty) team,
                        if (position.isNotEmpty) position,
                        if (number.isNotEmpty) '№ $number',
                      ].isEmpty
                          ? 'Игрок Sportoteka'
                          : [
                              if (team.isNotEmpty) team,
                              if (position.isNotEmpty) position,
                              if (number.isNotEmpty) '№ $number',
                            ].join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: PpText.body(10.8),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: const [
                        _Dot(size: 7),
                        SizedBox(width: 6),
                        TextLabel('SPORTOTEKA PLAYER CARD'),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          );

          final score = Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 10,
            ),
            decoration: BoxDecoration(
              color: PpColors.greenSoft2,
              borderRadius: BorderRadius.circular(11),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  rating > 0 ? '$rating' : '—',
                  style: PpText.value(26),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Рейтинг',
                      style: PpText.caption(),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      '/ 100',
                      style: PpText.body(
                        10,
                        color: PpColors.greenDark,
                        weight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          );

          if (compact) {
            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                identity,
                const SizedBox(height: 10),
                Align(
                  alignment: Alignment.centerLeft,
                  child: score,
                ),
              ],
            );
          }

          return Row(
            children: [
              Expanded(child: identity),
              const SizedBox(width: 12),
              score,
            ],
          );
        },
      ),
    );
  }
}

class TextLabel extends StatelessWidget {
  final String text;

  const TextLabel(this.text, {super.key});

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: PpText.caption(
        size: 9.3,
        color: PpColors.greenDark,
      ),
    );
  }
}

class _MainStats extends StatelessWidget {
  final int rating;
  final int attendance;
  final int matches;
  final int tests;
  final int sessions;

  const _MainStats({
    required this.rating,
    required this.attendance,
    required this.matches,
    required this.tests,
    required this.sessions,
  });

  @override
  Widget build(BuildContext context) {
    final items = <({String label, String value})>[
      (
        label: 'Рейтинг',
        value: rating > 0 ? '$rating' : '—',
      ),
      (
        label: 'Посещаемость',
        value: '$attendance%',
      ),
      (
        label: 'Матчи',
        value: '$matches',
      ),
      (
        label: 'Тесты',
        value: '$tests',
      ),
      (
        label: 'GPS сессии',
        value: '$sessions',
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final columns = constraints.maxWidth >= 980
            ? 5
            : constraints.maxWidth >= 650
                ? 3
                : 2;

        final width =
            (constraints.maxWidth - (columns - 1) * 8) / columns;

        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: items
              .map(
                (item) => SizedBox(
                  width: width,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(
                      10,
                      10,
                      10,
                      10,
                    ),
                    decoration: BoxDecoration(
                      color: PpColors.soft,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            const _Dot(),
                            const SizedBox(width: 6),
                            Expanded(
                              child: Text(
                                item.label,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: PpText.caption(),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        Text(
                          item.value,
                          style: PpText.value(16),
                        ),
                      ],
                    ),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _ProfileFacts extends StatelessWidget {
  final String height;
  final String weight;
  final String position;
  final String number;
  final double coachRating;
  final double selfRating;

  const _ProfileFacts({
    required this.height,
    required this.weight,
    required this.position,
    required this.number,
    required this.coachRating,
    required this.selfRating,
  });

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      bordered: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Профиль игрока',
            subtitle: 'Основные спортивные данные',
          ),
          const SizedBox(height: 8),
          _Fact(
            label: 'Амплуа',
            value: position.isEmpty ? '—' : position,
          ),
          _Fact(
            label: 'Игровой номер',
            value: number.isEmpty ? '—' : number,
          ),
          _Fact(label: 'Рост', value: height),
          _Fact(label: 'Вес', value: weight),
          _Fact(
            label: 'Оценка тренера',
            value: coachRating > 0
                ? coachRating.toStringAsFixed(1)
                : '—',
          ),
          _Fact(
            label: 'Самооценка',
            value: selfRating > 0
                ? selfRating.toStringAsFixed(1)
                : '—',
            last: true,
          ),
        ],
      ),
    );
  }
}

class _TrackerSummary extends StatelessWidget {
  final PlayerProfileSession? session;
  final PlayerProfileSession? maxHrSession;
  final PlayerProfileSession? restHrSession;

  const _TrackerSummary({
    required this.session,
    required this.maxHrSession,
    required this.restHrSession,
  });

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      bordered: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Форма и трекер',
            subtitle: 'Последние доступные GPS / Polar показатели',
          ),
          const SizedBox(height: 8),
          _Fact(
            label: 'Дистанция',
            value: session == null
                ? '—'
                : '${(session!.distanceM / 1000).toStringAsFixed(2)} км',
          ),
          _Fact(
            label: 'Макс. скорость',
            value: session == null ||
                    session!.maxSpeedKmh <= 0
                ? '—'
                : '${session!.maxSpeedKmh.toStringAsFixed(1)} км/ч',
          ),
          _Fact(
            label: 'Спринты',
            value: session == null
                ? '—'
                : '${session!.sprintCount}',
          ),
          _Fact(
            label: 'Средний пульс',
            value: session == null || session!.avgHr <= 0
                ? '—'
                : '${session!.avgHr.round()} уд/мин',
          ),
          _Fact(
            label: 'HR max',
            value: maxHrSession == null
                ? '—'
                : '${maxHrSession!.maxHr.round()} уд/мин',
          ),
          _Fact(
            label: 'Пульс покоя',
            value: restHrSession == null
                ? '—'
                : '${restHrSession!.minHr.round()} уд/мин',
            last: true,
          ),
        ],
      ),
    );
  }
}

class _Fact extends StatelessWidget {
  final String label;
  final String value;
  final bool last;

  const _Fact({
    required this.label,
    required this.value,
    this.last = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 7,
        bottom: last ? 0 : 7,
      ),
      child: Row(
        children: [
          const _Dot(size: 5),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              label,
              style: PpText.body(10.6),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: PpText.body(
              10.6,
              color: PpColors.text,
              weight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

class _RecentHighlights extends StatelessWidget {
  final PlayerProfileSnapshot data;

  const _RecentHighlights({required this.data});

  @override
  Widget build(BuildContext context) {
    return PpSurface(
      bordered: false,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const PpSectionTitle(
            title: 'Последние события',
            subtitle:
                'Короткая лента активности игрока',
          ),
          const SizedBox(height: 8),
          if (data.timeline.isEmpty)
            const SizedBox(
              height: 140,
              child: PpEmpty(
                title: 'Событий пока нет',
                text:
                    'Здесь появятся тренировки, матчи и тестирование.',
              ),
            )
          else
            ...data.timeline.take(8).map(
                  (item) => Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 7),
                    child: Row(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding:
                              const EdgeInsets.only(top: 5),
                          child: _Dot(
                            color:
                                _colorForItem(item),
                            size: 7,
                          ),
                        ),
                        const SizedBox(width: 9),
                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Text(
                                item.title,
                                style: PpText.body(
                                  11,
                                  color: PpColors.text,
                                  weight: FontWeight.w600,
                                ),
                              ),
                              if (item.subtitle
                                  .trim()
                                  .isNotEmpty) ...[
                                const SizedBox(height: 2),
                                Text(
                                  item.subtitle,
                                  style: PpText.body(10),
                                ),
                              ],
                            ],
                          ),
                        ),
                        if (item.date != null) ...[
                          const SizedBox(width: 8),
                          Text(
                            DateFormat('dd.MM')
                                .format(item.date!),
                            style: PpText.caption(),
                          ),
                        ],
                      ],
                    ),
                  ),
                ),
        ],
      ),
    );
  }

  Color _colorForItem(PlayerTimelineItem item) {
    final value =
        '${item.type} ${item.title}'.toLowerCase();

    if (value.contains('мед') ||
        value.contains('травм')) {
      return PpColors.red;
    }

    if (value.contains('тест')) {
      return PpColors.amber;
    }

    return PpColors.green;
  }
}

class _PlayerPhoto extends StatelessWidget {
  final String url;
  final String name;
  final double size;

  const _PlayerPhoto({
    required this.url,
    required this.name,
    required this.size,
  });

  @override
  Widget build(BuildContext context) {
    final initials = _initials(name);

    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: PpColors.soft,
        borderRadius: BorderRadius.circular(11),
      ),
      child: url.isEmpty
          ? Center(
              child: Text(
                initials,
                style: PpText.title(size * .27),
              ),
            )
          : Image.network(
              url,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Center(
                child: Text(
                  initials,
                  style: PpText.title(size * .27),
                ),
              ),
            ),
    );
  }
}

class _Dot extends StatelessWidget {
  final Color color;
  final double size;

  const _Dot({
    this.color = PpColors.green,
    this.size = 6,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }
}

String _initials(String name) {
  final parts = name
      .trim()
      .split(RegExp(r'\s+'))
      .where((part) => part.isNotEmpty)
      .toList();

  if (parts.isEmpty) return 'И';
  if (parts.length == 1) {
    return parts.first.substring(0, 1).toUpperCase();
  }

  return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
}
