import 'dart:async';
import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;


DateTime? _trackerParseServerInstant(dynamic value) {
  final raw = '${value ?? ''}'.trim();
  if (raw.isEmpty || raw == 'null') return null;
  final normalized = raw.replaceFirst(' ', 'T');
  final hasZone = RegExp(r'(Z|[+-]\d{2}:?\d{2})$', caseSensitive: false)
      .hasMatch(normalized);
  if (hasZone) return DateTime.tryParse(normalized)?.toUtc();

  final naive = DateTime.tryParse(normalized);
  if (naive == null) return null;
  // Серверные MySQL-строки без timezone считаем UTC.
  return DateTime.utc(
    naive.year,
    naive.month,
    naive.day,
    naive.hour,
    naive.minute,
    naive.second,
    naive.millisecond,
    naive.microsecond,
  );
}

DateTime? _trackerMoscowDateTime(dynamic value) {
  final instant = _trackerParseServerInstant(value);
  if (instant == null) return null;
  final moscow = instant.add(const Duration(hours: 3));
  // Возвращаем wall-clock Moscow без зависимости от timezone устройства.
  return DateTime(
    moscow.year,
    moscow.month,
    moscow.day,
    moscow.hour,
    moscow.minute,
    moscow.second,
    moscow.millisecond,
    moscow.microsecond,
  );
}

DateTime _trackerMoscowFromEpochMs(int millisecondsSinceEpoch) {
  final moscow = DateTime.fromMillisecondsSinceEpoch(
    millisecondsSinceEpoch,
    isUtc: true,
  ).add(const Duration(hours: 3));
  return DateTime(
    moscow.year,
    moscow.month,
    moscow.day,
    moscow.hour,
    moscow.minute,
    moscow.second,
    moscow.millisecond,
    moscow.microsecond,
  );
}


class PlayerTrainingNotificationsPanel extends StatefulWidget {
  const PlayerTrainingNotificationsPanel({
    super.key,
    required this.teamId,
    this.apiBaseUrl = 'https://sportotekaapp.ru/api/tracker',
    this.onOpenAnalytics,
    this.onOpenReport,
    this.playerDirectory = const <int, Map<String, String>>{},
  });

  final int teamId;
  final String apiBaseUrl;
  final ValueChanged<Map<String, dynamic>>? onOpenAnalytics;
  final ValueChanged<Map<String, dynamic>>? onOpenReport;
  /// Справочник состава: playerId -> {name, avatar}. Используется, когда API
  /// возвращает техническое имя вроде «Игрок 181».
  final Map<int, Map<String, String>> playerDirectory;

  @override
  State<PlayerTrainingNotificationsPanel> createState() => _PlayerTrainingNotificationsPanelState();
}

class _PlayerTrainingNotificationsPanelState extends State<PlayerTrainingNotificationsPanel> {
  static const _green = Color(0xFF00A750);
  static const _greenSoft = Color(0xFFF3FAF6);
  static const _text = Color(0xFF101828);
  static const _muted = Color(0xFF6B746E);
  static const _line = Color(0xFFE1E5E2);
  static const _soft = Color(0xFFF8F9F8);
  static const _red = Color(0xFFDC2626);
  static const _blue = Color(0xFF2563EB);
  static const _orange = Color(0xFFF59E0B);

  Timer? _timer;
  bool _loading = true;
  String? _error;
  List<Map<String, dynamic>> _live = const [];
  List<Map<String, dynamic>> _events = const [];
  Map<int, Map<String, String>> _resolvedDirectory = const <int, Map<String, String>>{};
  int _eventDayOffset = 0;

  @override
  void initState() {
    super.initState();
    _resolvedDirectory = Map<int, Map<String, String>>.from(widget.playerDirectory);
    _load();
    _timer = Timer.periodic(const Duration(seconds: 5), (_) => _load(silent: true));
  }

  @override
  void didUpdateWidget(covariant PlayerTrainingNotificationsPanel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.playerDirectory != widget.playerDirectory) {
      _resolvedDirectory = <int, Map<String, String>>{..._resolvedDirectory, ...widget.playerDirectory};
    }
    if (oldWidget.teamId != widget.teamId || oldWidget.apiBaseUrl != widget.apiBaseUrl) _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    if (widget.teamId <= 0) return;
    if (!silent && mounted) setState(() { _loading = true; _error = null; });
    try {
      final liveUri = Uri.parse('${widget.apiBaseUrl}/player_get_live_state.php').replace(queryParameters: {
        'team_id': '${widget.teamId}', 'personal_session': '1', 'active_only': '1', 'limit': '50',
      });
      final eventsUri = Uri.parse('${widget.apiBaseUrl}/player_get_training_notifications.php').replace(queryParameters: {
        'team_id': '${widget.teamId}', 'limit': '100', 'days': '7',
      });
      final playersUri = Uri.parse('${widget.apiBaseUrl}/get_tracker_players.php').replace(queryParameters: {
        'team_id': '${widget.teamId}',
      });
      final responses = await Future.wait([
        http.get(liveUri).timeout(const Duration(seconds: 10)),
        http.get(eventsUri).timeout(const Duration(seconds: 10)),
        http.get(playersUri).timeout(const Duration(seconds: 10)),
      ]);
      final liveJson = _decode(responses[0].body);
      if (liveJson['success'] == false) throw Exception(liveJson['message'] ?? 'Ошибка Live API');
      final eventJson = _decode(responses[1].body);
      final playersJson = _decode(responses[2].body);
      final directory = <int, Map<String, String>>{...widget.playerDirectory};
      final playersRaw = playersJson['players'] as List? ?? playersJson['items'] as List? ?? const [];
      for (final raw in playersRaw.whereType<Map>()) {
        final item = Map<String, dynamic>.from(raw);
        final id = _parsePositiveInt(item['id'] ?? item['player_id']);
        final userId = _parsePositiveInt(item['user_id'] ?? item['owner_user_id']);
        final name = _readText(item, const ['player_name', 'full_name', 'name'], fallback: '');
        final first = _readText(item, const ['first_name', 'player_first_name'], fallback: '');
        final last = _readText(item, const ['last_name', 'surname', 'player_last_name'], fallback: '');
        final resolvedName = (last.isNotEmpty || first.isNotEmpty)
            ? '$last $first'.trim()
            : name;
        final avatar = _readText(item, const ['avatar_url', 'avatar', 'photo_url', 'user_photo', 'photo'], fallback: '');
        final value = <String, String>{'name': resolvedName, 'avatar': avatar};
        if (id != null) directory[id] = value;
        if (userId != null) directory[userId] = value;
      }
      final liveRaw = liveJson['sessions'] as List? ??
          liveJson['live_sessions'] as List? ??
          liveJson['active_sessions'] as List? ??
          liveJson['items'] as List? ??
          const [];
      final eventsRaw = eventJson['notifications'] as List? ?? eventJson['items'] as List? ?? const [];

      final baseLive = liveRaw
          .whereType<Map>()
          .map((e) => Map<String, dynamic>.from(e))
          .where(_isActivePersonalLive)
          .toList();

      // player_get_live_state.php не во всех версиях API возвращает историю Polar.
      // Догружаем её отдельно для каждой активной сессии, чтобы карточка и график
      // появлялись сразу, даже когда основной Live-ответ содержит только session_id.
      final live = await Future.wait(baseLive.map(_enrichLiveRow));
      final events = eventsRaw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
      if (!mounted) return;
      setState(() { _resolvedDirectory = directory; _live = live; _events = events; _loading = false; _error = null; });
    } catch (e) {
      if (!mounted) return;
      setState(() { _loading = false; _error = e.toString(); });
    }
  }



  Map<String, dynamic> _flattenLivePayload(Map<String, dynamic> source) {
    final row = Map<String, dynamic>.from(source);

    void mergeDynamic(dynamic raw) {
      if (raw == null) return;
      dynamic value = raw;
      if (value is String && value.trim().isNotEmpty) {
        try {
          value = jsonDecode(value);
        } catch (_) {
          return;
        }
      }
      if (value is Map) {
        final map = Map<String, dynamic>.from(value);
        for (final entry in map.entries) {
          final current = row[entry.key];
          if (current == null || '$current'.trim().isEmpty || '$current' == '0') {
            row[entry.key] = entry.value;
          }
        }
        for (final nestedKey in const ['snapshot', 'metrics', 'heart_rate', 'polar', 'latest', 'live']) {
          mergeDynamic(map[nestedKey]);
        }
      }
    }

    for (final key in const [
      'snapshot',
      'snapshot_json',
      'analysis',
      'analysis_json',
      'metrics',
      'metrics_json',
      'live_data',
      'latest_data',
    ]) {
      mergeDynamic(row[key]);
    }

    // Серверные версии используют разные названия текущего HR.
    row['last_heart_rate_bpm'] ??= row['current_hr'];
    row['last_heart_rate_bpm'] ??= row['heart_rate'];
    row['last_heart_rate_bpm'] ??= row['last_hr'];
    row['last_heart_rate_bpm'] ??= row['polar_bpm'];
    row['heart_rate_samples'] ??= row['hr_history'];
    row['heart_rate_samples'] ??= row['polar_history'];
    row['heart_rate_samples'] ??= row['samples'];

    return row;
  }

  Future<Map<String, dynamic>> _enrichLiveRow(Map<String, dynamic> source) async {
    final row = _flattenLivePayload(source);
    final existing = _heartRateSamples(row);
    final currentHr = _int(row, const [
      'last_heart_rate_bpm',
      'heart_rate_bpm',
      'bpm',
      'current_bpm',
      'latest_bpm',
      'hr',
    ]);
    if (existing.isNotEmpty && currentHr > 0) return row;

    final liveId = _int(row, const ['live_session_id', 'id', 'tracker_live_session_id']);
    final sessionId = _int(row, const ['session_id', 'final_session_id', 'tracker_session_id']);
    if (liveId <= 0 && sessionId <= 0) return row;

    try {
      final query = <String, String>{
        'team_id': '${widget.teamId}',
        if (liveId > 0) 'live_session_id': '$liveId',
        if (sessionId > 0) 'session_id': '$sessionId',
        // Не кэшировать Live-график CDN/браузером.
        '_ts': '${DateTime.now().millisecondsSinceEpoch}',
      };
      final uri = Uri.parse('${widget.apiBaseUrl}/player_get_session_heart_rate.php')
          .replace(queryParameters: query);
      final response = await http.get(
        uri,
        headers: const {'Cache-Control': 'no-cache'},
      ).timeout(const Duration(seconds: 8));
      if (response.statusCode < 200 || response.statusCode >= 300) return row;

      final json = _decode(response.body);
      if (json['success'] == false) return row;

      final samples = json['samples'] ??
          json['heart_rate_samples'] ??
          json['hr_samples'] ??
          json['points'] ??
          (json['data'] is Map ? (json['data'] as Map)['samples'] : null);
      if (samples is List && samples.isNotEmpty) {
        row['heart_rate_samples'] = samples;
      }

      final summary = json['summary'] is Map
          ? Map<String, dynamic>.from(json['summary'] as Map)
          : <String, dynamic>{};
      final latest = json['last_bpm'] ??
          json['current_bpm'] ??
          json['latest_bpm'] ??
          summary['last_bpm'] ??
          summary['max_bpm'];
      if (_parsePositiveInt(latest) != null) {
        row['last_heart_rate_bpm'] = latest;
      } else if (samples is List && samples.isNotEmpty) {
        final last = samples.last;
        if (last is Map) {
          row['last_heart_rate_bpm'] =
              last['bpm'] ?? last['heart_rate_bpm'] ?? last['value'];
        }
      }

      row['avg_heart_rate_bpm'] =
          json['avg_bpm'] ?? summary['avg_bpm'] ?? row['avg_heart_rate_bpm'];
      row['max_heart_rate_bpm'] =
          json['max_bpm'] ?? summary['max_bpm'] ?? row['max_heart_rate_bpm'];
      row['min_heart_rate_bpm'] =
          json['min_bpm'] ?? summary['min_bpm'] ?? row['min_heart_rate_bpm'];
      row['heart_rate_samples_count'] =
          json['samples_count'] ?? summary['samples_count'] ?? (samples is List ? samples.length : 0);

      if (_heartRateSamples(row).isEmpty && liveId > 0) {
        await _tryLiveHeartRateFallback(row, liveId);
      }
      return row;
    } catch (_) {
      if (liveId > 0) {
        await _tryLiveHeartRateFallback(row, liveId);
      }
      // Live-карточка всё равно должна остаться видимой, даже если endpoint
      // истории Polar временно недоступен.
      return row;
    }
  }

  Future<void> _tryLiveHeartRateFallback(Map<String, dynamic> row, int liveId) async {
    for (final endpoint in const [
      'player_check_session_heart_rate.php',
      'player_get_live_heart_rate.php',
    ]) {
      try {
        final uri = Uri.parse('${widget.apiBaseUrl}/$endpoint').replace(
          queryParameters: {
            'live_session_id': '$liveId',
            'team_id': '${widget.teamId}',
            '_ts': '${DateTime.now().millisecondsSinceEpoch}',
          },
        );
        final response = await http.get(
          uri,
          headers: const {'Cache-Control': 'no-cache'},
        ).timeout(const Duration(seconds: 5));
        if (response.statusCode < 200 || response.statusCode >= 300) continue;
        final json = _decode(response.body);
        final hr = json['heart_rate'] is Map
            ? Map<String, dynamic>.from(json['heart_rate'] as Map)
            : <String, dynamic>{};
        final samples = json['samples'] ?? json['points'] ?? hr['samples'];
        if (samples is List && samples.isNotEmpty) {
          row['heart_rate_samples'] = samples;
        }
        row['last_heart_rate_bpm'] ??=
            json['last_bpm'] ?? hr['last_bpm'] ?? hr['max_bpm'];
        row['avg_heart_rate_bpm'] ??= json['avg_bpm'] ?? hr['avg_bpm'];
        row['max_heart_rate_bpm'] ??= json['max_bpm'] ?? hr['max_bpm'];
        row['heart_rate_samples_count'] ??=
            json['samples_count'] ?? hr['samples_count'];
        if (_int(row, const ['last_heart_rate_bpm', 'current_bpm', 'bpm']) > 0 ||
            _heartRateSamples(row).isNotEmpty) {
          return;
        }
      } catch (_) {}
    }
  }

  @override
  Widget build(BuildContext context) {
    final count = _live.length;
    return Container(
      color: Colors.white,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (_loading)
            const LinearProgressIndicator(color: _green, minHeight: 2),
          if (_error != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 6, 10, 0),
              child: _errorBox(_error!),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
            child: _summaryStrip(),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(10, 2, 10, 6),
            child: Container(
              constraints: const BoxConstraints(minHeight: 32),
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
              color: count > 0 ? _green.withOpacity(.055) : _soft,
              child: Row(
                children: [
                  Container(
                    width: 6,
                    height: 6,
                    decoration: BoxDecoration(
                      color: count > 0 ? _green : _muted,
                      shape: BoxShape.circle,
                    ),
                  ),
                  const SizedBox(width: 7),
                  Expanded(
                    child: Text(
                      count > 0
                          ? 'Live сейчас: $count игрок${_plural(count)}'
                          : 'Сейчас активных личных тренировок нет',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _text,
                        fontWeight: FontWeight.w600,
                        fontSize: 10.4,
                      ),
                    ),
                  ),
                  Text(
                    _lastUpdatedLabel(),
                    style: const TextStyle(
                      color: _muted,
                      fontWeight: FontWeight.w500,
                      fontSize: 9.6,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (!_loading && _error == null && _live.isEmpty)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: _emptyState(),
            ),
          if (_live.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 2, 10, 0),
              child: _liveStrip(_live),
            ),
          if (_events.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 10, 10, 10),
              child: _recentEvents(_events),
            ),
        ],
      ),
    );
  }

  Widget _liveStrip(List<Map<String, dynamic>> rows) {
    return LayoutBuilder(builder: (context, constraints) {
      final width = constraints.maxWidth;
      final cardWidth = width < 560 ? math.max(286.0, width * .94) : width < 980 ? 340.0 : 360.0;
      return SizedBox(
        height: 238,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          physics: const BouncingScrollPhysics(),
          itemCount: rows.length,
          separatorBuilder: (_, __) => const SizedBox(width: 10),
          itemBuilder: (_, index) => SizedBox(width: math.min(cardWidth, width), child: _liveCard(rows[index])),
        ),
      );
    });
  }

  Widget _liveCard(Map<String, dynamic> row) {
    final name = _playerName(row);
    final avatar = _avatarUrl(row);
    final hr = _int(row, const [
      'last_heart_rate_bpm',
      'heart_rate_bpm',
      'bpm',
      'current_bpm',
    ]);
    final duration = _int(row, const [
      'duration_sec',
      'duration_seconds',
      'elapsed_sec',
      'live_duration_sec',
    ]);
    final distance = _num(row, const [
      'total_distance_m',
      'distance_m',
      'distance',
      'session_distance_m',
    ]);
    final speed = _num(row, const [
      'speed_kmh',
      'last_speed_kmh',
      'current_speed_kmh',
    ]);
    final maxSpeed = _num(row, const [
      'max_speed_kmh',
      'top_speed_kmh',
      'max_speed',
    ]);
    final load = _num(row, const ['load_score', 'player_load', 'load']);
    final samples = _heartRateSamples(row);
    final sprintCount = _int(row, const ['sprint_count', 'sprints', 'spr']);

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => _showPlayerDetails(row),
        child: Container(
          padding: const EdgeInsets.fromLTRB(10, 9, 10, 8),
          color: Colors.white,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Container(
                    width: 3,
                    height: 38,
                    decoration: BoxDecoration(
                      color: _green,
                      borderRadius: BorderRadius.circular(99),
                    ),
                  ),
                  const SizedBox(width: 8),
                  _avatar(avatar, size: 38),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _text,
                            fontWeight: FontWeight.w700,
                            fontSize: 12.8,
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          '${_activityLabel(row)} · ${_startTime(row)} · ${_duration(duration)}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _muted,
                            fontWeight: FontWeight.w500,
                            fontSize: 10.4,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _liveStatusText(1),
                ],
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(child: _compactMetric('Дистанция', _meters(distance))),
                  Expanded(child: _compactMetric('Скорость', '${speed.toStringAsFixed(1)} км/ч')),
                  Expanded(
                    child: _compactMetric(
                      'Пульс',
                      hr > 0 ? '$hr bpm' : '—',
                      valueColor: hr > 0 ? _red : _muted,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Row(
                children: [
                  Expanded(child: _compactMetric('Load', load > 0 ? load.toStringAsFixed(0) : '—')),
                  Expanded(child: _compactMetric('Макс.', '${math.max(speed, maxSpeed).toStringAsFixed(1)} км/ч')),
                  Expanded(child: _compactMetric('Спринты', '$sprintCount')),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Text(
                    'Пульс Polar',
                    style: TextStyle(
                      color: _text,
                      fontWeight: FontWeight.w700,
                      fontSize: 11.2,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    hr > 0
                        ? '$hr bpm · ${samples.length} точек'
                        : (_sourceLabel(row).toLowerCase().contains('polar')
                            ? 'ожидаем данные'
                            : 'не подключён'),
                    style: TextStyle(
                      color: hr > 0 ? _red : _muted,
                      fontWeight: FontWeight.w600,
                      fontSize: 9.6,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 5),
              Expanded(child: _HrChart(values: samples, compact: true)),
              const SizedBox(height: 5),
              const Align(
                alignment: Alignment.centerRight,
                child: Text(
                  'Подробнее',
                  style: TextStyle(
                    color: _green,
                    fontWeight: FontWeight.w700,
                    fontSize: 10.4,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }


  Future<Map<String, dynamic>> _loadLatestDetailRow(
    Map<String, dynamic> source,
  ) async {
    final liveId = _int(
      source,
      const ['live_session_id', 'id', 'tracker_live_session_id'],
    );
    if (liveId <= 0) return source;

    try {
      final liveUri = Uri.parse(
        '${widget.apiBaseUrl}/player_get_live_state.php',
      ).replace(queryParameters: {
        'team_id': '${widget.teamId}',
        'live_session_id': '$liveId',
        'active_only': '0',
        'include_finished': '1',
        '_ts': '${DateTime.now().millisecondsSinceEpoch}',
      });
      final response = await http.get(
        liveUri,
        headers: const {'Cache-Control': 'no-cache'},
      ).timeout(const Duration(seconds: 6));
      if (response.statusCode >= 200 && response.statusCode < 300) {
        final json = _decode(response.body);
        final rows = json['sessions'] as List? ??
            json['items'] as List? ??
            const <dynamic>[];
        if (rows.isNotEmpty && rows.first is Map) {
          final merged = <String, dynamic>{
            ...source,
            ...Map<String, dynamic>.from(rows.first as Map),
          };
          return _enrichLiveRow(merged);
        }
      }
    } catch (_) {}

    final enriched = await _enrichLiveRow(source);
    final finalSessionId = _int(
      enriched,
      const ['final_session_id', 'session_id', 'tracker_session_id'],
    );
    if (finalSessionId > 0) {
      enriched['status'] = 'finished';
      enriched['is_live'] = false;
    }
    return enriched;
  }

  Future<void> _showPlayerDetails(Map<String, dynamic> row) async {
    final notifier = ValueNotifier<Map<String, dynamic>>(
      await _loadLatestDetailRow(row),
    );
    Timer? detailTimer;

    Future<void> refreshDetail() async {
      final latest = await _loadLatestDetailRow(notifier.value);
      if (notifier.value != latest) notifier.value = latest;
    }

    detailTimer = Timer.periodic(
      const Duration(seconds: 4),
      (_) => refreshDetail(),
    );

    try {
      await showDialog<void>(
        context: context,
        builder: (dialogContext) {
          return ValueListenableBuilder<Map<String, dynamic>>(
            valueListenable: notifier,
            builder: (context, current, _) {
              final name = _playerName(current);
              final avatar = _avatarUrl(current);
              final hr = _int(current, const [
                'last_heart_rate_bpm',
                'heart_rate_bpm',
                'bpm',
                'current_bpm',
              ]);
              final samples = _heartRateSamples(current);
              final running = _isRowRunning(current);

              return Dialog(
                backgroundColor: Colors.transparent,
                insetPadding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 22,
                ),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 820),
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(20, 18, 20, 18),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.zero,
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x24000000),
                          blurRadius: 16,
                          offset: Offset(0, 12),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(children: [
                          _avatar(avatar, size: 54),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(children: [
                                  Flexible(
                                    child: Text(
                                      name,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: const TextStyle(
                                        color: _text,
                                        fontWeight: FontWeight.w900,
                                        fontSize: 18,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 8,
                                      vertical: 4,
                                    ),
                                    decoration: BoxDecoration(
                                      color: running ? _greenSoft : _soft,
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: running
                                            ? const Color(0xFFB8E8CF)
                                            : _line,
                                      ),
                                    ),
                                    child: Row(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Container(
                                          width: 6,
                                          height: 6,
                                          decoration: BoxDecoration(
                                            color: running ? _green : _muted,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        const SizedBox(width: 5),
                                        Text(
                                          running ? 'LIVE' : 'ЗАВЕРШЕНА',
                                          style: TextStyle(
                                            color: running ? _green : _muted,
                                            fontWeight: FontWeight.w900,
                                            fontSize: 9.6,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ]),
                                const SizedBox(height: 3),
                                Text(
                                  '${_activityLabel(current)} · ${_sourceLabel(current)}',
                                  style: const TextStyle(
                                    color: _muted,
                                    fontWeight: FontWeight.w700,
                                    fontSize: 11.2,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: _soft,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: IconButton(
                              padding: EdgeInsets.zero,
                              onPressed: () =>
                                  Navigator.of(dialogContext).pop(),
                              icon: const Icon(
                                Icons.close_rounded,
                                size: 20,
                                color: _text,
                              ),
                            ),
                          ),
                        ]),
                        const SizedBox(height: 10),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final metricWidth = constraints.maxWidth < 620
                                ? (constraints.maxWidth - 8) / 2
                                : (constraints.maxWidth - 24) / 4;
                            return Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Вид',
                                    _activityLabel(current),
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Начало',
                                    _startTime(current),
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Окончание',
                                    _isRowRunning(current)
                                        ? _endTime(current)
                                        : (_endTime(current) == 'идёт сейчас'
                                            ? 'завершена'
                                            : _endTime(current)),
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Длительность',
                                    _duration(_sessionDuration(current)),
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Дистанция',
                                    _meters(
                                      _num(current, const [
                                        'total_distance_m',
                                        'distance_m',
                                        'distance',
                                      ]),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Скорость',
                                    '${_num(current, const ['speed_kmh', 'last_speed_kmh']).toStringAsFixed(1)} км/ч',
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    running ? 'Текущий пульс' : 'Последний пульс',
                                    hr > 0 ? '$hr уд/мин' : '—',
                                  ),
                                ),
                                SizedBox(
                                  width: metricWidth,
                                  child: _detailMetric(
                                    'Мин./макс. пульс',
                                    _hrExtremesText(samples),
                                  ),
                                ),
                              ],
                            );
                          },
                        ),
                        const SizedBox(height: 8),
                        Container(
                          height: 220,
                          padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFFAFA),
                            borderRadius: BorderRadius.zero,
                            border: Border.all(
                              color: const Color(0xFFFFE1E1),
                            ),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(children: [
                                Container(
                                  width: 28,
                                  height: 28,
                                  decoration: BoxDecoration(
                                    color: const Color(0xFFFFECEC),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Icon(
                                    Icons.favorite_rounded,
                                    color: _red,
                                    size: 16,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        'Пульс Polar',
                                        style: TextStyle(
                                          color: _text,
                                          fontWeight: FontWeight.w900,
                                          fontSize: 12,
                                        ),
                                      ),
                                      Text(
                                        '${samples.length} точек · шкала 0–${_durationMinutes(_sessionDuration(current))} мин',
                                        style: const TextStyle(
                                          color: _muted,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 9.6,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                IconButton(
                                  tooltip: 'Обновить',
                                  onPressed: refreshDetail,
                                  icon: const Icon(
                                    Icons.refresh_rounded,
                                    color: _red,
                                    size: 18,
                                  ),
                                ),
                              ]),
                              const SizedBox(height: 8),
                              Expanded(
                                child: _HrChart(
                                  values: samples,
                                  compact: false,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(children: [
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  foregroundColor: _green,
                                  side: const BorderSide(
                                    color: _green,
                                    width: 1.4,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(11),
                                  ),
                                  textStyle: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 12,
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.of(dialogContext).pop();
                                  widget.onOpenReport?.call(current);
                                },
                                icon: const Icon(
                                  Icons.description_rounded,
                                  size: 18,
                                ),
                                label: const Text('Открыть отчёт'),
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: SizedBox(
                              height: 44,
                              child: FilledButton.icon(
                                style: FilledButton.styleFrom(
                                  backgroundColor: _green,
                                  foregroundColor: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(11),
                                  ),
                                  textStyle: const TextStyle(
                                    fontWeight: FontWeight.w900,
                                    fontSize: 12,
                                  ),
                                ),
                                onPressed: () {
                                  Navigator.of(dialogContext).pop();
                                  widget.onOpenAnalytics?.call(current);
                                },
                                icon: const Icon(
                                  Icons.analytics_rounded,
                                  size: 18,
                                ),
                                label: const Text('Аналитика игрока'),
                              ),
                            ),
                          ),
                        ]),
                      ],
                    ),
                  ),
                ),
              );
            },
          );
        },
      );
    } finally {
      detailTimer.cancel();
      notifier.dispose();
    }
  }

  Widget _recentEvents(List<Map<String, dynamic>> events) {
    final now = DateTime.now();

    DateTime dayForOffset(int offset) =>
        DateTime(now.year, now.month, now.day).subtract(Duration(days: offset));

    bool sameDate(DateTime? a, DateTime b) =>
        a != null &&
        a.year == b.year &&
        a.month == b.month &&
        a.day == b.day;

    DateTime? eventDate(Map<String, dynamic> event) => _parseDate(
          event['ended_at'] ??
              event['stopped_at'] ??
              event['created_at'] ??
              event['event_at'] ??
              event['started_at'],
        );

    final selectedDay = dayForOffset(_eventDayOffset);
    final filtered = events
        .where((event) => sameDate(eventDate(event), selectedDay))
        .toList()
      ..sort(
        (a, b) => (eventDate(b) ?? DateTime(1970))
            .compareTo(eventDate(a) ?? DateTime(1970)),
      );

    String dayLabel(int offset) {
      if (offset == 0) return 'Сегодня';
      if (offset == 1) return 'Вчера';

      final day = dayForOffset(offset);
      const months = [
        'янв',
        'фев',
        'мар',
        'апр',
        'мая',
        'июн',
        'июл',
        'авг',
        'сен',
        'окт',
        'ноя',
        'дек',
      ];
      return '${day.day} ${months[day.month - 1]}';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Последние события',
                style: TextStyle(
                  color: _text,
                  fontWeight: FontWeight.w700,
                  fontSize: 12.4,
                ),
              ),
            ),
            Text(
              '${filtered.length} за день',
              style: const TextStyle(
                color: _muted,
                fontWeight: FontWeight.w500,
                fontSize: 10.4,
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        SizedBox(
          height: 34,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            itemCount: 7,
            separatorBuilder: (_, __) => const SizedBox(width: 4),
            itemBuilder: (_, offset) {
              final selected = offset == _eventDayOffset;
              final count = events
                  .where(
                    (event) =>
                        sameDate(eventDate(event), dayForOffset(offset)),
                  )
                  .length;

              return InkWell(
                onTap: () => setState(() => _eventDayOffset = offset),
                child: Container(
                  alignment: Alignment.center,
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: selected ? _green : Colors.transparent,
                        width: 2,
                      ),
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        dayLabel(offset),
                        style: TextStyle(
                          color: selected ? _text : _muted,
                          fontWeight:
                              selected ? FontWeight.w700 : FontWeight.w500,
                          fontSize: 10.4,
                        ),
                      ),
                      if (count > 0) ...[
                        const SizedBox(width: 5),
                        Text(
                          '$count',
                          style: TextStyle(
                            color: selected ? _green : _muted,
                            fontWeight: FontWeight.w700,
                            fontSize: 9.6,
                          ),
                        ),
                      ],
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 4),
        if (filtered.isEmpty)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 16),
            child: Text(
              'За выбранный день личных тренировок нет.',
              style: TextStyle(
                color: _muted,
                fontWeight: FontWeight.w500,
                fontSize: 11.2,
              ),
            ),
          )
        else
          Column(
            children: [
              for (var index = 0; index < filtered.length; index++) ...[
                _recentEventRow(filtered[index]),
                if (index != filtered.length - 1)
                  const Divider(
                    height: 1,
                    thickness: .7,
                    color: _line,
                  ),
              ],
            ],
          ),
      ],
    );
  }

  Widget _recentEventRow(Map<String, dynamic> event) {
    final finished = '${event['event_type'] ?? event['type'] ?? ''}'
        .toLowerCase()
        .contains('finish');

    final name = _playerName(event);
    final avatar = _avatarUrl(event);
    final duration = _sessionDuration(event);
    final distance = _num(
      event,
      const [
        'total_distance_m',
        'distance_m',
        'distance',
        'session_distance_m',
      ],
    );
    final avgHr = _int(
      event,
      const [
        'avg_heart_rate_bpm',
        'average_heart_rate_bpm',
        'avg_bpm',
        'heart_rate_avg',
      ],
    );
    final maxHr = _int(
      event,
      const [
        'max_heart_rate_bpm',
        'max_bpm',
        'heart_rate_max',
      ],
    );
    final speed = _num(
      event,
      const [
        'avg_speed_kmh',
        'speed_kmh',
        'average_speed_kmh',
      ],
    );

    final metrics = <String>[
      _duration(duration),
      if (distance > 0) _meters(distance),
      if (speed > 0) '${speed.toStringAsFixed(1)} км/ч',
      if (avgHr > 0) 'ср. $avgHr bpm',
      if (maxHr > 0) 'макс. $maxHr bpm',
    ];

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => finished
            ? widget.onOpenReport?.call(event)
            : widget.onOpenAnalytics?.call(event),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 38,
                decoration: BoxDecoration(
                  color: finished ? _green : _orange,
                  borderRadius: BorderRadius.circular(99),
                ),
              ),
              const SizedBox(width: 8),
              _avatar(avatar, size: 34),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _text,
                        fontWeight: FontWeight.w700,
                        fontSize: 11.3,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${finished ? 'Завершил' : 'Начал'} · ${_activityLabel(event)}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _muted,
                        fontWeight: FontWeight.w500,
                        fontSize: 10.4,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      metrics.join(' · '),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: _muted,
                        fontWeight: FontWeight.w500,
                        fontSize: 9.6,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _shortDate(
                      '${event['created_at'] ?? event['event_at'] ?? event['ended_at'] ?? ''}',
                    ),
                    style: const TextStyle(
                      color: _muted,
                      fontWeight: FontWeight.w500,
                      fontSize: 9.6,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    finished ? 'Отчёт' : 'Live',
                    style: const TextStyle(
                      color: _green,
                      fontWeight: FontWeight.w700,
                      fontSize: 10.4,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _eventMetric(IconData icon, String value, {Color accent = _muted}) => Container(
    margin: const EdgeInsets.only(right: 5),
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 5),
    decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(8), border: Border.all(color: _line)),
    child: Row(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, color: accent, size: 12),
      const SizedBox(width: 4),
      Text(value, style: TextStyle(color: accent == _muted ? _text : accent, fontWeight: FontWeight.w900, fontSize: 9.6)),
    ]),
  );

  Widget _compactMetric(String label, String value, {Color valueColor = _text}) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: valueColor, fontSize: 11.8, fontWeight: FontWeight.w700)),
      const SizedBox(height: 2),
      Text(label, style: const TextStyle(color: _muted, fontSize: 9.6, fontWeight: FontWeight.w500)),
    ]),
  );

  Widget _detailMetric(String label, String value) => Container(
    width: 150, padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: _soft, borderRadius: BorderRadius.circular(12), border: Border.all(color: _line)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: const TextStyle(color: _muted, fontSize: 10.4, fontWeight: FontWeight.w800)),
      const SizedBox(height: 3), Text(value, style: const TextStyle(color: _text, fontSize: 12, fontWeight: FontWeight.w900)),
    ]),
  );

  String _lastUpdatedLabel() {
    final now = DateTime.now();
    return 'обновлено ${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}';
  }

  Widget _liveStatusText(int count) {
    final active = count > 0;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 6,
          height: 6,
          decoration: BoxDecoration(
            color: active ? _green : _muted,
            shape: BoxShape.circle,
          ),
        ),
        const SizedBox(width: 5),
        Text(
          active ? 'LIVE $count' : 'OFFLINE',
          style: TextStyle(
            color: active ? _green : _muted,
            fontSize: 10.4,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    );
  }

  Widget _liveIcon(int count) => Container(width: 38, height: 38, decoration: BoxDecoration(color: _greenSoft, borderRadius: BorderRadius.circular(13)), child: Stack(clipBehavior: Clip.none, children: [
    const Center(child: Icon(Icons.notifications_active_rounded, color: _green, size: 20)),
    if (count > 0) Positioned(right: -4, top: -5, child: _smallBadge(count)),
  ]));

  Widget _countPill(int count) { final active = count > 0; return Container(height: 28, padding: const EdgeInsets.symmetric(horizontal: 9), alignment: Alignment.center, decoration: BoxDecoration(color: active ? _green : _soft, borderRadius: BorderRadius.circular(999), border: Border.all(color: active ? _green : _line)), child: Text('$count онлайн', style: TextStyle(color: active ? Colors.white : _muted, fontSize: 11.2, fontWeight: FontWeight.w900))); }
  Widget _smallBadge(int count) => Container(constraints: const BoxConstraints(minWidth: 18, minHeight: 18), padding: const EdgeInsets.symmetric(horizontal: 4), alignment: Alignment.center, decoration: BoxDecoration(color: _green, borderRadius: BorderRadius.circular(999), border: Border.all(color: Colors.white, width: 2)), child: Text('$count', style: const TextStyle(color: Colors.white, fontSize: 9.6, fontWeight: FontWeight.w900)));
  Widget _liveDot() => Container(padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4), decoration: BoxDecoration(color: _greenSoft, borderRadius: BorderRadius.circular(999), border: Border.all(color: _green.withOpacity(.25))), child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.circle, size: 6, color: _green), SizedBox(width: 4), Text('LIVE', style: TextStyle(color: _green, fontSize: 9.6, fontWeight: FontWeight.w900))]));

  Widget _avatar(String url, {double size = 42}) {
    if (url.trim().isNotEmpty) return ClipRRect(borderRadius: BorderRadius.circular(size * .3), child: Image.network(url, width: size, height: size, fit: BoxFit.cover, errorBuilder: (_, __, ___) => _avatarFallback(size)));
    return _avatarFallback(size);
  }
  Widget _avatarFallback(double size) => Container(width: size, height: size, decoration: BoxDecoration(color: _greenSoft, borderRadius: BorderRadius.circular(size * .3)), child: Icon(Icons.person_rounded, color: _green, size: size * .52));
  Widget _errorBox(String error) => Text(
    error,
    style: const TextStyle(color: _red, fontWeight: FontWeight.w600, fontSize: 11.2),
  );
  Widget _emptyState() => const Padding(
    padding: EdgeInsets.symmetric(vertical: 12),
    child: Text(
      'Сейчас никто из игроков не ведёт личную тренировку.',
      style: TextStyle(color: _muted, fontWeight: FontWeight.w500, fontSize: 11.2),
    ),
  );

  List<_HrPoint> _heartRateSamples(Map<String, dynamic> row) {
    dynamic raw = row['heart_rate_samples'] ??
        row['hr_samples'] ??
        row['polar_samples'] ??
        row['bpm_history'] ??
        row['heart_rate_history'] ??
        row['points'];

    if (raw is Map) {
      raw = raw['samples'] ?? raw['points'] ?? raw['items'] ?? raw['data'];
    }
    if (raw is String && raw.trim().isNotEmpty) {
      try {
        raw = jsonDecode(raw);
        if (raw is Map) {
          raw = raw['samples'] ?? raw['points'] ?? raw['items'] ?? raw['data'];
        }
      } catch (_) {}
    }

    final out = <_HrPoint>[];
    DateTime? firstMeasured;
    if (raw is List) {
      for (var i = 0; i < raw.length; i++) {
        final item = raw[i];
        final bpmValue = item is Map
            ? (item['bpm'] ?? item['heart_rate_bpm'] ?? item['heart_rate'] ?? item['hr'] ?? item['value'])
            : item;
        final bpm = double.tryParse('$bpmValue');
        if (bpm == null || bpm <= 0 || bpm >= 260) continue;

        double sec = i.toDouble();
        if (item is Map) {
          final value = item['elapsed_sec'] ??
              item['offset_sec'] ??
              item['time_sec'] ??
              item['seconds_from_start'] ??
              item['elapsed_seconds'] ??
              item['relative_sec'];
          final parsed = double.tryParse('$value');
          if (parsed != null) {
            sec = parsed;
          } else {
            final measuredRaw = '${item['measured_at'] ?? item['created_at'] ?? item['timestamp'] ?? ''}'.trim();
            final measured = measuredRaw.isEmpty
                ? null
                : _parseServerDate(measuredRaw);
            if (measured != null) {
              firstMeasured ??= measured;
              sec = measured.difference(firstMeasured!).inMilliseconds / 1000.0;
            }
          }
        }
        out.add(_HrPoint(sec: sec < 0 ? 0 : sec, bpm: bpm));
      }
    }

    // Даже один текущий BPM должен быть виден в Live-карточке.
    if (out.isEmpty) {
      final current = _int(row, const [
        'last_heart_rate_bpm',
        'heart_rate_bpm',
        'bpm',
        'current_bpm',
        'latest_bpm',
        'hr',
      ]);
      if (current > 0) {
        out.add(_HrPoint(sec: 0, bpm: current.toDouble()));
      }
    }
    out.sort((a, b) => a.sec.compareTo(b.sec));
    return out;
  }

  Widget _summaryStrip() {
    final today = DateTime.now();
    bool sameDay(DateTime? d) => d != null && d.year == today.year && d.month == today.month && d.day == today.day;
    final completed = _events.where((e) => '${e['event_type'] ?? e['type'] ?? ''}'.toLowerCase().contains('finish')).toList();
    final todayCount = completed.where((e) => sameDay(_parseDate(e['ended_at'] ?? e['created_at'] ?? e['event_at']))).length;
    final weekCount = completed.where((e) { final d = _parseDate(e['ended_at'] ?? e['created_at'] ?? e['event_at']); return d != null && today.difference(d).inDays < 7; }).length;
    return Wrap(spacing: 8, runSpacing: 8, children: [
      _summaryMetric('Всего', '${completed.length}', Icons.fitness_center_rounded),
      _summaryMetric('Сегодня', '$todayCount', Icons.today_rounded),
      _summaryMetric('7 дней', '$weekCount', Icons.date_range_rounded),
      _summaryMetric('Онлайн', '${_live.length}', Icons.notifications_active_rounded),
    ]);
  }

  Widget _summaryMetric(String label, String value, IconData icon) => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, style: const TextStyle(color: _text, fontWeight: FontWeight.w700, fontSize: 15.2)),
      const SizedBox(height: 2),
      Text(label, style: const TextStyle(color: _muted, fontWeight: FontWeight.w500, fontSize: 9.6)),
    ]),
  );

  String _activityLabel(Map<String, dynamic> row) {
    final raw = _readText(row, const ['activity_type', 'training_type', 'workout_type', 'mode'], fallback: '').toLowerCase();
    if (raw.contains('run') || raw.contains('бег')) return 'Бег';
    if (raw.contains('gym') || raw.contains('зал')) return 'Зал';
    if (raw.contains('strength') || raw.contains('сил')) return 'Силовая';
    if (raw.contains('field') || raw.contains('football') || raw.contains('поле')) return 'Поле';
    return 'Личная';
  }

  int _sessionDuration(Map<String, dynamic> row) {
    final direct = _int(row, const ['duration_sec', 'duration_seconds', 'elapsed_sec', 'live_duration_sec']);
    if (direct > 0) return direct;
    final a = _parseDate(row['started_at'] ?? row['start_time'] ?? row['created_at']);
    final b = _parseDate(row['ended_at'] ?? row['end_time'] ?? row['finished_at']) ?? DateTime.now();
    return a == null ? 0 : b.difference(a).inSeconds.clamp(0, 86400).toInt();
  }

  String _startTime(Map<String, dynamic> row) =>
      _formatTime(_parseServerDate(row['started_at'] ?? row['start_time'] ?? row['created_at']));

  String _endTime(Map<String, dynamic> row) {
    final d = _parseServerDate(
      row['stopped_at'] ??
          row['ended_at'] ??
          row['end_time'] ??
          row['finished_at'],
    );
    return d == null ? 'идёт сейчас' : _formatTime(d);
  }

  bool _isRowRunning(Map<String, dynamic> row) {
    // Наличие итоговой сессии однозначно означает, что Live уже завершён,
    // даже если старый API продолжает возвращать status=active.
    final finalSessionId = _int(
      row,
      const ['final_session_id', 'session_id', 'tracker_session_id'],
    );
    if (finalSessionId > 0) return false;

    final status = '${row['status'] ?? row['state'] ?? row['live_status'] ?? ''}'
        .trim()
        .toLowerCase();
    final explicitlyFinished = status.contains('finish') ||
        status.contains('stop') ||
        status.contains('closed') ||
        status.contains('cancel') ||
        status.contains('autosaved') ||
        status.contains('completed');
    if (explicitlyFinished) return false;

    final ended = row['stopped_at'] ??
        row['ended_at'] ??
        row['end_time'] ??
        row['finished_at'];
    if (_parseServerDate(ended) != null) return false;

    // Если heartbeat давно не обновлялся, такую строку нельзя показывать LIVE.
    final lastSeenInstant = _trackerParseServerInstant(
      row['last_seen_at'] ?? row['updated_at'] ?? row['heartbeat_at'],
    );
    if (lastSeenInstant != null &&
        DateTime.now().toUtc().difference(lastSeenInstant).abs() >
            const Duration(minutes: 2)) {
      return false;
    }

    return status.isEmpty ||
        status == 'active' ||
        status == 'online' ||
        status == 'live' ||
        status.contains('active');
  }

  String _formatTime(DateTime? d) => d == null
      ? '—'
      : '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';

  /// Серверные строки без timezone считаются UTC и отображаются
  /// строго по московскому времени (UTC+3), независимо от timezone устройства.
  DateTime? _parseServerDate(dynamic value) => _trackerMoscowDateTime(value);

  DateTime? _parseDate(dynamic value) => _parseServerDate(value);
  int _durationMinutes(int sec) => sec <= 0 ? 0 : (sec / 60).ceil();
  String _hrExtremesText(List<_HrPoint> values) {
    if (values.isEmpty) return 'Нет данных';
    final minP = values.reduce((a,b) => a.bpm <= b.bpm ? a : b);
    final maxP = values.reduce((a,b) => a.bpm >= b.bpm ? a : b);
    return '${minP.bpm.round()} (${(minP.sec/60).floor()} мин) / ${maxP.bpm.round()} (${(maxP.sec/60).floor()} мин)';
  }

  int? _parsePositiveInt(dynamic value) {
    final parsed = value is num ? value.toInt() : int.tryParse('${value ?? ''}');
    return parsed != null && parsed > 0 ? parsed : null;
  }

  int? _rowPlayerId(Map<String, dynamic> row) {
    for (final key in const ['player_id', 'playerId', 'resolved_player_id', 'owner_user_id', 'user_id', 'userId', 'resolved_user_id', 'athlete_id']) {
      final value = row[key];
      final parsed = value is num ? value.toInt() : int.tryParse('${value ?? ''}');
      if (parsed != null && parsed > 0 && _resolvedDirectory.containsKey(parsed)) return parsed;
    }
    final direct = _readText(row, const ['player_name', 'full_name', 'name', 'athlete_name'], fallback: '');
    final technical = RegExp(r'^(?:Игрок|Player)\s*#?\s*(\d+)$', caseSensitive: false).firstMatch(direct);
    final parsed = technical == null ? null : int.tryParse(technical.group(1) ?? '');
    return parsed != null && _resolvedDirectory.containsKey(parsed) ? parsed : null;
  }

  String _playerName(Map<String, dynamic> row) {
    // Сначала используем раздельные поля — это единственный надёжный способ
    // гарантировать формат «Фамилия И.» независимо от порядка full_name.
    final first = _readText(
      row,
      const ['first_name', 'player_first_name', 'user_first_name'],
      fallback: '',
    );
    final last = _readText(
      row,
      const ['last_name', 'surname', 'player_last_name', 'user_last_name'],
      fallback: '',
    );
    if (last.isNotEmpty || first.isNotEmpty) {
      return _surnameWithInitial(last: last, first: first);
    }

    final directoryId = _rowPlayerId(row);
    final directoryName = directoryId == null
        ? ''
        : (_resolvedDirectory[directoryId]?['name'] ?? '').trim();
    if (directoryName.isNotEmpty) return _shortSurnameFirst(directoryName);

    final direct = _readText(
      row,
      const ['player_short_name', 'short_name', 'player_name', 'full_name', 'name', 'athlete_name'],
      fallback: '',
    );
    final technical = RegExp(
      r'^(?:Игрок|Player)\s*#?\s*\d+$',
      caseSensitive: false,
    ).hasMatch(direct);
    if (direct.isNotEmpty && !technical) {
      return _shortSurnameFirst(direct, assumeFirstNameFirst: true);
    }
    return directoryId == null ? 'Игрок' : 'Игрок #$directoryId';
  }

  String _surnameWithInitial({required String last, required String first}) {
    final surname = last.trim();
    final given = first.trim();
    if (surname.isEmpty) return given;
    if (given.isEmpty) return surname;
    return '$surname ${given.substring(0, 1).toUpperCase()}.';
  }

  String _shortSurnameFirst(
    String value, {
    bool assumeFirstNameFirst = false,
  }) {
    final cleaned = value.trim();
    final parts = cleaned
        .split(RegExp(r'\s+'))
        .where((e) => e.isNotEmpty)
        .toList();
    if (parts.length < 2) return cleaned;

    // Если строка уже сокращена («Красновский С.»), оставляем как есть.
    if (parts[1].endsWith('.') && parts[1].length <= 3) {
      return '${parts.first} ${parts[1].substring(0, 1).toUpperCase()}.';
    }

    final surname = assumeFirstNameFirst ? parts.last : parts.first;
    final firstName = assumeFirstNameFirst ? parts.first : parts[1];
    return '$surname ${firstName.substring(0, 1).toUpperCase()}.';
  }
  String _avatarUrl(Map<String, dynamic> row) {
    final direct = _readText(row, const ['avatar_url', 'avatar', 'photo_url', 'photo', 'player_avatar'], fallback: '');
    if (direct.isNotEmpty) return direct;
    final id = _rowPlayerId(row);
    return id == null ? '' : (_resolvedDirectory[id]?['avatar'] ?? '').trim();
  }
  String _shortDate(String value) {
    final parsed = _parseServerDate(value);
    if (parsed == null) return value;
    return _formatTime(parsed);
  }
  IconData _iconFor(String type) => type.toLowerCase().contains('finish') ? Icons.check_circle_rounded : type.toLowerCase().contains('start') ? Icons.play_circle_fill_rounded : Icons.info_rounded;
  String _plural(int count) { final n10 = count % 10, n100 = count % 100; if (n10 == 1 && n100 != 11) return ''; if (n10 >= 2 && n10 <= 4 && (n100 < 12 || n100 > 14)) return 'а'; return 'ов'; }

  bool _isActivePersonalLive(Map<String, dynamic> s) {
    final status = '${s['status'] ?? s['state'] ?? s['live_status'] ?? 'active'}'.toLowerCase();
    if (status.contains('finish') || status.contains('stop') || status.contains('closed') || status.contains('cancel')) return false;
    final personalRaw = '${s['personal_session'] ?? s['is_personal'] ?? s['personal'] ?? ''}'.toLowerCase().trim();
    final kind = '${s['session_kind'] ?? s['source'] ?? s['started_by_role'] ?? ''}'.toLowerCase();
    return personalRaw == '1' || personalRaw == 'true' || kind.contains('personal') || kind.contains('player') || kind.contains('polar') || !s.containsKey('personal_session');
  }

  Map<String, dynamic> _decode(String body) { final text = body.trim(); final start = text.indexOf('{'); final decoded = jsonDecode(start >= 0 ? text.substring(start) : text); return decoded is Map ? Map<String, dynamic>.from(decoded) : {'success': false, 'message': 'Некорректный ответ API'}; }
  String _sourceLabel(Map<String, dynamic> row) { final source = _readText(row, const ['source', 'device_source', 'activity_source'], fallback: '').toLowerCase(); final device = _readText(row, const ['device_name', 'tracker_name'], fallback: '').toLowerCase(); final hasHr = _int(row, const ['last_heart_rate_bpm', 'heart_rate_bpm', 'bpm', 'avg_heart_rate_bpm']) > 0 || source.contains('polar') || device.contains('polar'); final hasGps = _num(row, const ['total_distance_m', 'distance_m', 'last_field_x_m', 'field_x_m', 'latitude', 'lat']) > 0 || source.contains('gps') || source.contains('tracker'); if (hasHr && hasGps) return 'Polar + GPS'; if (hasHr) return 'Polar'; if (hasGps) return 'GPS-трекер'; return 'личная сессия'; }
  String _readText(Map<String, dynamic> row, List<String> keys, {required String fallback}) { for (final key in keys) { final value = row[key]; if (value == null) continue; final text = '$value'.trim(); if (text.isNotEmpty && text != 'null') return text; } return fallback; }
  int _int(Map<String, dynamic> row, List<String> keys) { for (final key in keys) { final value = row[key]; if (value == null) continue; final parsed = int.tryParse('$value') ?? (value is num ? value.toInt() : null); if (parsed != null) return parsed; } return 0; }
  double _num(Map<String, dynamic> row, List<String> keys) { for (final key in keys) { final value = row[key]; if (value == null) continue; final parsed = double.tryParse('$value') ?? (value is num ? value.toDouble() : null); if (parsed != null && parsed.isFinite) return parsed; } return 0; }
  String _duration(int sec) { if (sec <= 0) return '0:00'; final h = sec ~/ 3600, m = (sec % 3600) ~/ 60, s = sec % 60; return h > 0 ? '$h:${m.toString().padLeft(2, '0')}:${s.toString().padLeft(2, '0')}' : '$m:${s.toString().padLeft(2, '0')}'; }
  String _meters(double value) => value >= 1000 ? '${(value / 1000).toStringAsFixed(2)} км' : '${value.toStringAsFixed(0)} м';
}

class _HrPoint {
  const _HrPoint({required this.sec, required this.bpm});
  final double sec;
  final double bpm;
}

class _HrChart extends StatefulWidget {
  const _HrChart({required this.values, required this.compact});
  final List<_HrPoint> values;
  final bool compact;
  @override
  State<_HrChart> createState() => _HrChartState();
}

class _HrChartState extends State<_HrChart> {
  int? selected;
  void _select(Offset p, Size size) {
    if (widget.values.isEmpty || size.width <= 0) return;
    final maxSec = math.max(1.0, widget.values.last.sec);
    final target = (p.dx.clamp(0.0, size.width) / size.width) * maxSec;
    var best = 0;
    var delta = double.infinity;
    for (var i=0;i<widget.values.length;i++) { final d=(widget.values[i].sec-target).abs(); if(d<delta){delta=d;best=i;} }
    setState(() => selected = best);
  }
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (_, c) {
      final size = Size(c.maxWidth, c.maxHeight);
      return GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (d) => _select(d.localPosition, size),
        onPanUpdate: (d) => _select(d.localPosition, size),
        child: CustomPaint(painter: _HrChartPainter(widget.values, detailed: !widget.compact, selected: selected), size: Size.infinite),
      );
    });
  }
}

class _HrChartPainter extends CustomPainter {
  const _HrChartPainter(this.values, {this.detailed = false, this.selected});
  final List<_HrPoint> values;
  final bool detailed;
  final int? selected;
  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()..color = const Color(0xFFFFE4E4)..strokeWidth = 1;
    for (var i = 1; i < 4; i++) { final y = size.height * i / 4; canvas.drawLine(Offset(0, y), Offset(size.width, y), grid); }
    if (values.isEmpty) {
      final tp = TextPainter(text: const TextSpan(text: 'Нет данных Polar', style: TextStyle(color: Color(0xFF98A2B3), fontSize: 11.2, fontWeight: FontWeight.w700)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, Offset((size.width - tp.width) / 2, (size.height - tp.height) / 2));
      return;
    }
    if (values.length == 1) {
      final p = values.first;
      final y = size.height * .5;
      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        Paint()..color = const Color(0xFFDC2626).withOpacity(.35)..strokeWidth = 1.5,
      );
      canvas.drawCircle(Offset(size.width * .5, y), 5, Paint()..color = const Color(0xFFDC2626));
      final tp = TextPainter(
        text: TextSpan(text: '${p.bpm.round()} bpm', style: const TextStyle(color: Color(0xFFDC2626), fontSize: 11.2, fontWeight: FontWeight.w900)),
        textDirection: TextDirection.ltr,
      )..layout();
      tp.paint(canvas, Offset((size.width - tp.width) / 2, math.max(0, y - 22)));
      return;
    }
    final minPoint = values.reduce((a,b)=>a.bpm<=b.bpm?a:b), maxPoint = values.reduce((a,b)=>a.bpm>=b.bpm?a:b);
    final minV = math.max(40.0, minPoint.bpm - 10), maxV = math.min(220.0, maxPoint.bpm + 10), span = math.max(1.0, maxV-minV), maxSec=math.max(1.0, values.last.sec);
    Offset pos(_HrPoint p)=>Offset(size.width*(p.sec/maxSec).clamp(0.0,1.0), size.height-((p.bpm-minV)/span).clamp(0.0,1.0)*size.height);
    final path=Path();
    for(var i=0;i<values.length;i++){final o=pos(values[i]); if(i==0) path.moveTo(o.dx,o.dy); else path.lineTo(o.dx,o.dy);}    
    canvas.drawPath(path, Paint()..color=const Color(0xFFDC2626)..strokeWidth=detailed?2.4:1.8..style=PaintingStyle.stroke..strokeCap=StrokeCap.round..strokeJoin=StrokeJoin.round);
    void marker(_HrPoint p, Color color, String text){final o=pos(p); canvas.drawCircle(o, detailed?4:3, Paint()..color=color); if(detailed){final tp=TextPainter(text:TextSpan(text:text,style:TextStyle(color:color,fontSize: 10.4,fontWeight:FontWeight.w900)),textDirection:TextDirection.ltr)..layout(); tp.paint(canvas, Offset((o.dx-tp.width/2).clamp(0.0,size.width-tp.width), (o.dy-18).clamp(0.0,size.height-tp.height)));}}
    marker(minPoint,const Color(0xFF2563EB),'мин ${minPoint.bpm.round()} · ${(minPoint.sec/60).floor()} мин');
    marker(maxPoint,const Color(0xFFDC2626),'макс ${maxPoint.bpm.round()} · ${(maxPoint.sec/60).floor()} мин');
    if(selected!=null && selected!>=0 && selected!<values.length){final p=values[selected!],o=pos(p); canvas.drawLine(Offset(o.dx,0),Offset(o.dx,size.height),Paint()..color=const Color(0xFF6B746E)..strokeWidth=1); marker(p,const Color(0xFF101828),'${p.bpm.round()} · ${(p.sec/60).floor()}:${((p.sec%60).round()).toString().padLeft(2,'0')}');}
    if(detailed){for(var i=0;i<=4;i++){final sec=maxSec*i/4;final text='${(sec/60).round()} мин';final tp=TextPainter(text:TextSpan(text:text,style:const TextStyle(color:Color(0xFF98A2B3),fontSize: 9.6,fontWeight:FontWeight.w700)),textDirection:TextDirection.ltr)..layout();tp.paint(canvas,Offset((size.width*i/4-tp.width/2).clamp(0.0,size.width-tp.width),size.height-tp.height));}}
  }
  @override
  bool shouldRepaint(covariant _HrChartPainter oldDelegate)=>oldDelegate.values!=values||oldDelegate.detailed!=detailed||oldDelegate.selected!=selected;
}

class PlayerTrainingOnlineBadge extends StatefulWidget {
  const PlayerTrainingOnlineBadge({
    super.key,
    required this.teamId,
    this.compact = true,
    this.apiBaseUrl = 'https://sportotekaapp.ru/api/tracker',
  });

  final int teamId;
  final bool compact;
  final String apiBaseUrl;

  @override
  State<PlayerTrainingOnlineBadge> createState() => _PlayerTrainingOnlineBadgeState();
}

class _PlayerTrainingOnlineBadgeState extends State<PlayerTrainingOnlineBadge> {
  Timer? _timer;
  int _count = 0;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => _load());
  }

  @override
  void didUpdateWidget(covariant PlayerTrainingOnlineBadge oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.teamId != widget.teamId || oldWidget.apiBaseUrl != widget.apiBaseUrl) {
      _load();
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _load() async {
    if (widget.teamId <= 0) return;
    try {
      final uri = Uri.parse('${widget.apiBaseUrl}/player_get_live_state.php').replace(
        queryParameters: <String, String>{
          'team_id': '${widget.teamId}',
          'personal_session': '1',
          'active_only': '1',
          'limit': '50',
        },
      );
      final response = await http.get(uri).timeout(const Duration(seconds: 8));
      final text = response.body.trim();
      final start = text.indexOf('{');
      final decoded = jsonDecode(start >= 0 ? text.substring(start) : text);
      if (decoded is! Map) return;
      final data = Map<String, dynamic>.from(decoded);
      final raw = data['sessions'] as List? ?? data['items'] as List? ?? const [];
      final count = raw.whereType<Map>().where((item) {
        final row = Map<String, dynamic>.from(item);
        final status = '${row['status'] ?? row['state'] ?? row['live_status'] ?? 'active'}'.toLowerCase();
        return !status.contains('finish') &&
            !status.contains('stop') &&
            !status.contains('closed') &&
            !status.contains('cancel');
      }).length;
      if (mounted && count != _count) setState(() => _count = count);
    } catch (_) {
      // Бейдж не должен ломать навигацию при временной ошибке сети.
    }
  }

  @override
  Widget build(BuildContext context) {
    final active = _count > 0;
    final size = widget.compact ? 20.0 : 24.0;
    return Container(
      constraints: BoxConstraints(minWidth: size, minHeight: size),
      padding: EdgeInsets.symmetric(horizontal: widget.compact ? 5 : 7, vertical: 2),
      decoration: BoxDecoration(
        color: active ? const Color(0xFF00A750) : const Color(0xFFF2F4F7),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: active ? const Color(0xFF00A750) : const Color(0xFFE4E7EC)),
      ),
      alignment: Alignment.center,
      child: Text(
        '$_count',
        style: TextStyle(
          color: active ? Colors.white : const Color(0xFF6B746E),
          fontSize: widget.compact ? 9 : 10,
          fontWeight: FontWeight.w900,
          height: 1,
        ),
      ),
    );
  }
}
