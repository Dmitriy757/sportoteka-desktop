import 'dart:async';
import 'dart:math' as math;

import '../models/action_tracker_protocol.dart';
import '../models/tracker_live_models.dart';
import 'action_tracker_ble_service.dart';
import 'team_action_tracker_ble_pool.dart';
import 'tracker_live_api.dart';

class TeamTrackerBinding {
  final int playerId;
  final String playerName;
  final String deviceUuid;
  final String deviceName;
  final int? batteryPercent;

  const TeamTrackerBinding({
    required this.playerId,
    required this.playerName,
    required this.deviceUuid,
    required this.deviceName,
    this.batteryPercent,
  });
}

class TeamTrackerChannelDebug {
  final int playerId;
  final String playerName;
  final String deviceUuid;
  final String deviceName;
  final bool bleReady;
  final int? liveSessionId;
  final DateTime? lastRxAt;
  final DateTime? lastGpsAt;
  final DateTime? lastServerSaveAt;
  final String? lastError;
  final int receivedPackets;
  final int savedPoints;
  final double totalDistanceM;
  final double lastSpeedKmh;
  final double maxSpeedKmh;
  final double avgSpeedKmh;
  final int recoveryCount;
  final bool serverGapActive;
  final bool backfillRequired;

  const TeamTrackerChannelDebug({
    required this.playerId,
    required this.playerName,
    required this.deviceUuid,
    required this.deviceName,
    required this.bleReady,
    required this.liveSessionId,
    required this.lastRxAt,
    required this.lastGpsAt,
    required this.lastServerSaveAt,
    required this.lastError,
    required this.receivedPackets,
    required this.savedPoints,
    required this.totalDistanceM,
    required this.lastSpeedKmh,
    required this.maxSpeedKmh,
    required this.avgSpeedKmh,
    required this.recoveryCount,
    required this.serverGapActive,
    required this.backfillRequired,
  });
}

class _TrackerGap {
  final DateTime from;
  final DateTime to;

  const _TrackerGap({required this.from, required this.to});

  Map<String, dynamic> toJson() => <String, dynamic>{
        'from_ms': from.millisecondsSinceEpoch,
        'to_ms': to.millisecondsSinceEpoch,
      };
}

class _Runtime {
  final TeamTrackerBinding binding;
  int? liveSessionId;
  bool txInFlight = false;
  DateTime? lastRxAt;
  DateTime? lastGpsAt;
  DateTime? lastServerSaveAt;
  String? lastError;
  int receivedPackets = 0;
  int savedPoints = 0;
  double totalDistanceM = 0;
  double lastSpeedKmh = 0;
  double maxSpeedKmh = 0;
  double speedSum = 0;
  int speedCount = 0;
  double? lastLat;
  double? lastLon;
  int? lastTimeMs;
  DateTime watchdogBaselineAt = DateTime.now();
  DateTime? lastDeviceKeepAliveAt;
  DateTime? lastRecoveryAttemptAt;
  int recoveryCount = 0;
  DateTime? liveStartedAt;
  DateTime? liveStoppedAt;
  int? finalSessionId;
  DateTime? bleGapStartedAt;
  DateTime? serverGapStartedAt;
  int? lastServerSavedPointTimeMs;
  final List<_TrackerGap> gaps = <_TrackerGap>[];
  bool backfillRequired = false;

  _Runtime(this.binding);
}

/// Одна командная тренировка на планшете, но отдельная активная строка сервера
/// и отдельный BLE-канал для каждого игрока/UUID.
class TeamTrackerLiveCoordinator {
  // BLE-пакет трекера не передаёт accuracy/HDOP, поэтому дрожание GPS
  // отсеиваем по минимальному смещению координат и скорости. Порог 1.5 км/ч
  // сохраняет обычную ходьбу, в отличие от прежних 4 км/ч.
  static const double _stationarySpeedDeadbandKmh = 1.5;
  static const double _stationaryCoordinateJitterM = 0.35;
  static const Duration _deviceKeepAliveInterval = Duration(seconds: 20);
  static const Duration _silentRxTimeout = Duration(seconds: 40);
  static const Duration _disconnectedRecoveryDelay = Duration(seconds: 8);
  static const Duration _recoveryCooldown = Duration(seconds: 30);

  final int clubId;
  final int teamId;
  int? fieldId;
  final TeamActionTrackerBlePool pool;
  final TrackerLiveApi api;
  final Map<String, _Runtime> _runtime = {};
  StreamSubscription<TeamTrackerBleEvent>? _dataSub;
  Timer? _heartbeat;
  Timer? _gpsScheduler;
  Timer? _bleWatchdog;
  int _gpsSchedulerCursor = 0;
  bool _heartbeatInFlight = false;
  bool _bleWatchdogInFlight = false;
  bool _running = false;
  bool _starting = false;
  int _offlineRecoveryTasks = 0;

  TeamTrackerLiveCoordinator({
    required this.clubId,
    required this.teamId,
    required this.pool,
    TrackerLiveApi? api,
    this.fieldId,
  }) : api = api ?? TrackerLiveApi();

  bool get running => _running || _starting;
  bool get offlineRecoveryBusy =>
      _offlineRecoveryTasks > 0 || pool.offlineTransferActive;

  int? liveSessionIdForPlayer(int playerId) {
    for (final runtime in _runtime.values) {
      if (runtime.binding.playerId == playerId) return runtime.liveSessionId;
    }
    return null;
  }

  List<TeamTrackerChannelDebug> get debugRows => _runtime.values.map((r) {
        return TeamTrackerChannelDebug(
          playerId: r.binding.playerId,
          playerName: r.binding.playerName,
          deviceUuid: r.binding.deviceUuid,
          deviceName: r.binding.deviceName,
          bleReady: pool.isConnected(r.binding.deviceUuid),
          liveSessionId: r.liveSessionId,
          lastRxAt: r.lastRxAt,
          lastGpsAt: r.lastGpsAt,
          lastServerSaveAt: r.lastServerSaveAt,
          lastError: r.lastError,
          receivedPackets: r.receivedPackets,
          savedPoints: r.savedPoints,
          totalDistanceM: r.totalDistanceM,
          lastSpeedKmh: r.lastSpeedKmh,
          maxSpeedKmh: r.maxSpeedKmh,
          avgSpeedKmh: r.speedCount == 0 ? 0 : r.speedSum / r.speedCount,
          recoveryCount: r.recoveryCount,
          serverGapActive: r.serverGapStartedAt != null,
          backfillRequired: r.backfillRequired,
        );
      }).toList(growable: false);

  Future<void> start(List<TeamTrackerBinding> bindings) async {
    if (_running || _starting) return;
    if (offlineRecoveryBusy) {
      throw StateError(
        'Идёт восстановление записи прошлого матча. Дождитесь окончания выгрузки GPS-файла.',
      );
    }
    if (bindings.isEmpty)
      throw StateError('Нет привязанных GPS-трекеров команды');
    _starting = true;

    try {
      final duplicateDevices = <String>{};
      final seenDevices = <String>{};
      final seenPlayers = <int>{};
      for (final b in bindings) {
        if (!seenDevices.add(b.deviceUuid)) duplicateDevices.add(b.deviceUuid);
        if (!seenPlayers.add(b.playerId)) {
          throw StateError(
              'Игрок ${b.playerName} привязан более чем к одному GPS');
        }
      }
      if (duplicateDevices.isNotEmpty) {
        throw StateError(
            'Один UUID назначен нескольким игрокам: ${duplicateDevices.join(', ')}');
      }

      _runtime.clear();
      for (final b in bindings) {
        if (!pool.isConnected(b.deviceUuid)) {
          throw StateError(
              'GPS ${b.deviceName} (${b.deviceUuid}) не подключён');
        }
        _runtime[b.deviceUuid] = _Runtime(b);
      }

      // Все серверные строки создаются одной транзакцией. Это не оставляет
      // пять активных игроков, если шестой трекер не прошёл проверку.
      final serverSessions = await api.startTeamLiveSessions(
        clubId: clubId,
        teamId: teamId,
        fieldId: fieldId,
        bindings: bindings
            .map((b) => <String, dynamic>{
                  'player_id': b.playerId,
                  'device_uuid': b.deviceUuid,
                  'device_name': b.deviceName,
                  'battery_percent': b.batteryPercent,
                })
            .toList(growable: false),
        activityType: 'football_field',
        fieldRequired: fieldId != null,
      );

      for (final item in serverSessions) {
        final uuid = '${item['device_uuid'] ?? ''}'.trim();
        final name = '${item['device_name'] ?? ''}'.trim();
        final playerId = int.tryParse('${item['player_id'] ?? 0}') ?? 0;
        final id =
            int.tryParse('${item['live_session_id'] ?? item['id'] ?? 0}') ?? 0;
        if (id <= 0) continue;

        _Runtime? target = _runtime[uuid];
        if (target == null) {
          for (final runtime in _runtime.values) {
            if (_samePhysicalTracker(
              runtime.binding.deviceUuid,
              runtime.binding.deviceName,
              uuid,
              name,
            )) {
              target = runtime;
              break;
            }
          }
        }
        if (target == null && playerId > 0) {
          for (final runtime in _runtime.values) {
            if (runtime.binding.playerId == playerId) {
              target = runtime;
              break;
            }
          }
        }
        if (target != null) {
          target.liveSessionId = id;
          target.liveStartedAt = DateTime.now();
        }
      }
      final missing = _runtime.values
          .where((r) => r.liveSessionId == null)
          .toList(growable: false);
      if (missing.isNotEmpty) {
        throw StateError(
          'Сервер не создал Live для: ${missing.map((r) => r.binding.playerName).join(', ')}',
        );
      }

      _dataSub = pool.dataStream.listen(_onData);
      _running = true;
      unawaited(ActionTrackerBleService.setTrackerKeepScreenOn(true));
      pool.setLivePolling(true);
      _startGpsScheduler();
      _startBleWatchdog();

      _heartbeat = Timer.periodic(const Duration(seconds: 5), (_) async {
        if (_heartbeatInFlight) return;
        _heartbeatInFlight = true;
        try {
          await Future.wait(_runtime.values.map((r) async {
            final id = r.liveSessionId;
            if (id == null) return;
            try {
              await api.heartbeatLiveSession(
                liveSessionId: id,
                statusText:
                    'team_live:${pool.connectedCount}/${_runtime.length}',
              );
            } catch (e) {
              r.lastError = 'heartbeat: $e';
            }
          }));
        } finally {
          _heartbeatInFlight = false;
        }
      });
    } catch (_) {
      _running = false;
      pool.setLivePolling(false);
      _gpsScheduler?.cancel();
      _gpsScheduler = null;
      _bleWatchdog?.cancel();
      _bleWatchdog = null;
      unawaited(ActionTrackerBleService.setTrackerKeepScreenOn(false));
      _heartbeat?.cancel();
      _heartbeat = null;
      await _dataSub?.cancel();
      _dataSub = null;
      for (final r in _runtime.values) {
        final id = r.liveSessionId;
        if (id == null) continue;
        try {
          await api.stopLiveSession(
              liveSessionId: id, createFinalSession: false);
        } catch (_) {}
      }
      rethrow;
    } finally {
      _starting = false;
    }
  }

  void _startGpsScheduler() {
    _gpsScheduler?.cancel();
    _gpsSchedulerCursor = 0;
    _gpsScheduler = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (!_running || _runtime.isEmpty) return;
      final rows = _runtime.values.toList(growable: false);
      if (_gpsSchedulerCursor >= rows.length) _gpsSchedulerCursor = 0;
      final runtime = rows[_gpsSchedulerCursor++];
      if (runtime.txInFlight) return;
      runtime.txInFlight = true;
      unawaited(() async {
        try {
          final now = DateTime.now();
          final lastKeepAlive = runtime.lastDeviceKeepAliveAt;
          final keepAliveDue = lastKeepAlive == null ||
              now.difference(lastKeepAlive) >= _deviceKeepAliveInterval;
          if (keepAliveDue) {
            // 0x20 не только читает батарею/GPS-ready, но и не даёт прошивке
            // некоторых партий трекеров уйти в 30-минутный idle/sleep.
            runtime.lastDeviceKeepAliveAt = now;
            await pool.requestBattery(runtime.binding.deviceUuid);
          } else {
            await pool.requestCurrentGps(runtime.binding.deviceUuid);
          }
        } catch (e) {
          runtime.lastError = 'TX: $e';
        } finally {
          runtime.txInFlight = false;
        }
      }());
    });
  }

  void _startBleWatchdog() {
    _bleWatchdog?.cancel();
    _bleWatchdog = Timer.periodic(const Duration(seconds: 5), (_) {
      unawaited(_runBleWatchdog());
    });
  }

  Future<void> _runBleWatchdog() async {
    if (!_running || _bleWatchdogInFlight || _runtime.isEmpty) return;
    _bleWatchdogInFlight = true;
    try {
      final now = DateTime.now();
      final candidates = _runtime.values.where((runtime) {
        final reference = runtime.lastRxAt ?? runtime.watchdogBaselineAt;
        final silentFor = now.difference(reference);
        final limit = pool.isConnected(runtime.binding.deviceUuid)
            ? _silentRxTimeout
            : _disconnectedRecoveryDelay;
        if (silentFor < limit) return false;
        final lastRecovery = runtime.lastRecoveryAttemptAt;
        return lastRecovery == null ||
            now.difference(lastRecovery) >= _recoveryCooldown;
      }).toList(growable: false)
        ..sort((a, b) {
          final aRx = a.lastRxAt ?? a.watchdogBaselineAt;
          final bRx = b.lastRxAt ?? b.watchdogBaselineAt;
          return aRx.compareTo(bRx);
        });

      // За один проход восстанавливаем только один GATT, иначе Android может
      // вернуть 133 и сбросить уже работающие каналы.
      if (candidates.isEmpty) return;
      final runtime = candidates.first;
      final reference = runtime.lastRxAt ?? runtime.watchdogBaselineAt;
      final silentSeconds = now.difference(reference).inSeconds;
      runtime.lastRecoveryAttemptAt = now;
      runtime.bleGapStartedAt ??=
          runtime.lastGpsAt ?? runtime.lastRxAt ?? now;
      runtime.lastError =
          'BLE watchdog: нет RX ${silentSeconds}s, восстанавливаю канал';

      var recovered = false;
      try {
        recovered = await pool.recoverConnection(
          runtime.binding.deviceUuid,
          reason: 'нет RX ${silentSeconds}s',
        );
      } catch (e) {
        runtime.lastError = 'BLE watchdog reconnect: $e';
      }
      runtime.watchdogBaselineAt = DateTime.now();
      runtime.lastDeviceKeepAliveAt = null;
      if (recovered) {
        runtime.recoveryCount++;
        // GATT уже поднялся, но BLE-gap закрываем только первой реальной
        // GPS-точкой. Ответ батареи/TX30 ещё не означает, что Live GPS вернулся.
        runtime.lastError =
            'BLE восстановлен автоматически · ожидаем GPS · попыток ${runtime.recoveryCount}';
      } else {
        runtime.lastError =
            'Трекер пока не отвечает · повтор через ${_recoveryCooldown.inSeconds}s';
      }
    } finally {
      _bleWatchdogInFlight = false;
    }
  }

  Future<void> _onData(TeamTrackerBleEvent event) async {
    final r = _runtime[event.deviceUuid];
    if (r == null) return;
    r.receivedPackets++;
    final rxAt = DateTime.now();
    r.lastRxAt = rxAt;
    r.watchdogBaselineAt = r.lastRxAt!;
    r.lastError = null;

    final chunk = event.data.gpsChunk;
    if (chunk == null || chunk.points.isEmpty) return;

    // Закрываем BLE/GPS-разрыв только когда реально вернулась хотя бы одна
    // валидная GPS-точка, а не по battery/record-list служебному ответу.
    final hasValidGps = chunk.points.any(
      (p) => p.latitude.abs() >= 0.000001 || p.longitude.abs() >= 0.000001,
    );
    if (hasValidGps) _closeOpenGap(r, rxAt);

    for (final p in chunk.points) {
      if (p.latitude.abs() < 0.000001 && p.longitude.abs() < 0.000001) {
        r.lastError = 'GPS 0,0: нет спутниковой фиксации';
        continue;
      }

      final nowMs =
          p.timeMs > 0 ? p.timeMs : DateTime.now().millisecondsSinceEpoch;
      double deltaM = 0;
      double speedKmh = 0;
      double rawSpeedKmh = 0;
      var acceptedForMetrics = true;
      String? rejectReason;
      var advanceAnchor = r.lastLat == null || r.lastLon == null || r.lastTimeMs == null;

      if (!advanceAnchor) {
        deltaM = _distanceM(r.lastLat!, r.lastLon!, p.latitude, p.longitude);
        final dt = (nowMs - r.lastTimeMs!) / 1000.0;

        if (dt <= 0) {
          // Дубликат/откат времени: не используем точку и, главное, не делаем
          // её новой опорой — иначе следующая нормальная точка породит ложный пик.
          speedKmh = 0;
          deltaM = 0;
          rejectReason = 'GPS-время дублировано/откатилось — точка отброшена';
          acceptedForMetrics = false;
          r.lastError = rejectReason;
        } else if (dt >= 10) {
          // После длинного BLE/GPS-разрыва начинаем новый сегмент маршрута.
          // Расстояние через разрыв не дорисовываем.
          speedKmh = 0;
          deltaM = 0;
          advanceAnchor = true;
        } else if (deltaM >= 300) {
          speedKmh = 0;
          deltaM = 0;
          rejectReason = 'GPS-телепорт координаты отброшен';
          acceptedForMetrics = false;
          r.lastError = rejectReason;
        } else {
          rawSpeedKmh = deltaM / dt * 3.6;
          speedKmh = rawSpeedKmh;

          if (speedKmh.isFinite &&
              deltaM >= _stationaryCoordinateJitterM &&
              speedKmh >= _stationarySpeedDeadbandKmh &&
              speedKmh <= 36) {
            r.totalDistanceM += deltaM;
            r.maxSpeedKmh = math.max(r.maxSpeedKmh, speedKmh);
            r.speedSum += speedKmh;
            r.speedCount++;
            advanceAnchor = true;
          } else if (speedKmh.isFinite &&
              speedKmh >= 0 &&
              (deltaM < _stationaryCoordinateJitterM ||
                  speedKmh < _stationarySpeedDeadbandKmh)) {
            // Покой/мелкий GPS-jitter: нулевая скорость, но опору обновляем,
            // чтобы небольшие смещения не накопились в один большой сегмент.
            speedKmh = 0;
            deltaM = 0;
            advanceAnchor = true;
          } else {
            // Ключевой V86 fix: выброс НЕ становится новой опорной координатой.
            // Раньше >36 отбрасывался, но следующая точка считалась уже от
            // плохой координаты и могла дать вторичный ложный 34–35.6 км/ч.
            speedKmh = 0;
            deltaM = 0;
            rejectReason = 'GPS-выброс скорости отброшен без сдвига опоры';
            acceptedForMetrics = false;
            r.lastError = rejectReason;
          }
        }
      }

      if (advanceAnchor) {
        r.lastLat = p.latitude;
        r.lastLon = p.longitude;
        r.lastTimeMs = nowMs;
      }
      r.lastGpsAt = DateTime.now();
      r.lastSpeedKmh = speedKmh;

      final id = r.liveSessionId;
      if (id == null) continue;
      try {
        await api.saveLivePoint(TrackerLivePointPayload(
          liveSessionId: id,
          clubId: clubId,
          teamId: teamId,
          playerId: r.binding.playerId,
          deviceUuid: r.binding.deviceUuid,
          latitude: p.latitude,
          longitude: p.longitude,
          rawLatitude: p.latitude,
          rawLongitude: p.longitude,
          acceptedForMetrics: acceptedForMetrics,
          rejectReason: rejectReason,
          timeMs: nowMs,
          speedKmh: speedKmh,
          rawSpeedKmh: rawSpeedKmh,
          distanceDeltaM: deltaM,
          totalDistanceM: r.totalDistanceM,
          maxSpeedKmh: r.maxSpeedKmh,
          avgSpeedKmh: r.speedCount == 0 ? 0 : r.speedSum / r.speedCount,
          rawHex: event.data.rawHex,
        ));
        r.savedPoints++;
        r.lastServerSaveAt = DateTime.now();
        r.lastServerSavedPointTimeMs = nowMs;
        _closeServerGap(
          r,
          DateTime.fromMillisecondsSinceEpoch(nowMs),
        );
        r.lastError = null;
      } catch (e) {
        // Интернет может пропасть при полностью рабочем BLE. Локальные метрики
        // продолжают считаться, а окно несохранённых GPS-точек запоминаем для
        // последующей выгрузки из памяти трекера. Раньше recovery создавался
        // только при BLE-разрыве, поэтому сетевой gap мог потеряться.
        r.serverGapStartedAt ??= DateTime.fromMillisecondsSinceEpoch(
          r.lastServerSavedPointTimeMs ?? nowMs,
        );
        r.backfillRequired = true;
        r.lastError = 'server offline · Live локально продолжается: $e';
      }
    }
  }

  Future<void> stop({bool createFinalSession = true}) async {
    // Идемпотентная остановка: повторный сигнал от UI не должен повторно
    // закрывать первую/отдельную сессию команды.
    if (!_running) return;
    final stoppedAt = DateTime.now();
    for (final r in _runtime.values) {
      // Если игрок потерялся прямо перед STOP и watchdog ещё не успел сработать,
      // всё равно фиксируем хвост от последней GPS-точки до конца матча.
      if (r.bleGapStartedAt == null) {
        final lastGps = r.lastGpsAt;
        if (lastGps != null &&
            stoppedAt.difference(lastGps) > const Duration(seconds: 5)) {
          r.bleGapStartedAt = lastGps;
        } else if (lastGps == null &&
            r.liveStartedAt != null &&
            stoppedAt.difference(r.liveStartedAt!) >
                const Duration(seconds: 10)) {
          // Live мог вообще не получить первую GPS-точку, хотя внутренняя
          // запись трекера шла. Тогда recovery имеет право проверить весь матч.
          r.bleGapStartedAt = r.liveStartedAt;
        }
      }
      if (r.bleGapStartedAt != null) _closeOpenGap(r, stoppedAt);
      if (r.serverGapStartedAt != null) _closeServerGap(r, stoppedAt);
    }

    _running = false;
    pool.setLivePolling(false);
    _gpsScheduler?.cancel();
    _gpsScheduler = null;
    _bleWatchdog?.cancel();
    _bleWatchdog = null;
    unawaited(ActionTrackerBleService.setTrackerKeepScreenOn(false));
    _heartbeat?.cancel();
    _heartbeat = null;
    await _dataSub?.cancel();
    _dataSub = null;

    final recoveryBindings = <TeamTrackerBinding>[];
    for (final r in _runtime.values) {
      final id = r.liveSessionId;
      if (id == null) continue;
      try {
        final result = await api.stopLiveSession(
          liveSessionId: id,
          createFinalSession: createFinalSession,
        );
        r.liveStoppedAt = stoppedAt;
        r.finalSessionId = int.tryParse(
          '${result['final_session_id'] ?? result['session_id'] ?? 0}',
        );
        r.liveSessionId = null;

        if (createFinalSession &&
            r.backfillRequired &&
            (r.finalSessionId ?? 0) > 0) {
          final jobId = await api.createOfflineRecoveryJob(
            liveSessionId: id,
            finalSessionId: r.finalSessionId!,
            teamId: teamId,
            playerId: r.binding.playerId,
            deviceUuid: r.binding.deviceUuid,
            deviceName: r.binding.deviceName,
            liveStartedMs: r.liveStartedAt?.millisecondsSinceEpoch ??
                stoppedAt.millisecondsSinceEpoch,
            liveStoppedMs: stoppedAt.millisecondsSinceEpoch,
            gaps: r.gaps.map((g) => g.toJson()).toList(growable: false),
          );
          if (jobId > 0) {
            recoveryBindings.add(r.binding);
            await api.sendDebugLog(
              teamId: teamId,
              playerId: r.binding.playerId,
              liveSessionId: id,
              level: 'info',
              source: 'team_offline_recovery_job',
              message:
                  'Создано восстановление GPS · job=$jobId · ${r.binding.deviceName} · gaps=${r.gaps.length} · final_session=${r.finalSessionId}',
              deviceUuid: r.binding.deviceUuid,
              deviceName: r.binding.deviceName,
              context: <String, dynamic>{
                'job_id': jobId,
                'final_session_id': r.finalSessionId,
                'gaps': r.gaps.map((g) => g.toJson()).toList(growable: false),
              },
            );
          }
        }
      } catch (e) {
        r.lastError = 'stop: $e';
      }
    }

    // Не задерживаем закрытие матча тяжёлой BLE-выгрузкой. Задача уже записана
    // на сервере; пока экран открыт, пробуем восстановить её сразу. Если файл ещё
    // recording или приложение закроют, задача останется pending и продолжится
    // при следующем подключении этого UUID.
    if (recoveryBindings.isNotEmpty) {
      unawaited(_recoverBindingsSequentially(recoveryBindings));
    }
  }

  void _closeOpenGap(_Runtime runtime, DateTime at) {
    final from = runtime.bleGapStartedAt;
    if (from == null) return;
    runtime.bleGapStartedAt = null;
    if (!at.isAfter(from)) return;
    final duration = at.difference(from);
    if (duration.inSeconds < 2) return;
    runtime.gaps.add(_TrackerGap(from: from, to: at));
    runtime.backfillRequired = true;
  }

  void _closeServerGap(_Runtime runtime, DateTime at) {
    final from = runtime.serverGapStartedAt;
    if (from == null) return;
    runtime.serverGapStartedAt = null;
    if (!at.isAfter(from)) return;
    // Даже короткий сетевой gap важен: BLE мог принять несколько GPS-точек,
    // которые не дошли до HTTP API. Сервер recovery сам удалит дубликаты.
    runtime.gaps.add(_TrackerGap(from: from, to: at));
    runtime.backfillRequired = true;
  }

  Future<void> _recoverBindingsSequentially(
    Iterable<TeamTrackerBinding> bindings,
  ) async {
    for (final binding in bindings) {
      if (_running || _starting) return;
      await tryRecoverPendingForBinding(binding);
    }
  }

  Future<void> tryRecoverPendingForBinding(
    TeamTrackerBinding binding,
  ) async {
    if (_running || _starting) return;
    if (!pool.isConnected(binding.deviceUuid)) return;

    _offlineRecoveryTasks++;
    try {
      List<Map<String, dynamic>> jobs;
      try {
        jobs = await api.loadPendingOfflineRecoveryJobs(
          teamId: teamId,
          deviceUuid: binding.deviceUuid,
          playerId: binding.playerId,
        );
      } catch (e) {
        // Recovery — фоновая best-effort функция. Отсутствующий endpoint,
        // временный 404/nginx или отсутствие интернета не должны превращаться
        // в необработанный PlatformError и ломать локальный BLE-просмотр.
        return;
      }
      if (jobs.isEmpty || _running || _starting) return;

      for (final job in jobs) {
        if (_running || _starting) return;
        final jobId = int.tryParse('${job['id'] ?? job['job_id'] ?? 0}') ?? 0;
        if (jobId <= 0) continue;

        try {
          final records = await pool.requestRecordListFor(binding.deviceUuid);
          final match = _findRecordForJob(records, job);
          if (match == null) {
            const waitMessage =
                'Подходящая запись в памяти трекера пока не найдена';
            await api.markOfflineRecoveryWaiting(
              jobId: jobId,
              message: waitMessage,
            );
            await api.sendDebugLog(
              teamId: teamId,
              playerId: binding.playerId,
              level: 'info',
              source: 'team_offline_recovery_wait',
              message:
                  'Офлайн GPS ждёт · ${binding.deviceName} · job=$jobId · $waitMessage',
              deviceUuid: binding.deviceUuid,
              deviceName: binding.deviceName,
            );
            continue;
          }
          if (match.state != ActionTrackerRecordState.finished) {
            final waitMessage =
                'file ${match.fileId} ещё не finished (${match.state.name})';
            await api.markOfflineRecoveryWaiting(
              jobId: jobId,
              message: waitMessage,
            );
            await api.sendDebugLog(
              teamId: teamId,
              playerId: binding.playerId,
              level: 'info',
              source: 'team_offline_recovery_wait',
              message:
                  'Офлайн GPS ждёт · ${binding.deviceName} · job=$jobId · $waitMessage',
              deviceUuid: binding.deviceUuid,
              deviceName: binding.deviceName,
              context: <String, dynamic>{'record': match.toJson()},
            );
            continue;
          }

          final rawPoints = await pool.downloadFinishedRecord(
            binding.deviceUuid,
            match,
          );
          final points = _offlinePointsForJob(match, rawPoints, job);
          if (points.isEmpty) {
            await api.markOfflineRecoveryWaiting(
              jobId: jobId,
              message: 'Файл ${match.fileId} прочитан, но точек окна матча нет',
            );
            continue;
          }

          const batchSize = 1500;
          var first = true;
          for (var offset = 0; offset < points.length; offset += batchSize) {
            if (_running || _starting) {
              throw StateError('Восстановление прервано новым Team Live');
            }
            final end = offset + batchSize < points.length
                ? offset + batchSize
                : points.length;
            await api.uploadOfflineRecoveryChunk(
              jobId: jobId,
              record: match.toJson(),
              points: points.sublist(offset, end),
              reset: first,
            );
            first = false;
          }

          final result = await api.finalizeOfflineRecovery(
            jobId: jobId,
            record: match.toJson(),
          );
          await api.sendDebugLog(
            teamId: teamId,
            playerId: binding.playerId,
            level: 'info',
            source: 'team_offline_recovery_done',
            message:
                'Офлайн GPS восстановлен · ${binding.deviceName} · file=${match.fileId} · downloaded=${rawPoints.length} · window=${points.length} · inserted=${result['inserted_points'] ?? 0}',
            deviceUuid: binding.deviceUuid,
            deviceName: binding.deviceName,
            context: <String, dynamic>{
              'job_id': jobId,
              'record': match.toJson(),
              'result': result,
            },
          );
        } catch (e) {
          await api.markOfflineRecoveryWaiting(
            jobId: jobId,
            message: '$e',
          );
          await api.sendDebugLog(
            teamId: teamId,
            playerId: binding.playerId,
            level: 'warning',
            source: 'team_offline_recovery_wait',
            message:
                'Офлайн GPS пока не восстановлен · ${binding.deviceName}: $e',
            deviceUuid: binding.deviceUuid,
            deviceName: binding.deviceName,
          );
        }
      }
    } finally {
      if (_offlineRecoveryTasks > 0) _offlineRecoveryTasks--;
    }
  }

  ActionTrackerRecord? _findRecordForJob(
    List<ActionTrackerRecord> records,
    Map<String, dynamic> job,
  ) {
    final liveStartMs = int.tryParse('${job['live_started_ms'] ?? 0}') ?? 0;
    final liveStopMs = int.tryParse('${job['live_stopped_ms'] ?? 0}') ?? 0;
    if (records.isEmpty) return null;

    int overlapMs(ActionTrackerRecord record) {
      final start = _recordDateTime(record.startDateRaw, record.startTimeMs);
      if (start == null) return -1;

      DateTime end;
      if (record.state == ActionTrackerRecordState.recording ||
          record.endTimeMs <= 0) {
        // Физическая запись у этих ATP длится около 2.5 часа; 4 часа — только
        // безопасное окно выбора текущего файла. Во время recording файл
        // всё равно не скачивается.
        end = start.add(const Duration(hours: 4));
      } else {
        end = _recordDateTime(
              record.endDateRaw > 0
                  ? record.endDateRaw
                  : record.startDateRaw,
              record.endTimeMs,
            ) ??
            start.add(const Duration(hours: 4));
        if (!end.isAfter(start)) {
          end = end.add(const Duration(days: 1));
        }
      }

      if (liveStartMs <= 0 || liveStopMs <= 0) return 1;
      final startMs = start.millisecondsSinceEpoch;
      final endMs = end.millisecondsSinceEpoch;
      final from = math.max(startMs, liveStartMs);
      final to = math.min(endMs, liveStopMs);
      return math.max(0, to - from);
    }

    final candidates = records
        .where((record) {
          final overlap = overlapMs(record);
          if (overlap > 0) return true;
          final start =
              _recordDateTime(record.startDateRaw, record.startTimeMs);
          if (start == null || liveStartMs <= 0 || liveStopMs <= 0) {
            return overlap >= 0;
          }
          final startMs = start.millisecondsSinceEpoch;
          const tolerance = Duration(minutes: 10);
          return startMs >= liveStartMs - tolerance.inMilliseconds &&
              startMs <= liveStopMs + tolerance.inMilliseconds;
        })
        .toList(growable: false)
      ..sort((a, b) {
        final overlapCompare = overlapMs(b).compareTo(overlapMs(a));
        if (overlapCompare != 0) return overlapCompare;
        final aFinished =
            a.state == ActionTrackerRecordState.finished ? 1 : 0;
        final bFinished =
            b.state == ActionTrackerRecordState.finished ? 1 : 0;
        if (aFinished != bFinished) return bFinished.compareTo(aFinished);
        return b.fileId.compareTo(a.fileId);
      });

    return candidates.isEmpty ? null : candidates.first;
  }

  List<Map<String, dynamic>> _offlinePointsForJob(
    ActionTrackerRecord record,
    List<ActionTrackerGpsPoint> points,
    Map<String, dynamic> job,
  ) {
    final base = _recordDateTime(record.startDateRaw, 0);
    if (base == null) return const <Map<String, dynamic>>[];
    final liveStartMs = int.tryParse('${job['live_started_ms'] ?? 0}') ?? 0;
    final liveStopMs = int.tryParse('${job['live_stopped_ms'] ?? 0}') ?? 0;
    final int? minMs = liveStartMs > 0
        ? liveStartMs - const Duration(seconds: 3).inMilliseconds
        : null;
    final int? maxMs = liveStopMs > 0
        ? liveStopMs + const Duration(seconds: 3).inMilliseconds
        : null;

    final result = <Map<String, dynamic>>[];
    var dayOffset = 0;
    int? previousTod;
    for (final point in points) {
      if (point.latitude.abs() < 0.000001 &&
          point.longitude.abs() < 0.000001) continue;
      var raw = point.timeMs;
      int epochMs;
      if (raw > 1000000000000) {
        epochMs = raw;
      } else if (raw >= 86400000) {
        epochMs = base.millisecondsSinceEpoch + raw;
      } else {
        if (previousTod != null && raw + 12 * 60 * 60 * 1000 < previousTod) {
          dayOffset++;
        }
        previousTod = raw;
        epochMs = base.millisecondsSinceEpoch +
            dayOffset * 24 * 60 * 60 * 1000 +
            raw;
      }
      if (minMs != null && epochMs < minMs) continue;
      if (maxMs != null && epochMs > maxMs) continue;
      result.add(<String, dynamic>{
        'time_ms': epochMs,
        'latitude': point.latitude,
        'longitude': point.longitude,
      });
    }
    result.sort((a, b) =>
        (a['time_ms'] as int).compareTo(b['time_ms'] as int));
    return result;
  }

  DateTime? _recordDateTime(int dateRaw, int timeMs) {
    if (dateRaw <= 0) return null;
    var year = dateRaw ~/ 10000;
    final ddmm = dateRaw % 10000;
    final day = ddmm ~/ 100;
    final month = ddmm % 100;
    if (year < 100) year += 2000;
    if (month < 1 || month > 12 || day < 1 || day > 31) return null;
    // Дата/время в памяти ATP — UTC, как и clock из Live 0x3B.
    final midnightUtc = DateTime.utc(year, month, day);
    return midnightUtc.add(
      Duration(milliseconds: timeMs < 0 ? 0 : timeMs),
    );
  }


  static double _distanceM(double lat1, double lon1, double lat2, double lon2) {
    const earth = 6371000.0;
    final p1 = lat1 * math.pi / 180;
    final p2 = lat2 * math.pi / 180;
    final dp = (lat2 - lat1) * math.pi / 180;
    final dl = (lon2 - lon1) * math.pi / 180;
    final a = math.sin(dp / 2) * math.sin(dp / 2) +
        math.cos(p1) * math.cos(p2) * math.sin(dl / 2) * math.sin(dl / 2);
    return earth * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
  }

  static bool _samePhysicalTracker(
    String firstUuid,
    String firstName,
    String secondUuid,
    String secondName,
  ) {
    String normalizeId(String value) =>
        value.trim().toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
    String normalizeName(String value) =>
        value.trim().toUpperCase().replaceAll(RegExp(r'\s+'), ' ');

    final firstId = normalizeId(firstUuid);
    final secondId = normalizeId(secondUuid);
    if (firstId.isNotEmpty && secondId.isNotEmpty) {
      if (firstId == secondId ||
          (firstId.length >= 12 &&
              secondId.length >= 12 &&
              (firstId.endsWith(secondId) || secondId.endsWith(firstId)))) {
        return true;
      }
    }

    final a = normalizeName(firstName);
    final b = normalizeName(secondName);
    final namedTracker =
        a.startsWith(r'$ATP') || a.startsWith(r'$ACT') || a.startsWith(r'$GPS');
    return namedTracker && a.isNotEmpty && a == b;
  }

  Future<void> dispose() async {
    if (_running) await stop(createFinalSession: false);
    _bleWatchdog?.cancel();
    _bleWatchdog = null;
  }
}
