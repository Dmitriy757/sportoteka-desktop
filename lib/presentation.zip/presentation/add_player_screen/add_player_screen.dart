// lib/presentation/team_screen/add_player_screen.dart
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

class AddPlayerScreen extends StatefulWidget {
  final int teamId;
  final String teamName;

  const AddPlayerScreen({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<AddPlayerScreen> createState() => _AddPlayerScreenState();
}

class _AddPlayerScreenState extends State<AddPlayerScreen> {
  // =============================
  // ✅ ВАЖНО: твой реальный домен
  // =============================
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String uploadPhotoUrl = "$apiBase/upload_player_photo.php";
  static const String addPlayerUrl = "$apiBase/add_player.php";

  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController birthDateController = TextEditingController();
  final TextEditingController nationalityController = TextEditingController();
  final TextEditingController statValueController = TextEditingController();
  final TextEditingController positionController = TextEditingController();
  final TextEditingController jerseyNumberController = TextEditingController();

  final List<String> sportMetrics = const [
    'Игры',
    'Время на поле',
    'Вышел на замену',
    'Был заменен',
    'Пропущенные голы',
    'Игры на "ноль"',
    'Голы',
    'Голевые передачи',
    'Желтые карточки',
    'Две желтые карточки',
    'Красные карточки',
    'Рост',
    'Вес',
    'Достижения',
  ];

  String? selectedMetric;
  final Map<String, String> playerStats = {};

  File? selectedImage;

  bool isLoading = false;

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    emailController.dispose();
    birthDateController.dispose();
    nationalityController.dispose();
    statValueController.dispose();
    positionController.dispose();
    jerseyNumberController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() => selectedImage = File(pickedFile.path));
    }
  }

  Future<void> _selectDate() async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime(2007),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: ColorScheme.light(
              primary: Theme.of(context).primaryColor,
              onPrimary: Colors.white,
              onSurface: Theme.of(context).colorScheme.onBackground,
            ),
            textButtonTheme: TextButtonThemeData(
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).primaryColor,
              ),
            ),
          ),
          child: child!,
        );
      },
    );

    if (pickedDate != null) {
      birthDateController.text = DateFormat('yyyy-MM-dd').format(pickedDate);
    }
  }

  Widget _buildTextField(
    TextEditingController controller,
    String label, {
    bool isNumber = false,
    bool readOnly = false,
    VoidCallback? onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        readOnly: readOnly,
        onTap: onTap,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(
              color: Theme.of(context).dividerColor.withOpacity(0.2),
            ),
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  Widget _buildAvatarSection() {
    return Center(
      child: Stack(
        alignment: Alignment.bottomRight,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                width: 2,
              ),
              color: Colors.grey[100],
            ),
            child: selectedImage != null
                ? ClipOval(
                    child: Image.file(
                      selectedImage!,
                      fit: BoxFit.cover,
                    ),
                  )
                : Icon(
                    Icons.person_outline,
                    size: 40,
                    color: Theme.of(context).colorScheme.onBackground.withOpacity(0.3),
                  ),
          ),
          Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor,
              shape: BoxShape.circle,
              border: Border.all(color: Colors.white, width: 2),
            ),
            child: IconButton(
              icon: const Icon(Icons.camera_alt, size: 16, color: Colors.white),
              onPressed: _pickImage,
              padding: EdgeInsets.zero,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBanner(String title, String subtitle, IconData icon, Color color) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2), width: 1),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: color),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    color: Theme.of(context).colorScheme.onBackground,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    color: Theme.of(context).colorScheme.onBackground.withOpacity(0.6),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMetricChip(String metric, String value) {
    return Chip(
      label: Text('$metric: $value'),
      backgroundColor: Theme.of(context).primaryColor.withOpacity(0.1),
      labelStyle: TextStyle(color: Theme.of(context).colorScheme.onBackground),
      deleteIcon: Icon(Icons.close, size: 16, color: Colors.red.shade400),
      onDeleted: () => setState(() => playerStats.remove(metric)),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: Theme.of(context).dividerColor.withOpacity(0.1)),
      ),
    );
  }

  void _addStat() {
    if (selectedMetric != null && statValueController.text.trim().isNotEmpty) {
      playerStats[selectedMetric!] = statValueController.text.trim();
      statValueController.clear();
      selectedMetric = null;
      setState(() {});
    } else {
      Get.snackbar(
        'Ошибка',
        'Выберите метрику и введите значение',
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(16),
        borderRadius: 12,
      );
    }
  }

  Future<String> _uploadPhotoIfNeeded() async {
    if (selectedImage == null) return '';

    final request = http.MultipartRequest('POST', Uri.parse(uploadPhotoUrl));
    request.files.add(await http.MultipartFile.fromPath('photo', selectedImage!.path));

    final response = await request.send();
    final body = await response.stream.bytesToString();

    final jsonResp = jsonDecode(body);
    if (jsonResp['status'] == 'success') {
      return (jsonResp['url'] ?? '').toString();
    }
    throw Exception(jsonResp['message'] ?? 'Не удалось загрузить фото');
  }

  Future<void> _submitPlayer() async {
    final firstName = firstNameController.text.trim();
    final lastName = lastNameController.text.trim();
    final email = emailController.text.trim();
    final dob = birthDateController.text.trim();
    final nationality = nationalityController.text.trim();
    final position = positionController.text.trim();
    final jerseyNumber = int.tryParse(jerseyNumberController.text.trim()) ?? 0;

    final sportData = playerStats.entries.map((e) => "${e.key}: ${e.value}").join(", ");

    if ([firstName, lastName, email, dob, nationality].any((e) => e.isEmpty)) {
      Get.snackbar(
        'Ошибка',
        'Заполните все обязательные поля',
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(16),
        borderRadius: 12,
      );
      return;
    }

    setState(() => isLoading = true);

    try {
      final uploadedPhotoUrl = await _uploadPhotoIfNeeded();

      // ✅ контроль: тут всегда teamId именно открытой команды
      debugPrint("ADD PLAYER => team_id=${widget.teamId}, teamName=${widget.teamName}, email=$email");

      final response = await http.post(
        Uri.parse(addPlayerUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'first_name': firstName,
          'last_name': lastName,
          'email': email,
          'birth_date': dob,
          'nationality': nationality,
          'sport_data': sportData,
          'team_id': widget.teamId, // ✅ ЖЁСТКО
          'position': position,
          'jersey_number': jerseyNumber,
          'photo_url': uploadedPhotoUrl,
        }),
      );

      if (response.statusCode == 200 && response.body.isNotEmpty) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'success') {
          Get.snackbar(
            'Успех',
            'Игрок успешно добавлен в команду «${widget.teamName}»',
            snackPosition: SnackPosition.BOTTOM,
            margin: const EdgeInsets.all(16),
            borderRadius: 12,
            colorText: Colors.white,
            backgroundColor: Colors.green,
          );
          Navigator.pop(context, true);
        } else {
          throw Exception(data['message'] ?? 'Не удалось добавить игрока');
        }
      } else {
        throw Exception('Пустой ответ от сервера');
      }
    } catch (e) {
      Get.snackbar(
        'Ошибка',
        e.toString(),
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(16),
        borderRadius: 12,
        colorText: Colors.white,
        backgroundColor: Colors.red,
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final teamNameController = TextEditingController(text: widget.teamName);

    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.background,
      appBar: AppBar(
        title: const Text('Добавить игрока'),
        elevation: 0.5,
        backgroundColor: Colors.white,
        foregroundColor: Theme.of(context).colorScheme.onBackground,
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildAvatarSection(),
                  const SizedBox(height: 24),

                  _buildInfoBanner(
                    'Команда',
                    'Игрок будет добавлен строго в открытую команду',
                    Icons.verified_outlined,
                    Colors.blue,
                  ),
                  //_buildTextField(teamNameController, 'Команда', readOnly: true),

                  _buildInfoBanner(
                    'Основная информация',
                    'Заполните основные данные игрока',
                    Icons.info_outline,
                    Colors.indigo,
                  ),

                  _buildTextField(firstNameController, 'Имя'),
                  _buildTextField(lastNameController, 'Фамилия'),
                  _buildTextField(emailController, 'Email'),

                  _buildTextField(
                    birthDateController,
                    'Дата рождения',
                    readOnly: true,
                    onTap: _selectDate,
                  ),
                  _buildTextField(nationalityController, 'Гражданство'),

                  _buildInfoBanner(
                    'Спортивная информация',
                    'Укажите позицию и номер игрока',
                    Icons.sports_soccer,
                    Colors.green,
                  ),

                  _buildTextField(positionController, 'Позиция'),
                  _buildTextField(jerseyNumberController, 'Номер игрока', isNumber: true),

                  _buildInfoBanner(
                    'Статистика игрока',
                    'Добавьте спортивные показатели',
                    Icons.analytics_outlined,
                    Colors.orange,
                  ),

                  DropdownButtonFormField<String>(
                    decoration: InputDecoration(
                      labelText: 'Метрика',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(
                          color: Theme.of(context).dividerColor.withOpacity(0.2),
                        ),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                    ),
                    value: selectedMetric,
                    isExpanded: true,
                    items: sportMetrics
                        .map((m) => DropdownMenuItem(value: m, child: Text(m)))
                        .toList(),
                    onChanged: (value) => setState(() => selectedMetric = value),
                  ),

                  if (selectedMetric != null) ...[
                    const SizedBox(height: 12),
                    _buildTextField(statValueController, "Значение", isNumber: true),
                    const SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: _addStat,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Theme.of(context).primaryColor,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 0,
                      ),
                      child: const Text('Добавить метрику'),
                    ),
                  ],

                  if (playerStats.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: playerStats.entries
                          .map((e) => _buildMetricChip(e.key, e.value))
                          .toList(),
                    ),
                  ],

                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _submitPlayer,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Theme.of(context).primaryColor,
                      foregroundColor: Colors.white,
                      minimumSize: const Size(double.infinity, 50),
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text('Добавить игрока'),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
    );
  }
}
