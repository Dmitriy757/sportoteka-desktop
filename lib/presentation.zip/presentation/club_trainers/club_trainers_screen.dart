import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

class ClubTrainersScreen extends StatefulWidget {
  final int clubId;
  final String clubName;

  const ClubTrainersScreen({
    super.key,
    required this.clubId,
    required this.clubName,
  });

  @override
  State<ClubTrainersScreen> createState() => _ClubTrainersScreenState();
}

class _ClubTrainersScreenState extends State<ClubTrainersScreen> {
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getClubTrainersUrl = "$apiBase/get_club_trainers.php";
  static const String searchTrainerByEmailUrl =
      "$apiBase/search_trainer_by_email.php";

  // ✅ endpoints для привязки/отвязки (как у тебя)
  static const String linkTrainerUrl = "$apiBase/link_trainer_to_club.php";
  static const String unlinkTrainerUrl = "$apiBase/unlink_trainer_from_club.php";

  bool loading = true;
  String? error;

  final TextEditingController _searchCtrl = TextEditingController();

  List<Map<String, dynamic>> trainers = [];
  List<Map<String, dynamic>> filtered = [];

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_applyFilter);
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_applyFilter);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _applyFilter() {
    final q = _searchCtrl.text.trim().toLowerCase();
    if (q.isEmpty) {
      setState(() => filtered = List.of(trainers));
      return;
    }
    setState(() {
      filtered = trainers.where((t) {
        final fn = _asStr(t["first_name"]).toLowerCase();
        final ln = _asStr(t["last_name"]).toLowerCase();
        final email = _asStr(t["email"]).toLowerCase();
        final pos = _pickAnyStr(t, ["position", "role_title", "title"]).toLowerCase();
        return fn.contains(q) ||
            ln.contains(q) ||
            email.contains(q) ||
            pos.contains(q);
      }).toList();
    });
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final resp = await http.post(
        Uri.parse(getClubTrainersUrl),
        body: {"club_id": widget.clubId.toString()},
      );
      final data = _decode(resp);

      if (data["success"] == true && data["trainers"] is List) {
        final list = (data["trainers"] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

        trainers = list;
        filtered = List.of(trainers);
      } else {
        trainers = [];
        filtered = [];
      }

      if (mounted) setState(() => loading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = "Ошибка загрузки тренеров: $e";
      });
    }
  }

  // =============================
  // 🔎 SEARCH TRAINER BY EXACT EMAIL
  // =============================
  Future<List<Map<String, dynamic>>> _searchTrainerByEmail(String email) async {
    try {
      final clean = email.trim();
      if (clean.isEmpty) return [];

      final resp = await http.post(
        Uri.parse(searchTrainerByEmailUrl),
        body: {"email": clean},
      );

      final data = _decode(resp);

      if (data["success"] == true && data["trainers"] is List) {
        final list = (data["trainers"] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
        return list;
      }
      return [];
    } catch (_) {
      return [];
    }
  }

  Future<Map<String, dynamic>?> _pickTrainerByEmailSheet() async {
    final emailCtrl = TextEditingController();
    List<Map<String, dynamic>> results = [];
    bool searching = false;

    return await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(22)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setSB) {
            Future<void> doSearch() async {
              final q = emailCtrl.text.trim();
              if (q.isEmpty) {
                setSB(() => results = []);
                return;
              }
              setSB(() => searching = true);
              final r = await _searchTrainerByEmail(q);
              setSB(() {
                searching = false;
                results = r;
              });

              if (r.isEmpty) {
                Get.snackbar(
                  "Не найдено",
                  "Тренер с таким email не найден.\nПроверь точный email и что role = coach.",
                  snackPosition: SnackPosition.BOTTOM,
                  margin: const EdgeInsets.all(12),
                );
              }
            }

            return Padding(
              padding: EdgeInsets.only(
                left: 16,
                right: 16,
                top: 14,
                bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 44,
                      height: 5,
                      margin: const EdgeInsets.only(bottom: 12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE5E7EB),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Добавить тренера по email",
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                      ),
                    ),
                    const SizedBox(height: 6),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        "Тренер получит доступ к своей команде через привязку.\nЗдесь отображение — информационное (визитка).",
                        style: TextStyle(color: Color(0xFF6B7280), fontWeight: FontWeight.w600),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: emailCtrl,
                      keyboardType: TextInputType.emailAddress,
                      textInputAction: TextInputAction.search,
                      onSubmitted: (_) => doSearch(),
                      decoration: InputDecoration(
                        labelText: "Точный email тренера",
                        hintText: "coach@mail.com",
                        border: const OutlineInputBorder(),
                        suffixIcon: IconButton(
                          icon: const Icon(Icons.search),
                          onPressed: doSearch,
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (searching)
                      const Padding(
                        padding: EdgeInsets.all(16),
                        child: CircularProgressIndicator(),
                      )
                    else if (results.isEmpty)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: Text(
                          "Введите точный email и нажмите поиск.",
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Color(0xFF6B7280)),
                        ),
                      )
                    else
                      Flexible(
                        child: ListView.separated(
                          shrinkWrap: true,
                          itemCount: results.length,
                          separatorBuilder: (_, __) => const Divider(height: 1),
                          itemBuilder: (context, i) {
                            final t = results[i];
                            final id = _asInt(t["id"]);
                            final email = _asStr(t["email"]);
                            final fn = _asStr(t["first_name"]);
                            final ln = _asStr(t["last_name"]);
                            final name = ("$fn $ln").trim();
                            return ListTile(
                              leading: const CircleAvatar(child: Icon(Icons.person_outline)),
                              title: Text(name.isEmpty ? "Тренер #$id" : name),
                              subtitle: Text(email),
                              onTap: () => Navigator.pop(context, {
                                "id": id,
                                "name": name.isEmpty ? "Тренер #$id" : name,
                                "email": email,
                              }),
                            );
                          },
                        ),
                      ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _linkTrainer(int trainerId) async {
    try {
      Get.snackbar("Тренеры", "Добавляю тренера...", snackPosition: SnackPosition.BOTTOM);

      final resp = await http.post(
        Uri.parse(linkTrainerUrl),
        body: {
          "club_id": widget.clubId.toString(),
          "trainer_id": trainerId.toString(),
        },
      );
      final data = _decode(resp);

      if (data["success"] == true) {
        Get.snackbar("Готово", "Тренер добавлен в клуб", snackPosition: SnackPosition.BOTTOM);
        await _load();
      } else {
        Get.snackbar("Ошибка", _asStr(data["message"]).isEmpty ? "Не удалось добавить" : _asStr(data["message"]));
      }
    } catch (e) {
      Get.snackbar("Сеть", "Ошибка соединения: $e");
    }
  }

  Future<void> _unlinkTrainer(int trainerId) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Удалить тренера из списка?"),
        content: const Text("Тренер будет отвязан от клуба и исчезнет из списка."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Отмена")),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Удалить", style: TextStyle(color: Colors.red, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );

    if (ok != true) return;

    try {
      Get.snackbar("Тренеры", "Удаляю...", snackPosition: SnackPosition.BOTTOM);

      final resp = await http.post(
        Uri.parse(unlinkTrainerUrl),
        body: {
          "club_id": widget.clubId.toString(),
          "trainer_id": trainerId.toString(),
        },
      );
      final data = _decode(resp);

      if (data["success"] == true) {
        Get.snackbar("Готово", "Тренер удалён", snackPosition: SnackPosition.BOTTOM);
        await _load();
      } else {
        Get.snackbar("Ошибка", _asStr(data["message"]).isEmpty ? "Не удалось удалить" : _asStr(data["message"]));
      }
    } catch (e) {
      Get.snackbar("Сеть", "Ошибка соединения: $e");
    }
  }

  void _openTrainerCard(Map<String, dynamic> t) {
    final trainer = Map<String, dynamic>.from(t);
    Get.to(() => TrainerCardScreen(
          clubName: widget.clubName,
          trainer: trainer,
        ));
  }

  // =============================
  // UI
  // =============================
  @override
  Widget build(BuildContext context) {
    final bg = const Color(0xFFF3F5F8);
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: Text(
          widget.clubName,
          style: const TextStyle(fontWeight: FontWeight.w900, color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          IconButton(
            tooltip: "Обновить",
            onPressed: _load,
            icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: primary,
        onPressed: () async {
          final picked = await _pickTrainerByEmailSheet();
          if (picked == null) return;
          final id = _asInt(picked["id"]);
          if (id <= 0) return;
          await _linkTrainer(id);
        },
        icon: const Icon(Icons.person_add_alt_1, color: Colors.white),
        label: const Text(
          "Добавить тренера",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? _ErrorView(text: error!, onRetry: _load)
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                    children: [
                      _ClubHeader(
                        clubName: widget.clubName,
                        count: trainers.length,
                      ),
                      const SizedBox(height: 12),

                      // поиск
                      _SearchBox(controller: _searchCtrl),

                      const SizedBox(height: 12),

                      if (filtered.isEmpty)
                        const _EmptyHint(
                          text: "Пока нет тренеров в списке.\nНажмите «Добавить тренера» и привяжите по email.",
                        )
                      else
                        ...filtered.map(
                          (t) => _TrainerTile(
                            primary: primary,
                            clubName: widget.clubName,
                            trainer: t,
                            onTap: () => _openTrainerCard(t),
                            onRemove: () => _unlinkTrainer(_asInt(t["id"])),
                          ),
                        ),
                    ],
                  ),
                ),
    );
  }

  // =============================
  // helpers
  // =============================
  Map<String, dynamic> _decode(http.Response resp) {
    try {
      final j = json.decode(resp.body);
      if (j is Map<String, dynamic>) return j;
      return {"success": false};
    } catch (_) {
      return {"success": false};
    }
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  String _asStr(dynamic v) => (v ?? "").toString();

  String _pickAnyStr(Map<String, dynamic> m, List<String> keys) {
    for (final k in keys) {
      final v = (m[k] ?? "").toString().trim();
      if (v.isNotEmpty) return v;
    }
    return "";
  }
}

// ============================================================================
// Trainer визитка (экран)
// ============================================================================
class TrainerCardScreen extends StatelessWidget {
  final String clubName;
  final Map<String, dynamic> trainer;

  const TrainerCardScreen({
    super.key,
    required this.clubName,
    required this.trainer,
  });

  String _asStr(dynamic v) => (v ?? "").toString();
  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  String _pickAnyStr(List<String> keys) {
    for (final k in keys) {
      final v = (trainer[k] ?? "").toString().trim();
      if (v.isNotEmpty) return v;
    }
    return "";
  }

  String? _normalizePhoto(String? raw) {
    if (raw == null) return null;
    var s = raw.trim();
    if (s.isEmpty) return null;
    if (s.startsWith("http://") || s.startsWith("https://")) return s;
    if (!s.startsWith("/")) s = "/$s";
    return "https://sportotekaapp.ru$s";
  }

  @override
  Widget build(BuildContext context) {
    final bg = const Color(0xFFF3F5F8);
    final primary = Theme.of(context).colorScheme.primary;

    final id = _asInt(trainer["id"]);
    final fn = _asStr(trainer["first_name"]).trim();
    final ln = _asStr(trainer["last_name"]).trim();
    final email = _asStr(trainer["email"]).trim();
    final name = ("$fn $ln").trim().isEmpty ? "Тренер #$id" : ("$fn $ln").trim();

    final pos = _pickAnyStr(["position", "role_title", "title"]).trim();
    final bio = _pickAnyStr(["bio", "about", "description"]).trim();
    final born = _pickAnyStr(["born", "birth_date", "birthday"]).trim();
    final career = _pickAnyStr(["career", "experience", "history"]).trim();

    final photo = _normalizePhoto(_asStr(trainer["photo"]).trim().isEmpty ? null : _asStr(trainer["photo"]));

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.black87),
        title: const Text(
          "Визитная карточка",
          style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          // Top card
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(20),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.04),
                  blurRadius: 14,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Row(
              children: [
                Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: primary.withOpacity(0.25), width: 2),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(999),
                    child: photo != null
                        ? Image.network(
                            photo,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => _fallbackAvatar(primary),
                          )
                        : _fallbackAvatar(primary),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18),
                      ),
                      const SizedBox(height: 6),
                      if (pos.isNotEmpty)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                          decoration: BoxDecoration(
                            color: primary.withOpacity(0.10),
                            borderRadius: BorderRadius.circular(999),
                          ),
                          child: Text(
                            pos,
                            style: TextStyle(color: primary, fontWeight: FontWeight.w900),
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                        )
                      else
                        Text(
                          "Тренер-преподаватель",
                          style: TextStyle(color: primary, fontWeight: FontWeight.w900),
                        ),
                      const SizedBox(height: 8),
                      Text(
                        clubName,
                        style: const TextStyle(color: Color(0xFF6B7280), fontWeight: FontWeight.w700),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                      if (email.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          email,
                          style: const TextStyle(color: Color(0xFF6B7280), fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 12),

          // Sections
          if (born.isNotEmpty) _InfoSection(title: "Дата рождения", text: born),
          if (career.isNotEmpty) ...[
            const SizedBox(height: 12),
            _InfoSection(title: "Опыт / карьера", text: career),
          ],

          const SizedBox(height: 12),
          _InfoSection(
            title: "Описание",
            text: bio.isNotEmpty
                ? bio
                : "Описание тренера пока не заполнено.\nМожно добавить текст в базе и выводить здесь как визитку.",
          ),
        ],
      ),
    );
  }

  Widget _fallbackAvatar(Color primary) {
    return Container(
      color: primary.withOpacity(0.10),
      child: Icon(Icons.person_outline, color: primary),
    );
  }
}

// ============================================================================
// UI pieces
// ============================================================================
class _ClubHeader extends StatelessWidget {
  final String clubName;
  final int count;

  const _ClubHeader({
    required this.clubName,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: [primary.withOpacity(0.95), primary.withOpacity(0.55)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.18),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.school_outlined, color: Colors.white),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Тренерско-преподавательский состав",
                  style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 15),
                ),
                const SizedBox(height: 4),
                Text(
                  "$clubName • $count",
                  style: TextStyle(color: Colors.white.withOpacity(0.9), fontWeight: FontWeight.w700),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SearchBox extends StatelessWidget {
  final TextEditingController controller;
  const _SearchBox({required this.controller});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 14,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: TextField(
        controller: controller,
        decoration: const InputDecoration(
          border: InputBorder.none,
          hintText: "Поиск: ФИО, должность или email",
          icon: Icon(Icons.search),
        ),
      ),
    );
  }
}

class _TrainerTile extends StatelessWidget {
  final Color primary;
  final String clubName;
  final Map<String, dynamic> trainer;
  final VoidCallback onTap;
  final VoidCallback onRemove;

  const _TrainerTile({
    required this.primary,
    required this.clubName,
    required this.trainer,
    required this.onTap,
    required this.onRemove,
  });

  String _asStr(dynamic v) => (v ?? "").toString();
  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }

  String _pickAnyStr(List<String> keys) {
    for (final k in keys) {
      final v = (trainer[k] ?? "").toString().trim();
      if (v.isNotEmpty) return v;
    }
    return "";
  }

  String? _normalizePhoto(String? raw) {
    if (raw == null) return null;
    var s = raw.trim();
    if (s.isEmpty) return null;
    if (s.startsWith("http://") || s.startsWith("https://")) return s;
    if (!s.startsWith("/")) s = "/$s";
    return "https://sportotekaapp.ru$s";
  }

  @override
  Widget build(BuildContext context) {
    final id = _asInt(trainer["id"]);
    final fn = _asStr(trainer["first_name"]).trim();
    final ln = _asStr(trainer["last_name"]).trim();
    final name = ("$fn $ln").trim().isEmpty ? "Тренер #$id" : ("$fn $ln").trim();

    final pos = _pickAnyStr(["position", "role_title", "title"]);
    final email = _asStr(trainer["email"]).trim();

    final photo = _normalizePhoto(_asStr(trainer["photo"]).trim().isEmpty ? null : _asStr(trainer["photo"]));

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 14,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Row(
          children: [
            // avatar
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: primary.withOpacity(0.25), width: 2),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(999),
                child: photo != null
                    ? Image.network(
                        photo,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => _fallbackAvatar(),
                      )
                    : _fallbackAvatar(),
              ),
            ),
            const SizedBox(width: 12),

            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // name + menu
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15),
                        ),
                      ),
                      PopupMenuButton<String>(
                        onSelected: (v) {
                          if (v == "remove") onRemove();
                        },
                        itemBuilder: (_) => const [
                          PopupMenuItem(
                            value: "remove",
                            child: Row(
                              children: [
                                Icon(Icons.link_off, color: Colors.red, size: 18),
                                SizedBox(width: 10),
                                Text("Удалить из списка", style: TextStyle(fontWeight: FontWeight.w800)),
                              ],
                            ),
                          ),
                        ],
                        child: const Padding(
                          padding: EdgeInsets.all(6),
                          child: Icon(Icons.more_horiz),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),

                  // position chip
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: primary.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          pos.isNotEmpty ? pos : "тренер-преподаватель",
                          style: TextStyle(color: primary, fontWeight: FontWeight.w900, fontSize: 12),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFF3F5F8),
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: Text(
                          clubName,
                          style: const TextStyle(color: Color(0xFF111827), fontWeight: FontWeight.w800, fontSize: 12),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),

                  if (email.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      email,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: Color(0xFF6B7280), fontWeight: FontWeight.w600),
                    ),
                  ],

                  const SizedBox(height: 10),

                  // hint
                  Row(
                    children: [
                      Icon(Icons.badge_outlined, size: 18, color: primary),
                      const SizedBox(width: 8),
                      const Text(
                        "Открыть визитку",
                        style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF111827)),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fallbackAvatar() {
    return Container(
      color: primary.withOpacity(0.10),
      child: Icon(Icons.person_outline, color: primary),
    );
  }
}

class _InfoSection extends StatelessWidget {
  final String title;
  final String text;

  const _InfoSection({
    required this.title,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 14,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
          const SizedBox(height: 8),
          Text(
            text,
            style: const TextStyle(color: Color(0xFF111827), fontWeight: FontWeight.w600, height: 1.35),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;
  const _ErrorView({required this.text, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 44),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: onRetry, child: const Text("Повторить")),
          ],
        ),
      ),
    );
  }
}

class _EmptyHint extends StatelessWidget {
  final String text;
  const _EmptyHint({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF6B7280),
          fontWeight: FontWeight.w600,
          height: 1.35,
        ),
      ),
    );
  }
}
