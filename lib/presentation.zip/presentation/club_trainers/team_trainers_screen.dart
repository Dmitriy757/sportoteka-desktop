// lib/presentation/club_trainers/team_trainers_screen.dart
import 'dart:async';
import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/constants/app_colors.dart';
import 'package:sportoteka/presentation/club_trainers/edit_trainer_profile_screen.dart';
import 'package:sportoteka/presentation/my_team_screen/my_team_screen.dart';

// =============================
// КОНСТАНТЫ И КОНФИГУРАЦИЯ
// =============================
class _ApiEndpoints {
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getTeamTrainers = "$apiBase/get_team_trainers.php";
  static const String linkTrainerToTeam = "$apiBase/link_trainer_to_team.php";
  static const String unlinkTrainerFromTeam = "$apiBase/unlink_trainer_from_team.php";
  static const String searchTrainerByEmail = "$apiBase/search_trainer_by_email.php";
  static const String getClubProfile = "$apiBase/get_club_profile.php";
  static const String getTrainerProfile = "$apiBase/get_trainer_profile.php";
}

// =============================
// РОЛИ (UI) — ПОКА СЕКЦИИ, ПОТОМ ПРИВЯЖЕМ К RBAC
// =============================
enum StaffRoleGroup {
  all,
  mainCoaches,
  coaches,
  assistantCoaches,
  goalkeeperCoaches,
  methodists,
  doctors,
  press,
  managers,
}

class _RoleUi {
  final StaffRoleGroup key;
  final String title;
  final String subtitle;
  final IconData icon;

  const _RoleUi(this.key, this.title, this.subtitle, this.icon);
}

const List<_RoleUi> _roleTabs = [
  _RoleUi(StaffRoleGroup.all, "Все", "Весь штаб", Icons.groups_2_rounded),
  _RoleUi(StaffRoleGroup.mainCoaches, "Главные", "Главные тренеры", Icons.star_rounded),
  _RoleUi(StaffRoleGroup.coaches, "Тренеры", "Тренерский состав", Icons.sports_rounded),
  _RoleUi(StaffRoleGroup.assistantCoaches, "Помощники", "Ассистенты", Icons.support_agent_rounded),
  _RoleUi(StaffRoleGroup.goalkeeperCoaches, "Вратари", "Тренеры вратарей", Icons.sports_handball_rounded),
  _RoleUi(StaffRoleGroup.methodists, "Методисты", "Инструкторы-методисты", Icons.menu_book_rounded),
  _RoleUi(StaffRoleGroup.doctors, "Врачи", "Спорт-медицина", Icons.medical_services_rounded),
  _RoleUi(StaffRoleGroup.press, "Пресс", "Посты / Рилсы", Icons.campaign_rounded),
  _RoleUi(StaffRoleGroup.managers, "Менеджмент", "Администрация", Icons.admin_panel_settings_rounded),
];

// =============================
// УТИЛИТЫ
// =============================
class _Utils {
  static int asInt(dynamic value) {
    if (value is int) return value;
    if (value is String) return int.tryParse(value) ?? 0;
    return 0;
  }

  static bool asBool(dynamic value) {
    if (value is bool) return value;
    if (value is String) return value.toLowerCase().trim() == "true";
    if (value is num) return value != 0;
    return false;
  }

  static String asString(dynamic value) => (value ?? "").toString();

  static Map<String, dynamic> decodeResponse(http.Response response) {
    try {
      final json = jsonDecode(response.body);
      return json is Map<String, dynamic> ? json : {"status": "error", "message": "Некорректный JSON"};
    } catch (_) {
      return {"status": "error", "message": "Ошибка парсинга JSON"};
    }
  }

  static Future<Map<String, dynamic>> postJson(String url, Map<String, dynamic> body) async {
    final response = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json; charset=utf-8"},
      body: jsonEncode(body),
    );
    return decodeResponse(response);
  }

  static String? normalizeImage(String? raw) {
    if (raw == null || raw.trim().isEmpty) return null;
    String url = raw.trim();

    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    if (url.startsWith("//")) return "https:$url";
    if (url.startsWith("sportotekaapp.ru/")) return "https://$url";
    if (url.startsWith("www.sportotekaapp.ru/")) return "https://$url";
    if (url.startsWith("/")) return "https://sportotekaapp.ru$url";
    if (url.startsWith("uploads/")) return "https://sportotekaapp.ru/$url";

    return "https://sportotekaapp.ru/uploads/$url";
  }

  static String getTrainerName(Map<String, dynamic> trainer) {
    final firstName = asString(trainer["first_name"]).trim();
    final lastName = asString(trainer["last_name"]).trim();
    final name = "$firstName $lastName".trim();
    final id = asInt(trainer["id"]);
    return name.isNotEmpty ? name : "Тренер #$id";
  }
}

// =============================
// ОСНОВНОЙ ЭКРАН
// =============================
class TeamTrainersScreen extends StatefulWidget {
  final int clubId;
  final String clubName;
  final List<dynamic> teams;
  final String? clubLogoUrl;

  const TeamTrainersScreen({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teams,
    this.clubLogoUrl,
  });

  @override
  State<TeamTrainersScreen> createState() => _TeamTrainersScreenState();
}

class _TeamTrainersScreenState extends State<TeamTrainersScreen> {
  bool _isLoading = true;
  String? _errorMessage;
  List<Map<String, dynamic>> _trainers = [];
  List<Map<String, dynamic>> _filteredTrainers = [];
  String? _clubLogoUrl;

  StaffRoleGroup _selectedGroup = StaffRoleGroup.all;

  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _searchController.addListener(_applyFilter);
    _initializeData();
  }

  @override
  void dispose() {
    _searchController.removeListener(_applyFilter);
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _initializeData() async {
    _clubLogoUrl = _Utils.normalizeImage(widget.clubLogoUrl);
    if (_clubLogoUrl == null) {
      await _loadClubLogo();
    }

    if (widget.teams.isEmpty) {
      setState(() {
        _isLoading = false;
        _errorMessage = "У клуба нет команд";
        _trainers = [];
        _filteredTrainers = [];
      });
    } else {
      await _loadTrainers();
    }
  }

  // =============================
  // API
  // =============================
  Future<void> _loadClubLogo() async {
    try {
      final url = Uri.parse("${_ApiEndpoints.getClubProfile}?club_id=${widget.clubId}");
      final response = await http.get(url);
      final data = _Utils.decodeResponse(response);

      if (data["success"] == true && data["club"] is Map) {
        final club = Map<String, dynamic>.from(data["club"]);
        final rawLogo = _Utils.asString(club["photo_url"] ?? club["photo"]);
        final resolvedLogo = _Utils.normalizeImage(rawLogo);

        if (mounted) {
          setState(() => _clubLogoUrl = resolvedLogo);
        } else {
          _clubLogoUrl = resolvedLogo;
        }
      }
    } catch (_) {}
  }

  Future<void> _loadTrainers() async {
    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _trainers = [];
      _filteredTrainers = [];
    });

    try {
      // meta по командам (id/name/logo)
      final teamMeta = <int, Map<String, dynamic>>{};
      for (final rawTeam in widget.teams) {
        final teamId = _getTeamId(rawTeam);
        if (teamId <= 0) continue;

        teamMeta[teamId] = {
          "team_id": teamId,
          "team_name": _getTeamName(rawTeam),
          "team_logo": _getTeamLogo(rawTeam),
        };
      }

      final teamIds = teamMeta.keys.toList();
      if (teamIds.isEmpty) {
        setState(() {
          _isLoading = false;
          _errorMessage = "Не найдены team_id у команд";
        });
        return;
      }

      // грузим тренеров по каждой команде
      final results = await Future.wait(
        teamIds.map((teamId) async {
          final data = await _Utils.postJson(_ApiEndpoints.getTeamTrainers, {"team_id": teamId});
          final trainers = (data["trainers"] is List) ? (data["trainers"] as List) : const [];
          final mainCoachId = _Utils.asInt(data["main_coach_id"]);
          return {"team_id": teamId, "main_coach_id": mainCoachId, "trainers": trainers};
        }),
      );

      // агрегируем тренеров в общий список (один тренер -> список команд)
      final aggregated = <int, Map<String, dynamic>>{};

      for (final result in results) {
        final teamId = _Utils.asInt(result["team_id"]);
        final teamData = teamMeta[teamId];
        if (teamData == null) continue;

        final mainCoachId = _Utils.asInt(result["main_coach_id"]);
        final trainers = (result["trainers"] is List) ? (result["trainers"] as List) : const [];

        for (final t in trainers) {
          if (t is! Map) continue;
          final trainerMap = Map<String, dynamic>.from(t);
          final trainerId = _Utils.asInt(trainerMap["id"]);
          if (trainerId <= 0) continue;

          final base = aggregated.putIfAbsent(trainerId, () {
            final copy = Map<String, dynamic>.from(trainerMap);
            copy["teams"] = <Map<String, dynamic>>[];
            copy["is_main_any"] = false; // ✅ главный хотя бы в одной команде
            copy["profile"] = "extra"; // для отображения (глобально)
            return copy;
          });

          // профиль связи именно в ЭТОЙ команде
          final linkProfile = _Utils.asString(trainerMap["profile"]).trim().toLowerCase();

          // признак главного в этой команде: либо profile=main, либо совпал main_coach_id
          final isMainHere = (linkProfile == "main") || (mainCoachId > 0 && trainerId == mainCoachId);

          if (isMainHere) {
            base["is_main_any"] = true;
            base["profile"] = "main"; // глобально для бейджа/сортировки
          }

          final teams = (base["teams"] as List).cast<Map<String, dynamic>>();
          final exists = teams.any((team) => _Utils.asInt(team["team_id"]) == teamId);

          if (!exists) {
            final teamWithLink = <String, dynamic>{
              ...teamData,
              "link_profile": linkProfile, // ✅ важно для отвязки/показа
              "main_coach_id": mainCoachId,
            };
            teams.add(teamWithLink);
          }
        }
      }

      _trainers = aggregated.values.toList()
        ..sort((a, b) {
          final mA = _Utils.asBool(a["is_main_any"]);
          final mB = _Utils.asBool(b["is_main_any"]);
          if (mA && !mB) return -1;
          if (mB && !mA) return 1;

          final nameA = "${_Utils.asString(a["last_name"])} ${_Utils.asString(a["first_name"])}".toLowerCase();
          final nameB = "${_Utils.asString(b["last_name"])} ${_Utils.asString(b["first_name"])}".toLowerCase();
          return nameA.compareTo(nameB);
        });

      _filteredTrainers = List.of(_trainers);
      setState(() => _isLoading = false);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isLoading = false;
        _errorMessage = "Ошибка загрузки: $e";
      });
    }
  }

  // =============================
  // SEARCH
  // =============================
  void _applyFilter() {
    final query = _searchController.text.trim().toLowerCase();
    if (query.isEmpty) {
      setState(() => _filteredTrainers = List.of(_trainers));
      return;
    }

    setState(() {
      _filteredTrainers = _trainers.where((trainer) {
        final firstName = _Utils.asString(trainer["first_name"]).toLowerCase();
        final lastName = _Utils.asString(trainer["last_name"]).toLowerCase();
        final email = _Utils.asString(trainer["email"]).toLowerCase();

        final teams = (trainer["teams"] is List) ? (trainer["teams"] as List) : const [];
        final teamNames =
            teams.whereType<Map>().map((team) => _Utils.asString(team["team_name"]).toLowerCase()).join(" ");

        return firstName.contains(query) || lastName.contains(query) || email.contains(query) || teamNames.contains(query);
      }).toList();
    });
  }

  // =============================
  // ROLE GROUPING (ПОКА ПРОСТО: Главный / Тренер)
  // потом подключим реальные role_code/staff_role
  // =============================
  StaffRoleGroup _detectGroup(Map<String, dynamic> t) {
    final isMainAny = _Utils.asBool(t["is_main_any"]);
    if (isMainAny) return StaffRoleGroup.mainCoaches;

    // Пока ролей нет — все остальные как "Тренеры"
    return StaffRoleGroup.coaches;
  }

  Map<StaffRoleGroup, List<Map<String, dynamic>>> _groupedTrainers(List<Map<String, dynamic>> list) {
    final map = <StaffRoleGroup, List<Map<String, dynamic>>>{};
    for (final t in list) {
      final g = _detectGroup(t);
      (map[g] ??= []).add(t);
    }

    for (final e in map.entries) {
      e.value.sort((a, b) => _Utils.getTrainerName(a).toLowerCase().compareTo(_Utils.getTrainerName(b).toLowerCase()));
    }
    return map;
  }

  int _countForGroup(StaffRoleGroup g) {
    if (g == StaffRoleGroup.all) return _filteredTrainers.length;
    return _filteredTrainers.where((t) => _detectGroup(t) == g).length;
  }

  List<Map<String, dynamic>> _listForSelectedGroup() {
    if (_selectedGroup == StaffRoleGroup.all) return _filteredTrainers;
    return _filteredTrainers.where((t) => _detectGroup(t) == _selectedGroup).toList();
  }

  // =============================
  // ADD TRAINER
  // =============================
  Future<void> _addTrainer() async {
    if (widget.teams.isEmpty) {
      Get.snackbar("Команды", "У клуба нет команд");
      return;
    }

    final emailController = TextEditingController();
    final foundTrainers = <Map<String, dynamic>>[];
    bool isSearching = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateSB) {
            Future<void> searchTrainer() async {
              final email = emailController.text.trim();
              if (email.isEmpty) return;

              setStateSB(() => isSearching = true);
              try {
                final response = await http.post(
                  Uri.parse(_ApiEndpoints.searchTrainerByEmail),
                  body: {"email": email},
                );
                final data = _Utils.decodeResponse(response);

                if ((data["success"] == true || data["status"] == "success") && data["trainers"] is List) {
                  final trainers =
                      (data["trainers"] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();
                  setStateSB(() {
                    foundTrainers
                      ..clear()
                      ..addAll(trainers);
                  });
                } else {
                  setStateSB(() => foundTrainers.clear());
                }
              } catch (_) {
                setStateSB(() => foundTrainers.clear());
              }
              setStateSB(() => isSearching = false);
            }

            Future<void> linkTrainerToTeam(Map<String, dynamic> trainer) async {
              final trainerId = _Utils.asInt(trainer["id"]);
              if (trainerId <= 0) return;

              final selectedTeam = await _showTeamPicker(widget.teams);
              if (selectedTeam == null) return;

              final teamId = _getTeamId(selectedTeam);
              if (teamId <= 0) return;

              final data = await _Utils.postJson(_ApiEndpoints.linkTrainerToTeam, {
                "team_id": teamId,
                "trainer_id": trainerId,
                "profile": "extra",
              });

              if (data["status"] == "success" || data["success"] == true) {
                Get.back();
                await _loadTrainers();
                Get.snackbar("Успешно", "Тренер привязан к команде");
              } else {
                Get.snackbar(
                  "Ошибка",
                  _Utils.asString(data["message"]).isEmpty ? "Не удалось привязать" : _Utils.asString(data["message"]),
                );
              }
            }

            return Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const SizedBox(height: 12),
                  Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Добавить тренера",
                          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Colors.black),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          "Найти по email → выбрать команду → привязать",
                          style: TextStyle(color: AppColors.textSecondary, fontSize: 14),
                        ),
                        const SizedBox(height: 16),
                        Container(
                          decoration: BoxDecoration(
                            color: const Color(0xFFF3F5F8),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: TextField(
                            controller: emailController,
                            keyboardType: TextInputType.emailAddress,
                            decoration: InputDecoration(
                              hintText: "Введите email тренера...",
                              hintStyle: const TextStyle(color: AppColors.textTertiary),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                              suffixIcon: IconButton(
                                icon: const Icon(Icons.search, color: AppColors.primaryGreen),
                                onPressed: searchTrainer,
                              ),
                            ),
                            onSubmitted: (_) => searchTrainer(),
                          ),
                        ),
                        const SizedBox(height: 16),
                        if (isSearching)
                          const Center(
                            child: Padding(
                              padding: EdgeInsets.all(12),
                              child: CircularProgressIndicator(),
                            ),
                          )
                        else if (foundTrainers.isEmpty)
                          Padding(
                            padding: const EdgeInsets.only(top: 6),
                            child: Text("Введите email и нажмите поиск.", style: TextStyle(color: Colors.grey.shade600)),
                          )
                        else
                          ...foundTrainers.map((trainer) {
                            final name = _Utils.getTrainerName(trainer);
                            final email = _Utils.asString(trainer["email"]).trim();
                            return ListTile(
                              contentPadding: EdgeInsets.zero,
                              leading: CircleAvatar(
                                backgroundColor: AppColors.primaryGreen.withOpacity(0.1),
                                child: const Icon(Icons.person_outline, color: AppColors.primaryGreen),
                              ),
                              title: Text(name.isEmpty ? "Пользователь" : name),
                              subtitle: Text(email),
                              trailing: IconButton(
                                icon: const Icon(Icons.link, color: AppColors.primaryGreen),
                                onPressed: () => linkTrainerToTeam(trainer),
                              ),
                            );
                          }).toList(),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // =============================
  // UNLINK TRAINER (ВАЖНО: проверяем main ПО ВЫБРАННОЙ КОМАНДЕ)
  // =============================
  Future<void> _unlinkTrainer(Map<String, dynamic> trainer) async {
    final teams = (trainer["teams"] is List)
        ? (trainer["teams"] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
        : <Map<String, dynamic>>[];

    if (teams.isEmpty) {
      Get.snackbar("Команды", "У тренера нет привязок");
      return;
    }

    final selectedTeam = await _showTeamPicker(teams);
    if (selectedTeam == null) return;

    final trainerId = _Utils.asInt(trainer["id"]);
    final teamId = _Utils.asInt(selectedTeam["team_id"]);
    if (trainerId <= 0 || teamId <= 0) return;

    final linkProfile = _Utils.asString(selectedTeam["link_profile"]).trim().toLowerCase();
    final mainCoachId = _Utils.asInt(selectedTeam["main_coach_id"]);

    final isMainHere = (linkProfile == "main") || (mainCoachId > 0 && trainerId == mainCoachId);

    if (isMainHere) {
      Get.snackbar(
        "Нельзя отвязать",
        "Этот тренер главный в команде «${_Utils.asString(selectedTeam["team_name"])}». Назначьте другого главным и затем отвязывайте.",
      );
      return;
    }

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Отвязать?"),
        content: Text("Тренер будет отвязан от команды «${_Utils.asString(selectedTeam["team_name"])}»."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Отмена")),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: AppColors.error),
            child: const Text("Отвязать"),
          ),
        ],
      ),
    );

    if (confirmed != true) return;

    try {
      final res = await _Utils.postJson(_ApiEndpoints.unlinkTrainerFromTeam, {
        "team_id": teamId,
        "trainer_id": trainerId,
      });

      if (res["status"] == "success" || res["success"] == true) {
        await _loadTrainers();
        Get.snackbar("Успешно", "Тренер отвязан");
      } else {
        Get.snackbar(
          "Ошибка",
          _Utils.asString(res["message"]).isEmpty ? "Не удалось отвязать" : _Utils.asString(res["message"]),
        );
      }
    } catch (_) {
      Get.snackbar("Ошибка", "Не удалось отвязать");
    }
  }

  // =============================
  // SET MAIN COACH (profile=main)
  // =============================
  Future<void> _setMainCoach(Map<String, dynamic> trainer) async {
    final trainerId = _Utils.asInt(trainer["id"]);
    if (trainerId <= 0) return;

    final teams = (trainer["teams"] is List)
        ? (trainer["teams"] as List).whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList()
        : <Map<String, dynamic>>[];

    if (teams.isEmpty) {
      Get.snackbar("Команды", "Сначала привяжите тренера к команде");
      return;
    }

    final selectedTeam = await _showTeamPicker(teams);
    if (selectedTeam == null) return;

    final teamId = _Utils.asInt(selectedTeam["team_id"]);
    if (teamId <= 0) return;

    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Назначить главным?"),
        content: Text("Тренер станет главным для команды «${_Utils.asString(selectedTeam["team_name"])}»."),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text("Отмена")),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text("Назначить")),
        ],
      ),
    );

    if (ok != true) return;

    try {
      final res = await _Utils.postJson(_ApiEndpoints.linkTrainerToTeam, {
        "team_id": teamId,
        "trainer_id": trainerId,
        "profile": "main",
      });

      if (res["status"] == "success" || res["success"] == true) {
        await _loadTrainers();
        Get.snackbar("Успешно", "Главный тренер назначен");
      } else {
        Get.snackbar(
          "Ошибка",
          _Utils.asString(res["message"]).isEmpty ? "Не удалось назначить" : _Utils.asString(res["message"]),
        );
      }
    } catch (_) {
      Get.snackbar("Ошибка", "Не удалось назначить");
    }
  }

  // =============================
  // HELPERS
  // =============================
  int _getTeamId(dynamic team) {
    if (team is Map) {
      final map = Map<String, dynamic>.from(team as Map);
      final id = _Utils.asInt(map["id"]);
      if (id > 0) return id;
      return _Utils.asInt(map["team_id"]);
    }
    return 0;
  }

  String _getTeamName(dynamic team) {
    if (team is Map) {
      final map = Map<String, dynamic>.from(team as Map);
      final name1 = _Utils.asString(map["name"]).trim();
      if (name1.isNotEmpty) return name1;
      final name2 = _Utils.asString(map["team_name"]).trim();
      if (name2.isNotEmpty) return name2;
    }
    return "Команда";
  }

  String? _getTeamLogo(dynamic team) {
    if (team is Map) {
      final map = Map<String, dynamic>.from(team as Map);
      final logoUrl = _Utils.asString(map["logo_url"]).trim();
      if (logoUrl.isNotEmpty) return _Utils.normalizeImage(logoUrl);
      final logo = _Utils.asString(map["logo"]).trim();
      if (logo.isNotEmpty) return _Utils.normalizeImage(logo);
    }
    return null;
  }

  Future<Map<String, dynamic>?> _showTeamPicker(List<dynamic> teams) async {
    return await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => SafeArea(
        top: false,
        child: _TeamPickerSheet(
          teams: teams,
          teamIdExtractor: _getTeamId,
          teamNameExtractor: _getTeamName,
          teamLogoExtractor: _getTeamLogo,
        ),
      ),
    );
  }

  void _openChatWithTrainer({
    required int trainerId,
    required String trainerName,
    required String trainerEmail,
  }) {
    Get.snackbar(
      "Написать тренеру",
      "Подключи маршрут чата для: $trainerName",
      snackPosition: SnackPosition.BOTTOM,
    );
  }

  // =============================
  // UI
  // =============================
  @override
  Widget build(BuildContext context) {
    final visible = _listForSelectedGroup();
    final grouped = _groupedTrainers(visible);
    final selectedTabUi = _roleTabs.firstWhere(
  (e) => e.key == _selectedGroup,
  orElse: () => _roleTabs.first,
);

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
          color: AppColors.textPrimary,
          onPressed: () => Get.back(),
        ),
        title: const Text(
          "Тренерский штаб",
          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary, fontSize: 18),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.primaryGreen),
            onPressed: () async {
              await _loadClubLogo();
              await _loadTrainers();
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primaryGreen,
        foregroundColor: AppColors.white,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onPressed: _addTrainer,
        icon: const Icon(Icons.add, size: 22),
        label: const Text("Добавить тренера", style: TextStyle(fontWeight: FontWeight.w900, fontSize: 14)),
      ),
      body: widget.teams.isEmpty
          ? const _EmptyState(
              icon: Icons.group_off_rounded,
              title: "Нет команд",
              subtitle: "У клуба пока нет команд",
            )
          : _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage != null
                  ? _ErrorState(error: _errorMessage!, onRetry: _loadTrainers)
                  : RefreshIndicator(
                      color: AppColors.primaryGreen,
                      backgroundColor: AppColors.background,
                      onRefresh: () async {
                        await _loadClubLogo();
                        await _loadTrainers();
                      },
                      child: CustomScrollView(
                        slivers: [
                          SliverToBoxAdapter(
                            child: _HeaderSection(
                              clubName: widget.clubName,
                              clubLogoUrl: _clubLogoUrl,
                              trainersCount: _trainers.length,
                            ),
                          ),
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                              child: _SearchBar(
                                controller: _searchController,
                                onClear: () {
                                  _searchController.clear();
                                  FocusScope.of(context).unfocus();
                                },
                              ),
                            ),
                          ),

                          // ✅ Роли (баннеры/табы)
                          SliverToBoxAdapter(
                            child: Padding(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
                              child: _RoleTabsBar(
                                selected: _selectedGroup,
                                onSelect: (g) => setState(() => _selectedGroup = g),
                                countOf: _countForGroup,
                              ),
                            ),
                          ),

                          if (_filteredTrainers.isEmpty)
                            SliverToBoxAdapter(child: const _NoResultsState())
                          else if (visible.isEmpty)
                            SliverToBoxAdapter(child: const _NoResultsState())
                          else
                            SliverPadding(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                              sliver: SliverList(
                                delegate: SliverChildListDelegate(
                                  [
                                    // Если "Все" — показываем секциями.
                                    // Если выбрана конкретная роль — одна секция.
                                    if (_selectedGroup == StaffRoleGroup.all) ...[
  for (final tab in _roleTabs)
    if (tab.key != StaffRoleGroup.all && (grouped[tab.key]?.isNotEmpty ?? false)) ...[
      _RoleSectionBanner(
        title: tab.title,
        subtitle: tab.subtitle,
        icon: tab.icon,
        count: grouped[tab.key]!.length,
      ),
      const SizedBox(height: 10),
      ...grouped[tab.key]!.map((trainer) => _TrainerCard(
            trainer: trainer,
            onTap: () => _openTrainerProfile(trainer),
            onChat: () {
              _openChatWithTrainer(
                trainerId: _Utils.asInt(trainer["id"]),
                trainerName: _Utils.getTrainerName(trainer),
                trainerEmail: _Utils.asString(trainer["email"]),
              );
            },
            onUnlink: () => _unlinkTrainer(trainer),
            onSetMain: () => _setMainCoach(trainer),
          )),
      const SizedBox(height: 14),
    ],
  if (grouped.isEmpty) const _NoResultsState(),
] else ...[
  _RoleSectionBanner(
    title: selectedTabUi.title,
    subtitle: selectedTabUi.subtitle,
    icon: selectedTabUi.icon,
    count: visible.length,
  ),
  const SizedBox(height: 10),
  ...visible.map((trainer) => _TrainerCard(
        trainer: trainer,
        onTap: () => _openTrainerProfile(trainer),
        onChat: () {
          _openChatWithTrainer(
            trainerId: _Utils.asInt(trainer["id"]),
            trainerName: _Utils.getTrainerName(trainer),
            trainerEmail: _Utils.asString(trainer["email"]),
          );
        },
        onUnlink: () => _unlinkTrainer(trainer),
        onSetMain: () => _setMainCoach(trainer),
      )),
],
                                  ],
                                ),
                              ),
                            ),
                        ],
                      ),
                    ),
    );
  }

  Future<void> _openTrainerProfile(Map<String, dynamic> trainer) async {
    final result = await Get.to<bool>(
      () => ClubTrainerCardScreen(
        clubName: widget.clubName,
        trainer: trainer,
        teams: (trainer["teams"] is List) ? (trainer["teams"] as List).cast<Map<String, dynamic>>() : [],
        clubTeams: widget.teams,
        onWrite: () {
          _openChatWithTrainer(
            trainerId: _Utils.asInt(trainer["id"]),
            trainerName: _Utils.getTrainerName(trainer),
            trainerEmail: _Utils.asString(trainer["email"]),
          );
        },
      ),
    );

    if (result == true) {
      await _loadTrainers();
    }
  }
}

// =============================
// UI COMPONENTS
// =============================
class _HeaderSection extends StatelessWidget {
  final String clubName;
  final String? clubLogoUrl;
  final int trainersCount;

  const _HeaderSection({
    required this.clubName,
    required this.clubLogoUrl,
    required this.trainersCount,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 14),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [
              AppColors.primaryGreen.withOpacity(0.18),
              AppColors.primaryGreen.withOpacity(0.05),
              AppColors.white,
            ],
          ),
          boxShadow: [
            BoxShadow(
              color: AppColors.primaryGreen.withOpacity(0.12),
              blurRadius: 24,
              offset: const Offset(0, 10),
            ),
          ],
          border: Border.all(color: AppColors.primaryGreen.withOpacity(0.15)),
        ),
        child: Row(
          children: [
            _CircleNetworkImage(
              imageUrl: clubLogoUrl,
              size: 64,
              borderColor: AppColors.primaryGreen.withOpacity(0.22),
              borderWidth: 2,
              glow: AppColors.primaryGreen.withOpacity(0.25),
              fallback: Icon(Icons.sports_soccer, color: AppColors.primaryGreen, size: 30),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    clubName,
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w900,
                      color: AppColors.textPrimary,
                      height: 1.1,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Тренерско-преподавательский состав",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                      color: AppColors.primaryGreen.withOpacity(0.9),
                      height: 1.15,
                      letterSpacing: 0.2,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    "Всего сотрудников: $trainersCount",
                    style: TextStyle(
                      color: AppColors.textSecondary.withOpacity(0.9),
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.primaryGreen.withOpacity(0.12),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                "$trainersCount",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primaryGreen,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final VoidCallback onClear;

  const _SearchBar({
    required this.controller,
    required this.onClear,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 52,
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Center(
        child: TextField(
          controller: controller,
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            hintText: "Поиск тренеров или команды...",
            hintStyle: TextStyle(color: AppColors.textTertiary.withOpacity(0.7)),
            border: InputBorder.none,
            prefixIcon: const Icon(Icons.search_rounded, color: AppColors.textTertiary),
            suffixIcon: controller.text.isNotEmpty ? IconButton(icon: const Icon(Icons.close_rounded), onPressed: onClear) : null,
            contentPadding: const EdgeInsets.symmetric(horizontal: 16),
          ),
        ),
      ),
    );
  }
}

// ✅ Баннер-табы ролей
class _RoleTabsBar extends StatelessWidget {
  final StaffRoleGroup selected;
  final ValueChanged<StaffRoleGroup> onSelect;
  final int Function(StaffRoleGroup) countOf;

  const _RoleTabsBar({
    required this.selected,
    required this.onSelect,
    required this.countOf,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 86,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: _roleTabs.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (context, i) {
          final tab = _roleTabs[i];
          final isActive = tab.key == selected;
          final count = countOf(tab.key);

          return InkWell(
            onTap: () => onSelect(tab.key),
            borderRadius: BorderRadius.circular(18),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 170,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                color: isActive ? AppColors.primaryGreen.withOpacity(0.14) : AppColors.card,
                border: Border.all(
                  color: isActive ? AppColors.primaryGreen.withOpacity(0.35) : Colors.grey.shade200,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(isActive ? 0.05 : 0.03),
                    blurRadius: 12,
                    offset: const Offset(0, 6),
                  ),
                ],
              ),
              child: Row(
                children: [
                  Container(
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreen.withOpacity(isActive ? 0.16 : 0.10),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Icon(tab.icon, color: AppColors.primaryGreen, size: 22),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          tab.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontWeight: FontWeight.w900,
                            color: AppColors.textPrimary,
                            fontSize: 14,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          tab.subtitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            color: AppColors.textSecondary.withOpacity(0.85),
                            fontWeight: FontWeight.w800,
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                    decoration: BoxDecoration(
                      color: AppColors.primaryGreen.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      "$count",
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AppColors.primaryGreen,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ✅ Секционный баннер списка
class _RoleSectionBanner extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final int count;

  const _RoleSectionBanner({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppColors.primaryGreen.withOpacity(0.18),
            AppColors.primaryGreen.withOpacity(0.06),
            AppColors.card,
          ],
        ),
        border: Border.all(color: AppColors.primaryGreen.withOpacity(0.16)),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: AppColors.primaryGreen.withOpacity(0.14),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: AppColors.primaryGreen, size: 22),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                    color: AppColors.textPrimary,
                    height: 1.1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: AppColors.textSecondary.withOpacity(0.85),
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: AppColors.primaryGreen.withOpacity(0.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              "$count",
              style: const TextStyle(
                fontWeight: FontWeight.w900,
                color: AppColors.primaryGreen,
                fontSize: 14,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerCard extends StatelessWidget {
  final Map<String, dynamic> trainer;
  final VoidCallback onTap;
  final VoidCallback onChat;
  final VoidCallback onUnlink;
  final VoidCallback onSetMain;

  const _TrainerCard({
    required this.trainer,
    required this.onTap,
    required this.onChat,
    required this.onUnlink,
    required this.onSetMain,
  });

  @override
  Widget build(BuildContext context) {
    final name = _Utils.getTrainerName(trainer);
    final email = _Utils.asString(trainer["email"]).trim();
    final isMainAny = _Utils.asBool(trainer["is_main_any"]);

    final rawPhoto = _Utils.asString(trainer["photo_url"]).trim().isNotEmpty
        ? _Utils.asString(trainer["photo_url"])
        : _Utils.asString(trainer["photo"]);
    final photo = _Utils.normalizeImage(rawPhoto);

    final teams = (trainer["teams"] is List) ? (trainer["teams"] as List).cast<Map<String, dynamic>>() : <Map<String, dynamic>>[];

    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.card,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.03),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Row(
            children: [
              _CircleNetworkImage(
                imageUrl: photo,
                size: 56,
                borderColor: AppColors.primaryGreen.withOpacity(0.2),
                borderWidth: 2,
                fallback: Container(
                  color: AppColors.primaryGreen.withOpacity(0.1),
                  child: Icon(Icons.person_outline_rounded, color: AppColors.primaryGreen, size: 28),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Expanded(
                                child: Text(
                                  name,
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w900,
                                    color: AppColors.textPrimary,
                                  ),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              if (isMainAny) ...[
                                const SizedBox(width: 8),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: AppColors.primaryGreen.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(999),
                                    border: Border.all(color: AppColors.primaryGreen.withOpacity(0.25)),
                                  ),
                                  child: const Text(
                                    "ГЛАВНЫЙ",
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.primaryGreen,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        InkWell(
                          onTap: onChat,
                          borderRadius: BorderRadius.circular(12),
                          child: Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: AppColors.primaryGreen.withOpacity(0.10),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Icon(Icons.chat_bubble_outline_rounded, color: AppColors.primaryGreen, size: 20),
                          ),
                        ),
                        const SizedBox(width: 6),
                        PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'main') onSetMain();
                            if (value == 'unlink') onUnlink();
                          },
                          itemBuilder: (context) => const [
                            PopupMenuItem(
                              value: 'main',
                              child: Row(
                                children: [
                                  Icon(Icons.star_rounded, size: 18, color: AppColors.primaryGreen),
                                  SizedBox(width: 8),
                                  Text("Назначить главным"),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'unlink',
                              child: Row(
                                children: [
                                  Icon(Icons.link_off, size: 18, color: AppColors.error),
                                  SizedBox(width: 8),
                                  Text("Отвязать от команды"),
                                ],
                              ),
                            ),
                          ],
                          child: Icon(Icons.more_vert_rounded, color: AppColors.textSecondary.withOpacity(0.6)),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      email,
                      style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 10),
                    if (teams.isEmpty)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                        decoration: BoxDecoration(
                          color: Colors.grey.withOpacity(0.10),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Text(
                          "НЕТ ПРИВЯЗКИ К КОМАНДЕ",
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w900,
                            color: AppColors.textSecondary,
                            letterSpacing: 0.5,
                          ),
                        ),
                      )
                    else
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final team in teams.take(2))
                            _TeamChip(
                              title: _Utils.asString(team["team_name"]).trim().isEmpty
                                  ? "Команда"
                                  : _Utils.asString(team["team_name"]).trim(),
                            ),
                          if (teams.length > 2)
                            _TeamChip(
                              title: "+${teams.length - 2}",
                              compact: true,
                            ),
                        ],
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TeamChip extends StatelessWidget {
  final String title;
  final bool compact;

  const _TeamChip({
    required this.title,
    this.compact = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: compact ? 10 : 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.primaryGreen.withOpacity(0.10),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        title,
        style: TextStyle(
          fontSize: compact ? 11 : 12,
          fontWeight: FontWeight.w900,
          color: AppColors.primaryGreen,
        ),
      ),
    );
  }
}

class _CircleNetworkImage extends StatelessWidget {
  final String? imageUrl;
  final double size;
  final double borderWidth;
  final Color borderColor;
  final Color? glow;
  final Widget fallback;

  const _CircleNetworkImage({
    required this.imageUrl,
    required this.size,
    required this.borderWidth,
    required this.borderColor,
    required this.fallback,
    this.glow,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.white,
        boxShadow: glow != null
            ? [
                BoxShadow(
                  color: glow!,
                  blurRadius: 22,
                  offset: const Offset(0, 10),
                ),
              ]
            : null,
        border: Border.all(color: borderColor, width: borderWidth),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size / 2),
        child: (imageUrl == null || imageUrl!.isEmpty)
            ? fallback
            : CachedNetworkImage(
                imageUrl: imageUrl!,
                fit: BoxFit.cover,
                fadeInDuration: const Duration(milliseconds: 120),
                placeholder: (context, _) => const Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
                errorWidget: (context, _, __) => fallback,
              ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text(
            title,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          Text(subtitle, style: const TextStyle(color: AppColors.textSecondary)),
        ],
      ),
    );
  }
}

class _ErrorState extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;

  const _ErrorState({
    required this.error,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.error_outline_rounded, size: 64, color: Colors.red.shade400),
          const SizedBox(height: 16),
          Text(error, textAlign: TextAlign.center),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: onRetry,
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryGreen,
              foregroundColor: AppColors.white,
            ),
            child: const Text("Повторить"),
          ),
        ],
      ),
    );
  }
}

class _NoResultsState extends StatelessWidget {
  const _NoResultsState();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(40),
      child: Column(
        children: [
          Icon(Icons.group_add_rounded, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 20),
          const Text(
            "Сотрудники не найдены",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w800,
              color: AppColors.textPrimary,
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            "Попробуйте другой запрос\nили добавьте сотрудника",
            textAlign: TextAlign.center,
            style: TextStyle(color: AppColors.textSecondary),
          ),
        ],
      ),
    );
  }
}

// =============================
// ЭКРАН КАРТОЧКИ ТРЕНЕРА
// =============================
class ClubTrainerCardScreen extends StatefulWidget {
  final String clubName;
  final Map<String, dynamic> trainer;
  final List<Map<String, dynamic>> teams; // тут teams уже с link_profile/main_coach_id
  final List<dynamic> clubTeams;
  final VoidCallback onWrite;

  const ClubTrainerCardScreen({
    super.key,
    required this.clubName,
    required this.trainer,
    required this.teams,
    required this.clubTeams,
    required this.onWrite,
  });

  @override
  State<ClubTrainerCardScreen> createState() => _ClubTrainerCardScreenState();
}

class _ClubTrainerCardScreenState extends State<ClubTrainerCardScreen> {
  bool _isLoading = true;
  Map<String, dynamic> _profile = {};

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final trainerId = _Utils.asInt(widget.trainer["id"]);
    if (trainerId <= 0) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _profile = {};
        });
      }
      return;
    }

    Map<String, dynamic> pickProfile(Map<String, dynamic> res) {
      Map<String, dynamic>? m(dynamic v) => (v is Map) ? Map<String, dynamic>.from(v as Map) : null;

      final p1 = m(res["profile"]);
      if (p1 != null) return p1;

      final p2 = m(res["trainer"]);
      if (p2 != null) return p2;

      final p3 = m(res["user"]);
      if (p3 != null) return p3;

      final p4 = m(res["data"]);
      if (p4 != null) return p4;

      return res;
    }

    try {
      final response = await _Utils.postJson(_ApiEndpoints.getTrainerProfile, {"trainer_id": trainerId});
      // ignore: avoid_print
      print("GET TRAINER PROFILE: $response");

      final ok = response["success"] == true || response["status"] == "success";
      final prof = ok ? pickProfile(response) : <String, dynamic>{};

      if (mounted) {
        setState(() {
          _profile = prof;
          _isLoading = false;
        });
      } else {
        _profile = prof;
      }
    } catch (e) {
      // ignore: avoid_print
      print("GET TRAINER PROFILE ERROR: $e");
      if (mounted) {
        setState(() {
          _profile = {};
          _isLoading = false;
        });
      }
    }
  }

  void _openTeam(Map<String, dynamic> team) {
    final teamId = _Utils.asInt(team["team_id"]);
    final teamName = _Utils.asString(team["team_name"]).trim();
    if (teamId <= 0) return;
    Get.to(() => MyTeamScreen(teamId: teamId, teamName: teamName));
  }

  Future<void> _linkToAnotherTeam() async {
    final trainerId = _Utils.asInt(widget.trainer["id"]);
    if (trainerId <= 0) return;

    if (widget.clubTeams.isEmpty) {
      Get.snackbar("Команды", "У клуба нет команд");
      return;
    }

    final selectedTeam = await showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      backgroundColor: Colors.white,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (context) => SafeArea(
        top: false,
        child: _TeamPickerSheet(
          teams: widget.clubTeams,
          teamIdExtractor: (team) => _Utils.asInt(team is Map ? team["id"] : 0),
          teamNameExtractor: (team) => _Utils.asString(team is Map ? team["name"] : "Команда"),
          teamLogoExtractor: (team) => _Utils.normalizeImage(team is Map ? _Utils.asString(team["logo"]) : null),
        ),
      ),
    );

    if (selectedTeam == null) return;

    final teamId = _Utils.asInt(selectedTeam["id"]);
    if (teamId <= 0) return;

    final data = await _Utils.postJson(_ApiEndpoints.linkTrainerToTeam, {
      "team_id": teamId,
      "trainer_id": trainerId,
      "profile": "extra",
    });

    if (data["status"] == "success" || data["success"] == true) {
      Get.snackbar("Успешно", "Тренер привязан к команде");
      Get.back(result: true);
    } else {
      Get.snackbar(
        "Ошибка",
        _Utils.asString(data["message"]).isEmpty ? "Не удалось привязать" : _Utils.asString(data["message"]),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final name = _Utils.getTrainerName(widget.trainer);
    final email = _Utils.asString(widget.trainer["email"]).trim();

    final rawPhotoFromProfile =
        _Utils.asString(_profile["photo_url"]).trim().isNotEmpty ? _Utils.asString(_profile["photo_url"]) : _Utils.asString(_profile["photo"]);

    final rawPhotoFromTrainer =
        _Utils.asString(widget.trainer["photo_url"]).trim().isNotEmpty ? _Utils.asString(widget.trainer["photo_url"]) : _Utils.asString(widget.trainer["photo"]);

    final photo = _Utils.normalizeImage(rawPhotoFromProfile.trim().isNotEmpty ? rawPhotoFromProfile : rawPhotoFromTrainer);

    final position = _Utils.asString(_profile["position"]).trim();
    final bio = _Utils.asString(_profile["bio"]).trim();
    final birthday = _Utils.asString(_profile["birthday"]).trim();
    final experience = _Utils.asString(_profile["experience"]).trim();

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
          color: AppColors.textPrimary,
          onPressed: () => Get.back(),
        ),
        title: const Text(
          "Визитка тренера",
          style: TextStyle(fontWeight: FontWeight.w900, color: AppColors.textPrimary, fontSize: 18),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined, size: 22),
            color: AppColors.textPrimary,
            onPressed: () async {
              final saved = await Get.to<bool>(() => EditTrainerProfileScreen(
                    trainerId: _Utils.asInt(widget.trainer["id"]),
                    trainerName: name,
                  ));
              if (saved == true) {
                await _loadProfile();
                Get.back(result: true);
              }
            },
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : CustomScrollView(
              slivers: [
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: _TrainerProfileCard(
                      name: name,
                      email: email,
                      photo: photo,
                      position: position,
                      clubName: widget.clubName,
                      teams: widget.teams,
                      onWrite: widget.onWrite,
                      onLinkTeam: _linkToAnotherTeam,
                      onTeamTap: _openTeam,
                    ),
                  ),
                ),
                if (birthday.isNotEmpty || experience.isNotEmpty || bio.isNotEmpty)
                  SliverPadding(
                    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                    sliver: SliverList(
                      delegate: SliverChildListDelegate([
                        if (birthday.isNotEmpty) _InfoCard(icon: Icons.cake_rounded, title: "Дата рождения", content: birthday),
                        if (birthday.isNotEmpty) const SizedBox(height: 12),
                        if (experience.isNotEmpty) _InfoCard(icon: Icons.work_history_rounded, title: "Опыт / карьера", content: experience),
                        if (experience.isNotEmpty) const SizedBox(height: 12),
                        if (bio.isNotEmpty) _InfoCard(icon: Icons.description_rounded, title: "О тренере", content: bio),
                      ]),
                    ),
                  ),
              ],
            ),
    );
  }
}

class _TrainerProfileCard extends StatelessWidget {
  final String name;
  final String email;
  final String? photo;
  final String position;
  final String clubName;
  final List<Map<String, dynamic>> teams;
  final VoidCallback onWrite;
  final VoidCallback onLinkTeam;
  final Function(Map<String, dynamic>) onTeamTap;

  const _TrainerProfileCard({
    required this.name,
    required this.email,
    required this.photo,
    required this.position,
    required this.clubName,
    required this.teams,
    required this.onWrite,
    required this.onLinkTeam,
    required this.onTeamTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          _CircleNetworkImage(
            imageUrl: photo,
            size: 100,
            borderColor: AppColors.primaryGreen.withOpacity(0.25),
            borderWidth: 2,
            fallback: Container(
              color: AppColors.primaryGreen.withOpacity(0.1),
              child: Icon(Icons.person_outline, color: AppColors.primaryGreen, size: 50),
            ),
          ),
          const SizedBox(height: 20),
          Text(
            name,
            style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: AppColors.textPrimary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          Text(email, style: const TextStyle(fontSize: 15, color: AppColors.textSecondary)),
          const SizedBox(height: 14),
          if (position.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.primaryGreen.withOpacity(0.10),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                position,
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w900, color: AppColors.primaryGreen),
                textAlign: TextAlign.center,
              ),
            ),
          const SizedBox(height: 18),
          _InfoRow(icon: Icons.shield_outlined, label: "Клуб", value: clubName),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _CircleAction(icon: Icons.chat_bubble_outline_rounded, title: "Чат", onTap: onWrite),
              const SizedBox(width: 22),
              _CircleAction(icon: Icons.link_rounded, title: "Привязать", onTap: onLinkTeam),
            ],
          ),
          const SizedBox(height: 18),
          const Align(
            alignment: Alignment.centerLeft,
            child: Text(
              "Команды тренера",
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w900,
                color: AppColors.textSecondary,
                letterSpacing: 0.5,
              ),
            ),
          ),
          const SizedBox(height: 10),
          if (teams.isEmpty)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Text(
                "Тренер пока не привязан к командам",
                style: TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.w700),
              ),
            )
          else
            Column(
              children: teams.map((team) {
                final teamName = _Utils.asString(team["team_name"]).trim();
                final logoUrl = _Utils.normalizeImage(_Utils.asString(team["team_logo"]));
                final lp = _Utils.asString(team["link_profile"]).trim().toLowerCase();
                final isMainHere = lp == "main";

                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: InkWell(
                    onTap: () => onTeamTap(team),
                    borderRadius: BorderRadius.circular(16),
                    child: Container(
                      padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: AppColors.primaryGreen.withOpacity(0.06),
                        border: Border.all(color: AppColors.primaryGreen.withOpacity(0.15)),
                      ),
                      child: Row(
                        children: [
                          _CircleNetworkImage(
                            imageUrl: logoUrl,
                            size: 44,
                            borderColor: AppColors.primaryGreen.withOpacity(0.20),
                            borderWidth: 1,
                            fallback: Icon(Icons.groups_outlined, color: AppColors.primaryGreen),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Row(
                              children: [
                                Expanded(
                                  child: Text(
                                    teamName.isEmpty ? "Команда" : teamName,
                                    style: const TextStyle(
                                      fontSize: 15,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.textPrimary,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                if (isMainHere) ...[
                                  const SizedBox(width: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                    decoration: BoxDecoration(
                                      color: AppColors.primaryGreen.withOpacity(0.12),
                                      borderRadius: BorderRadius.circular(999),
                                      border: Border.all(color: AppColors.primaryGreen.withOpacity(0.25)),
                                    ),
                                    child: const Text(
                                      "ГЛАВНЫЙ",
                                      style: TextStyle(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w900,
                                        color: AppColors.primaryGreen,
                                        letterSpacing: 0.6,
                                      ),
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                          const SizedBox(width: 10),
                          Icon(Icons.arrow_forward_ios_rounded, size: 18, color: AppColors.primaryGreen),
                        ],
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }
}

class _CircleAction extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _CircleAction({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.primaryGreen.withOpacity(0.12),
              border: Border.all(color: AppColors.primaryGreen.withOpacity(0.25)),
              boxShadow: [
                BoxShadow(
                  color: AppColors.primaryGreen.withOpacity(0.12),
                  blurRadius: 18,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: Icon(icon, color: AppColors.primaryGreen, size: 26),
          ),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.primaryGreen.withOpacity(0.1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 20, color: AppColors.primaryGreen),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w800)),
              const SizedBox(height: 2),
              Text(value, style: const TextStyle(fontSize: 16, color: AppColors.textPrimary, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      ],
    );
  }
}

class _InfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String content;

  const _InfoCard({
    required this.icon,
    required this.title,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: AppColors.primaryGreen),
              const SizedBox(width: 8),
              Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
            ],
          ),
          const SizedBox(height: 12),
          Text(content, style: const TextStyle(fontSize: 15, color: AppColors.textSecondary, height: 1.5)),
        ],
      ),
    );
  }
}

// =============================
// ВЫБОР КОМАНДЫ (БОТТОМ ШИТ)
// =============================
class _TeamPickerSheet extends StatelessWidget {
  final List<dynamic> teams;
  final int Function(dynamic) teamIdExtractor;
  final String Function(dynamic) teamNameExtractor;
  final String? Function(dynamic) teamLogoExtractor;

  const _TeamPickerSheet({
    required this.teams,
    required this.teamIdExtractor,
    required this.teamNameExtractor,
    required this.teamLogoExtractor,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(height: 12),
        Container(
          width: 36,
          height: 4,
          decoration: BoxDecoration(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(2)),
        ),
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text("Выбор команды",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: AppColors.textPrimary)),
              const SizedBox(height: 8),
              const Text("Выберите команду", style: TextStyle(color: AppColors.textTertiary, fontSize: 14)),
              const SizedBox(height: 20),
            ],
          ),
        ),
        Flexible(
          child: ListView.separated(
            shrinkWrap: true,
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 30),
            itemCount: teams.length,
            separatorBuilder: (_, __) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final team = teams[index];
              final id = teamIdExtractor(team);
              final name = teamNameExtractor(team);
              final logo = teamLogoExtractor(team);

              // Для отображения бейджа "ГЛАВНЫЙ" прямо в выборе (если в team есть link_profile)
              final map = (team is Map) ? Map<String, dynamic>.from(team as Map) : <String, dynamic>{};
              final lp = _Utils.asString(map["link_profile"]).trim().toLowerCase();
              final isMainHere = lp == "main";

              return Material(
                color: Colors.transparent,
                child: InkWell(
                  onTap: () {
                    final outMap = <String, dynamic>{
                      ...map,
                      "team_id": map["team_id"] ?? map["id"] ?? id,
                      "team_name": map["team_name"] ?? map["name"] ?? name,
                      "team_logo": map["team_logo"] ?? map["logo_url"] ?? map["logo"] ?? logo,
                      "link_profile": map["link_profile"],
                      "main_coach_id": map["main_coach_id"],
                    };
                    Navigator.pop(context, outMap);
                  },
                  borderRadius: BorderRadius.circular(16),
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppColors.card,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.grey.shade200, width: 1),
                    ),
                    child: Row(
                      children: [
                        _CircleNetworkImage(
                          imageUrl: logo,
                          size: 52,
                          borderColor: AppColors.primaryGreen.withOpacity(0.2),
                          borderWidth: 1,
                          fallback: Icon(Icons.emoji_events_outlined, color: AppColors.primaryGreen),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                name,
                                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: AppColors.textPrimary),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              if (isMainHere) ...[
                                const SizedBox(height: 6),
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                                  decoration: BoxDecoration(
                                    color: AppColors.primaryGreen.withOpacity(0.12),
                                    borderRadius: BorderRadius.circular(999),
                                    border: Border.all(color: AppColors.primaryGreen.withOpacity(0.25)),
                                  ),
                                  child: const Text(
                                    "ГЛАВНЫЙ",
                                    style: TextStyle(
                                      fontSize: 10,
                                      fontWeight: FontWeight.w900,
                                      color: AppColors.primaryGreen,
                                      letterSpacing: 0.6,
                                    ),
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                        const SizedBox(width: 10),
                        Icon(Icons.arrow_forward_ios_rounded, size: 18, color: AppColors.textTertiary.withOpacity(0.8)),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}
