// lib/presentation/team_roster/team_roster_screen.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:cached_network_image/cached_network_image.dart';

import 'package:sportoteka/routes/app_routes.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/core/constants/app_colors.dart';

// ✅ ЧАТ
import 'package:sportoteka/presentation/chat_screen/chat_room_screen.dart';

// ✅ Печать / PDF
import 'package:printing/printing.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/pdf.dart';

class TeamRosterScreen extends StatefulWidget {
  final int teamId;
  final String teamName;

  const TeamRosterScreen({
    super.key,
    required this.teamId,
    required this.teamName,
  });

  @override
  State<TeamRosterScreen> createState() => _TeamRosterScreenState();
}

/// ✅ Новый порядок вкладок:
/// Игроки → Тренерский штаб → Родители → Руководство
enum _RosterTab {
  players,
  staff,
  parents,
  managers,
}

class _TeamRosterScreenState extends State<TeamRosterScreen>
    with SingleTickerProviderStateMixin {
  // =============================
  // ✅ API
  // =============================
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String deletePlayerUrl = "$apiBase/delete_player.php";
  static const String getUserUrl = "$apiBase/get_user.php";
  static const String getPlayersUrl = "$apiBase/get_players.php";
  static const String getManagersUrl = "$apiBase/get_club_managers.php";
  static const String getParentsUrl = "$apiBase/get_team_parents.php";

  // ✅ тренерский штаб по команде
  static const String getTeamTrainersUrl = "$apiBase/get_team_trainers.php";

  // ✅ профиль тренера (визитка)
  static const String getTrainerProfileUrl = "$apiBase/get_trainer_profile.php";

  // =============================
  // ✅ STATE
  // =============================
  late final TabController _tab;

  bool loading = true;
  String? error;

  int userId = 0;
  int clubId = 0;

  /// ✅ роль текущего пользователя (coach/player/parent/manager/admin...)
  String role = "";

  /// ✅ запрет редактирования состава для player
  bool get canEditRoster => role != "player";

  List<Map<String, dynamic>> players = [];
  List<Map<String, dynamic>> staff = [];
  List<Map<String, dynamic>> parents = [];
  List<Map<String, dynamic>> managers = [];

  Color get _bg => const Color(0xFFF3F5F8);

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: _RosterTab.values.length, vsync: this);

    final args = Get.arguments;
    if (args is Map) {
      clubId = _safeInt(args["clubId"]);
    }

    _initAndLoad();
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  Future<void> _initAndLoad() async {
    final uid = await PrefUtils.getUserId();
    userId = uid ?? 0;

    // ✅ роль берем с сервера через get_user.php, чтобы не зависеть от PrefUtils.getRole()
    if (userId > 0) {
      role = await _fetchRoleByUser(userId);
    } else {
      role = "";
    }

    if (clubId <= 0 && userId > 0) {
      clubId = await _fetchClubIdByUser(userId);
    }

    await _loadAll();
  }

  Future<void> _loadAll() async {
    if (!mounted) return;
    setState(() {
      loading = true;
      error = null;
    });

    try {
      await Future.wait([
        _fetchPlayers(),
        _fetchStaffByTeam(), // ✅ штаб по команде
        _fetchParents(),
        _fetchManagers(),
      ]);

      players = _sortByFio(players);
      staff = _sortByFio(staff);
      parents = _sortByFio(parents);
      managers = _sortByFio(managers);
    } catch (e) {
      error = "Ошибка загрузки: $e";
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  // =============================
  // ✅ get role via get_user.php
  // =============================
  Future<String> _fetchRoleByUser(int uid) async {
    try {
      final uri = Uri.parse("$getUserUrl?user_id=$uid");
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);

      if (data is! Map) return "";
      final ok = data["success"] == true || data["status"] == "success";
      if (!ok) return "";

      final user = data["user"];
      if (user is Map) {
        final r = (user["role"] ?? "").toString().trim();
        return r;
      }
      return "";
    } catch (_) {
      return "";
    }
  }

  // =============================
  // ✅ get clubId via get_user.php
  // =============================
  Future<int> _fetchClubIdByUser(int uid) async {
    try {
      final uri = Uri.parse("$getUserUrl?user_id=$uid");
      final resp = await http.get(uri);
      final data = jsonDecode(resp.body);

      if (data is! Map) return 0;
      final ok = data["success"] == true || data["status"] == "success";
      if (!ok) return 0;

      final user = data["user"];
      final cidFromUser = _safeInt(user is Map ? user["club_id"] : null);
      if (cidFromUser > 0) return cidFromUser;

      final team = data["team"];
      final cidFromTeam = _safeInt(team is Map ? team["club_id"] : null);
      if (cidFromTeam > 0) return cidFromTeam;

      final teams = data["teams"];
      if (teams is List && teams.isNotEmpty) {
        final first = teams.first;
        final cidFromTeams = _safeInt(first is Map ? first["club_id"] : null);
        if (cidFromTeams > 0) return cidFromTeams;
      }

      return 0;
    } catch (_) {
      return 0;
    }
  }

  // =============================
  // ✅ API helper: POST list
  // =============================
  Future<List<Map<String, dynamic>>> _postList(
    String url,
    Map<String, dynamic> body,
    String key,
  ) async {
    final resp = await http.post(
      Uri.parse(url),
      headers: {"Content-Type": "application/json; charset=utf-8"},
      body: jsonEncode(body),
    );

    final data = jsonDecode(resp.body);

    final ok = (data is Map) &&
        (data["status"] == "success" || data["success"] == true);

    if (!ok) {
      final msg = (data is Map ? (data["message"] ?? data["error"]) : null) ??
          "Не удалось загрузить данные";
      throw msg;
    }

    if (data is Map) {
      return List<Map<String, dynamic>>.from(data[key] ?? []);
    }
    return [];
  }

  // =============================
  // ✅ fetchers
  // =============================
  Future<void> _fetchPlayers() async {
    try {
      players =
          await _postList(getPlayersUrl, {"team_id": widget.teamId}, "players");
    } catch (_) {
      players = [];
    }
  }

  Future<bool> _confirmDeletePlayer(String fio) async {
    return (await showDialog<bool>(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text("Удалить игрока?"),
            content: Text(
              fio.isEmpty
                  ? "Удалить игрока из команды?"
                  : "Удалить \"$fio\" из команды?",
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context, false),
                child: const Text("Отмена"),
              ),
              FilledButton(
                style: FilledButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                ),
                onPressed: () => Navigator.pop(context, true),
                child: const Text("Удалить"),
              ),
            ],
          ),
        )) ??
        false;
  }

  Future<void> _deletePlayer(Map<String, dynamic> p) async {
    // ✅ ЖЕСТКИЙ GUARD: player не может менять состав
    if (!canEditRoster) {
      Get.snackbar(
        "Доступ ограничен",
        "Игрок не может изменять состав команды",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
      return;
    }

    int _pickPlayerId(Map<String, dynamic> m) {
      int asInt(dynamic v) =>
          v is int ? v : int.tryParse((v ?? "").toString()) ?? 0;

      final candidates = [
        m["id"], // id игрока в players
        m["player_id"], // если бек так отдаёт
        m["playerId"],
        m["uid"],
      ];

      for (final c in candidates) {
        final v = asInt(c);
        if (v > 0) return v;
      }
      return 0;
    }

    final playerId = _pickPlayerId(p);
    final fio = _fio(p);

    if (playerId <= 0) {
      Get.snackbar(
        "Удаление",
        "Не найден id игрока. Ключи: ${p.keys.toList()}",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
      return;
    }

    final okConfirm = await _confirmDeletePlayer(fio);
    if (!okConfirm) return;

    try {
      // ✅ оптимистично убираем из списка
      if (mounted) {
        setState(() {
          players.removeWhere((x) => _pickPlayerId(x) == playerId);
        });
      }

      final resp = await http.post(
        Uri.parse(deletePlayerUrl),
        headers: const {"Content-Type": "application/json; charset=utf-8"},
        body: jsonEncode({
          "player_id": playerId,
          "team_id": widget.teamId,
        }),
      );

      final data = jsonDecode(resp.body);
      final success = (data is Map) &&
          (data["success"] == true || data["status"] == "success");

      if (!success) {
        final msg =
            (data is Map ? (data["message"] ?? data["error"]) : null) ??
                "Не удалось удалить";
        await _fetchPlayers();
        if (mounted) setState(() {});
        Get.snackbar("Удаление", msg, snackPosition: SnackPosition.BOTTOM);
        return;
      }

      Get.snackbar("Удаление", "Игрок удалён",
          snackPosition: SnackPosition.BOTTOM);
      await _fetchPlayers();
      if (mounted) setState(() {});
    } catch (e) {
      await _fetchPlayers();
      if (mounted) setState(() {});
      Get.snackbar("Удаление", "Ошибка: $e",
          snackPosition: SnackPosition.BOTTOM);
    }
  }

  Future<void> _fetchParents() async {
    try {
      parents =
          await _postList(getParentsUrl, {"team_id": widget.teamId}, "parents");
    } catch (_) {
      parents = [];
    }
  }

  Future<void> _fetchManagers() async {
    if (clubId <= 0) {
      managers = [];
      return;
    }
    try {
      managers = await _postList(getManagersUrl, {"club_id": clubId}, "managers");
    } catch (_) {
      managers = [];
    }
  }

  /// ✅ Тренерский штаб по команде
  /// Берем список из get_team_trainers.php.
  /// Если в нём нет должности — добираем из get_trainer_profile.php.
  Future<void> _fetchStaffByTeam() async {
    try {
      staff = await _postList(
        getTeamTrainersUrl,
        {"team_id": widget.teamId},
        "trainers",
      );

      // ✅ гарантируем "position" (должность) через get_trainer_profile.php
      staff = await _enrichStaffWithProfiles(staff);
    } catch (_) {
      staff = [];
    }
  }

  /// Обогащаем тренеров данными визитки (position/experience/bio/birthday).
  /// Если position уже есть — не дергаем лишний раз.
  Future<List<Map<String, dynamic>>> _enrichStaffWithProfiles(
    List<Map<String, dynamic>> list,
  ) async {
    if (list.isEmpty) return list;

    Future<Map<String, dynamic>?> loadProfile(int trainerId) async {
      try {
        final resp = await http.post(
          Uri.parse(getTrainerProfileUrl),
          headers: const {"Content-Type": "application/json; charset=utf-8"},
          body: jsonEncode({"trainer_id": trainerId}),
        );
        final data = jsonDecode(resp.body);

        // ✅ поддерживаем оба формата API:
        // - { status: "success", trainer: {...} }
        // - { success: true, profile: {...} }
        if (data is Map) {
          final ok = (data["status"] == "success" || data["success"] == true);
          final obj = data["trainer"] ?? data["profile"];
          if (ok && obj is Map) {
            return Map<String, dynamic>.from(obj);
          }
        }
      } catch (_) {}
      return null;
    }

    const int chunk = 6;
    final out = <Map<String, dynamic>>[];

    for (int i = 0; i < list.length; i += chunk) {
      final part = list.skip(i).take(chunk).toList();

      final futures = part.map((t) async {
        final m = Map<String, dynamic>.from(t);

        final tid = _pickTrainerId(m);
        final hasPosition =
            _s(m["position"]).isNotEmpty || _s(m["role_title"]).isNotEmpty;

        if (tid > 0 && !hasPosition) {
          final prof = await loadProfile(tid);
          if (prof != null) {
            if (_s(m["position"]).isEmpty) m["position"] = prof["position"];
            if (_s(m["birthday"]).isEmpty) m["birthday"] = prof["birthday"];
            if (_s(m["experience"]).isEmpty) {
              m["experience"] = prof["experience"];
            }
            if (_s(m["bio"]).isEmpty) m["bio"] = prof["bio"];
            if (_s(m["photo"]).isEmpty) m["photo"] = prof["photo"];
            if (_s(m["photo_url"]).isEmpty) m["photo_url"] = prof["photo_url"];
            if (_s(m["email"]).isEmpty) m["email"] = prof["email"];
            // ✅ полезно для чата (если бек отдаёт)
            if (m["user_id"] == null && prof["user_id"] != null) {
              m["user_id"] = prof["user_id"];
            }
          }
        }

        return m;
      }).toList();

      out.addAll(await Future.wait(futures));
    }

    return out;
  }

  // =============================
  // ✅ helpers
  // =============================
  int _safeInt(dynamic v) {
    if (v == null) return 0;
    if (v is int) return v;
    return int.tryParse(v.toString()) ?? 0;
  }

  String _s(dynamic v) => (v ?? "").toString().trim();

  String _fio(Map<String, dynamic> x) {
    final last = _s(x["last_name"]);
    final first = _s(x["first_name"]);
    final middle = _s(x["middle_name"]);
    final fio = [last, first, middle].where((e) => e.isNotEmpty).join(" ");
    return fio.isEmpty ? _s(x["name"]) : fio;
  }

  List<Map<String, dynamic>> _sortByFio(List<Map<String, dynamic>> list) {
    final copy = [...list];
    copy.sort((a, b) {
      final al = _s(a["last_name"]).toLowerCase();
      final af = _s(a["first_name"]).toLowerCase();
      final bl = _s(b["last_name"]).toLowerCase();
      final bf = _s(b["first_name"]).toLowerCase();
      final c1 = al.compareTo(bl);
      if (c1 != 0) return c1;
      return af.compareTo(bf);
    });
    return copy;
  }

  /// ✅ Супер-устойчиво достаем trainerId из любого ответа API
  int _pickTrainerId(Map<String, dynamic> t) {
    int asInt(dynamic v) =>
        v is int ? v : int.tryParse((v ?? "").toString()) ?? 0;

    final candidates = [
      t["trainer_id"],
      t["trainerId"],
      t["id"],
      t["user_id"],
      t["uid"],
      t["trainer_user_id"],
      t["trainer_profile_id"],
    ];

    for (final c in candidates) {
      final v = asInt(c);
      if (v > 0) return v;
    }
    return 0;
  }

  // =============================
  // ✅ PDF PRINT (table players)
  // =============================
  Future<void> _printPlayersTable() async {
    if (players.isEmpty) {
      Get.snackbar("Печать", "Нет игроков для печати");
      return;
    }

    final doc = pw.Document();

    Future<pw.ImageProvider?> loadPhoto(String url) async {
      try {
        if (url.isEmpty) return null;
        final uri = Uri.parse(url);
        final resp = await http.get(uri);
        if (resp.statusCode == 200) {
          return pw.MemoryImage(resp.bodyBytes);
        }
      } catch (_) {}
      return null;
    }

    pw.Widget headerCell(String text) => pw.Padding(
          padding: const pw.EdgeInsets.all(6),
          child: pw.Text(
            text,
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(fontSize: 9.5, fontWeight: pw.FontWeight.bold),
          ),
        );

    pw.Widget cell(String text) => pw.Padding(
          padding: const pw.EdgeInsets.all(6),
          child: pw.Text(text, style: const pw.TextStyle(fontSize: 9)),
        );

    final rows = <pw.TableRow>[];

    for (final p in players) {
      final last = _s(p["last_name"]);
      final first = _s(p["first_name"]);
      final middle = _s(p["middle_name"]);
      final fio =
          [last, first, middle].where((e) => e.isNotEmpty).join(" ").trim();

      final dob = _s(p["birth_date"]);
      final position = _s(p["position"]);
      final foot = _s(p["foot"]);
      final number = _s(p["number"]);
      final metrics = _s(p["metrics"]);

      final photoUrl =
          _s(p["photo_url"]).isNotEmpty ? _s(p["photo_url"]) : _s(p["photo"]);
      final img =
          (photoUrl.startsWith("http")) ? await loadPhoto(photoUrl) : null;

      final letter = fio.isNotEmpty ? fio.substring(0, 1).toUpperCase() : "И";

      rows.add(
        pw.TableRow(
          children: [
            pw.Padding(
              padding: const pw.EdgeInsets.all(6),
              child: pw.Row(
                children: [
                  pw.Container(
                    width: 18,
                    height: 18,
                    decoration: const pw.BoxDecoration(
                      shape: pw.BoxShape.circle,
                      color: PdfColors.grey300,
                    ),
                    child: img != null
                        ? pw.ClipOval(
                            child: pw.Image(img, fit: pw.BoxFit.cover),
                          )
                        : pw.Center(
                            child: pw.Text(
                              letter,
                              style: pw.TextStyle(
                                fontSize: 9,
                                fontWeight: pw.FontWeight.bold,
                              ),
                            ),
                          ),
                  ),
                  pw.SizedBox(width: 6),
                  pw.Expanded(
                    child: pw.Text(
                      fio.isEmpty ? "Игрок" : fio,
                      style: const pw.TextStyle(fontSize: 9),
                    ),
                  ),
                ],
              ),
            ),
            cell(dob),
            cell(position),
            cell(foot),
            cell(number),
            cell(metrics),
          ],
        ),
      );
    }

    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.fromLTRB(24, 24, 24, 24),
        build: (_) => [
          pw.Text(
            "Состав команды: ${widget.teamName}",
            style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.black, width: 0.7),
            columnWidths: {
              0: const pw.FlexColumnWidth(2.2),
              1: const pw.FlexColumnWidth(1.2),
              2: const pw.FlexColumnWidth(1.3),
              3: const pw.FlexColumnWidth(1.5),
              4: const pw.FlexColumnWidth(1.1),
              5: const pw.FlexColumnWidth(1.7),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(color: PdfColors.grey200),
                children: [
                  headerCell("ФИО с фото"),
                  headerCell("Дата рождения"),
                  headerCell("Амплуа"),
                  headerCell("Профильная\nнога"),
                  headerCell("Игровой\nномер"),
                  headerCell("Метрики"),
                ],
              ),
              ...rows,
            ],
          ),
        ],
      ),
    );

    await Printing.layoutPdf(onLayout: (_) async => doc.save());
  }

  // =============================
  // ✅ UI (Matte)
  // =============================
  Widget _shimmerMatte() {
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      itemCount: 7,
      itemBuilder: (_, __) => Shimmer.fromColors(
        baseColor: const Color(0xFFE5E7EB),
        highlightColor: Colors.white,
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          height: 74,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bg = _bg;
    final primary = Theme.of(context).colorScheme.primary;
    final tabTitle = _tabTitle(_RosterTab.values[_tab.index]);

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: bg,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 16,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_rounded),
          onPressed: () => Navigator.pop(context),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.teamName,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 2),
            Text(
              tabTitle,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF64748B),
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Печать состава',
            onPressed: _printPlayersTable,
            icon: const Icon(Icons.print_rounded),
          ),
          IconButton(
            tooltip: 'Обновить',
            onPressed: _loadAll,
            icon: const Icon(Icons.refresh_rounded),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _loadAll,
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _tabsMatte(primary)),
            SliverToBoxAdapter(child: const SizedBox(height: 10)),
            if (loading) ...[
              SliverToBoxAdapter(
                child: SizedBox(height: 520, child: _shimmerMatte()),
              ),
            ] else if (error != null) ...[
              SliverFillRemaining(
                hasScrollBody: false,
                child: _ErrorBlock(text: error!, onRetry: _loadAll),
              ),
            ] else ...[
              SliverFillRemaining(
                hasScrollBody: true,
                child: TabBarView(
                  controller: _tab,
                  children: [
                    // 1) Игроки
                    _PlayersTabMatte(
  teamId: widget.teamId,
  primary: primary,
  players: players,
  canEdit: canEditRoster,
  canOpenPlayerProfile: role != "player",
 onPlayerTap: (p) {
  final mp = Map<String, dynamic>.from(p);
  mp["team_id"] = widget.teamId;     // ✅ КЛЮЧ ДЛЯ ДНЕВНИКА
  mp["teamId"] = widget.teamId;      // ✅ на всякий (если где-то ждёшь teamId)
  mp["club_id"] = clubId;            // ✅ опционально
  mp["team_name"] = widget.teamName; // ✅ опционально

  Get.toNamed(AppRoutes.playerProfileScreen, arguments: mp);
},
  onPlayerDelete: _deletePlayer,
),
                    // 2) Тренерский штаб (по команде)
                    _StaffListMatte(
                      title: "Тренерский штаб",
                      items: staff,
                      emptyText: "Тренеры команды не назначены.",
                      onTapTrainer: (t) {
                        final tid = _pickTrainerId(t);
                        final name = _fio(t);

                        if (tid <= 0) {
                          Get.snackbar(
                            "Тренер",
                            "Не найден trainer_id в ответе API. Ключи: ${t.keys.toList()}",
                            snackPosition: SnackPosition.BOTTOM,
                            margin: const EdgeInsets.all(12),
                          );
                          return;
                        }

                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => TrainerProfileViewScreen(
                              trainerId: tid,
                              trainerName: name.isEmpty ? "Тренер #$tid" : name,
                              // ✅ опционально пробросим фото/email из списка штаба
                              trainerPhotoRaw:
                                  (t["photo_url"] ?? t["photo"])?.toString(),
                              trainerEmailRaw: (t["email"])?.toString(),
                            ),
                          ),
                        );
                      },
                    ),

                    // 3) Родители
                    _PeopleListMatte(
                      title: "Родители",
                      items: parents,
                      emptyText: "Родители не найдены.",
                    ),

                    // 4) Руководство
                    _PeopleListMatte(
                      title: "Руководство",
                      items: managers,
                      emptyText: clubId <= 0
                          ? "Не найден club_id (через get_user.php)."
                          : "Руководство не найдено.",
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _tabsMatte(Color primary) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
      child: _MatteSurface(
        padding: const EdgeInsets.all(6),
        child: TabBar(
          controller: _tab,
          isScrollable: true,
          dividerColor: Colors.transparent,
          indicatorSize: TabBarIndicatorSize.tab,
          indicator: BoxDecoration(
            color: const Color(0xFFEFF6FF),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFF93C5FD)),
          ),
          labelColor: const Color(0xFF1D4ED8),
          unselectedLabelColor: const Color(0xFF334155),
          labelStyle: const TextStyle(fontWeight: FontWeight.w900, fontSize: 13),
          unselectedLabelStyle:
              const TextStyle(fontWeight: FontWeight.w800, fontSize: 13),
          labelPadding: const EdgeInsets.symmetric(horizontal: 6),
          onTap: (_) => setState(() {}),
          tabs: const [
            _MatteTab(icon: Icons.people_outline, text: "Игроки"),
            _MatteTab(icon: Icons.groups_2_outlined, text: "Тренерский штаб"),
            _MatteTab(icon: Icons.family_restroom_outlined, text: "Родители"),
            _MatteTab(icon: Icons.apartment_rounded, text: "Руководство"),
          ],
        ),
      ),
    );
  }

  String _tabTitle(_RosterTab t) {
    switch (t) {
      case _RosterTab.players:
        return "Состав команды";
      case _RosterTab.staff:
        return "Тренерский штаб";
      case _RosterTab.parents:
        return "Родители игроков";
      case _RosterTab.managers:
        return "Руководство клуба";
    }
  }
}

// ======================================================
// ✅ STAFF LIST (тренерский штаб)
// ======================================================
class _StaffListMatte extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> items;
  final String emptyText;
  final ValueChanged<Map<String, dynamic>> onTapTrainer;

  const _StaffListMatte({
    required this.title,
    required this.items,
    required this.emptyText,
    required this.onTapTrainer,
  });

  String _s(dynamic v) => (v ?? "").toString().trim();

  String _fio(Map<String, dynamic> x) {
    final last = _s(x["last_name"]);
    final first = _s(x["first_name"]);
    final middle = _s(x["middle_name"]);
    final fio = [last, first, middle].where((e) => e.isNotEmpty).join(" ");
    return fio.isEmpty ? _s(x["name"]) : fio;
  }

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        _MatteSurface(
          child: Row(
            children: [
              const Icon(Icons.groups_2_outlined, color: Color(0xFF0EA5E9)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F5F8),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),
                child: Text(
                  "${items.length}",
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (items.isEmpty)
          _MatteEmptyHint(text: emptyText)
        else
          ...items.map((t) {
            final fio = _fio(t);
            final photo = _s(t["photo_url"]).isNotEmpty ? _s(t["photo_url"]) : _s(t["photo"]);
            final position = _s(t["position"]);
            final roleTitle = _s(t["role_title"]);

            final subtitle = position.isNotEmpty
                ? position
                : (roleTitle.isNotEmpty ? roleTitle : "Тренер");

            return _MatteSurface(
              onTap: () => onTapTrainer(t),
              child: Row(
                children: [
                  _MatteAvatarSquare(
                    name: fio.isEmpty ? "Т" : fio,
                    photoUrl: photo,
                    primary: primary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          fio.isEmpty ? "Тренер" : fio,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          subtitle,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Color(0xFF64748B)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  const Icon(Icons.chevron_right_rounded, color: Color(0xFF94A3B8)),
                ],
              ),
            );
          }),
      ],
    );
  }
}

// ======================================================
// ✅ MATTE PEOPLE LIST (простые списки)
// ======================================================
class _PeopleListMatte extends StatelessWidget {
  final String title;
  final List<Map<String, dynamic>> items;
  final String emptyText;

  const _PeopleListMatte({
    required this.title,
    required this.items,
    required this.emptyText,
  });

  String _s(dynamic v) => (v ?? "").toString().trim();

  String _fio(Map<String, dynamic> x) {
    final last = _s(x["last_name"]);
    final first = _s(x["first_name"]);
    final middle = _s(x["middle_name"]);
    final fio = [last, first, middle].where((e) => e.isNotEmpty).join(" ");
    return fio.isEmpty ? _s(x["name"]) : fio;
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        _MatteSurface(
          child: Row(
            children: [
              const Icon(Icons.badge_outlined, color: Color(0xFF0EA5E9)),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFF3F5F8),
                  borderRadius: BorderRadius.circular(999),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                ),
                child: Text(
                  "${items.length}",
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 12),
        if (items.isEmpty)
          _MatteEmptyHint(text: emptyText)
        else
          ...items.map((x) {
            final fio = _fio(x);
            final roleTitle = _s(x["role_title"]);
            final role = _s(x["role"]);
            final email = _s(x["email"]);
            final photo =
                _s(x["photo_url"]).isNotEmpty ? _s(x["photo_url"]) : _s(x["photo"]);

            final subtitle = roleTitle.isNotEmpty
                ? roleTitle
                : (role.isNotEmpty ? role : (email.isNotEmpty ? email : "—"));

            return _MattePersonTile(
              fio: fio.isEmpty ? "Пользователь" : fio,
              subtitle: subtitle,
              photoUrl: photo,
            );
          }),
      ],
    );
  }
}

class _MattePersonTile extends StatelessWidget {
  final String fio;
  final String subtitle;
  final String photoUrl;

  const _MattePersonTile({
    required this.fio,
    required this.subtitle,
    required this.photoUrl,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    return _MatteSurface(
      onTap: () {},
      child: Row(
        children: [
          _MatteAvatarSquare(name: fio, photoUrl: photoUrl, primary: primary),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  fio,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Color(0xFF64748B)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ======================================================
// ✅ MATTE PLAYERS TAB
// ======================================================
class _PlayersTabMatte extends StatelessWidget {
  final int teamId;
  final Color primary;
  final List<Map<String, dynamic>> players;
  final bool canEdit;
  final bool canOpenPlayerProfile;
  final ValueChanged<Map<String, dynamic>> onPlayerTap;
  final ValueChanged<Map<String, dynamic>> onPlayerDelete;

  const _PlayersTabMatte({
    required this.teamId,
    required this.primary,
    required this.players,
    required this.canEdit,
    required this.canOpenPlayerProfile,
    required this.onPlayerTap,
    required this.onPlayerDelete,
  });

  String _s(dynamic v) => (v ?? "").toString().trim();

  String _fio(Map<String, dynamic> x) {
    final last = _s(x["last_name"]);
    final first = _s(x["first_name"]);
    final middle = _s(x["middle_name"]);
    return [last, first, middle].where((e) => e.isNotEmpty).join(" ").trim();
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        // ✅ Кнопка "Добавить игрока" — только если можно редактировать
        if (canEdit) ...[
          Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: LinearGradient(
                colors: [primary.withOpacity(0.95), primary.withOpacity(0.55)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: const [
                BoxShadow(
                  color: Color(0x22000000),
                  blurRadius: 18,
                  offset: Offset(0, 10),
                ),
              ],
            ),
            child: ElevatedButton(
              onPressed: () {
                Get.toNamed(
                  AppRoutes.addPlayerScreen,
                  arguments: {"teamId": teamId},
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 14),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.person_add_alt_1, color: Colors.white),
                  SizedBox(width: 10),
                  Text(
                    "Добавить игрока",
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],

        if (players.isEmpty)
          const _MatteEmptyHint(text: "Игроки не найдены.")
        else
          ...players.map((p) {
            final name = _fio(p);
            final pos = _s(p["position"]).isEmpty ? "Без позиции" : _s(p["position"]);
            final number = _s(p["number"]);
            final photo =
                _s(p["photo_url"]).isNotEmpty ? _s(p["photo_url"]) : _s(p["photo"]);

            return _MatteSurface(
              onTap: canOpenPlayerProfile ? () => onPlayerTap(p) : null,
              child: Row(
                children: [
                  _MatteAvatarSquare(
                    name: name.isEmpty ? "Игрок" : name,
                    photoUrl: photo,
                    primary: primary,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          name.isEmpty ? "Игрок" : name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          number.isNotEmpty ? "$pos • №$number" : pos,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: Color(0xFF64748B)),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),

                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // ✅ Меню действий — только если можно редактировать
                      if (canEdit)
                        PopupMenuButton<String>(
                          tooltip: "Действия",
                          onSelected: (v) {
                            if (v == "delete") onPlayerDelete(p);
                          },
                          itemBuilder: (_) => const [
                            PopupMenuItem(
                              value: "delete",
                              child: Row(
                                children: [
                                  Icon(Icons.delete_outline, color: Colors.red),
                                  SizedBox(width: 10),
                                  Text("Удалить из команды"),
                                ],
                              ),
                            ),
                          ],
                          child: const Padding(
                            padding: EdgeInsets.all(6),
                            child: Icon(Icons.more_vert_rounded, color: Color(0xFF94A3B8)),
                          ),
                        ),
                       // ✅ стрелочка только если можно открывать профиль
    if (canOpenPlayerProfile)
      const Icon(Icons.chevron_right_rounded, color: Color(0xFF94A3B8)),
  ],
),
                ],
              ),
            );
          }),
      ],
    );
  }
}

// ======================================================
// ✅ VIEW TRAINER PROFILE (ВИЗИТКА + КНОПКА ЧАТА)
// ======================================================
class TrainerProfileViewScreen extends StatefulWidget {
  final int trainerId;
  final String trainerName;

  /// ✅ опционально: если уже есть фото/email в списке штаба — пробросим
  final String? trainerPhotoRaw;
  final String? trainerEmailRaw;

  const TrainerProfileViewScreen({
    super.key,
    required this.trainerId,
    required this.trainerName,
    this.trainerPhotoRaw,
    this.trainerEmailRaw,
  });

  @override
  State<TrainerProfileViewScreen> createState() => _TrainerProfileViewScreenState();
}

class _TrainerProfileViewScreenState extends State<TrainerProfileViewScreen> {
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getUrl = "$apiBase/get_trainer_profile.php";

  // ✅ нужен эндпоинт: создаёт/возвращает direct chat между двумя users
  static const String getOrCreateDirectChatUrl =
      "https://sportotekaapp.ru/api/get_or_create_direct_chat.php";

  bool _isLoading = true;
  String? _error;
  Map<String, dynamic> _profile = {};

  String _s(dynamic v) => (v ?? "").toString().trim();

  Map<String, dynamic> _decode(String s) {
    try {
      final j = jsonDecode(s);
      return (j is Map) ? Map<String, dynamic>.from(j) : {};
    } catch (_) {
      return {};
    }
  }

  String? _normalizeImage(String? raw) {
    if (raw == null || raw.trim().isEmpty) return null;
    String url = raw.trim();

    if (url.startsWith("http://") || url.startsWith("https://")) return url;
    if (url.startsWith("//")) return "https:$url";
    if (url.startsWith("sportotekaapp.ru/")) return "https://$url";
    if (url.startsWith("www.sportotekaapp.ru/")) return "https://$url";
    if (url.startsWith("/")) return "https://sportotekaapp.ru$url";
    if (url.startsWith("uploads/")) return "https://sportotekaapp.ru/$url";

    return "https://sportotekaapp.ru/uploads/$url";
  }

  /// ✅ для чата нужен именно user_id тренера (из users)
  int _pickTrainerUserIdForChat(Map<String, dynamic> p) {
    int asInt(dynamic v) => v is int ? v : int.tryParse((v ?? "").toString()) ?? 0;

    final candidates = [
      p["user_id"],
      p["trainer_user_id"],
      p["uid"],
      // ВНИМАНИЕ: "id" берём только если бек реально отдаёт id из users
      p["id"],
    ];

    for (final c in candidates) {
      final v = asInt(c);
      if (v > 0) return v;
    }
    return 0;
  }

  Future<int?> _getOrCreateDirectChat({
    required int myUserId,
    required int otherUserId,
  }) async {
    try {
      final res = await http.post(
        Uri.parse(getOrCreateDirectChatUrl),
        body: {
          "user_id": myUserId.toString(),
          "other_user_id": otherUserId.toString(),
        },
      );

      if (res.statusCode != 200) return null;

      final data = jsonDecode(res.body);
      if (data is Map) {
        final ok = data["success"] == true || data["status"] == "success";
        if (!ok) return null;

        final chatId = data["chat_id"] ?? data["id"];
        return int.tryParse((chatId ?? "").toString());
      }
      return null;
    } catch (_) {
      return null;
    }
  }

  Future<void> _openChatToTrainer({required String trainerName}) async {
    final myId = (await PrefUtils.getUserId()) ?? 0;
    if (myId <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Не найден userId. Перезайдите в аккаунт.")),
      );
      return;
    }

    final trainerUserId = _pickTrainerUserIdForChat(_profile);
    if (trainerUserId <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            "Не найден user_id тренера в профиле. Ключи: ${_profile.keys.toList()}",
          ),
        ),
      );
      return;
    }

    final chatId = await _getOrCreateDirectChat(
      myUserId: myId,
      otherUserId: trainerUserId,
    );

    if (chatId == null || chatId <= 0) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Не удалось создать/открыть чат")),
      );
      return;
    }

    if (!mounted) return;
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => ChatRoomScreen(
          chatId: chatId,
          userId: myId,
          chatName: trainerName,
        ),
      ),
    );
  }

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final resp = await http.post(
        Uri.parse(getUrl),
        headers: const {"Content-Type": "application/json; charset=utf-8"},
        body: jsonEncode({"trainer_id": widget.trainerId}),
      );

      final data = _decode(resp.body);

      // ✅ поддержка двух форматов:
      // - { status: "success", trainer: {...} }
      // - { success: true, profile: {...} }
      final ok = data["status"] == "success" || data["success"] == true;
      final obj = data["trainer"] ?? data["profile"];

      if (ok && obj is Map) {
        _profile = Map<String, dynamic>.from(obj);
        setState(() => _isLoading = false);
      } else {
        setState(() {
          _isLoading = false;
          _error = _s(data["message"]).isEmpty ? "Не удалось загрузить" : _s(data["message"]);
        });
      }
    } catch (e) {
      setState(() {
        _isLoading = false;
        _error = "Ошибка загрузки: $e";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final photo = _normalizeImage(
      _s(_profile["photo_url"]).isNotEmpty
          ? _s(_profile["photo_url"])
          : (_s(_profile["photo"]).isNotEmpty
              ? _s(_profile["photo"])
              : (widget.trainerPhotoRaw ?? "")),
    );

    final email = _s(_profile["email"]).isNotEmpty
        ? _s(_profile["email"])
        : _s(widget.trainerEmailRaw);

    final position = _s(_profile["position"]);
    final bio = _s(_profile["bio"]);
    final birthdayRaw = _s(_profile["birthday"]);
    final birthday = birthdayRaw.length >= 10 ? birthdayRaw.substring(0, 10) : birthdayRaw;
    final experience = _s(_profile["experience"]);

    final displayName = widget.trainerName.isEmpty
        ? "Тренер #${widget.trainerId}"
        : widget.trainerName;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        backgroundColor: AppColors.card,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
          color: AppColors.textPrimary,
          onPressed: () => Get.back(),
        ),
        title: const Text(
          "Визитка тренера",
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: AppColors.textPrimary,
            fontSize: 18,
          ),
        ),
        centerTitle: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppColors.primaryGreen),
            onPressed: _loadProfile,
          ),
          const SizedBox(width: 8),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? _TrainerErrorState(error: _error!, onRetry: _loadProfile)
              : RefreshIndicator(
                  color: AppColors.primaryGreen,
                  backgroundColor: AppColors.background,
                  onRefresh: () async => _loadProfile(),
                  child: CustomScrollView(
                    slivers: [
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.all(20),
                          child: _TrainerProfileCardView(
                            name: displayName,
                            email: email,
                            photo: photo,
                            position: position,
                            trainerId: widget.trainerId,
                            onChatTap: () => _openChatToTrainer(trainerName: displayName),
                          ),
                        ),
                      ),
                      SliverPadding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                        sliver: SliverList(
                          delegate: SliverChildListDelegate([
                            if (birthday.isNotEmpty)
                              _TrainerInfoCard(
                                icon: Icons.cake_rounded,
                                title: "Дата рождения",
                                content: birthday,
                              ),
                            if (birthday.isNotEmpty) const SizedBox(height: 12),
                            if (experience.isNotEmpty)
                              _TrainerInfoCard(
                                icon: Icons.work_history_rounded,
                                title: "Опыт / карьера",
                                content: experience,
                              ),
                            if (experience.isNotEmpty) const SizedBox(height: 12),
                            if (bio.isNotEmpty)
                              _TrainerInfoCard(
                                icon: Icons.description_rounded,
                                title: "О тренере",
                                content: bio,
                              ),
                            if (birthday.isEmpty && experience.isEmpty && bio.isEmpty)
                              const _TrainerEmptyInfoHint(),
                          ]),
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }
}

class _TrainerProfileCardView extends StatelessWidget {
  final String name;
  final String email;
  final String? photo;
  final String position;
  final int trainerId;

  // ✅ кнопка чата
  final VoidCallback onChatTap;

  const _TrainerProfileCardView({
    required this.name,
    required this.email,
    required this.photo,
    required this.position,
    required this.trainerId,
    required this.onChatTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          _TrainerCircleNetworkImage(
            imageUrl: photo,
            size: 104,
            borderColor: AppColors.primaryGreen.withOpacity(0.25),
            borderWidth: 2,
            glow: AppColors.primaryGreen.withOpacity(0.20),
            fallback: Container(
              color: AppColors.primaryGreen.withOpacity(0.10),
              child: Icon(
                Icons.person_outline_rounded,
                color: AppColors.primaryGreen,
                size: 52,
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            name,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: AppColors.textPrimary,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 8),
          if (email.isNotEmpty)
            Text(
              email,
              style: const TextStyle(
                fontSize: 15,
                color: AppColors.textSecondary,
              ),
              textAlign: TextAlign.center,
            )
          else
            Text(
              "ID: $trainerId",
              style: TextStyle(
                fontSize: 14,
                color: AppColors.textSecondary.withOpacity(0.9),
                fontWeight: FontWeight.w800,
              ),
            ),
          const SizedBox(height: 14),
          if (position.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.primaryGreen.withOpacity(0.10),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Text(
                position,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                  color: AppColors.primaryGreen,
                ),
                textAlign: TextAlign.center,
              ),
            )
          else
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.grey.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: const Text(
                "Должность не указана",
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w800,
                  color: AppColors.textSecondary,
                ),
              ),
            ),

          // ✅ кнопка "Написать"
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: onChatTap,
                  icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                  label: const Text(
                    "Написать",
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primaryGreen,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _TrainerInfoCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String content;

  const _TrainerInfoCard({
    required this.icon,
    required this.title,
    required this.content,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: AppColors.primaryGreen),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w900,
                  color: AppColors.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            content,
            style: const TextStyle(
              fontSize: 15,
              color: AppColors.textSecondary,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerCircleNetworkImage extends StatelessWidget {
  final String? imageUrl;
  final double size;
  final double borderWidth;
  final Color borderColor;
  final Color? glow;
  final Widget fallback;

  const _TrainerCircleNetworkImage({
    required this.imageUrl,
    required this.size,
    required this.borderWidth,
    required this.borderColor,
    required this.fallback,
    this.glow,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: AppColors.white,
        boxShadow: glow != null
            ? [
                BoxShadow(
                  color: glow!,
                  blurRadius: 22,
                  offset: const Offset(0, 10),
                ),
              ]
            : null,
        border: Border.all(color: borderColor, width: borderWidth),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(size / 2),
        child: (imageUrl == null || imageUrl!.isEmpty)
            ? fallback
            : CachedNetworkImage(
                imageUrl: imageUrl!,
                fit: BoxFit.cover,
                fadeInDuration: const Duration(milliseconds: 120),
                placeholder: (context, _) => const Center(
                  child: SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
                errorWidget: (context, _, __) => fallback,
              ),
      ),
    );
  }
}

class _TrainerEmptyInfoHint extends StatelessWidget {
  const _TrainerEmptyInfoHint();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.card,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.grey.shade200),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded,
              color: AppColors.textSecondary.withOpacity(0.7)),
          const SizedBox(width: 12),
          const Expanded(
            child: Text(
              "Информация о тренере пока не заполнена.",
              style: TextStyle(
                color: AppColors.textSecondary,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TrainerErrorState extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;

  const _TrainerErrorState({
    required this.error,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded, size: 64, color: Colors.red.shade400),
            const SizedBox(height: 16),
            Text(error, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: onRetry,
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryGreen,
                foregroundColor: AppColors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
              ),
              child: const Text("Повторить"),
            ),
          ],
        ),
      ),
    );
  }
}

// ======================================================
// ✅ MATTE AVATAR (как было)
// ======================================================
class _MatteAvatarSquare extends StatelessWidget {
  final String name;
  final String photoUrl;
  final Color primary;

  const _MatteAvatarSquare({
    required this.name,
    required this.photoUrl,
    required this.primary,
  });

  @override
  Widget build(BuildContext context) {
    final u = photoUrl.trim();
    final letter = (name.isNotEmpty ? name.substring(0, 1) : "И").toUpperCase();

    return Container(
      width: 44,
      height: 44,
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      clipBehavior: Clip.antiAlias,
      child: (u.isNotEmpty && u.startsWith("http"))
          ? Image.network(
              u,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => _fallback(letter),
            )
          : _fallback(letter),
    );
  }

  Widget _fallback(String letter) {
    return Container(
      color: primary.withOpacity(0.10),
      alignment: Alignment.center,
      child: Text(
        letter,
        style: TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w900,
          color: primary,
        ),
      ),
    );
  }
}

// ======================================================
// ✅ EMPTY / ERROR
// ======================================================
class _MatteEmptyHint extends StatelessWidget {
  final String text;
  const _MatteEmptyHint({required this.text});

  @override
  Widget build(BuildContext context) {
    return _MatteSurface(
      child: Row(
        children: [
          const Icon(Icons.info_outline, color: Color(0xFF94A3B8)),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(fontWeight: FontWeight.w900),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorBlock extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;
  const _ErrorBlock({required this.text, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline, size: 56, color: Colors.redAccent),
            const SizedBox(height: 12),
            const Text('Ошибка загрузки',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
            const SizedBox(height: 6),
            Text(
              text,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xFF64748B)),
            ),
            const SizedBox(height: 16),
            FilledButton(onPressed: onRetry, child: const Text('Повторить')),
          ],
        ),
      ),
    );
  }
}

// ======================================================
// ✅ MATTE UI ATOMS
// ======================================================
class _MatteSurface extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;

  const _MatteSurface({
    required this.child,
    this.padding = const EdgeInsets.all(12),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: const [
          BoxShadow(color: Color(0x11000000), blurRadius: 16, offset: Offset(0, 6)),
        ],
      ),
      child: child,
    );

    if (onTap != null) {
      return Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: onTap,
          child: content,
        ),
      );
    }
    return content;
  }
}

class _MatteTab extends StatelessWidget {
  final IconData icon;
  final String text;

  const _MatteTab({required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Tab(
      child: Container(
        height: 40,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18),
            const SizedBox(width: 8),
            Text(text, maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}
