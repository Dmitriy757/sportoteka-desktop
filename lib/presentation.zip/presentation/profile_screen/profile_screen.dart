import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:sportoteka/core/app_export.dart';
import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/achievements_screen/achievements_screen.dart';
import 'package:sportoteka/presentation/add_personal_training_screen/my_trainings_screen.dart';
import 'package:sportoteka/presentation/booking_screen/bookings_for_my_venues_screen.dart';
import 'package:sportoteka/presentation/innovation/history_screen.dart';
import 'package:sportoteka/widgets/support_button.dart';

import 'controller/profile_controller.dart';

class ProfilePalette {
  static const primaryGreen = Color(0xFF00A750);
  static const primaryGreenDark = Color(0xFF008C40);
  static const primaryGreenLight = Color(0xFF00C060);
  static const accentGreen = Color(0xFF7ED321);
  static const lightGreen = Color(0xFFE8F5E9);
  static const superLightGreen = Color(0xFFF2FFF5);

  static const white = Color(0xFFFFFFFF);
  static const text = Color(0xFF1A1A1A);
  static const textMuted = Color(0xFF666666);
  static const textLight = Color(0xFF999999);
  static const background = Color(0xFFF8F9FA);
  static const card = Color(0xFFFFFFFF);
  static const border = Color(0xFFE5E7EB);

  static const greenGradient = LinearGradient(
    colors: [primaryGreen, primaryGreenDark],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  final ProfileController controller = Get.put(ProfileController());

  static const String deleteAccountUrl =
      'https://sportoteka.by/api/delete_account.php';
  static const String termsUrl = 'https://sportoteka.by/terms';
  static const String privacyUrl = 'https://sportoteka.by/privacy';
  static const String rulesUrl = 'https://sportoteka.by/community-rules';

  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getMyCoachTeamUrl = "$apiBase/get_my_team_by_coach.php";
  static const String getAssignedCoachTeamUrl = "$apiBase/get_trainer_team.php";
  static const String getPlayerTeamUrl = "$apiBase/get_player_team.php";

  String userRole = '';
  String firstName = '';
  String lastName = '';
  String email = '';
  String avatarUrl = '';

  late AnimationController _animationController;

  bool get isClub {
    final r = userRole.trim().toLowerCase();
    return r == 'club' || r == 'clubs' || r == 'клуб';
  }

  bool get isCoach {
    final r = userRole.trim().toLowerCase();
    return r == 'coach' ||
        r == 'trainer' ||
        r == 'тренер' ||
        r == 'coaches';
  }

  bool get isPlayer {
    final r = userRole.trim().toLowerCase();
    return r == 'player' || r == 'игрок';
  }

  bool myTeamLoading = false;
  int myTeamId = 0;
  String myTeamName = "";
  String myTeamLogo = "";
  String myTeamCategory = "";

  bool assignedTeamLoading = false;
  int assignedTeamId = 0;
  String assignedTeamName = "";
  String assignedTeamLogo = "";
  String assignedTeamCategory = "";

  bool playerTeamLoading = false;
  int playerTeamId = 0;
  String playerTeamName = "";
  String playerTeamLogo = "";
  String playerTeamCategory = "";

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is String) return int.tryParse(v) ?? 0;
    return 0;
  }
  Map<String, dynamic> _decode(http.Response r) {
  try {
    final body = r.body.trim();
    if (body.isEmpty) {
      return {"status": "error", "message": "EMPTY_BODY"};
    }

    final j = json.decode(body);

    if (j is Map<String, dynamic>) {
      return j;
    }

    if (j is Map) {
      return Map<String, dynamic>.from(j);
    }
  } catch (_) {}

  return {"status": "error"};
}

  String _normalizeFileUrl(String raw) {
    var s = raw.trim();
    if (s.isEmpty) return "";
    if (s.startsWith("http://") || s.startsWith("https://")) return s;
    if (!s.startsWith("/")) s = "/$s";
    return "https://sportotekaapp.ru$s";
  }

  Future<String> _loadSavedAvatarUrl() async {
    final prefs = await SharedPreferences.getInstance();

    final candidates = <String?>[
      prefs.getString('photo'),
      prefs.getString('photo_url'),
      prefs.getString('avatar'),
      prefs.getString('image'),
      prefs.getString('user_photo'),
      prefs.getString('user_avatar'),
      prefs.getString('profile_photo'),
      prefs.getString('profile_image'),
    ];

    for (final raw in candidates) {
      final normalized = _normalizeFileUrl(raw ?? '');
      if (normalized.isNotEmpty) {
        return normalized;
      }
    }

    return '';
  }

  bool _isTablet(double width) => width >= 700;

  int _bannerColumns(double width) {
    if (width >= 1280) return 4;
    if (width >= 900) return 4;
    if (width >= 700) return 3;
    return 2;
  }

  double _bannerAspectRatio(double width) {
    if (width >= 1280) return 1.45;
    if (width >= 900) return 1.28;
    if (width >= 700) return 1.18;
    return 1.35;
  }

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    )..forward();

    _loadUserData();
  }

  Future<void> _loadUserData() async {
    controller.currentUserId = await PrefUtils.getUserId() ?? 0;

    final pref = PrefUtils();
    await pref.init();

    userRole = pref.getUserRole();
    firstName = pref.getUserFirstName();
    lastName = pref.getUserLastName();
    email = pref.getUserEmail();
    avatarUrl = await _loadSavedAvatarUrl();

    if (mounted) setState(() {});

    if (isCoach) {
      await _loadMyCoachTeam();
      await _loadAssignedCoachTeam();
    }

    if (isPlayer) {
      await _loadPlayerTeam();
    }
  }

  Future<void> _loadMyCoachTeam() async {
    final userId = controller.currentUserId;
    if (userId == 0) return;

    if (mounted) setState(() => myTeamLoading = true);

    try {
      final resp = await http.post(
        Uri.parse(getMyCoachTeamUrl),
        body: {"trainer_id": userId.toString()},
      );

      Map<String, dynamic> j;
      try {
        j = json.decode(resp.body) as Map<String, dynamic>;
      } catch (_) {
        j = {"success": false};
      }

      if (j["success"] == true && j["team"] is Map) {
        final team = Map<String, dynamic>.from(j["team"]);
        myTeamId = _asInt(team["id"]);
        myTeamName = (team["name"] ?? "").toString();
        myTeamCategory = (team["category"] ?? "").toString();
        myTeamLogo = _normalizeFileUrl((team["logo"] ?? "").toString());
      } else {
        myTeamId = 0;
        myTeamName = "";
        myTeamCategory = "";
        myTeamLogo = "";
      }
    } catch (_) {
      //
    } finally {
      if (mounted) setState(() => myTeamLoading = false);
    }
  }

  Future<void> _loadAssignedCoachTeam() async {
    final userId = controller.currentUserId;
    if (userId == 0) return;

    if (mounted) setState(() => assignedTeamLoading = true);

    try {
      final resp = await http.post(
        Uri.parse(getAssignedCoachTeamUrl),
        body: {"trainer_id": userId.toString()},
      );

      Map<String, dynamic> j;
      try {
        j = json.decode(resp.body) as Map<String, dynamic>;
      } catch (_) {
        j = {"success": false};
      }

      if (j["success"] == true && j["team"] is Map) {
        final team = Map<String, dynamic>.from(j["team"]);
        assignedTeamId = _asInt(team["id"]);
        assignedTeamName = (team["name"] ?? "").toString();
        assignedTeamCategory = (team["category"] ?? "").toString();
        assignedTeamLogo = _normalizeFileUrl((team["logo"] ?? "").toString());
      } else {
        assignedTeamId = 0;
        assignedTeamName = "";
        assignedTeamCategory = "";
        assignedTeamLogo = "";
      }
    } catch (_) {
      //
    } finally {
      if (mounted) setState(() => assignedTeamLoading = false);
    }
  }

  Future<void> _loadPlayerTeam() async {
  final userId = await PrefUtils.getUserId();
  if (userId == null || userId == 0) return;

  if (mounted) {
    setState(() => playerTeamLoading = true);
  }

  try {
    final resp = await http
        .get(Uri.parse("$getPlayerTeamUrl?user_id=$userId"))
        .timeout(const Duration(seconds: 12));

    debugPrint("PROFILE PLAYER TEAM RESPONSE: ${resp.body}");

    final data = _decode(resp);
    final ok = data["success"] == true || data["status"] == "success";

    if (!ok || data["team"] is! Map) {
      if (mounted) {
        setState(() {
          playerTeamId = 0;
          playerTeamName = "";
          playerTeamCategory = "";
          playerTeamLogo = "";
          playerTeamLoading = false;
        });
      }
      return;
    }

    final team = Map<String, dynamic>.from(data["team"]);

    if (mounted) {
      setState(() {
        playerTeamId = _asInt(team["team_id"] ?? team["id"]);
        playerTeamName =
            (team["team_name"] ?? team["name"] ?? "").toString();
        playerTeamCategory =
            (team["category"] ?? team["sport_type"] ?? "").toString();
        playerTeamLogo = _normalizeFileUrl(
          (team["team_logo"] ?? team["logo"] ?? "").toString(),
        );
        playerTeamLoading = false;
      });
    }
  } catch (e) {
    debugPrint("PROFILE _loadPlayerTeam error: $e");
    if (mounted) {
      setState(() {
        playerTeamId = 0;
        playerTeamName = "";
        playerTeamCategory = "";
        playerTeamLogo = "";
        playerTeamLoading = false;
      });
    }
  }
}
  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _onEditAvatar() {
    Get.toNamed(AppRoutes.myProfileScreen)?.then((_) => _loadUserData());
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      Get.snackbar("Ошибка", "Не удалось открыть ссылку");
    }
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    final width = MediaQuery.of(context).size.width;
    final banners = _menuBanners(context);
    final activities = _activitiesForRole(context);
    final tablet = _isTablet(width);

    return Scaffold(
      backgroundColor: ProfilePalette.background,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: ProfilePalette.white,
        surfaceTintColor: Colors.transparent,
        centerTitle: false,
        titleSpacing: 16,
        title: const Text(
          "Профиль",
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: ProfilePalette.text,
            fontSize: 16,
          ),
        ),
        actions: [
          IconButton(
            tooltip: 'Обновить',
            onPressed: _loadUserData,
            icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
          ),
          IconButton(
            tooltip: 'Уведомления',
            onPressed: () {},
            icon: const Icon(
              Icons.notifications_none_rounded,
              color: Colors.black87,
            ),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: FadeTransition(
        opacity: CurvedAnimation(
          parent: _animationController,
          curve: Curves.easeInOut,
        ),
        child: RefreshIndicator(
          onRefresh: _loadUserData,
          color: ProfilePalette.primaryGreen,
          child: Align(
            alignment: Alignment.topCenter,
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1180),
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 110),
                children: [
                  _buildTopProfileCard(tablet: tablet),
                  const SizedBox(height: 12),
                  _buildTeamsDashboardCard(),
                  if (isClub) ...[
                    const SizedBox(height: 12),
                    _buildClubBanner(),
                  ],
                  const SizedBox(height: 14),
                  _buildSectionTitle(isClub ? "Панель" : "Быстрые действия"),
                  const SizedBox(height: 8),
                  GridView.builder(
                    itemCount: banners.length,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: _bannerColumns(width),
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: _bannerAspectRatio(width),
                    ),
                    itemBuilder: (context, index) =>
                        _buildMenuBanner(context, banners[index]),
                  ),
                  const SizedBox(height: 18),
                  tablet
                      ? _buildTabletSections(context, activities)
                      : _buildMobileSections(context, activities),
                  const SizedBox(height: 16),
                  const SupportButton(),
                  const SizedBox(height: 18),
                  Center(
                    child: Text(
                      "Версия 1.0.0",
                      style: TextStyle(
                        color: Colors.grey.shade600,
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
      floatingActionButton: _buildLogoutButton(context),
    );
  }

  Widget _buildTopProfileCard({required bool tablet}) {
    final fullName = "$firstName $lastName".trim().isEmpty
        ? "Пользователь"
        : "$firstName $lastName".trim();

    return Container(
      padding: EdgeInsets.all(tablet ? 20 : 16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            ProfilePalette.primaryGreen.withOpacity(0.12),
            ProfilePalette.superLightGreen,
            Colors.white,
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: ProfilePalette.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.045),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              GestureDetector(
                onTap: _onEditAvatar,
                child: _buildAvatar(
                  radius: tablet ? 34 : 30,
                  withBorder: true,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      fullName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: tablet ? 20 : 17,
                        color: ProfilePalette.text,
                        height: 1.15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      email.isEmpty ? "Email не указан" : email,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: ProfilePalette.textMuted,
                        fontWeight: FontWeight.w700,
                        fontSize: 12.5,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        _metaChip(
                          Icons.badge_outlined,
                          _roleLabelRu(userRole),
                        ),
                        if (isPlayer && playerTeamName.isNotEmpty)
                          _metaChip(Icons.group_outlined, playerTeamName),
                        if (isCoach && myTeamName.isNotEmpty)
                          _metaChip(Icons.group_outlined, myTeamName),
                        if (isCoach &&
                            assignedTeamId > 0 &&
                            assignedTeamName.isNotEmpty &&
                            assignedTeamId != myTeamId)
                          _metaChip(Icons.shield_outlined, assignedTeamName),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildProfileStatChip(
                  icon: Icons.dashboard_outlined,
                  title: 'Роль',
                  value: _roleLabelRu(userRole),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildProfileStatChip(
                  icon: Icons.group_work_outlined,
                  title: 'Команд',
                  value: isCoach
                      ? '${(myTeamId > 0 ? 1 : 0) + (assignedTeamId > 0 && assignedTeamId != myTeamId ? 1 : 0)}'
                      : isPlayer
                          ? '${playerTeamId > 0 ? 1 : 0}'
                          : '—',
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _buildProfileStatChip(
                  icon: Icons.verified_user_outlined,
                  title: 'Статус',
                  value: 'Активен',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildProfileStatChip({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: ProfilePalette.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
              color: ProfilePalette.superLightGreen,
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(
              icon,
              size: 18,
              color: ProfilePalette.primaryGreen,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w900,
              color: ProfilePalette.text,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            title,
            style: const TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w700,
              color: ProfilePalette.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTeamsDashboardCard() {
    if (!isCoach && !isPlayer) return const SizedBox();

    final hasMyTeam = myTeamId > 0;
    final hasAssignedTeam = assignedTeamId > 0 && assignedTeamId != myTeamId;
    final hasPlayerTeam = playerTeamId > 0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: ProfilePalette.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: ProfilePalette.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.045),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: const BoxDecoration(
                  gradient: ProfilePalette.greenGradient,
                  borderRadius: BorderRadius.all(Radius.circular(12)),
                ),
                child: const Icon(
                  Icons.groups_rounded,
                  color: Colors.white,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      isPlayer ? 'Моя команда' : 'Мои команды',
                      style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        fontSize: 16,
                        color: ProfilePalette.text,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      isPlayer
                          ? 'Команда, к которой привязан игрок'
                          : 'Управление личной и назначенной командой',
                      style: const TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: ProfilePalette.textMuted,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 7,
                ),
                decoration: BoxDecoration(
                  color: ProfilePalette.superLightGreen,
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  isPlayer
                      ? '${hasPlayerTeam ? 1 : 0}'
                      : '${(hasMyTeam ? 1 : 0) + (hasAssignedTeam ? 1 : 0)}',
                  style: const TextStyle(
                    color: ProfilePalette.primaryGreen,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          if ((isCoach && (myTeamLoading || assignedTeamLoading)) ||
              (isPlayer && playerTeamLoading))
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: ProfilePalette.background,
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Row(
                children: [
                  SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                  SizedBox(width: 12),
                  Text(
                    'Загрузка информации о командах...',
                    style: TextStyle(
                      fontWeight: FontWeight.w700,
                      color: ProfilePalette.textMuted,
                    ),
                  ),
                ],
              ),
            )
          else ...[
            if (isCoach) ...[
              if (hasMyTeam)
                _buildMiniTeamCard(
                  title: 'Моя команда',
                  subtitle:
                      myTeamCategory.isEmpty ? 'Команда тренера' : myTeamCategory,
                  teamName: myTeamName,
                  logoUrl: myTeamLogo,
                  badgeText: 'Моя',
                  onTap: () => Get.toNamed(
                    "/myTeamScreen",
                    arguments: {
                      "team_id": myTeamId,
                      "mode": "coach_my",
                    },
                  ),
                )
              else
                _buildMiniTeamCard(
                  title: 'Моя команда',
                  subtitle: 'Команда ещё не создана',
                  teamName: 'Создать команду',
                  logoUrl: '',
                  badgeText: 'Новая',
                  onTap: () => Get.toNamed(AppRoutes.createTeamScreen),
                  isPlaceholder: true,
                ),
              if (hasAssignedTeam) ...[
                const SizedBox(height: 10),
                _buildMiniTeamCard(
                  title: 'Команда клуба',
                  subtitle: assignedTeamCategory.isEmpty
                      ? 'Назначена клубом'
                      : assignedTeamCategory,
                  teamName: assignedTeamName,
                  logoUrl: assignedTeamLogo,
                  badgeText: 'Club',
                  onTap: () => Get.toNamed(
                    "/myTeamScreen",
                    arguments: {
                      "team_id": assignedTeamId,
                      "mode": "club_assigned",
                    },
                  ),
                ),
              ],
            ],
            if (isPlayer)
              hasPlayerTeam
                  ? _buildMiniTeamCard(
                      title: 'Назначенная команда',
                      subtitle: playerTeamCategory.isEmpty
                          ? 'Команда игрока'
                          : playerTeamCategory,
                      teamName: playerTeamName,
                      logoUrl: playerTeamLogo,
                      badgeText: 'Игрок',
                      onTap: () => Get.toNamed(
                        "/myTeamScreen",
                        arguments: {
                          "team_id": playerTeamId,
                          "mode": "player_team",
                        },
                      ),
                    )
                  : _buildMiniTeamCard(
                      title: 'Назначенная команда',
                      subtitle: 'Игрок пока не привязан к команде',
                      teamName: 'Команда не назначена',
                      logoUrl: '',
                      badgeText: '—',
                      onTap: () {},
                      isPlaceholder: true,
                    ),
          ],
        ],
      ),
    );
  }

  Widget _buildMiniTeamCard({
    required String title,
    required String subtitle,
    required String teamName,
    required String logoUrl,
    required String badgeText,
    required VoidCallback onTap,
    bool isPlaceholder = false,
  }) {
    final hasLogo = logoUrl.trim().isNotEmpty;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isPlaceholder
              ? ProfilePalette.superLightGreen
              : ProfilePalette.background,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isPlaceholder
                ? ProfilePalette.lightGreen
                : ProfilePalette.border,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: ProfilePalette.border),
              ),
              child: hasLogo
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(15),
                      child: Image.network(
                        logoUrl,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(
                          Icons.shield_outlined,
                          color: ProfilePalette.primaryGreen,
                        ),
                      ),
                    )
                  : const Icon(
                      Icons.shield_outlined,
                      color: ProfilePalette.primaryGreen,
                      size: 26,
                    ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: ProfilePalette.textMuted,
                        ),
                      ),
                      const SizedBox(width: 8),
                      _buildStatusDot(
                        isPlaceholder ? Colors.orange : Colors.green,
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    teamName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w900,
                      color: ProfilePalette.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: ProfilePalette.textMuted,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Column(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(999),
                    border: Border.all(color: ProfilePalette.border),
                  ),
                  child: Text(
                    badgeText,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      color: ProfilePalette.primaryGreen,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: ProfilePalette.border),
                  ),
                  child: Icon(
                    Icons.chevron_right,
                    size: 18,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusDot(Color color) {
    return Container(
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
      ),
    );
  }

  Widget _buildAvatar({
    required double radius,
    bool withBorder = false,
  }) {
    final size = radius * 2;
    final hasAvatar = avatarUrl.trim().isNotEmpty;

    Widget avatarContent = Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        color: ProfilePalette.lightGreen,
      ),
      child: hasAvatar
          ? ClipOval(
              child: Image.network(
                avatarUrl,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) {
                  return Icon(
                    Icons.person_rounded,
                    size: radius,
                    color: ProfilePalette.primaryGreen,
                  );
                },
              ),
            )
          : Icon(
              Icons.person_rounded,
              size: radius,
              color: ProfilePalette.primaryGreen,
            ),
    );

    if (!withBorder) return avatarContent;

    return Container(
      padding: const EdgeInsets.all(2),
      decoration: const BoxDecoration(
        gradient: ProfilePalette.greenGradient,
        shape: BoxShape.circle,
      ),
      child: Container(
        padding: const EdgeInsets.all(2),
        decoration: const BoxDecoration(
          color: Colors.white,
          shape: BoxShape.circle,
        ),
        child: avatarContent,
      ),
    );
  }

  Widget _buildClubBanner() {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            ProfilePalette.primaryGreen,
            ProfilePalette.primaryGreen.withOpacity(0.72),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(0.16),
              borderRadius: BorderRadius.circular(14),
            ),
            child: const Icon(Icons.shield_outlined, color: Colors.white),
          ),
          const SizedBox(width: 12),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Режим клуба",
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "Управление командами, тренерами, расписанием и аналитикой.",
                  style: TextStyle(
                    color: Color(0xEFFFFFFF),
                    fontSize: 12,
                    height: 1.25,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(
              "CLUB",
              style: TextStyle(
                color: ProfilePalette.primaryGreen,
                fontWeight: FontWeight.w900,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title.toUpperCase(),
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        color: ProfilePalette.textMuted,
        letterSpacing: 1.15,
      ),
    );
  }

  Widget _metaChip(IconData icon, String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: ProfilePalette.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: ProfilePalette.border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            icon,
            size: 14,
            color: ProfilePalette.primaryGreen,
          ),
          const SizedBox(width: 6),
          Flexible(
            child: Text(
              text,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontWeight: FontWeight.w800,
                fontSize: 12,
                color: ProfilePalette.textMuted,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWhitePanel({
    required String title,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: ProfilePalette.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: ProfilePalette.border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 16,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildSectionTitle(title),
          const SizedBox(height: 10),
          ...children,
        ],
      ),
    );
  }

  String _roleLabelRu(String role) {
    final r = role.trim().toLowerCase();

    switch (r) {
      case 'player':
        return 'Игрок';
      case 'coach':
      case 'trainer':
        return 'Тренер';
      case 'club':
        return 'Клуб';
      case 'parent':
        return 'Родитель';
      case 'federation':
        return 'Федерация';
      case 'school':
        return 'Школа';
      case 'student':
        return 'Ученик';
      default:
        return role.isEmpty ? 'Пользователь' : role;
    }
  }

  Widget _buildTabletSections(
    BuildContext context,
    List<Map<String, dynamic>> activities,
  ) {
    final leftChildren = <Widget>[];
    final rightChildren = <Widget>[];

    if (activities.isNotEmpty) {
      leftChildren.add(
        _buildWhitePanel(
          title: isClub ? "Панель клуба" : "Мои активности",
          children: activities
              .map((e) => _buildActivityTile(context, e, compact: true))
              .toList(),
        ),
      );
    }

    leftChildren.add(
      _buildWhitePanel(
        title: "Настройки",
        children: List.generate(
          3,
          (index) => _buildSettingsItem(context, index, compact: true),
        ),
      ),
    );

    rightChildren.add(
      _buildWhitePanel(
        title: "Юридическая информация",
        children: List.generate(
          3,
          (index) => _buildLegalItem(context, index, compact: true),
        ),
      ),
    );

    rightChildren.add(_buildDeleteCard(context));

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: Column(
            children: [
              ...leftChildren.expand((e) => [e, const SizedBox(height: 14)]),
            ],
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            children: [
              ...rightChildren.expand((e) => [e, const SizedBox(height: 14)]),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMobileSections(
    BuildContext context,
    List<Map<String, dynamic>> activities,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (activities.isNotEmpty) ...[
          _buildSectionTitle(isClub ? "Панель клуба" : "Мои активности"),
          const SizedBox(height: 8),
          ...activities.map((e) => _buildActivityTile(context, e)),
          const SizedBox(height: 18),
        ],
        _buildSectionTitle("Настройки"),
        const SizedBox(height: 8),
        ...List.generate(3, (index) => _buildSettingsItem(context, index)),
        const SizedBox(height: 18),
        _buildSectionTitle("Юридическая информация"),
        const SizedBox(height: 8),
        ...List.generate(3, (index) => _buildLegalItem(context, index)),
        const SizedBox(height: 18),
        _buildDeleteCard(context),
      ],
    );
  }

  List<Map<String, dynamic>> _menuBanners(BuildContext context) {
    if (isClub) {
      return [
        {
          "title": "Панель клуба",
          "icon": Icons.dashboard_outlined,
          "color": ProfilePalette.lightGreen,
          "iconColor": ProfilePalette.primaryGreen,
          "onTap": () => Get.toNamed(AppRoutes.clubDashboardScreen),
        },
        {
          "title": "Мои посты",
          "icon": Icons.article_outlined,
          "color": const Color(0xFFE8F2FF),
          "iconColor": const Color(0xFF0066CC),
          "onTap": () => Get.toNamed(AppRoutes.myProfileScreen),
        },
        {
          "title": "Мои площадки",
          "icon": Icons.stadium_outlined,
          "color": const Color(0xFFE8F5FF),
          "iconColor": const Color(0xFF007AFF),
          "onTap": () => Get.toNamed(AppRoutes.myGroundsScreen),
        },
        {
          "title": "Бронирования",
          "icon": Icons.book_online_outlined,
          "color": const Color(0xFFE8F8E8),
          "iconColor": ProfilePalette.primaryGreen,
          "onTap": () => Get.to(() => const BookingsForMyVenuesScreen()),
        },
      ];
    }

    return [
      {
        "title": "Мои посты",
        "icon": Icons.article_outlined,
        "color": const Color(0xFFE8F2FF),
        "iconColor": const Color(0xFF0066CC),
        "onTap": () => Get.toNamed(AppRoutes.myProfileScreen),
      },
      {
        "title": "Мои площадки",
        "icon": Icons.stadium_outlined,
        "color": const Color(0xFFE8F5FF),
        "iconColor": const Color(0xFF007AFF),
        "onTap": () => Get.toNamed(AppRoutes.myGroundsScreen),
      },
      {
        "title": "Бронирования",
        "icon": Icons.calendar_today_outlined,
        "color": const Color(0xFFE8F8E8),
        "iconColor": ProfilePalette.primaryGreen,
        "onTap": () => Get.toNamed('/myBookingsScreen'),
      },
      {
        "title": "Тренировки",
        "icon": Icons.directions_run_outlined,
        "color": const Color(0xFFFFF4E6),
        "iconColor": const Color(0xFFFF9500),
        "onTap": () => Get.to(() => const MyTrainingsScreen()),
      },
      {
        "title": "Достижения",
        "icon": Icons.emoji_events_outlined,
        "color": const Color(0xFFF3E8FF),
        "iconColor": const Color(0xFF7E3AED),
        "onTap": () => Get.to(() => const AchievementsScreen()),
      },
      {
        "title": "AR Тренировки",
        "icon": Icons.auto_awesome_outlined,
        "color": const Color(0xFFFFF9E6),
        "iconColor": const Color(0xFFFFCC00),
        "onTap": () => Get.to(() => const InnovationHistoryScreen()),
      },
    ];
  }

  Widget _buildMenuBanner(BuildContext context, Map<String, dynamic> item) {
    return Material(
      color: item['color'],
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: item['onTap'],
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 10,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.04),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Icon(
                    item['icon'],
                    size: 22,
                    color: item['iconColor'],
                  ),
                ),
                const Spacer(),
                Text(
                  item['title'],
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    color: Colors.black,
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Map<String, dynamic>> _activitiesForRole(BuildContext context) {
    if (isClub) return [];

    final items = <Map<String, dynamic>>[
      {
        "title": "Бронирования площадок",
        "icon": Icons.book_online_outlined,
        "color": const Color(0xFFE8F5FF),
        "onTap": () => Get.to(() => const BookingsForMyVenuesScreen()),
      },
    ];

    if (isCoach) {
      if (myTeamLoading) {
        items.add({
          "title": "Моя команда (загрузка...)",
          "icon": Icons.hourglass_top_rounded,
          "color": Colors.grey.shade100,
          "onTap": () {},
        });
      } else {
        items.add({
          "title": "Моя команда",
          "icon": Icons.group_outlined,
          "color": const Color(0xFFE8F9F5),
          "onTap": () => Get.toNamed(
                "/myTeamScreen",
                arguments: {
                  "team_id": myTeamId,
                  "mode": "coach_my",
                },
              ),
        });

        if (myTeamId == 0) {
          items.add({
            "title": "Создать команду",
            "icon": Icons.add_circle_outlined,
            "color": const Color(0xFFE6F7FF),
            "onTap": () => Get.toNamed(AppRoutes.createTeamScreen),
          });
        }
      }

      final showAssigned = assignedTeamId > 0 && assignedTeamId != myTeamId;

      if (assignedTeamLoading) {
        items.add({
          "title": "Команда клуба (загрузка...)",
          "icon": Icons.hourglass_top_rounded,
          "color": Colors.grey.shade100,
          "onTap": () {},
        });
      } else if (showAssigned) {
        items.add({
          "title": "Команда клуба",
          "icon": Icons.shield_outlined,
          "color": const Color(0xFFF0F2FF),
          "onTap": () => Get.toNamed(
                "/myTeamScreen",
                arguments: {
                  "team_id": assignedTeamId,
                  "mode": "club_assigned",
                },
              ),
        });
      }
    } else {
      items.addAll([
        {
          "title": "Моя команда",
          "icon": Icons.group_outlined,
          "color": const Color(0xFFE8F9F5),
          "onTap": () => Get.toNamed("/myTeamScreen"),
        },
        {
          "title": "Создать команду",
          "icon": Icons.add_circle_outlined,
          "color": const Color(0xFFE6F7FF),
          "onTap": () => Get.toNamed(AppRoutes.createTeamScreen),
        },
      ]);
    }

    items.add({
      "title": "Добавить игрока",
      "icon": Icons.person_add_alt_outlined,
      "color": const Color(0xFFF0F2FF),
      "onTap": () => Get.toNamed(AppRoutes.addPlayerScreen),
    });

    return items;
  }

  Widget _buildActivityTile(
    BuildContext context,
    Map<String, dynamic> item, {
    bool compact = false,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: item['color'],
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ProfilePalette.border),
      ),
      child: ListTile(
        dense: compact,
        minVerticalPadding: compact ? 6 : 8,
        onTap: item['onTap'],
        leading: Container(
          width: compact ? 40 : 42,
          height: compact ? 40 : 42,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            item['icon'],
            size: 20,
            color: ProfilePalette.primaryGreen,
          ),
        ),
        title: Text(
          item['title'],
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: Colors.black,
          ),
        ),
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: ProfilePalette.border),
          ),
          child: Icon(
            Icons.chevron_right,
            size: 18,
            color: Colors.grey.shade600,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  Widget _buildSettingsItem(
    BuildContext context,
    int index, {
    bool compact = false,
  }) {
    final List<Map<String, dynamic>> settings = [
      {
        "title": "Редактировать профиль",
        "icon": Icons.edit_outlined,
        "color": Colors.white,
        "onTap": () =>
            Get.toNamed(AppRoutes.myProfileScreen)?.then((_) => _loadUserData()),
      },
      {
        "title": "Настройки приложения",
        "icon": Icons.settings_outlined,
        "color": Colors.white,
        "onTap": () => Get.toNamed(AppRoutes.settingsScreen),
      },
      {
        "title": "Мои подписки",
        "icon": Icons.subscriptions_outlined,
        "color": Colors.white,
        "onTap": () => Get.toNamed(AppRoutes.subscriptionsScreen),
      },
    ];

    final item = settings[index];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: item['color'],
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ProfilePalette.border),
      ),
      child: ListTile(
        dense: compact,
        minVerticalPadding: compact ? 6 : 8,
        onTap: item['onTap'],
        leading: Container(
          width: compact ? 40 : 42,
          height: compact ? 40 : 42,
          decoration: BoxDecoration(
            color: ProfilePalette.lightGreen,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            item['icon'],
            size: 20,
            color: ProfilePalette.primaryGreen,
          ),
        ),
        title: Text(
          item['title'],
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: Colors.black,
          ),
        ),
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: ProfilePalette.border),
          ),
          child: Icon(
            Icons.chevron_right,
            size: 18,
            color: Colors.grey.shade600,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
    );
  }

  Widget _buildLegalItem(
    BuildContext context,
    int index, {
    bool compact = false,
  }) {
    final items = [
      {
        "title": "Условия использования (EULA)",
        "icon": Icons.description_outlined,
        "onTap": () => _openUrl(termsUrl),
      },
      {
        "title": "Политика конфиденциальности",
        "icon": Icons.privacy_tip_outlined,
        "onTap": () => _openUrl(privacyUrl),
      },
      {
        "title": "Правила сообщества (нулевая терпимость)",
        "icon": Icons.shield_outlined,
        "onTap": () => _openUrl(rulesUrl),
      },
    ];

    final item = items[index];
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: ProfilePalette.border),
      ),
      child: ListTile(
        dense: compact,
        minVerticalPadding: compact ? 6 : 8,
        onTap: item['onTap'] as void Function()?,
        leading: Container(
          width: compact ? 40 : 42,
          height: compact ? 40 : 42,
          decoration: BoxDecoration(
            color: ProfilePalette.lightGreen,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            item['icon'] as IconData,
            size: 20,
            color: ProfilePalette.primaryGreen,
          ),
        ),
        title: Text(
          item['title'] as String,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: Colors.black,
          ),
        ),
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: ProfilePalette.border),
          ),
          child: Icon(
            Icons.chevron_right,
            size: 18,
            color: Colors.grey.shade600,
          ),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      ),
    );
  }

  Widget _buildDeleteCard(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.red.shade50,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.red.shade100),
      ),
      child: ListTile(
        onTap: () => _showDeleteAccountSheet(context),
        leading: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            Icons.delete_forever_outlined,
            size: 22,
            color: Colors.red.shade400,
          ),
        ),
        title: const Text(
          "Удалить аккаунт",
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w800,
            color: Colors.red,
          ),
        ),
        subtitle: const Text(
          "Навсегда удалить профиль и данные",
          style: TextStyle(
            fontSize: 12,
            color: Color(0xFF9CA3AF),
            fontWeight: FontWeight.w600,
          ),
        ),
        trailing: Icon(
          Icons.chevron_right,
          size: 20,
          color: Colors.red.shade300,
        ),
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: FloatingActionButton(
        onPressed: () => _showLogoutDialog(context),
        backgroundColor: Colors.transparent,
        foregroundColor: Colors.red,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        child: const Icon(Icons.logout, size: 22),
      ),
    );
  }

  void _showLogoutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          insetPadding: const EdgeInsets.all(24),
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.red.shade50,
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    Icons.logout,
                    size: 36,
                    color: Colors.red.shade400,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Выйти из аккаунта?",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w800,
                    color: Colors.black,
                  ),
                ),
                const SizedBox(height: 12),
                const Text(
                  "Вы уверены, что хотите выйти?",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.grey,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 24),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(context),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          side: const BorderSide(color: Color(0xFFE5E7EB)),
                        ),
                        child: const Text(
                          "Отмена",
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () async {
                          await _clearLocalAuth();
                          Get.offAllNamed(AppRoutes.loginScreen);
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.red.shade400,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          elevation: 0,
                        ),
                        child: const Text(
                          "Выйти",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showDeleteAccountSheet(BuildContext context) {
    bool agree = false;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateSB) {
            return Padding(
              padding: EdgeInsets.only(
                left: 20,
                right: 20,
                top: 16,
                bottom: 16 + MediaQuery.of(context).viewInsets.bottom,
              ),
              child: SafeArea(
                top: false,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 44,
                      height: 5,
                      margin: const EdgeInsets.only(bottom: 16),
                      decoration: BoxDecoration(
                        color: const Color(0xFFE5E7EB),
                        borderRadius: BorderRadius.circular(3),
                      ),
                    ),
                    Icon(
                      Icons.warning_amber_rounded,
                      size: 42,
                      color: Colors.red.shade400,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      "Удаление аккаунта",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      "Это действие необратимо. Ваш профиль, публикации и связанные данные будут удалены навсегда.",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 13,
                        color: Color(0xFF6B7280),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Checkbox(
                          value: agree,
                          onChanged: (v) =>
                              setStateSB(() => agree = v ?? false),
                          activeColor: Colors.red,
                        ),
                        const Expanded(
                          child: Padding(
                            padding: EdgeInsets.only(top: 12),
                            child: Text(
                              "Я понимаю последствия и хочу удалить аккаунт навсегда.",
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            onPressed: () => Navigator.pop(context),
                            style: OutlinedButton.styleFrom(
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              side: const BorderSide(color: Color(0xFFE5E7EB)),
                            ),
                            child: const Text("Отмена"),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: agree
                                ? () async {
                                    Navigator.pop(context);
                                    await _deleteAccount();
                                  }
                                : null,
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.red,
                              disabledBackgroundColor: Colors.red.shade200,
                              padding:
                                  const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                              elevation: 0,
                            ),
                            child: const Text(
                              "Удалить навсегда",
                              style: TextStyle(color: Colors.white),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _deleteAccount() async {
    final userId = await PrefUtils.getUserId();
    if (userId == 0) {
      Get.snackbar(
        "Ошибка",
        "Не найден идентификатор пользователя.",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
      return;
    }

    Get.snackbar(
      "Удаление...",
      "Пожалуйста, подождите",
      snackPosition: SnackPosition.BOTTOM,
      margin: const EdgeInsets.all(12),
      duration: const Duration(seconds: 2),
      isDismissible: true,
    );

    try {
      final resp = await http.post(
        Uri.parse(deleteAccountUrl),
        body: {'user_id': userId.toString()},
      );

      if (resp.statusCode == 200) {
        bool ok = false;
        String message = 'Аккаунт удалён.';
        try {
          final jsonBody = json.decode(resp.body);
          ok = jsonBody['success'] == true;
          if (jsonBody['message'] is String) {
            message = jsonBody['message'];
          }
        } catch (_) {
          ok = true;
        }

        if (ok) {
          await _clearLocalAuth();
          Get.snackbar(
            "Готово",
            message,
            snackPosition: SnackPosition.BOTTOM,
            margin: const EdgeInsets.all(12),
            duration: const Duration(seconds: 3),
          );
          Get.offAllNamed(AppRoutes.loginScreen);
        } else {
          Get.snackbar(
            "Ошибка",
            message,
            snackPosition: SnackPosition.BOTTOM,
            margin: const EdgeInsets.all(12),
          );
        }
      } else {
        Get.snackbar(
          "Ошибка",
          "Сервер вернул статус ${resp.statusCode}.",
          snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(12),
        );
      }
    } catch (_) {
      Get.snackbar(
        "Сеть недоступна",
        "Не удалось связаться с сервером. Повторите позже.",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
    }
  }

  Future<void> _clearLocalAuth() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(PrefUtils.userIdKey);
    await prefs.remove(PrefUtils.teamIdKey);

    await prefs.remove(PrefUtils.userRole);
    await prefs.remove(PrefUtils.userFirstName);
    await prefs.remove(PrefUtils.userLastName);
    await prefs.remove(PrefUtils.userEmail);
    await prefs.remove(PrefUtils.signIn);
  }
}