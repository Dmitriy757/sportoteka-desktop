import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_analytics_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_tracking_controller.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/utils/formatters.dart';

class AiAnalyticsPanelWidget extends StatefulWidget {
  final AiTrackingController aiTracking;
  final bool showHeatmap;
  final String statusText;

  final VoidCallback onToggleAi;
  final ValueChanged<bool> onToggleHeatmap;
  final VoidCallback onBindTrack;
  final ValueChanged<int> onJumpToTime;
  final VoidCallback onExport;
  final ValueChanged<AiTtdSuggestion> onConfirmSuggestion;

  const AiAnalyticsPanelWidget({
    super.key,
    required this.aiTracking,
    required this.showHeatmap,
    required this.statusText,
    required this.onToggleAi,
    required this.onToggleHeatmap,
    required this.onBindTrack,
    required this.onJumpToTime,
    required this.onExport,
    required this.onConfirmSuggestion,
  });

  @override
  State<AiAnalyticsPanelWidget> createState() => _AiAnalyticsPanelWidgetState();
}

class _AiAnalyticsPanelWidgetState extends State<AiAnalyticsPanelWidget>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 5, vsync: this);
  }

  @override
  Widget build(BuildContext context) {
    final track = widget.aiTracking.lockedTrack;
    final stats = _buildStats(track);
    final playerName = track?.boundPlayerName ?? 'Игрок не выбран';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildTopSummary(
          playerName: playerName,
          track: track,
          stats: stats,
        ),
        const SizedBox(height: 12),
        _buildControlsRow(),
        const SizedBox(height: 12),
        Container(
          height: 42,
          decoration: BoxDecoration(
            color: const Color(0xFFF8FAFC),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE2E8F0)),
          ),
          child: TabBar(
            controller: _tabController,
            labelColor: const Color(0xFF0F172A),
            unselectedLabelColor: const Color(0xFF64748B),
            labelStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
            unselectedLabelStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
            indicator: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 8,
                  offset: const Offset(0, 3),
                ),
              ],
            ),
            tabs: const [
              Tab(text: 'Обзор'),
              Tab(text: 'События'),
              Tab(text: 'ТТД'),
              Tab(text: 'Карта'),
              Tab(text: 'Экспорт'),
            ],
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 560,
          child: TabBarView(
            controller: _tabController,
            children: [
              _buildOverviewTab(stats, track),
              _buildEventsTab(),
              _buildTtdTab(),
              _buildMapTab(),
              _buildExportTab(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTopSummary({
    required String playerName,
    required PlayerTrack? track,
    required _AiLiveStats stats,
  }) {
    final isLocked = widget.aiTracking.isLocked;
    final statusColor =
        isLocked ? const Color(0xFF16A34A) : const Color(0xFFF59E0B);

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFF7C3AED).withOpacity(0.10),
            const Color(0xFF2563EB).withOpacity(0.08),
          ],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: const Color(0xFF7C3AED).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Icon(
                  Icons.psychology_alt_rounded,
                  color: Color(0xFF7C3AED),
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'ИИ-анализ матча',
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF0F172A),
                      ),
                    ),
                    SizedBox(height: 2),
                    Text(
                      'Автоматическое отслеживание и подсказки по ТТД',
                      style: TextStyle(
                        fontSize: 12,
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(
                  isLocked ? 'Игрок захвачен' : 'Ожидание выбора',
                  style: TextStyle(
                    color: statusColor,
                    fontWeight: FontWeight.w800,
                    fontSize: 11,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(
                child: _summaryTile(
                  'Игрок',
                  playerName,
                  Icons.person_outline_rounded,
                  const Color(0xFF2563EB),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _summaryTile(
                  'Статус',
                  widget.statusText.isEmpty ? '—' : widget.statusText,
                  Icons.sensors_rounded,
                  const Color(0xFF7C3AED),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _miniStat(
                    'Скорость', '${stats.currentSpeed.toStringAsFixed(1)} км/ч'),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _miniStat(
                    'Дистанция', '${stats.totalDistance.toStringAsFixed(1)} м'),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _miniStat('Рывки', '${stats.sprints}'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildControlsRow() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        _actionChip(
          icon: widget.aiTracking.isRunning
              ? Icons.pause_circle_outline_rounded
              : Icons.play_circle_outline_rounded,
          label: widget.aiTracking.isRunning ? 'Остановить ИИ' : 'Запустить ИИ',
          color: const Color(0xFF16A34A),
          onTap: widget.onToggleAi,
        ),
        _actionChip(
          icon: Icons.link_rounded,
          label: 'Привязать к игроку',
          color: const Color(0xFF2563EB),
          onTap: widget.onBindTrack,
        ),
        _actionChip(
          icon: widget.showHeatmap
              ? Icons.local_fire_department_rounded
              : Icons.heat_pump_rounded,
          label: widget.showHeatmap
              ? 'Скрыть тепловую карту'
              : 'Показать тепловую карту',
          color: const Color(0xFFDC2626),
          onTap: () => widget.onToggleHeatmap(!widget.showHeatmap),
        ),
        _actionChip(
          icon: Icons.upload_file_rounded,
          label: 'Экспорт',
          color: const Color(0xFF7C3AED),
          onTap: widget.onExport,
        ),
      ],
    );
  }

  Widget _buildOverviewTab(_AiLiveStats stats, PlayerTrack? track) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _metricCard(
                  title: 'Текущая скорость',
                  value: '${stats.currentSpeed.toStringAsFixed(1)} км/ч',
                  subtitle: 'В данный момент',
                  icon: Icons.speed_rounded,
                  color: const Color(0xFF2563EB),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _metricCard(
                  title: 'Максимальная скорость',
                  value:
                      '${widget.aiTracking.maxSpeedKmh.toStringAsFixed(1)} км/ч',
                  subtitle: 'За текущий трек',
                  icon: Icons.rocket_launch_rounded,
                  color: const Color(0xFFF59E0B),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _metricCard(
                  title: 'Ускорение',
                  value:
                      '${stats.currentAcceleration.toStringAsFixed(1)}',
                  subtitle: 'Текущий импульс',
                  icon: Icons.trending_up_rounded,
                  color: const Color(0xFF16A34A),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _metricCard(
                  title: 'Пройденная дистанция',
                  value:
                      '${widget.aiTracking.totalDistanceMeters.toStringAsFixed(1)} м',
                  subtitle: 'По текущему треку',
                  icon: Icons.route_rounded,
                  color: const Color(0xFF7C3AED),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          _sectionCard(
            title: 'Живая аналитика',
            icon: Icons.analytics_outlined,
            color: const Color(0xFF0F172A),
            child: Column(
              children: [
                _infoRow('Средняя скорость',
                    '${widget.aiTracking.averageSpeedKmh.toStringAsFixed(1)} км/ч'),
                _infoRow('Максимальная скорость',
                    '${widget.aiTracking.maxSpeedKmh.toStringAsFixed(1)} км/ч'),
                _infoRow('Количество точек трека', '${track?.points.length ?? 0}'),
                _infoRow('Количество рывков', '${widget.aiTracking.sprintCount}'),
                _infoRow('Смены направления',
                    '${widget.aiTracking.directionChangeCount}'),
                _infoRow('Резкие ускорения',
                    '${widget.aiTracking.accelerationBurstCount}'),
                _infoRow(
                  'Последняя отметка',
                  track == null
                      ? '—'
                      : Formatters.formatDuration(
                          Duration(milliseconds: track.lastSeenTimeMs),
                        ),
                ),
                _infoRow('Показ траектории',
                    widget.aiTracking.showTrails ? 'Да' : 'Нет'),
                _infoRow('Показ рамок',
                    widget.aiTracking.showBoundingBoxes ? 'Да' : 'Нет'),
                _infoRow('Показ скорости',
                    widget.aiTracking.showSpeed ? 'Да' : 'Нет'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventsTab() {
    final events = widget.aiTracking.autoEvents;

    return SingleChildScrollView(
      child: Column(
        children: [
          _sectionCard(
            title: 'Автоматически найденные события',
            icon: Icons.timeline_rounded,
            color: const Color(0xFF2563EB),
            child: events.isEmpty
                ? const Padding(
                    padding: EdgeInsets.symmetric(vertical: 8),
                    child: Text(
                      'Пока нет событий. Запусти ИИ и выбери игрока.',
                      style: TextStyle(
                        color: Color(0xFF64748B),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  )
                : Column(
                    children: events.map((e) => _eventTile(e)).toList(),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildTtdTab() {
    final suggestions = widget.aiTracking.ttdSuggestions;

    final main = suggestions
        .where((e) => e.section == 'Основные действия')
        .toList();

    final passes = suggestions
        .where((e) => e.section == 'Передачи')
        .toList();

    final gk = suggestions
        .where((e) => e.section == 'Вратарские действия')
        .toList();

    return SingleChildScrollView(
      child: Column(
        children: [
          _ttdSection(
            title: 'Основные действия',
            color: const Color(0xFF2563EB),
            items: main,
            presets: const [
              'Финт / дриблинг',
              'Удары',
              'Отбор',
              'Перехват',
              'Подбор',
              'Игра головой',
              'Ауты',
              'Пас АВП',
            ],
          ),
          const SizedBox(height: 12),
          _ttdSection(
            title: 'Передачи',
            color: const Color(0xFF7C3AED),
            items: passes,
            presets: const [
              'Передача вперед короткая',
              'Передача вперед средняя',
              'Передача вперед длинная',
              'Передача поперек короткая',
              'Передача поперек средняя',
              'Передача поперек длинная',
              'Передача назад короткая',
              'Передача назад средняя',
              'Передача назад длинная',
            ],
          ),
          const SizedBox(height: 12),
          _ttdSection(
            title: 'Вратарские действия',
            color: const Color(0xFFDC2626),
            items: gk,
            presets: const [
              'Сейв',
              'Выход',
              'Ввод рукой',
              'Ближний бой',
              'Перехват',
              'За пределами штрафной',
              'Пас короткий',
              'Пас средний',
              'Пас длинный',
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMapTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _sectionCard(
            title: 'Режимы отображения',
            icon: Icons.map_outlined,
            color: const Color(0xFF16A34A),
            child: Column(
              children: [
                _switchRow(
                  title: 'Показывать траекторию',
                  value: widget.aiTracking.showTrails,
                  onChanged: (_) {
                    setState(() {
                      widget.aiTracking.showTrails =
                          !widget.aiTracking.showTrails;
                    });
                    widget.aiTracking.notifyListeners();
                  },
                ),
                _switchRow(
                  title: 'Показывать подписи',
                  value: widget.aiTracking.showLabels,
                  onChanged: (_) {
                    setState(() {
                      widget.aiTracking.showLabels =
                          !widget.aiTracking.showLabels;
                    });
                    widget.aiTracking.notifyListeners();
                  },
                ),
                _switchRow(
                  title: 'Показывать скорость',
                  value: widget.aiTracking.showSpeed,
                  onChanged: (_) {
                    setState(() {
                      widget.aiTracking.showSpeed =
                          !widget.aiTracking.showSpeed;
                    });
                    widget.aiTracking.notifyListeners();
                  },
                ),
                _switchRow(
                  title: 'Показывать рамки',
                  value: widget.aiTracking.showBoundingBoxes,
                  onChanged: (_) {
                    setState(() {
                      widget.aiTracking.showBoundingBoxes =
                          !widget.aiTracking.showBoundingBoxes;
                    });
                    widget.aiTracking.notifyListeners();
                  },
                ),
                _switchRow(
                  title: 'Показывать только выбранного',
                  value: widget.aiTracking.showOnlySelectedPlayer,
                  onChanged: (_) {
                    setState(() {
                      widget.aiTracking.showOnlySelectedPlayer =
                          !widget.aiTracking.showOnlySelectedPlayer;
                    });
                    widget.aiTracking.notifyListeners();
                  },
                ),
                _switchRow(
                  title: 'Тепловая карта',
                  value: widget.showHeatmap,
                  onChanged: (v) => widget.onToggleHeatmap(v),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          _sectionCard(
            title: 'Подсказки по карте действий',
            icon: Icons.local_fire_department_outlined,
            color: const Color(0xFFF59E0B),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: const [
                _StaticHint(
                    'Используй тепловую карту для анализа активности по зонам.'),
                _StaticHint(
                    'Сопоставляй рывки с эпизодами обострения.'),
                _StaticHint(
                    'Сравнивай траекторию с ручными ТТД в конкретном эпизоде.'),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildExportTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          _sectionCard(
            title: 'Экспорт и сохранение',
            icon: Icons.upload_file_rounded,
            color: const Color(0xFF7C3AED),
            child: Column(
              children: [
                _exportItem(
                  title: 'Экспорт AI-анализа',
                  subtitle: 'Сохранить текущий трек и аналитику',
                  icon: Icons.analytics_rounded,
                  onTap: widget.onExport,
                ),
                _exportItem(
                  title: 'Экспорт подтвержденных ТТД',
                  subtitle: 'Передать подтвержденные действия в отчет',
                  icon: Icons.fact_check_outlined,
                  onTap: widget.onExport,
                ),
                _exportItem(
                  title: 'Отчет по игроку',
                  subtitle:
                      'Сформировать отдельную аналитику по выбранному игроку',
                  icon: Icons.person_search_rounded,
                  onTap: widget.onExport,
                ),
                _exportItem(
                  title: 'Отчет по матчу',
                  subtitle: 'Сохранить AI-события вместе с метриками',
                  icon: Icons.summarize_outlined,
                  onTap: widget.onExport,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _ttdSection({
    required String title,
    required Color color,
    required List<AiTtdSuggestion> items,
    required List<String> presets,
  }) {
    return _sectionCard(
      title: title,
      icon: Icons.sports_soccer_rounded,
      color: color,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (items.isNotEmpty) ...[
            ...items.map((e) => _ttdSuggestionTile(e)),
            const SizedBox(height: 12),
          ],
          Text(
            'Быстрое подтверждение',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: color,
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: presets.map((e) {
              return _presetChip(
                label: e,
                color: color,
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _ttdSuggestionTile(AiTtdSuggestion item) {
    final timeText = Formatters.formatDuration(
      Duration(milliseconds: item.timeMs),
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  item.title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Text(
                timeText,
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF64748B),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              _pill(
                item.success ? 'Успешно' : 'Неуспешно',
                item.success
                    ? const Color(0xFF16A34A)
                    : const Color(0xFFDC2626),
              ),
              const SizedBox(width: 8),
              _pill(
                'Уверенность ${(item.confidence * 100).round()}%',
                const Color(0xFF2563EB),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _miniButton(
                  label: 'Перейти',
                  icon: Icons.play_arrow_rounded,
                  color: const Color(0xFF2563EB),
                  onTap: () => widget.onJumpToTime(item.timeMs),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _miniButton(
                  label: 'Подтвердить',
                  icon: Icons.check_circle_outline_rounded,
                  color: const Color(0xFF16A34A),
                  onTap: () => widget.onConfirmSuggestion(item),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _eventTile(AiDetectedEvent item) {
    final timeText = Formatters.formatDuration(
      Duration(milliseconds: item.timeMs),
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: item.color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(item.icon, color: item.color),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  item.subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Уверенность ${(item.confidence * 100).round()}%',
                  style: TextStyle(
                    fontSize: 11,
                    color: item.color,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              Text(
                timeText,
                style: const TextStyle(
                  fontSize: 11,
                  color: Color(0xFF64748B),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 6),
              IconButton(
                onPressed: () => widget.onJumpToTime(item.timeMs),
                icon: const Icon(Icons.play_circle_outline_rounded),
                color: const Color(0xFF2563EB),
                tooltip: 'Перейти к моменту',
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _sectionCard({
    required String title,
    required IconData icon,
    required Color color,
    required Widget child,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 20),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF0F172A),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _metricCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [color.withOpacity(0.10), color.withOpacity(0.05)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 20),
          const SizedBox(height: 10),
          Text(
            title,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w900,
              color: Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: const TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: Color(0xFF64748B),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryTile(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.75),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 11,
                    color: Color(0xFF64748B),
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF0F172A),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _miniStat(String title, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              color: Color(0xFF64748B),
              fontWeight: FontWeight.w700,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              color: Color(0xFF0F172A),
              fontWeight: FontWeight.w900,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _actionChip({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(999),
        child: Ink(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(
            color: color.withOpacity(0.10),
            borderRadius: BorderRadius.circular(999),
            border: Border.all(color: color.withOpacity(0.22)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _miniButton({
    required String label,
    required IconData icon,
    required Color color,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      height: 36,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 15),
        label: Text(label),
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: color.withOpacity(0.10),
          foregroundColor: color,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: color.withOpacity(0.20)),
          ),
          textStyle: const TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w800,
          ),
        ),
      ),
    );
  }

  Widget _presetChip({
    required String label,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.18)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: color,
        ),
      ),
    );
  }

  Widget _pill(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }

  Widget _switchRow({
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xFF0F172A),
              ),
            ),
          ),
          Switch.adaptive(
            value: value,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }

  Widget _exportItem({
    required String title,
    required String subtitle,
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        onTap: onTap,
        tileColor: const Color(0xFFF8FAFC),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        leading: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
            color: const Color(0xFF7C3AED).withOpacity(0.10),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: const Color(0xFF7C3AED)),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
            color: Color(0xFF0F172A),
          ),
        ),
        subtitle: Text(
          subtitle,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w600,
            color: Color(0xFF64748B),
          ),
        ),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }

  Widget _infoRow(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                color: Color(0xFF64748B),
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            value,
            style: const TextStyle(
              fontSize: 12,
              color: Color(0xFF0F172A),
              fontWeight: FontWeight.w800,
            ),
          ),
        ],
      ),
    );
  }

  _AiLiveStats _buildStats(PlayerTrack? track) {
    if (track == null || track.points.isEmpty) {
      return const _AiLiveStats.empty();
    }

    final points = track.points;
    final currentSpeed = points.last.speed;

    double maxSpeed = 0;
    double sumSpeed = 0;
    double totalDistance = 0;
    int sprints = 0;
    bool sprintOpen = false;

    for (var i = 0; i < points.length; i++) {
      final p = points[i];
      maxSpeed = p.speed > maxSpeed ? p.speed : maxSpeed;
      sumSpeed += p.speed;

      if (p.speed >= 24.0 && !sprintOpen) {
        sprintOpen = true;
        sprints++;
      } else if (p.speed < 20.0) {
        sprintOpen = false;
      }

      if (i > 0) {
        final prev = points[i - 1].position;
        final dx = p.position.dx - prev.dx;
        final dy = p.position.dy - prev.dy;
        totalDistance += math.sqrt(dx * dx + dy * dy) * 0.12;
      }
    }

    final double avgSpeed =
    points.isEmpty ? 0.0 : (sumSpeed / points.length).toDouble();
        final last = points.last;
    final currentAcceleration = math.sqrt(last.ax * last.ax + last.ay * last.ay);

    return _AiLiveStats(
      currentSpeed: currentSpeed,
      avgSpeed: avgSpeed,
      maxSpeed: maxSpeed,
      totalDistance: totalDistance,
      sprints: sprints,
      currentAcceleration: currentAcceleration,
    );
  }
}

class _AiLiveStats {
  final double currentSpeed;
  final double avgSpeed;
  final double maxSpeed;
  final double totalDistance;
  final int sprints;
  final double currentAcceleration;

  const _AiLiveStats({
    required this.currentSpeed,
    required this.avgSpeed,
    required this.maxSpeed,
    required this.totalDistance,
    required this.sprints,
    required this.currentAcceleration,
  });

  const _AiLiveStats.empty()
      : currentSpeed = 0,
        avgSpeed = 0,
        maxSpeed = 0,
        totalDistance = 0,
        sprints = 0,
        currentAcceleration = 0;
}

class _StaticHint extends StatelessWidget {
  final String text;

  const _StaticHint(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Padding(
            padding: EdgeInsets.only(top: 3),
            child: Icon(
              Icons.circle,
              size: 8,
              color: Color(0xFF64748B),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w600,
                color: Color(0xFF334155),
              ),
            ),
          ),
        ],
      ),
    );
  }
}