class ApiConstants {
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getPlayersUrl = "$apiBase/get_players_by_team.php";
  static const String addEventUrl = "$apiBase/add_video_event.php";
  static const String getEventsUrl = "$apiBase/get_video_events_by_match.php";
  static const String deleteEventUrl = "$apiBase/delete_video_event.php";
  static const String getMatchTtdReportUrl = "$apiBase/get_match_ttd_report.php";
  static const String updateEventUrl = "$apiBase/update_video_event.php";
  static const String getPlayerTtdEventsUrl = "$apiBase/get_player_ttd_events.php";

  // Python AI service via nginx
  static const String pythonBaseUrl = 'https://sportotekaapp.ru/ai';
}