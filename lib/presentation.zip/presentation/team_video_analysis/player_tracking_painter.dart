import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracked_player_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class PlayerTrackingPainter extends CustomPainter {
  final List<TrackedPlayer> trackedPlayers;
  final String? selectedTrackId;
  final bool showTrails;
  final bool showLabels;
  final bool showSpeed;
  final bool showBoundingBoxes;
  final bool showOnlySelectedPlayer;

  const PlayerTrackingPainter({
    required this.trackedPlayers,
    this.selectedTrackId,
    this.showTrails = true,
    this.showLabels = true,
    this.showSpeed = false,
    this.showBoundingBoxes = true,
    this.showOnlySelectedPlayer = false,
  });

  @override
  void paint(Canvas canvas, Size size) {
    if (trackedPlayers.isEmpty) return;

    final playersToDraw = showOnlySelectedPlayer && selectedTrackId != null
        ? trackedPlayers.where((p) => p.id.toString() == selectedTrackId).toList()
        : trackedPlayers;

    if (showTrails) {
      for (final player in playersToDraw) {
        _drawTrail(canvas, player);
      }
    }

    if (showBoundingBoxes) {
      for (final player in playersToDraw) {
        _drawBoundingBox(canvas, player);
      }
    }

    for (final player in playersToDraw) {
      _drawPlayerMarker(canvas, player);
    }

    if (showLabels) {
      for (final player in playersToDraw) {
        _drawLabel(canvas, player);
      }
    }
  }

  void _drawTrail(Canvas canvas, TrackedPlayer player) {
    if (player.trail.length < 2) return;

    for (int i = 0; i < player.trail.length - 1; i++) {
      final progress = (i + 1) / player.trail.length;
      final trailPaint = Paint()
        ..color = player.color.withOpacity(0.15 + progress * 0.35)
        ..strokeWidth = 1.5 + progress * 2.0
        ..strokeCap = StrokeCap.round
        ..style = PaintingStyle.stroke;

      canvas.drawLine(
        player.trail[i],
        player.trail[i + 1],
        trailPaint,
      );
    }
  }

  void _drawBoundingBox(Canvas canvas, TrackedPlayer player) {
    final rect = player.boundingBox;
    if (rect == null) return;

    final isSelected = player.id.toString() == selectedTrackId;

    final boxPaint = Paint()
      ..color = isSelected ? Colors.white : player.color
      ..strokeWidth = isSelected ? 3.5 : 2.2
      ..style = PaintingStyle.stroke;

    final glowPaint = Paint()
      ..color = player.color.withOpacity(0.18)
      ..strokeWidth = isSelected ? 8 : 6
      ..style = PaintingStyle.stroke;

    canvas.drawRect(rect, glowPaint);
    canvas.drawRect(rect, boxPaint);

    final centerPaint = Paint()
      ..color = isSelected ? Colors.white : player.color
      ..style = PaintingStyle.fill;

    canvas.drawCircle(player.position, isSelected ? 4.5 : 3.5, centerPaint);
  }

  void _drawPlayerMarker(Canvas canvas, TrackedPlayer player) {
    final isSelected = player.id.toString() == selectedTrackId;

    final markerFillPaint = Paint()
      ..color = isSelected ? Colors.white : player.color
      ..style = PaintingStyle.fill;

    final markerStrokePaint = Paint()
      ..color = player.color
      ..strokeWidth = isSelected ? 4 : 2
      ..style = PaintingStyle.stroke;

    final center = player.position;
    final radius = isSelected ? 12.0 : 8.0;

    switch (player.markerType) {
      case PlayerMarkerType.box:
        canvas.drawRect(
          Rect.fromCenter(center: center, width: radius * 2, height: radius * 2),
          markerStrokePaint,
        );
        if (isSelected) {
          canvas.drawRect(
            Rect.fromCenter(center: center, width: radius * 1.5, height: radius * 1.5),
            markerFillPaint,
          );
        }
        break;
      case PlayerMarkerType.circle:
        canvas.drawCircle(center, radius, markerStrokePaint);
        if (isSelected) {
          canvas.drawCircle(center, radius * 0.7, markerFillPaint);
        }
        break;
      case PlayerMarkerType.triangle:
        _drawTriangle(canvas, center, radius, markerStrokePaint);
        if (isSelected) {
          _drawTriangle(canvas, center, radius * 0.7, markerFillPaint);
        }
        break;
    }
  }

  void _drawTriangle(Canvas canvas, Offset center, double size, Paint paint) {
    final path = Path()
      ..moveTo(center.dx, center.dy - size)
      ..lineTo(center.dx + size * 0.866, center.dy + size * 0.5)
      ..lineTo(center.dx - size * 0.866, center.dy + size * 0.5)
      ..close();

    canvas.drawPath(path, paint);
  }

  void _drawLabel(Canvas canvas, TrackedPlayer player) {
    String label = '';

    if (player.name != null && player.name!.isNotEmpty) {
      label = player.name!;
    } else {
      label = 'ID ${player.id}';
    }

    if (showSpeed && player.speed > 0) {
      label += '  ${player.speed.toStringAsFixed(1)} км/ч';
    }

    final textPainter = TextPainter(
      text: TextSpan(
        text: label,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 11,
          fontWeight: FontWeight.w700,
        ),
      ),
      textDirection: TextDirection.ltr,
    )..layout();

    final padding = 6.0;
    final bgRect = RRect.fromRectAndRadius(
      Rect.fromLTWH(
        player.position.dx - textPainter.width / 2 - padding,
        player.position.dy - 28 - padding,
        textPainter.width + padding * 2,
        textPainter.height + padding * 2,
      ),
      const Radius.circular(8),
    );

    final bgPaint = Paint()..color = Colors.black.withOpacity(0.65);
    canvas.drawRRect(bgRect, bgPaint);

    textPainter.paint(
      canvas,
      Offset(
        player.position.dx - textPainter.width / 2,
        player.position.dy - 28,
      ),
    );
  }

  @override
  bool shouldRepaint(covariant PlayerTrackingPainter oldDelegate) {
    return oldDelegate.trackedPlayers != trackedPlayers ||
        oldDelegate.selectedTrackId != selectedTrackId ||
        oldDelegate.showTrails != showTrails ||
        oldDelegate.showLabels != showLabels ||
        oldDelegate.showSpeed != showSpeed ||
        oldDelegate.showBoundingBoxes != showBoundingBoxes ||
        oldDelegate.showOnlySelectedPlayer != showOnlySelectedPlayer;
  }
}