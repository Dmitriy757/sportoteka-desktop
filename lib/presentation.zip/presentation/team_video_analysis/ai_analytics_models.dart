import 'package:flutter/material.dart';

class AiDetectedEvent {
  final String type;
  final String title;
  final String subtitle;
  final int timeMs;
  final double confidence;
  final IconData icon;
  final Color color;
  final Map<String, dynamic>? meta;

  const AiDetectedEvent({
    required this.type,
    required this.title,
    required this.subtitle,
    required this.timeMs,
    required this.confidence,
    required this.icon,
    required this.color,
    this.meta,
  });
}

class AiTtdSuggestion {
  final String code;
  final String title;
  final String section;
  final int timeMs;
  final double confidence;
  final bool success;
  final Map<String, dynamic>? meta;

  const AiTtdSuggestion({
    required this.code,
    required this.title,
    required this.section,
    required this.timeMs,
    required this.confidence,
    required this.success,
    this.meta,
  });
}