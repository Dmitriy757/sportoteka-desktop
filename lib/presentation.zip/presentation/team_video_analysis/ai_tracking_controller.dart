import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/ai_analytics_models.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class AiTrackingController extends ChangeNotifier {
  bool isRunning = false;

  int sampleMs = 180;

  List<PlayerTrack> tracks = [];

  String? selectedTrackId;
  PlayerTrack? selectedTrack;

  bool showTrails = true;
  bool showLabels = true;
  bool showSpeed = true;
  bool showBoundingBoxes = true;
  bool showOnlySelectedPlayer = false;

  Timer? _loopTimer;
  bool _isProcessingFrame = false;

  double _pixelsToMeters = 0.12;

  bool isLocked = false;
  bool isSelectingTarget = false;

  PlayerTrack? lockedTrack;
  Rect? lockedRect;
  Offset? lockedPosition;

  int _missedLockedFrames = 0;
  final int _maxMissedLockedFrames = 8;

  List<DetectedPlayerBox> _lastDetections = [];
  int _lastDetectionTimeMs = 0;

  final double _maxPlayerSpeedKmh = 40.0;
  final int _maxPointsPerTrack = 120;

  double _positionSmoothFactor = 0.95;
  double _speedSmoothFactor = 0.85;
  double _maxJumpDistance = 300.0;
  bool _usePrediction = true;
  double _predictionFactor = 0.3;

  int _lastUpdateTimeMs = 0;
  double _lastSpeedKmh = 0;
  Offset _lastVelocity = Offset.zero;

  final List<AiDetectedEvent> autoEvents = [];
  final List<AiTtdSuggestion> ttdSuggestions = [];

  double averageSpeedKmh = 0;
  double maxSpeedKmh = 0;
  double totalDistanceMeters = 0;
  int sprintCount = 0;
  int directionChangeCount = 0;
  int accelerationBurstCount = 0;

  int _lastSprintEventTimeMs = 0;
  int _lastDirectionEventTimeMs = 0;
  int _lastAccelerationEventTimeMs = 0;
  int _lastTtdSuggestionTimeMs = 0;

  void startLoop({
    required Future<List<DetectedPlayerBox>> Function(int) frameDetector,
    required int Function() currentTimeMs,
  }) {
    stopLoop();

    isRunning = true;
    notifyListeners();

    _loopTimer = Timer.periodic(Duration(milliseconds: sampleMs), (timer) async {
      if (_isProcessingFrame) return;

      _isProcessingFrame = true;
      try {
        final timeMs = currentTimeMs();
        final detections = await frameDetector(timeMs);

        _lastDetections = detections;
        _lastDetectionTimeMs = timeMs;

        if (isLocked) {
          updateLockedTrack(detections, timeMs);
        }
      } catch (e) {
        debugPrint('❌ AI tracking loop error: $e');
      } finally {
        _isProcessingFrame = false;
      }
    });
  }

  void stopLoop() {
    _loopTimer?.cancel();
    _loopTimer = null;
    _isProcessingFrame = false;
    isRunning = false;
    notifyListeners();
  }

  void resetTracks() {
    tracks.clear();
    selectedTrackId = null;
    selectedTrack = null;

    lockedTrack = null;
    lockedRect = null;
    lockedPosition = null;
    isLocked = false;
    isSelectingTarget = false;
    _missedLockedFrames = 0;

    _lastDetections = [];
    _lastDetectionTimeMs = 0;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    autoEvents.clear();
    ttdSuggestions.clear();

    averageSpeedKmh = 0;
    maxSpeedKmh = 0;
    totalDistanceMeters = 0;
    sprintCount = 0;
    directionChangeCount = 0;
    accelerationBurstCount = 0;

    _lastSprintEventTimeMs = 0;
    _lastDirectionEventTimeMs = 0;
    _lastAccelerationEventTimeMs = 0;
    _lastTtdSuggestionTimeMs = 0;

    notifyListeners();
  }

  void disposeController() {
    stopLoop();
  }

  @override
  void dispose() {
    stopLoop();
    super.dispose();
  }

  void startTargetSelection() {
    isSelectingTarget = true;
    notifyListeners();
  }

  void clearLock() {
    isLocked = false;
    isSelectingTarget = false;

    lockedTrack = null;
    lockedRect = null;
    lockedPosition = null;

    tracks = [];
    selectedTrackId = null;
    selectedTrack = null;
    _missedLockedFrames = 0;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    autoEvents.clear();
    ttdSuggestions.clear();

    averageSpeedKmh = 0;
    maxSpeedKmh = 0;
    totalDistanceMeters = 0;
    sprintCount = 0;
    directionChangeCount = 0;
    accelerationBurstCount = 0;

    _lastSprintEventTimeMs = 0;
    _lastDirectionEventTimeMs = 0;
    _lastAccelerationEventTimeMs = 0;
    _lastTtdSuggestionTimeMs = 0;

    notifyListeners();
  }

  void setDetectionsForSelection(List<DetectedPlayerBox> detections, int timeMs) {
    _lastDetections = detections;
    _lastDetectionTimeMs = timeMs;
  }

  void selectTrackByTap(Offset tapPosition) {
    if (_lastDetections.isEmpty) {
      debugPrint('⚠️ No detections available for tap-lock');
      return;
    }

    lockOnDetections(
      tapPosition: tapPosition,
      detections: _lastDetections,
      timeMs: _lastDetectionTimeMs,
    );
  }

  void lockOnDetections({
    required Offset tapPosition,
    required List<DetectedPlayerBox> detections,
    required int timeMs,
  }) {
    if (detections.isEmpty) return;

    DetectedPlayerBox? best;
    double bestDistance = double.infinity;

    for (final d in detections) {
      final dist = (d.rect.center - tapPosition).distance;
      if (dist < bestDistance) {
        bestDistance = dist;
        best = d;
      }
    }

    if (best == null) return;

    final newTrack = PlayerTrack(
      id: 'track_$timeMs',
      color: Colors.red,
      points: [
        TrackPoint(
          position: best.rect.center,
          timeMs: timeMs,
          speed: 0,
          rect: best.rect,
          vx: 0,
          vy: 0,
          ax: 0,
          ay: 0,
        ),
      ],
      speed: 0,
      boundPlayerId: selectedTrack?.boundPlayerId,
      boundPlayerName: selectedTrack?.boundPlayerName ?? 'Игрок',
      createdAtMs: timeMs,
      lastSeenTimeMs: timeMs,
      lockedBox: best.rect,
    );

    lockedTrack = newTrack;
    lockedRect = best.rect;
    lockedPosition = best.rect.center;

    isLocked = true;
    isSelectingTarget = false;
    _missedLockedFrames = 0;
    _lastUpdateTimeMs = timeMs;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    tracks = [newTrack];
    selectedTrackId = newTrack.id;
    selectedTrack = newTrack;

    _recalculateLiveStats(newTrack);

    debugPrint('✅ Locked on player at ${best.rect.center}');
    notifyListeners();
  }

  void updateLockedTrack(List<DetectedPlayerBox> detections, int timeMs) {
    if (!isLocked || lockedTrack == null || lockedRect == null) return;

    final deltaTimeMs =
        _lastUpdateTimeMs > 0 ? timeMs - _lastUpdateTimeMs : sampleMs;
    _lastUpdateTimeMs = timeMs;

    if (detections.isEmpty) {
      _missedLockedFrames++;
      if (_missedLockedFrames > _maxMissedLockedFrames) {
        debugPrint('🗑 Lock lost: no detections');
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    final prevTrack = lockedTrack!;
    final predictedCenter = _predictNextPosition(prevTrack, timeMs, deltaTimeMs);

    DetectedPlayerBox? best;
    double bestScore = double.infinity;

    for (final d in detections) {
      final centerDistance = (d.rect.center - predictedCenter).distance;
      final score = centerDistance;

      if (score < bestScore) {
        bestScore = score;
        best = d;
      }
    }

    if (best == null) {
      _missedLockedFrames++;
      if (_missedLockedFrames > _maxMissedLockedFrames) {
        debugPrint('🗑 Lock lost: no best detection');
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    final bestDistance = (best.rect.center - predictedCenter).distance;

    if (bestDistance > _maxJumpDistance) {
      _missedLockedFrames++;
      debugPrint('⚠️ Target too far: ${bestDistance.toStringAsFixed(1)}px');

      if (_missedLockedFrames > _maxMissedLockedFrames) {
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    _missedLockedFrames = 0;

    Rect newRect = best.rect;
    newRect = _smoothRectFast(lockedRect!, newRect, _positionSmoothFactor);

    final motion = _calculateMotionForTrackFast(
      track: prevTrack,
      newCenter: newRect.center,
      timeMs: timeMs,
      deltaTimeMs: deltaTimeMs,
    );

    final updatedPoints = List<TrackPoint>.from(prevTrack.points)
      ..add(
        TrackPoint(
          position: newRect.center,
          timeMs: timeMs,
          speed: motion.speedKmh,
          rect: newRect,
          vx: motion.vx,
          vy: motion.vy,
          ax: motion.ax,
          ay: motion.ay,
        ),
      );

    final trimmedPoints = updatedPoints.length > _maxPointsPerTrack
        ? updatedPoints.sublist(updatedPoints.length - _maxPointsPerTrack)
        : updatedPoints;

    final updatedTrack = PlayerTrack(
      id: prevTrack.id,
      color: prevTrack.color,
      points: trimmedPoints,
      speed: motion.speedKmh,
      boundPlayerId: prevTrack.boundPlayerId,
      boundPlayerName: prevTrack.boundPlayerName,
      createdAtMs: prevTrack.createdAtMs,
      lastSeenTimeMs: timeMs,
      lockedBox: newRect,
    );

    lockedTrack = updatedTrack;
    lockedRect = newRect;
    lockedPosition = newRect.center;

    _lastVelocity = Offset(motion.vx, motion.vy);
    _lastSpeedKmh = motion.speedKmh;

    tracks = [updatedTrack];
    selectedTrackId = updatedTrack.id;
    selectedTrack = updatedTrack;

    _recalculateLiveStats(updatedTrack);
    _generateAiEvents(updatedTrack);
    _generateTtdSuggestions(updatedTrack);

    debugPrint(
      '⚡ TRACK: ${motion.speedKmh.toStringAsFixed(1)} km/h '
      'dist=${bestDistance.toStringAsFixed(1)}px '
      'dt=${deltaTimeMs}ms',
    );

    notifyListeners();
  }

  TrackMotionResult _calculateMotionForTrackFast({
    required PlayerTrack track,
    required Offset newCenter,
    required int timeMs,
    required int deltaTimeMs,
  }) {
    if (track.points.isEmpty) {
      return const TrackMotionResult(
        speedKmh: 0,
        vx: 0,
        vy: 0,
        ax: 0,
        ay: 0,
      );
    }

    final last = track.points.last;
    final dt = (deltaTimeMs / 1000.0).clamp(0.01, 0.1);

    final dx = newCenter.dx - last.position.dx;
    final dy = newCenter.dy - last.position.dy;

    final rawVx = dx / dt;
    final rawVy = dy / dt;

    final vx = last.vx * (1 - _speedSmoothFactor) + rawVx * _speedSmoothFactor;
    final vy = last.vy * (1 - _speedSmoothFactor) + rawVy * _speedSmoothFactor;

    final rawAx = (rawVx - last.vx) / dt;
    final rawAy = (rawVy - last.vy) / dt;

    final ax = last.ax * 0.3 + rawAx * 0.7;
    final ay = last.ay * 0.3 + rawAy * 0.7;

    final distancePx = sqrt(dx * dx + dy * dy);
    final distanceM = distancePx * _pixelsToMeters;
    final rawSpeedKmh = (distanceM / dt) * 3.6;

    double speedKmh =
        last.speed * (1 - _speedSmoothFactor) + rawSpeedKmh * _speedSmoothFactor;

    if (speedKmh > _maxPlayerSpeedKmh * 1.5) {
      speedKmh = last.speed;
    }

    return TrackMotionResult(
      speedKmh: speedKmh,
      vx: vx,
      vy: vy,
      ax: ax,
      ay: ay,
    );
  }

  Offset _predictNextPosition(PlayerTrack track, int timeMs, int deltaTimeMs) {
    if (track.points.isEmpty) return Offset.zero;
    if (!_usePrediction) return track.points.last.position;

    final last = track.points.last;
    final dt = (deltaTimeMs / 1000.0).clamp(0.0, 0.1);

    if (last.speed > 1.0) {
      final predictedX = last.position.dx + last.vx * dt * (1 + _predictionFactor);
      final predictedY = last.position.dy + last.vy * dt * (1 + _predictionFactor);
      return Offset(predictedX, predictedY);
    }

    return last.position;
  }

  Offset getPredictedPositionForTrack(PlayerTrack track, int currentVideoTimeMs) {
    if (track.points.isEmpty) return Offset.zero;

    final last = track.points.last;
    final dtMs = currentVideoTimeMs - last.timeMs;
    if (dtMs <= 0) return last.position;

    final dt = (dtMs / 1000.0).clamp(0.0, 0.04);

    if (_usePrediction && last.speed > 1.0) {
      return Offset(
        last.position.dx + last.vx * dt * (1 + _predictionFactor),
        last.position.dy + last.vy * dt * (1 + _predictionFactor),
      );
    }

    return Offset(
      last.position.dx + last.vx * dt,
      last.position.dy + last.vy * dt,
    );
  }

  Rect? getPredictedRectForTrack(PlayerTrack track, int currentVideoTimeMs) {
    if (track.points.isEmpty) return null;

    final last = track.points.last;
    final baseRect = last.rect;
    if (baseRect == null) return null;

    final predictedPos = getPredictedPositionForTrack(track, currentVideoTimeMs);
    final offset = predictedPos - last.position;

    return baseRect.shift(offset);
  }

  Rect _smoothRectFast(Rect prev, Rect next, double t) {
    return Rect.fromLTRB(
      prev.left * (1 - t) + next.left * t,
      prev.top * (1 - t) + next.top * t,
      prev.right * (1 - t) + next.right * t,
      prev.bottom * (1 - t) + next.bottom * t,
    );
  }

  Rect _smoothRect(Rect prev, Rect next, double t) {
    return _smoothRectFast(prev, next, t);
  }

  double _sizePenalty(Rect a, Rect b) {
    final areaA = a.width * a.height;
    final areaB = b.width * b.height;
    if (areaA <= 0) return 0;
    return ((areaB - areaA).abs() / areaA);
  }

  double _computeIoU(Rect a, Rect b) {
    final left = max(a.left, b.left);
    final top = max(a.top, b.top);
    final right = min(a.right, b.right);
    final bottom = min(a.bottom, b.bottom);

    if (right <= left || bottom <= top) return 0.0;

    final intersection = (right - left) * (bottom - top);
    final union = a.width * a.height + b.width * b.height - intersection;
    if (union <= 0) return 0.0;

    return intersection / union;
  }

  bool isSprintNow() {
    if (lockedTrack == null || lockedTrack!.points.isEmpty) return false;
    return lockedTrack!.points.last.speed >= 24.0;
  }

  double currentAcceleration() {
    if (lockedTrack == null || lockedTrack!.points.isEmpty) return 0;
    final p = lockedTrack!.points.last;
    return sqrt(p.ax * p.ax + p.ay * p.ay);
  }

  double? getCurrentSelectedPlayerSpeed() {
    if (lockedTrack != null && lockedTrack!.points.isNotEmpty) {
      return lockedTrack!.points.last.speed;
    }
    return null;
  }

  void bindSelectedTrackToPlayer({
    required int playerId,
    required String playerName,
  }) {
    if (lockedTrack == null) return;

    lockedTrack!.boundPlayerId = playerId;
    lockedTrack!.boundPlayerName = playerName;

    if (tracks.isNotEmpty) {
      tracks[0].boundPlayerId = playerId;
      tracks[0].boundPlayerName = playerName;
    }

    if (selectedTrack != null) {
      selectedTrack!.boundPlayerId = playerId;
      selectedTrack!.boundPlayerName = playerName;
    }

    debugPrint('✅ Locked track bound to player $playerName');
    notifyListeners();
  }

  Map<String, dynamic> exportJson() {
    return {
      'locked': isLocked,
      'track': lockedTrack?.toJson(),
      'timestamp': DateTime.now().toIso8601String(),
      'stats': _calculateStats(),
      'is_sprint_now': isSprintNow(),
      'current_acceleration': currentAcceleration(),
      'auto_events': autoEvents.map((e) => {
            'type': e.type,
            'title': e.title,
            'subtitle': e.subtitle,
            'timeMs': e.timeMs,
            'confidence': e.confidence,
            'meta': e.meta,
          }).toList(),
      'ttd_suggestions': ttdSuggestions.map((e) => {
            'code': e.code,
            'title': e.title,
            'section': e.section,
            'timeMs': e.timeMs,
            'confidence': e.confidence,
            'success': e.success,
            'meta': e.meta,
          }).toList(),
    };
  }

  Map<String, dynamic> _calculateStats() {
    if (lockedTrack == null) {
      return {
        'total_tracks': 0,
        'total_points': 0,
        'total_distance_m': 0.0,
        'max_speed_kmh': 0.0,
      };
    }

    double totalDistance = 0;
    double maxSpeed = 0;
    final pts = lockedTrack!.points;

    for (final point in pts) {
      maxSpeed = max(maxSpeed, point.speed);
    }

    for (int i = 1; i < pts.length; i++) {
      final p1 = pts[i - 1].position;
      final p2 = pts[i].position;
      final dx = p2.dx - p1.dx;
      final dy = p2.dy - p1.dy;
      totalDistance += sqrt(dx * dx + dy * dy) * _pixelsToMeters;
    }

    return {
      'total_tracks': 1,
      'total_points': pts.length,
      'total_distance_m': totalDistance,
      'max_speed_kmh': maxSpeed,
    };
  }

  void calibratePixelsToMeters(double knownDistanceMeters, double pixelsDistance) {
    if (pixelsDistance > 0) {
      _pixelsToMeters = knownDistanceMeters / pixelsDistance;
      debugPrint('📏 Calibrated pixelsToMeters = $_pixelsToMeters');
      notifyListeners();
    }
  }

  void autoCalibrateStandardField(double fieldPixelsLength) {
    if (fieldPixelsLength > 0) {
      _pixelsToMeters = 105.0 / fieldPixelsLength;

      debugPrint('📏 Auto calibration (field):');
      debugPrint(
        '   fieldPixelsLength = ${fieldPixelsLength.toStringAsFixed(1)} px',
      );
      debugPrint(
        '   scale = 1px = ${(_pixelsToMeters * 100).toStringAsFixed(1)} cm',
      );

      notifyListeners();
    }
  }

  bool get isCalibrating => false;
  double get currentScale => _pixelsToMeters;
  String get currentScaleText =>
      '1px = ${(_pixelsToMeters * 100).toStringAsFixed(1)}cm';

  void setTrackingSensitivity({
    required double positionSmoothFactor,
    required double speedSmoothFactor,
    required double maxJumpDistance,
    required bool usePrediction,
    required double predictionFactor,
  }) {
    _positionSmoothFactor = positionSmoothFactor.clamp(0.5, 0.99);
    _speedSmoothFactor = speedSmoothFactor.clamp(0.5, 0.99);
    _maxJumpDistance = maxJumpDistance.clamp(100, 500);
    _usePrediction = usePrediction;
    _predictionFactor = predictionFactor.clamp(0.0, 0.5);

    debugPrint('⚙️ Tracking sensitivity updated:');
    debugPrint('   positionSmooth=$_positionSmoothFactor');
    debugPrint('   speedSmooth=$_speedSmoothFactor');
    debugPrint('   maxJump=$_maxJumpDistance');
    debugPrint('   usePrediction=$_usePrediction');
    debugPrint('   predictionFactor=$_predictionFactor');
  }

  void _recalculateLiveStats(PlayerTrack track) {
    if (track.points.isEmpty) {
      averageSpeedKmh = 0;
      maxSpeedKmh = 0;
      totalDistanceMeters = 0;
      sprintCount = 0;
      return;
    }

    double sumSpeed = 0;
    double maxSpeed = 0;
    double totalDistance = 0;

    int sprints = 0;
    bool sprintOpen = false;

    for (int i = 0; i < track.points.length; i++) {
      final p = track.points[i];
      sumSpeed += p.speed;
      if (p.speed > maxSpeed) maxSpeed = p.speed;

      if (p.speed >= 24.0 && !sprintOpen) {
        sprintOpen = true;
        sprints++;
      } else if (p.speed < 20.0) {
        sprintOpen = false;
      }

      if (i > 0) {
        final prev = track.points[i - 1].position;
        final dx = p.position.dx - prev.dx;
        final dy = p.position.dy - prev.dy;
        totalDistance += sqrt(dx * dx + dy * dy) * _pixelsToMeters;
      }
    }

    averageSpeedKmh = sumSpeed / track.points.length;
    maxSpeedKmh = maxSpeed;
    totalDistanceMeters = totalDistance;
    sprintCount = sprints;
  }

  void _generateAiEvents(PlayerTrack track) {
    if (track.points.length < 3) return;

    final last = track.points.last;
    final prev = track.points[track.points.length - 2];

    final accel = sqrt(last.ax * last.ax + last.ay * last.ay);
    final speed = last.speed;

    final directionNow = atan2(last.vy, last.vx);
    final directionPrev = atan2(prev.vy, prev.vx);
    double directionDelta = (directionNow - directionPrev).abs();
    if (directionDelta > pi) {
      directionDelta = 2 * pi - directionDelta;
    }

    if (speed >= 24.0 && last.timeMs - _lastSprintEventTimeMs > 4000) {
      _lastSprintEventTimeMs = last.timeMs;

      autoEvents.insert(
        0,
        AiDetectedEvent(
          type: 'sprint',
          title: 'Рывок',
          subtitle: 'Игрок резко набрал высокую скорость',
          timeMs: last.timeMs,
          confidence: 0.86,
          icon: Icons.flash_on_rounded,
          color: const Color(0xFFF59E0B),
          meta: {'speed': speed},
        ),
      );
    }

    if (accel >= 120.0 && last.timeMs - _lastAccelerationEventTimeMs > 3500) {
      _lastAccelerationEventTimeMs = last.timeMs;
      accelerationBurstCount++;

      autoEvents.insert(
        0,
        AiDetectedEvent(
          type: 'acceleration',
          title: 'Резкое ускорение',
          subtitle: 'Выраженный импульс ускорения',
          timeMs: last.timeMs,
          confidence: 0.78,
          icon: Icons.trending_up_rounded,
          color: const Color(0xFF16A34A),
          meta: {'acceleration': accel},
        ),
      );
    }

    if (directionDelta >= 0.65 &&
        speed >= 8.0 &&
        last.timeMs - _lastDirectionEventTimeMs > 3000) {
      _lastDirectionEventTimeMs = last.timeMs;
      directionChangeCount++;

      autoEvents.insert(
        0,
        AiDetectedEvent(
          type: 'direction_change',
          title: 'Смена направления',
          subtitle: 'Возможный манёвр, обыгрыш или уход от соперника',
          timeMs: last.timeMs,
          confidence: 0.74,
          icon: Icons.turn_right_rounded,
          color: const Color(0xFF2563EB),
          meta: {'delta': directionDelta},
        ),
      );
    }

    if (autoEvents.length > 50) {
      autoEvents.removeRange(50, autoEvents.length);
    }
  }

  void _generateTtdSuggestions(PlayerTrack track) {
    if (track.points.length < 3) return;

    final last = track.points.last;
    final prev = track.points[track.points.length - 2];

    final accel = sqrt(last.ax * last.ax + last.ay * last.ay);

    final directionNow = atan2(last.vy, last.vx);
    final directionPrev = atan2(prev.vy, prev.vx);
    double directionDelta = (directionNow - directionPrev).abs();
    if (directionDelta > pi) {
      directionDelta = 2 * pi - directionDelta;
    }

    if (last.timeMs - _lastTtdSuggestionTimeMs < 2500) return;

    if (directionDelta >= 0.70 && last.speed >= 10.0) {
      _lastTtdSuggestionTimeMs = last.timeMs;

      ttdSuggestions.insert(
        0,
        AiTtdSuggestion(
          code: 'feint_dribble',
          title: 'Финт / дриблинг',
          section: 'Основные действия',
          timeMs: last.timeMs,
          confidence: 0.72,
          success: true,
          meta: {
            'speed': last.speed,
            'direction_delta': directionDelta,
          },
        ),
      );
    } else if (last.speed >= 6.0 && last.speed <= 18.0 && accel >= 90.0) {
      _lastTtdSuggestionTimeMs = last.timeMs;

      ttdSuggestions.insert(
        0,
        AiTtdSuggestion(
          code: 'forward_short',
          title: 'Передача вперед короткая',
          section: 'Передачи',
          timeMs: last.timeMs,
          confidence: 0.64,
          success: true,
          meta: {
            'speed': last.speed,
            'acceleration': accel,
          },
        ),
      );
    } else if (last.speed >= 12.0 && accel >= 130.0) {
      _lastTtdSuggestionTimeMs = last.timeMs;

      ttdSuggestions.insert(
        0,
        AiTtdSuggestion(
          code: 'interception',
          title: 'Перехват',
          section: 'Основные действия',
          timeMs: last.timeMs,
          confidence: 0.58,
          success: true,
          meta: {
            'speed': last.speed,
            'acceleration': accel,
          },
        ),
      );
    }

    if (ttdSuggestions.length > 50) {
      ttdSuggestions.removeRange(50, ttdSuggestions.length);
    }
  }
}

class TrackMotionResult {
  final double speedKmh;
  final double vx;
  final double vy;
  final double ax;
  final double ay;

  const TrackMotionResult({
    required this.speedKmh,
    required this.vx,
    required this.vy,
    required this.ax,
    required this.ay,
  });
}