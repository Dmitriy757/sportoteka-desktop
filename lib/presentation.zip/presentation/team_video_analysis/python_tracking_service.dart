import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class PythonTrackingService {
  final String baseUrl;

  PythonTrackingService({required this.baseUrl});

  Future<List<DetectedPlayerBox>> detectFrame({
    required File frameFile,
    required int timeMs,
  }) async {
    try {
      final url = '$baseUrl/analyze_frame';
      debugPrint('🚀 PYTHON URL: $url');
      debugPrint('🕒 timeMs: $timeMs');
      debugPrint('🖼 frame path: ${frameFile.path}');

      final request = http.MultipartRequest(
        'POST',
        Uri.parse(url),
      );

      request.fields['timeMs'] = timeMs.toString();
      request.files.add(
        await http.MultipartFile.fromPath(
          'frame',
          frameFile.path,
        ),
      );

      final streamed = await request.send().timeout(
        const Duration(seconds: 20),
      );

      final response = await http.Response.fromStream(streamed).timeout(
        const Duration(seconds: 20),
      );

      debugPrint('📥 PYTHON STATUS: ${response.statusCode}');
      debugPrint('📥 PYTHON BODY: ${response.body}');

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (data['success'] != true) {
        debugPrint('❌ PYTHON success=false: ${data['error']}');
        return [];
      }

      final detectionsRaw = (data['detections'] as List?) ?? const [];

      return detectionsRaw
          .map((item) => DetectedPlayerBox.fromJson(
                Map<String, dynamic>.from(item as Map),
              ))
          .toList();
    } catch (e) {
      debugPrint('❌ PYTHON detectFrame error: $e');
      return [];
    }
  }

  Future<List<DetectedPlayerBox>> detectFrameFromUrl({
    required String videoUrl,
    required int timeMs,
  }) async {
    try {
      final url = '$baseUrl/analyze_frame_from_url';
      debugPrint('🚀 PYTHON URL STREAM: $url');
      debugPrint('🎬 videoUrl: $videoUrl');
      debugPrint('🕒 timeMs: $timeMs');

      final response = await http
          .post(
            Uri.parse(url),
            headers: {
              'Content-Type': 'application/json',
            },
            body: jsonEncode({
              'video_url': videoUrl,
              'timeMs': timeMs,
            }),
          )
          .timeout(const Duration(seconds: 25));

      debugPrint('📥 PYTHON STREAM STATUS: ${response.statusCode}');
      debugPrint('📥 PYTHON STREAM BODY: ${response.body}');

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (data['success'] != true) {
        debugPrint('❌ PYTHON STREAM success=false: ${data['error']}');
        return [];
      }

      final detectionsRaw = (data['detections'] as List?) ?? const [];

      return detectionsRaw
          .map((item) => DetectedPlayerBox.fromJson(
                Map<String, dynamic>.from(item as Map),
              ))
          .toList();
    } catch (e) {
      debugPrint('❌ PYTHON detectFrameFromUrl error: $e');
      return [];
    }
  }
}