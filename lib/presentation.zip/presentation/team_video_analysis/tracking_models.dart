import 'dart:ui';
import 'package:flutter/material.dart';

enum PlayerMarkerType {
  box,
  circle,
  triangle,
}

class TrackPoint {
  final Offset position;
  final int timeMs;
  final double speed;

  final double vx;
  final double vy;
  final double ax;
  final double ay;

  final Rect? rect;

  const TrackPoint({
    required this.position,
    required this.timeMs,
    this.speed = 0,
    this.vx = 0,
    this.vy = 0,
    this.ax = 0,
    this.ay = 0,
    this.rect,
  });

  Rect? get boundingBox => rect;

  Map<String, dynamic> toJson() {
    return {
      'x': position.dx,
      'y': position.dy,
      'timeMs': timeMs,
      'speed': speed,
      'vx': vx,
      'vy': vy,
      'ax': ax,
      'ay': ay,
      'rect': rect == null
          ? null
          : {
              'left': rect!.left,
              'top': rect!.top,
              'right': rect!.right,
              'bottom': rect!.bottom,
            },
    };
  }

  factory TrackPoint.fromJson(Map<String, dynamic> json) {
    Rect? parsedRect;
    final rawRect = json['rect'] ?? json['boundingBox'];
    if (rawRect is Map) {
      parsedRect = Rect.fromLTRB(
        (rawRect['left'] ?? 0).toDouble(),
        (rawRect['top'] ?? 0).toDouble(),
        (rawRect['right'] ?? 0).toDouble(),
        (rawRect['bottom'] ?? 0).toDouble(),
      );
    }

    return TrackPoint(
      position: Offset(
        (json['x'] ?? 0).toDouble(),
        (json['y'] ?? 0).toDouble(),
      ),
      timeMs: (json['timeMs'] ?? 0) as int,
      speed: (json['speed'] ?? 0).toDouble(),
      vx: (json['vx'] ?? 0).toDouble(),
      vy: (json['vy'] ?? 0).toDouble(),
      ax: (json['ax'] ?? 0).toDouble(),
      ay: (json['ay'] ?? 0).toDouble(),
      rect: parsedRect,
    );
  }
}

class DetectedPlayerBox {
  final int id;
  final Rect rect;
  final double confidence;
  final int? classId;
  final String? label;

  const DetectedPlayerBox({
    required this.id,
    required this.rect,
    this.confidence = 0,
    this.classId,
    this.label,
  });

  Offset get center => rect.center;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'left': rect.left,
      'top': rect.top,
      'right': rect.right,
      'bottom': rect.bottom,
      'confidence': confidence,
      'classId': classId,
      'label': label,
    };
  }

  factory DetectedPlayerBox.fromJson(Map<String, dynamic> json) {
    final left = (json['left'] ?? json['x'] ?? 0).toDouble();
    final top = (json['top'] ?? json['y'] ?? 0).toDouble();

    final right = json['right'] != null
        ? (json['right']).toDouble()
        : left + (json['width'] ?? 0).toDouble();

    final bottom = json['bottom'] != null
        ? (json['bottom']).toDouble()
        : top + (json['height'] ?? 0).toDouble();

    return DetectedPlayerBox(
      id: (json['id'] ?? 0) as int,
      rect: Rect.fromLTRB(left, top, right, bottom),
      confidence: (json['confidence'] ?? 0).toDouble(),
      classId: json['classId'] as int?,
      label: json['label']?.toString(),
    );
  }
}

class PlayerTrack {
  final String id;
  int? boundPlayerId;
  String boundPlayerName;
  final Color color;
  final List<TrackPoint> points;
  double? speed;
  final bool isLocked;
  final int createdAtMs;
  final int lastSeenTimeMs;
  final Rect? lockedBox;

  PlayerTrack({
    required this.id,
    required this.boundPlayerName,
    required this.color,
    required this.points,
    required this.createdAtMs,
    required this.lastSeenTimeMs,
    this.boundPlayerId,
    this.speed,
    this.isLocked = false,
    this.lockedBox,
  });

  TrackPoint? get lastPoint => points.isNotEmpty ? points.last : null;

  Offset? get currentPosition => lastPoint?.position;

  Rect? get currentBoundingBox => lastPoint?.rect ?? lockedBox;

  PlayerTrack copyWith({
    String? id,
    int? boundPlayerId,
    String? boundPlayerName,
    Color? color,
    List<TrackPoint>? points,
    double? speed,
    bool? isLocked,
    int? createdAtMs,
    int? lastSeenTimeMs,
    Rect? lockedBox,
  }) {
    return PlayerTrack(
      id: id ?? this.id,
      boundPlayerId: boundPlayerId ?? this.boundPlayerId,
      boundPlayerName: boundPlayerName ?? this.boundPlayerName,
      color: color ?? this.color,
      points: points ?? this.points,
      speed: speed ?? this.speed,
      isLocked: isLocked ?? this.isLocked,
      createdAtMs: createdAtMs ?? this.createdAtMs,
      lastSeenTimeMs: lastSeenTimeMs ?? this.lastSeenTimeMs,
      lockedBox: lockedBox ?? this.lockedBox,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'boundPlayerId': boundPlayerId,
      'boundPlayerName': boundPlayerName,
      'color': color.value,
      'speed': speed,
      'isLocked': isLocked,
      'createdAtMs': createdAtMs,
      'lastSeenTimeMs': lastSeenTimeMs,
      'lockedBox': lockedBox == null
          ? null
          : {
              'left': lockedBox!.left,
              'top': lockedBox!.top,
              'right': lockedBox!.right,
              'bottom': lockedBox!.bottom,
            },
      'points': points.map((e) => e.toJson()).toList(),
    };
  }

  factory PlayerTrack.fromJson(Map<String, dynamic> json) {
    Rect? parsedLockedBox;
    final rawLockedBox = json['lockedBox'];
    if (rawLockedBox is Map) {
      parsedLockedBox = Rect.fromLTRB(
        (rawLockedBox['left'] ?? 0).toDouble(),
        (rawLockedBox['top'] ?? 0).toDouble(),
        (rawLockedBox['right'] ?? 0).toDouble(),
        (rawLockedBox['bottom'] ?? 0).toDouble(),
      );
    }

    final rawPoints = (json['points'] as List?) ?? const [];

    return PlayerTrack(
      id: json['id']?.toString() ?? '',
      boundPlayerId: json['boundPlayerId'] as int?,
      boundPlayerName: json['boundPlayerName']?.toString() ?? 'Игрок',
      color: Color((json['color'] ?? Colors.red.value) as int),
      speed: json['speed'] == null ? null : (json['speed'] as num).toDouble(),
      isLocked: json['isLocked'] == true,
      createdAtMs: (json['createdAtMs'] ?? 0) as int,
      lastSeenTimeMs: (json['lastSeenTimeMs'] ?? 0) as int,
      lockedBox: parsedLockedBox,
      points: rawPoints
          .whereType<Map>()
          .map((e) => TrackPoint.fromJson(Map<String, dynamic>.from(e)))
          .toList(),
    );
  }
}

class TrackingStats {
  final double totalDistance;
  final double averageSpeed;
  final double maxSpeed;
  final int durationMs;

  const TrackingStats({
    required this.totalDistance,
    required this.averageSpeed,
    required this.maxSpeed,
    required this.durationMs,
  });

  const TrackingStats.empty()
      : totalDistance = 0,
        averageSpeed = 0,
        maxSpeed = 0,
        durationMs = 0;
}