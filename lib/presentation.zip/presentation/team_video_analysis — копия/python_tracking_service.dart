import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class PythonTrackingService {
  final String baseUrl;

  PythonTrackingService({required this.baseUrl});

  Future<List<DetectedPlayerBox>> detectFrame({
    required File frameFile,
    required int timeMs,
  }) async {
    try {
      final url = '$baseUrl/track_frame';
      debugPrint('🚀 PYTHON URL: $url');

      final request = http.MultipartRequest(
        'POST',
        Uri.parse(url),
      );

      request.fields['time_ms'] = timeMs.toString();
      request.files.add(
        await http.MultipartFile.fromPath('frame', frameFile.path),
      );

      final streamed = await request.send();
      final response = await http.Response.fromStream(streamed);

      debugPrint('📥 PYTHON STATUS: ${response.statusCode}');
      debugPrint('📥 PYTHON BODY: ${response.body}');

      if (response.statusCode != 200) {
        return [];
      }

      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final detectionsRaw = (data['detections'] as List?) ?? [];

      return detectionsRaw.map<DetectedPlayerBox>((item) {
        final map = item as Map<String, dynamic>;

        return DetectedPlayerBox(
          id: (map['id'] ?? 0) as int,
          rect: Rect.fromLTWH(
            ((map['x'] ?? map['left'] ?? 0) as num).toDouble(),
            ((map['y'] ?? map['top'] ?? 0) as num).toDouble(),
            ((map['width'] ?? map['w'] ?? 0) as num).toDouble(),
            ((map['height'] ?? map['h'] ?? 0) as num).toDouble(),
          ),
          confidence: ((map['confidence'] ?? 1.0) as num).toDouble(),
        
        );
      }).toList();
    } catch (e) {
      debugPrint('❌ PYTHON detectFrame error: $e');
      return [];
    }
  }
}