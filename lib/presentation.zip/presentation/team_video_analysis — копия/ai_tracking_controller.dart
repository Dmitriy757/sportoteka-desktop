import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:sportoteka/presentation/team_video_analysis/tracking_models.dart';

class AiTrackingController extends ChangeNotifier {
  bool isRunning = false;

  /// Для snapshot-based анализа оптимально 70-100 мс
  int sampleMs = 80;

  /// Для совместимости с текущим UI:
  /// храним максимум один трек в списке.
  List<PlayerTrack> tracks = [];

  String? selectedTrackId;
  PlayerTrack? selectedTrack;

  bool showTrails = true;
  bool showLabels = true;
  bool showSpeed = true;
  bool showBoundingBoxes = true;
  bool showOnlySelectedPlayer = false;

  Timer? _loopTimer;
  bool _isProcessingFrame = false;

  /// Масштаб px -> meters
  double _pixelsToMeters = 0.12;

  /// Жесткий lock
  bool isLocked = false;
  bool isSelectingTarget = false;

  PlayerTrack? lockedTrack;
  Rect? lockedRect;
  Offset? lockedPosition;

  int _missedLockedFrames = 0;
  final int _maxMissedLockedFrames = 8;

  /// Последние детекции нужны, чтобы тапом выбрать ближайшего игрока
  List<DetectedPlayerBox> _lastDetections = [];
  int _lastDetectionTimeMs = 0;

  /// Ограничения и фильтры
  final double _maxPlayerSpeedKmh = 40.0;
  final int _maxPointsPerTrack = 120;

  // =========================
  // НОВЫЕ ПАРАМЕТРЫ ДЛЯ БЫСТРОГО СЛЕЖЕНИЯ
  // =========================
  
  /// Коэффициент сглаживания позиции (чем ближе к 1.0, тем быстрее реакция)
  double _positionSmoothFactor = 0.95; // Увеличил с 0.88 до 0.95
  
  /// Коэффициент сглаживания скорости
  double _speedSmoothFactor = 0.85; // Увеличил с 0.75 до 0.85
  
  /// Максимальное допустимое смещение между кадрами (в пикселях)
  double _maxJumpDistance = 300.0; // Увеличил с 200 до 300
  
  /// Прогнозирование позиции (true - использовать, false - использовать только текущую)
  bool _usePrediction = true; // Включаем прогнозирование
  
  /// Коэффициент экстраполяции для предсказания (0.0-1.0)
  double _predictionFactor = 0.3; // Добавляем 30% от скорости для предсказания
  
  /// Время последнего обновления для расчета дельты
  int _lastUpdateTimeMs = 0;
  
  /// Последняя вычисленная скорость для более плавного предсказания
  double _lastSpeedKmh = 0;
  Offset _lastVelocity = Offset.zero;

  // =========================
  // LOOP
  // =========================

  void startLoop({
    required Future<List<DetectedPlayerBox>> Function(int) frameDetector,
    required int Function() currentTimeMs,
  }) {
    stopLoop();

    isRunning = true;
    notifyListeners();

    _loopTimer = Timer.periodic(Duration(milliseconds: sampleMs), (timer) async {
      if (_isProcessingFrame) return;

      _isProcessingFrame = true;
      try {
        final timeMs = currentTimeMs();
        final detections = await frameDetector(timeMs);

        _lastDetections = detections;
        _lastDetectionTimeMs = timeMs;

        if (isLocked) {
          updateLockedTrack(detections, timeMs);
        }
      } catch (e) {
        debugPrint('❌ AI tracking loop error: $e');
      } finally {
        _isProcessingFrame = false;
      }
    });
  }

  void stopLoop() {
    _loopTimer?.cancel();
    _loopTimer = null;
    _isProcessingFrame = false;
    isRunning = false;
    notifyListeners();
  }

  void resetTracks() {
    tracks.clear();
    selectedTrackId = null;
    selectedTrack = null;

    lockedTrack = null;
    lockedRect = null;
    lockedPosition = null;
    isLocked = false;
    isSelectingTarget = false;
    _missedLockedFrames = 0;

    _lastDetections = [];
    _lastDetectionTimeMs = 0;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    notifyListeners();
  }

  void disposeController() {
    stopLoop();
  }

  @override
  void dispose() {
    stopLoop();
    super.dispose();
  }

  // =========================
  // LOCK / TARGET SELECTION
  // =========================

  void startTargetSelection() {
    isSelectingTarget = true;
    notifyListeners();
  }

  void clearLock() {
    isLocked = false;
    isSelectingTarget = false;

    lockedTrack = null;
    lockedRect = null;
    lockedPosition = null;

    tracks = [];
    selectedTrackId = null;
    selectedTrack = null;
    _missedLockedFrames = 0;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    notifyListeners();
  }

  void setDetectionsForSelection(List<DetectedPlayerBox> detections, int timeMs) {
    _lastDetections = detections;
    _lastDetectionTimeMs = timeMs;
  }

  /// Пользователь тапает по видео.
  /// Если есть свежие detections — лочимся на ближайшего игрока.
  void selectTrackByTap(Offset tapPosition) {
    if (_lastDetections.isEmpty) {
      debugPrint('⚠️ No detections available for tap-lock');
      return;
    }

    lockOnDetections(
      tapPosition: tapPosition,
      detections: _lastDetections,
      timeMs: _lastDetectionTimeMs,
    );
  }

  void lockOnDetections({
    required Offset tapPosition,
    required List<DetectedPlayerBox> detections,
    required int timeMs,
  }) {
    if (detections.isEmpty) return;

    DetectedPlayerBox? best;
    double bestDistance = double.infinity;

    for (final d in detections) {
      final dist = (d.rect.center - tapPosition).distance;
      if (dist < bestDistance) {
        bestDistance = dist;
        best = d;
      }
    }

    if (best == null) return;

    final newTrack = PlayerTrack(
  id: 'track_$timeMs',
  color: Colors.red,
  points: [
    TrackPoint(
      position: best.rect.center,
      timeMs: timeMs,
      speed: 0,
      rect: best.rect,
      vx: 0,
      vy: 0,
      ax: 0,
      ay: 0,
    ),
  ],
  speed: 0,
  boundPlayerId: selectedTrack?.boundPlayerId,
  boundPlayerName: selectedTrack?.boundPlayerName ?? 'Игрок',
  createdAtMs: timeMs,
  lastSeenTimeMs: timeMs,
  lockedBox: best.rect,
);

    lockedTrack = newTrack;
    lockedRect = best.rect;
    lockedPosition = best.rect.center;

    isLocked = true;
    isSelectingTarget = false;
    _missedLockedFrames = 0;
    _lastUpdateTimeMs = timeMs;
    _lastVelocity = Offset.zero;
    _lastSpeedKmh = 0;

    tracks = [newTrack];
    selectedTrackId = newTrack.id;
    selectedTrack = newTrack;

    debugPrint('✅ Locked on player at ${best.rect.center}');
    notifyListeners();
  }

  // =========================
  // TRACK UPDATE - ОПТИМИЗИРОВАННАЯ ВЕРСИЯ
  // =========================

  void updateLockedTrack(List<DetectedPlayerBox> detections, int timeMs) {
    if (!isLocked || lockedTrack == null || lockedRect == null) return;

    // Сохраняем время для расчета дельты
    final deltaTimeMs = _lastUpdateTimeMs > 0 ? timeMs - _lastUpdateTimeMs : sampleMs;
    _lastUpdateTimeMs = timeMs;

    if (detections.isEmpty) {
      _missedLockedFrames++;
      if (_missedLockedFrames > _maxMissedLockedFrames) {
        debugPrint('🗑 Lock lost: no detections');
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    final prevTrack = lockedTrack!;
    
    // Предсказываем следующую позицию на основе скорости
    final predictedCenter = _predictNextPosition(prevTrack, timeMs, deltaTimeMs);

    DetectedPlayerBox? best;
    double bestScore = double.infinity;

    for (final d in detections) {
      // Упрощенная метрика - больше вес на расстояние, меньше на IOU
      final centerDistance = (d.rect.center - predictedCenter).distance;
      
      // Упрощаем скоринг - расстояние важнее всего
      final score = centerDistance; // * 0.8 + (1.0 - _computeIoU(lockedRect!, d.rect)) * 20.0;

      if (score < bestScore) {
        bestScore = score;
        best = d;
      }
    }

    if (best == null) {
      _missedLockedFrames++;
      if (_missedLockedFrames > _maxMissedLockedFrames) {
        debugPrint('🗑 Lock lost: no best detection');
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    final bestDistance = (best.rect.center - predictedCenter).distance;
    
    // Увеличиваем допустимую дистанцию прыжка
    if (bestDistance > _maxJumpDistance) {
      _missedLockedFrames++;
      debugPrint('⚠️ Target too far: ${bestDistance.toStringAsFixed(1)}px');

      if (_missedLockedFrames > _maxMissedLockedFrames) {
        clearLock();
      } else {
        notifyListeners();
      }
      return;
    }

    _missedLockedFrames = 0;

    Rect newRect = best.rect;

    // Быстрое сглаживание с высоким коэффициентом (почти без лага)
    newRect = _smoothRectFast(lockedRect!, newRect, _positionSmoothFactor);

    final motion = _calculateMotionForTrackFast(
      track: prevTrack,
      newCenter: newRect.center,
      timeMs: timeMs,
      deltaTimeMs: deltaTimeMs,
    );

    final updatedPoints = List<TrackPoint>.from(prevTrack.points)
  ..add(
    TrackPoint(
      position: newRect.center,
      timeMs: timeMs,
      speed: motion.speedKmh,
      rect: newRect,
      vx: motion.vx,
      vy: motion.vy,
      ax: motion.ax,
      ay: motion.ay,
    ),
  );

final trimmedPoints = updatedPoints.length > _maxPointsPerTrack
    ? updatedPoints.sublist(updatedPoints.length - _maxPointsPerTrack)
    : updatedPoints;

final updatedTrack = PlayerTrack(
  id: prevTrack.id,
  color: prevTrack.color,
  points: trimmedPoints,
  speed: motion.speedKmh,
  boundPlayerId: prevTrack.boundPlayerId,
  boundPlayerName: prevTrack.boundPlayerName,
  createdAtMs: prevTrack.createdAtMs,
  lastSeenTimeMs: timeMs,
  lockedBox: newRect,
);

    lockedTrack = updatedTrack;
    lockedRect = newRect;
    lockedPosition = newRect.center;
    
    // Сохраняем скорость для предсказания
    _lastVelocity = Offset(motion.vx, motion.vy);
    _lastSpeedKmh = motion.speedKmh;

    tracks = [updatedTrack];
    selectedTrackId = updatedTrack.id;
    selectedTrack = updatedTrack;

    debugPrint(
      '⚡ TRACK: ${motion.speedKmh.toStringAsFixed(1)} km/h '
      'dist=${bestDistance.toStringAsFixed(1)}px '
      'dt=${deltaTimeMs}ms',
    );

    notifyListeners();
  }

  // =========================
  // MOTION / PREDICTION - ОПТИМИЗИРОВАННЫЕ
  // =========================

  /// Ускоренный расчет движения с учетом дельты времени
  TrackMotionResult _calculateMotionForTrackFast({
    required PlayerTrack track,
    required Offset newCenter,
    required int timeMs,
    required int deltaTimeMs,
  }) {
    if (track.points.isEmpty) {
      return const TrackMotionResult(
        speedKmh: 0,
        vx: 0,
        vy: 0,
        ax: 0,
        ay: 0,
      );
    }

    final last = track.points.last;

    // Используем реальную дельту времени, но с ограничениями
    final dt = (deltaTimeMs / 1000.0).clamp(0.01, 0.1);

    final dx = newCenter.dx - last.position.dx;
    final dy = newCenter.dy - last.position.dy;

    // Сырая скорость
    final rawVx = dx / dt;
    final rawVy = dy / dt;

    // Быстрое сглаживание скорости (больше вес на новые данные)
    final vx = last.vx * (1 - _speedSmoothFactor) + rawVx * _speedSmoothFactor;
    final vy = last.vy * (1 - _speedSmoothFactor) + rawVy * _speedSmoothFactor;

    // Ускорение (опционально)
    final rawAx = (rawVx - last.vx) / dt;
    final rawAy = (rawVy - last.vy) / dt;
    
    final ax = last.ax * 0.3 + rawAx * 0.7;
    final ay = last.ay * 0.3 + rawAy * 0.7;

    // Расчет скорости в км/ч
    final distancePx = sqrt(dx * dx + dy * dy);
    final distanceM = distancePx * _pixelsToMeters;
    final rawSpeedKmh = (distanceM / dt) * 3.6;

    // Сглаживание скорости
    double speedKmh = last.speed * (1 - _speedSmoothFactor) + rawSpeedKmh * _speedSmoothFactor;

    // Проверка на аномалии
    if (speedKmh > _maxPlayerSpeedKmh * 1.5) {
      speedKmh = last.speed;
    }

    return TrackMotionResult(
      speedKmh: speedKmh,
      vx: vx,
      vy: vy,
      ax: ax,
      ay: ay,
    );
  }

  /// Улучшенное предсказание следующей позиции
  Offset _predictNextPosition(PlayerTrack track, int timeMs, int deltaTimeMs) {
    if (track.points.isEmpty) return Offset.zero;
    if (!_usePrediction) return track.points.last.position;

    final last = track.points.last;
    
    // Используем реальную дельту времени
    final dt = (deltaTimeMs / 1000.0).clamp(0.0, 0.1);
    
    // Добавляем экстраполяцию на основе скорости
    if (last.speed > 1.0) { // Если есть значимая скорость
      final predictedX = last.position.dx + last.vx * dt * (1 + _predictionFactor);
      final predictedY = last.position.dy + last.vy * dt * (1 + _predictionFactor);
      return Offset(predictedX, predictedY);
    }

    return last.position;
  }

  Offset getPredictedPositionForTrack(PlayerTrack track, int currentVideoTimeMs) {
    if (track.points.isEmpty) return Offset.zero;

    final last = track.points.last;
    final dtMs = currentVideoTimeMs - last.timeMs;
    if (dtMs <= 0) return last.position;

    final dt = (dtMs / 1000.0).clamp(0.0, 0.04);

    // Используем ту же логику с экстраполяцией
    if (_usePrediction && last.speed > 1.0) {
      return Offset(
        last.position.dx + last.vx * dt * (1 + _predictionFactor),
        last.position.dy + last.vy * dt * (1 + _predictionFactor),
      );
    }

    return Offset(
      last.position.dx + last.vx * dt,
      last.position.dy + last.vy * dt,
    );
  }

  Rect? getPredictedRectForTrack(PlayerTrack track, int currentVideoTimeMs) {
    if (track.points.isEmpty) return null;

    final last = track.points.last;
    final baseRect = last.rect;
    if (baseRect == null) return null;

    final predictedPos = getPredictedPositionForTrack(track, currentVideoTimeMs);
    final offset = predictedPos - last.position;

    return baseRect.shift(offset);
  }

  /// Быстрое сглаживание rect (минимальный лаг)
  Rect _smoothRectFast(Rect prev, Rect next, double t) {
    // При t близком к 1.0 - почти без сглаживания
    return Rect.fromLTRB(
      prev.left * (1 - t) + next.left * t,
      prev.top * (1 - t) + next.top * t,
      prev.right * (1 - t) + next.right * t,
      prev.bottom * (1 - t) + next.bottom * t,
    );
  }

  // Сохраняем старый метод для обратной совместимости
  Rect _smoothRect(Rect prev, Rect next, double t) {
    return _smoothRectFast(prev, next, t);
  }

  double _sizePenalty(Rect a, Rect b) {
    final areaA = a.width * a.height;
    final areaB = b.width * b.height;
    if (areaA <= 0) return 0;
    return ((areaB - areaA).abs() / areaA);
  }

  // =========================
  // IOU
  // =========================

  double _computeIoU(Rect a, Rect b) {
    final left = max(a.left, b.left);
    final top = max(a.top, b.top);
    final right = min(a.right, b.right);
    final bottom = min(a.bottom, b.bottom);

    if (right <= left || bottom <= top) return 0.0;

    final intersection = (right - left) * (bottom - top);
    final union = a.width * a.height + b.width * b.height - intersection;
    if (union <= 0) return 0.0;

    return intersection / union;
  }

  // =========================
  // SPRINT / ACCELERATION
  // =========================

  bool isSprintNow() {
    if (lockedTrack == null || lockedTrack!.points.isEmpty) return false;
    return lockedTrack!.points.last.speed >= 24.0;
  }

  double currentAcceleration() {
    if (lockedTrack == null || lockedTrack!.points.isEmpty) return 0;
    final p = lockedTrack!.points.last;
    return sqrt(p.ax * p.ax + p.ay * p.ay);
  }

  double? getCurrentSelectedPlayerSpeed() {
    if (lockedTrack != null && lockedTrack!.points.isNotEmpty) {
      return lockedTrack!.points.last.speed;
    }
    return null;
  }

  // =========================
  // BIND / EXPORT / STATS
  // =========================

  void bindSelectedTrackToPlayer({
    required int playerId,
    required String playerName,
  }) {
    if (lockedTrack == null) return;

    lockedTrack!.boundPlayerId = playerId;
    lockedTrack!.boundPlayerName = playerName;

    if (tracks.isNotEmpty) {
      tracks[0].boundPlayerId = playerId;
      tracks[0].boundPlayerName = playerName;
    }

    if (selectedTrack != null) {
      selectedTrack!.boundPlayerId = playerId;
      selectedTrack!.boundPlayerName = playerName;
    }

    debugPrint('✅ Locked track bound to player $playerName');
    notifyListeners();
  }

  Map<String, dynamic> exportJson() {
    return {
      'locked': isLocked,
      'track': lockedTrack?.toJson(),
      'timestamp': DateTime.now().toIso8601String(),
      'stats': _calculateStats(),
      'is_sprint_now': isSprintNow(),
      'current_acceleration': currentAcceleration(),
    };
  }

  Map<String, dynamic> _calculateStats() {
    if (lockedTrack == null) {
      return {
        'total_tracks': 0,
        'total_points': 0,
        'total_distance_m': 0.0,
        'max_speed_kmh': 0.0,
      };
    }

    double totalDistance = 0;
    double maxSpeed = 0;
    final pts = lockedTrack!.points;

    for (final point in pts) {
      maxSpeed = max(maxSpeed, point.speed);
    }

    for (int i = 1; i < pts.length; i++) {
      final p1 = pts[i - 1].position;
      final p2 = pts[i].position;
      final dx = p2.dx - p1.dx;
      final dy = p2.dy - p1.dy;
      totalDistance += sqrt(dx * dx + dy * dy) * _pixelsToMeters;
    }

    return {
      'total_tracks': 1,
      'total_points': pts.length,
      'total_distance_m': totalDistance,
      'max_speed_kmh': maxSpeed,
    };
  }

  // =========================
  // CALIBRATION
  // =========================

  void calibratePixelsToMeters(double knownDistanceMeters, double pixelsDistance) {
    if (pixelsDistance > 0) {
      _pixelsToMeters = knownDistanceMeters / pixelsDistance;
      debugPrint('📏 Calibrated pixelsToMeters = $_pixelsToMeters');
      notifyListeners();
    }
  }

  void autoCalibrateStandardField(double fieldPixelsLength) {
    if (fieldPixelsLength > 0) {
      _pixelsToMeters = 105.0 / fieldPixelsLength;

      debugPrint('📏 Auto calibration (field):');
      debugPrint(
        '   fieldPixelsLength = ${fieldPixelsLength.toStringAsFixed(1)} px',
      );
      debugPrint(
        '   scale = 1px = ${(_pixelsToMeters * 100).toStringAsFixed(1)} cm',
      );

      notifyListeners();
    }
  }

  bool get isCalibrating => false;
  double get currentScale => _pixelsToMeters;
  String get currentScaleText =>
      '1px = ${(_pixelsToMeters * 100).toStringAsFixed(1)}cm';

  // =========================
  // ДОПОЛНИТЕЛЬНЫЕ МЕТОДЫ ДЛЯ НАСТРОЙКИ
  // =========================

  /// Настройка чувствительности слежения
  void setTrackingSensitivity({
    required double positionSmoothFactor, // 0.9-0.99 (выше = быстрее)
    required double speedSmoothFactor,    // 0.7-0.95 (выше = быстрее)
    required double maxJumpDistance,      // в пикселях
    required bool usePrediction,
    required double predictionFactor,     // 0.0-0.5
  }) {
    _positionSmoothFactor = positionSmoothFactor.clamp(0.5, 0.99);
    _speedSmoothFactor = speedSmoothFactor.clamp(0.5, 0.99);
    _maxJumpDistance = maxJumpDistance.clamp(100, 500);
    _usePrediction = usePrediction;
    _predictionFactor = predictionFactor.clamp(0.0, 0.5);
    
    debugPrint('⚙️ Tracking sensitivity updated:');
    debugPrint('   positionSmooth=$_positionSmoothFactor');
    debugPrint('   speedSmooth=$_speedSmoothFactor');
    debugPrint('   maxJump=$_maxJumpDistance');
    debugPrint('   usePrediction=$_usePrediction');
    debugPrint('   predictionFactor=$_predictionFactor');
  }
}

class TrackMotionResult {
  final double speedKmh;
  final double vx;
  final double vy;
  final double ax;
  final double ay;

  const TrackMotionResult({
    required this.speedKmh,
    required this.vx,
    required this.vy,
    required this.ax,
    required this.ay,
  });
}