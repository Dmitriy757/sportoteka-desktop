import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:video_thumbnail/video_thumbnail.dart';

class VideoThumbnailHelper {
  static Future<File?> generateSnapshotFile({
    required String videoUrl,
    required int timeMs,
    int quality = 90,
    int maxWidth = 1280,
  }) async {
    try {
      final tempDir = await getTemporaryDirectory();

      final thumbPath = await VideoThumbnail.thumbnailFile(
        video: videoUrl,
        thumbnailPath: tempDir.path,
        imageFormat: ImageFormat.JPEG,
        timeMs: timeMs,
        quality: quality,
        maxWidth: maxWidth,
      );

      if (thumbPath == null || thumbPath.isEmpty) return null;

      final file = File(thumbPath);
      if (!await file.exists()) return null;

      return file;
    } catch (_) {
      return null;
    }
  }
}