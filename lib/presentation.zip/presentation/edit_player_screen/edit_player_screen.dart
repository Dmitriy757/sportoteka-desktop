import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

// Цветовые константы в том же стиле, что и в профиле
class _AppColors {
  static const Color primaryGreen = Color(0xFF00C853);
  static const Color primaryGradientStart = Color(0xFF00E676);
  static const Color primaryGradientEnd = Color(0xFF00BFA5);
  static const Color background = Color(0xFFF8FAFC);
  static const Color card = Colors.white;
  static const Color textPrimary = Color(0xFF1E293B);
  static const Color textSecondary = Color(0xFF64748B);
  static const Color textTertiary = Color(0xFF94A3B8);
  static const Color error = Color(0xFFEF4444);
  static const Color success = Color(0xFF22C55E);
  static const Color warning = Color(0xFFF59E0B);
  static const Color info = Color(0xFF3B82F6);
  static const Color white = Colors.white;
  static const Color surfaceLight = Color(0xFFF1F5F9);
  static const Color inputBackground = Color(0xFFF8FAFC);
  static const Color borderColor = Color(0xFFE2E8F0);
}

class EditPlayerScreen extends StatefulWidget {
  @override
  State<EditPlayerScreen> createState() => _EditPlayerScreenState();
}

class _EditPlayerScreenState extends State<EditPlayerScreen> with SingleTickerProviderStateMixin {
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController birthDateController = TextEditingController();
  final TextEditingController nationalityController = TextEditingController();
  final TextEditingController positionController = TextEditingController();
  final TextEditingController jerseyNumberController = TextEditingController();

  final Map<String, String> playerStats = {};
  String? selectedMetric;
  final TextEditingController statValueController = TextEditingController();

  File? selectedImage;
  String? uploadedPhotoUrl;

  late Map<String, dynamic> player;

  // Для анимации
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // Список доступных метрик
  final List<String> availableMetrics = [
    'Рост (см)',
    'Вес (кг)',
    'Игры',
    'Голы',
    'Голевые передачи',
    'Жёлтые карточки',
    'Красные карточки',
    'Минуты на поле',
    'Скорость (км/ч)',
    'Выносливость',
    'Сила удара',
    'Точность передач',
  ];

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    _animationController.forward();

    player = Get.arguments as Map<String, dynamic>;

    // Заполнение полей из данных игрока
    if (player.containsKey('first_name') && player.containsKey('last_name')) {
      firstNameController.text = player['first_name'] ?? '';
      lastNameController.text = player['last_name'] ?? '';
    } else if (player.containsKey('fullName')) {
      final parts = player['fullName'].toString().split(' ');
      firstNameController.text = parts.first;
      lastNameController.text = parts.length > 1 ? parts.sublist(1).join(' ') : '';
    }

    birthDateController.text = player['birth_date'] ?? player['birthDate'] ?? '';
    nationalityController.text = player['nationality'] ?? '';
    positionController.text = player['position'] ?? '';
    jerseyNumberController.text = player['jersey_number']?.toString() ?? '';
    uploadedPhotoUrl = player['photo'] ?? player['photo_url'] ?? '';

    // Парсинг спортивных метрик
    if (player['sport_data'] != null) {
      final parts = player['sport_data'].toString().split(',');
      for (var p in parts) {
        final split = p.split(':');
        if (split.length >= 2) {
          playerStats[split[0].trim()] = split.sublist(1).join(':').trim();
        }
      }
    }
  }

  @override
  void dispose() {
    firstNameController.dispose();
    lastNameController.dispose();
    birthDateController.dispose();
    nationalityController.dispose();
    positionController.dispose();
    jerseyNumberController.dispose();
    statValueController.dispose();
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery);
    if (picked != null) {
      setState(() => selectedImage = File(picked.path));
    }
  }

  Future<void> _selectDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2007),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: _AppColors.primaryGreen,
              onPrimary: _AppColors.white,
              surface: _AppColors.white,
              onSurface: _AppColors.textPrimary,
            ),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        birthDateController.text = DateFormat('yyyy-MM-dd').format(picked);
      });
    }
  }

  Future<void> _savePlayer() async {
    final firstName = firstNameController.text.trim();
    final lastName = lastNameController.text.trim();
    final birthDate = birthDateController.text.trim();
    final nationality = nationalityController.text.trim();
    final position = positionController.text.trim();
    final jerseyNumber = int.tryParse(jerseyNumberController.text.trim()) ?? 0;
    final sportData = playerStats.entries.map((e) => "${e.key}: ${e.value}").join(", ");
    final playerId = player['player_id'];

    if ([firstName, lastName, birthDate, nationality].any((e) => e.isEmpty)) {
      Get.snackbar(
        "Ошибка",
        "Заполните все обязательные поля",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: _AppColors.error,
        colorText: _AppColors.white,
        icon: const Icon(Icons.error_outline_rounded, color: _AppColors.white),
      );
      return;
    }

    try {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: CircularProgressIndicator(color: _AppColors.primaryGreen),
        ),
      );

      if (selectedImage != null) {
        final request = http.MultipartRequest(
          'POST',
          Uri.parse('https://sportotekaapp.ru/api/upload_player_photo.php'),
        );
        request.files.add(await http.MultipartFile.fromPath('photo', selectedImage!.path));
        final response = await request.send();
        final body = await response.stream.bytesToString();
        final jsonResp = jsonDecode(body);
        if (jsonResp['status'] == 'success') {
          uploadedPhotoUrl = jsonResp['url'];
        }
      }

      final response = await http.post(
        Uri.parse('https://sportotekaapp.ru/api/update_player.php'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'player_id': playerId,
          'first_name': firstName,
          'last_name': lastName,
          'birth_date': birthDate,
          'nationality': nationality,
          'sport_data': sportData,
          'position': position,
          'jersey_number': jerseyNumber,
          'photo_url': uploadedPhotoUrl ?? '',
        }),
      );

      if (!mounted) return;
      Navigator.of(context).pop(); // закрыть лоадер

      final json = jsonDecode(response.body);
      if (json['status'] == 'success') {
        Get.snackbar(
          "Успех",
          "Данные игрока обновлены",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: _AppColors.success,
          colorText: _AppColors.white,
          icon: const Icon(Icons.check_circle_rounded, color: _AppColors.white),
        );
        await Future.delayed(const Duration(milliseconds: 600));
        if (mounted) {
          Get.back(result: true);
        }
      } else {
        Get.snackbar(
          "Ошибка",
          json['message'] ?? "Не удалось обновить игрока",
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: _AppColors.error,
          colorText: _AppColors.white,
          icon: const Icon(Icons.error_outline_rounded, color: _AppColors.white),
        );
      }
    } catch (e) {
      if (!mounted) return;
      Navigator.of(context).pop();
      Get.snackbar(
        "Ошибка",
        "Произошла ошибка: $e",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: _AppColors.error,
        colorText: _AppColors.white,
        icon: const Icon(Icons.error_outline_rounded, color: _AppColors.white),
      );
    }
  }

  void _addStat() {
    if (selectedMetric != null && statValueController.text.trim().isNotEmpty) {
      setState(() {
        playerStats[selectedMetric!] = statValueController.text.trim();
        selectedMetric = null;
        statValueController.clear();
      });
    } else {
      Get.snackbar(
        "Внимание",
        "Выберите метрику и введите значение",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: _AppColors.warning,
        colorText: _AppColors.white,
      );
    }
  }

  void _removeStat(String key) {
    setState(() {
      playerStats.remove(key);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _AppColors.background,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: _AppColors.textPrimary,
          onPressed: () => Get.back(),
        ),
        title: const Text(
          "Редактировать игрока",
          style: TextStyle(
            fontWeight: FontWeight.w900,
            color: _AppColors.textPrimary,
            fontSize: 18,
          ),
        ),
        centerTitle: false,
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              color: _AppColors.primaryGreen.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: IconButton(
              icon: const Icon(Icons.photo_camera_rounded, color: _AppColors.primaryGreen, size: 20),
              onPressed: _pickImage,
              tooltip: "Изменить фото",
            ),
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                // Секция фото
                _buildPhotoSection(),
                const SizedBox(height: 20),

                // Основная информация
                _buildSection(
                  title: "Основная информация",
                  icon: Icons.person_outline_rounded,
                  children: [
                    _buildStyledTextField(
                      controller: firstNameController,
                      label: "Имя",
                      icon: Icons.person_rounded,
                    ),
                    const SizedBox(height: 12),
                    _buildStyledTextField(
                      controller: lastNameController,
                      label: "Фамилия",
                      icon: Icons.person_rounded,
                    ),
                    const SizedBox(height: 12),
                    _buildStyledTextField(
                      controller: birthDateController,
                      label: "Дата рождения",
                      icon: Icons.cake_rounded,
                      readOnly: true,
                      onTap: _selectDate,
                      suffixIcon: Icons.calendar_today_rounded,
                    ),
                    const SizedBox(height: 12),
                    _buildStyledTextField(
                      controller: nationalityController,
                      label: "Гражданство",
                      icon: Icons.flag_rounded,
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Игровая информация
                _buildSection(
                  title: "Игровая информация",
                  icon: Icons.sports_soccer_rounded,
                  children: [
                    _buildStyledTextField(
                      controller: positionController,
                      label: "Позиция на поле",
                      icon: Icons.sports_handball_rounded,
                    ),
                    const SizedBox(height: 12),
                    _buildStyledTextField(
                      controller: jerseyNumberController,
                      label: "Игровой номер",
                      icon: Icons.format_list_numbered_rounded,
                      isNumber: true,
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Спортивные метрики
                _buildSection(
                  title: "Спортивные метрики",
                  icon: Icons.show_chart_rounded,
                  children: [
                    // Добавление новой метрики
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _AppColors.primaryGreen.withOpacity(0.04),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: _AppColors.primaryGreen.withOpacity(0.1)),
                      ),
                      child: Column(
                        children: [
                          DropdownButtonFormField<String>(
                            value: selectedMetric,
                            isExpanded: true,
                            decoration: InputDecoration(
                              labelText: "Выберите метрику",
                              labelStyle: const TextStyle(color: _AppColors.textSecondary, fontSize: 13),
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12),
                                borderSide: BorderSide.none,
                              ),
                              filled: true,
                              fillColor: _AppColors.white,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                            ),
                            items: availableMetrics.map((m) => DropdownMenuItem(
                              value: m,
                              child: Text(m, style: const TextStyle(fontSize: 13)),
                            )).toList(),
                            onChanged: (v) => setState(() => selectedMetric = v),
                          ),
                          if (selectedMetric != null) ...[
                            const SizedBox(height: 10),
                            Row(
                              children: [
                                Expanded(
                                  child: _buildStyledTextField(
                                    controller: statValueController,
                                    label: "Значение",
                                    icon: Icons.edit_rounded,
                                    noMargin: true,
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    gradient: LinearGradient(
                                      colors: [
                                        _AppColors.primaryGradientStart,
                                        _AppColors.primaryGradientEnd,
                                      ],
                                    ),
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: IconButton(
                                    onPressed: _addStat,
                                    icon: const Icon(Icons.add_rounded, color: _AppColors.white),
                                    style: IconButton.styleFrom(
                                      backgroundColor: Colors.transparent,
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),

                    // Список добавленных метрик
                    if (playerStats.isEmpty)
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: _AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Column(
                          children: [
                            Icon(Icons.analytics_outlined, size: 40, color: _AppColors.textTertiary),
                            const SizedBox(height: 8),
                            Text(
                              "Нет добавленных метрик",
                              style: TextStyle(
                                color: _AppColors.textSecondary,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      )
                    else
                      ...playerStats.entries.map((e) => Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                        decoration: BoxDecoration(
                          color: _AppColors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: _AppColors.borderColor),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 36,
                              height: 36,
                              decoration: BoxDecoration(
                                color: _AppColors.primaryGreen.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                _getMetricIcon(e.key),
                                color: _AppColors.primaryGreen,
                                size: 18,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    e.key,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 12,
                                      color: _AppColors.textSecondary,
                                    ),
                                  ),
                                  Text(
                                    e.value,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.w900,
                                      fontSize: 14,
                                      color: _AppColors.textPrimary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              decoration: BoxDecoration(
                                color: _AppColors.error.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: IconButton(
                                onPressed: () => _removeStat(e.key),
                                icon: const Icon(Icons.close_rounded, size: 16, color: _AppColors.error),
                                padding: EdgeInsets.zero,
                                constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                              ),
                            ),
                          ],
                        ),
                      )).toList(),
                  ],
                ),
                const SizedBox(height: 24),

                // Кнопка сохранения
                Container(
                  width: double.infinity,
                  margin: const EdgeInsets.only(bottom: 16),
                  child: ElevatedButton(
                    onPressed: _savePlayer,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _AppColors.primaryGreen,
                      foregroundColor: _AppColors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                      elevation: 0,
                    ),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.save_rounded, size: 20),
                        SizedBox(width: 8),
                        Text(
                          "Сохранить изменения",
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildPhotoSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _AppColors.card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  _AppColors.primaryGradientStart.withOpacity(0.1),
                  _AppColors.primaryGradientEnd.withOpacity(0.1),
                ],
              ),
              border: Border.all(color: _AppColors.primaryGreen.withOpacity(0.3), width: 2),
            ),
            child: ClipOval(
              child: selectedImage != null
                  ? Image.file(selectedImage!, fit: BoxFit.cover)
                  : (uploadedPhotoUrl?.isNotEmpty == true
                      ? Image.network(uploadedPhotoUrl!, fit: BoxFit.cover)
                      : Container(
                          color: _AppColors.primaryGreen.withOpacity(0.1),
                          child: const Icon(
                            Icons.person_rounded,
                            color: _AppColors.primaryGreen,
                            size: 40,
                          ),
                        )),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  "Фото профиля",
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    color: _AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  "Нажмите на иконку камеры вверху, чтобы изменить фото",
                  style: TextStyle(
                    fontSize: 11,
                    color: _AppColors.textSecondary,
                    height: 1.3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSection({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _AppColors.card,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _AppColors.primaryGreen.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: _AppColors.primaryGreen, size: 18),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontWeight: FontWeight.w900,
                  fontSize: 15,
                  color: _AppColors.textPrimary,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          ...children,
        ],
      ),
    );
  }

  Widget _buildStyledTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool readOnly = false,
    VoidCallback? onTap,
    bool isNumber = false,
    IconData? suffixIcon,
    bool noMargin = false,
  }) {
    return Container(
      margin: noMargin ? null : const EdgeInsets.only(bottom: 0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _AppColors.inputBackground,
      ),
      child: TextField(
        controller: controller,
        readOnly: readOnly,
        onTap: onTap,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        style: const TextStyle(fontSize: 14),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: _AppColors.textSecondary, fontSize: 13),
          prefixIcon: Icon(icon, size: 18, color: _AppColors.primaryGreen),
          suffixIcon: suffixIcon != null
              ? Icon(suffixIcon, size: 16, color: _AppColors.primaryGreen)
              : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: BorderSide(color: _AppColors.primaryGreen.withOpacity(0.5)),
          ),
          filled: true,
          fillColor: _AppColors.inputBackground,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      ),
    );
  }

  IconData _getMetricIcon(String metric) {
    if (metric.contains('Рост')) return Icons.height_rounded;
    if (metric.contains('Вес')) return Icons.monitor_weight_rounded;
    if (metric.contains('Гол')) return Icons.sports_soccer_rounded;
    if (metric.contains('Скорость')) return Icons.speed_rounded;
    if (metric.contains('Выносливость')) return Icons.timer_rounded;
    if (metric.contains('Сила')) return Icons.fitness_center_rounded;
    if (metric.contains('Точность')) return Icons.track_changes_rounded;
    if (metric.contains('карточ')) return Icons.warning_rounded;
    return Icons.trending_up_rounded;
  }
}