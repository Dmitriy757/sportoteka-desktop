import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/core/app_export.dart';

class CreateTeamScreen extends StatefulWidget {
  const CreateTeamScreen({super.key});

  @override
  State<CreateTeamScreen> createState() => _CreateTeamScreenState();
}

class _CreateTeamScreenState extends State<CreateTeamScreen> {
  final TextEditingController teamNameController = TextEditingController();
  String? selectedCategory;
  bool isLoading = false;

  final ImagePicker _picker = ImagePicker();
  File? _logoFile;

  final List<String> sportCategories = [
    'Футбол',
    'Баскетбол',
    'Волейбол',
    'Хоккей',
    'Теннис',
    'Плавание',
    'Гимнастика',
    'Лёгкая атлетика',
    'Прочее',
  ];

  Future<void> _pickLogo() async {
    try {
      final XFile? x = await _picker.pickImage(
        source: ImageSource.gallery,
        maxWidth: 1200,
        imageQuality: 85,
      );
      if (x == null) return;

      setState(() {
        _logoFile = File(x.path);
      });
    } catch (e) {
      Get.snackbar("Ошибка", "Не удалось выбрать логотип: $e");
    }
  }

  Future<void> createTeam() async {
    final teamName = teamNameController.text.trim();
    final coachId = await PrefUtils.getUserId();

    if (teamName.isEmpty || coachId == null) {
      Get.snackbar("Ошибка", "Введите название команды и авторизуйтесь как тренер");
      return;
    }

    setState(() => isLoading = true);

    final uri = Uri.parse('https://sportotekaapp.ru/api/create_team.php');

    try {
      // ✅ multipart, чтобы можно было отправлять файл
      final req = http.MultipartRequest('POST', uri);

      // поля (обычные form-data)
      req.fields['team_name'] = teamName;
      req.fields['coach_id'] = coachId.toString();

      if (selectedCategory != null && selectedCategory!.isNotEmpty) {
        req.fields['category'] = selectedCategory!;
      }

      // файл логотипа (опционально)
      if (_logoFile != null && await _logoFile!.exists()) {
        final fileName = p.basename(_logoFile!.path);
        req.files.add(
          await http.MultipartFile.fromPath(
            'logo', // ✅ имя поля (на сервере так и читаем)
            _logoFile!.path,
            filename: fileName,
          ),
        );
      }

      final streamed = await req.send();
      final body = await streamed.stream.bytesToString();

      Map<String, dynamic> json;
      try {
        json = jsonDecode(body) as Map<String, dynamic>;
      } catch (_) {
        throw Exception("Сервер вернул не JSON: $body");
      }

      if (json['status'] == 'success') {
        final teamId = json['team_id'];
        await PrefUtils.setTeamId(teamId);

        Get.snackbar("Успех", "Команда создана!");
        Get.toNamed(AppRoutes.myTeamScreen);
      } else {
        Get.snackbar("Ошибка", (json["message"] ?? "Не удалось создать команду").toString());
      }
    } catch (e) {
      Get.snackbar("Ошибка", "Ошибка подключения: $e");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  @override
  void dispose() {
    teamNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final blue = const Color(0xFF1E74C4);

    return Scaffold(
      appBar: AppBar(
        title: const Text("Создание команды", style: TextStyle(color: Colors.white)),
        backgroundColor: blue,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Container(
        color: const Color(0xFFF5F7FA),
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // CARD
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(16),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.10),
                      blurRadius: 12,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    // ✅ Логотип команды
                    Row(
                      children: [
                        GestureDetector(
                          onTap: isLoading ? null : _pickLogo,
                          child: Container(
                            width: 76,
                            height: 76,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: blue.withOpacity(0.08),
                              border: Border.all(color: blue.withOpacity(0.18)),
                            ),
                            child: ClipOval(
                              child: _logoFile != null
                                  ? Image.file(_logoFile!, fit: BoxFit.cover)
                                  : Icon(Icons.photo_camera_rounded, color: blue, size: 30),
                            ),
                          ),
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const Text(
                                "Логотип команды",
                                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                _logoFile != null ? "Выбран файл" : "Нажмите, чтобы выбрать (необязательно)",
                                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                              ),
                              const SizedBox(height: 8),
                              if (_logoFile != null)
                                TextButton(
                                  onPressed: isLoading
                                      ? null
                                      : () => setState(() => _logoFile = null),
                                  child: const Text("Убрать"),
                                ),
                            ],
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 18),

                    TextField(
                      controller: teamNameController,
                      decoration: InputDecoration(
                        labelText: "Название команды",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    DropdownButtonFormField<String>(
                      value: selectedCategory,
                      items: [
                        const DropdownMenuItem<String>(
                          value: null,
                          child: Text("Не выбрано"),
                        ),
                        ...sportCategories.map(
                          (category) => DropdownMenuItem<String>(
                            value: category,
                            child: Text(category),
                          ),
                        ),
                      ],
                      onChanged: isLoading
                          ? null
                          : (value) {
                              setState(() {
                                selectedCategory = value;
                              });
                            },
                      decoration: InputDecoration(
                        labelText: "Категория спорта (необязательно)",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 28),

              SizedBox(
                width: double.infinity,
                height: 56,
                child: ElevatedButton(
                  onPressed: isLoading ? null : createTeam,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: blue,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                  child: isLoading
                      ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.6),
                        )
                      : const Text(
                          "Создать команду",
                          style: TextStyle(fontSize: 18, color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
