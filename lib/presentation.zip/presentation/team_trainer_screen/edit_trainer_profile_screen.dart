import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:sportoteka/core/utils/media_utils.dart';

class EditTrainerProfileScreen extends StatefulWidget {
  final int trainerId;
  final String trainerName;

  const EditTrainerProfileScreen({
    super.key,
    required this.trainerId,
    required this.trainerName,
  });

  @override
  State<EditTrainerProfileScreen> createState() => _EditTrainerProfileScreenState();
}

class _EditTrainerProfileScreenState extends State<EditTrainerProfileScreen> {
  static const String apiBase = "https://sportotekaapp.ru/api";
  static const String getUrl = "$apiBase/get_trainer_profile.php";
  static const String saveUrl = "$apiBase/update_trainer_profile.php";

  bool loading = true;
  bool saving = false;
  String? error;

  final TextEditingController positionC = TextEditingController();
  final TextEditingController birthdayC = TextEditingController(); // YYYY-MM-DD
  final TextEditingController experienceC = TextEditingController();
  final TextEditingController bioC = TextEditingController();

  // ✅ Фото
  String? photoUrl; // то confirmation URL для Image.network
  File? photoFile;
  XFile? newPhotoFile;

  Map<String, dynamic> _decode(http.Response resp) {
    try {
      final j = json.decode(resp.body);
      if (j is Map<String, dynamic>) return j;
    } catch (_) {}
    return {"status": "error", "message": "bad json", "raw": resp.body};
  }

  String _asStr(dynamic v) => (v ?? "").toString();

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    positionC.dispose();
    birthdayC.dispose();
    experienceC.dispose();
    bioC.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      final resp = await http.post(
        Uri.parse(getUrl),
        headers: const {"Content-Type": "application/json; charset=utf-8"},
        body: jsonEncode({"trainer_id": widget.trainerId}),
      );

      final data = _decode(resp);

      if (data["status"] == "success" && data["trainer"] is Map) {
        final t = Map<String, dynamic>.from(data["trainer"]);

        positionC.text = _asStr(t["position"]).trim();
        bioC.text = _asStr(t["bio"]).trim();
        experienceC.text = _asStr(t["experience"]).trim();

        // birthday может прийти как "2026-02-04" или "2026-02-04 00:00:00"
        final b = _asStr(t["birthday"]).trim();
        birthdayC.text = (b.length >= 10) ? b.substring(0, 10) : b;

        // ✅ фото (может быть /uploads/... или полный URL)
        final rawPhoto = _asStr(t["photo"]).trim();
        photoUrl = MediaUtils.normalizeUrl(rawPhoto);

        if (mounted) setState(() => loading = false);
      } else {
        if (!mounted) return;
        setState(() {
          loading = false;
          error = _asStr(data["message"]).isEmpty ? "Не удалось загрузить" : _asStr(data["message"]);
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = "Ошибка загрузки: $e";
      });
    }
  }

  Future<void> _pickPhoto() async {
    final picker = ImagePicker();
    final XFile? x = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 85,
      maxWidth: 1200,
    );
    if (x == null) return;

    setState(() {
      newPhotoFile = x;
      photoFile = File(x.path);
    });
  }

  Future<void> _pickBirthday() async {
    DateTime initial = DateTime(2000, 1, 1);

    final raw = birthdayC.text.trim();
    if (raw.length >= 10) {
      final y = int.tryParse(raw.substring(0, 4));
      final m = int.tryParse(raw.substring(5, 7));
      final d = int.tryParse(raw.substring(8, 10));
      if (y != null && m != null && d != null) {
        initial = DateTime(y, m, d);
      }
    }

    final picked = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: DateTime(1940, 1, 1),
      lastDate: DateTime(DateTime.now().year + 1, 12, 31),
    );

    if (picked == null) return;
    final yyyy = picked.year.toString().padLeft(4, "0");
    final mm = picked.month.toString().padLeft(2, "0");
    final dd = picked.day.toString().padLeft(2, "0");
    birthdayC.text = "$yyyy-$mm-$dd";
    setState(() {});
  }

  bool _validBirthday(String s) {
    if (s.trim().isEmpty) return true;
    final r = RegExp(r'^\d{4}-\d{2}-\d{2}$');
    return r.hasMatch(s.trim());
  }

  Future<void> _save() async {
    final birthday = birthdayC.text.trim();
    if (!_validBirthday(birthday)) {
      Get.snackbar(
        "Дата рождения",
        "Формат должен быть YYYY-MM-DD (например 2008-05-17)",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
      return;
    }

    setState(() => saving = true);

    try {
      final uri = Uri.parse(saveUrl);
      final req = http.MultipartRequest("POST", uri);

      req.fields["trainer_id"] = widget.trainerId.toString();
      req.fields["position"] = positionC.text.trim();
      req.fields["birthday"] = birthday;
      req.fields["experience"] = experienceC.text.trim();
      req.fields["bio"] = bioC.text.trim();

      // ✅ фото (если выбрали)
      if (newPhotoFile != null) {
        req.files.add(await http.MultipartFile.fromPath(
          "photo", // должно совпасть с PHP: $_FILES['photo']
          newPhotoFile!.path,
        ));
      }

      final streamed = await req.send();
      final resp = await http.Response.fromStream(streamed);
      final data = _decode(resp);

      if (data["status"] == "success" || data["success"] == true) {
        // ✅ обновим фото без перезахода
        final p = _asStr(data["photo"]).trim();
        if (p.isNotEmpty) {
          photoUrl = MediaUtils.normalizeUrl(p) ?? photoUrl;
        }
        newPhotoFile = null;

        Get.snackbar(
          "Готово",
          "Визитка сохранена ✅",
          snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(12),
        );

        if (mounted) Navigator.pop(context, true);
      } else {
        Get.snackbar(
          "Ошибка",
          _asStr(data["message"]).isEmpty ? "Не удалось сохранить" : _asStr(data["message"]),
          snackPosition: SnackPosition.BOTTOM,
          margin: const EdgeInsets.all(12),
        );
      }
    } catch (e) {
      Get.snackbar(
        "Сеть",
        "Ошибка: $e",
        snackPosition: SnackPosition.BOTTOM,
        margin: const EdgeInsets.all(12),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bg = const Color(0xFFF3F5F8);
    final primary = Theme.of(context).colorScheme.primary;

    return Scaffold(
      backgroundColor: bg,
      appBar: AppBar(
        backgroundColor: bg,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        title: const Text(
          "Визитка тренера",
          style: TextStyle(fontWeight: FontWeight.w900, color: Colors.black),
        ),
        iconTheme: const IconThemeData(color: Colors.black87),
        actions: [
          IconButton(
            tooltip: "Обновить",
            onPressed: saving ? null : _load,
            icon: const Icon(Icons.refresh_rounded, color: Colors.black87),
          ),
          const SizedBox(width: 6),
        ],
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 14),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: (loading || saving) ? null : _save,
              icon: saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.save_outlined, color: Colors.white),
              label: Text(
                saving ? "Сохраняю..." : "Сохранить",
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900),
              ),
              style: ElevatedButton.styleFrom(
                backgroundColor: primary,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
          ),
        ),
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? _ErrorView(text: error!, onRetry: _load)
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                  children: [
                    _TrainerPhotoHeader(
                      name: widget.trainerName,
                      trainerId: widget.trainerId,
                      photoUrl: photoUrl,
                      photoFile: photoFile,
                      onPick: saving ? null : _pickPhoto,
                    ),
                    const SizedBox(height: 12),

                    const _SectionTitle("Данные профиля"),
                    const SizedBox(height: 8),

                    _Card(
                      child: Column(
                        children: [
                          _Field(
                            label: "Должность / позиция",
                            hint: "Например: Главный тренер, Тренер по ОФП",
                            controller: positionC,
                          ),
                          const SizedBox(height: 10),
                          _DateField(
                            label: "Дата рождения",
                            hint: "YYYY-MM-DD",
                            controller: birthdayC,
                            onPick: _pickBirthday,
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 12),
                    const _SectionTitle("Опыт / карьера"),
                    const SizedBox(height: 8),

                    _Card(
                      child: _MultilineField(
                        label: "Опыт",
                        hint: "Коротко: клубы, категории, лицензии, стаж и т.д.",
                        controller: experienceC,
                        minLines: 3,
                        maxLines: 6,
                      ),
                    ),

                    const SizedBox(height: 12),
                    const _SectionTitle("Описание (Bio)"),
                    const SizedBox(height: 8),

                    _Card(
                      child: _MultilineField(
                        label: "Описание",
                        hint: "О себе, подход к работе, специализация…",
                        controller: bioC,
                        minLines: 4,
                        maxLines: 10,
                      ),
                    ),
                  ],
                ),
    );
  }
}

// ---------------- UI widgets ----------------

class _TrainerPhotoHeader extends StatelessWidget {
  final String name;
  final int trainerId;
  final String? photoUrl;
  final File? photoFile;
  final VoidCallback? onPick;

  const _TrainerPhotoHeader({
    required this.name,
    required this.trainerId,
    required this.photoUrl,
    required this.photoFile,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    final primary = Theme.of(context).colorScheme.primary;

    Widget avatar() {
      if (photoFile != null) {
        return ClipOval(
          child: Image.file(photoFile!, width: 56, height: 56, fit: BoxFit.cover),
        );
      }
      if (photoUrl != null && photoUrl!.trim().isNotEmpty) {
        return ClipOval(
          child: Image.network(
            photoUrl!.trim(),
            width: 56,
            height: 56,
            fit: BoxFit.cover,
            errorBuilder: (_, __, ___) => _fallback(primary),
          ),
        );
      }
      return _fallback(primary);
    }

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: LinearGradient(
          colors: [primary.withOpacity(0.95), primary.withOpacity(0.55)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 18,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Stack(
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white.withOpacity(0.55), width: 2),
                ),
                child: avatar(),
              ),
              if (onPick != null)
                Positioned(
                  right: 0,
                  bottom: 0,
                  child: InkWell(
                    onTap: onPick,
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.12),
                            blurRadius: 10,
                            offset: const Offset(0, 6),
                          ),
                        ],
                      ),
                      child: Icon(Icons.camera_alt_outlined, size: 16, color: primary),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name.isEmpty ? "Тренер #$trainerId" : name,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16),
                ),
                const SizedBox(height: 4),
                Text(
                  "Нажмите на камеру, чтобы сменить фото",
                  style: TextStyle(color: Colors.white.withOpacity(0.9), fontWeight: FontWeight.w700),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  static Widget _fallback(Color primary) {
    return Container(
      color: Colors.white.withOpacity(0.18),
      child: const Center(
        child: Icon(Icons.person_outline, color: Colors.white),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.1,
        color: Color(0xFF6B7280),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 14,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: child,
    );
  }
}

class _Field extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;

  const _Field({
    required this.label,
    required this.hint,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      textInputAction: TextInputAction.next,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
      ),
    );
  }
}

class _MultilineField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final int minLines;
  final int maxLines;

  const _MultilineField({
    required this.label,
    required this.hint,
    required this.controller,
    required this.minLines,
    required this.maxLines,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      minLines: minLines,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
      ),
    );
  }
}

class _DateField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final VoidCallback onPick;

  const _DateField({
    required this.label,
    required this.hint,
    required this.controller,
    required this.onPick,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      readOnly: true,
      onTap: onPick,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        border: const OutlineInputBorder(),
        suffixIcon: IconButton(
          icon: const Icon(Icons.calendar_month_outlined),
          onPressed: onPick,
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String text;
  final VoidCallback onRetry;
  const _ErrorView({required this.text, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, size: 44),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: onRetry, child: const Text("Повторить")),
          ],
        ),
      ),
    );
  }
}
