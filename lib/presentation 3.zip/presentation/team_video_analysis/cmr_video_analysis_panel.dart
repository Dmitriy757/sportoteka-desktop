// lib/presentation/team_video_analysis/cmr_video_analysis_panel.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/team_video_analysis/team_video_analysis_screen.dart';
import 'package:sportoteka/presentation/team_video_analysis/video_match_review_screen.dart';

class CmrVideoAnalysisPanel extends StatefulWidget {
  final int teamId;
  final String teamName;
  final int clubId;
  final String clubName;

  const CmrVideoAnalysisPanel({
    super.key,
    required this.teamId,
    required this.teamName,
    required this.clubId,
    required this.clubName,
  });

  @override
  State<CmrVideoAnalysisPanel> createState() => _CmrVideoAnalysisPanelState();
}

class _CmrVideoAnalysisPanelState extends State<CmrVideoAnalysisPanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';
  static const String getMatchesUrl = '$apiBase/get_team_matches.php';
  static const String getTeamProfileUrl = '$apiBase/get_team_profile.php';
  static const String deleteVideoUrl = '$apiBase/delete_team_match_video.php';
  static const String deleteMatchUrl = '$apiBase/delete_team_match.php';

  final TextEditingController searchCtrl = TextEditingController();

  bool loading = true;
  bool refreshing = false;
  bool actionLoading = false;
  String? error;

  int coachId = 0;
  String actualTeamName = '';

  List<Map<String, dynamic>> matches = [];
  List<Map<String, dynamic>> filtered = [];
  Map<String, dynamic>? selectedMatch;

  @override
  void initState() {
    super.initState();
    searchCtrl.addListener(_applySearch);
    _init();
  }

  @override
  void dispose() {
    searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    coachId = await PrefUtils.getUserId() ?? 0;
    await _loadTeamProfile();
    await _loadMatches(initial: true);
  }

  Future<void> _loadTeamProfile() async {
    try {
      final response = await http
          .post(
            Uri.parse(getTeamProfileUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'team_id': widget.teamId}),
          )
          .timeout(const Duration(seconds: 12));

      final data = _decode(response.body);
      final ok =
          data is Map && (data['success'] == true || data['status'] == 'success');

      if (ok && data['team'] is Map) {
        final team = Map<String, dynamic>.from(data['team']);
        final serverName = _s(team['name']);
        if (serverName.isNotEmpty && mounted) {
          setState(() => actualTeamName = serverName);
        }
      }
    } catch (_) {}
  }

  Future<void> _loadMatches({bool initial = false}) async {
    if (!mounted) return;

    setState(() {
      if (initial) {
        loading = true;
      } else {
        refreshing = true;
      }
      error = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse(getMatchesUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'team_id': widget.teamId}),
          )
          .timeout(const Duration(seconds: 20));

      final data = _decode(response.body);

      if (data is Map && data['success'] == true && data['matches'] is List) {
        matches = (data['matches'] as List)
            .whereType<Map>()
            .map((e) => Map<String, dynamic>.from(e))
            .toList();
      } else {
        matches = [];
      }

      matches.sort((a, b) => _s(b['match_date']).compareTo(_s(a['match_date'])));
      _applySearch(silent: true);

      final oldId = _asInt(selectedMatch?['id']);
      Map<String, dynamic>? next;

      if (oldId > 0) {
        for (final m in filtered) {
          if (_asInt(m['id']) == oldId) {
            next = m;
            break;
          }
        }
      }

      next ??= filtered.isNotEmpty ? filtered.first : null;

      if (!mounted) return;

      setState(() {
        selectedMatch = next;
        loading = false;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        loading = false;
        refreshing = false;
        error = '$e';
      });
    }
  }

  void _applySearch({bool silent = false}) {
    final q = searchCtrl.text.trim().toLowerCase();

    final list = q.isEmpty
        ? List<Map<String, dynamic>>.from(matches)
        : matches.where((item) {
            final title = _matchTitle(item).toLowerCase();
            final opponent = _s(item['opponent']).toLowerCase();
            final tournament = _s(item['tournament']).toLowerCase();
            final date = _s(item['match_date']).toLowerCase();

            return title.contains(q) ||
                opponent.contains(q) ||
                tournament.contains(q) ||
                date.contains(q);
          }).toList();

    if (silent || !mounted) {
      filtered = list;
      return;
    }

    setState(() {
      filtered = list;
      if (filtered.isNotEmpty && selectedMatch == null) {
        selectedMatch = filtered.first;
      }
    });
  }

  Future<void> _deleteVideo(Map<String, dynamic> item) async {
    final matchId = _asInt(item['id']);
    if (matchId <= 0) return;

    final ok = await Get.dialog<bool>(
      AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text(
          'Удалить видео?',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        content: Text('Видео матча «${_matchTitle(item)}» будет удалено.'),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(foregroundColor: _C.red),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    setState(() => actionLoading = true);

    try {
      final response = await http
          .post(
            Uri.parse(deleteVideoUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'match_id': matchId, 'team_id': widget.teamId}),
          )
          .timeout(const Duration(seconds: 14));

      final data = _decode(response.body);

      if (data is! Map || data['success'] != true) {
        throw data is Map
            ? (data['message'] ?? 'Не удалось удалить видео')
            : 'Не удалось удалить видео';
      }

      await _loadMatches();
      Get.snackbar('Готово', 'Видео удалено');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => actionLoading = false);
    }
  }

  Future<void> _deleteMatch(Map<String, dynamic> item) async {
    final matchId = _asInt(item['id']);
    if (matchId <= 0) return;

    final ok = await Get.dialog<bool>(
      AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: const Text(
          'Удалить матч?',
          style: TextStyle(fontWeight: FontWeight.w900),
        ),
        content: Text('Матч «${_matchTitle(item)}» будет удалён.'),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(foregroundColor: _C.red),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    setState(() => actionLoading = true);

    try {
      final response = await http
          .post(
            Uri.parse(deleteMatchUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'match_id': matchId, 'team_id': widget.teamId}),
          )
          .timeout(const Duration(seconds: 14));

      final data = _decode(response.body);

      if (data is! Map || data['success'] != true) {
        throw data is Map
            ? (data['message'] ?? 'Не удалось удалить матч')
            : 'Не удалось удалить матч';
      }

      selectedMatch = null;
      await _loadMatches();
      Get.snackbar('Готово', 'Матч удалён');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => actionLoading = false);
    }
  }

  void _openFullModule() {
    Get.to(() => TeamVideoAnalysisScreen(
          teamId: widget.teamId,
          teamName: _displayTeamName,
          clubId: widget.clubId,
          clubName: widget.clubName,
        ));
  }

  void _openReview(Map<String, dynamic> item) {
    final matchId = _asInt(item['id']);
    final videoUrl = _normalizeUrl(_s(item['video_url'])) ?? '';

    if (matchId <= 0) {
      Get.snackbar('Видеоанализ', 'Некорректный match_id');
      return;
    }

    if (videoUrl.isEmpty) {
      Get.snackbar('Видеоанализ', 'Сначала загрузите видео матча');
      return;
    }

    Get.to(() => VideoMatchReviewScreen(
          matchId: matchId,
          teamId: widget.teamId,
          teamName: _displayTeamName,
          coachId: coachId,
          matchTitle: _matchTitle(item),
          videoUrl: videoUrl,
          videoId: matchId,
        ));
  }

  String get _displayTeamName {
    final server = actualTeamName.trim();
    if (server.isNotEmpty && !RegExp(r'^Команда\s+\d+$').hasMatch(server)) {
      return server;
    }

    final passed = widget.teamName.trim();
    if (passed.isNotEmpty && !RegExp(r'^Команда\s+\d+$').hasMatch(passed)) {
      return passed;
    }

    return 'Команда';
  }

  int _asInt(dynamic value) {
    if (value is int) return value;
    if (value is num) return value.toInt();
    return int.tryParse('${value ?? 0}') ?? 0;
  }

  String _s(dynamic value) {
    final text = '${value ?? ''}'.trim();
    return text == 'null' ? '' : text;
  }

  dynamic _decode(String body) {
    final trimmed = body.trim();
    final startObj = trimmed.indexOf('{');
    final startArr = trimmed.indexOf('[');
    final starts = [startObj, startArr].where((e) => e >= 0).toList();
    if (starts.isEmpty) return {};
    final start = starts.reduce((a, b) => a < b ? a : b);
    return jsonDecode(trimmed.substring(start));
  }

  String _matchTitle(Map<String, dynamic> item) {
    final explicit = _s(item['title']);
    if (explicit.isNotEmpty) return explicit;

    final opponent = _s(item['opponent']);
    final home = _s(item['home_team']);
    final away = _s(item['away_team']);

    if (home.isNotEmpty || away.isNotEmpty) {
      return '${home.isEmpty ? _displayTeamName : home} — ${away.isEmpty ? opponent : away}';
    }

    if (opponent.isNotEmpty) return 'Матч с $opponent';
    return 'Матч #${_asInt(item['id'])}';
  }

  String _score(Map<String, dynamic> item) {
    final score = _s(item['score']);
    if (score.isNotEmpty) return score;

    final home = _s(item['home_score']);
    final away = _s(item['away_score']);

    if (home.isNotEmpty || away.isNotEmpty) {
      return '${home.isEmpty ? '0' : home}:${away.isEmpty ? '0' : away}';
    }

    return '—';
  }

  String _date(Map<String, dynamic> item) {
    final d = _s(item['match_date']);
    if (d.length >= 10) return d.substring(0, 10);
    return d.isEmpty ? 'Дата не указана' : d;
  }

  String _videoStatus(Map<String, dynamic> item) {
    final video = _normalizeUrl(_s(item['video_url']));
    if (video != null && video.isNotEmpty) return 'Видео загружено';
    return 'Видео не загружено';
  }

  String? _normalizeUrl(String raw) {
    final value = raw.trim();
    if (value.isEmpty || value == 'null') return null;
    if (value.startsWith('http://') || value.startsWith('https://')) return value;
    if (value.startsWith('/')) return '$apiBase$value';
    return '$apiBase/$value';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return _LoadingCard(teamName: widget.teamName);
    }

    if (error != null) {
      return _EmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить видеоанализ',
        text: error!,
        actionText: 'Повторить',
        onAction: () => _loadMatches(initial: true),
      );
    }

    return Stack(
      children: [
        Row(
          children: [
            SizedBox(width: 420, child: _buildLeftColumn()),
            const SizedBox(width: 12),
            Expanded(child: _buildDetails()),
          ],
        ),
        if (refreshing || actionLoading)
          const Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: LinearProgressIndicator(
              minHeight: 3,
              color: _C.black,
              backgroundColor: _C.active,
            ),
          ),
      ],
    );
  }

  Widget _buildLeftColumn() {
    final withVideo =
        matches.where((m) => _normalizeUrl(_s(m['video_url'])) != null).length;

    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(18, 18, 18, 14),
            child: Column(
              children: [
                Row(
                  children: [
                    const _IconBox(icon: Icons.analytics_rounded),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _displayTeamName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _C.title.copyWith(fontSize: 19),
                          ),
                          const SizedBox(height: 4),
                          const Text(
                            'Видеоанализ команды',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: _C.muted,
                              fontWeight: FontWeight.w700,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _HeaderIconButton(
                      icon: Icons.refresh_rounded,
                      onTap: () => _loadMatches(),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Row(
                  children: [
                    Expanded(
                      child: _HeroStat(
                        value: '${matches.length}',
                        title: 'матчей',
                        icon: Icons.sports_soccer_rounded,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _HeroStat(
                        value: '$withVideo',
                        title: 'с видео',
                        icon: Icons.videocam_rounded,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _HeroStat(
                        value: '${matches.length - withVideo}',
                        title: 'без видео',
                        icon: Icons.videocam_off_rounded,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: Column(
              children: [
                TextField(
                  controller: searchCtrl,
                  style: const TextStyle(
                    color: _C.text,
                    fontWeight: FontWeight.w700,
                    fontSize: 14,
                  ),
                  decoration: InputDecoration(
                    hintText: 'Поиск по матчу, сопернику, турниру',
                    hintStyle: const TextStyle(color: _C.muted),
                    prefixIcon: const Icon(Icons.search_rounded, color: _C.muted),
                    suffixIcon: searchCtrl.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              searchCtrl.clear();
                              _applySearch();
                            },
                            icon: const Icon(Icons.close_rounded, color: _C.muted),
                          ),
                    filled: true,
                    fillColor: _C.soft,
                    contentPadding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 13,
                    ),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: const BorderSide(color: _C.black, width: 1.2),
                    ),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _ToolButton(
                        icon: Icons.open_in_new_rounded,
                        text: 'Полный модуль',
                        onTap: _openFullModule,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _ToolButton(
                        icon: Icons.cloud_upload_outlined,
                        text: 'Загрузка видео',
                        onTap: _openFullModule,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: _C.border),
          Expanded(
            child: filtered.isEmpty
                ? const _MiniEmpty(text: 'Матчи не найдены')
                : ListView.separated(
                    padding: const EdgeInsets.all(14),
                    itemCount: filtered.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, index) {
                      final item = filtered[index];
                      final active =
                          _asInt(item['id']) == _asInt(selectedMatch?['id']);

                      return _MatchTile(
                        title: _matchTitle(item),
                        date: _date(item),
                        score: _score(item),
                        tournament: _s(item['tournament']),
                        hasVideo: _normalizeUrl(_s(item['video_url'])) != null,
                        active: active,
                        onTap: () => setState(() => selectedMatch = item),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildDetails() {
    final item = selectedMatch;

    if (item == null) {
      return _EmptyState(
        icon: Icons.video_library_outlined,
        title: 'Выберите матч',
        text:
            'Слева выберите матч, чтобы открыть видео, статистику и действия внутри CMR.',
        actionText: 'Открыть полный модуль',
        onAction: _openFullModule,
      );
    }

    final videoUrl = _normalizeUrl(_s(item['video_url']));
    final hasVideo = videoUrl != null && videoUrl.isNotEmpty;
    final notes = _s(item['notes']);
    final tournament = _s(item['tournament']);
    final location = _s(item['location']);
    final thumbnail = _normalizeUrl(
      _s(item['thumbnail_url'] ?? item['preview_url'] ?? item['image']),
    );

    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(18),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _ThumbBox(url: thumbnail, hasVideo: hasVideo),
                const SizedBox(width: 16),
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 92),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _matchTitle(item),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: _C.title.copyWith(fontSize: 22),
                        ),
                        const SizedBox(height: 10),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            _LightChip(text: _date(item)),
                            _LightChip(text: 'Счёт ${_score(item)}'),
                            _LightChip(
                              text: hasVideo ? 'Видео загружено' : 'Без видео',
                            ),
                            if (tournament.isNotEmpty) _LightChip(text: tournament),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                SizedBox(
                  width: 156,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _HeaderButton(
                        icon: Icons.play_circle_outline_rounded,
                        text: 'Анализ',
                        onTap: () => _openReview(item),
                      ),
                      const SizedBox(height: 8),
                      _HeaderButton(
                        icon: Icons.open_in_new_rounded,
                        text: 'Полный экран',
                        onTap: _openFullModule,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: _C.border),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _InfoCard(
                        title: 'Дата матча',
                        value: _date(item),
                        icon: Icons.calendar_today_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Счёт',
                        value: _score(item),
                        icon: Icons.scoreboard_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Видео',
                        value: _videoStatus(item),
                        icon: Icons.video_file_rounded,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _InfoCard(
                        title: 'Турнир',
                        value: tournament.isEmpty ? '—' : tournament,
                        icon: Icons.emoji_events_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Локация',
                        value: location.isEmpty ? '—' : location,
                        icon: Icons.place_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'ID матча',
                        value: '${_asInt(item['id'])}',
                        icon: Icons.tag_rounded,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _SectionCard(
                  title: 'Видео матча',
                  icon: Icons.ondemand_video_rounded,
                  child: hasVideo
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              videoUrl,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: _C.muted,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            const SizedBox(height: 12),
                            Row(
                              children: [
                                Expanded(
                                  child: _PrimaryButton(
                                    text: 'Открыть AI-анализ',
                                    icon: Icons.analytics_rounded,
                                    onTap: () => _openReview(item),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                _DangerButton(
                                  text: 'Удалить видео',
                                  icon: Icons.delete_outline_rounded,
                                  onTap: () => _deleteVideo(item),
                                ),
                              ],
                            ),
                          ],
                        )
                      : Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Видео ещё не загружено. Для загрузки открой полный модуль.',
                              style: TextStyle(
                                color: _C.text,
                                fontWeight: FontWeight.w700,
                                height: 1.45,
                              ),
                            ),
                            const SizedBox(height: 12),
                            _PrimaryButton(
                              text: 'Загрузить видео',
                              icon: Icons.cloud_upload_outlined,
                              onTap: _openFullModule,
                            ),
                          ],
                        ),
                ),
                const SizedBox(height: 12),
                _SectionCard(
                  title: 'Заметки тренера',
                  icon: Icons.notes_rounded,
                  child: Text(
                    notes.isEmpty ? 'Заметки пока не заполнены.' : notes,
                    style: const TextStyle(
                      color: _C.text,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      height: 1.45,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                _SectionCard(
                  title: 'Быстрые действия',
                  icon: Icons.tune_rounded,
                  child: Wrap(
                    spacing: 10,
                    runSpacing: 10,
                    children: [
                      _ActionPill(
                        icon: Icons.play_circle_outline_rounded,
                        text: 'Видеоразбор',
                        onTap: () => _openReview(item),
                      ),
                      _ActionPill(
                        icon: Icons.cloud_upload_outlined,
                        text: 'Загрузить видео',
                        onTap: _openFullModule,
                      ),
                      _ActionPill(
                        icon: Icons.refresh_rounded,
                        text: 'Обновить',
                        onTap: () => _loadMatches(),
                      ),
                      _ActionPill(
                        icon: Icons.delete_outline_rounded,
                        text: 'Удалить матч',
                        danger: true,
                        onTap: () => _deleteMatch(item),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _C {
  static const Color black = Color(0xFF111111);
  static const Color bg = Color(0xFFF7F7F7);
  static const Color card = Colors.white;
  static const Color soft = Color(0xFFF5F5F5);
  static const Color active = Color(0xFFE8E8E8);
  static const Color text = Color(0xFF111111);
  static const Color muted = Color(0xFF777777);
  static const Color border = Color(0xFFE0E0E0);
  static const Color red = Color(0xFFDC2626);

  static BoxDecoration get cardDecoration => BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.026),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      );

  static const TextStyle title = TextStyle(
    color: text,
    fontSize: 18,
    fontWeight: FontWeight.w900,
    height: 1.15,
  );
}

class _LoadingCard extends StatelessWidget {
  final String teamName;

  const _LoadingCard({required this.teamName});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          const LinearProgressIndicator(
            minHeight: 3,
            color: _C.black,
            backgroundColor: _C.active,
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const _IconBox(
                    icon: Icons.analytics_rounded,
                    size: 76,
                    iconSize: 38,
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    'Загружаем видеоанализ',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Матчи, видео и данные команды ${teamName.isEmpty ? '' : '«$teamName»'}',
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: _C.muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 22),
                  const SizedBox(
                    width: 42,
                    height: 42,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      color: _C.black,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IconBox extends StatelessWidget {
  final IconData icon;
  final double size;
  final double iconSize;

  const _IconBox({
    required this.icon,
    this.size = 52,
    this.iconSize = 26,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(size * .34),
        border: Border.all(color: _C.border),
      ),
      child: Icon(icon, color: _C.black, size: iconSize),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;
  final IconData icon;

  const _HeroStat({
    required this.value,
    required this.title,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 74,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(icon, color: _C.black, size: 20),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 18,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.muted,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ToolButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _ToolButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _C.black, size: 18),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _HeaderIconButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Icon(icon, color: _C.black),
      ),
    );
  }
}

class _MatchTile extends StatelessWidget {
  final String title;
  final String date;
  final String score;
  final String tournament;
  final bool hasVideo;
  final bool active;
  final VoidCallback onTap;

  const _MatchTile({
    required this.title,
    required this.date,
    required this.score,
    required this.tournament,
    required this.hasVideo,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final line = [
      date,
      'счёт $score',
      if (tournament.isNotEmpty) tournament,
    ].join(' • ');

    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: active ? _C.active : _C.soft,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? const Color(0xFFD0D0D0) : _C.border),
        ),
        child: Row(
          children: [
            _IconBox(
              icon: hasVideo
                  ? Icons.play_circle_fill_rounded
                  : Icons.sports_soccer_rounded,
              size: 48,
              iconSize: 25,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: _C.title.copyWith(fontSize: 14.5),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    line,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.muted,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              hasVideo ? Icons.videocam_rounded : Icons.videocam_off_rounded,
              color: _C.muted,
            ),
          ],
        ),
      ),
    );
  }
}

class _ThumbBox extends StatelessWidget {
  final String? url;
  final bool hasVideo;

  const _ThumbBox({
    required this.url,
    required this.hasVideo,
  });

  @override
  Widget build(BuildContext context) {
    final hasUrl = url != null && url!.isNotEmpty;

    return Container(
      width: 92,
      height: 92,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.border),
      ),
      child: hasUrl
          ? Image.network(
              url!,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Icon(
                hasVideo ? Icons.play_circle_fill_rounded : Icons.video_library_outlined,
                color: _C.black,
                size: 42,
              ),
            )
          : Icon(
              hasVideo ? Icons.play_circle_fill_rounded : Icons.video_library_outlined,
              color: _C.black,
              size: 42,
            ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _InfoCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minHeight: 76),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: _C.black, size: 21),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.muted,
                      fontSize: 11.5,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    value,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.text,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
class _SectionCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final Widget child;

  const _SectionCard({
    required this.title,
    required this.icon,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: _C.black, size: 20),
              const SizedBox(width: 9),
              Text(title, style: _C.title.copyWith(fontSize: 16)),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }
}

class _LightChip extends StatelessWidget {
  final String text;

  const _LightChip({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: _C.soft,
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: _C.border),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: _C.text,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _HeaderButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          color: _C.black,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 7),
            Expanded(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 12.5,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  const _PrimaryButton({
    required this.text,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(text),
      style: ElevatedButton.styleFrom(
        backgroundColor: _C.black,
        foregroundColor: Colors.white,
        elevation: 0,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _DangerButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback onTap;

  const _DangerButton({
    required this.text,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(text),
      style: OutlinedButton.styleFrom(
        foregroundColor: _C.red,
        side: const BorderSide(color: Color(0xFFFECACA)),
        minimumSize: const Size(158, 52),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontWeight: FontWeight.w900),
      ),
    );
  }
}

class _ActionPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool danger;

  const _ActionPill({
    required this.icon,
    required this.text,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final bg = danger ? const Color(0xFFFFF1F2) : _C.soft;
    final border = danger ? const Color(0xFFFECACA) : _C.border;
    final color = danger ? _C.red : _C.text;

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: border),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 8),
            Text(
              text,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.w900,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniEmpty extends StatelessWidget {
  final String text;

  const _MiniEmpty({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: _C.muted,
            fontWeight: FontWeight.w700,
            height: 1.4,
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String? actionText;
  final VoidCallback? onAction;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.text,
    this.actionText,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _IconBox(icon: icon, size: 72, iconSize: 36),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: _C.title.copyWith(fontSize: 22),
              ),
              const SizedBox(height: 8),
              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _C.muted,
                  height: 1.45,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (actionText != null && onAction != null) ...[
                const SizedBox(height: 18),
                SizedBox(
                  width: 230,
                  child: _PrimaryButton(
                    text: actionText!,
                    icon: Icons.open_in_new_rounded,
                    onTap: onAction!,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
