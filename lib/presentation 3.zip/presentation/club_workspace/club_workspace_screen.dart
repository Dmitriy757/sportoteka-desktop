// lib/presentation/club_workspace/club_workspace_screen.dart
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/chat_screen/chat_screen.dart';
import 'package:sportoteka/presentation/club_trainers/club_trainers_screen.dart';
import 'package:sportoteka/presentation/club_trainers/team_trainers_screen.dart';
import 'package:sportoteka/presentation/player_game_zone/create_challenge_screen.dart';
import 'package:sportoteka/presentation/player_game_zone/create_quiz_screen.dart';
import 'package:sportoteka/presentation/player_game_zone/team_challenges_screen.dart';
import 'package:sportoteka/presentation/player_game_zone/team_quizzes_screen.dart';
import 'package:sportoteka/presentation/manager_mode/screens/manager_dashboard_screen.dart';
import 'package:sportoteka/presentation/plans/plan_folders_screen.dart';
import 'package:sportoteka/presentation/team_calendar_screen/team_calendar_screen.dart';
import 'package:sportoteka/presentation/team_description_screen/team_description_screen.dart';
import 'package:sportoteka/presentation/team_matches_screen/team_matches_screen.dart';
import 'package:sportoteka/presentation/team_roster_screen/team_roster_screen.dart';
import 'package:sportoteka/presentation/team_screen/team_dashboard_screen.dart';
import 'package:sportoteka/presentation/team_video_analysis/team_video_analysis_screen.dart';
import 'package:sportoteka/presentation/training_graphics/training_graphics_screen.dart';
import 'package:sportoteka/presentation/video_lessons/video_lessons_screen.dart';
import 'package:sportoteka/routes/app_routes.dart';
import 'package:sportoteka/presentation/plans/cmr_plans_panel.dart';
import 'package:sportoteka/presentation/team_calendar_screen/cmr_calendar_panel.dart';
import 'package:sportoteka/presentation/team_video_analysis/cmr_video_analysis_panel.dart';
import 'package:sportoteka/presentation/team_attendance_screen/cmr_attendance_panel.dart';
import 'package:sportoteka/presentation/team_matches_screen/cmr_team_matches_panel.dart';

enum ClubSection {
  overview,
  teams,
  teamDashboard,
  roster,
  trainers,
  teamTrainers,
  playerProfile,
  matches,
  calendar,
  trainings,
  plans,
  graphics,
  videoAnalysis,
  description,
  chat,
  videoLessons,
  attendance,
  challenges,
  challengeCreate,
  quizzes,
  quizCreate,
  rating,
  manager,
  miniGames,
  medical,
  parents,
  settings,
}

class ClubWorkspaceScreen extends StatefulWidget {
  const ClubWorkspaceScreen({super.key});

  @override
  State<ClubWorkspaceScreen> createState() => _ClubWorkspaceScreenState();
}

class _ClubWorkspaceScreenState extends State<ClubWorkspaceScreen>
    with SingleTickerProviderStateMixin {
  static const String apiBase = 'https://sportotekaapp.ru/api';
  static const String getClubProfileUrl = '$apiBase/get_club_profile.php';
  static const String getClubTeamsUrl = '$apiBase/get_club_teams.php';
  static const String getClubTrainersUrl = '$apiBase/get_club_trainers.php';
  static const String getTeamTrainersUrl = '$apiBase/get_team_trainers.php';
  static const String getClubEventsUrl = '$apiBase/get_club_events.php';
  static const String getPlayersUrl = '$apiBase/get_players.php';
  static const String updateClubProfileUrl = '$apiBase/update_club_profile.php';
  static const String updateTeamProfileUrl = '$apiBase/update_team_profile.php';

  int currentUserId = 0;
  int clubId = 0;

  bool loading = true;
  bool refreshing = false;
  bool loadingPlayers = false;
  String? error;

  String clubName = 'Клуб';
  String? clubLogo;
  String clubDescription = '';
  bool savingProfile = false;

  List<Map<String, dynamic>> teams = [];
  List<Map<String, dynamic>> trainers = [];
  List<Map<String, dynamic>> events = [];
  List<Map<String, dynamic>> players = [];

  int? selectedTeamId;
  String selectedTeamName = 'Команда не выбрана';
  Map<String, dynamic>? selectedTeam;
  Map<String, dynamic>? selectedPlayer;

  ClubSection selectedSection = ClubSection.overview;

  late final AnimationController _introController;
  bool _introStarted = false;
  bool _introFinished = false;

  @override
  void initState() {
    super.initState();

    _introController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2650),
    );

    _introController.addStatusListener((status) {
      if (status == AnimationStatus.completed && mounted) {
        setState(() => _introFinished = true);
      }
    });

    _boot();
  }

  @override
  void dispose() {
    _introController.dispose();
    super.dispose();
  }

  Future<void> _boot() async {
    currentUserId = await PrefUtils.getUserId() ?? 0;
    clubId = currentUserId;
    await _loadAll(initial: true);
  }

  Future<void> _loadAll({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      if (initial) loading = true;
      refreshing = !initial;
      error = null;
    });

    await _safeLoad(_loadClubProfile);
    await _safeLoad(_loadTeams);
    await _safeLoad(_loadTrainers);
    await _safeLoad(_loadEvents);

    if (selectedTeamId == null && teams.isNotEmpty) {
      await _selectTeam(teams.first, openTeam: false);
    }

    if (!mounted) return;
    setState(() {
      loading = false;
      refreshing = false;
    });

    if (!_introStarted) {
      _introStarted = true;
      _introController.forward(from: 0);
    }
  }

  Future<void> _safeLoad(Future<void> Function() loader) async {
    try {
      await loader();
    } catch (_) {}
  }

  Future<void> _loadClubProfile() async {
    // Важно: этот экран должен работать с тем же club_id, что и старый
    // ClubDashboardScreen. Поэтому профиль клуба грузим через POST club_id
    // и НЕ перезаписываем clubId из ответа: в некоторых ответах поле id
    // может быть id записи/пользователя, из-за чего тренеры считались как 0.
    final response = await http
        .post(Uri.parse(getClubProfileUrl), body: {'club_id': clubId.toString()})
        .timeout(const Duration(seconds: 10));

    final data = _decode(response.body);
    if (data is Map && data['success'] == true) {
      final raw = data['club'] ?? data['data'] ?? data;
      if (raw is Map) {
        clubName = _asString(raw['club_name']) ??
            _asString(raw['name']) ??
            _asString(raw['title']) ??
            clubName;

        clubLogo = _asString(raw['photo']) ??
            _asString(raw['logo']) ??
            _asString(raw['logo_url']) ??
            _asString(raw['avatar']) ??
            clubLogo;

        clubDescription = _asString(raw['club_description']) ??
            _asString(raw['description']) ??
            _asString(raw['about']) ??
            clubDescription;
      }
    }
  }

  Future<void> _loadTeams() async {
    final response = await http
        .post(Uri.parse(getClubTeamsUrl), body: {'club_id': clubId.toString()})
        .timeout(const Duration(seconds: 10));

    final data = _decode(response.body);

    if (data is Map && data['success'] == true && data['teams'] is List) {
      teams = List<Map<String, dynamic>>.from(
        (data['teams'] as List).map((e) => Map<String, dynamic>.from(e)),
      );
    } else {
      teams = _extractList(data, keys: const ['teams', 'data', 'items']);
    }
  }

  Future<void> _loadTrainers() async {
    // 1) Сначала пробуем прямой список тренеров клуба, как в ClubTrainersScreen.
    // 2) Если сервер вместо JSON отдаёт HTML/404, берём тренеров из рабочих
    //    экранов состава: get_team_trainers.php по каждой команде клуба.
    trainers = [];

    if (clubId <= 0) {
      debugPrint('Club workspace trainers skipped: club_id is empty');
      return;
    }

    try {
      final resp = await http
          .post(
            Uri.parse(getClubTrainersUrl),
            body: {'club_id': clubId.toString()},
          )
          .timeout(const Duration(seconds: 10));

      final data = _tryDecodeJson(resp.body);
      if (data != null) {
        final list = _extractTrainersList(data);
        if (list.isNotEmpty) {
          trainers = _uniqueTrainers(list);
          debugPrint(
            'Club workspace trainers loaded from club endpoint '
            'club_id=$clubId count=${trainers.length}',
          );
          return;
        }
      } else {
        debugPrint(
          'Club workspace trainers club endpoint returned non-json '
          'club_id=$clubId status=${resp.statusCode}: ${_shortBody(resp.body)}',
        );
      }
    } catch (e) {
      debugPrint('Club workspace trainers club endpoint error club_id=$clubId: $e');
    }

    // Fallback: в team_roster_screen.dart тренеры команды грузятся именно так:
    // POST get_team_trainers.php { team_id: ... } -> trainers[]
    final byTeams = await _loadTrainersFromTeams();
    trainers = _uniqueTrainers(byTeams);
    debugPrint(
      'Club workspace trainers loaded from teams fallback '
      'club_id=$clubId teams=${teams.length} count=${trainers.length}',
    );
  }

  Future<List<Map<String, dynamic>>> _loadTrainersFromTeams() async {
    if (teams.isEmpty) return [];

    final result = <Map<String, dynamic>>[];

    for (final team in teams) {
      final teamId = _asInt(team['id'] ?? team['team_id'] ?? team['teamId']);
      if (teamId <= 0) continue;

      try {
        final resp = await http
            .post(
              Uri.parse(getTeamTrainersUrl),
              headers: const {'Content-Type': 'application/json; charset=utf-8'},
              body: jsonEncode({'team_id': teamId}),
            )
            .timeout(const Duration(seconds: 8));

        dynamic data = _tryDecodeJson(resp.body);

        // Если сервер принимает только form body, пробуем второй вариант.
        if (data == null || _extractTrainersList(data).isEmpty) {
          final formResp = await http
              .post(
                Uri.parse(getTeamTrainersUrl),
                body: {'team_id': teamId.toString()},
              )
              .timeout(const Duration(seconds: 8));
          data = _tryDecodeJson(formResp.body);
          if (data == null) {
            debugPrint(
              'Club workspace team trainers non-json '
              'team_id=$teamId status=${formResp.statusCode}: ${_shortBody(formResp.body)}',
            );
          }
        }

        final list = _extractTrainersList(data);
        for (final t in list) {
          final item = Map<String, dynamic>.from(t);
          item['team_id'] = item['team_id'] ?? teamId;
          item['teamId'] = item['teamId'] ?? teamId;
          item['team_name'] = item['team_name'] ??
              item['teamName'] ??
              _asString(team['name']) ??
              _asString(team['team_name']) ??
              _asString(team['title']) ??
              'Команда';
          result.add(item);
        }
      } catch (e) {
        debugPrint('Club workspace team trainers error team_id=$teamId: $e');
      }
    }

    return result;
  }

  List<Map<String, dynamic>> _uniqueTrainers(List<Map<String, dynamic>> list) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];

    for (final raw in list) {
      final item = Map<String, dynamic>.from(raw);
      final key = _trainerUniqueKey(item);
      if (seen.add(key)) out.add(item);
    }

    return out;
  }

  String _trainerUniqueKey(Map<String, dynamic> t) {
    final id = _asInt(
      t['trainer_id'] ??
          t['trainerId'] ??
          t['coach_id'] ??
          t['coachId'] ??
          t['user_id'] ??
          t['userId'] ??
          t['id'],
    );
    if (id > 0) return 'id:$id';

    final email = (_asString(t['email']) ?? '').trim().toLowerCase();
    if (email.isNotEmpty) return 'email:$email';

    final name = [
      _asString(t['first_name']),
      _asString(t['last_name']),
      _asString(t['name']),
      _asString(t['full_name']),
    ].whereType<String>().join('|').trim().toLowerCase();
    return name.isNotEmpty ? 'name:$name' : 'raw:${jsonEncode(t)}';
  }

  Future<void> _loadEvents() async {
    final response = await http
        .get(Uri.parse('$getClubEventsUrl?club_id=$clubId'))
        .timeout(const Duration(seconds: 10));
    events = _extractList(
      _decode(response.body),
      keys: const ['events', 'data', 'items'],
    );
  }

  Future<void> _loadPlayersForTeam(int teamId) async {
    if (!mounted) return;

    setState(() {
      loadingPlayers = true;
      players = [];
      selectedPlayer = null;
    });

    try {
      final response = await http
          .post(
            Uri.parse(getPlayersUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({'team_id': teamId}),
          )
          .timeout(const Duration(seconds: 12));

      debugPrint('Club workspace get_players JSON team_id=$teamId');
      debugPrint('Club workspace get_players response=${response.body}');

      final data = jsonDecode(response.body);
      final ok = data is Map &&
          (data['status'] == 'success' || data['success'] == true);
      final loaded = ok
          ? List<Map<String, dynamic>>.from(data['players'] ?? []).map((p) {
              p['team_id'] = teamId;
              p['teamId'] = teamId;
              p['club_id'] = clubId;
              p['clubId'] = clubId;
              p['team_name'] = selectedTeamName;
              p['teamName'] = selectedTeamName;
              return p;
            }).toList()
          : <Map<String, dynamic>>[];

      if (!mounted) return;
      setState(() {
        players = loaded;
        selectedPlayer = loaded.isNotEmpty ? loaded.first : null;
        loadingPlayers = false;
      });

      // Если игроков нет, не показываем всплывающие окна — пустое состояние есть в списке.
    } catch (e) {
      if (!mounted) return;
      setState(() {
        players = [];
        selectedPlayer = null;
        loadingPlayers = false;
      });
      debugPrint('Club workspace players load error: $e');
    }
  }

  Future<void> _selectTeam(Map<String, dynamic> team,
      {bool openTeam = false}) async {
    final id = _asInt(
        team['id'] ?? team['team_id'] ?? team['teamId'] ?? team['teamID']);

    if (!mounted) return;
    setState(() {
      selectedTeam = team;
      selectedTeamId = id;
      selectedTeamName = _asString(team['name']) ??
          _asString(team['team_name']) ??
          _asString(team['title']) ??
          'Команда';
      if (openTeam) selectedSection = ClubSection.teamDashboard;
    });

    if (id > 0) {
      await _loadPlayersForTeam(id);
    } else {
      Get.snackbar('Команда', 'У выбранной команды нет корректного ID');
    }
  }

  Map<String, dynamic> _playerArgs(Map<String, dynamic> player) {
    final mp = Map<String, dynamic>.from(player);

    mp['team_id'] = selectedTeamId ?? mp['team_id'] ?? mp['teamId'];
    mp['teamId'] = selectedTeamId ?? mp['teamId'] ?? mp['team_id'];
    mp['club_id'] = clubId;
    mp['clubId'] = clubId;
    mp['team_name'] = selectedTeamName;
    mp['teamName'] = selectedTeamName;

    return mp;
  }

  void _openPlayer(Map<String, dynamic> player) {
    final mp = _playerArgs(player);

    setState(() {
      selectedPlayer = mp;
      selectedSection = ClubSection.roster;
    });
  }

  void _openPlayerProfile(Map<String, dynamic> player) {
    final mp = _playerArgs(player);

    setState(() {
      selectedPlayer = mp;
    });

    Get.toNamed(
      AppRoutes.playerProfileScreen,
      arguments: mp,
    );
  }


  Future<void> _openEditClubDialog() async {
    final nameCtrl = TextEditingController(text: clubName);
    final descCtrl = TextEditingController(text: clubDescription);
    XFile? pickedLogo;
    final picker = ImagePicker();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 18,
                  right: 18,
                  top: 14,
                  bottom: 18 + MediaQuery.of(context).viewInsets.bottom,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 46,
                        height: 5,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5E7EB),
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    const Text(
                      'Редактирование клуба',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w900,
                        color: _C.text,
                      ),
                    ),
                    const SizedBox(height: 14),
                    InkWell(
                      onTap: () async {
                        final x = await picker.pickImage(
                          source: ImageSource.gallery,
                          imageQuality: 85,
                          maxWidth: 1400,
                        );
                        if (x != null) setSheetState(() => pickedLogo = x);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _C.soft,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _C.border),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 28,
                              backgroundColor: Colors.white,
                              backgroundImage: pickedLogo != null
                                  ? FileImage(File(pickedLogo!.path))
                                  : (clubLogo != null && clubLogo!.isNotEmpty
                                      ? NetworkImage(clubLogo!) as ImageProvider
                                      : null),
                              child: pickedLogo == null &&
                                      (clubLogo == null || clubLogo!.isEmpty)
                                  ? const Icon(Icons.shield_rounded,
                                      color: _C.primaryGreen)
                                  : null,
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Логотип клуба',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: _C.text)),
                                  SizedBox(height: 3),
                                  Text('Нажмите, чтобы заменить изображение',
                                      style: TextStyle(
                                          color: _C.muted,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12)),
                                ],
                              ),
                            ),
                            const Icon(Icons.edit_rounded, color: _C.primaryGreen),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: nameCtrl,
                      decoration: InputDecoration(
                        labelText: 'Название клуба',
                        filled: true,
                        fillColor: _C.soft,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: descCtrl,
                      maxLines: 3,
                      decoration: InputDecoration(
                        labelText: 'Описание клуба',
                        filled: true,
                        fillColor: _C.soft,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: savingProfile
                          ? null
                          : () async {
                              await _saveClubProfile(
                                name: nameCtrl.text.trim(),
                                description: descCtrl.text.trim(),
                                logo: pickedLogo,
                              );
                              if (mounted) Navigator.pop(context);
                            },
                      icon: const Icon(Icons.save_rounded, color: Colors.white),
                      label: const Text('Сохранить',
                          style: TextStyle(color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _C.primaryGreen,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _saveClubProfile({
    required String name,
    required String description,
    XFile? logo,
  }) async {
    if (name.isEmpty) {
      Get.snackbar('Клуб', 'Введите название клуба');
      return;
    }
    if (!mounted) return;
    setState(() => savingProfile = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse(updateClubProfileUrl));
      req.fields['club_id'] = clubId.toString();
      req.fields['club_name'] = name;
      req.fields['name'] = name;
      req.fields['club_description'] = description;
      req.fields['description'] = description;
      if (logo != null) {
        req.files.add(await http.MultipartFile.fromPath('club_logo', logo.path));
      }
      final streamed = await req.send().timeout(const Duration(seconds: 20));
      final resp = await http.Response.fromStream(streamed);
      final data = _decode(resp.body);
      final ok = data is Map && (data['success'] == true || data['status'] == 'success');
      if (ok) {
        final raw = data is Map ? (data['club'] ?? data['data']) : null;
        setState(() {
          clubName = name;
          clubDescription = description;
          if (raw is Map) {
            clubLogo = _asString(raw['logo']) ??
                _asString(raw['logo_url']) ??
                _asString(raw['photo']) ??
                _asString(raw['avatar']) ??
                clubLogo;
          }
        });
        await _loadClubProfile();
        Get.snackbar('Готово', 'Данные клуба обновлены');
      } else {
        Get.snackbar('Ошибка', data is Map ? '${data['message'] ?? data['error'] ?? 'Не удалось сохранить'}' : 'Не удалось сохранить');
      }
    } catch (e) {
      Get.snackbar('Сеть', 'Ошибка сохранения: $e');
    } finally {
      if (mounted) setState(() => savingProfile = false);
    }
  }

  Future<void> _openEditTeamDialog() async {
    if (!_hasTeam || selectedTeam == null) {
      Get.snackbar('Команда', 'Сначала выберите команду');
      return;
    }

    final nameCtrl = TextEditingController(text: selectedTeamName);
    final categoryCtrl = TextEditingController(
      text: _asString(selectedTeam?['category'] ?? selectedTeam?['sport'] ?? selectedTeam?['age_group']) ?? 'Футбол',
    );
    final oldLogo = _asString(selectedTeam?['logo'] ?? selectedTeam?['logo_url'] ?? selectedTeam?['photo']);
    XFile? pickedLogo;
    final picker = ImagePicker();

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
      ),
      builder: (_) {
        return StatefulBuilder(
          builder: (context, setSheetState) {
            return SafeArea(
              top: false,
              child: Padding(
                padding: EdgeInsets.only(
                  left: 18,
                  right: 18,
                  top: 14,
                  bottom: 18 + MediaQuery.of(context).viewInsets.bottom,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 46,
                        height: 5,
                        decoration: BoxDecoration(
                          color: const Color(0xFFE5E7EB),
                          borderRadius: BorderRadius.circular(999),
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Row(
                      children: const [
                        _IconBadge(icon: Icons.tune_rounded, size: 46, iconSize: 23),
                        SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Редактирование команды',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900,
                                      color: _C.text)),
                              SizedBox(height: 3),
                              Text('Название, категория и логотип команды',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w700,
                                      color: _C.muted)),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    InkWell(
                      onTap: () async {
                        final x = await picker.pickImage(
                          source: ImageSource.gallery,
                          imageQuality: 85,
                          maxWidth: 1400,
                        );
                        if (x != null) setSheetState(() => pickedLogo = x);
                      },
                      borderRadius: BorderRadius.circular(18),
                      child: Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: _C.soft,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: _C.border),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 28,
                              backgroundColor: Colors.white,
                              backgroundImage: pickedLogo != null
                                  ? FileImage(File(pickedLogo!.path))
                                  : (oldLogo != null && oldLogo.isNotEmpty
                                      ? NetworkImage(oldLogo) as ImageProvider
                                      : null),
                              child: pickedLogo == null &&
                                      (oldLogo == null || oldLogo.isEmpty)
                                  ? const Icon(Icons.groups_2_rounded,
                                      color: _C.primaryGreen)
                                  : null,
                            ),
                            const SizedBox(width: 12),
                            const Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Логотип команды',
                                      style: TextStyle(
                                          fontWeight: FontWeight.w900,
                                          color: _C.text)),
                                  SizedBox(height: 3),
                                  Text('Нажмите, чтобы заменить изображение',
                                      style: TextStyle(
                                          color: _C.muted,
                                          fontWeight: FontWeight.w600,
                                          fontSize: 12)),
                                ],
                              ),
                            ),
                            const Icon(Icons.edit_rounded, color: _C.primaryGreen),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: nameCtrl,
                      decoration: InputDecoration(
                        labelText: 'Название команды',
                        filled: true,
                        fillColor: _C.soft,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: categoryCtrl,
                      decoration: InputDecoration(
                        labelText: 'Категория / вид спорта',
                        filled: true,
                        fillColor: _C.soft,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    ElevatedButton.icon(
                      onPressed: savingProfile
                          ? null
                          : () async {
                              await _saveSelectedTeamProfile(
                                name: nameCtrl.text.trim(),
                                category: categoryCtrl.text.trim(),
                                logo: pickedLogo,
                              );
                              if (mounted) Navigator.pop(context);
                            },
                      icon: const Icon(Icons.save_rounded, color: Colors.white),
                      label: const Text('Сохранить',
                          style: TextStyle(color: Colors.white)),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _C.primaryGreen,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _saveSelectedTeamProfile({
    required String name,
    required String category,
    XFile? logo,
  }) async {
    if (!_hasTeam) return;
    if (name.isEmpty) {
      Get.snackbar('Команда', 'Введите название команды');
      return;
    }
    if (!mounted) return;
    setState(() => savingProfile = true);
    try {
      final req = http.MultipartRequest('POST', Uri.parse(updateTeamProfileUrl));
      req.fields['team_id'] = selectedTeamId.toString();
      req.fields['team_name'] = name;
      req.fields['name'] = name;
      req.fields['category'] = category.isEmpty ? 'Футбол' : category;
      if (logo != null) {
        req.files.add(await http.MultipartFile.fromPath('logo', logo.path));
      }
      final streamed = await req.send().timeout(const Duration(seconds: 20));
      final resp = await http.Response.fromStream(streamed);
      final data = _decode(resp.body);
      final ok = data is Map && (data['success'] == true || data['status'] == 'success');
      if (ok) {
        setState(() {
          selectedTeamName = name;
          selectedTeam = {
            ...?selectedTeam,
            'name': name,
            'team_name': name,
            'category': category.isEmpty ? 'Футбол' : category,
          };
        });
        await _loadTeams();
        if (selectedTeamId != null && selectedTeamId! > 0) {
          await _loadPlayersForTeam(selectedTeamId!);
        }
        Get.snackbar('Готово', 'Данные команды обновлены');
      } else {
        Get.snackbar('Ошибка', data is Map ? '${data['message'] ?? data['error'] ?? 'Не удалось сохранить'}' : 'Не удалось сохранить');
      }
    } catch (e) {
      Get.snackbar('Сеть', 'Ошибка сохранения: $e');
    } finally {
      if (mounted) setState(() => savingProfile = false);
    }
  }

  void _openGameModule(ClubSection section) {
    final isGameSection = section == ClubSection.challengeCreate ||
        section == ClubSection.challenges ||
        section == ClubSection.quizCreate ||
        section == ClubSection.quizzes ||
        section == ClubSection.rating ||
        section == ClubSection.manager;

    if (isGameSection && !_hasTeam) {
      Get.snackbar('Команда', 'Сначала выберите команду');
      return;
    }

    final args = {
      'team_id': selectedTeamId,
      'teamId': selectedTeamId,
      'user_id': currentUserId,
      'team_name': selectedTeamName,
    };
    switch (section) {
      case ClubSection.challengeCreate:
        Get.to(() => const CreateChallengeScreen(), arguments: args);
        break;
      case ClubSection.challenges:
        Get.to(() => const TeamChallengesScreen(), arguments: args);
        break;
      case ClubSection.quizCreate:
        Get.to(() => const CreateQuizScreen(), arguments: args);
        break;
      case ClubSection.quizzes:
        Get.to(() => const TeamQuizzesScreen(), arguments: args);
        break;
      case ClubSection.rating:
        Get.toNamed(AppRoutes.teamRatingScreen, arguments: args);
        break;
      case ClubSection.manager:
        Get.to(() => ManagerDashboardScreen(
              teamId: selectedTeamId!,
              userId: currentUserId,
              teamName: selectedTeamName,
            ));
        break;
      default:
        setState(() => selectedSection = section);
    }
  }

  void _openCreateTeam() async {
    await Get.toNamed(AppRoutes.createTeamScreen);
    _loadAll();
  }

  void _openFullTeamDashboard() {
    if (!_hasTeam) return;
    Get.to(() => TeamDashboardScreen(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        ));
  }


  Future<void> _openClubTrainersScreen() async {
    await Get.to(() => ClubTrainersScreen(
          clubId: clubId,
          clubName: clubName,
        ));
    await _safeLoad(_loadTrainers);
    if (mounted) setState(() {});
  }

  Future<void> _openTeamTrainersScreen() async {
    if (!_hasTeam) {
      Get.snackbar('Команда', 'Сначала выберите активную команду');
      return;
    }

    await Get.to(() => TeamTrainersScreen(
          clubId: clubId,
          clubName: clubName,
          teams: teams,
          clubLogoUrl: clubLogo,
        ));

    await _safeLoad(_loadTrainers);
    if (selectedTeamId != null && selectedTeamId! > 0) {
      await _safeLoad(() => _loadPlayersForTeam(selectedTeamId!));
    }
    if (mounted) setState(() {});
  }

  void _openFullRosterScreen() {
    if (!_hasTeam) return;
    Get.to(() =>
        TeamRosterScreen(teamId: selectedTeamId!, teamName: selectedTeamName));
  }

  void _openFullMatches() {
    if (!_hasTeam) return;
    Get.to(() => const TeamMatchesScreen(), arguments: {
      'teamId': selectedTeamId,
      'teamName': selectedTeamName,
    });
  }

  void _openFullCalendar() {
    if (!_hasTeam) return;
    Get.to(() =>
        TeamCalendarScreen(teamId: selectedTeamId!, teamName: selectedTeamName));
  }

  void _openFullPlans() {
    Get.to(() => PlanFoldersScreen(
          clubId: clubId,
          clubName: clubName,
          teamId: selectedTeamId,
          selectMode: false,
          browsePlansMode: false,
        ));
  }

  void _openFullGraphics() {
    Get.to(() => TrainingGraphicsScreen(
          teamId: selectedTeamId,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        ));
  }

  void _openFullVideoAnalysis() {
    if (!_hasTeam) return;
    Get.to(() => TeamVideoAnalysisScreen(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        ));
  }

  void _openFullTeamDescription() {
    if (!_hasTeam) return;
    Get.to(() => const TeamDescriptionScreen(), arguments: selectedTeamId);
  }

  void _openFullChat() {
    final userId = currentUserId > 0 ? currentUserId : clubId;
    Get.to(() => ChatScreen(userId: userId));
  }

  void _openFullVideoLessons() {
    final userId = currentUserId > 0 ? currentUserId : clubId;
    Get.to(() => VideoLessonsScreen(
          ownerUserId: userId,
          ownerName: clubName,
          isMyMode: true,
          embedded: false,
        ));
  }

  bool get _hasTeam => selectedTeamId != null && selectedTeamId! > 0;

  dynamic _decode(String body) {
    final data = _tryDecodeJson(body);
    if (data != null) return data;
    return <String, dynamic>{};
  }

  dynamic _tryDecodeJson(String body) {
    final raw = body.trim();
    if (raw.isEmpty) return null;

    // Быстрый отсев HTML-ответов: 404, PHP warning page, редирект и т.п.
    final lower = raw.length > 80 ? raw.substring(0, 80).toLowerCase() : raw.toLowerCase();
    if (lower.startsWith('<!doctype') || lower.startsWith('<html')) {
      return null;
    }

    try {
      return jsonDecode(raw);
    } catch (_) {
      // Иногда сервер добавляет warning/notice до или после JSON.
      final startObj = raw.indexOf('{');
      final startArr = raw.indexOf('[');
      final starts = [startObj, startArr].where((e) => e >= 0).toList();
      if (starts.isEmpty) return null;

      final start = starts.reduce(math.min);
      final startedWithObject = start == startObj || startArr < 0;
      final end = startedWithObject ? raw.lastIndexOf('}') : raw.lastIndexOf(']');
      if (end <= start) return null;

      final sliced = raw.substring(start, end + 1).trim();
      try {
        return jsonDecode(sliced);
      } catch (_) {
        return null;
      }
    }
  }

  String _shortBody(String body, {int max = 180}) {
    final oneLine = body.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (oneLine.length <= max) return oneLine;
    return '${oneLine.substring(0, max)}…';
  }

  List<Map<String, dynamic>> _extractList(dynamic data,
      {required List<String> keys}) {
    dynamic raw = data;
    if (data is Map) {
      for (final key in keys) {
        if (data[key] is List) {
          raw = data[key];
          break;
        }
      }
    }
    if (raw is! List) return [];
    return raw
        .whereType<Map>()
        .map((e) => Map<String, dynamic>.from(e))
        .toList();
  }

  List<Map<String, dynamic>> _extractTrainersList(dynamic data) {
    // Основной рабочий формат: { success: true, trainers: [...] }
    final direct = _extractList(
      data,
      keys: const ['trainers', 'coaches', 'users', 'items', 'data', 'result'],
    );
    if (direct.isNotEmpty) return direct;

    // Частые вложенные форматы: { data: { trainers: [...] } }
    if (data is Map) {
      for (final key in const ['data', 'result', 'response', 'payload']) {
        final nested = data[key];
        if (nested is Map) {
          final list = _extractList(
            nested,
            keys: const ['trainers', 'coaches', 'users', 'items', 'data'],
          );
          if (list.isNotEmpty) return list;
        }
      }
    }

    return [];
  }

  int _asInt(dynamic value) {
    if (value is int) return value;
    if (value is double) return value.round();
    return int.tryParse('${value ?? 0}') ?? 0;
  }

  String? _asString(dynamic value) {
    final text = '${value ?? ''}'.trim();
    return text.isEmpty || text == 'null' ? null : text;
  }

  bool _isTablet(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return math.min(size.width, size.height) >= 600;
  }

  bool _isLandscape(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return size.width > size.height;
  }

  double _getResponsiveFontSize(BuildContext context, double baseSize) {
    final width = MediaQuery.of(context).size.width;
    if (width < 360) return baseSize * 0.7;
    if (width < 400) return baseSize * 0.8;
    if (width < 600) return baseSize * 0.9;
    if (width < 900) return baseSize * 0.95;
    return baseSize;
  }

  double _getResponsivePadding(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width < 360) return 10.0;
    if (width < 400) return 12.0;
    if (width < 600) return 14.0;
    return 16.0;
  }

  void _handleWorkspaceBack() {
    if (selectedSection != ClubSection.overview) {
      setState(() => selectedSection = ClubSection.overview);
      return;
    }

    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    } else {
      Get.back();
    }
  }

  @override
  Widget build(BuildContext context) {
    final tablet = _isTablet(context);
    final landscape = _isLandscape(context);

    if (loading) {
      return const Scaffold(
        backgroundColor: _C.bg,
        body: Center(child: CircularProgressIndicator(color: _C.primaryGreen)),
      );
    }

    if (tablet && !landscape) {
      return _RotateTabletHint(clubName: clubName, clubLogo: clubLogo);
    }

    if (tablet && landscape) return _buildWorkspace();
    return _buildMobileVersion();
  }

  Widget _buildMobileVersion() {
    return Scaffold(
      backgroundColor: _C.bg,
      appBar: _buildMobileAppBar(),
      body: _buildMobileContent(),
      bottomNavigationBar: _buildMobileBottomNav(),
    );
  }

  PreferredSizeWidget _buildMobileAppBar() {
    final fontSize = _getResponsiveFontSize(context, 18);
    return AppBar(
      automaticallyImplyLeading: false,
      leadingWidth: 58,
      leading: Padding(
        padding: const EdgeInsets.only(left: 12),
        child: Center(
          child: _BackCircleButton(onTap: _handleWorkspaceBack),
        ),
      ),
      title: Text(
        'Кабинет клуба',
        style: TextStyle(
          fontSize: fontSize,
          fontWeight: FontWeight.w900,
        ),
      ),
      backgroundColor: Colors.white,
      foregroundColor: _C.text,
      elevation: 0,
      actions: [
        IconButton(
          onPressed: () => _loadAll(),
          icon: Icon(Icons.refresh_rounded,
              size: _getResponsiveFontSize(context, 24)),
          tooltip: 'Обновить',
        ),
      ],
    );
  }

  Widget _buildMobileContent() {
    final padding = _getResponsivePadding(context);
    final fontSize = _getResponsiveFontSize(context, 16);

    switch (selectedSection) {
      case ClubSection.overview:
        return _MobileOverview(padding: padding, fontSize: fontSize);
      case ClubSection.teams:
        return _MobileTeams(padding: padding, fontSize: fontSize);
      case ClubSection.roster:
        return _MobileRoster(padding: padding, fontSize: fontSize);
      case ClubSection.trainers:
        return _TeamModulePanel(
          hasTeam: true,
          title: 'Тренеры клуба',
          subtitle: 'Тренеры клуба, добавление и доступы.',
          icon: Icons.badge_rounded,
          primaryText: 'Открыть',
          onPrimary: _openClubTrainersScreen,
          quickActions: [
            _ModuleQuickAction('Команды', Icons.account_tree_rounded,
                () => setState(() => selectedSection = ClubSection.teams)),
            _ModuleQuickAction('Назначения', Icons.assignment_ind_rounded,
                _openTeamTrainersScreen),
          ],
        );
      case ClubSection.teamTrainers:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Тренеры команды',
          subtitle: 'Тренеры и специалисты выбранной команды.',
          icon: Icons.assignment_ind_rounded,
          primaryText: 'Назначения',
          onPrimary: _openTeamTrainersScreen,
          quickActions: [
            _ModuleQuickAction('Тренеры', Icons.badge_rounded,
                _openClubTrainersScreen),
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
          ],
        );
      case ClubSection.matches:
        if (!_hasTeam) return const _NeedTeam();
        return CmrTeamMatchesPanel(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        );
      case ClubSection.calendar:
        if (!_hasTeam) return const _NeedTeam();
        return CmrCalendarPanel(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        );
      case ClubSection.trainings:
        return _MobileTrainings(padding: padding, fontSize: fontSize);
      case ClubSection.plans:
        if (!_hasTeam) return const _NeedTeam();
        return CmrPlansPanel(
          clubId: clubId,
          clubName: clubName,
          teamId: selectedTeamId,
          teamName: selectedTeamName,
        );
      case ClubSection.videoAnalysis:
        if (!_hasTeam) return const _NeedTeam();
        return CmrVideoAnalysisPanel(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        );
      case ClubSection.attendance:
        if (!_hasTeam) return const _NeedTeam();
        return CmrAttendancePanel(
          teamId: selectedTeamId!,
          teamName: selectedTeamName,
          clubId: clubId,
          clubName: clubName,
        );

      case ClubSection.challenges:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Задания команды',
          subtitle: 'Создание заданий и просмотр результатов игроков.',
          icon: Icons.flag_rounded,
          primaryText: 'Открыть задания',
          onPrimary: () => _openGameModule(ClubSection.challenges),
          quickActions: [
            _ModuleQuickAction('Создать', Icons.add_rounded,
                () => _openGameModule(ClubSection.challengeCreate)),
            _ModuleQuickAction('Квизы', Icons.quiz_rounded,
                () => _openGameModule(ClubSection.quizzes)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.challengeCreate:
        _openGameModule(ClubSection.challengeCreate);
        return const _NeedTeam();
      case ClubSection.quizzes:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Квизы команды',
          subtitle: 'Викторины, вопросы и попытки игроков.',
          icon: Icons.quiz_rounded,
          primaryText: 'Открыть квизы',
          onPrimary: () => _openGameModule(ClubSection.quizzes),
          quickActions: [
            _ModuleQuickAction('Создать квиз', Icons.add_rounded,
                () => _openGameModule(ClubSection.quizCreate)),
            _ModuleQuickAction('Задания', Icons.flag_rounded,
                () => _openGameModule(ClubSection.challenges)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.quizCreate:
        _openGameModule(ClubSection.quizCreate);
        return const _NeedTeam();
      case ClubSection.rating:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Рейтинг команды',
          subtitle: 'Очки, активность и лидерборд игроков.',
          icon: Icons.emoji_events_rounded,
          primaryText: 'Открыть рейтинг',
          onPrimary: () => _openGameModule(ClubSection.rating),
        );
      case ClubSection.manager:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Менеджер команды',
          subtitle: 'Тактика, состав, игровые сценарии и симуляция матчей.',
          icon: Icons.psychology_alt_rounded,
          primaryText: 'Открыть менеджер',
          onPrimary: () => _openGameModule(ClubSection.manager),
        );
      case ClubSection.miniGames:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Игровая зона команды',
          subtitle: 'Задания, квизы, рейтинг, будущие битвы и мини-игры.',
          icon: Icons.videogame_asset_rounded,
          primaryText: 'Задания',
          onPrimary: () => _openGameModule(ClubSection.challenges),
          quickActions: [
            _ModuleQuickAction('Создать задание', Icons.flag_rounded,
                () => _openGameModule(ClubSection.challengeCreate)),
            _ModuleQuickAction('Создать квиз', Icons.quiz_rounded,
                () => _openGameModule(ClubSection.quizCreate)),
            _ModuleQuickAction('Мои квизы', Icons.view_list_rounded,
                () => _openGameModule(ClubSection.quizzes)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.chat:
        final userId = currentUserId > 0 ? currentUserId : clubId;
        if (userId <= 0) {
          return const _SolidPlaceholder(
            icon: Icons.forum_rounded,
            title: 'Чаты недоступны',
            subtitle: 'Не удалось определить пользователя для загрузки чатов.',
            chips: ['Личные', 'Группы', 'Команда'],
          );
        }
        return ChatScreen(userId: userId);
      case ClubSection.graphics:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Графический редактор',
          subtitle:
              'Тактические схемы, упражнения и визуальные конспекты.',
          icon: Icons.draw_rounded,
          primaryText: 'Открыть редактор',
          onPrimary: _openFullGraphics,
        );
      case ClubSection.description:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Визитка команды',
          subtitle: 'Описание команды, публичная информация.',
          icon: Icons.article_rounded,
          primaryText: 'Открыть визитку',
          onPrimary: _openFullTeamDescription,
        );
      case ClubSection.videoLessons:
        return _TeamModulePanel(
          hasTeam: true,
          title: 'Видеоуроки',
          subtitle: 'Обучающие материалы и видео.',
          icon: Icons.video_library_rounded,
          primaryText: 'Открыть видеоуроки',
          onPrimary: _openFullVideoLessons,
        );
      default:
        return const _SolidPlaceholder(
          icon: Icons.construction_rounded,
          title: 'В разработке',
          subtitle: 'Этот раздел оптимизируется для мобильной версии.',
          chips: ['Клуб', 'Мобайл', 'Планшет'],
        );
    }
  }

  Widget _MobileOverview({required double padding, required double fontSize}) {
    return RefreshIndicator(
      onRefresh: () => _loadAll(),
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: EdgeInsets.all(padding),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildMobileBanner(fontSize),
            SizedBox(height: padding),
            _buildMobileStatsRow(fontSize),
            SizedBox(height: padding),
            _buildMobileTeamInfo(fontSize),
            SizedBox(height: padding),
            _buildMobileQuickActions(fontSize),
            SizedBox(height: padding),
            _buildMobileEvents(fontSize),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileBanner(double fontSize) {
    return Container(
      padding: EdgeInsets.all(fontSize * 1.2),
      decoration: _mobileCardDecoration(radius: 20),
      child: Column(
        children: [
          if (clubLogo != null && clubLogo!.isNotEmpty)
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Image.network(
                clubLogo!,
                height: 72,
                width: 72,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) => Container(
                  height: 72,
                  width: 72,
                  decoration: BoxDecoration(
                    color: _C.primaryGreen.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: const Icon(
                    Icons.shield_rounded,
                    color: _C.primaryGreen,
                    size: 36,
                  ),
                ),
              ),
            ),
          SizedBox(height: fontSize * 0.8),
          Text(
            clubName,
            style: TextStyle(
              fontSize: fontSize * 1.4,
              fontWeight: FontWeight.w900,
              color: _C.text,
              height: 1.1,
            ),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          SizedBox(height: fontSize * 0.4),
          Text(
            'Рабочий кабинет клуба',
            style: TextStyle(
              fontSize: fontSize * 0.85,
              color: _C.muted,
              fontWeight: FontWeight.w600,
            ),
            textAlign: TextAlign.center,
          ),
          if (clubDescription.trim().isNotEmpty) ...[
            SizedBox(height: fontSize * 0.45),
            Text(
              clubDescription.trim(),
              style: TextStyle(
                fontSize: fontSize * 0.78,
                color: _C.muted,
                height: 1.32,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
          ],
          SizedBox(height: fontSize * 0.8),
          Wrap(
            alignment: WrapAlignment.center,
            spacing: 8,
            runSpacing: 8,
            children: [
              _SmallActionChip(
                icon: Icons.edit_rounded,
                label: 'Редактировать клуб',
                onTap: _openEditClubDialog,
              ),
              _SmallActionChip(
                icon: Icons.image_rounded,
                label: 'Логотип',
                onTap: _openEditClubDialog,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMobileStatsRow(double fontSize) {
    return Container(
      padding: EdgeInsets.all(fontSize * 0.8),
      decoration: _mobileCardDecoration(radius: 18),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Expanded(child: _buildMobileStat(
            value: '${teams.length}',
            label: 'Команды',
            icon: Icons.account_tree_rounded,
            color: _C.blue,
            fontSize: fontSize,
          )),
          Expanded(child: _buildMobileStat(
            value: '${players.length}',
            label: 'Игроки',
            icon: Icons.groups_2_rounded,
            color: _C.primaryGreen,
            fontSize: fontSize,
          )),
          Expanded(child: _buildMobileStat(
            value: '${trainers.length}',
            label: 'Тренеры',
            icon: Icons.badge_rounded,
            color: _C.purple,
            fontSize: fontSize,
          )),
          Expanded(child: _buildMobileStat(
            value: '${events.length}',
            label: 'События',
            icon: Icons.event_available_rounded,
            color: _C.orange,
            fontSize: fontSize,
          )),
        ],
      ),
    );
  }

  Widget _buildMobileStat({
    required String value,
    required String label,
    required IconData icon,
    required Color color,
    required double fontSize,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        SizedBox(height: fontSize * 0.3),
        Text(
          value,
          style: TextStyle(
            fontSize: fontSize * 1.2,
            fontWeight: FontWeight.w900,
            color: _C.text,
          ),
        ),
        Text(
          label,
          style: TextStyle(
            fontSize: fontSize * 0.7,
            color: _C.muted,
            fontWeight: FontWeight.w600,
          ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  Widget _buildMobileTeamInfo(double fontSize) {
    return Container(
      padding: EdgeInsets.all(fontSize),
      decoration: _mobileCardDecoration(radius: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.shield_rounded,
                  color: _C.footballGreen, size: 22),
              SizedBox(width: fontSize * 0.5),
              Text(
                'Активная команда',
                style: TextStyle(
                  fontSize: fontSize * 1.1,
                  fontWeight: FontWeight.w900,
                  color: _C.text,
                ),
              ),
            ],
          ),
          SizedBox(height: fontSize * 0.6),
          Container(
            padding: EdgeInsets.all(fontSize * 0.6),
            decoration: BoxDecoration(
              color: _C.footballGreenSoft,
              borderRadius: BorderRadius.circular(12),
              border:
                  Border.all(color: _C.footballGreen.withOpacity(0.2)),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    selectedTeamName,
                    style: TextStyle(
                      fontSize: fontSize,
                      fontWeight: FontWeight.w800,
                      color: _C.text,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                SizedBox(width: fontSize * 0.5),
                Text(
                  '${players.length} игроков',
                  style: TextStyle(
                    fontSize: fontSize * 0.8,
                    color: _C.muted,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: fontSize * 0.8),
          Row(
            children: [
              Expanded(
                child: _MobileActionButton(
                  icon: Icons.swap_horiz_rounded,
                  label: 'Сменить',
                  onTap: () =>
                      setState(() => selectedSection = ClubSection.teams),
                  fontSize: fontSize,
                ),
              ),
              SizedBox(width: fontSize * 0.5),
              Expanded(
                child: _MobileActionButton(
                  icon: Icons.groups_2_rounded,
                  label: 'Состав',
                  onTap: () =>
                      setState(() => selectedSection = ClubSection.roster),
                  fontSize: fontSize,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _MobileActionButton({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required double fontSize,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: EdgeInsets.symmetric(
          vertical: fontSize * 0.55,
          horizontal: fontSize * 0.65,
        ),
        decoration: BoxDecoration(
          color: _C.primaryGreen,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: fontSize),
            SizedBox(width: fontSize * 0.25),
            Flexible(
              child: Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: fontSize * 0.78,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileQuickActions(double fontSize) {
    final actions = [
      {
        'icon': Icons.badge_rounded,
        'label': 'Тренеры',
        'section': ClubSection.trainers,
        'color': _C.purple,
      },
      {
        'icon': Icons.assignment_ind_rounded,
        'label': 'Назначения',
        'section': ClubSection.teamTrainers,
        'color': _C.teal,
      },
      {
        'icon': Icons.sports_soccer_rounded,
        'label': 'Матчи',
        'section': ClubSection.matches,
        'color': _C.orange,
      },
      {
        'icon': Icons.calendar_month_rounded,
        'label': 'Календарь',
        'section': ClubSection.calendar,
        'color': _C.teal,
      },
      {
        'icon': Icons.fitness_center_rounded,
        'label': 'Тренировки',
        'section': ClubSection.trainings,
        'color': _C.footballGreen,
      },
      {
        'icon': Icons.folder_copy_rounded,
        'label': 'Планы',
        'section': ClubSection.plans,
        'color': _C.blue,
      },
      {
        'icon': Icons.analytics_rounded,
        'label': 'Видеоанализ',
        'section': ClubSection.videoAnalysis,
        'color': _C.purple,
      },
      {
        'icon': Icons.forum_rounded,
        'label': 'Чаты',
        'section': ClubSection.chat,
        'color': _C.greenDark,
      },
      {
        'icon': Icons.flag_rounded,
        'label': 'Задания',
        'section': ClubSection.challenges,
        'color': _C.orange,
      },
      {
        'icon': Icons.quiz_rounded,
        'label': 'Квизы',
        'section': ClubSection.quizzes,
        'color': _C.blue,
      },
      {
        'icon': Icons.emoji_events_rounded,
        'label': 'Рейтинг',
        'section': ClubSection.rating,
        'color': _C.purple,
      },
      {
        'icon': Icons.psychology_alt_rounded,
        'label': 'Менеджер',
        'section': ClubSection.manager,
        'color': _C.teal,
      },
    ];

    return Container(
      padding: EdgeInsets.all(fontSize),
      decoration: _mobileCardDecoration(radius: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Быстрые действия',
            style: TextStyle(
              fontSize: fontSize * 1.1,
              fontWeight: FontWeight.w900,
              color: _C.text,
            ),
          ),
          SizedBox(height: fontSize * 0.8),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 3,
              mainAxisSpacing: fontSize * 0.5,
              crossAxisSpacing: fontSize * 0.5,
              childAspectRatio: 1.18,
            ),
            itemCount: actions.length,
            itemBuilder: (context, index) {
              final action = actions[index];
              return _buildQuickActionCard(
                icon: action['icon'] as IconData,
                label: action['label'] as String,
                section: action['section'] as ClubSection,
                color: action['color'] as Color,
                fontSize: fontSize,
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _buildQuickActionCard({
    required IconData icon,
    required String label,
    required ClubSection section,
    required Color color,
    required double fontSize,
  }) {
    return InkWell(
      onTap: () => _openGameModule(section),
      borderRadius: BorderRadius.circular(14),
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.08),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: fontSize * 1.5),
            SizedBox(height: fontSize * 0.3),
            Text(
              label,
              style: TextStyle(
                fontSize: fontSize * 0.61,
                fontWeight: FontWeight.w800,
                color: _C.text,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileEvents(double fontSize) {
    if (events.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: EdgeInsets.all(fontSize),
      decoration: _mobileCardDecoration(radius: 18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ближайшие события',
            style: TextStyle(
              fontSize: fontSize * 1.1,
              fontWeight: FontWeight.w900,
              color: _C.text,
            ),
          ),
          SizedBox(height: fontSize * 0.6),
          ...events.take(3).map((event) {
            final title =
                _asString(event['title'] ?? event['name']) ?? 'Событие';
            final date = _asString(
                    event['date'] ?? event['event_date'] ?? event['start_date']) ??
                'Дата не указана';
            return Container(
              margin: EdgeInsets.only(bottom: fontSize * 0.5),
              padding: EdgeInsets.all(fontSize * 0.6),
              decoration: BoxDecoration(
                color: _C.soft2,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      color: _C.teal,
                      shape: BoxShape.circle,
                    ),
                  ),
                  SizedBox(width: fontSize * 0.5),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: TextStyle(
                            fontSize: fontSize * 0.9,
                            fontWeight: FontWeight.w700,
                            color: _C.text,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        Text(
                          date,
                          style: TextStyle(
                            fontSize: fontSize * 0.75,
                            color: _C.muted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _MobileTeams({required double padding, required double fontSize}) {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.all(padding),
          padding: EdgeInsets.all(fontSize * 0.8),
          decoration: _mobileCardDecoration(radius: 16),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  'Команды клуба',
                  style: TextStyle(
                    fontSize: fontSize * 1.2,
                    fontWeight: FontWeight.w900,
                    color: _C.text,
                  ),
                ),
              ),
              IconButton(
                onPressed: _openCreateTeam,
                icon: Icon(Icons.add_circle_rounded,
                    color: _C.primaryGreen, size: fontSize * 1.8),
              ),
            ],
          ),
        ),
        Expanded(
          child: teams.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.account_tree_rounded,
                          size: fontSize * 3, color: _C.muted),
                      SizedBox(height: padding),
                      Text(
                        'Нет команд',
                        style:
                            TextStyle(fontSize: fontSize, color: _C.muted),
                      ),
                      SizedBox(height: padding),
                      ElevatedButton.icon(
                        onPressed: _openCreateTeam,
                        icon: const Icon(Icons.add),
                        label: const Text('Создать команду'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _C.primaryGreen,
                          foregroundColor: Colors.white,
                          padding: EdgeInsets.symmetric(
                            horizontal: padding * 1.5,
                            vertical: padding,
                          ),
                        ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () => _loadAll(),
                  child: ListView.builder(
                    padding: EdgeInsets.all(padding),
                    itemCount: teams.length,
                    itemBuilder: (context, index) {
                      final team = teams[index];
                      final id =
                          _asInt(team['id'] ?? team['team_id']);
                      final name =
                          _asString(team['name']) ?? 'Команда';
                      final subtitle =
                          _asString(team['age_group']) ??
                              'Футбол';
                      final logo = _asString(team['logo']);
                      final isActive = id == selectedTeamId;

                      return Card(
                        margin:
                            EdgeInsets.only(bottom: padding * 0.75),
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(16),
                          side: BorderSide(
                            color: isActive
                                ? _C.primaryGreen.withOpacity(0.3)
                                : _C.border,
                            width: isActive ? 1.5 : 1,
                          ),
                        ),
                        elevation: isActive ? 4 : 1,
                        child: ListTile(
                          contentPadding: EdgeInsets.all(
                              padding * 0.75),
                          leading: CircleAvatar(
                            radius: 28,
                            backgroundColor: _C.soft,
                            backgroundImage:
                                logo != null && logo.isNotEmpty
                                    ? NetworkImage(logo)
                                    : null,
                            child: logo == null ||
                                    logo.isEmpty
                                ? Icon(Icons.shield_rounded,
                                    color: _C.primaryGreen,
                                    size: 28)
                                : null,
                          ),
                          title: Text(
                            name,
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: fontSize,
                              color: isActive
                                  ? _C.primaryGreen
                                  : _C.text,
                            ),
                          ),
                          subtitle: Text(
                            subtitle,
                            style: TextStyle(
                                fontSize: fontSize * 0.8),
                          ),
                          trailing: isActive
                              ? Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: padding * 0.5,
                                    vertical: padding * 0.25,
                                  ),
                                  decoration: BoxDecoration(
                                    color: _C.primaryGreen
                                        .withOpacity(0.1),
                                    borderRadius:
                                        BorderRadius.circular(
                                            20),
                                  ),
                                  child: Text(
                                    'Активна',
                                    style: TextStyle(
                                      color: _C.primaryGreen,
                                      fontSize:
                                          fontSize * 0.7,
                                      fontWeight:
                                          FontWeight.w700,
                                    ),
                                  ),
                                )
                              : null,
                          onTap: () => _selectTeam(team),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _MobileRoster({required double padding, required double fontSize}) {
    if (!_hasTeam) return const _NeedTeam();

    if (loadingPlayers) {
      return const Center(
          child: CircularProgressIndicator(color: _C.primaryGreen));
    }

    return Column(
      children: [
        Container(
          margin: EdgeInsets.all(padding),
          padding: EdgeInsets.all(fontSize * 0.8),
          decoration: _mobileCardDecoration(radius: 16),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Состав команды',
                      style: TextStyle(
                        fontSize: fontSize * 1.1,
                        fontWeight: FontWeight.w900,
                        color: _C.text,
                      ),
                    ),
                    SizedBox(height: fontSize * 0.2),
                    Text(
                      selectedTeamName,
                      style: TextStyle(
                        fontSize: fontSize * 0.85,
                        color: _C.muted,
                        fontWeight: FontWeight.w600,
                      ),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    onPressed: () {
                      if (selectedTeamId != null &&
                          selectedTeamId! > 0) {
                        Get.toNamed(
                          AppRoutes.addPlayerScreen,
                          arguments: {
                            'team_id': selectedTeamId,
                            'teamId': selectedTeamId,
                            'club_id': clubId,
                            'clubId': clubId,
                            'team_name': selectedTeamName,
                            'teamName': selectedTeamName,
                          },
                        )?.then((_) {
                          if (selectedTeamId != null) {
                            _loadPlayersForTeam(
                                selectedTeamId!);
                          }
                        });
                      } else {
                        Get.snackbar('Команда',
                            'Сначала выберите команду');
                      }
                    },
                    icon: Icon(Icons.person_add_alt_1_rounded,
                        color: _C.primaryGreen,
                        size: fontSize * 1.4),
                  ),
                  SizedBox(width: padding * 0.25),
                  IconButton(
                    onPressed: _openFullRosterScreen,
                    icon: Icon(Icons.open_in_new_rounded,
                        color: _C.primaryGreen,
                        size: fontSize * 1.4),
                  ),
                ],
              ),
            ],
          ),
        ),
        Expanded(
          child: players.isEmpty
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.person_search_rounded,
                          size: fontSize * 3, color: _C.muted),
                      SizedBox(height: padding),
                      Text(
                        'Игроки не найдены',
                        style: TextStyle(
                            fontSize: fontSize,
                            color: _C.muted),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: () =>
                      selectedTeamId != null
                          ? _loadPlayersForTeam(selectedTeamId!)
                          : Future.value(),
                  child: ListView.builder(
                    padding: EdgeInsets.symmetric(
                        horizontal: padding),
                    itemCount: players.length,
                    itemBuilder: (context, index) {
                      final player = players[index];
                      final first =
                          _asString(player['first_name']) ?? '';
                      final last =
                          _asString(player['last_name']) ?? '';
                      final name = '$first $last'.trim().isEmpty
                          ? 'Игрок'
                          : '$first $last';
                      final position =
                          _asString(player['position']) ??
                              'Амплуа';
                      final photo =
                          _asString(player['photo']);
                      final isActive =
                          selectedPlayer?['id'] ==
                              player['id'];

                      return Card(
                        margin: EdgeInsets.only(
                            bottom: padding * 0.5),
                        shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(14),
                          side: BorderSide(
                            color: isActive
                                ? _C.blue.withOpacity(0.3)
                                : _C.border,
                          ),
                        ),
                        child: ListTile(
                          contentPadding:
                              EdgeInsets.symmetric(
                            horizontal: padding * 0.75,
                            vertical: padding * 0.3,
                          ),
                          leading: CircleAvatar(
                            radius: 22,
                            backgroundColor: _C.soft,
                            backgroundImage: photo != null &&
                                    photo.isNotEmpty
                                ? NetworkImage(photo)
                                : null,
                            child: photo == null ||
                                    photo.isEmpty
                                ? Icon(Icons.person,
                                    color: _C.muted,
                                    size: 22)
                                : null,
                          ),
                          title: Text(
                            name,
                            style: TextStyle(
                              fontWeight: FontWeight.w800,
                              fontSize: fontSize * 0.95,
                              color: isActive
                                  ? _C.blue
                                  : _C.text,
                            ),
                          ),
                          subtitle: Text(
                            position,
                            style: TextStyle(
                                fontSize: fontSize * 0.8),
                          ),
                          trailing: isActive
                              ? const Icon(
                                  Icons.check_circle,
                                  color: _C.blue,
                                  size: 20,
                                )
                              : const Icon(
                                  Icons.chevron_right,
                                  color: _C.muted,
                                  size: 20,
                                ),
                          onTap: () => _openPlayerProfile(player),
                        ),
                      );
                    },
                  ),
                ),
        ),
      ],
    );
  }

  Widget _MobileTrainings({required double padding, required double fontSize}) {
    if (!_hasTeam) return const _NeedTeam();

    final modules = [
      {
        'icon': Icons.folder_copy_rounded,
        'title': 'Планы-конспекты',
        'section': ClubSection.plans,
        'color': _C.blue,
      },
      {
        'icon': Icons.draw_rounded,
        'title': 'Графика',
        'section': ClubSection.graphics,
        'color': _C.purple,
      },
      {
        'icon': Icons.calendar_month_rounded,
        'title': 'Календарь',
        'section': ClubSection.calendar,
        'color': _C.teal,
      },
      {
        'icon': Icons.fact_check_rounded,
        'title': 'Посещаемость',
        'section': ClubSection.attendance,
        'color': _C.orange,
      },
      {
        'icon': Icons.analytics_rounded,
        'title': 'Видеоанализ',
        'section': ClubSection.videoAnalysis,
        'color': _C.purple,
      },
      {
        'icon': Icons.flag_rounded,
        'title': 'Задания',
        'section': ClubSection.challenges,
        'color': _C.orange,
      },
      {
        'icon': Icons.quiz_rounded,
        'title': 'Квизы',
        'section': ClubSection.quizzes,
        'color': _C.blue,
      },
      {
        'icon': Icons.emoji_events_rounded,
        'title': 'Рейтинг',
        'section': ClubSection.rating,
        'color': _C.purple,
      },
      {
        'icon': Icons.psychology_alt_rounded,
        'title': 'Менеджер',
        'section': ClubSection.manager,
        'color': _C.teal,
      },
      {
        'icon': Icons.videogame_asset_rounded,
        'title': 'Игровая зона',
        'section': ClubSection.miniGames,
        'color': _C.teal,
      },
      {
        'icon': Icons.badge_rounded,
        'title': 'Тренеры клуба',
        'section': ClubSection.trainers,
        'color': _C.purple,
      },
      {
        'icon': Icons.assignment_ind_rounded,
        'title': 'Тренеры команды',
        'section': ClubSection.teamTrainers,
        'color': _C.teal,
      },
      {
        'icon': Icons.dashboard_customize_rounded,
        'title': 'Панель команды',
        'section': ClubSection.teamDashboard,
        'color': _C.footballGreen,
      },
    ];

    return GridView.builder(
      padding: EdgeInsets.all(padding),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: padding,
        crossAxisSpacing: padding,
        childAspectRatio: 1.3,
      ),
      itemCount: modules.length,
      itemBuilder: (context, index) {
        final module = modules[index];
        return _buildMobileModuleCard(
          icon: module['icon'] as IconData,
          title: module['title'] as String,
          section: module['section'] as ClubSection,
          color: module['color'] as Color,
          fontSize: fontSize,
        );
      },
    );
  }

  Widget _buildMobileModuleCard({
    required IconData icon,
    required String title,
    required ClubSection section,
    required Color color,
    required double fontSize,
  }) {
    return InkWell(
      onTap: () => setState(() => selectedSection = section),
      borderRadius: BorderRadius.circular(18),
      child: Container(
        decoration: _mobileCardDecoration(radius: 18),
        padding: EdgeInsets.all(fontSize * 0.7),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: fontSize * 3.2,
              height: fontSize * 3.2,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Icon(icon, color: color, size: fontSize * 1.8),
            ),
            SizedBox(height: fontSize * 0.6),
            Text(
              title,
              style: TextStyle(
                fontSize: fontSize * 0.85,
                fontWeight: FontWeight.w700,
                color: _C.text,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMobileBottomNav() {
    final fontSize = _getResponsiveFontSize(context, 11);

    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(
                icon: Icons.space_dashboard_rounded,
                label: 'Обзор',
                section: ClubSection.overview,
                fontSize: fontSize,
              ),
              _buildNavItem(
                icon: Icons.account_tree_rounded,
                label: 'Команды',
                section: ClubSection.teams,
                fontSize: fontSize,
              ),
              _buildNavItem(
                icon: Icons.groups_2_rounded,
                label: 'Состав',
                section: ClubSection.roster,
                fontSize: fontSize,
              ),
              _buildNavItem(
                icon: Icons.calendar_month_rounded,
                label: 'Календарь',
                section: ClubSection.calendar,
                fontSize: fontSize,
              ),
              _buildNavItem(
                icon: Icons.menu_rounded,
                label: 'Ещё',
                section: ClubSection.trainings,
                fontSize: fontSize,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem({
    required IconData icon,
    required String label,
    required ClubSection section,
    required double fontSize,
  }) {
    final isActive = selectedSection == section;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => selectedSection = section),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                size: fontSize * 2,
                color: isActive ? _C.primaryGreen : _C.muted,
              ),
              const SizedBox(height: 2),
              Text(
                label,
                style: TextStyle(
                  fontSize: fontSize * 0.9,
                  fontWeight:
                      isActive ? FontWeight.w800 : FontWeight.w500,
                  color: isActive ? _C.primaryGreen : _C.muted,
                ),
                textAlign: TextAlign.center,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
      ),
    );
  }

  BoxDecoration _mobileCardDecoration({double radius = 16}) {
    return BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(radius),
      border: Border.all(color: _C.border.withOpacity(0.8)),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.03),
          blurRadius: 10,
          offset: const Offset(0, 3),
        ),
      ],
    );
  }

  Widget _buildWorkspace() {
    return Scaffold(
      backgroundColor: _C.bg,
      body: SafeArea(
        child: AnimatedBuilder(
          animation: _introController,
          builder: (context, _) {
            final appValue = CurvedAnimation(
              parent: _introController,
              curve: const Interval(.64, 1, curve: Curves.easeOutCubic),
            ).value;

            return Stack(
              children: [
                Opacity(
                  opacity: appValue,
                  child: Transform.scale(
                    scale: .965 + (.035 * appValue),
                    child: Transform.translate(
                      offset: Offset(0, 26 * (1 - appValue)),
                      child: Row(
                        children: [
                          _Sidebar(
                            clubName: clubName,
                            clubLogo: clubLogo,
                            clubDescription: clubDescription,
                            selectedTeamName: selectedTeamName,
                            teamsCount: teams.length,
                            playersCount: players.length,
                            trainersCount: trainers.length,
                            selectedSection: selectedSection,
                            onSelect: (section) =>
                                setState(() => selectedSection = section),
                          ),
                          Expanded(
                            child: Column(
                              children: [
                                _TopBar(
                                  title: _titleFor(selectedSection),
                                  subtitle: _subtitleFor(selectedSection),
                                  selectedSection: selectedSection,
                                  selectedTeamName: selectedTeamName,
                                  teams: teams,
                                  selectedTeamId: selectedTeamId,
                                  onTeamChanged: (team) =>
                                      _selectTeam(team),
                                  onBack: _handleWorkspaceBack,
                                  onRefresh: () => _loadAll(),
                                  onCreateTeam: _openCreateTeam,
                                  onEditClub: _openEditClubDialog,
                                  onEditTeam: _openEditTeamDialog,
                                  refreshing: refreshing,
                                ),
                                Expanded(
                                  child: AnimatedSwitcher(
                                    duration: const Duration(
                                        milliseconds: 180),
                                    child: Padding(
                                      key: ValueKey(
                                          selectedSection.name),
                                      padding: const EdgeInsets.fromLTRB(
                                          0, 4, 12, 12),
                                      child: _buildContent(),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                if (!_introFinished)
                  Positioned.fill(
                      child: _ClubIntroSplash(
                          animation: _introController)),
              ],
            );
          },
        ),
      ),
    );
  }

  String _titleFor(ClubSection section) {
    switch (section) {
      case ClubSection.overview:
        return 'Рабочий кабинет клуба';
      case ClubSection.teams:
        return 'Команды клуба';
      case ClubSection.teamDashboard:
        return selectedTeamName;
      case ClubSection.roster:
        return 'Состав команды';
      case ClubSection.trainers:
        return 'Тренеры клуба';
      case ClubSection.teamTrainers:
        return 'Тренеры команды';
      case ClubSection.playerProfile:
        return 'Профиль игрока';
      case ClubSection.matches:
        return 'Матчи';
      case ClubSection.calendar:
        return 'Календарь';
      case ClubSection.trainings:
        return 'Тренировки';
      case ClubSection.plans:
        return 'Планы-конспекты';
      case ClubSection.graphics:
        return 'Графический редактор';
      case ClubSection.videoAnalysis:
        return 'Видеоанализ';
      case ClubSection.description:
        return 'Визитка команды';
      case ClubSection.chat:
        return 'Чаты';
      case ClubSection.videoLessons:
        return 'Видеоуроки';
      case ClubSection.attendance:
        return 'Посещаемость';
      case ClubSection.challenges:
        return 'Задания команды';
      case ClubSection.challengeCreate:
        return 'Создать задание';
      case ClubSection.quizzes:
        return 'Квизы команды';
      case ClubSection.quizCreate:
        return 'Создать квиз';
      case ClubSection.rating:
        return 'Рейтинг команды';
      case ClubSection.manager:
        return 'Менеджер команды';
      case ClubSection.miniGames:
        return 'Игровая зона';
      case ClubSection.medical:
        return 'Медкарта';
      case ClubSection.parents:
        return 'Родители';
      case ClubSection.settings:
        return 'Настройки';
    }
  }

  String _subtitleFor(ClubSection section) {
    switch (section) {
      case ClubSection.overview:
        return 'Команды, игроки, матчи, тренировки и аналитика в одном экране';
      case ClubSection.teams:
        return 'Крупные карточки команд и быстрое создание новой команды';
      case ClubSection.teamDashboard:
        return 'Единая панель выбранной команды';
      case ClubSection.roster:
        return 'Игроки, карточки, профиль и быстрые действия';
      case ClubSection.trainers:
        return 'Тренеры, специалисты и доступы клуба';
      case ClubSection.teamTrainers:
        return 'Назначение тренеров и специалистов к выбранной команде';
      case ClubSection.playerProfile:
        return 'Профиль игрока без выхода из рабочего кабинета';
      case ClubSection.matches:
        return 'Игры, результаты, календарь матчей и отчёты';
      case ClubSection.calendar:
        return 'Тренировки, матчи, события и расписание';
      case ClubSection.trainings:
        return 'Планы, графика, посещаемость и оценка тренировок';
      case ClubSection.plans:
        return 'База планов и конспектов тренера';
      case ClubSection.graphics:
        return 'Тактические схемы и упражнения';
      case ClubSection.videoAnalysis:
        return 'AI-анализ, видео, ТТД и статистика матча';
      case ClubSection.description:
        return 'Описание команды, информация и публичная карточка';
      case ClubSection.chat:
        return 'Командное и клубное общение';
      case ClubSection.videoLessons:
        return 'Обучающие материалы, папки и видео тренеров';
      case ClubSection.attendance:
        return 'Журнал посещаемости, события и оценка тренировок';
      case ClubSection.challenges:
        return 'Задания для игроков и контроль выполнения';
      case ClubSection.challengeCreate:
        return 'Новое задание для активной команды';
      case ClubSection.quizzes:
        return 'Викторины, вопросы и попытки игроков';
      case ClubSection.quizCreate:
        return 'Создание нового квиза для команды';
      case ClubSection.rating:
        return 'Очки, активность и лидерборд команды';
      case ClubSection.manager:
        return 'Тактика, состав и игровые сценарии';
      case ClubSection.miniGames:
        return 'Игровые механики команды: задания, квизы и рейтинги';
      case ClubSection.medical:
        return 'Контроль состояния, травм и документов';
      case ClubSection.parents:
        return 'Доступы родителей и коммуникация';
      case ClubSection.settings:
        return 'Настройка модулей и прав доступа';
    }
  }

  Widget _buildContent() {
    switch (selectedSection) {
      case ClubSection.overview:
        return _OverviewPanel(
          clubName: clubName,
          clubLogo: clubLogo,
          clubDescription: clubDescription,
          teams: teams,
          trainers: trainers,
          events: events,
          playersCount: players.length,
          selectedTeamName: selectedTeamName,
          onOpenTeams: () =>
              setState(() => selectedSection = ClubSection.teams),
          onOpenRoster: () =>
              setState(() => selectedSection = ClubSection.roster),
          onOpenTrainers: () =>
              setState(() => selectedSection = ClubSection.trainers),
          onOpenTeamTrainers: () =>
              setState(() => selectedSection = ClubSection.teamTrainers),
          onOpenMatches: () =>
              setState(() => selectedSection = ClubSection.matches),
          onOpenVideo: () =>
              setState(() => selectedSection = ClubSection.videoAnalysis),
        );
      case ClubSection.teams:
        return _TeamsPanel(
          teams: teams,
          selectedTeamId: selectedTeamId,
          onOpenTeam: (team) => _selectTeam(team),
          onCreateTeam: _openCreateTeam,
        );
      case ClubSection.teamDashboard:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Панель команды',
          subtitle:
              'Откройте полный рабочий экран команды или используйте модули слева.',
          icon: Icons.dashboard_customize_rounded,
          primaryText: 'Открыть панель команды',
          onPrimary: _openFullTeamDashboard,
          quickActions: [
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
            _ModuleQuickAction('Матчи', Icons.sports_soccer_rounded,
                () => setState(() => selectedSection = ClubSection.matches)),
            _ModuleQuickAction(
                'Тренировки',
                Icons.fitness_center_rounded,
                () => setState(
                    () => selectedSection = ClubSection.trainings)),
            _ModuleQuickAction(
                'Видеоанализ',
                Icons.analytics_rounded,
                () => setState(
                    () => selectedSection = ClubSection.videoAnalysis)),
          ],
        );
      case ClubSection.roster:
        return _TeamGuard(
          hasTeam: _hasTeam,
          child: _RosterPanel(
            teamName: selectedTeamName,
            selectedTeamId: selectedTeamId,
            clubId: clubId,
            players: players,
            loading: loadingPlayers,
            selectedPlayer: selectedPlayer,
            onRefresh: selectedTeamId == null
                ? null
                : () => _loadPlayersForTeam(selectedTeamId!),
            onOpenPlayer: _openPlayer,
            onOpenFullRoster: _openFullRosterScreen,
            onAddPlayer: () {
              if (selectedTeamId == null || selectedTeamId! <= 0) {
                Get.snackbar('Команда', 'Сначала выберите команду');
                return;
              }

              Get.toNamed(
                AppRoutes.addPlayerScreen,
                arguments: {
                  'team_id': selectedTeamId,
                  'teamId': selectedTeamId,
                  'club_id': clubId,
                  'clubId': clubId,
                  'team_name': selectedTeamName,
                  'teamName': selectedTeamName,
                },
              )?.then((_) {
                if (selectedTeamId != null) {
                  _loadPlayersForTeam(selectedTeamId!);
                }
              });
            },
          ),
        );
      case ClubSection.trainers:
        return _TeamModulePanel(
          hasTeam: true,
          title: 'Тренеры клуба',
          subtitle: 'Тренеры клуба, добавление по email и доступы.',
          icon: Icons.badge_rounded,
          primaryText: 'Открыть',
          onPrimary: _openClubTrainersScreen,
          quickActions: [
            _ModuleQuickAction('Назначить', Icons.assignment_ind_rounded,
                _openTeamTrainersScreen),
            _ModuleQuickAction('Команды', Icons.account_tree_rounded,
                () => setState(() => selectedSection = ClubSection.teams)),
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
          ],
        );
      case ClubSection.teamTrainers:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Тренеры команды',
          subtitle: 'Прикрепление тренеров и специалистов к активной команде.',
          icon: Icons.assignment_ind_rounded,
          primaryText: 'Назначения',
          onPrimary: _openTeamTrainersScreen,
          quickActions: [
            _ModuleQuickAction('Тренеры', Icons.badge_rounded,
                _openClubTrainersScreen),
            _ModuleQuickAction('Команда', Icons.swap_horiz_rounded,
                () => setState(() => selectedSection = ClubSection.teams)),
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
          ],
        );
      case ClubSection.playerProfile:
        return _TeamGuard(
          hasTeam: _hasTeam,
          child: _PlayerPanel(
            player: selectedPlayer,
            teamName: selectedTeamName,
            onBack: () =>
                setState(() => selectedSection = ClubSection.roster),
            onOpenFull: selectedPlayer == null
                ? null
                : () {
                    final mp =
                        Map<String, dynamic>.from(selectedPlayer!);

                    mp['team_id'] = selectedTeamId;
                    mp['teamId'] = selectedTeamId;
                    mp['club_id'] = clubId;
                    mp['clubId'] = clubId;
                    mp['team_name'] = selectedTeamName;
                    mp['teamName'] = selectedTeamName;

                    Get.toNamed(AppRoutes.playerProfileScreen,
                        arguments: mp);
                  },
          ),
        );
      case ClubSection.matches:
        return _TeamGuard(
            hasTeam: _hasTeam,
            child: CmrTeamMatchesPanel(
                teamId: selectedTeamId!,
                teamName: selectedTeamName,
                clubId: clubId,
                clubName: clubName));
      case ClubSection.calendar:
        return _TeamGuard(
            hasTeam: _hasTeam,
            child: CmrCalendarPanel(
                teamId: selectedTeamId!,
                teamName: selectedTeamName,
                clubId: clubId,
                clubName: clubName));
      case ClubSection.trainings:
        return _TrainingsPanel(
          hasTeam: _hasTeam,
          onOpenPlans: () =>
              setState(() => selectedSection = ClubSection.plans),
          onOpenGraphics: () =>
              setState(() => selectedSection = ClubSection.graphics),
          onOpenCalendar: () =>
              setState(() => selectedSection = ClubSection.calendar),
          onOpenFullTeam: _openFullTeamDashboard,
        );
      case ClubSection.plans:
        return _TeamGuard(
            hasTeam: _hasTeam,
            child: CmrPlansPanel(
                clubId: clubId,
                clubName: clubName,
                teamId: selectedTeamId,
                teamName: selectedTeamName));
      case ClubSection.graphics:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Графический редактор',
          subtitle:
              'Тактические схемы, упражнения и визуальные конспекты.',
          icon: Icons.draw_rounded,
          primaryText: 'Открыть редактор',
          onPrimary: _openFullGraphics,
          quickActions: [
            _ModuleQuickAction('Планы', Icons.folder_copy_rounded,
                () => setState(() => selectedSection = ClubSection.plans)),
            _ModuleQuickAction(
                'Видеоанализ',
                Icons.analytics_rounded,
                () => setState(
                    () => selectedSection = ClubSection.videoAnalysis)),
          ],
        );
      case ClubSection.videoAnalysis:
        return _TeamGuard(
            hasTeam: _hasTeam,
            child: CmrVideoAnalysisPanel(
                teamId: selectedTeamId!,
                teamName: selectedTeamName,
                clubId: clubId,
                clubName: clubName));
      case ClubSection.description:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Визитка команды',
          subtitle:
              'Описание команды, публичная информация, история и контакты.',
          icon: Icons.article_rounded,
          primaryText: 'Открыть визитку',
          onPrimary: _openFullTeamDescription,
          quickActions: [
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
            _ModuleQuickAction('Матчи', Icons.sports_soccer_rounded,
                () => setState(() => selectedSection = ClubSection.matches)),
          ],
        );
      case ClubSection.chat:
        final userId = currentUserId > 0 ? currentUserId : clubId;

        return _ClubChatPanel(
          userId: userId,
          onOpenFullChat: _openFullChat,
        );
      case ClubSection.videoLessons:
        return _TeamModulePanel(
          hasTeam: true,
          title: 'Видеоуроки клуба',
          subtitle:
              'Папки с обучающими материалами, видео тренеров и методическая база для игроков.',
          icon: Icons.video_library_rounded,
          primaryText: 'Открыть видеоуроки',
          onPrimary: _openFullVideoLessons,
          quickActions: [
            _ModuleQuickAction('Планы', Icons.folder_copy_rounded,
                () => setState(() => selectedSection = ClubSection.plans)),
            _ModuleQuickAction('Графика', Icons.draw_rounded,
                () => setState(() => selectedSection = ClubSection.graphics)),
            _ModuleQuickAction('Состав', Icons.groups_2_rounded,
                () => setState(() => selectedSection = ClubSection.roster)),
          ],
        );
      case ClubSection.attendance:
        return _TeamGuard(
            hasTeam: _hasTeam,
            child: CmrAttendancePanel(
                teamId: selectedTeamId!,
                teamName: selectedTeamName,
                clubId: clubId,
                clubName: clubName));

      case ClubSection.challenges:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Задания команды',
          subtitle: 'Создание заданий и просмотр результатов игроков.',
          icon: Icons.flag_rounded,
          primaryText: 'Открыть задания',
          onPrimary: () => _openGameModule(ClubSection.challenges),
          quickActions: [
            _ModuleQuickAction('Создать', Icons.add_rounded,
                () => _openGameModule(ClubSection.challengeCreate)),
            _ModuleQuickAction('Квизы', Icons.quiz_rounded,
                () => _openGameModule(ClubSection.quizzes)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.challengeCreate:
        _openGameModule(ClubSection.challengeCreate);
        return const _NeedTeam();
      case ClubSection.quizzes:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Квизы команды',
          subtitle: 'Викторины, вопросы и попытки игроков.',
          icon: Icons.quiz_rounded,
          primaryText: 'Открыть квизы',
          onPrimary: () => _openGameModule(ClubSection.quizzes),
          quickActions: [
            _ModuleQuickAction('Создать квиз', Icons.add_rounded,
                () => _openGameModule(ClubSection.quizCreate)),
            _ModuleQuickAction('Задания', Icons.flag_rounded,
                () => _openGameModule(ClubSection.challenges)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.quizCreate:
        _openGameModule(ClubSection.quizCreate);
        return const _NeedTeam();
      case ClubSection.rating:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Рейтинг команды',
          subtitle: 'Очки, активность и лидерборд игроков.',
          icon: Icons.emoji_events_rounded,
          primaryText: 'Открыть рейтинг',
          onPrimary: () => _openGameModule(ClubSection.rating),
        );
      case ClubSection.manager:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Менеджер команды',
          subtitle: 'Тактика, состав, игровые сценарии и симуляция матчей.',
          icon: Icons.psychology_alt_rounded,
          primaryText: 'Открыть менеджер',
          onPrimary: () => _openGameModule(ClubSection.manager),
        );
      case ClubSection.miniGames:
        return _TeamModulePanel(
          hasTeam: _hasTeam,
          title: 'Игровая зона команды',
          subtitle: 'Задания, квизы, рейтинг, будущие битвы и мини-игры.',
          icon: Icons.videogame_asset_rounded,
          primaryText: 'Задания',
          onPrimary: () => _openGameModule(ClubSection.challenges),
          quickActions: [
            _ModuleQuickAction('Создать задание', Icons.flag_rounded,
                () => _openGameModule(ClubSection.challengeCreate)),
            _ModuleQuickAction('Создать квиз', Icons.quiz_rounded,
                () => _openGameModule(ClubSection.quizCreate)),
            _ModuleQuickAction('Мои квизы', Icons.view_list_rounded,
                () => _openGameModule(ClubSection.quizzes)),
            _ModuleQuickAction('Рейтинг', Icons.emoji_events_rounded,
                () => _openGameModule(ClubSection.rating)),
          ],
        );
      case ClubSection.medical:
        return const _SolidPlaceholder(
            icon: Icons.medical_information_rounded,
            title: 'Медкарта игроков',
            subtitle:
                'Здесь можно подключить медицинские записи, травмы, осмотры, вакцинации и документы по игрокам.',
            chips: ['Осмотры', 'Травмы', 'Вакцинация', 'Документы', 'История']);
      case ClubSection.parents:
        return const _SolidPlaceholder(
            icon: Icons.family_restroom_rounded,
            title: 'Родители и доступы',
            subtitle:
                'Раздел для доступа родителей к данным ребёнка, уведомлений, согласований и общения.',
            chips: ['Доступы', 'Уведомления', 'Чат', 'Карточки детей']);
      case ClubSection.settings:
        return const _SolidPlaceholder(
            icon: Icons.tune_rounded,
            title: 'Настройки рабочего кабинета',
            subtitle:
                'Следующим шагом сюда можно добавить порядок модулей, видимость разделов и права ролей.',
            chips: ['Меню', 'Роли', 'Виджеты', 'Оформление']);
    }
  }
}


class _SmallActionChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _SmallActionChip({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(999),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
        decoration: BoxDecoration(
          color: _C.primaryGreen.withOpacity(.10),
          borderRadius: BorderRadius.circular(999),
          border: Border.all(color: _C.primaryGreen.withOpacity(.18)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 15, color: _C.primaryGreen),
            const SizedBox(width: 6),
            Text(
              label,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w900,
                color: _C.text,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _C {
  static const Color bg = Color(0xFFFBFBFA);
  static const Color card = Color(0xFFFFFFFF);
  static const Color text = Color(0xFF0F172A);
  static const Color muted = Color(0xFF64748B);
  static const Color border = Color(0xFFE7ECF2);

  static const Color black = Color(0xFF111827);
  static const Color graphite = Color(0xFF334155);
  static const Color active = Color(0xFFF1F5F9);
  static const Color soft = Color(0xFFF8FAFC);
  static const Color soft2 = Color(0xFFFAFCFB);
  static const Color accent = Color(0xFF94A3B8);

  static const Color primaryGreen = Color(0xFF00A750);
  static const Color greenDark = Color(0xFF008C40);
  static const Color footballGreen = Color(0xFF178A45);
  static const Color footballGreenSoft = Color(0xFFEAF5EE);

  static const Color blue = Color(0xFF2563EB);
  static const Color blueSoft = Color(0xFFEFF6FF);
  static const Color purple = Color(0xFF7C3AED);
  static const Color purpleSoft = Color(0xFFF3E8FF);
  static const Color orange = Color(0xFFEA580C);
  static const Color orangeSoft = Color(0xFFFFF1E8);
  static const Color teal = Color(0xFF0F766E);
  static const Color tealSoft = Color(0xFFE6F6F4);
  static const Color red = Color(0xFFDC2626);
  static const Color redSoft = Color(0xFFFEE2E2);

  static Color accentForSection(ClubSection section) {
    switch (section) {
      case ClubSection.overview:
        return primaryGreen;
      case ClubSection.teams:
      case ClubSection.trainers:
      case ClubSection.teamTrainers:
      case ClubSection.teamDashboard:
      case ClubSection.roster:
      case ClubSection.playerProfile:
        return blue;
      case ClubSection.matches:
        return orange;
      case ClubSection.calendar:
      case ClubSection.attendance:
        return teal;
      case ClubSection.videoAnalysis:
      case ClubSection.graphics:
        return purple;
      case ClubSection.trainings:
      case ClubSection.plans:
      case ClubSection.videoLessons:
        return footballGreen;
      case ClubSection.medical:
        return red;
      case ClubSection.chat:
      case ClubSection.parents:
      case ClubSection.description:
      case ClubSection.settings:
        return graphite;
      case ClubSection.challenges:
      case ClubSection.challengeCreate:
      case ClubSection.quizzes:
      case ClubSection.quizCreate:
      case ClubSection.rating:
      case ClubSection.manager:
      case ClubSection.miniGames:
        return purple;
    }
  }

  static Color softFor(Color color) {
    if (color == blue) return blueSoft;
    if (color == purple) return purpleSoft;
    if (color == orange) return orangeSoft;
    if (color == teal) return tealSoft;
    if (color == red) return redSoft;
    if (color == footballGreen || color == primaryGreen || color == greenDark)
      return footballGreenSoft;
    return soft;
  }

  static Color accentForIcon(IconData icon) {
    if (icon == Icons.groups_2_rounded ||
        icon == Icons.account_tree_rounded ||
        icon == Icons.dashboard_customize_rounded ||
        icon == Icons.person_search_rounded) return blue;
    if (icon == Icons.sports_soccer_rounded ||
        icon == Icons.sports_score_rounded) return orange;
    if (icon == Icons.calendar_month_rounded ||
        icon == Icons.event_available_rounded ||
        icon == Icons.event_note_outlined ||
        icon == Icons.fact_check_rounded) return teal;
    if (icon == Icons.analytics_rounded || icon == Icons.draw_rounded)
      return purple;
    if (icon == Icons.medical_information_rounded ||
        icon == Icons.health_and_safety_rounded) return red;
    if (icon == Icons.folder_copy_rounded ||
        icon == Icons.fitness_center_rounded ||
        icon == Icons.video_library_rounded) return footballGreen;
    return primaryGreen;
  }
}

class _Sidebar extends StatelessWidget {
  final String clubName;
  final String? clubLogo;
  final String clubDescription;
  final String selectedTeamName;
  final int teamsCount;
  final int playersCount;
  final int trainersCount;
  final ClubSection selectedSection;
  final ValueChanged<ClubSection> onSelect;

  const _Sidebar({
    required this.clubName,
    required this.clubLogo,
    required this.clubDescription,
    required this.selectedTeamName,
    required this.teamsCount,
    required this.playersCount,
    required this.trainersCount,
    required this.selectedSection,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    final items = <_NavItem>[
      _NavItem(ClubSection.overview, Icons.space_dashboard_rounded, 'Обзор'),
      _NavItem(ClubSection.trainers, Icons.badge_rounded, 'Тренеры'),
      _NavItem(ClubSection.teamTrainers, Icons.assignment_ind_rounded, 'Назначения'),
      _NavItem(ClubSection.teamDashboard, Icons.dashboard_customize_rounded,
          'Панель'),
      _NavItem(ClubSection.roster, Icons.groups_2_rounded, 'Состав'),
      _NavItem(ClubSection.matches, Icons.sports_soccer_rounded, 'Матчи'),
      _NavItem(
          ClubSection.calendar, Icons.calendar_month_rounded, 'Календарь'),
      _NavItem(
          ClubSection.trainings, Icons.fitness_center_rounded, 'Тренировки'),
      _NavItem(ClubSection.plans, Icons.folder_copy_rounded, 'Планы'),
      _NavItem(ClubSection.graphics, Icons.draw_rounded, 'Графика'),
      _NavItem(
          ClubSection.videoAnalysis, Icons.analytics_rounded, 'Видеоанализ'),
      _NavItem(ClubSection.description, Icons.article_rounded, 'Визитка'),
      _NavItem(ClubSection.chat, Icons.forum_rounded, 'Чаты'),
      _NavItem(
          ClubSection.videoLessons, Icons.video_library_rounded, 'Видеоуроки'),
      _NavItem(
          ClubSection.attendance, Icons.fact_check_rounded, 'Посещаемость'),
      _NavItem(ClubSection.challenges, Icons.flag_rounded, 'Задания'),
      _NavItem(ClubSection.quizzes, Icons.quiz_rounded, 'Квизы'),
      _NavItem(ClubSection.rating, Icons.emoji_events_rounded, 'Рейтинг'),
      _NavItem(ClubSection.manager, Icons.psychology_alt_rounded, 'Менеджер'),
      _NavItem(ClubSection.miniGames, Icons.videogame_asset_rounded, 'Игровая зона'),
      _NavItem(ClubSection.medical, Icons.medical_information_rounded,
          'Медкарта'),
      _NavItem(
          ClubSection.parents, Icons.family_restroom_rounded, 'Родители'),
      _NavItem(ClubSection.settings, Icons.tune_rounded, 'Настройки'),
    ];

    return Container(
      width: 274,
      margin: const EdgeInsets.all(10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(34),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.055),
              blurRadius: 30,
              offset: const Offset(0, 18))
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: _C.soft2,
                borderRadius: BorderRadius.circular(26),
                border: Border.all(color: _C.border)),
            child: Row(
              children: [
                _LogoBox(url: clubLogo, size: 52, bgColor: Colors.white),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(clubName,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: const TextStyle(
                                color: _C.text,
                                height: 1.05,
                                fontSize: 13.2,
                                fontWeight: FontWeight.w900)),
                        const SizedBox(height: 2),
                        Wrap(
                          spacing: 5,
                          runSpacing: 3,
                          children: [
                            _MiniCountPill(value: '$teamsCount', label: 'команд'),
                            _MiniCountPill(value: '$playersCount', label: 'игроков'),
                            _MiniCountPill(value: '$trainersCount', label: 'тренеров'),
                          ],
                        ),
                      ]),
                ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
                color: _C.footballGreenSoft,
                borderRadius: BorderRadius.circular(24),
                border: Border.all(
                    color: _C.footballGreen.withOpacity(.16))),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(children: [
                    Icon(Icons.shield_rounded,
                        size: 18, color: _C.footballGreen),
                    SizedBox(width: 8),
                    Text('Активная команда',
                        style: TextStyle(
                            color: _C.muted,
                            fontSize: 12,
                            fontWeight: FontWeight.w700))
                  ]),
                  const SizedBox(height: 8),
                  Text(selectedTeamName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: _C.text,
                          fontSize: 15,
                          fontWeight: FontWeight.w900)),
                ]),
          ),
          const SizedBox(height: 14),
          Expanded(
            child: ListView.separated(
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 6),
              itemBuilder: (_, index) {
                final item = items[index];
                final active = item.section == selectedSection;
                final accent = _C.accentForSection(item.section);
                return InkWell(
                  borderRadius: BorderRadius.circular(18),
                  onTap: () => onSelect(item.section),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 170),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 11),
                    decoration: BoxDecoration(
                      color: active
                          ? _C.softFor(accent)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(18),
                      border: active
                          ? Border.all(color: accent.withOpacity(.16))
                          : null,
                    ),
                    child: Row(children: [
                      Icon(item.icon,
                          size: 21,
                          color: active ? accent : _C.muted),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Text(item.label,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                  color: active ? _C.text : _C.text,
                                  fontWeight: active
                                      ? FontWeight.w900
                                      : FontWeight.w700,
                                  fontSize: item.label.length > 10 ? 10.6 : 11.8))),
                    ]),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}


class _MiniCountPill extends StatelessWidget {
  final String value;
  final String label;

  const _MiniCountPill({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: _C.border),
      ),
      child: RichText(
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        text: TextSpan(
          children: [
            TextSpan(
              text: value,
              style: const TextStyle(
                color: _C.text,
                fontSize: 10.8,
                fontWeight: FontWeight.w900,
              ),
            ),
            TextSpan(
              text: ' $label',
              style: const TextStyle(
                color: _C.muted,
                fontSize: 9.4,
                fontWeight: FontWeight.w800,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavItem {
  final ClubSection section;
  final IconData icon;
  final String label;
  const _NavItem(this.section, this.icon, this.label);
}

class _BackCircleButton extends StatelessWidget {
  final VoidCallback onTap;

  const _BackCircleButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      shape: const CircleBorder(),
      elevation: 0,
      child: InkWell(
        onTap: onTap,
        customBorder: const CircleBorder(),
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: _C.soft,
            border: Border.all(color: _C.border),
          ),
          child: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 18,
            color: _C.text,
          ),
        ),
      ),
    );
  }
}

class _TopBar extends StatelessWidget {
  final String title;
  final String subtitle;
  final ClubSection selectedSection;
  final String selectedTeamName;
  final int? selectedTeamId;
  final List<Map<String, dynamic>> teams;
  final ValueChanged<Map<String, dynamic>> onTeamChanged;
  final VoidCallback onBack;
  final VoidCallback onRefresh;
  final VoidCallback onCreateTeam;
  final VoidCallback onEditClub;
  final VoidCallback onEditTeam;
  final bool refreshing;

  const _TopBar({
    required this.title,
    required this.subtitle,
    required this.selectedSection,
    required this.selectedTeamName,
    required this.selectedTeamId,
    required this.teams,
    required this.onTeamChanged,
    required this.onBack,
    required this.onRefresh,
    required this.onCreateTeam,
    required this.onEditClub,
    required this.onEditTeam,
    required this.refreshing,
  });

  @override
  Widget build(BuildContext context) {
    final accent = _C.accentForSection(selectedSection);
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 10, 10, 6),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.96),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: _C.border),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(.045),
              blurRadius: 24,
              offset: const Offset(0, 12))
        ],
      ),
      child: Row(children: [
        _BackCircleButton(onTap: onBack),
        const SizedBox(width: 10),
        Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
                color: _C.softFor(accent),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: accent.withOpacity(.18))),
            child:
                Icon(Icons.dashboard_customize_rounded, color: accent, size: 22)),
        const SizedBox(width: 14),
        Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              Text(title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      fontSize: 18,
                      height: 1.05,
                      fontWeight: FontWeight.w900,
                      color: _C.text)),
              const SizedBox(height: 3),
              Text(subtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: _C.muted,
                      height: 1.15,
                      fontSize: 10.8,
                      fontWeight: FontWeight.w700)),
            ])),
        const SizedBox(width: 12),
        _TeamChooser(
            teams: teams,
            selectedTeamName: selectedTeamName,
            selectedTeamId: selectedTeamId,
            onTeamChanged: onTeamChanged),
        const SizedBox(width: 8),
        _TopToolButton(
            icon: Icons.edit_rounded,
            text: 'Клуб',
            onTap: onEditClub),
        const SizedBox(width: 8),
        _TopToolButton(
            icon: Icons.tune_rounded,
            text: 'Команда',
            onTap: onEditTeam),
        const SizedBox(width: 8),
        _TopToolButton(
            icon: Icons.add_rounded,
            text: 'Новая',
            onTap: onCreateTeam),
        const SizedBox(width: 8),
        _IconCircleButton(
            icon: refreshing
                ? Icons.sync_rounded
                : Icons.refresh_rounded,
            onTap: onRefresh),
      ]),
    );
  }
}


class _TopToolButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _TopToolButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 40,
        padding: const EdgeInsets.symmetric(horizontal: 9),
        decoration: BoxDecoration(
          color: _C.soft2,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: _C.primaryGreen, size: 17),
          const SizedBox(width: 6),
          Text(
            text,
            style: const TextStyle(
              color: _C.text,
              fontSize: 11,
              fontWeight: FontWeight.w900,
            ),
          ),
        ]),
      ),
    );
  }
}

class _TeamChooser extends StatelessWidget {
  final List<Map<String, dynamic>> teams;
  final String selectedTeamName;
  final int? selectedTeamId;
  final ValueChanged<Map<String, dynamic>> onTeamChanged;

  const _TeamChooser(
      {required this.teams,
      required this.selectedTeamName,
      required this.selectedTeamId,
      required this.onTeamChanged});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<Map<String, dynamic>>(
      tooltip: 'Выбрать команду',
      onSelected: onTeamChanged,
      color: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      itemBuilder: (_) => teams.map((team) {
        final id = int.tryParse(
                '${team['id'] ?? team['team_id'] ?? 0}') ??
            0;
        final name =
            '${team['name'] ?? team['team_name'] ?? 'Команда'}';
        return PopupMenuItem<Map<String, dynamic>>(
          value: team,
          child: Row(children: [
            Icon(
                id == selectedTeamId
                    ? Icons.check_circle_rounded
                    : Icons.shield_outlined,
                color: id == selectedTeamId
                    ? _C.primaryGreen
                    : _C.muted),
            const SizedBox(width: 10),
            Expanded(
                child: Text(name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w800,
                        color: _C.text))),
          ]),
        );
      }).toList(),
      child: Container(
        constraints:
            const BoxConstraints(minWidth: 148, maxWidth: 205),
        padding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
            color: _C.soft2,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _C.border)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.shield_rounded,
              color: _C.primaryGreen, size: 22),
          const SizedBox(width: 10),
          Expanded(
              child: Text(selectedTeamName,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: _C.text,
                      fontWeight: FontWeight.w900,
                      fontSize: 11.4))),
          const SizedBox(width: 8),
          const Icon(Icons.keyboard_arrow_down_rounded,
              color: _C.black),
        ]),
      ),
    );
  }
}

class _OverviewPanel extends StatelessWidget {
  final String clubName;
  final String? clubLogo;
  final String clubDescription;
  final String selectedTeamName;
  final List<Map<String, dynamic>> teams;
  final List<Map<String, dynamic>> trainers;
  final List<Map<String, dynamic>> events;
  final int playersCount;
  final VoidCallback onOpenTeams;
  final VoidCallback onOpenRoster;
  final VoidCallback onOpenTrainers;
  final VoidCallback onOpenTeamTrainers;
  final VoidCallback onOpenMatches;
  final VoidCallback onOpenVideo;

  const _OverviewPanel(
      {required this.clubName,
      required this.clubLogo,
      required this.clubDescription,
      required this.selectedTeamName,
      required this.teams,
      required this.trainers,
      required this.events,
      required this.playersCount,
      required this.onOpenTeams,
      required this.onOpenRoster,
      required this.onOpenTrainers,
      required this.onOpenTeamTrainers,
      required this.onOpenMatches,
      required this.onOpenVideo});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.only(right: 2, bottom: 24),
      children: [
        _ClubHeroCard(
          clubName: clubName,
          clubLogo: clubLogo,
          clubDescription: clubDescription,
        ),
        const SizedBox(height: 12),
        Row(children: [
          Expanded(
              child: _MetricCard(
                  icon: Icons.account_tree_rounded,
                  title: 'Команды',
                  value: '${teams.length}',
                  onTap: onOpenTeams)),
          const SizedBox(width: 12),
          Expanded(
              child: _MetricCard(
                  icon: Icons.groups_2_rounded,
                  title: 'Игроки',
                  value: '$playersCount',
                  onTap: onOpenRoster)),
          const SizedBox(width: 12),
          Expanded(
              child: _MetricCard(
                  icon: Icons.badge_rounded,
                  title: 'Тренеры',
                  value: '${trainers.length}',
                  onTap: onOpenTrainers)),
          const SizedBox(width: 12),
          Expanded(
              child: _MetricCard(
                  icon: Icons.event_available_rounded,
                  title: 'События',
                  value: '${events.length}',
                  onTap: () {})),
        ]),
        const SizedBox(height: 12),
        _SolidCard(
            title: 'Ближайшие события',
            child: events.isEmpty
                ? const _EmptyText(
                    'Пока нет событий для отображения.')
                : Column(
                    children: events.take(5).map((event) {
                    final title =
                        '${event['title'] ?? event['name'] ?? 'Событие'}';
                    final date =
                        '${event['date'] ?? event['event_date'] ?? event['start_date'] ?? ''}';
                    return _EventRow(title: title, date: date);
                  }).toList())),
      ],
    );
  }
}

class _TeamsPanel extends StatelessWidget {
  final List<Map<String, dynamic>> teams;
  final int? selectedTeamId;
  final ValueChanged<Map<String, dynamic>> onOpenTeam;
  final VoidCallback onCreateTeam;

  const _TeamsPanel(
      {required this.teams,
      required this.selectedTeamId,
      required this.onOpenTeam,
      required this.onCreateTeam});

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      _TeamsHeader(onCreateTeam: onCreateTeam),
      const SizedBox(height: 12),
      Expanded(
        child: teams.isEmpty
            ? _EmptyTeams(onCreateTeam: onCreateTeam)
            : GridView.builder(
                padding: const EdgeInsets.only(bottom: 20),
                gridDelegate:
                    const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 3,
                        mainAxisSpacing: 14,
                        crossAxisSpacing: 14,
                        childAspectRatio: 1.35),
                itemCount: teams.length,
                itemBuilder: (_, index) {
                  final team = teams[index];
                  final id = int.tryParse(
                          '${team['id'] ?? team['team_id'] ?? 0}') ??
                      0;
                  final name =
                      '${team['name'] ?? team['team_name'] ?? 'Команда'}';
                  final subtitle =
                      '${team['age_group'] ?? team['category'] ?? team['sport'] ?? 'Футбол'}';
                  final logo =
                      '${team['logo'] ?? team['logo_url'] ?? team['photo'] ?? ''}';
                  return _TeamCard(
                      name: name,
                      subtitle: subtitle,
                      logo: logo.isEmpty ? null : logo,
                      active: id == selectedTeamId,
                      onTap: () => onOpenTeam(team));
                },
              ),
      ),
    ]);
  }
}

class _TeamsHeader extends StatelessWidget {
  final VoidCallback onCreateTeam;
  const _TeamsHeader({required this.onCreateTeam});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(radius: 28),
      child: Row(children: [
        const _IconBadge(icon: Icons.account_tree_rounded, size: 54),
        const SizedBox(width: 14),
        const Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              Text('Команды клуба',
                  style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.w900,
                      color: _C.text)),
              SizedBox(height: 4),
              Text(
                  'Создавайте команды, выбирайте активную и переходите к рабочим модулям.',
                  style: TextStyle(
                      color: _C.muted,
                      fontWeight: FontWeight.w600)),
            ])),
        _GreenButton(
            icon: Icons.add_rounded,
            text: 'Добавить команду',
            onTap: onCreateTeam,
            large: true),
      ]),
    );
  }
}

class _TeamCard extends StatelessWidget {
  final String name;
  final String subtitle;
  final String? logo;
  final bool active;
  final VoidCallback onTap;

  const _TeamCard(
      {required this.name,
      required this.subtitle,
      required this.logo,
      required this.active,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(30),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 170),
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: active ? _C.blueSoft : Colors.white,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(
              color: active
                  ? _C.blue.withOpacity(.28)
                  : _C.border,
              width: active ? 1.4 : 1),
          boxShadow: [
            BoxShadow(
                color: active
                    ? _C.blue.withOpacity(.12)
                    : Colors.black.withOpacity(.035),
                blurRadius: 22,
                offset: const Offset(0, 12))
          ],
        ),
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                _LogoBox(
                    url: logo,
                    size: 58,
                    bgColor: active ? Colors.white : _C.soft),
                const Spacer(),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                      color: active ? Colors.white : _C.soft2,
                      borderRadius: BorderRadius.circular(99),
                      border: Border.all(
                          color: active
                              ? _C.blue.withOpacity(.18)
                              : _C.border)),
                  child: Text(active ? 'Активна' : 'Открыть',
                      style: TextStyle(
                          color: active ? _C.blue : _C.black,
                          fontSize: 11,
                          fontWeight: FontWeight.w900)),
                ),
              ]),
              const Spacer(),
              Text(name,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                      fontSize: 19,
                      height: 1.1,
                      fontWeight: FontWeight.w900,
                      color: active ? _C.blue : _C.text)),
              const SizedBox(height: 7),
              Text(subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                      color: _C.muted,
                      fontSize: 13,
                      fontWeight: FontWeight.w700)),
            ]),
      ),
    );
  }
}

class _RosterPanel extends StatelessWidget {
  final String teamName;
  final int? selectedTeamId;
  final int clubId;
  final List<Map<String, dynamic>> players;
  final bool loading;
  final Map<String, dynamic>? selectedPlayer;
  final Future<void> Function()? onRefresh;
  final ValueChanged<Map<String, dynamic>> onOpenPlayer;
  final VoidCallback onOpenFullRoster;
  final VoidCallback onAddPlayer;

  const _RosterPanel({
    required this.teamName,
    required this.selectedTeamId,
    required this.clubId,
    required this.players,
    required this.loading,
    required this.selectedPlayer,
    required this.onRefresh,
    required this.onOpenPlayer,
    required this.onOpenFullRoster,
    required this.onAddPlayer,
  });
  @override
  Widget build(BuildContext context) {
    if (loading)
      return const Center(
          child:
              CircularProgressIndicator(color: _C.primaryGreen));

    return Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          SizedBox(
            width: 390,
            child: Container(
              padding: const EdgeInsets.all(18),
              decoration: _cardDecoration(radius: 28),
              child: Column(children: [
                Row(children: [
                  Expanded(
                      child: Text('Состав: $teamName',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w900,
                              color: _C.text))),
                  _SmallIconButton(
                    icon: Icons.person_add_alt_1_rounded,
                    onTap: onAddPlayer,
                  ),
                  const SizedBox(width: 8),
                  _SmallIconButton(
                    icon: Icons.open_in_new_rounded,
                    onTap: onOpenFullRoster,
                  ),
                ]),
                const SizedBox(height: 14),
                Expanded(
                  child: players.isEmpty
                      ? const Center(
                          child: _EmptyText(
                              'Игроки пока не найдены.'))
                      : ListView.separated(
                          itemCount: players.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (_, index) {
                            final player = players[index];
                            final active =
                                '${player['id']}' ==
                                    '${selectedPlayer?['id']}';
                            return _PlayerTile(
                                player: player,
                                active: active,
                                onTap: () =>
                                    onOpenPlayer(player));
                          },
                        ),
                ),
              ]),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: _PlayerPanel(
              player: selectedPlayer,
              teamName: teamName,
              onBack: null,
              onOpenFull: selectedPlayer == null
                  ? null
                  : () {
                      final mp = Map<String, dynamic>.from(
                          selectedPlayer!);

                      mp['team_id'] ??= mp['teamId'];
                      mp['teamId'] ??= mp['team_id'];

                      Get.toNamed(
                          AppRoutes.playerProfileScreen,
                          arguments: mp);
                    },
            ),
          ),
        ]);
  }
}

class _PlayerTile extends StatelessWidget {
  final Map<String, dynamic> player;
  final bool active;
  final VoidCallback onTap;

  const _PlayerTile(
      {required this.player, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final first =
        '${player['first_name'] ?? player['firstname'] ?? ''}'.trim();
    final last =
        '${player['last_name'] ?? player['lastname'] ?? ''}'.trim();
    final name = ('$first $last').trim().isEmpty
        ? '${player['name'] ?? 'Игрок'}'
        : ('$first $last').trim();
    final position =
        '${player['position'] ?? player['role'] ?? 'Амплуа не указано'}';
    final photo =
        '${player['photo'] ?? player['avatar'] ?? player['image'] ?? ''}';

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.all(11),
        decoration: BoxDecoration(
          color: active ? _C.blueSoft : _C.soft2,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: active
                  ? _C.blue.withOpacity(.22)
                  : _C.border),
        ),
        child: Row(children: [
          _LogoBox(
              url: photo.isEmpty ? null : photo,
              size: 44,
              bgColor: Colors.white),
          const SizedBox(width: 10),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(name,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: active ? _C.blue : _C.text)),
                const SizedBox(height: 2),
                Text(position,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        color: _C.muted,
                        fontSize: 12,
                        fontWeight: FontWeight.w700)),
              ])),
          Icon(Icons.chevron_right_rounded,
              color: active ? _C.blue : _C.black),
        ]),
      ),
    );
  }
}

class _PlayerPanel extends StatelessWidget {
  final Map<String, dynamic>? player;
  final String teamName;
  final VoidCallback? onBack;
  final VoidCallback? onOpenFull;

  const _PlayerPanel(
      {required this.player,
      required this.teamName,
      required this.onBack,
      required this.onOpenFull});

  String _text(String key, [String fallback = '—']) {
    final value = player?[key];
    final text = '${value ?? ''}'.trim();
    return text.isEmpty || text == 'null' ? fallback : text;
  }

  @override
  Widget build(BuildContext context) {
    if (player == null) {
      return const _SolidPlaceholder(
          icon: Icons.person_search_rounded,
          title: 'Выберите игрока',
          subtitle:
              'Нажмите на игрока в составе, чтобы открыть его карточку.',
          chips: ['Профиль', 'Метрики', 'Медкарта']);
    }

    final first = _text('first_name', '');
    final last = _text('last_name', '');
    final fullName = _text('fullName', '$first $last').trim();
    final name =
        fullName.isEmpty ? _text('name', 'Игрок') : fullName;
    final photo = _text('photo', '');
    final position = _text('position', 'Амплуа не указано');
    final number = _text('number');
    final birth =
        _text('birthDate', _text('birth_date'));
    final email = _text('email');
    final nationality =
        _text('nationality', _text('nationa'));
    final height = _text('height');
    final weight = _text('weight');
    final sportData =
        _text('sport_data', _text('sportData', ''));

    return Container(
      decoration: _cardDecoration(radius: 28),
      child: Column(children: [
        Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: _C.blueSoft,
            borderRadius: const BorderRadius.vertical(
                top: Radius.circular(28)),
            border: Border(
                bottom: BorderSide(
                    color: _C.blue.withOpacity(.12))),
          ),
          child: Row(children: [
            if (onBack != null)
              _SmallIconButton(
                  icon: Icons.arrow_back_rounded,
                  onTap: onBack!),
            if (onBack != null) const SizedBox(width: 12),
            _LogoBox(
                url: photo.isEmpty ? null : photo,
                size: 86,
                bgColor: Colors.white),
            const SizedBox(width: 18),
            Expanded(
                child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                  Text(name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: _C.text,
                          fontSize: 25,
                          height: 1.05,
                          fontWeight:
                              FontWeight.w900)),
                  const SizedBox(height: 10),
                  Wrap(spacing: 8, runSpacing: 8, children: [
                    _LightChip(text: position),
                    _LightChip(text: '№ $number'),
                    _LightChip(text: teamName)
                  ]),
                ])),
            if (onOpenFull != null)
              _GreenButton(
                  icon: Icons.open_in_new_rounded,
                  text: 'Полный профиль',
                  onTap: onOpenFull!),
          ]),
        ),
        Expanded(
          child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Row(children: [
                  Expanded(
                      child: _MiniStat(
                          title: 'Дата рождения',
                          value: birth,
                          icon: Icons.cake_rounded)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _MiniStat(
                          title: 'Амплуа',
                          value: position,
                          icon: Icons.sports_soccer_rounded)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _MiniStat(
                          title: 'Номер',
                          value: number,
                          icon: Icons.tag_rounded)),
                ]),
                const SizedBox(height: 12),
                Row(children: [
                  Expanded(
                      child: _MiniStat(
                          title: 'Рост',
                          value: height,
                          icon: Icons.height_rounded)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _MiniStat(
                          title: 'Вес',
                          value: weight,
                          icon: Icons
                              .monitor_weight_outlined)),
                  const SizedBox(width: 10),
                  Expanded(
                      child: _MiniStat(
                          title: 'Гражданство',
                          value: nationality,
                          icon: Icons.flag_rounded)),
                ]),
                const SizedBox(height: 14),
                _SolidCard(
                    title: 'Контакты',
                    child: _ProfileLine(
                        icon: Icons.email_outlined,
                        title: 'Email',
                        value: email)),
                const SizedBox(height: 12),
                _SolidCard(
                    title: 'Спортивные данные',
                    child: Text(
                        sportData.isEmpty
                            ? 'Спортивные данные пока не заполнены.'
                            : sportData,
                        style: const TextStyle(
                            color: _C.text,
                            fontSize: 14,
                            height: 1.45,
                            fontWeight:
                                FontWeight.w600))),
              ]),
        ),
      ]),
    );
  }
}

class _TrainingsPanel extends StatelessWidget {
  final bool hasTeam;
  final VoidCallback onOpenPlans;
  final VoidCallback onOpenGraphics;
  final VoidCallback onOpenCalendar;
  final VoidCallback onOpenFullTeam;

  const _TrainingsPanel(
      {required this.hasTeam,
      required this.onOpenPlans,
      required this.onOpenGraphics,
      required this.onOpenCalendar,
      required this.onOpenFullTeam});

  @override
  Widget build(BuildContext context) {
    if (!hasTeam) return const _NeedTeam();
    return GridView.count(
      crossAxisCount: 2,
      mainAxisSpacing: 12,
      crossAxisSpacing: 12,
      childAspectRatio: 2.1,
      children: [
        _ModuleCard(
            icon: Icons.folder_copy_rounded,
            title: 'Планы-конспекты',
            subtitle: 'Папки, программы, вложения',
            onTap: onOpenPlans),
        _ModuleCard(
            icon: Icons.draw_rounded,
            title: 'Графический редактор',
            subtitle: 'Схемы и упражнения',
            onTap: onOpenGraphics),
        _ModuleCard(
            icon: Icons.calendar_month_rounded,
            title: 'Календарь тренировок',
            subtitle: 'Расписание и события',
            onTap: onOpenCalendar),
        _ModuleCard(
            icon: Icons.assignment_turned_in_rounded,
            title: 'Посещаемость и оценка',
            subtitle: 'Журнал и рейтинг тренировки',
            onTap: onOpenFullTeam),
      ],
    );
  }
}

class _TeamModulePanel extends StatelessWidget {
  final bool hasTeam;
  final String title;
  final String subtitle;
  final IconData icon;
  final String primaryText;
  final VoidCallback onPrimary;
  final List<_ModuleQuickAction> quickActions;

  const _TeamModulePanel(
      {required this.hasTeam,
      required this.title,
      required this.subtitle,
      required this.icon,
      required this.primaryText,
      required this.onPrimary,
      this.quickActions = const []});

  @override
  Widget build(BuildContext context) {
    if (!hasTeam) return const _NeedTeam();

    final width = MediaQuery.of(context).size.width;
    final isMobile = width < 700;
    final columns = isMobile ? 2 : (width < 1180 ? 2 : 3);
    final headerPadding = isMobile ? 16.0 : 20.0;
    final iconSize = isMobile ? 52.0 : 60.0;
    final titleSize = isMobile ? 16.2 : 18.2;
    final subtitleSize = isMobile ? 11.4 : 12.2;

    final internalCards = <_ModuleQuickAction>[
      ...quickActions,
      _ModuleQuickAction('Полный модуль', Icons.open_in_new_rounded, onPrimary),
    ];

    return ListView(
      padding: EdgeInsets.only(right: isMobile ? 0 : 2, bottom: 24),
      children: [
        Container(
          padding: EdgeInsets.all(headerPadding),
          decoration: _cardDecoration(radius: isMobile ? 24 : 30),
          child: isMobile
              ? Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _IconBadge(icon: icon, size: iconSize, iconSize: 27),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                title,
                                maxLines: isMobile ? 2 : 1,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  fontSize: titleSize,
                                  height: 1.05,
                                  fontWeight: FontWeight.w900,
                                  color: _C.text,
                                ),
                              ),
                              const SizedBox(height: 6),
                              Text(
                                subtitle,
                                maxLines: 4,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(
                                  color: _C.muted,
                                  height: 1.25,
                                  fontSize: subtitleSize,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: _GreenButton(
                        icon: Icons.open_in_new_rounded,
                        text: primaryText,
                        onTap: onPrimary,
                      ),
                    ),
                  ],
                )
              : Row(
                  children: [
                    _IconBadge(icon: icon, size: iconSize, iconSize: 31),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: titleSize,
                              height: 1.05,
                              fontWeight: FontWeight.w900,
                              color: _C.text,
                            ),
                          ),
                          const SizedBox(height: 7),
                          Text(
                            subtitle,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              color: _C.muted,
                              height: 1.28,
                              fontSize: subtitleSize,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 12),
                    Flexible(
                      flex: 0,
                      child: _GreenButton(
                        icon: Icons.open_in_new_rounded,
                        text: primaryText,
                        onTap: onPrimary,
                        large: width > 1120,
                      ),
                    ),
                  ],
                ),
        ),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: columns,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            childAspectRatio: isMobile ? 1.55 : 2.25,
          ),
          itemCount: internalCards.length,
          itemBuilder: (_, index) {
            final action = internalCards[index];
            return _ModuleCard(
              icon: action.icon,
              title: action.text,
              subtitle: index == internalCards.length - 1
                  ? 'Открыть рабочий экран'
                  : 'Быстрое действие',
              onTap: action.onTap,
            );
          },
        ),
      ],
    );
  }
}

class _ModuleQuickAction {
  final String text;
  final IconData icon;
  final VoidCallback onTap;
  const _ModuleQuickAction(this.text, this.icon, this.onTap);
}

class _TeamGuard extends StatelessWidget {
  final bool hasTeam;
  final Widget child;
  const _TeamGuard({required this.hasTeam, required this.child});
  @override
  Widget build(BuildContext context) =>
      hasTeam ? child : const _NeedTeam();
}

class _NeedTeam extends StatelessWidget {
  const _NeedTeam();
  @override
  Widget build(BuildContext context) => const _SolidPlaceholder(
      icon: Icons.info_rounded,
      title: 'Сначала выберите команду',
      subtitle:
          'Откройте раздел «Команды клуба» и выберите команду для работы.',
      chips: ['Команды', 'Состав', 'Матчи']);
}

class _SolidPlaceholder extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final List<String> chips;
  const _SolidPlaceholder(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.chips});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        constraints: const BoxConstraints(maxWidth: 650),
        padding: const EdgeInsets.all(28),
        decoration: _cardDecoration(radius: 32),
        child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _IconBadge(icon: icon, size: 76, iconSize: 38),
              const SizedBox(height: 16),
              Text(title,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                      color: _C.text)),
              const SizedBox(height: 8),
              Text(subtitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                      color: _C.muted, height: 1.45)),
              const SizedBox(height: 18),
              Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.center,
                  children: chips
                      .map((e) => _LightChip(text: e))
                      .toList()),
            ]),
      ),
    );
  }
}

class _SolidCard extends StatelessWidget {
  final String title;
  final Widget child;
  final Widget? trailing;
  const _SolidCard({required this.title, required this.child, this.trailing});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(radius: 28),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Expanded(
                  child: Text(title,
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                          color: _C.text))),
              if (trailing != null) trailing!
            ]),
            const SizedBox(height: 14),
            child,
          ]),
    );
  }
}

class _ClubHeroCard extends StatelessWidget {
  final String clubName;
  final String? clubLogo;
  final String clubDescription;

  const _ClubHeroCard({
    required this.clubName,
    required this.clubLogo,
    required this.clubDescription,
  });

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    final compact = width < 1120;
    final description = clubDescription.trim().isEmpty
        ? 'Единый рабочий кабинет клуба: команды, составы, тренеры, события и аналитика.'
        : clubDescription.trim();

    return Container(
      padding: EdgeInsets.all(compact ? 16 : 20),
      decoration: _cardDecoration(radius: 30),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _LogoBox(url: clubLogo, size: compact ? 58 : 70, bgColor: Colors.white),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  clubName,
                  maxLines: compact ? 2 : 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _C.text,
                    fontSize: compact ? 18 : 21,
                    height: 1.06,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  description,
                  maxLines: compact ? 3 : 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: _C.muted,
                    fontSize: compact ? 12.2 : 13.2,
                    height: 1.36,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;
  final Color color;
  const _HeroStat(
      {required this.value,
      required this.title,
      this.color = _C.primaryGreen});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 92,
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
          color: _C.softFor(color),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(.16))),
      child: Column(children: [
        Text(value,
            style: TextStyle(
                color: color,
                fontSize: 22,
                fontWeight: FontWeight.w900)),
        const SizedBox(height: 1),
        Text(title,
            style: const TextStyle(
                color: _C.muted,
                fontSize: 11,
                fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  final VoidCallback onTap;
  const _MetricCard(
      {required this.icon,
      required this.title,
      required this.value,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(22),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: _cardDecoration(radius: 22),
        child: Row(
          children: [
            _IconBadge(icon: icon, size: 38, iconSize: 20),
            const SizedBox(width: 9),
            Expanded(
              child: Text(
                title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _C.muted,
                  fontSize: 11,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            const SizedBox(width: 6),
            FittedBox(
              fit: BoxFit.scaleDown,
              child: Text(
                value,
                style: TextStyle(
                  fontSize: 21,
                  fontWeight: FontWeight.w900,
                  color: _C.accentForIcon(icon),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ModuleCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _ModuleCard(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = _C.accentForIcon(icon);
    final width = MediaQuery.of(context).size.width;
    final mobile = width < 700;
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Container(
        padding: EdgeInsets.all(mobile ? 13 : 16),
        decoration: _cardDecoration(radius: 24),
        child: Row(
          children: [
            _IconBadge(icon: icon, size: mobile ? 40 : 46, iconSize: mobile ? 20 : 23),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: mobile ? 12.2 : 14.2,
                      height: 1.08,
                      fontWeight: FontWeight.w900,
                      color: _C.text,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: mobile ? 1 : 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: _C.muted,
                      fontSize: mobile ? 10.4 : 11.2,
                      height: 1.15,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 4),
            Icon(Icons.chevron_right_rounded, color: accent, size: mobile ? 20 : 24),
          ],
        ),
      ),
    );
  }
}

class _ActionPill extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;
  const _ActionPill({required this.icon, required this.text, this.onTap});

  @override
  Widget build(BuildContext context) {
    final accent = _C.accentForIcon(icon);
    return InkWell(
      borderRadius: BorderRadius.circular(99),
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 210),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: _C.softFor(accent),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: accent.withOpacity(.14)),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: accent, size: 17),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: accent,
                  fontWeight: FontWeight.w900,
                  fontSize: 11.8,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GreenButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  final bool large;
  const _GreenButton(
      {required this.icon,
      required this.text,
      required this.onTap,
      this.large = false});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(maxWidth: 320),
        padding: EdgeInsets.symmetric(
          horizontal: large ? 18 : 13,
          vertical: large ? 14 : 11,
        ),
        decoration: BoxDecoration(
          color: _C.primaryGreen,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: _C.primaryGreen.withOpacity(.22),
              blurRadius: 18,
              offset: const Offset(0, 8),
            )
          ],
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white, size: large ? 21 : 18),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                  fontSize: large ? 12.2 : 11.2,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _WhiteButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  const _WhiteButton(
      {required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
            horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: _C.black, size: 19),
          const SizedBox(width: 8),
          Text(text,
              style: const TextStyle(
                  color: _C.black,
                  fontWeight: FontWeight.w900,
                  fontSize: 13)),
        ]),
      ),
    );
  }
}

class _IconCircleButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _IconCircleButton(
      {required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
              color: _C.soft2,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.border)),
          child: Icon(icon, color: _C.primaryGreen)),
    );
  }
}

class _SmallIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _SmallIconButton(
      {required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(
              color: _C.soft2,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: _C.border)),
          child: Icon(icon,
              color: _C.primaryGreen, size: 20)),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String title;
  final String value;
  final IconData? icon;
  const _MiniStat(
      {required this.title, required this.value, this.icon});

  @override
  Widget build(BuildContext context) {
    final accent = icon == null
        ? _C.primaryGreen
        : _C.accentForIcon(icon!);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: _C.softFor(accent),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
              color: accent.withOpacity(.12))),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              if (icon != null)
                Icon(icon, color: accent, size: 15),
              if (icon != null) const SizedBox(width: 6),
              Expanded(
                  child: Text(title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          color: _C.muted,
                          fontSize: 12,
                          fontWeight: FontWeight.w700)))
            ]),
            const SizedBox(height: 5),
            Text(value,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    color: _C.text,
                    fontWeight: FontWeight.w900)),
          ]),
    );
  }
}

class _DarkChip extends StatelessWidget {
  final String text;
  const _DarkChip({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(.12),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(
              color: Colors.white.withOpacity(.06))),
      child: Text(text,
          style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w800)),
    );
  }
}

class _LightChip extends StatelessWidget {
  final String text;
  const _LightChip({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
          horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
          color: Colors.white.withOpacity(.86),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: _C.border)),
      child: Text(text,
          style: const TextStyle(
              color: _C.black,
              fontWeight: FontWeight.w800)),
    );
  }
}

class _EventRow extends StatelessWidget {
  final String title;
  final String date;
  const _EventRow({required this.title, required this.date});

  @override
  Widget build(BuildContext context) {
    const accent = _C.teal;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: _C.tealSoft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: accent.withOpacity(.16))),
      child: Row(children: [
        Container(
            width: 34,
            height: 34,
            decoration: BoxDecoration(
                color: Colors.white.withOpacity(.9),
                borderRadius: BorderRadius.circular(12)),
            child: const Icon(
                Icons.event_available_rounded,
                color: accent,
                size: 18)),
        const SizedBox(width: 10),
        Expanded(
            child: Text(title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontWeight: FontWeight.w900,
                    color: _C.text))),
        const SizedBox(width: 10),
        Text(date,
            style: const TextStyle(
                color: _C.muted,
                fontSize: 12,
                fontWeight: FontWeight.w700)),
      ]),
    );
  }
}

class _EmptyText extends StatelessWidget {
  final String text;
  const _EmptyText(this.text);
  @override
  Widget build(BuildContext context) => Text(text,
      textAlign: TextAlign.center,
      style: const TextStyle(
          color: _C.muted, height: 1.4));
}

class _EmptyTeams extends StatelessWidget {
  final VoidCallback onCreateTeam;
  const _EmptyTeams({required this.onCreateTeam});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: _SolidPlaceholder(
        icon: Icons.account_tree_rounded,
        title: 'Команды ещё не добавлены',
        subtitle:
            'Создайте первую команду клуба, чтобы открыть состав, матчи и тренировочный процесс.',
        chips: const ['Команда', 'Состав', 'Матчи'],
      ),
    );
  }
}

class _LargeActionButton extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _LargeActionButton(
      {required this.icon,
      required this.title,
      required this.subtitle,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(24),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: _cardDecoration(radius: 24),
        child: Row(children: [
          _IconBadge(icon: icon, size: 50, iconSize: 28),
          const SizedBox(width: 14),
          Expanded(
              child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                Text(title,
                    style: const TextStyle(
                        fontSize: 17,
                        fontWeight: FontWeight.w900,
                        color: _C.text)),
                const SizedBox(height: 4),
                Text(subtitle,
                    style: const TextStyle(
                        color: _C.muted)),
              ])),
          Icon(Icons.chevron_right_rounded,
              color: _C.accentForIcon(icon)),
        ]),
      ),
    );
  }
}

class _LogoBox extends StatelessWidget {
  final String? url;
  final double size;
  final Color? bgColor;
  const _LogoBox(
      {required this.url, required this.size, this.bgColor});

  @override
  Widget build(BuildContext context) {
    final hasUrl = url != null &&
        url!.trim().isNotEmpty &&
        url != 'null';
    return Container(
      width: size,
      height: size,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
          color: bgColor ?? _C.soft,
          borderRadius:
              BorderRadius.circular(size * .34),
          border: Border.all(
              color: Colors.black.withOpacity(.045))),
      child: hasUrl
          ? Image.network(url!,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Icon(
                  Icons.shield_rounded,
                  color: _C.primaryGreen,
                  size: size * .48))
          : Icon(Icons.shield_rounded,
              color: _C.primaryGreen,
              size: size * .48),
    );
  }
}

class _RotateTabletHint extends StatelessWidget {
  final String clubName;
  final String? clubLogo;
  const _RotateTabletHint(
      {required this.clubName, required this.clubLogo});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.bg,
      body: Center(
        child: Container(
          width: 520,
          padding: const EdgeInsets.all(30),
          decoration: _cardDecoration(radius: 34),
          child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _LogoBox(
                    url: clubLogo,
                    size: 78,
                    bgColor: _C.soft),
                const SizedBox(height: 20),
                Text(clubName,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w900,
                        color: _C.text)),
                const SizedBox(height: 8),
                const Text(
                    'Для полноценного рабочий кабинет-кабинета поверните планшет горизонтально.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: _C.muted,
                        height: 1.45)),
                const SizedBox(height: 22),
                const Icon(
                    Icons.screen_rotation_alt_rounded,
                    color: _C.primaryGreen,
                    size: 58),
              ]),
        ),
      ),
    );
  }
}

class _ProfileLine extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  const _ProfileLine(
      {required this.icon,
      required this.title,
      required this.value});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Icon(icon,
          color: _C.accentForIcon(icon), size: 22),
      const SizedBox(width: 12),
      Text('$title:',
          style: const TextStyle(
              color: _C.muted,
              fontWeight: FontWeight.w700)),
      const SizedBox(width: 8),
      Expanded(
          child: Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                  color: _C.text,
                  fontWeight: FontWeight.w900))),
    ]);
  }
}

class _IconBadge extends StatelessWidget {
  final IconData icon;
  final double size;
  final double iconSize;
  final Color? color;
  const _IconBadge(
      {required this.icon,
      this.size = 58,
      this.iconSize = 30,
      this.color});

  @override
  Widget build(BuildContext context) {
    final accent = color ?? _C.accentForIcon(icon);
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
          color: _C.softFor(accent),
          borderRadius:
              BorderRadius.circular(size * .34),
          border: Border.all(
              color: accent.withOpacity(.18))),
      child: Icon(icon, color: accent, size: iconSize),
    );
  }
}

BoxDecoration _cardDecoration({double radius = 28}) {
  return BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.circular(radius),
    border: Border.all(color: _C.border),
    boxShadow: [
      BoxShadow(
          color: Colors.black.withOpacity(.032),
          blurRadius: 20,
          offset: const Offset(0, 10))
    ],
  );
}

class _ClubChatPanel extends StatelessWidget {
  final int userId;
  final VoidCallback onOpenFullChat;

  const _ClubChatPanel({
    required this.userId,
    required this.onOpenFullChat,
  });

  @override
  Widget build(BuildContext context) {
    if (userId <= 0) {
      return const _SolidPlaceholder(
        icon: Icons.forum_rounded,
        title: 'Чаты недоступны',
        subtitle:
            'Не удалось определить пользователя для загрузки чатов.',
        chips: ['Личные', 'Группы', 'Команда'],
      );
    }

    return Container(
      decoration: _cardDecoration(radius: 30),
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.fromLTRB(18, 14, 18, 12),
            decoration: BoxDecoration(
              color: _C.purpleSoft,
              border: Border(
                bottom: BorderSide(
                    color: _C.purple.withOpacity(.12)),
              ),
            ),
            child: Row(
              children: [
                const _IconBadge(
                  icon: Icons.forum_rounded,
                  size: 48,
                  iconSize: 24,
                  color: _C.purple,
                ),
                const SizedBox(width: 12),
                const Expanded(
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Чаты клуба',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _C.text,
                          fontSize: 18,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      SizedBox(height: 3),
                      Text(
                        'Личные диалоги, группы и командное общение внутри рабочий кабинет',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          color: _C.muted,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
                _SmallIconButton(
                  icon: Icons.open_in_new_rounded,
                  onTap: onOpenFullChat,
                ),
              ],
            ),
          ),
          Expanded(
            child: ClipRect(
              child: ChatScreen(
                userId: userId,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ClubIntroSplash extends StatelessWidget {
  final Animation<double> animation;
  const _ClubIntroSplash({required this.animation});

  @override
  Widget build(BuildContext context) {
    final ballValue = CurvedAnimation(
            parent: animation,
            curve:
                const Interval(0, .42, curve: Curves.elasticOut))
        .value;
    final titleValue = CurvedAnimation(
            parent: animation,
            curve: const Interval(.16, .55,
                curve: Curves.easeOutCubic))
        .value;
    final sloganValue = CurvedAnimation(
            parent: animation,
            curve: const Interval(.32, .68,
                curve: Curves.easeOutCubic))
        .value;
    final fadeOut = CurvedAnimation(
            parent: animation,
            curve: const Interval(.72, 1,
                curve: Curves.easeInOut))
        .value;

    return IgnorePointer(
      child: Opacity(
        opacity: 1 - fadeOut,
        child: Container(
          color: _C.bg,
          child: Stack(children: [
            Positioned(
                top: -120,
                right: -80,
                child: Container(
                    width: 320,
                    height: 320,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.primaryGreen
                            .withOpacity(.055)))),
            Positioned(
                bottom: -140,
                left: -90,
                child: Container(
                    width: 360,
                    height: 360,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: _C.blue
                            .withOpacity(.055)))),
            Center(
              child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Transform.scale(
                      scale:
                          .55 + (.45 * ballValue),
                      child: Transform.rotate(
                        angle: (1 - ballValue) *
                            -0.55,
                        child: Container(
                          width: 124,
                          height: 124,
                          decoration: BoxDecoration(
                              color:
                                  _C.primaryGreen,
                              borderRadius:
                                  BorderRadius
                                      .circular(38),
                              boxShadow: [
                                BoxShadow(
                                    color: _C.primaryGreen
                                        .withOpacity(
                                            .28),
                                    blurRadius: 38,
                                    offset: const Offset(
                                        0, 20))
                              ]),
                          child: const Icon(
                              Icons
                                  .sports_soccer_rounded,
                              color: Colors.white,
                              size: 62),
                        ),
                      ),
                    ),
                    const SizedBox(height: 30),
                    Opacity(
                        opacity: titleValue,
                        child: Transform.translate(
                            offset: Offset(
                                0,
                                28 *
                                    (1 -
                                        titleValue)),
                            child: const Text(
                                'СПОРТОТЕКА',
                                textAlign:
                                    TextAlign.center,
                                style: TextStyle(
                                    color: _C.text,
                                    fontSize: 48,
                                    height: 1,
                                    letterSpacing:
                                        4.5,
                                    fontWeight:
                                        FontWeight
                                            .w900)))),
                    const SizedBox(height: 14),
                    Opacity(
                      opacity: sloganValue,
                      child:
                          Transform.translate(
                        offset: Offset(
                            0,
                            20 *
                                (1 -
                                    sloganValue)),
                        child: Container(
                          padding: const EdgeInsets
                              .symmetric(
                              horizontal: 22,
                              vertical: 11),
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  BorderRadius
                                      .circular(99),
                              border: Border.all(
                                  color:
                                      _C.border),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors
                                        .black
                                        .withOpacity(
                                            .045),
                                    blurRadius: 18,
                                    offset: const Offset(
                                        0, 8))
                              ]),
                          child: const Text(
                              'Вперёд к победам!',
                              style: TextStyle(
                                  color: _C.muted,
                                  fontSize: 17,
                                  fontWeight:
                                      FontWeight
                                          .w800,
                                  letterSpacing:
                                      .3)),
                        ),
                      ),
                    ),
                  ]),
            ),
          ]),
        ),
      ),
    );
  }
}