// lib/presentation/plans/cmr_plans_panel.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/presentation/plans/plan_detail_screen.dart';
import 'package:sportoteka/presentation/plans/plan_folders_screen.dart';

class CmrPlansPanel extends StatefulWidget {
  final int clubId;
  final String clubName;
  final int? teamId;
  final String teamName;

  /// ВАЖНО:
  /// Используй это, чтобы кнопка назад возвращала не в профиль,
  /// а обратно в меню CMR.
  final VoidCallback? onBackToMenu;

  const CmrPlansPanel({
    super.key,
    required this.clubId,
    required this.clubName,
    required this.teamId,
    required this.teamName,
    this.onBackToMenu,
  });

  @override
  State<CmrPlansPanel> createState() => _CmrPlansPanelState();
}

class _CmrPlansPanelState extends State<CmrPlansPanel> {
  bool loading = true;
  bool saving = false;
  String? error;

  int? selectedFolderId;
  String selectedFolderTitle = 'Все материалы';

  List<Map<String, dynamic>> folders = [];
  List<Map<String, dynamic>> _allFolders = [];

  List<Map<String, dynamic>> plans = [];
  Map<String, dynamic>? selectedPlan;

  final TextEditingController searchCtrl = TextEditingController();
  final TextEditingController themeCtrl = TextEditingController();
  final TextEditingController cycleCtrl = TextEditingController();
  final TextEditingController descriptionCtrl = TextEditingController();
  final TextEditingController dateCtrl = TextEditingController();

  bool editMode = false;
  bool showFoldersList = false;

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse('${v ?? 0}') ?? 0;
  }

  String _asStr(dynamic v) {
    final s = '${v ?? ''}'.trim();
    return s == 'null' ? '' : s;
  }

  bool get _hasTeam => widget.teamId != null && widget.teamId! > 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    searchCtrl.dispose();
    themeCtrl.dispose();
    cycleCtrl.dispose();
    descriptionCtrl.dispose();
    dateCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (!mounted) return;

    setState(() {
      loading = true;
      error = null;
    });

    try {
      final foldersResp = await PlanFoldersApi.list(
        clubId: widget.clubId,
      );

      if (foldersResp['success'] != true) {
        throw foldersResp['message'] ?? 'Не удалось загрузить папки';
      }

      _processFoldersResponse(foldersResp);

      await _loadPlansForTeam();

      if (!mounted) return;
      setState(() {
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = '$e';
      });
    }
  }

  void _processFoldersResponse(Map<String, dynamic> response) {
    final tree = (response['tree'] as List?) ??
        (response['folders'] as List?) ??
        (response['data'] as List?) ??
        (response['items'] as List?) ??
        [];

    final flatFolders = <Map<String, dynamic>>[];

    void walk(List list, [int level = 0, int? parentId]) {
      for (final item in list) {
        if (item is Map) {
          final map = Map<String, dynamic>.from(item);

          map['_level'] = level;

          if (_asInt(map['parent_id']) == 0 && parentId != null) {
            map['parent_id'] = parentId;
          }

          flatFolders.add(map);

          final children = (map['children'] as List?) ?? [];
          if (children.isNotEmpty) {
            walk(children, level + 1, _asInt(map['id']));
          }
        }
      }
    }

    walk(tree);

    _allFolders = flatFolders;
    folders = List<Map<String, dynamic>>.from(flatFolders);
  }

  Future<void> _loadPlansForTeam() async {
    try {
      final resp = await TrainingPlansApi.listPlans(
        clubId: widget.clubId,
        teamId: _hasTeam ? widget.teamId! : 0,
        folderId: selectedFolderId ?? 0,
      );

      if (resp['success'] != true) {
        throw resp['message'] ?? 'Не удалось загрузить планы';
      }

      final raw = (resp['items'] as List?) ??
          (resp['data'] as List?) ??
          (resp['plans'] as List?) ??
          const [];

      var loadedPlans = raw.whereType<Map>().map((e) {
        final map = Map<String, dynamic>.from(e);

        final folderId = _asInt(map['folder_id']);
        if (_asStr(map['folder_title']).isEmpty && folderId > 0) {
          map['folder_title'] = _folderTitleFromList(_allFolders, folderId);
        }

        return map;
      }).toList();

      if (_hasTeam) {
        loadedPlans = loadedPlans.where((p) {
          final planTeamId = _asInt(p['team_id']);

          if (planTeamId == 0) return true;

          return planTeamId == widget.teamId;
        }).toList();
      }

      _rebuildVisibleFoldersForTeam(loadedPlans);

      if (selectedFolderId != null &&
          selectedFolderId! > 0 &&
          !_folderExistsInVisibleList(selectedFolderId!)) {
        selectedFolderId = null;
        selectedFolderTitle = 'Все материалы';
      }

      loadedPlans.sort((a, b) {
        final ad = _asStr(a['created_at']).isNotEmpty
            ? _asStr(a['created_at'])
            : _asStr(a['plan_date']);

        final bd = _asStr(b['created_at']).isNotEmpty
            ? _asStr(b['created_at'])
            : _asStr(b['plan_date']);

        return bd.compareTo(ad);
      });

      final q = searchCtrl.text.trim().toLowerCase();
      var filteredPlans = loadedPlans;

      if (q.isNotEmpty) {
        filteredPlans = loadedPlans.where((p) {
          return _asStr(p['theme']).toLowerCase().contains(q) ||
              _asStr(p['cycle_title']).toLowerCase().contains(q) ||
              _asStr(p['trainer_name']).toLowerCase().contains(q) ||
              _asStr(p['team_name']).toLowerCase().contains(q) ||
              _asStr(p['folder_title']).toLowerCase().contains(q);
        }).toList();
      }

      final oldPlanId = _asInt(selectedPlan?['id']);
      Map<String, dynamic>? nextSelected;

      if (oldPlanId > 0) {
        for (final p in filteredPlans) {
          if (_asInt(p['id']) == oldPlanId) {
            nextSelected = p;
            break;
          }
        }
      }

      nextSelected ??= filteredPlans.isNotEmpty ? filteredPlans.first : null;

      if (!mounted) return;

      setState(() {
        plans = filteredPlans;
        selectedPlan = nextSelected;
      });

      _syncEditors();
    } catch (e) {
      if (!mounted) return;

      setState(() {
        plans = [];
        selectedPlan = null;
      });
    }
  }

  void _rebuildVisibleFoldersForTeam(List<Map<String, dynamic>> teamPlans) {
    if (!_hasTeam) {
      folders = List<Map<String, dynamic>>.from(_allFolders);
      return;
    }

    final usedFolderIds = <int>{};

    for (final p in teamPlans) {
      final folderId = _asInt(p['folder_id']);
      if (folderId > 0) {
        usedFolderIds.add(folderId);
        _collectParents(folderId, usedFolderIds);
      }
    }

    final filtered = <Map<String, dynamic>>[];

    for (final f in _allFolders) {
      final folderId = _asInt(f['id']);
      final folderTeamId = _asInt(f['team_id']);

      final isGlobalFolder = folderTeamId == 0;
      final isTeamFolder = folderTeamId == widget.teamId;
      final hasTeamPlansInside = usedFolderIds.contains(folderId);

      if (isTeamFolder || hasTeamPlansInside || isGlobalFolder) {
        filtered.add(f);
      }
    }

    folders = filtered;
  }

  void _collectParents(int folderId, Set<int> result) {
    final folder = _allFolders.firstWhereOrNull(
      (f) => _asInt(f['id']) == folderId,
    );

    if (folder == null) return;

    final parentId = _asInt(folder['parent_id']);
    if (parentId > 0 && !result.contains(parentId)) {
      result.add(parentId);
      _collectParents(parentId, result);
    }
  }

  bool _folderExistsInVisibleList(int folderId) {
    for (final f in folders) {
      if (_asInt(f['id']) == folderId) return true;
    }
    return false;
  }

  String _folderTitleFromList(
    List<Map<String, dynamic>> list,
    int folderId,
  ) {
    for (final f in list) {
      if (_asInt(f['id']) == folderId) {
        return _asStr(f['title']);
      }
    }
    return '';
  }

  String _folderTitleById(int id) {
    for (final f in _allFolders) {
      if (_asInt(f['id']) == id) return _asStr(f['title']);
    }
    return '';
  }

  void _syncEditors() {
    final p = selectedPlan;

    themeCtrl.text = _asStr(p?['theme']);
    cycleCtrl.text = _asStr(p?['cycle_title']);
    descriptionCtrl.text = _asStr(
      p?['description'] ??
          p?['plan_description'] ??
          p?['comment'] ??
          p?['notes'],
    );
    dateCtrl.text = _asStr(p?['plan_date'] ?? p?['created_at']);
  }

  void _selectFolder(Map<String, dynamic>? folder) {
    setState(() {
      selectedFolderId = folder == null ? null : _asInt(folder['id']);
      selectedFolderTitle = folder == null
          ? 'Все материалы'
          : (_asStr(folder['title']).isEmpty
              ? 'Папка'
              : _asStr(folder['title']));
      selectedPlan = null;
      editMode = false;
      showFoldersList = false;
    });

    _loadPlansForTeam();
  }

  void _selectPlan(Map<String, dynamic> plan) {
    setState(() {
      selectedPlan = plan;
      editMode = false;
    });

    _syncEditors();
  }

  void _handleBack() {
    if (editMode) {
      setState(() => editMode = false);
      _syncEditors();
      return;
    }

    if (showFoldersList) {
      setState(() => showFoldersList = false);
      return;
    }

    if (selectedPlan != null && _isMobile(context)) {
      setState(() => selectedPlan = null);
      return;
    }

    if (widget.onBackToMenu != null) {
      widget.onBackToMenu!();
      return;
    }

    Get.back();
  }

  Future<void> _createFolder() async {
    final parentId = selectedFolderId;
    final titleCtrl = TextEditingController();
    String type = parentId == null ? 'age' : 'custom';

    final ok = await Get.dialog<bool>(
      StatefulBuilder(
        builder: (context, setLocalState) {
          return AlertDialog(
            title: const Text('Новая папка'),
            content: SizedBox(
              width: _isMobile(context) ? double.infinity : 420,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  TextField(
                    controller: titleCtrl,
                    autofocus: true,
                    decoration: const InputDecoration(
                      labelText: 'Название папки',
                      hintText: 'Например: U-8 или Передачи',
                    ),
                  ),
                  const SizedBox(height: 14),
                  DropdownButtonFormField<String>(
                    value: type,
                    decoration: const InputDecoration(labelText: 'Тип папки'),
                    items: const [
                      DropdownMenuItem(
                        value: 'age',
                        child: Text('Возраст'),
                      ),
                      DropdownMenuItem(
                        value: 'category',
                        child: Text('Категория'),
                      ),
                      DropdownMenuItem(
                        value: 'custom',
                        child: Text('Произвольная'),
                      ),
                    ],
                    onChanged: (v) {
                      setLocalState(() => type = v ?? 'custom');
                    },
                  ),
                  const SizedBox(height: 10),
                  Text(
                    parentId == null
                        ? 'Папка будет создана в корне дерева.'
                        : 'Папка будет создана внутри «$selectedFolderTitle».',
                    style: const TextStyle(
                      color: _C.muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Get.back(result: false),
                child: const Text('Отмена'),
              ),
              ElevatedButton(
                onPressed: () => Get.back(result: true),
                child: const Text('Создать'),
              ),
            ],
          );
        },
      ),
    );

    if (ok != true) return;

    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;

    setState(() => saving = true);

    try {
      final r = await PlanFoldersApi.create(
        clubId: widget.clubId,
        parentId: parentId,
        title: title,
        type: type,
        createdBy: widget.clubId,
      );

      if (r['success'] != true) {
        throw r['message'] ?? 'Не удалось создать папку';
      }

      await _load();
      Get.snackbar('Готово', 'Папка создана');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _renameSelectedFolder() async {
    final id = selectedFolderId;

    if (id == null || id <= 0) {
      Get.snackbar('Папка', 'Выберите папку для переименования');
      return;
    }

    final titleCtrl = TextEditingController(text: selectedFolderTitle);

    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Переименовать папку'),
        content: TextField(
          controller: titleCtrl,
          autofocus: true,
          decoration: const InputDecoration(
            labelText: 'Новое название',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Отмена'),
          ),
          ElevatedButton(
            onPressed: () => Get.back(result: true),
            child: const Text('Сохранить'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    final title = titleCtrl.text.trim();
    if (title.isEmpty) return;

    setState(() => saving = true);

    try {
      final r = await PlanFoldersApi.rename(
        clubId: widget.clubId,
        folderId: id,
        title: title,
      );

      if (r['success'] != true) {
        throw r['message'] ?? 'Не удалось переименовать папку';
      }

      selectedFolderTitle = title;

      await _load();
      Get.snackbar('Готово', 'Папка переименована');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _deleteSelectedFolder() async {
    final id = selectedFolderId;

    if (id == null || id <= 0) {
      Get.snackbar('Папка', 'Выберите папку для удаления');
      return;
    }

    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Удалить папку?'),
        content: Text(
          'Папка «$selectedFolderTitle» будет удалена. '
          'Если внутри есть материалы, сервер может запретить удаление.',
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(
              foregroundColor: _C.red,
            ),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    setState(() => saving = true);

    try {
      final r = await PlanFoldersApi.remove(
        clubId: widget.clubId,
        folderId: id,
      );

      if (r['success'] != true) {
        throw r['message'] ?? 'Не удалось удалить папку';
      }

      selectedFolderId = null;
      selectedFolderTitle = 'Все материалы';
      selectedPlan = null;

      await _load();
      Get.snackbar('Готово', 'Папка удалена');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _deleteSelectedPlan() async {
    final plan = selectedPlan;
    if (plan == null) return;

    final planId = _asInt(plan['id']);
    if (planId <= 0) return;

    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Удалить план?'),
        content: Text('План «${_planTitle(plan)}» будет удалён.'),
        actions: [
          TextButton(
            onPressed: () => Get.back(result: false),
            child: const Text('Отмена'),
          ),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );

    if (ok != true) return;

    setState(() => saving = true);

    try {
      final r = await TrainingPlansApi.deletePlan(
        clubId: widget.clubId,
        planId: planId,
      );

      if (r['success'] != true) {
        throw r['message'] ?? 'Не удалось удалить план';
      }

      selectedPlan = null;

      await _loadPlansForTeam();
      Get.snackbar('Готово', 'План удалён');
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> _saveSelectedPlan() async {
    final plan = selectedPlan;
    if (plan == null) return;

    final planId = _asInt(plan['id']);
    if (planId <= 0) return;

    setState(() => saving = true);

    try {
      final payload = <String, dynamic>{
        'id': planId,
        'plan_id': planId,
        'club_id': widget.clubId,
        'team_id': widget.teamId ?? _asInt(plan['team_id']),
        'folder_id': selectedFolderId ?? _asInt(plan['folder_id']),
        'theme': themeCtrl.text.trim(),
        'cycle_title': cycleCtrl.text.trim(),
        'description': descriptionCtrl.text.trim(),
        'plan_description': descriptionCtrl.text.trim(),
        'plan_date': dateCtrl.text.trim(),
      };

      final response = await http
          .post(
            Uri.parse('${TrainingPlansApi.base}/update_training_plan.php'),
            headers: const {
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode(payload),
          )
          .timeout(const Duration(seconds: 12));

      final data = jsonDecode(response.body);

      if (data is! Map || data['success'] != true) {
        throw data is Map
            ? (data['message'] ?? 'Не удалось сохранить')
            : 'Не удалось сохранить';
      }

      if (!mounted) return;

      setState(() => editMode = false);

      await _loadPlansForTeam();
      Get.snackbar('Готово', 'План сохранён');
    } catch (e) {
      Get.snackbar(
        'Сохранение',
        'Не удалось сохранить. Ошибка: $e',
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void _openFullFoldersScreen() {
    Get.to(
      () => PlanFoldersScreen(
        clubId: widget.clubId,
        clubName: widget.clubName,
        teamId: widget.teamId,
        selectMode: false,
        browsePlansMode: false,
      ),
    );
  }

  void _openFullPlanScreen() {
    final plan = selectedPlan;
    if (plan == null) return;

    Get.to(
      () => const PlanDetailScreen(),
      arguments: {
        'planId': _asInt(plan['id']),
        'clubId': widget.clubId,
        'clubName': widget.clubName,
        'teamId': widget.teamId ?? _asInt(plan['team_id']),
        'teamName': _asStr(plan['team_name']).isNotEmpty
            ? _asStr(plan['team_name'])
            : widget.teamName,
        'folderId': selectedFolderId ?? _asInt(plan['folder_id']),
        'folderName': selectedFolderTitle,
        'trainerName': _asStr(plan['trainer_name']),
      },
    );
  }

  String _planTitle(Map<String, dynamic> plan) {
    final theme = _asStr(plan['theme']);
    if (theme.isNotEmpty) return theme;

    final cycle = _asStr(plan['cycle_title']);
    if (cycle.isNotEmpty) return cycle;

    return 'План #${_asInt(plan['id'])}';
  }

  bool _isMobile(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return size.width < 600;
  }

  @override
  Widget build(BuildContext context) {
    final isMobile = _isMobile(context);

    if (loading) {
      return Container(
        decoration: _C.cardDecoration,
        child: Column(
          children: [
            const LinearProgressIndicator(
              minHeight: 4,
              color: _C.green,
              backgroundColor: _C.soft,
            ),
            Expanded(
              child: Center(
                child: Container(
                  constraints: const BoxConstraints(maxWidth: 520),
                  padding: EdgeInsets.all(isMobile ? 16 : 28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        Icons.folder_copy_rounded,
                        color: _C.greenDark,
                        size: isMobile ? 40 : 58,
                      ),
                      SizedBox(height: isMobile ? 12 : 18),
                      Text(
                        'Загружаем планы',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _C.text,
                          fontSize: isMobile ? 18 : 24,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Собираем папки, планы-конспекты и материалы команды...',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: _C.muted,
                          fontSize: isMobile ? 12 : 14,
                          height: 1.45,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: isMobile ? 16 : 22),
                      SizedBox(
                        width: isMobile ? 32 : 42,
                        height: isMobile ? 32 : 42,
                        child: const CircularProgressIndicator(
                          strokeWidth: 3,
                          color: _C.green,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      );
    }

    if (error != null) {
      return _CmrEmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить планы',
        text: error!,
        actionText: 'Повторить',
        onAction: _load,
        isMobile: isMobile,
      );
    }

    if (isMobile) return _buildMobileLayout();

    return Stack(
      children: [
        Row(
          children: [
            SizedBox(
              width: 410,
              child: _buildLeftColumn(),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: _buildPlanEditor(),
            ),
          ],
        ),
        if (saving)
          const Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: LinearProgressIndicator(
              minHeight: 4,
              color: _C.green,
              backgroundColor: _C.soft,
            ),
          ),
      ],
    );
  }

  Widget _buildMobileLayout() {
    return Stack(
      children: [
        Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.05),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: _handleBack,
                        icon: const Icon(Icons.arrow_back_rounded),
                        color: _C.greenDark,
                        iconSize: 22,
                      ),
                      const SizedBox(width: 8),
                      const _CmrIconBox(
                        icon: Icons.folder_copy_rounded,
                        size: 40,
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              selectedFolderTitle,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: _C.text,
                              ),
                            ),
                            Text(
                              '${folders.length} папок • ${plans.length} материалов',
                              style: const TextStyle(
                                color: _C.muted,
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: () {
                          setState(() {
                            showFoldersList = !showFoldersList;
                          });
                        },
                        icon: Icon(
                          showFoldersList
                              ? Icons.list_alt
                              : Icons.folder_open_rounded,
                        ),
                        color: _C.greenDark,
                        iconSize: 22,
                      ),
                      IconButton(
                        onPressed: saving ? null : _load,
                        icon: const Icon(Icons.refresh_rounded),
                        color: _C.greenDark,
                        iconSize: 22,
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: searchCtrl,
                    onSubmitted: (_) => _loadPlansForTeam(),
                    style: const TextStyle(fontSize: 14),
                    decoration: InputDecoration(
                      hintText: 'Поиск по планам',
                      hintStyle: const TextStyle(fontSize: 13),
                      prefixIcon: const Icon(
                        Icons.search_rounded,
                        size: 20,
                      ),
                      suffixIcon: searchCtrl.text.isEmpty
                          ? null
                          : IconButton(
                              onPressed: () {
                                searchCtrl.clear();
                                _loadPlansForTeam();
                              },
                              icon: const Icon(
                                Icons.close_rounded,
                                size: 18,
                              ),
                            ),
                      filled: true,
                      fillColor: _C.soft,
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 12,
                        vertical: 10,
                      ),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: _MiniToolButton(
                          icon: Icons.create_new_folder_rounded,
                          text: 'Добавить',
                          onTap: saving ? null : _createFolder,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: _MiniToolButton(
                          icon: Icons.drive_file_rename_outline_rounded,
                          text: 'Переименовать',
                          onTap: saving ? null : _renameSelectedFolder,
                        ),
                      ),
                      const SizedBox(width: 6),
                      _IconToolButton(
                        icon: Icons.delete_outline_rounded,
                        danger: true,
                        onTap: saving ? null : _deleteSelectedFolder,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (showFoldersList)
              Expanded(
                child: _buildFoldersList(),
              )
            else if (plans.isEmpty)
              Expanded(
                child: _buildNoPlans(),
              )
            else
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: plans.length,
                  itemBuilder: (context, index) {
                    final plan = plans[index];
                    final active =
                        _asInt(plan['id']) == _asInt(selectedPlan?['id']);

                    return Card(
                      margin: const EdgeInsets.only(bottom: 8),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(
                          color: active
                              ? _C.green.withOpacity(0.3)
                              : _C.border,
                        ),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 8,
                        ),
                        leading: const _CmrIconBox(
                          icon: Icons.menu_book_rounded,
                          size: 36,
                        ),
                        title: Text(
                          _planTitle(plan),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w800,
                            color: active ? _C.greenDark : _C.text,
                          ),
                        ),
                        subtitle: Text(
                          _asStr(plan['folder_title']).isNotEmpty
                              ? _asStr(plan['folder_title'])
                              : _folderTitleById(_asInt(plan['folder_id'])),
                          style: const TextStyle(
                            fontSize: 11,
                            color: _C.muted,
                          ),
                        ),
                        trailing: active
                            ? const Icon(
                                Icons.check_circle,
                                color: _C.green,
                                size: 20,
                              )
                            : const Icon(
                                Icons.chevron_right,
                                color: _C.muted,
                                size: 20,
                              ),
                        onTap: () => _selectPlan(plan),
                      ),
                    );
                  },
                ),
              ),
          ],
        ),
        if (selectedPlan != null && !showFoldersList)
          Positioned(
            right: 12,
            bottom: 12,
            child: FloatingActionButton(
              onPressed: _openFullPlanScreen,
              backgroundColor: _C.green,
              child: const Icon(
                Icons.open_in_new,
                color: Colors.white,
              ),
            ),
          ),
        if (saving)
          const Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: LinearProgressIndicator(
              minHeight: 3,
              color: _C.green,
              backgroundColor: _C.soft,
            ),
          ),
      ],
    );
  }

  Widget _buildFoldersList() {
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: folders.length + 1,
      itemBuilder: (_, index) {
        if (index == 0) {
          return _FolderRow(
            title: 'Все материалы',
            subtitle: 'Показать планы из всех папок',
            level: 0,
            active: selectedFolderId == null,
            onTap: () => _selectFolder(null),
          );
        }

        final f = folders[index - 1];

        return _FolderRow(
          title: _asStr(f['title']).isEmpty ? 'Папка' : _asStr(f['title']),
          subtitle: _asStr(f['type']).isEmpty ? null : _asStr(f['type']),
          level: _asInt(f['_level']),
          active: selectedFolderId == _asInt(f['id']),
          onTap: () => _selectFolder(f),
        );
      },
    );
  }

  Widget _buildNoPlans() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: const [
          Icon(
            Icons.menu_book_rounded,
            size: 48,
            color: _C.muted,
          ),
          SizedBox(height: 12),
          Text(
            'Материалы не найдены',
            style: TextStyle(
              color: _C.muted,
              fontWeight: FontWeight.w800,
              fontSize: 16,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLeftColumn() {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: _handleBack,
                      icon: const Icon(Icons.arrow_back_rounded),
                      color: _C.greenDark,
                      padding: EdgeInsets.zero,
                      constraints: const BoxConstraints(
                        minWidth: 40,
                        minHeight: 40,
                      ),
                    ),
                    const SizedBox(width: 4),
                    const _CmrIconBox(
                      icon: Icons.folder_copy_rounded,
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            selectedFolderTitle,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _C.title,
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '${folders.length} папок • ${plans.length} материалов',
                            style: const TextStyle(
                              color: _C.muted,
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: saving ? null : _load,
                      icon: const Icon(Icons.refresh_rounded),
                      color: _C.greenDark,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: searchCtrl,
                  onSubmitted: (_) => _loadPlansForTeam(),
                  decoration: InputDecoration(
                    hintText: 'Поиск по планам',
                    prefixIcon: const Icon(Icons.search_rounded),
                    suffixIcon: searchCtrl.text.isEmpty
                        ? null
                        : IconButton(
                            onPressed: () {
                              searchCtrl.clear();
                              _loadPlansForTeam();
                            },
                            icon: const Icon(Icons.close_rounded),
                          ),
                    filled: true,
                    fillColor: _C.soft,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _MiniToolButton(
                        icon: Icons.create_new_folder_rounded,
                        text: 'Добавить',
                        onTap: saving ? null : _createFolder,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _MiniToolButton(
                        icon: Icons.drive_file_rename_outline_rounded,
                        text: 'Переименовать',
                        onTap: saving ? null : _renameSelectedFolder,
                      ),
                    ),
                    const SizedBox(width: 8),
                    _IconToolButton(
                      icon: Icons.delete_outline_rounded,
                      danger: true,
                      onTap: saving ? null : _deleteSelectedFolder,
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(
            height: 1,
            color: _C.border,
          ),
          SizedBox(
            height: 250,
            child: ListView.separated(
              padding: const EdgeInsets.fromLTRB(14, 14, 14, 12),
              itemCount: folders.length + 1,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, index) {
                if (index == 0) {
                  return _FolderRow(
                    title: 'Все материалы',
                    subtitle: 'Показать планы из всех папок',
                    level: 0,
                    active: selectedFolderId == null,
                    onTap: () => _selectFolder(null),
                  );
                }

                final f = folders[index - 1];

                return _FolderRow(
                  title:
                      _asStr(f['title']).isEmpty ? 'Папка' : _asStr(f['title']),
                  subtitle:
                      _asStr(f['type']).isEmpty ? null : _asStr(f['type']),
                  level: _asInt(f['_level']),
                  active: selectedFolderId == _asInt(f['id']),
                  onTap: () => _selectFolder(f),
                );
              },
            ),
          ),
          const Divider(
            height: 1,
            color: _C.border,
          ),
          Expanded(
            child: plans.isEmpty
                ? const Center(
                    child: Text(
                      'Материалы не найдены',
                      style: TextStyle(
                        color: _C.muted,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  )
                : ListView.separated(
                    padding: const EdgeInsets.all(14),
                    itemCount: plans.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, index) {
                      final plan = plans[index];

                      final active =
                          _asInt(plan['id']) == _asInt(selectedPlan?['id']);

                      return _PlanListTile(
                        plan: plan,
                        title: _planTitle(plan),
                        folderTitle: _asStr(plan['folder_title']).isNotEmpty
                            ? _asStr(plan['folder_title'])
                            : _folderTitleById(_asInt(plan['folder_id'])),
                        active: active,
                        onTap: () => _selectPlan(plan),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlanEditor() {
    final plan = selectedPlan;

    if (plan == null) {
      return _CmrEmptyState(
        icon: Icons.menu_book_rounded,
        title: selectedFolderId == null ? 'Все материалы' : selectedFolderTitle,
        text:
            'Выберите план слева. Здесь будет просмотр и редактирование прямо внутри CMR.',
        actionText: 'Открыть полный модуль',
        onAction: _openFullFoldersScreen,
      );
    }

    final trainer = _asStr(plan['trainer_name']);
    final team =
        _asStr(plan['team_name']).isNotEmpty ? _asStr(plan['team_name']) : widget.teamName;

    final createdAt = _asStr(plan['created_at']);
    final planDate = _asStr(plan['plan_date']);

    final folderTitle = _asStr(plan['folder_title']).isNotEmpty
        ? _asStr(plan['folder_title'])
        : _folderTitleById(_asInt(plan['folder_id']));

    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: _C.darkGreen,
              borderRadius: BorderRadius.vertical(
                top: Radius.circular(28),
              ),
            ),
            child: Row(
              children: [
                const _CmrIconBox(
                  icon: Icons.assignment_rounded,
                  dark: true,
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _planTitle(plan),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: _C.darkTitle,
                      ),
                      const SizedBox(height: 8),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _DarkChip(
                            text: team.isEmpty ? 'Команда' : team,
                          ),
                          if (folderTitle.isNotEmpty)
                            _DarkChip(text: folderTitle),
                          if (trainer.isNotEmpty) _DarkChip(text: trainer),
                          if (planDate.isNotEmpty)
                            _DarkChip(
                              text: planDate.length > 10
                                  ? planDate.substring(0, 10)
                                  : planDate,
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                _HeaderButton(
                  icon: editMode ? Icons.close_rounded : Icons.edit_rounded,
                  text: editMode ? 'Отмена' : 'Редактировать',
                  onTap: () {
                    setState(() => editMode = !editMode);
                    _syncEditors();
                  },
                ),
                const SizedBox(width: 8),
                _HeaderButton(
                  icon: Icons.open_in_new_rounded,
                  text: 'Полный экран',
                  onTap: _openFullPlanScreen,
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Row(
                  children: [
                    Expanded(
                      child: _InfoCard(
                        title: 'Команда',
                        value: team.isEmpty ? '—' : team,
                        icon: Icons.shield_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Папка',
                        value: folderTitle.isEmpty ? '—' : folderTitle,
                        icon: Icons.folder_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Тренер',
                        value: trainer.isEmpty ? '—' : trainer,
                        icon: Icons.badge_rounded,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(
                      child: _InfoCard(
                        title: 'Дата плана',
                        value: planDate.isEmpty ? '—' : planDate,
                        icon: Icons.event_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'Создан',
                        value: createdAt.isEmpty
                            ? '—'
                            : createdAt.substring(
                                0,
                                createdAt.length.clamp(0, 10),
                              ),
                        icon: Icons.calendar_today_rounded,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: _InfoCard(
                        title: 'ID плана',
                        value: '${_asInt(plan['id'])}',
                        icon: Icons.tag_rounded,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _EditorCard(
                  title: 'Тема занятия',
                  icon: Icons.title_rounded,
                  editMode: editMode,
                  controller: themeCtrl,
                  value: _asStr(plan['theme']).isEmpty
                      ? 'Без темы'
                      : _asStr(plan['theme']),
                ),
                const SizedBox(height: 12),
                _EditorCard(
                  title: 'Цикл / раздел',
                  icon: Icons.account_tree_rounded,
                  editMode: editMode,
                  controller: cycleCtrl,
                  value: _asStr(plan['cycle_title']).isEmpty
                      ? 'Не указан'
                      : _asStr(plan['cycle_title']),
                ),
                const SizedBox(height: 12),
                _EditorCard(
                  title: 'Дата плана',
                  icon: Icons.event_rounded,
                  editMode: editMode,
                  controller: dateCtrl,
                  value: planDate.isEmpty ? 'Не указана' : planDate,
                ),
                const SizedBox(height: 12),
                _EditorCard(
                  title: 'Описание / заметки',
                  icon: Icons.notes_rounded,
                  editMode: editMode,
                  controller: descriptionCtrl,
                  value: descriptionCtrl.text.trim().isEmpty
                      ? 'Описание пока не заполнено.'
                      : descriptionCtrl.text.trim(),
                  maxLines: 8,
                ),
                const SizedBox(height: 18),
                if (editMode)
                  Row(
                    children: [
                      Expanded(
                        child: _PrimaryButton(
                          text: saving
                              ? 'Сохранение...'
                              : 'Сохранить изменения',
                          icon: Icons.save_rounded,
                          onTap: saving ? null : _saveSelectedPlan,
                        ),
                      ),
                      const SizedBox(width: 10),
                      _DangerButton(
                        text: 'Удалить план',
                        icon: Icons.delete_outline_rounded,
                        onTap: saving ? null : _deleteSelectedPlan,
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _C {
  static const Color green = Color(0xFF1F8A4C);
  static const Color greenDark = Color(0xFF176B3A);
  static const Color darkGreen = Color(0xFF0B3324);
  static const Color card = Colors.white;
  static const Color soft = Color(0xFFF1F6F3);
  static const Color text = Color(0xFF111827);
  static const Color muted = Color(0xFF667085);
  static const Color border = Color(0xFFE3E8E5);
  static const Color red = Color(0xFFDC2626);

  static BoxDecoration get cardDecoration => BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.035),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      );

  static const TextStyle title = TextStyle(
    color: text,
    fontSize: 18,
    fontWeight: FontWeight.w900,
    height: 1.15,
  );

  static const TextStyle darkTitle = TextStyle(
    color: Colors.white,
    fontSize: 24,
    fontWeight: FontWeight.w900,
    height: 1.05,
  );
}

class _CmrIconBox extends StatelessWidget {
  final IconData icon;
  final bool dark;
  final double size;

  const _CmrIconBox({
    required this.icon,
    this.dark = false,
    this.size = 52,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: dark ? Colors.white.withOpacity(.12) : _C.soft,
        borderRadius: BorderRadius.circular(size * 0.35),
        border: Border.all(
          color: dark ? Colors.white.withOpacity(.12) : _C.border,
        ),
      ),
      child: Icon(
        icon,
        color: dark ? Colors.white : _C.greenDark,
        size: size * 0.5,
      ),
    );
  }
}

class _MiniToolButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;

  const _MiniToolButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return InkWell(
      borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
      onTap: onTap,
      child: Container(
        height: isMobile ? 40 : 44,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: _C.greenDark,
              size: isMobile ? 16 : 18,
            ),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  color: _C.text,
                  fontSize: isMobile ? 11 : 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IconToolButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final bool danger;

  const _IconToolButton({
    required this.icon,
    required this.onTap,
    this.danger = false,
  });

  @override
  Widget build(BuildContext context) {
    final isMobile = MediaQuery.of(context).size.width < 600;

    return InkWell(
      borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
      onTap: onTap,
      child: Container(
        width: isMobile ? 40 : 44,
        height: isMobile ? 40 : 44,
        decoration: BoxDecoration(
          color: danger ? const Color(0xFFFFF1F2) : _C.soft,
          borderRadius: BorderRadius.circular(isMobile ? 12 : 16),
          border: Border.all(
            color: danger ? const Color(0xFFFECACA) : _C.border,
          ),
        ),
        child: Icon(
          icon,
          color: danger ? _C.red : _C.greenDark,
          size: isMobile ? 18 : 20,
        ),
      ),
    );
  }
}

class _FolderRow extends StatelessWidget {
  final String title;
  final String? subtitle;
  final int level;
  final bool active;
  final VoidCallback onTap;

  const _FolderRow({
    required this.title,
    this.subtitle,
    required this.level,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isChild = level > 0;

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        margin: EdgeInsets.only(left: level * 18.0),
        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 12),
        decoration: BoxDecoration(
          color: active ? _C.darkGreen : Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: active ? _C.darkGreen : _C.border,
          ),
        ),
        child: Row(
          children: [
            Icon(
              isChild
                  ? Icons.subdirectory_arrow_right_rounded
                  : Icons.folder_rounded,
              color: active ? Colors.white : _C.greenDark,
              size: 20,
            ),
            const SizedBox(width: 9),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: active ? Colors.white : _C.text,
                      fontSize: isChild ? 12.5 : 13.5,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  if (subtitle != null && subtitle!.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color:
                            active ? Colors.white.withOpacity(.66) : _C.muted,
                        fontSize: 10.5,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanListTile extends StatelessWidget {
  final Map<String, dynamic> plan;
  final String title;
  final String folderTitle;
  final bool active;
  final VoidCallback onTap;

  const _PlanListTile({
    required this.plan,
    required this.title,
    required this.folderTitle,
    required this.active,
    required this.onTap,
  });

  String _s(dynamic v) => '${v ?? ''}'.trim();

  @override
  Widget build(BuildContext context) {
    final date = _s(plan['plan_date'] ?? plan['created_at']);
    final team = _s(plan['team_name']);

    final meta = [
      if (folderTitle.isNotEmpty) folderTitle,
      if (team.isNotEmpty) team,
      if (date.isNotEmpty) date.length > 10 ? date.substring(0, 10) : date,
    ].join(' • ');

    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: active ? _C.soft : const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: active ? _C.green.withOpacity(.28) : _C.border,
          ),
        ),
        child: Row(
          children: [
            const _CmrIconBox(
              icon: Icons.menu_book_rounded,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: _C.title.copyWith(fontSize: 14.5),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    meta.isEmpty ? 'План-конспект' : meta,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      color: _C.muted,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right_rounded,
              color: active ? _C.greenDark : _C.muted,
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;

  const _InfoCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        children: [
          Icon(
            icon,
            color: _C.greenDark,
            size: 21,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.muted,
                    fontSize: 11.5,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.text,
                    fontSize: 14,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EditorCard extends StatelessWidget {
  final String title;
  final IconData icon;
  final bool editMode;
  final TextEditingController controller;
  final String value;
  final int maxLines;

  const _EditorCard({
    required this.title,
    required this.icon,
    required this.editMode,
    required this.controller,
    required this.value,
    this.maxLines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _C.cardDecoration.copyWith(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                color: _C.greenDark,
                size: 20,
              ),
              const SizedBox(width: 9),
              Text(
                title,
                style: _C.title.copyWith(fontSize: 16),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (editMode)
            TextField(
              controller: controller,
              maxLines: maxLines,
              decoration: InputDecoration(
                filled: true,
                fillColor: _C.soft,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: _C.border),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(16),
                  borderSide: const BorderSide(color: _C.border),
                ),
              ),
            )
          else
            Text(
              value,
              style: const TextStyle(
                color: _C.text,
                fontSize: 15,
                fontWeight: FontWeight.w700,
                height: 1.45,
              ),
            ),
        ],
      ),
    );
  }
}

class _DarkChip extends StatelessWidget {
  final String text;

  const _DarkChip({
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 7,
      ),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.12),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _HeaderButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 11,
        ),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: Colors.white.withOpacity(.14),
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: Colors.white,
              size: 18,
            ),
            const SizedBox(width: 7),
            Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback? onTap;

  const _PrimaryButton({
    required this.text,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(text),
      style: ElevatedButton.styleFrom(
        backgroundColor: _C.green,
        foregroundColor: Colors.white,
        elevation: 0,
        minimumSize: const Size.fromHeight(52),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        textStyle: const TextStyle(
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _DangerButton extends StatelessWidget {
  final String text;
  final IconData icon;
  final VoidCallback? onTap;

  const _DangerButton({
    required this.text,
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Text(text),
      style: OutlinedButton.styleFrom(
        foregroundColor: _C.red,
        side: const BorderSide(
          color: Color(0xFFFECACA),
        ),
        minimumSize: const Size(158, 52),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
        ),
        textStyle: const TextStyle(
          fontWeight: FontWeight.w900,
        ),
      ),
    );
  }
}

class _CmrEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String? actionText;
  final VoidCallback? onAction;
  final bool isMobile;

  const _CmrEmptyState({
    required this.icon,
    required this.title,
    required this.text,
    this.actionText,
    this.onAction,
    this.isMobile = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: EdgeInsets.all(isMobile ? 16 : 28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                icon,
                color: _C.greenDark,
                size: isMobile ? 40 : 54,
              ),
              SizedBox(height: isMobile ? 10 : 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: _C.title.copyWith(
                  fontSize: isMobile ? 18 : 22,
                ),
              ),
              SizedBox(height: isMobile ? 6 : 8),
              Text(
                text,
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.muted,
                  height: 1.45,
                  fontWeight: FontWeight.w600,
                  fontSize: isMobile ? 12 : 14,
                ),
              ),
              if (actionText != null && onAction != null) ...[
                SizedBox(height: isMobile ? 12 : 18),
                SizedBox(
                  width: isMobile ? 200 : 230,
                  child: _PrimaryButton(
                    text: actionText!,
                    icon: Icons.open_in_new_rounded,
                    onTap: onAction,
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}