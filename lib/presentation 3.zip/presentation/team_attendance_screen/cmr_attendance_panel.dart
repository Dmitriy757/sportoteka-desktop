// lib/presentation/attendance/cmr_attendance_panel.dart
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/utils/pref_utils.dart';

class CmrAttendancePanel extends StatefulWidget {
  final int teamId;
  final String teamName;
  final int clubId;
  final String clubName;

  const CmrAttendancePanel({
    super.key,
    required this.teamId,
    required this.teamName,
    required this.clubId,
    required this.clubName,
  });

  @override
  State<CmrAttendancePanel> createState() => _CmrAttendancePanelState();
}

class _CmrAttendancePanelState extends State<CmrAttendancePanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';

  static const String getPlayersUrl = '$apiBase/get_players.php';
  static const String getEventsUrl = '$apiBase/get_team_events.php';
  static const String getAttendanceUrl = '$apiBase/get_attendance.php';
  static const String saveAttendanceUrl = '$apiBase/save_attendance.php';

  bool loading = true;
  bool saving = false;
  bool refreshing = false;
  String? error;

  DateTime selectedDate = DateTime.now();

  List<Map<String, dynamic>> events = [];
  List<Map<String, dynamic>> players = [];

  int? selectedEventId;
  String selectedEventTitle = 'Мероприятие не выбрано';

  final Map<int, String> statuses = {};
  final Map<int, TextEditingController> commentCtrls = {};

  int currentUserId = 0;

  String get _dateSql {
    return '${selectedDate.year.toString().padLeft(4, '0')}-'
        '${selectedDate.month.toString().padLeft(2, '0')}-'
        '${selectedDate.day.toString().padLeft(2, '0')}';
  }

  int _asInt(dynamic v) {
    if (v is int) return v;
    if (v is num) return v.toInt();
    return int.tryParse('${v ?? 0}') ?? 0;
  }

  String _s(dynamic v) {
    final text = '${v ?? ''}'.trim();
    return text == 'null' ? '' : text;
  }

  dynamic _decode(String body) {
    final clear = body.trim();
    final startObj = clear.indexOf('{');
    final startArr = clear.indexOf('[');
    final starts = [startObj, startArr].where((e) => e >= 0).toList();
    if (starts.isEmpty) return {};
    final start = starts.reduce((a, b) => a < b ? a : b);
    return jsonDecode(clear.substring(start));
  }

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    for (final c in commentCtrls.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _init() async {
    currentUserId = await PrefUtils.getUserId() ?? 0;
    await _load(initial: true);
  }

  Future<void> _load({bool initial = false}) async {
    if (!mounted) return;

    setState(() {
      if (initial) {
        loading = true;
      } else {
        refreshing = true;
      }
      error = null;
    });

    try {
      await _loadEvents();
      await _loadPlayers();
      await _loadAttendance();

      if (!mounted) return;
      setState(() {
        loading = false;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        refreshing = false;
        error = '$e';
      });
    }
  }

  Future<void> _loadEvents() async {
    final response = await http
        .post(
          Uri.parse(getEventsUrl),
          headers: const {'Content-Type': 'application/json; charset=utf-8'},
          body: jsonEncode({
            'team_id': widget.teamId,
            'club_id': widget.clubId,
            'date': _dateSql,
            'event_date': _dateSql,
          }),
        )
        .timeout(const Duration(seconds: 14));

    final data = _decode(response.body);

    final raw = data is Map
        ? ((data['events'] as List?) ??
            (data['data'] as List?) ??
            (data['items'] as List?) ??
            const [])
        : const [];

    events = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();

    if (events.isNotEmpty) {
      final exists = selectedEventId != null &&
          events.any((e) => _asInt(e['id']) == selectedEventId);

      if (!exists) {
        selectedEventId = _asInt(events.first['id']);
        selectedEventTitle = _eventTitle(events.first);
      } else {
        final current = events.firstWhere((e) => _asInt(e['id']) == selectedEventId);
        selectedEventTitle = _eventTitle(current);
      }
    } else {
      selectedEventId = null;
      selectedEventTitle = 'На выбранную дату мероприятий нет';
    }
  }

  Future<void> _loadPlayers() async {
    final response = await http
        .post(
          Uri.parse(getPlayersUrl),
          headers: const {'Content-Type': 'application/json; charset=utf-8'},
          body: jsonEncode({'team_id': widget.teamId}),
        )
        .timeout(const Duration(seconds: 14));

    final data = _decode(response.body);

    final raw = data is Map
        ? ((data['players'] as List?) ??
            (data['data'] as List?) ??
            (data['items'] as List?) ??
            const [])
        : const [];

    players = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();

    for (final p in players) {
      final id = _playerId(p);
      statuses.putIfAbsent(id, () => 'present');
      commentCtrls.putIfAbsent(id, () => TextEditingController());
    }
  }

  Future<void> _loadAttendance() async {
    if (selectedEventId == null || selectedEventId! <= 0) {
      statuses.clear();
      for (final p in players) {
        statuses[_playerId(p)] = 'present';
      }
      return;
    }

    final response = await http
        .post(
          Uri.parse(getAttendanceUrl),
          headers: const {'Content-Type': 'application/json; charset=utf-8'},
          body: jsonEncode({
            'team_id': widget.teamId,
            'club_id': widget.clubId,
            'event_id': selectedEventId,
            'date': _dateSql,
            'attendance_date': _dateSql,
          }),
        )
        .timeout(const Duration(seconds: 14));

    final data = _decode(response.body);

    final raw = data is Map
        ? ((data['attendance'] as List?) ??
            (data['data'] as List?) ??
            (data['items'] as List?) ??
            const [])
        : const [];

    final rows = raw.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList();

    statuses.clear();

    for (final p in players) {
      final id = _playerId(p);
      statuses[id] = 'present';
      commentCtrls.putIfAbsent(id, () => TextEditingController());
      commentCtrls[id]!.text = '';
    }

    for (final row in rows) {
      final playerId = _asInt(row['player_id'] ?? row['student_id'] ?? row['user_id']);
      if (playerId <= 0) continue;

      statuses[playerId] = _s(row['status']).isEmpty ? 'present' : _s(row['status']);
      commentCtrls.putIfAbsent(playerId, () => TextEditingController());
      commentCtrls[playerId]!.text = _s(row['comment'] ?? row['notes']);
    }
  }

  Future<void> _save() async {
    if (selectedEventId == null || selectedEventId! <= 0) {
      Get.snackbar('Посещаемость', 'Сначала выберите мероприятие');
      return;
    }

    setState(() => saving = true);

    try {
      final items = players.map((p) {
        final id = _playerId(p);
        return {
          'player_id': id,
          'status': statuses[id] ?? 'present',
          'comment': commentCtrls[id]?.text.trim() ?? '',
        };
      }).toList();

      final response = await http
          .post(
            Uri.parse(saveAttendanceUrl),
            headers: const {'Content-Type': 'application/json; charset=utf-8'},
            body: jsonEncode({
              'team_id': widget.teamId,
              'club_id': widget.clubId,
              'event_id': selectedEventId,
              'event_title': selectedEventTitle,
              'date': _dateSql,
              'attendance_date': _dateSql,
              'created_by': currentUserId,
              'items': items,
            }),
          )
          .timeout(const Duration(seconds: 16));

      final data = _decode(response.body);

      if (data is! Map || data['success'] != true) {
        throw data is Map ? (data['message'] ?? 'Не удалось сохранить') : 'Не удалось сохранить';
      }

      Get.snackbar('Готово', 'Посещаемость сохранена');
      await _load();
    } catch (e) {
      Get.snackbar('Ошибка', '$e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  int _playerId(Map<String, dynamic> p) {
    return _asInt(p['id'] ?? p['player_id'] ?? p['user_id']);
  }

  String _playerName(Map<String, dynamic> p) {
    final first = _s(p['first_name'] ?? p['firstname']);
    final last = _s(p['last_name'] ?? p['lastname']);
    final full = '$first $last'.trim();
    if (full.isNotEmpty) return full;
    final name = _s(p['fullName'] ?? p['name']);
    return name.isEmpty ? 'Игрок #${_playerId(p)}' : name;
  }

  String _playerSub(Map<String, dynamic> p) {
    final position = _s(p['position'] ?? p['role']);
    final number = _s(p['number']);
    final parts = [
      if (position.isNotEmpty) position,
      if (number.isNotEmpty) '№ $number',
    ];
    return parts.isEmpty ? widget.teamName : parts.join(' • ');
  }

  String _photo(Map<String, dynamic> p) {
    return _s(p['photo'] ?? p['avatar'] ?? p['image']);
  }

  String _eventTitle(Map<String, dynamic> e) {
    final title = _s(e['title'] ?? e['name']);
    if (title.isNotEmpty) return title;

    final type = _s(e['type']);
    final time = _s(e['start_time'] ?? e['time']);
    final parts = [
      if (type.isNotEmpty) type,
      if (time.isNotEmpty) time,
    ];

    return parts.isEmpty ? 'Мероприятие #${_asInt(e['id'])}' : parts.join(' • ');
  }

  String _eventSub(Map<String, dynamic> e) {
    final start = _s(e['start_time'] ?? e['start_at'] ?? e['date']);
    final location = _s(e['location']);
    final parts = [
      if (start.isNotEmpty) start,
      if (location.isNotEmpty) location,
    ];
    return parts.isEmpty ? _dateSql : parts.join(' • ');
  }

  int get presentCount => statuses.values.where((e) => e == 'present').length;
  int get lateCount => statuses.values.where((e) => e == 'late').length;
  int get absentCount => statuses.values.where((e) => e == 'absent').length;
  int get medicalCount => statuses.values.where((e) => e == 'medical').length;

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );

    if (picked == null) return;

    setState(() {
      selectedDate = picked;
      selectedEventId = null;
      selectedEventTitle = 'Мероприятие не выбрано';
    });

    await _load();
  }

  void _changeEvent(int? id) {
    if (id == null) return;

    final event = events.firstWhereOrNull((e) => _asInt(e['id']) == id);

    setState(() {
      selectedEventId = id;
      selectedEventTitle = event == null ? 'Мероприятие #$id' : _eventTitle(event);
    });

    _load();
  }

  void _setAll(String status) {
    setState(() {
      for (final p in players) {
        statuses[_playerId(p)] = status;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    if (loading) {
      return const _LoadingCard();
    }

    if (error != null) {
      return _EmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить посещаемость',
        text: error!,
        actionText: 'Повторить',
        onAction: () => _load(initial: true),
      );
    }

    return Stack(
      children: [
        Row(
          children: [
            SizedBox(width: 410, child: _buildLeftPanel()),
            const SizedBox(width: 12),
            Expanded(child: _buildMainPanel()),
          ],
        ),
        if (saving || refreshing)
          const Positioned(
            left: 0,
            right: 0,
            top: 0,
            child: LinearProgressIndicator(
              minHeight: 4,
              color: _C.green,
              backgroundColor: _C.soft,
            ),
          ),
      ],
    );
  }

  Widget _buildLeftPanel() {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: const BoxDecoration(
              color: _C.darkGreen,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Column(
              children: [
                Row(
                  children: [
                    const _IconBox(icon: Icons.fact_check_rounded, dark: true),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            widget.teamName,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: _C.darkTitle.copyWith(fontSize: 19),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            'Посещаемость команды',
                            style: TextStyle(
                              color: Colors.white.withOpacity(.68),
                              fontSize: 12,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ],
                      ),
                    ),
                    _HeaderIconButton(
                      icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded,
                      onTap: () => _load(),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _HeroStat(value: '${players.length}', title: 'игроков')),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: '$presentCount', title: 'на месте')),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: '$absentCount', title: 'нет')),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              children: [
                _DateSelector(
                  dateText: _dateSql,
                  onTap: _pickDate,
                ),
                const SizedBox(height: 10),
                DropdownButtonFormField<int>(
                  value: selectedEventId,
                  isExpanded: true,
                  decoration: InputDecoration(
                    labelText: 'Мероприятие',
                    filled: true,
                    fillColor: _C.soft,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(18),
                      borderSide: BorderSide.none,
                    ),
                  ),
                  items: events.map((e) {
                    final id = _asInt(e['id']);
                    return DropdownMenuItem<int>(
                      value: id,
                      child: Text(
                        _eventTitle(e),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    );
                  }).toList(),
                  onChanged: events.isEmpty ? null : _changeEvent,
                ),
                if (events.isEmpty) ...[
                  const SizedBox(height: 10),
                  const _HintBox(
                    text: 'На выбранную дату нет мероприятий. Создайте тренировку или событие в календаре.',
                  ),
                ],
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: _MiniToolButton(
                        icon: Icons.check_circle_rounded,
                        text: 'Все были',
                        onTap: () => _setAll('present'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _MiniToolButton(
                        icon: Icons.cancel_rounded,
                        text: 'Все нет',
                        onTap: () => _setAll('absent'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const Divider(height: 1, color: _C.border),
          Expanded(
            child: events.isEmpty
                ? const _MiniEmpty(text: 'Выберите дату с мероприятием')
                : ListView.separated(
                    padding: const EdgeInsets.all(14),
                    itemCount: events.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, index) {
                      final e = events[index];
                      final id = _asInt(e['id']);
                      return _EventTile(
                        title: _eventTitle(e),
                        subtitle: _eventSub(e),
                        active: selectedEventId == id,
                        onTap: () => _changeEvent(id),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainPanel() {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: _C.darkGreen,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Row(
              children: [
                const _IconBox(icon: Icons.event_available_rounded, dark: true),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        selectedEventTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: _C.darkTitle.copyWith(fontSize: 23),
                      ),
                      const SizedBox(height: 7),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          _DarkChip(text: _dateSql),
                          _DarkChip(text: '${players.length} игроков'),
                          _DarkChip(text: '$presentCount присутствуют'),
                          if (lateCount > 0) _DarkChip(text: '$lateCount опоздали'),
                          if (medicalCount > 0) _DarkChip(text: '$medicalCount мед. причина'),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 12),
                _HeaderButton(
                  icon: Icons.save_rounded,
                  text: saving ? 'Сохранение...' : 'Сохранить',
                  onTap: saving ? null : _save,
                ),
              ],
            ),
          ),
          Expanded(
            child: players.isEmpty
                ? const _MiniEmpty(text: 'Игроки команды не найдены')
                : ListView.separated(
                    padding: const EdgeInsets.all(18),
                    itemCount: players.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, index) {
                      final p = players[index];
                      final id = _playerId(p);
                      return _PlayerAttendanceCard(
                        name: _playerName(p),
                        subtitle: _playerSub(p),
                        photo: _photo(p),
                        status: statuses[id] ?? 'present',
                        commentController: commentCtrls[id]!,
                        onStatusChanged: (value) {
                          setState(() => statuses[id] = value);
                        },
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _C {
  static const Color green = Color(0xFF1F8A4C);
  static const Color greenDark = Color(0xFF176B3A);
  static const Color darkGreen = Color(0xFF0B3324);
  static const Color card = Colors.white;
  static const Color soft = Color(0xFFF1F6F3);
  static const Color text = Color(0xFF111827);
  static const Color muted = Color(0xFF667085);
  static const Color border = Color(0xFFE3E8E5);
  static const Color red = Color(0xFFDC2626);
  static const Color orange = Color(0xFFF59E0B);
  static const Color blue = Color(0xFF2563EB);

  static BoxDecoration get cardDecoration => BoxDecoration(
        color: card,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: border),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.035),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      );

  static const TextStyle title = TextStyle(
    color: text,
    fontSize: 18,
    fontWeight: FontWeight.w900,
    height: 1.15,
  );

  static const TextStyle darkTitle = TextStyle(
    color: Colors.white,
    fontSize: 24,
    fontWeight: FontWeight.w900,
    height: 1.05,
  );
}

class _LoadingCard extends StatelessWidget {
  const _LoadingCard();

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: const Column(
        children: [
          LinearProgressIndicator(
            minHeight: 4,
            color: _C.green,
            backgroundColor: _C.soft,
          ),
          Expanded(
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.fact_check_rounded, color: _C.greenDark, size: 58),
                  SizedBox(height: 18),
                  Text(
                    'Загружаем посещаемость',
                    style: TextStyle(
                      color: _C.text,
                      fontSize: 24,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text(
                    'Собираем мероприятия, игроков и отметки команды...',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: _C.muted,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 22),
                  SizedBox(
                    width: 42,
                    height: 42,
                    child: CircularProgressIndicator(
                      strokeWidth: 3,
                      color: _C.green,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IconBox extends StatelessWidget {
  final IconData icon;
  final bool dark;

  const _IconBox({
    required this.icon,
    this.dark = false,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 52,
      height: 52,
      decoration: BoxDecoration(
        color: dark ? Colors.white.withOpacity(.12) : _C.soft,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: dark ? Colors.white.withOpacity(.12) : _C.border,
        ),
      ),
      child: Icon(
        icon,
        color: dark ? Colors.white : _C.greenDark,
        size: 26,
      ),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;

  const _HeroStat({
    required this.value,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 11),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.10),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        children: [
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w900,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white.withOpacity(.66),
              fontSize: 10.5,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;

  const _HeaderIconButton({
    required this.icon,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(.14)),
        ),
        child: Icon(icon, color: Colors.white),
      ),
    );
  }
}

class _HeaderButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback? onTap;

  const _HeaderButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(.12),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(.14)),
        ),
        child: Row(
          children: [
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 7),
            Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 12.5,
                fontWeight: FontWeight.w900,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DarkChip extends StatelessWidget {
  final String text;

  const _DarkChip({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.12),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Colors.white,
          fontSize: 12,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _DateSelector extends StatelessWidget {
  final String dateText;
  final VoidCallback onTap;

  const _DateSelector({
    required this.dateText,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          children: [
            const Icon(Icons.calendar_today_rounded, color: _C.greenDark, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                dateText,
                style: const TextStyle(
                  color: _C.text,
                  fontSize: 14,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded, color: _C.greenDark),
          ],
        ),
      ),
    );
  }
}

class _MiniToolButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;

  const _MiniToolButton({
    required this.icon,
    required this.text,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 10),
        decoration: BoxDecoration(
          color: _C.soft,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: _C.border),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: _C.greenDark, size: 18),
            const SizedBox(width: 7),
            Flexible(
              child: Text(
                text,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: _C.text,
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _EventTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool active;
  final VoidCallback onTap;

  const _EventTile({
    required this.title,
    required this.subtitle,
    required this.active,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: active ? _C.darkGreen : const Color(0xFFF9FAFB),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? _C.darkGreen : _C.border),
        ),
        child: Row(
          children: [
            Icon(
              Icons.event_note_rounded,
              color: active ? Colors.white : _C.greenDark,
              size: 22,
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: active ? Colors.white : _C.text,
                      fontSize: 14,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: active ? Colors.white.withOpacity(.68) : _C.muted,
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlayerAttendanceCard extends StatelessWidget {
  final String name;
  final String subtitle;
  final String photo;
  final String status;
  final TextEditingController commentController;
  final ValueChanged<String> onStatusChanged;

  const _PlayerAttendanceCard({
    required this.name,
    required this.subtitle,
    required this.photo,
    required this.status,
    required this.commentController,
    required this.onStatusChanged,
  });

  Color get statusColor {
    switch (status) {
      case 'absent':
        return _C.red;
      case 'late':
        return _C.orange;
      case 'medical':
        return _C.blue;
      default:
        return _C.greenDark;
    }
  }

  String get statusText {
    switch (status) {
      case 'absent':
        return 'Отсутствует';
      case 'late':
        return 'Опоздал';
      case 'medical':
        return 'Мед. причина';
      default:
        return 'Присутствует';
    }
  }

  @override
  Widget build(BuildContext context) {
    final hasPhoto = photo.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: _C.border),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 54,
            height: 54,
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(18),
              border: Border.all(color: _C.border),
            ),
            child: hasPhoto
                ? Image.network(
                    photo,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Icon(
                      Icons.person_rounded,
                      color: _C.greenDark,
                    ),
                  )
                : const Icon(Icons.person_rounded, color: _C.greenDark),
          ),
          const SizedBox(width: 13),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: _C.text,
                          fontSize: 15,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(99),
                        border: Border.all(color: statusColor.withOpacity(.25)),
                      ),
                      child: Text(
                        statusText,
                        style: TextStyle(
                          color: statusColor,
                          fontSize: 11.5,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: _C.muted,
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    _StatusButton(
                      text: 'Был',
                      active: status == 'present',
                      color: _C.greenDark,
                      onTap: () => onStatusChanged('present'),
                    ),
                    _StatusButton(
                      text: 'Нет',
                      active: status == 'absent',
                      color: _C.red,
                      onTap: () => onStatusChanged('absent'),
                    ),
                    _StatusButton(
                      text: 'Опоздал',
                      active: status == 'late',
                      color: _C.orange,
                      onTap: () => onStatusChanged('late'),
                    ),
                    _StatusButton(
                      text: 'Мед.',
                      active: status == 'medical',
                      color: _C.blue,
                      onTap: () => onStatusChanged('medical'),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: commentController,
                  minLines: 1,
                  maxLines: 2,
                  decoration: InputDecoration(
                    hintText: 'Комментарий тренера',
                    filled: true,
                    fillColor: Colors.white,
                    contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 11),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: const BorderSide(color: _C.border),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _StatusButton extends StatelessWidget {
  final String text;
  final bool active;
  final Color color;
  final VoidCallback onTap;

  const _StatusButton({
    required this.text,
    required this.active,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(99),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: active ? color : Colors.white,
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: active ? color : _C.border),
        ),
        child: Text(
          text,
          style: TextStyle(
            color: active ? Colors.white : _C.text,
            fontSize: 12,
            fontWeight: FontWeight.w900,
          ),
        ),
      ),
    );
  }
}

class _HintBox extends StatelessWidget {
  final String text;

  const _HintBox({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFFFFFBEB),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFFDE68A)),
      ),
      child: Text(
        text,
        style: const TextStyle(
          color: Color(0xFF92400E),
          fontSize: 12,
          fontWeight: FontWeight.w700,
          height: 1.35,
        ),
      ),
    );
  }
}

class _MiniEmpty extends StatelessWidget {
  final String text;

  const _MiniEmpty({required this.text});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: _C.muted,
            fontWeight: FontWeight.w700,
            height: 1.4,
          ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String? actionText;
  final VoidCallback? onAction;

  const _EmptyState({
    required this.icon,
    required this.title,
    required this.text,
    this.actionText,
    this.onAction,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: _C.cardDecoration,
      child: Center(
        child: Container(
          constraints: const BoxConstraints(maxWidth: 520),
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, color: _C.greenDark, size: 54),
              const SizedBox(height: 14),
              Text(
                title,
                textAlign: TextAlign.center,
                style: _C.title.copyWith(fontSize: 22),
              ),
              const SizedBox(height: 8),
              Text(
                text,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: _C.muted,
                  height: 1.45,
                  fontWeight: FontWeight.w600,
                ),
              ),
              if (actionText != null && onAction != null) ...[
                const SizedBox(height: 18),
                ElevatedButton.icon(
                  onPressed: onAction,
                  icon: const Icon(Icons.refresh_rounded),
                  label: Text(actionText!),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: _C.green,
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(18),
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}