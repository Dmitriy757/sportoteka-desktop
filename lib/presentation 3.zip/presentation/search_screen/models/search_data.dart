
class SearchData{
}