// lib/presentation/team_matches_screen/cmr_team_matches_panel.dart
import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;

import 'package:sportoteka/core/utils/pref_utils.dart';
import 'package:sportoteka/presentation/team_matches_screen/team_match_detail_screen.dart';

enum CmrMatchesFilter { all, upcoming, past }

class CmrTeamMatchesPanel extends StatefulWidget {
  final int teamId;
  final String teamName;
  final int clubId;
  final String clubName;

  const CmrTeamMatchesPanel({
    super.key,
    required this.teamId,
    required this.teamName,
    required this.clubId,
    required this.clubName,
  });

  @override
  State<CmrTeamMatchesPanel> createState() => _CmrTeamMatchesPanelState();
}

class _CmrTeamMatchesPanelState extends State<CmrTeamMatchesPanel> {
  static const String apiBase = 'https://sportotekaapp.ru/api';
  static const String getUrl = '$apiBase/get_team_matches.php';
  static const String addUrl = '$apiBase/add_team_match.php';
  static const String deleteUrl = '$apiBase/delete_team_match.php';
  static const String getUserUrl = '$apiBase/get_user.php';

  final TextEditingController _searchCtrl = TextEditingController();
  Timer? _searchDebounce;

  bool loading = true;
  bool refreshing = false;
  String? error;

  int userId = 0;
  String role = '';
  CmrMatchesFilter filter = CmrMatchesFilter.upcoming;
  DateTime selectedMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);

  List<Map<String, dynamic>> matches = [];

  bool get canEdit => role.toLowerCase().trim() != 'player';

  @override
  void initState() {
    super.initState();
    _searchCtrl.addListener(_onSearchChanged);
    _init();
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearchChanged);
    _searchDebounce?.cancel();
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _init() async {
    userId = await PrefUtils.getUserId() ?? 0;
    role = userId > 0 ? await _fetchRoleByUser(userId) : '';
    await _fetch(initial: true);
  }

  Future<String> _fetchRoleByUser(int uid) async {
    try {
      final res = await http.get(Uri.parse('$getUserUrl?user_id=$uid')).timeout(const Duration(seconds: 15));
      final data = _decodeJsonMap(res.body);
      final ok = data['success'] == true || data['status'] == 'success';
      if (!ok) return '';
      final user = data['user'];
      if (user is Map) return (user['role'] ?? '').toString().trim().toLowerCase();
    } catch (_) {}
    return '';
  }

  Future<void> _fetch({bool initial = false}) async {
    if (!mounted) return;
    setState(() {
      if (initial) {
        loading = true;
      } else {
        refreshing = true;
      }
      error = null;
    });

    try {
      final res = await http.post(
        Uri.parse(getUrl),
        headers: const {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({'team_id': widget.teamId}),
      ).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final ok = data['status'] == 'success' || data['success'] == true;
      if (!ok) throw Exception(data['message']?.toString() ?? 'Не удалось загрузить матчи');

      final list = (data['matches'] as List?) ?? [];
      final parsed = list.map((e) => Map<String, dynamic>.from(e as Map)).toList();
      parsed.sort((a, b) => _parseDate(_s(a['match_date'])).compareTo(_parseDate(_s(b['match_date']))));

      if (!mounted) return;
      setState(() {
        matches = parsed;
        loading = false;
        refreshing = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        loading = false;
        refreshing = false;
        error = e.toString();
      });
    }
  }

  Map<String, dynamic> _decodeJsonMap(String body) {
    final raw = body.trim();
    final start = raw.indexOf('{');
    if (start < 0) throw Exception('Сервер вернул некорректный ответ');
    final decoded = jsonDecode(raw.substring(start));
    if (decoded is! Map) throw Exception('Некорректный формат ответа API');
    return Map<String, dynamic>.from(decoded);
  }

  Future<void> _openCreate() async {
    if (!canEdit) return;
    if (widget.teamId <= 0) {
      Get.snackbar('Ошибка', 'Не удалось определить team_id');
      return;
    }

    final created = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _CmrAddMatchSheet(
        onSubmit: _addMatch,
      ),
    );

    if (created == true) {
      await _fetch();
      Get.snackbar('Готово', 'Матч добавлен');
    }
  }

  Future<bool> _addMatch({
    required String eventType,
    required String opponent,
    required String ourScore,
    required String opponentScore,
    required String matchDate,
    required String competitionName,
    required String tourLabel,
    required String stadium,
    required String referees,
    required String notes,
  }) async {
    if (!canEdit) return false;
    if (opponent.trim().isEmpty || matchDate.trim().isEmpty) {
      Get.snackbar('Ошибка', 'Укажите соперника и дату матча');
      return false;
    }

    try {
      final res = await http.post(
        Uri.parse(addUrl),
        headers: const {'Content-Type': 'application/json; charset=utf-8'},
        body: jsonEncode({
          'team_id': widget.teamId,
          'team_name': widget.teamName.trim().isEmpty ? 'Команда #${widget.teamId}' : widget.teamName,
          'event_type': eventType,
          'opponent': opponent.trim(),
          'our_score': int.tryParse(ourScore.trim()) ?? 0,
          'opponent_score': int.tryParse(opponentScore.trim()) ?? 0,
          'match_date': matchDate,
          'competition_name': competitionName.trim(),
          'tour_label': tourLabel.trim(),
          'stadium': stadium.trim(),
          'referees': referees.trim(),
          'notes': notes.trim(),
        }),
      ).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final ok = data['status'] == 'success' || data['success'] == true;
      if (!ok) {
        Get.snackbar('Ошибка', data['message']?.toString() ?? 'Не удалось добавить матч');
        return false;
      }
      return true;
    } catch (e) {
      Get.snackbar('Ошибка', 'Проверь API add_team_match.php');
      return false;
    }
  }

  Future<void> _deleteMatch(Map<String, dynamic> match) async {
    if (!canEdit) return;
    final id = _i(match['id']);
    if (id <= 0) return;

    final ok = await Get.dialog<bool>(
      AlertDialog(
        title: const Text('Удалить матч?'),
        content: Text('Матч с ${_s(match['opponent']).isEmpty ? 'соперником' : _s(match['opponent'])} будет удалён.'),
        actions: [
          TextButton(onPressed: () => Get.back(result: false), child: const Text('Отмена')),
          TextButton(
            onPressed: () => Get.back(result: true),
            style: TextButton.styleFrom(foregroundColor: _C.red),
            child: const Text('Удалить'),
          ),
        ],
      ),
    );
    if (ok != true) return;

    try {
      final res = await http.post(Uri.parse(deleteUrl), body: {
        'id': id.toString(),
        'team_id': widget.teamId.toString(),
      }).timeout(const Duration(seconds: 20));

      final data = _decodeJsonMap(res.body);
      final success = data['status'] == 'success' || data['success'] == true;
      if (!success) throw Exception(data['message']?.toString() ?? 'Не удалось удалить матч');
      await _fetch();
      Get.snackbar('Готово', 'Матч удалён');
    } catch (e) {
      Get.snackbar('Ошибка', e.toString(), snackPosition: SnackPosition.BOTTOM);
    }
  }

  void _openDetails(Map<String, dynamic> match) {
    Get.to(
      () => const TeamMatchDetailScreen(),
      arguments: {
        'match': match,
        'match_id': _i(match['id']),
        'team_id': widget.teamId,
      },
    );
  }

  void _onSearchChanged() {
    _searchDebounce?.cancel();
    _searchDebounce = Timer(const Duration(milliseconds: 220), () {
      if (mounted) setState(() {});
    });
  }

  String _s(dynamic v) => (v ?? '').toString().trim();
  int _i(dynamic v) => int.tryParse((v ?? '').toString()) ?? 0;

  DateTime _parseDate(String s) {
    try {
      final t = s.trim();
      if (t.contains('.')) {
        final p = t.split('.');
        if (p.length == 3) return DateTime(int.tryParse(p[2]) ?? 2000, int.tryParse(p[1]) ?? 1, int.tryParse(p[0]) ?? 1);
      }
      final d = DateTime.tryParse(t);
      if (d != null) return DateTime(d.year, d.month, d.day);
    } catch (_) {}
    return DateTime(2000, 1, 1);
  }

  String _dateRu(DateTime d) => '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  bool _isUpcoming(DateTime d) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return !d.isBefore(today);
  }

  String _eventTypeLabel(String raw) {
    switch (raw.toLowerCase()) {
      case 'championship':
        return 'Чемпионат';
      case 'friendly':
        return 'Товарищеский';
      case 'tournament':
        return 'Турнир';
      default:
        return raw.isEmpty ? 'Матч' : raw;
    }
  }

  List<Map<String, dynamic>> _visibleMatches() {
    final q = _searchCtrl.text.trim().toLowerCase();
    final first = DateTime(selectedMonth.year, selectedMonth.month, 1);
    final next = DateTime(selectedMonth.year, selectedMonth.month + 1, 1);
    Iterable<Map<String, dynamic>> list = matches.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(first) && d.isBefore(next);
    });

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    if (filter == CmrMatchesFilter.upcoming) {
      list = list.where((m) => !_parseDate(_s(m['match_date'])).isBefore(today));
    } else if (filter == CmrMatchesFilter.past) {
      list = list.where((m) => _parseDate(_s(m['match_date'])).isBefore(today));
    }

    if (q.isNotEmpty) {
      list = list.where((m) {
        final text = '${_s(m['opponent'])} ${_s(m['match_date'])} ${_s(m['event_type'])} ${_s(m['competition_name'])} ${_s(m['stadium'])}'.toLowerCase();
        return text.contains(q);
      });
    }

    final out = list.toList();
    out.sort((a, b) => _parseDate(_s(a['match_date'])).compareTo(_parseDate(_s(b['match_date']))));
    return out;
  }

  List<Map<String, dynamic>> _monthMatches() {
    final first = DateTime(selectedMonth.year, selectedMonth.month, 1);
    final next = DateTime(selectedMonth.year, selectedMonth.month + 1, 1);
    return matches.where((m) {
      final d = _parseDate(_s(m['match_date']));
      return !d.isBefore(first) && d.isBefore(next);
    }).toList();
  }

  Map<DateTime, List<Map<String, dynamic>>> _monthMap() {
    final map = <DateTime, List<Map<String, dynamic>>>{};
    for (final m in _monthMatches()) {
      final d = _parseDate(_s(m['match_date']));
      final key = DateTime(d.year, d.month, d.day);
      (map[key] ??= []).add(m);
    }
    return map;
  }

  int _wins(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) > _i(m['opponent_score'])).length;
  int _draws(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) == _i(m['opponent_score'])).length;
  int _losses(Iterable<Map<String, dynamic>> list) => list.where((m) => _i(m['our_score']) < _i(m['opponent_score'])).length;

  void _prevMonth() {
    setState(() => selectedMonth = DateTime(selectedMonth.year, selectedMonth.month - 1, 1));
  }

  void _nextMonth() {
    setState(() => selectedMonth = DateTime(selectedMonth.year, selectedMonth.month + 1, 1));
  }

  void _thisMonth() {
    final now = DateTime.now();
    setState(() => selectedMonth = DateTime(now.year, now.month, 1));
  }

  String _monthTitle(DateTime d) {
    const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
    return '${months[d.month - 1]} ${d.year}';
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Center(child: CircularProgressIndicator(color: _C.green));
    if (error != null) {
      return _CmrEmptyState(
        icon: Icons.error_outline_rounded,
        title: 'Не удалось загрузить матчи',
        text: error!,
        actionText: 'Повторить',
        onAction: () => _fetch(initial: true),
      );
    }

    final visible = _visibleMatches();
    final monthList = _monthMatches();
    final map = _monthMap();

    return LayoutBuilder(
      builder: (context, c) {
        final compact = c.maxWidth < 860;
        final left = _buildLeftColumn(visible, monthList);
        final right = _buildCalendarArea(map, monthList);

        if (compact) {
          return Column(
            children: [
              SizedBox(height: 365, child: left),
              const SizedBox(height: 12),
              Expanded(child: right),
            ],
          );
        }

        return Row(
          children: [
            SizedBox(width: 390, child: left),
            const SizedBox(width: 12),
            Expanded(child: right),
          ],
        );
      },
    );
  }

  Widget _buildLeftColumn(List<Map<String, dynamic>> visible, List<Map<String, dynamic>> monthList) {
    final upcomingCount = matches.where((m) => _isUpcoming(_parseDate(_s(m['match_date'])))).length;

    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: const BoxDecoration(
              color: _C.darkGreen,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const _CmrIconBox(icon: Icons.sports_soccer_rounded, dark: true),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(widget.teamName, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.darkTitle.copyWith(fontSize: 19)),
                          const SizedBox(height: 4),
                          Text('Матчи команды', maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.68), fontWeight: FontWeight.w700, fontSize: 12)),
                        ],
                      ),
                    ),
                    _HeaderIconButton(icon: refreshing ? Icons.sync_rounded : Icons.refresh_rounded, onTap: () => _fetch()),
                  ],
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: _HeroStat(value: '${matches.length}', title: 'всего')),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: '$upcomingCount', title: 'впереди')),
                    const SizedBox(width: 8),
                    Expanded(child: _HeroStat(value: canEdit ? 'Да' : 'Нет', title: 'редакт.')),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(14),
            child: _CmrSearch(
              controller: _searchCtrl,
              hint: 'Поиск по сопернику, турниру, стадиону',
              onClear: () {
                _searchCtrl.clear();
                setState(() {});
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: Row(
              children: [
                Expanded(child: _FilterButton(text: 'Все', active: filter == CmrMatchesFilter.all, onTap: () => setState(() => filter = CmrMatchesFilter.all))),
                const SizedBox(width: 8),
                Expanded(child: _FilterButton(text: 'Впереди', active: filter == CmrMatchesFilter.upcoming, onTap: () => setState(() => filter = CmrMatchesFilter.upcoming))),
                const SizedBox(width: 8),
                Expanded(child: _FilterButton(text: 'Архив', active: filter == CmrMatchesFilter.past, onTap: () => setState(() => filter = CmrMatchesFilter.past))),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
            child: _SelectedMatchesHeader(
              title: _monthTitle(selectedMonth),
              canEdit: canEdit,
              onAdd: _openCreate,
            ),
          ),
          Expanded(
            child: visible.isEmpty
                ? const _MiniEmpty(text: 'Матчей по выбранным условиям нет')
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                    itemCount: visible.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) {
                      final m = visible[i];
                      return _CmrMatchTile(
                        eventType: _eventTypeLabel(_s(m['event_type'])),
                        opponent: _s(m['opponent']),
                        date: _dateRu(_parseDate(_s(m['match_date']))),
                        competition: _s(m['competition_name']),
                        stadium: _s(m['stadium']),
                        score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                        upcoming: _isUpcoming(_parseDate(_s(m['match_date']))),
                        canEdit: canEdit,
                        onTap: () => _openDetails(m),
                        onDelete: () => _deleteMatch(m),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildCalendarArea(Map<DateTime, List<Map<String, dynamic>>> monthMap, List<Map<String, dynamic>> monthList) {
    return Container(
      decoration: _C.cardDecoration,
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
            ),
            child: Row(
              children: [
                const _CmrIconBox(icon: Icons.event_available_rounded),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_monthTitle(selectedMonth), maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 22)),
                      const SizedBox(height: 4),
                      Text('Победы ${_wins(monthList)} • Ничьи ${_draws(monthList)} • Поражения ${_losses(monthList)}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 12.5)),
                    ],
                  ),
                ),
                _TopActionButton(icon: Icons.today_rounded, text: 'Этот месяц', onTap: _thisMonth),
                const SizedBox(width: 8),
                _SquareButton(icon: Icons.chevron_left_rounded, onTap: _prevMonth),
                const SizedBox(width: 8),
                _SquareButton(icon: Icons.chevron_right_rounded, onTap: _nextMonth),
              ],
            ),
          ),
          const Divider(height: 1, color: _C.border),
          Padding(
            padding: const EdgeInsets.all(14),
            child: _buildStatsRow(monthList),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
              child: _MonthMatchesGrid(
                month: selectedMonth,
                matchesByDay: monthMap,
                dateText: _dateRu,
                onDayTap: (day, list) {
                  if (list.isEmpty) return;
                  _showDayMatches(day, list);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(List<Map<String, dynamic>> monthList) {
    final goalsFor = monthList.fold<int>(0, (v, m) => v + _i(m['our_score']));
    final goalsAgainst = monthList.fold<int>(0, (v, m) => v + _i(m['opponent_score']));
    return Row(
      children: [
        Expanded(child: _MetricCard(icon: Icons.sports_soccer_rounded, title: 'Матчи', value: '${monthList.length}')),
        const SizedBox(width: 10),
        Expanded(child: _MetricCard(icon: Icons.trending_up_rounded, title: 'Голы', value: '$goalsFor:$goalsAgainst')),
        const SizedBox(width: 10),
        Expanded(child: _MetricCard(icon: Icons.emoji_events_outlined, title: 'Победы', value: '${_wins(monthList)}')),
        const SizedBox(width: 10),
        Expanded(child: _MetricCard(icon: Icons.timeline_rounded, title: 'Баланс', value: '${_wins(monthList)}-${_draws(monthList)}-${_losses(monthList)}')),
      ],
    );
  }

  void _showDayMatches(DateTime day, List<Map<String, dynamic>> list) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 30, offset: Offset(0, 12))]),
        child: SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const _CmrIconBox(icon: Icons.sports_soccer_rounded),
                  const SizedBox(width: 12),
                  Expanded(child: Text('Матчи • ${_dateRu(day)}', style: _C.title.copyWith(fontSize: 18))),
                  IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                ],
              ),
              const SizedBox(height: 12),
              ...list.map((m) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: _CmrMatchTile(
                      eventType: _eventTypeLabel(_s(m['event_type'])),
                      opponent: _s(m['opponent']),
                      date: _dateRu(_parseDate(_s(m['match_date']))),
                      competition: _s(m['competition_name']),
                      stadium: _s(m['stadium']),
                      score: '${_i(m['our_score'])}:${_i(m['opponent_score'])}',
                      upcoming: _isUpcoming(_parseDate(_s(m['match_date']))),
                      canEdit: canEdit,
                      onTap: () {
                        Navigator.pop(context);
                        _openDetails(m);
                      },
                      onDelete: () => _deleteMatch(m),
                    ),
                  )),
            ],
          ),
        ),
      ),
    );
  }
}

class _MonthMatchesGrid extends StatelessWidget {
  final DateTime month;
  final Map<DateTime, List<Map<String, dynamic>>> matchesByDay;
  final String Function(DateTime) dateText;
  final void Function(DateTime day, List<Map<String, dynamic>> matches) onDayTap;

  const _MonthMatchesGrid({required this.month, required this.matchesByDay, required this.dateText, required this.onDayTap});

  @override
  Widget build(BuildContext context) {
    const weekdays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    final first = DateTime(month.year, month.month, 1);
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final offset = first.weekday - 1;
    final total = offset + daysInMonth;
    final cells = ((total / 7).ceil()) * 7;

    return Column(
      children: [
        Row(children: weekdays.map((d) => Expanded(child: Center(child: Text(d, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w900, fontSize: 12))))).toList()),
        const SizedBox(height: 8),
        Expanded(
          child: GridView.builder(
            padding: EdgeInsets.zero,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 7, mainAxisSpacing: 8, crossAxisSpacing: 8, childAspectRatio: 1.05),
            itemCount: cells,
            itemBuilder: (_, index) {
              final dayNumber = index - offset + 1;
              final inMonth = dayNumber >= 1 && dayNumber <= daysInMonth;
              if (!inMonth) return const SizedBox.shrink();

              final day = DateTime(month.year, month.month, dayNumber);
              final list = matchesByDay[day] ?? const <Map<String, dynamic>>[];
              final today = DateTime.now();
              final isToday = day.year == today.year && day.month == today.month && day.day == today.day;

              return InkWell(
                borderRadius: BorderRadius.circular(18),
                onTap: () => onDayTap(day, list),
                child: Container(
                  padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(
                    color: list.isNotEmpty ? const Color(0xFFEFFDF5) : Colors.white,
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: isToday ? _C.green : (list.isNotEmpty ? const Color(0xFFBBF7D0) : _C.border), width: isToday ? 1.6 : 1),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text('$dayNumber', style: TextStyle(fontWeight: FontWeight.w900, color: isToday ? _C.green : _C.text, fontSize: 13)),
                          const Spacer(),
                          if (list.isNotEmpty)
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                              decoration: BoxDecoration(color: _C.darkGreen, borderRadius: BorderRadius.circular(99)),
                              child: Text('${list.length}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 10)),
                            ),
                        ],
                      ),
                      const Spacer(),
                      if (list.isNotEmpty)
                        ...list.take(2).map((m) => Padding(
                              padding: const EdgeInsets.only(top: 3),
                              child: Row(
                                children: [
                                  const Icon(Icons.sports_soccer_rounded, size: 11, color: _C.green),
                                  const SizedBox(width: 3),
                                  Expanded(child: Text((m['opponent'] ?? 'Соперник').toString(), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 10.5, color: _C.text))),
                                ],
                              ),
                            )),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

class _CmrAddMatchSheet extends StatefulWidget {
  final Future<bool> Function({
    required String eventType,
    required String opponent,
    required String ourScore,
    required String opponentScore,
    required String matchDate,
    required String competitionName,
    required String tourLabel,
    required String stadium,
    required String referees,
    required String notes,
  }) onSubmit;

  const _CmrAddMatchSheet({required this.onSubmit});

  @override
  State<_CmrAddMatchSheet> createState() => _CmrAddMatchSheetState();
}

class _CmrAddMatchSheetState extends State<_CmrAddMatchSheet> {
  final opponent = TextEditingController();
  final ourScore = TextEditingController(text: '0');
  final opponentScore = TextEditingController(text: '0');
  final competition = TextEditingController();
  final tour = TextEditingController();
  final stadium = TextEditingController();
  final referees = TextEditingController();
  final notes = TextEditingController();

  DateTime? picked;
  bool saving = false;
  String eventType = 'championship';

  @override
  void dispose() {
    opponent.dispose();
    ourScore.dispose();
    opponentScore.dispose();
    competition.dispose();
    tour.dispose();
    stadium.dispose();
    referees.dispose();
    notes.dispose();
    super.dispose();
  }

  String _iso(DateTime d) => '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
  String _ru(DateTime d) => '${d.day.toString().padLeft(2, '0')}.${d.month.toString().padLeft(2, '0')}.${d.year}';

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final res = await showDatePicker(context: context, initialDate: picked ?? now, firstDate: DateTime(now.year - 2), lastDate: DateTime(now.year + 3, 12, 31), helpText: 'Выберите дату матча');
    if (res != null) setState(() => picked = DateTime(res.year, res.month, res.day));
  }

  Future<void> _submit() async {
    if (opponent.text.trim().isEmpty || picked == null) {
      Get.snackbar('Ошибка', 'Заполните соперника и дату матча');
      return;
    }
    setState(() => saving = true);
    try {
      final ok = await widget.onSubmit(
        eventType: eventType,
        opponent: opponent.text,
        ourScore: ourScore.text,
        opponentScore: opponentScore.text,
        matchDate: _iso(picked!),
        competitionName: competition.text,
        tourLabel: tour.text,
        stadium: stadium.text,
        referees: referees.text,
        notes: notes.text,
      );
      if (ok && mounted) Navigator.pop(context, true);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final bottom = MediaQuery.of(context).viewInsets.bottom;
    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(bottom: bottom),
        child: Container(
          margin: const EdgeInsets.all(12),
          constraints: const BoxConstraints(maxWidth: 720),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 30, offset: Offset(0, 12))]),
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    const _CmrIconBox(icon: Icons.add_rounded),
                    const SizedBox(width: 12),
                    Expanded(child: Text('Добавить матч', style: _C.title.copyWith(fontSize: 19))),
                    IconButton(onPressed: saving ? null : () => Navigator.pop(context), icon: const Icon(Icons.close_rounded)),
                  ],
                ),
                const SizedBox(height: 12),
                _CmrFieldShell(
                  child: DropdownButtonFormField<String>(
                    value: eventType,
                    decoration: const InputDecoration(border: InputBorder.none, labelText: 'Тип матча'),
                    items: const [
                      DropdownMenuItem(value: 'championship', child: Text('Чемпионат')),
                      DropdownMenuItem(value: 'friendly', child: Text('Товарищеский')),
                      DropdownMenuItem(value: 'tournament', child: Text('Турнир')),
                    ],
                    onChanged: saving ? null : (v) => setState(() => eventType = v ?? 'championship'),
                  ),
                ),
                const SizedBox(height: 10),
                _CmrTextField(controller: opponent, icon: Icons.shield_outlined, hint: 'Соперник', onChanged: (_) => setState(() {})),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: _CmrTextField(controller: ourScore, icon: Icons.looks_one_rounded, hint: 'Наш счёт', keyboardType: TextInputType.number)),
                  const SizedBox(width: 10),
                  Expanded(child: _CmrTextField(controller: opponentScore, icon: Icons.looks_two_rounded, hint: 'Счёт соперника', keyboardType: TextInputType.number)),
                ]),
                const SizedBox(height: 10),
                _CmrFieldShell(onTap: saving ? null : _pickDate, child: Row(children: [
                  const Icon(Icons.calendar_month_rounded, size: 20, color: _C.muted),
                  const SizedBox(width: 8),
                  Expanded(child: Text(picked == null ? 'Выбрать дату матча' : _ru(picked!), style: TextStyle(fontWeight: FontWeight.w900, color: picked == null ? _C.muted : _C.text))),
                  const Icon(Icons.chevron_right_rounded, color: _C.muted),
                ])),
                const SizedBox(height: 10),
                _CmrTextField(controller: competition, icon: Icons.emoji_events_outlined, hint: 'Турнир / соревнование'),
                const SizedBox(height: 10),
                _CmrTextField(controller: tour, icon: Icons.format_list_numbered_rounded, hint: 'Тур / этап'),
                const SizedBox(height: 10),
                _CmrTextField(controller: stadium, icon: Icons.location_on_outlined, hint: 'Стадион'),
                const SizedBox(height: 10),
                _CmrTextField(controller: referees, icon: Icons.gavel_rounded, hint: 'Судьи'),
                const SizedBox(height: 10),
                _CmrTextField(controller: notes, icon: Icons.notes_rounded, hint: 'Примечания', maxLines: 3),
                const SizedBox(height: 14),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: !saving && opponent.text.trim().isNotEmpty && picked != null ? _submit : null,
                    icon: saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.check_rounded),
                    label: Text(saving ? 'Сохранение...' : 'Сохранить матч'),
                    style: ElevatedButton.styleFrom(backgroundColor: _C.green, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _CmrMatchTile extends StatelessWidget {
  final String eventType;
  final String opponent;
  final String date;
  final String competition;
  final String stadium;
  final String score;
  final bool upcoming;
  final bool canEdit;
  final VoidCallback onTap;
  final VoidCallback onDelete;

  const _CmrMatchTile({required this.eventType, required this.opponent, required this.date, required this.competition, required this.stadium, required this.score, required this.upcoming, required this.canEdit, required this.onTap, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.border)),
          child: Row(
            children: [
              Container(width: 46, height: 46, decoration: BoxDecoration(color: upcoming ? const Color(0xFFEFFDF5) : const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(15), border: Border.all(color: upcoming ? const Color(0xFFBBF7D0) : _C.border)), child: Icon(upcoming ? Icons.schedule_rounded : Icons.history_rounded, color: upcoming ? _C.green : _C.muted)),
              const SizedBox(width: 11),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Expanded(child: Text(opponent.isEmpty ? 'Соперник' : opponent, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 14.5))),
                    const SizedBox(width: 8),
                    Text(score, style: const TextStyle(fontWeight: FontWeight.w900, color: _C.darkGreen, fontSize: 16)),
                  ]),
                  const SizedBox(height: 5),
                  Text('$eventType • $date', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.green, fontWeight: FontWeight.w800, fontSize: 12)),
                  if (competition.isNotEmpty || stadium.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text([competition, stadium].where((e) => e.trim().isNotEmpty).join(' • '), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700, fontSize: 12)),
                  ],
                ]),
              ),
              const SizedBox(width: 8),
              if (canEdit)
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_horiz_rounded, color: _C.muted),
                  onSelected: (v) {
                    if (v == 'delete') onDelete();
                  },
                  itemBuilder: (_) => const [PopupMenuItem(value: 'delete', child: Text('Удалить'))],
                )
              else
                const Icon(Icons.chevron_right_rounded, color: _C.muted),
            ],
          ),
        ),
      ),
    );
  }
}

class _MetricCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String value;
  const _MetricCard({required this.icon, required this.title, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(20), border: Border.all(color: _C.border)),
      child: Row(children: [
        Icon(icon, color: _C.green, size: 20),
        const SizedBox(width: 9),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, color: _C.text, fontSize: 16)),
          const SizedBox(height: 2),
          Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700, color: _C.muted, fontSize: 11)),
        ])),
      ]),
    );
  }
}

class _SelectedMatchesHeader extends StatelessWidget {
  final String title;
  final bool canEdit;
  final VoidCallback onAdd;
  const _SelectedMatchesHeader({required this.title, required this.canEdit, required this.onAdd});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Expanded(child: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: _C.title.copyWith(fontSize: 15))),
      if (canEdit) _TopActionButton(icon: Icons.add_rounded, text: 'Матч', onTap: onAdd),
    ]);
  }
}

class _CmrSearch extends StatelessWidget {
  final TextEditingController controller;
  final String hint;
  final VoidCallback onClear;
  const _CmrSearch({required this.controller, required this.hint, required this.onClear});

  @override
  Widget build(BuildContext context) {
    return _CmrFieldShell(child: Row(children: [
      const Icon(Icons.search_rounded, size: 22, color: _C.muted),
      const SizedBox(width: 8),
      Expanded(child: TextField(controller: controller, decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true, hintStyle: const TextStyle(color: _C.muted)), textInputAction: TextInputAction.search)),
      if (controller.text.isNotEmpty) IconButton(padding: EdgeInsets.zero, constraints: const BoxConstraints(), icon: const Icon(Icons.close_rounded, size: 20), onPressed: onClear),
    ]));
  }
}

class _CmrTextField extends StatelessWidget {
  final TextEditingController controller;
  final IconData icon;
  final String hint;
  final TextInputType? keyboardType;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  const _CmrTextField({required this.controller, required this.icon, required this.hint, this.keyboardType, this.maxLines = 1, this.onChanged});

  @override
  Widget build(BuildContext context) {
    return _CmrFieldShell(child: Row(crossAxisAlignment: maxLines > 1 ? CrossAxisAlignment.start : CrossAxisAlignment.center, children: [
      Padding(padding: EdgeInsets.only(top: maxLines > 1 ? 10 : 0), child: Icon(icon, size: 20, color: _C.muted)),
      const SizedBox(width: 8),
      Expanded(child: TextField(controller: controller, keyboardType: keyboardType, maxLines: maxLines, onChanged: onChanged, decoration: InputDecoration(hintText: hint, border: InputBorder.none, isDense: true, hintStyle: const TextStyle(color: _C.muted)))),
    ]));
  }
}

class _CmrFieldShell extends StatelessWidget {
  final Widget child;
  final VoidCallback? onTap;
  const _CmrFieldShell({required this.child, this.onTap});

  @override
  Widget build(BuildContext context) {
    final box = Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7), decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(16), border: Border.all(color: _C.border)), child: child);
    if (onTap == null) return box;
    return Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(16), onTap: onTap, child: box));
  }
}

class _FilterButton extends StatelessWidget {
  final String text;
  final bool active;
  final VoidCallback onTap;
  const _FilterButton({required this.text, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 42,
        alignment: Alignment.center,
        decoration: BoxDecoration(color: active ? _C.darkGreen : const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(16), border: Border.all(color: active ? _C.darkGreen : _C.border)),
        child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: active ? Colors.white : _C.text, fontWeight: FontWeight.w900, fontSize: 12)),
      ),
    );
  }
}

class _TopActionButton extends StatelessWidget {
  final IconData icon;
  final String text;
  final VoidCallback onTap;
  const _TopActionButton({required this.icon, required this.text, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        height: 42,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(color: const Color(0xFFEFFDF5), borderRadius: BorderRadius.circular(16), border: Border.all(color: const Color(0xFFBBF7D0))),
        child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(icon, size: 18, color: _C.green), const SizedBox(width: 6), Text(text, style: const TextStyle(color: _C.green, fontWeight: FontWeight.w900, fontSize: 12))]),
      ),
    );
  }
}

class _SquareButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _SquareButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(15),
      onTap: onTap,
      child: Container(width: 42, height: 42, decoration: BoxDecoration(color: const Color(0xFFF8FAFC), borderRadius: BorderRadius.circular(15), border: Border.all(color: _C.border)), child: Icon(icon, color: _C.text)),
    );
  }
}

class _HeaderIconButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _HeaderIconButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(width: 42, height: 42, decoration: BoxDecoration(color: Colors.white.withOpacity(.12), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(.12))), child: Icon(icon, color: Colors.white, size: 21)),
    );
  }
}

class _HeroStat extends StatelessWidget {
  final String value;
  final String title;
  const _HeroStat({required this.value, required this.title});

  @override
  Widget build(BuildContext context) {
    return Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10), decoration: BoxDecoration(color: Colors.white.withOpacity(.10), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(.10))), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 17)),
      const SizedBox(height: 2),
      Text(title, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(.66), fontWeight: FontWeight.w700, fontSize: 11)),
    ]));
  }
}

class _CmrIconBox extends StatelessWidget {
  final IconData icon;
  final bool dark;
  const _CmrIconBox({required this.icon, this.dark = false});

  @override
  Widget build(BuildContext context) {
    return Container(width: 46, height: 46, decoration: BoxDecoration(color: dark ? Colors.white.withOpacity(.12) : const Color(0xFFEFFDF5), borderRadius: BorderRadius.circular(16), border: Border.all(color: dark ? Colors.white.withOpacity(.12) : const Color(0xFFBBF7D0))), child: Icon(icon, color: dark ? Colors.white : _C.green));
  }
}

class _MiniEmpty extends StatelessWidget {
  final String text;
  const _MiniEmpty({required this.text});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(20), child: Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700))));
}

class _CmrEmptyState extends StatelessWidget {
  final IconData icon;
  final String title;
  final String text;
  final String actionText;
  final VoidCallback onAction;
  const _CmrEmptyState({required this.icon, required this.title, required this.text, required this.actionText, required this.onAction});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        width: 420,
        padding: const EdgeInsets.all(22),
        decoration: _C.cardDecoration,
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, color: _C.green, size: 42),
          const SizedBox(height: 12),
          Text(title, textAlign: TextAlign.center, style: _C.title.copyWith(fontSize: 18)),
          const SizedBox(height: 8),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: _C.muted, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          _TopActionButton(icon: Icons.refresh_rounded, text: actionText, onTap: onAction),
        ]),
      ),
    );
  }
}

class _C {
  static const Color bg = Color(0xFFF3F5F8);
  static const Color text = Color(0xFF0F172A);
  static const Color muted = Color(0xFF64748B);
  static const Color border = Color(0xFFE5E7EB);
  static const Color green = Color(0xFF16A34A);
  static const Color darkGreen = Color(0xFF0F3D2E);
  static const Color red = Color(0xFFEF4444);

  static const TextStyle title = TextStyle(color: text, fontWeight: FontWeight.w900, letterSpacing: -.2);
  static const TextStyle darkTitle = TextStyle(color: Colors.white, fontWeight: FontWeight.w900, letterSpacing: -.2);

  static BoxDecoration get cardDecoration => BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(28), border: Border.all(color: border), boxShadow: const [BoxShadow(color: Color(0x0F000000), blurRadius: 22, offset: Offset(0, 10))]);
}
