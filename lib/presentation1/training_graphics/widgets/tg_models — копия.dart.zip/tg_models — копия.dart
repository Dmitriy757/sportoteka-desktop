import 'package:flutter/material.dart';

import '../training_graphics_state.dart';
import '../tg_painter.dart';

class TgCanvas extends StatelessWidget {
  final Color primary;
  final TgState state;

  const TgCanvas({
    super.key,
    required this.primary,
    required this.state,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: state,
      builder: (_, __) {
        return ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Container(
            color: Colors.white,
            child: Stack(
              children: [
                // поле
                Positioned.fill(
                  child: Image.asset(
                    "assets/training/field.png", // ✅ положи сюда твою картинку поля
                    fit: BoxFit.cover,
                  ),
                ),

                // интерактив (zoom/pan) + рисование
                Positioned.fill(
                  child: InteractiveViewer(
                    transformationController: state.transform,
                    minScale: 0.6,
                    maxScale: 3.0,
                    panEnabled: !state.isDrawingNow, // ✅ иначе “съезжает”
                    scaleEnabled: true,
                    child: RepaintBoundary(
                      key: state.repaintKey,
                      child: GestureDetector(
                        behavior: HitTestBehavior.opaque,
                        onTapUp: (d) => state.onTapCanvas(d.localPosition),
                        onPanStart: (d) {
                          // рисуем только на инструментах рисования
                          if (state.tool == TgTool.select) return;
                          state.onPanStart(d.localPosition);
                        },
                        onPanUpdate: (d) {
                          if (state.tool == TgTool.select) return;
                          state.onPanUpdate(d.localPosition);
                        },
                        onPanEnd: (_) {
                          if (state.tool == TgTool.select) return;
                          state.onPanEnd();
                        },
                        child: CustomPaint(
                          painter: TgPainter(
                            elements: state.elements,
                            preview: state.preview,
                            selectedId: state.selectedId,
                          ),
                          child: const SizedBox(
                            width: 1200,
                            height: 1800,
                          ),
                        ),
                      ),
                    ),
                  ),
                ),

                // маленькая кнопка панели (на мобильном)
                Positioned(
                  right: 10,
                  top: 10,
                  child: Material(
                    color: Colors.white.withOpacity(0.92),
                    borderRadius: BorderRadius.circular(12),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(12),
                      onTap: state.toggleRightPanel,
                      child: Padding(
                        padding: const EdgeInsets.all(10),
                        child: Icon(
                          Icons.tune_rounded,
                          color: primary,
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
